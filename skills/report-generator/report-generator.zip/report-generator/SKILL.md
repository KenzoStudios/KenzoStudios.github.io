---
name: "report-generator"
description: "Generate professional data reports with charts, tables, and visualizations"
---

# Report Generator Skill

## Overview

This skill enables automatic generation of professional data reports. Create dashboards, KPI summaries, and analytical reports with charts, tables, and insights from your data.

Every report uses a house colour palette (maroon by default; five alternatives are listed under Palettes) and fonts below. The shared files in `assets/` hold them, so use those instead of writing colours by hand:
- `assets/report.css`: the stylesheet for HTML and PDF reports (embed it inline in the report's `<style>`).
- `assets/theme.py`: the matplotlib theme (`theme.apply()`, `theme.SERIES`, `theme.PALETTE`, `theme.style_table()`).

## Step 0: ask which palette (always do this first)

When the user invokes `/report-generator`, **before generating anything**, show an interactive palette grid so they choose.
Skip it only if the request already names a palette (e.g. "make it navy"); use that one and say so.

**Show all six palettes at once in a grid, with their colours.** Do not use `AskUserQuestion` for this: it shows at most 4 options
and hides the rest behind "Other", and it cannot display colour swatches.

1. Silently call `mcp__visualize__read_me` (modules `["interactive"]`), then call `mcp__visualize__show_widget` with
   `title: "report_palette_picker"` and `widget_code` set to the exact contents of `assets/palette-picker.html`
   (read the file, pass it unchanged). Do not narrate these calls.
2. The widget is a 3 x 2 grid of cards (2 x 3 on narrow screens). Each card shows the palette's name on its deepest colour,
   a swatch strip of its other five colours, a one-line description and its key hex codes. Clicking a card sends
   "Use the <name> palette for the report." to the chat.
3. Add one short line under the widget, e.g. "Pick a palette above and I'll continue." Then stop and wait for the click.
   If the user types a palette name instead, use that.
4. **Fallback** only if `mcp__visualize__show_widget` is unavailable: print the six palettes as a table (name, three hex codes)
   and ask the user to reply with a name.

Then use the choice everywhere: `<html data-palette="NAME">` for HTML/PDF, `theme.apply("NAME")` for charts (omit the attribute
for maroon). Mention the chosen palette in one line when delivering the report. Do not ask again later in the same session
unless the user asks to change it.

## How to Use

1. Provide data (CSV, Excel, JSON, or describe it)
2. Specify the type of report needed
3. I'll generate a formatted report with visualizations

**Example prompts:**
- "Generate a sales report from this data"
- "Create a monthly KPI dashboard"
- "Build an executive summary with charts"
- "Produce a data analysis report"

## Palettes

Six palettes share the same roles. The token names in the table below are **roles** (`oxblood` is always the deepest shade,
`rose` the lightest series colour), so every rule that follows holds in every palette. Use one palette per report and never mix them.

| Palette | Deepest | Accent | Lightest series | Feel |
|---|---|---|---|---|
| `maroon` (default) | `#4A0F1C` | `#9B2335` | `#D49AA4` | Warm, formal |
| `forest` | `#12301F` | `#2F7A4F` | `#A8CDB6` | Calm, sustainability, finance |
| `navy` | `#0F2442` | `#2A5FA8` | `#A9C4E3` | Corporate, trustworthy |
| `plum` | `#2E1240` | `#6C3A8C` | `#C5A8D8` | Creative, premium |
| `terracotta` | `#4A1E0E` | `#B04A24` | `#EDB898` | Warm, editorial |
| `graphite` | `#1A1D21` | `#4F5861` | `#B9C0C7` | Neutral, technical |

- **HTML/PDF:** set `<html data-palette="forest">` (omit for maroon). `assets/report.css` remaps the roles.
- **matplotlib:** `theme.apply("forest")`, or `theme.use("forest")` to switch `theme.PALETTE` and `theme.SERIES`.
- **Own CSS:** `theme.css_tokens("forest")` returns a `:root{...}` block of tokens.
- Page numbers in the PDF margin are a fixed neutral grey, because `@page` boxes cannot read tokens.
- Two-page examples of each palette are in `samples/` (`sample-<palette>.html` and `.pdf`), built from the same fictional report so they compare directly.

## Colour palette (maroon, the default)

The maroon/crimson family plus warm greys. **No gold and no blue anywhere**, including chart defaults, links, focus rings and
library themes. Never use a colour that isn't in this table.

| Name | Hex | Use |
|---|---|---|
| Oxblood | `#4A0F1C` | Title bands, darkest chart series, headings |
| Maroon | `#6E1A2C` | Table headers, header rule, sub-headings |
| Crimson | `#9B2335` | Eyebrow labels, bullets, accent bars, critical-point callouts |
| Claret | `#B5485A` | Mid chart series |
| Rose | `#D49AA4` | Light chart series, large numerals |
| Blush | `#F5E9EB` | Callout backgrounds, table total rows |
| Ink | `#262224` | Body text |
| Slate | `#55504F` | Secondary text, labels |
| Ash | `#8E8888` | Captions, axis labels, page numbers |
| Mist | `#E4E0E0` | Gridlines, table row dividers |
| Paper | `#F6F4F4` | Zebra table rows, neutral callout backgrounds |

White (`#FFFFFF`) is used only for the page background and for text on oxblood or maroon.

**Rules**
- **Charts:** use the series in this order: oxblood, maroon, crimson, claret, rose. Gridlines are mist, axis text is ash, and charts have no borders (no spines, no frame, no legend box).
- **Tables:** maroon header row with white text, alternate rows paper, mist dividers between rows, and the totals row on blush.
- **Callouts:** a light background with a 2.5pt left bar. Use blush with a crimson bar for key points, and paper with an ash bar for examples.
- **Type:** a serif for headings (Caladea; fall back to Cambria or Georgia) and a sans for body text (Carlito; fall back to Calibri, Helvetica Neue or Arial). Headings are oxblood, sub-headings maroon, eyebrow labels crimson in small capitals, body text ink, secondary text slate, captions and page numbers ash.
- **Structure:** an oxblood title band at the top (white title, rose eyebrow, mist subtitle), h2 headings with a maroon rule beneath them, and crimson bullets and accent bars.
- **Large numerals** (KPIs) are rose, or oxblood when they need more weight.

## Domain Knowledge

### Report Components

```python
# Report structure
report = {
    'title': 'Monthly Sales Report',
    'period': 'January 2024',
    'sections': [
        'executive_summary',
        'kpi_dashboard',
        'detailed_analysis',
        'charts',
        'recommendations'
    ]
}
```

### Using Python for Reports

```python
import os, sys
import pandas as pd
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.expanduser("~/.claude/skills/report-generator/assets"))
import theme

def generate_report(data, output_path):
    theme.apply()  # house palette: series order, mist gridlines, ash axis text, no borders

    # Load data
    df = pd.read_csv(data)

    # Calculate KPIs
    total_revenue = df['revenue'].sum()
    avg_order = df['revenue'].mean()
    growth = df['revenue'].pct_change().mean()

    # Create charts (colours come from theme.apply(); don't pass other colours)
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    df.plot(kind='bar', ax=axes[0,0], title='Revenue by Month')
    df.plot(kind='line', ax=axes[0,1], title='Trend')
    plt.savefig('charts.png', dpi=200)

    # Generate the PDF by printing the HTML report (below) with headless Chrome,
    # so the PDF uses the same stylesheet.

    return output_path
```

### Charts without matplotlib (inline SVG)

When matplotlib isn't available, draw charts as inline SVG and let `report.css` colour them. Give each series a class
`s1` to `s5` in order (s1 oxblood, s2 maroon, s3 crimson, s4 claret, s5 rose), gridlines the class `grid`, and lines
the extra class `line`. Axis text inherits ash. Never set `fill` or `stroke` colours inline.

```html
<figure>
  <svg class="chart" viewBox="0 0 600 220" role="img" aria-label="Revenue by quarter">
    <line class="grid" x1="40" x2="590" y1="20" y2="20"/>   <!-- one per gridline -->
    <rect class="s1" x="60" y="80" width="40" height="120"/>  <!-- series 1 bar -->
    <polyline class="s3 line" points="80,120 200,90 320,70"/> <!-- series 3 line -->
    <text x="80" y="214" text-anchor="middle">Q1</text>
  </svg>
  <figcaption>Revenue by quarter, £m</figcaption>
</figure>
```

### HTML Report Template

Embed `assets/report.css` inline so the file is self-contained, then use these building blocks.

```python
import os

CSS = open(os.path.expanduser("~/.claude/skills/report-generator/assets/report.css")).read()

def generate_html_report(data, title):
    html = f'''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <title>{title}</title>
        <style>{CSS}</style>
    </head>
    <body>
      <div class="page">
        <header class="title-band">
            <div class="eyebrow">Monthly report</div>
            <h1>{title}</h1>
            <p class="subtitle">January 2024</p>
        </header>

        <h2>Key figures</h2>
        <div class="kpis">
            <div class="kpi"><div class="value">${data['revenue']:,.0f}</div><div class="label">Total revenue</div></div>
            <div class="kpi"><div class="value">{data['growth']:.1%}</div><div class="label">Growth rate</div></div>
        </div>

        <div class="callout"><span class="eyebrow">Key point</span>Revenue grew faster than costs.</div>
        <div class="callout example"><span class="eyebrow">Example</span>A worked example goes here.</div>

        <table>
            <thead><tr><th>Product</th><th class="num">Revenue</th></tr></thead>
            <tbody><tr><td>A</td><td class="num">120</td></tr><tr><td>B</td><td class="num">80</td></tr></tbody>
            <tfoot><tr><td>Total</td><td class="num">200</td></tr></tfoot>
        </table>

        <footer class="footer"><span>Source: internal data</span><span>Page 1</span></footer>
      </div>
    </body>
    </html>
    '''
    return html
```

## Example: Sales Report

```python
import os, sys
import pandas as pd
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.expanduser("~/.claude/skills/report-generator/assets"))
import theme

def create_sales_report(csv_path, output_path):
    theme.apply()

    # Read data
    df = pd.read_csv(csv_path)

    # Calculate metrics
    metrics = {
        'total_revenue': df['amount'].sum(),
        'total_orders': len(df),
        'avg_order': df['amount'].mean(),
        'top_product': df.groupby('product')['amount'].sum().idxmax()
    }

    # Create visualizations (series colours follow theme.SERIES in order)
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    # Revenue by product
    df.groupby('product')['amount'].sum().plot(
        kind='bar', ax=axes[0,0], title='Revenue by Product', color=theme.SERIES[0]
    )

    # Monthly trend
    df.groupby('month')['amount'].sum().plot(
        kind='line', ax=axes[0,1], title='Monthly Revenue', color=theme.SERIES[0]
    )

    plt.tight_layout()
    plt.savefig(output_path.replace('.html', '_charts.png'), dpi=200)

    # Generate HTML report
    html = generate_html_report(metrics, 'Sales Report')

    with open(output_path, 'w') as f:
        f.write(html)

    return output_path

create_sales_report('sales_data.csv', 'sales_report.html')
```

### PDF output

Print the HTML report with headless Chrome so the PDF uses the same stylesheet, fonts and colours:

```bash
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --no-pdf-header-footer \
  --print-to-pdf=report.pdf report.html
```

Before sharing a report, check that every colour in it is from the palette table (no blue or gold from library defaults).

## Resources

- [Matplotlib](https://matplotlib.org/)
- [Plotly](https://plotly.com/)
- [ReportLab](https://www.reportlab.com/)
