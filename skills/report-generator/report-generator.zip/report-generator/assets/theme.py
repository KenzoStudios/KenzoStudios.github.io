"""Report Generator house style for charts. Six palettes: maroon (default), forest, navy, plum, terracotta, graphite.

    import sys; sys.path.insert(0, os.path.expanduser("~/.claude/skills/report-generator/assets"))
    import theme; theme.apply()            # matplotlib defaults: colour cycle, gridlines, axis text, fonts
    theme.SERIES                           # ["#4A0F1C", "#6E1A2C", "#9B2335", "#B5485A", "#D49AA4"]
    theme.style_table(ax_table)            # matplotlib table: maroon header, paper zebra, blush totals

Every colour comes from PALETTE; never hard-code another hex value.
"""
# Palettes. The token names (oxblood ... paper) are ROLES, not colours: "oxblood" is always the deepest shade
# (title band, headings), "rose" the lightest series colour, and so on. Each palette fills the same roles.
# The first, "maroon", is the house default. Use one palette per report; never mix palettes.
_ROLES = ("oxblood", "maroon", "crimson", "claret", "rose", "blush", "ink", "slate", "ash", "mist", "paper")
_P = lambda *v: dict(zip(_ROLES, v), white="#FFFFFF")
PALETTES = {
    "maroon":     _P("#4A0F1C", "#6E1A2C", "#9B2335", "#B5485A", "#D49AA4", "#F5E9EB", "#262224", "#55504F", "#8E8888", "#E4E0E0", "#F6F4F4"),
    "forest":     _P("#12301F", "#1E4D34", "#2F7A4F", "#5C9E78", "#A8CDB6", "#E9F3ED", "#1F2622", "#4E5A53", "#87918B", "#DFE5E1", "#F3F6F4"),
    "navy":       _P("#0F2442", "#17365F", "#2A5FA8", "#5B8CC4", "#A9C4E3", "#E8EFF8", "#1E2430", "#4C5668", "#858FA0", "#DEE3EA", "#F3F5F8"),
    "plum":       _P("#2E1240", "#46205F", "#6C3A8C", "#9468B0", "#C5A8D8", "#F1EAF6", "#261F2B", "#564D5E", "#8D8595", "#E4DFE8", "#F6F4F8"),
    "terracotta": _P("#4A1E0E", "#7A3317", "#B04A24", "#D17B55", "#EDB898", "#FAEDE5", "#2A2220", "#5A4F4A", "#918883", "#E8E0DB", "#F8F5F2"),
    "graphite":   _P("#1A1D21", "#2F353C", "#4F5861", "#7F8993", "#B9C0C7", "#EDF0F2", "#1B1E21", "#4B5258", "#868D94", "#E0E3E6", "#F4F5F6"),
}
DEFAULT_PALETTE = "maroon"
PALETTE = dict(PALETTES[DEFAULT_PALETTE])
SERIES = [PALETTE[k] for k in ("oxblood", "maroon", "crimson", "claret", "rose")]  # chart series, always this order
SERIF = ["Caladea", "Cambria", "Georgia", "DejaVu Serif", "serif"]
SANS = ["Carlito", "Calibri", "Helvetica Neue", "Arial", "DejaVu Sans", "sans-serif"]


def use(name=DEFAULT_PALETTE):
    """Switch the module-level PALETTE and SERIES to a named palette (maroon, forest, navy, plum, terracotta, graphite)."""
    global PALETTE, SERIES
    if name not in PALETTES:
        raise KeyError(f"Unknown palette {name!r}; choose from {', '.join(PALETTES)}")
    PALETTE = dict(PALETTES[name])
    SERIES = [PALETTE[k] for k in ("oxblood", "maroon", "crimson", "claret", "rose")]
    return PALETTE


def css_tokens(name=DEFAULT_PALETTE):
    """The :root colour-token block for a palette, to inline in a report's <style> instead of using data-palette."""
    return ":root{" + "".join(f"--{k}:{v};" for k, v in PALETTES[name].items()) + "}"


def apply(name=None):
    """Set matplotlib defaults: series colours in order, mist gridlines, ash axis text, no chart borders.
    Pass a palette name (e.g. apply("forest")) to chart in that palette."""
    if name:
        use(name)
    import matplotlib as mpl
    from cycler import cycler
    mpl.rcParams.update({
        "axes.prop_cycle": cycler(color=SERIES),
        "font.family": "sans-serif", "font.sans-serif": SANS, "font.serif": SERIF,
        "text.color": PALETTE["ink"],
        "axes.titlecolor": PALETTE["oxblood"], "axes.titleweight": "bold", "axes.titlelocation": "left",
        "axes.labelcolor": PALETTE["ash"], "xtick.color": PALETTE["ash"], "ytick.color": PALETTE["ash"],
        "axes.edgecolor": PALETTE["mist"],
        "axes.spines.top": False, "axes.spines.right": False, "axes.spines.left": False, "axes.spines.bottom": False,
        "axes.grid": True, "axes.grid.axis": "y", "grid.color": PALETTE["mist"], "grid.linewidth": 0.8,
        "axes.axisbelow": True, "axes.facecolor": PALETTE["white"], "figure.facecolor": PALETTE["white"],
        "savefig.facecolor": PALETTE["white"], "legend.frameon": False, "legend.labelcolor": PALETTE["slate"],
        "xtick.major.size": 0, "ytick.major.size": 0,
    })


def style_table(table, total_row=None):
    """Style a matplotlib table: maroon header with white text, paper zebra rows, mist dividers, blush totals."""
    for (row, _), cell in table.get_celld().items():
        cell.set_edgecolor(PALETTE["mist"])
        if row == 0:
            cell.set_facecolor(PALETTE["maroon"])
            cell.get_text().set_color(PALETTE["white"])
            cell.get_text().set_fontweight("bold")
        elif total_row is not None and row == total_row:
            cell.set_facecolor(PALETTE["blush"])
            cell.get_text().set_color(PALETTE["oxblood"])
            cell.get_text().set_fontweight("bold")
        else:
            cell.set_facecolor(PALETTE["paper"] if row % 2 == 0 else PALETTE["white"])
            cell.get_text().set_color(PALETTE["ink"])
