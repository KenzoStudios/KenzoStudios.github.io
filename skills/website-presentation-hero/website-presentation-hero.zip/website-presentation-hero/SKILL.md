---
name: website-presentation-hero
description: WebsitePresentationHero. End-to-end workflow for building art-directed, non-generic websites, landing pages, hero sections, portfolios, product pages, redesigns and scroll-based web presentations, then proving them in a real browser. Combines Taste Skill (anti-slop design direction), Image-to-Code (reference-first, extract-then-build), the awesome-design-md library (84 real-site design systems), Vercel's Web Interface Guidelines (a11y / UX audit) and Microsoft's playwright-cli (screenshots and checks at every viewport). Use when the user asks for a beautiful / premium / modern site, page, hero, landing page, one-pager or web presentation, a redesign, a site that "looks like" a named brand, or a design review of one.
---

# WebsitePresentationHero

One workflow, five sources. The short rules you need on every job are in this file; the full source texts are in `references/` for when you need depth:

| File | What it is | Read it when |
|---|---|---|
| `references/taste.md` | Taste Skill v2 (Leonxlnx, tasteskill.dev): brief inference, dials, design-system map, layout discipline, AI tells, redesign protocol, motion skeletons (GSAP sticky-stack, horizontal pan), full pre-flight | Always skim §0-1 and §14; §5 for motion, §11 for redesigns, Appendix A for official design-system installs |
| `references/image-to-code.md` | Image-to-Code (Leonxlnx): reference first, deep image analysis, extraction rules, variation engine, section packs | When you have (or can make) reference images |
| `references/designs/<site>.md` | 84 DESIGN.md analyses of real sites (VoltAgent/awesome-design-md) | When a brand or "like X" is named, or you need a credible system to start from |
| `references/web-interface-guidelines.md` | Vercel Web Interface Guidelines (snapshot) | The audit pass; fetch the live copy if online |
| `references/playwright-cli.md` | playwright-cli command reference | Every visual check |

## The workflow

Work through the phases in order. Don't skip phase 4: a page that hasn't been looked at in a browser isn't done.

### Phase 0: Read the brief

1. **Brand override first.** If the site belongs to an organisation with its own brand skill or design system (for IE University: `anthropic-skills:ie-brand`, WCAG 2.1 AA), that system wins over everything below; use the rest of this skill only for craft, layout and verification.
2. **Signals** (taste §0.A): page kind, vibe words, references (URLs, screenshots, named brands), audience, existing brand assets, quiet constraints (accessibility, public sector, regulated). Constraints beat aesthetics.
3. **Mode:** new build, redesign-preserve, or redesign-overhaul (taste §11). For a redesign, screenshot and audit the existing site first (phase 4 tools) and list the brand tokens to keep.
4. **Say the Design Read in one line before any code:** *"Reading this as: <page kind> for <audience>, with a <vibe> language, leaning toward <system or aesthetic family>."*
5. **Set the dials** from the read (taste §1): `DESIGN_VARIANCE`, `MOTION_INTENSITY`, `VISUAL_DENSITY`, 1-10 each. Baseline 8/6/4; minimalist/editorial 5/3/2; premium consumer 7/6/3; agency/experimental 9/8/3; trust-first 3/2/5. State them.
6. Ask **one** question only if the read genuinely forks (e.g. "Linear-clean or Awwwards-experimental?"). Otherwise proceed.

### Phase 1: Get a reference (the image-first step)

The image-to-code principle: never free-design straight into code for a visual brief. Get a concrete visual reference, analyse it, then build to it. In order of preference:

1. **User-supplied screenshots or mockups**: these are the spec.
2. **An image-generation tool, if this environment has one**: generate one large, readable reference per section (not one compressed board), per `references/image-to-code.md` §2-7.
3. **A DESIGN.md from the library**: `ls references/designs/`, pick the closest 1-2 to the read, read the whole file. Use its tokens and rules as the system; never its logo, name, product imagery or licensed fonts (swap SF Pro / Söhne etc. for open equivalents such as Geist, Inter Tight, Switzer).
4. **Screenshots of live reference sites** the user named, captured with playwright-cli (phase 4 commands) at 1440×900, then read the PNGs.

Then **analyse the reference like a spec** (image-to-code §9, §21-25): headline wording and line count, type character and scale ratios, alignment, section spacing and gutters, radius logic, button shapes and hierarchy, palette and the single accent, background and image treatment, grid, section order and density, the motifs that make it look the way it does. Write the extracted system down (tokens as CSS variables) before building; on a multi-page job, save it as the project's `DESIGN.md`.

### Phase 2: Plan the page

- **Sections:** pick a pack that fits the content (4: hero, features, proof, CTA; 8 adds trust bar, showcase, use cases, pricing; 12 adds problem/solution, workflow, metrics, FAQ). Only what the content supports.
- **Layout families:** each section gets a family (split, full-bleed media, bento, sticky-stack, horizontal pan, marquee, vertical stack, quote, logo wall...). No family twice; at least 4 families across 8 sections; at most 2 image/text zigzags in a row.
- **Locks, decided now and kept everywhere:** one theme (light, dark, or auto) for the whole page; one accent colour; one radius system; one type pairing; one icon library (Phosphor / Tabler / Radix / HugeIcons); one label per CTA intent.
- **Web presentation mode** (when the user wants a talk, pitch or walkthrough as a web page): each slide is a full-viewport section (`min-height: 100dvh`, `scroll-snap-type: y mandatory`), every slide obeys the hero rules below, keyboard arrows / PageUp / PageDown move between slides, and a reduced-motion variant drops the transitions.

### Phase 3: Build

**Stack.** Match the project if there is one. Otherwise: a single self-contained HTML file with inline CSS and minimal JS for one page; Vite (or Next.js if asked) + Tailwind for more. Verify every dependency exists before importing it (taste §3.F). Use the official package when the brief maps to a real design system (taste §2).

**The hero (the rules that matter most; where the sources differ, the stricter wins):**
- Fits the first viewport on a small laptop (1280×720): headline at most **2 lines** on desktop, subtext at most **20 words** and 4 lines, primary CTA visible without scrolling.
- At most 4 text elements: eyebrow *or* brand strip (or neither), headline, subtext, CTAs (1 primary + at most 1 secondary). No trust strip, pricing teaser, bullet list, avatar row or tagline under the CTAs: those get their own sections below.
- One focal point and a **real visual** (generated image, real photo, real product screenshot, or a real live component). Never a gradient blob, never a fake UI made of `<div>`s.
- Plan font size and image size together: `clamp()` from about 2.25rem to 4rem for most headlines; go bigger only for 3-5 word headlines. Top padding at most ~6rem. Nav one line, 64-72 px tall.
- Avoid a centred hero when `DESIGN_VARIANCE > 4` (split, left-aligned with asset right, asymmetric space) unless it's a manifesto or launch.

**Craft defaults (taste §4, §9; image-to-code §16-17, §29):**
- Type: not Inter / not a serif by default; never Fraunces or Instrument Serif as a reflex. Emphasis is italic or bold of the same family. Body `max-width: 65ch`. `text-wrap: balance` on headings. Italic descenders get `line-height ≥ 1.1` plus bottom padding.
- Colour: neutral base + one accent under 80% saturation; no AI purple-blue glow, no neon, no pure `#000`; no beige + brass + espresso by reflex on premium-consumer briefs; shadows tinted to the background.
- Layout: no three equal feature cards; no cards inside cards inside cards; bento has exactly as many cells as content and at least 2-3 cells with real visual variation; no split headers (headline left, tiny paragraph right); eyebrows at most 1 per 3 sections; mobile fallback declared for every multi-column block.
- Content: no em dashes or en dashes anywhere visible (hyphen only); no "Acme", "John Doe", 99.99%, "Elevate / Seamless / Unleash"; no version labels, section numbers, scroll cues, decorative dots, locale/weather strips, pills on images or fake photo credits. Real-sounding names and organic numbers. Re-read every visible string.
- Images: generation tool first; then `https://picsum.photos/seed/<descriptive-seed>/<w>/<h>` or assets the user provides; else labelled placeholder slots and tell the user. Logo walls use real SVG logos (Simple Icons) and nothing under them. Every `<img>` has `width`, `height`, `alt`; below-fold `loading="lazy"`, hero `fetchpriority="high"`.
- Motion: every animation justified in one sentence; `transform` / `opacity` only; never `transition: all`; no `scroll` event listeners (IntersectionObserver, CSS scroll-driven animation, GSAP ScrollTrigger, Motion `useScroll`); everything wrapped for `prefers-reduced-motion`; at most one marquee. Sticky-stack and horizontal-pan follow the canonical skeletons in taste §5.A / 5.B.
- Robustness: `min-height: 100dvh`, never `100vh` / `h-screen`; loading, empty and error states for anything dynamic; visible `:focus-visible` rings; semantic HTML and a skip link; `color-scheme` and `<meta name="theme-color">` set; dark mode tokens tested if the page supports both.

### Phase 4: See it (playwright-cli)

Check visuals, don't assume them. `playwright-cli` is installed globally (`npm install -g @playwright/cli@latest` if not; `npx playwright cli ...` also works in a project that has Playwright). Serve the page over HTTP: playwright-cli **blocks `file://`**. Use the project's dev server, or for a plain HTML file `python3 -m http.server <port> --bind 127.0.0.1 --directory <dir>` in the background on a port you've checked is free (a busy port serves someone else's page; confirm the screenshot shows yours). Stop the server when done. Then:

```bash
playwright-cli open http://localhost:5173
playwright-cli resize 1440 900
playwright-cli screenshot --filename=shots/desktop-1440.png
playwright-cli resize 1280 720
playwright-cli screenshot --filename=shots/laptop-1280.png
playwright-cli resize 390 844
playwright-cli screenshot --filename=shots/mobile-390.png
playwright-cli screenshot --full-page --filename=shots/mobile-full.png
playwright-cli resize 1440 900
playwright-cli screenshot --full-page --filename=shots/desktop-full.png
playwright-cli console warning
playwright-cli eval "document.documentElement.scrollWidth > innerWidth"
playwright-cli close
```

Then **read every screenshot** and judge it against the reference and the rules: does the hero fit at 1280×720 with the CTA visible? Headline lines? Anything overflowing sideways (the `eval` must print `false`), clipped, overlapping, unreadable, low contrast? Does it still look like the reference? Is the console clean? Fix and re-shoot until it holds. For dark mode, `playwright-cli set-color-scheme dark` and shoot again (`clear-color-scheme` after); `set-reduced-motion reduce` checks the reduced-motion variant the same way. For reviews with the user, `playwright-cli show --annotate` opens a page they can mark up and returns their notes. Put screenshots in a scratch or `shots/` folder the user can open, not in the shipped build. Close every browser you open.

If a built-in browser tool is available in the environment (a preview pane, Chrome tools), it is fine to use it instead; the checks are the same.

### Phase 5: Audit and pre-flight

1. **Web Interface Guidelines audit:** fetch the live rules from `https://raw.githubusercontent.com/vercel-labs/web-interface-guidelines/main/command.md` (fallback: `references/web-interface-guidelines.md`), check the page's files against every rule, and fix what fails. If the user asked for a review rather than a build, output findings in its terse `file:line` format and stop.
2. **Taste pre-flight:** run the checklist in `references/taste.md` §14. Two mechanical checks to actually run: grep the output for `—` and `–` (must be zero in visible text) and count eyebrow labels (≤ ceil(sections / 3)).
3. **Accessibility:** contrast of every CTA, form field, placeholder and focus ring at WCAG AA (4.5:1 body, 3:1 large text); keyboard through the whole page once.

### Phase 6: Hand over

Tell the user: the Design Read and dials used, the reference it was built to, what the page contains, the screenshots (send or link the files), what the audit found and fixed, and anything still open (placeholder images that need real ones, copy to confirm). If the page is for external publication (press, marketing, social), say it should be reviewed by the organisation's communications team before it goes live; if it's going to be deployed on an organisation's infrastructure, suggest checking with its cloud / IT team first.

## When sources disagree

- Hero headline: image-to-code allows 3 lines, taste 2. Use **2** on desktop.
- Headings case: follow the reference DESIGN.md or brand; with none, sentence case for headlines and Title Case for buttons (WIG).
- Dashes: WIG asks for typographic `…` and curly quotes, which are fine; taste bans `—` and `–` outright. Both hold.
- Scope: taste is for landing pages, portfolios, redesigns and editorial pages, not dashboards or dense product UI. For those, keep phases 0, 4 and 5 and drop the marketing-page rules.
