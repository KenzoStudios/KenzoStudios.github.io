"""Inline-SVG chart helpers for document-analyst reports.

Every function returns a <figure> string. Colours come from report.css classes (s1..s5, grid), so the charts follow the
active palette (navy for analyses). Never pass colours. Values are plain numbers; `fmt` formats labels.

    import charts
    charts.grouped_bars(["FY24","FY25","FY26"], [("Revenue",[391,416,479]),("Net income",[94,112,132])], fmt=lambda v:f"{v:,.0f}")
    charts.line_chart(cats, [("Gross margin",[46.2,46.9,48.8])], fmt=lambda v:f"{v:.1f}%")
    charts.hbars([("iPhone",254.1),("Services",123.3)], fmt=lambda v:f"${v:,.1f}bn")
    charts.waterfall([("FY25",416.2,"total"),("iPhone",44.5,"delta"),("FY26",478.8,"total")], fmt=...)
"""
import math

def _nice(vmax, n=4):
    if vmax <= 0: return 1, 1
    raw = vmax / n
    mag = 10 ** math.floor(math.log10(raw))
    for m in (1, 2, 2.5, 5, 10):
        step = m * mag
        if step * n >= vmax: return step, step * n
    return raw, vmax

def _fig(svg, legend, caption, label):
    leg = "".join(f'<span><i class="sw{i}"></i>{n}</span>' for i, n in legend) if legend else ""
    leg = f'<div class="legend">{leg}</div>' if leg else ""
    cap = f"<figcaption>{caption}</figcaption>" if caption else ""
    return f'<figure><svg class="chart" viewBox="0 0 {svg[0]} {svg[1]}" role="img" aria-label="{label}">{svg[2]}</svg>{leg}{cap}</figure>'

def _grid(w, top, bot, step_px, ticks, vmax, fmt, left=52):
    out = ""
    for i in range(ticks + 1):
        y = bot - i * step_px
        v = vmax * i / ticks
        out += f'<line class="grid" x1="{left}" x2="{w-8}" y1="{y:.1f}" y2="{y:.1f}"/><text x="{left-8}" y="{y+3.5:.1f}" text-anchor="end">{fmt(v)}</text>'
    return out

def grouped_bars(cats, series, fmt=lambda v: f"{v:,.0f}", caption="", label="Bar chart", w=600, h=230, labels=True):
    ymax = max(max(v) for _, v in series)
    step, top_v = _nice(ymax)
    ticks = round(top_v / step)
    top, bot, left = 14, h - 30, 52
    ph = bot - top
    g = _grid(w, top, bot, ph / ticks, ticks, top_v, fmt, left)
    n = len(series); cw = (w - left - 8) / len(cats)
    bw = min(46, cw * 0.7 / n)
    b = ""
    for ci, c in enumerate(cats):
        x0 = left + ci * cw + (cw - bw * n - (n - 1) * 4) / 2
        for si, (_, vals) in enumerate(series):
            v = vals[ci]; bh = max(0, v / top_v * ph); x = x0 + si * (bw + 4)
            b += f'<rect class="s{si*2+1 if n<3 else si+1}" x="{x:.1f}" y="{bot-bh:.1f}" width="{bw:.1f}" height="{bh:.1f}"/>'
            if labels: b += f'<text class="lab" x="{x+bw/2:.1f}" y="{bot-bh-5:.1f}" text-anchor="middle">{fmt(v)}</text>'
        b += f'<text x="{left+ci*cw+cw/2:.1f}" y="{h-10}" text-anchor="middle">{c}</text>'
    legend = [((si * 2 + 1 if n < 3 else si + 1), nm) for si, (nm, _) in enumerate(series)] if n > 1 else None
    return _fig((w, h, g + b), legend, caption, label)

def line_chart(cats, series, fmt=lambda v: f"{v:,.1f}", caption="", label="Line chart", w=600, h=230, ymin=None, ymax=None, classes=None):
    allv = [x for _, v in series for x in v]
    lo = min(allv) if ymin is None else ymin
    hi = max(allv) if ymax is None else ymax
    pad = (hi - lo) * 0.15 or 1
    lo = lo - pad if ymin is None else lo; hi = hi + pad if ymax is None else hi
    ticks = 4; top, bot, left = 14, h - 30, 52
    ph = bot - top
    g = "".join(f'<line class="grid" x1="{left}" x2="{w-8}" y1="{bot-i*ph/ticks:.1f}" y2="{bot-i*ph/ticks:.1f}"/><text x="{left-8}" y="{bot-i*ph/ticks+3.5:.1f}" text-anchor="end">{fmt(lo+(hi-lo)*i/ticks)}</text>' for i in range(ticks + 1))
    cw = (w - left - 8) / len(cats); out = ""
    for si, (_, vals) in enumerate(series):
        cls = (classes or [1, 3, 5, 2, 4])[si]
        pts = [(left + cw * (i + .5), bot - (v - lo) / (hi - lo) * ph) for i, v in enumerate(vals)]
        out += f'<polyline class="s{cls} line" points="{" ".join(f"{x:.1f},{y:.1f}" for x,y in pts)}"/>'
        for (x, y), v in zip(pts, vals):
            out += f'<circle class="s{cls}" cx="{x:.1f}" cy="{y:.1f}" r="3.5"/><text class="lab" x="{x:.1f}" y="{y-9:.1f}" text-anchor="middle">{fmt(v)}</text>'
    for i, c in enumerate(cats): out += f'<text x="{left+cw*(i+.5):.1f}" y="{h-10}" text-anchor="middle">{c}</text>'
    legend = [((classes or [1, 3, 5, 2, 4])[i], nm) for i, (nm, _) in enumerate(series)] if len(series) > 1 else None
    return _fig((w, h, g + out), legend, caption, label)

def hbars(items, fmt=lambda v: f"{v:,.1f}", caption="", label="Bar chart", w=600, rowh=30, cls="s1", classes=None, labw=150):
    vmax = max(v for _, v in items) or 1
    h = rowh * len(items) + 8; out = ""
    for i, (nm, v) in enumerate(items):
        y = 4 + i * rowh; bw = max(1, v / vmax * (w - labw - 70))
        c = classes[i] if classes else cls
        out += f'<text x="{labw-10}" y="{y+rowh*0.62:.1f}" text-anchor="end" class="rl">{nm}</text><rect class="{c}" x="{labw}" y="{y+4}" width="{bw:.1f}" height="{rowh-10}"/><text class="lab" x="{labw+bw+8:.1f}" y="{y+rowh*0.62:.1f}">{fmt(v)}</text>'
    return _fig((w, h, out), None, caption, label)

def waterfall(items, fmt=lambda v: f"{v:,.1f}", caption="", label="Waterfall chart", w=600, h=250, ymin=0):
    run = 0; bars = []
    for nm, v, kind in items:
        if kind == "total": bars.append((nm, ymin, v, "s1", v)); run = v
        else: bars.append((nm, min(run, run + v), max(run, run + v), "s3" if v >= 0 else "s5", v)); run += v
    top_v = max(b[2] for b in bars); lo = ymin
    span = top_v - lo; top_v += span * .1
    top, bot, left = 18, h - 34, 20
    ph = bot - top; cw = (w - left - 8) / len(bars); bw = min(54, cw * .66)
    sy = lambda v: bot - (v - lo) / (top_v - lo) * ph
    out = f'<line class="grid" x1="{left}" x2="{w-8}" y1="{bot}" y2="{bot}"/>'
    for i, (nm, a, b, cls, v) in enumerate(bars):
        x = left + i * cw + (cw - bw) / 2
        out += f'<rect class="{cls}" x="{x:.1f}" y="{sy(b):.1f}" width="{bw:.1f}" height="{max(1.5, sy(a)-sy(b)):.1f}"/>'
        txt = fmt(v) if cls == "s1" else (("+" if v >= 0 else "−") + fmt(abs(v)))
        out += f'<text class="lab" x="{x+bw/2:.1f}" y="{sy(b)-5:.1f}" text-anchor="middle">{txt}</text><text x="{x+bw/2:.1f}" y="{h-14}" text-anchor="middle">{nm}</text>'
    legend = [(1, "Total"), (3, "Increase"), (5, "Decrease")]
    return _fig((w, h, out), legend, caption, label)
