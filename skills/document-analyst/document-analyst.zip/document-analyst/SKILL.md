---
name: "document-analyst"
description: "Read a quarterly report, annual report, 10-K/10-Q, financial statement, earnings release or any corporate document and produce a deep, evidence-backed analysis: an executive overview (red flags, inferences, likely next steps, financial health) followed by a thorough breakdown with charts and tables, rendered as a navy report in the report-generator house style."
---

# Document Analyst

Turns a corporate document into an analyst-grade report. The goal is to extract **as much information as the document
physically contains**, check it against itself, and say what it means. Facts, inferences and speculation are always labelled.

Triggers: the user types `/document-analyst`, or asks to "analyse", "break down", "pick apart" or "red-flag" a quarterly or annual
report, 10-K, 10-Q, 8-K, earnings release, annual accounts, prospectus, credit agreement summary, investor deck, MD&A, audit
report, or any other business or financial document.

## Output style (fixed, do not ask)

- Render with the **report-generator** skill's house style, **navy palette only**: `<html data-palette="navy">`, embed
  `~/.claude/skills/report-generator/assets/report.css` and then `assets/analysis.css` from this skill.
- Do **not** show the report-generator palette picker. The palette is always navy.
- Charts are inline SVG made with `assets/charts.py` (colours come from the palette classes; never pass colours).
- Export HTML and print a PDF with headless Chrome (see report-generator, "PDF output"). Offer both files.
- If matplotlib charts are needed, use `theme.apply("navy")` from report-generator.

## Step 1: intake

1. Get the text. PDF: `pdftotext -layout` or PyMuPDF (`fitz`) page by page, keeping page numbers for citations. HTML/iXBRL: strip
   tags, keep tables as tab-separated rows. Excel/CSV: read every sheet. Images/scans: OCR first and say so.
2. If the document is on a public site (for example an SEC filing) and the user gave a company and period rather than a file,
   fetch the primary source. SEC EDGAR blocks anonymous scripts: use the browser tool to read the filing page, and
   `data.sec.gov/api/xbrl/companyfacts/CIK##########.json` for structured numbers. Never put the user's personal contact details in
   a request header; ask first if a service demands them.
3. Record: entity, document type, period, fiscal year-end, currency, units (thousands/millions), audited or not, basis (GAAP/IFRS),
   comparatives available, and anything that looks missing (pages, notes, segments). State these in the report.
4. If the user's request is narrow ("just the risks"), still do the full pass internally and weight the report to their question.

## Step 2: extraction passes (do all that apply)

Work through the document in separate passes. Keep a running list of **every number, claim and caveat** with its page or section.

| Pass | What to pull out |
|---|---|
| Entity and business | What the company does, segments, products, customers, geography, employees, seasonality |
| Income statement | Revenue, cost of sales, gross profit, opex lines, operating income, interest, tax, net income, EPS, share count, for every period shown |
| Segments and mix | Revenue and profit by segment, product, region, channel; growth and share of total |
| Cash flow | Operating cash flow, capex, free cash flow, working-capital movements, buybacks, dividends, debt issued/repaid, acquisitions, stock-comp |
| Balance sheet | Cash and investments, receivables, inventory, payables, PP&E, goodwill, debt (current and long-term), leases, equity |
| MD&A and narrative | What management says drove results, what they emphasise, what they leave out, tone changes, new or removed language |
| Risk factors | New, changed or reordered risks; which are specific to this company versus boilerplate |
| Notes and accounting | Revenue recognition, estimates, policy changes, restatements, impairments, one-offs, non-GAAP adjustments, off-balance-sheet items |
| Commitments | Debt maturities, leases, purchase obligations, guarantees, contingencies, litigation, tax disputes |
| Capital allocation | Buyback and dividend programmes, authorisations, M&A, capex plans, share count trend |
| Governance and controls | Auditor, opinion type, material weaknesses, related-party items, executive changes, subsequent events |
| Outlook | Guidance, targets, announced launches, backlog, pipeline, stated priorities |

For non-financial documents (a strategy memo, a contract, an operating report), keep the same discipline: entities, numbers,
commitments, risks, what changed, what is missing, what it implies.

## Step 3: calculate

Compute from the document's own numbers (show formulas in an appendix, units in every table). Do not use outside data unless the
user asks, and label it if used.

- **Growth:** YoY and 2-year CAGR for revenue, gross profit, operating income, net income, EPS, operating cash flow, free cash flow.
- **Margins:** gross, operating, net, EBITDA (operating income plus D&A), FCF margin; **incremental margin** = change in operating income / change in revenue.
- **Mix:** each segment's share of revenue and of profit; contribution to growth (a revenue bridge).
- **Cost structure:** each opex line as % of revenue; growth versus revenue growth ("operating leverage").
- **Cash quality:** FCF / net income, operating cash flow / net income, accruals, stock-comp as % of revenue.
- **Working capital:** DSO, DIO, DPO, cash conversion cycle; flag any line growing much faster than sales.
- **Liquidity:** current ratio, quick ratio, cash and securities, net cash or net debt.
- **Leverage and cover:** debt / EBITDA, net debt / EBITDA, interest cover, lease-adjusted leverage, debt maturity ladder.
- **Returns:** ROE, ROA, ROIC (state definition), asset turnover.
- **Capital return:** buybacks + dividends as % of FCF, share-count change, effective yield on shares retired.
- **Tie-outs:** do segments sum to the total? does cash flow reconcile to the balance sheet? do the MD&A percentages match the tables? Report any mismatch.

## Step 4: judge

Produce a **verdict** and a **scorecard**. Rate each dimension on four levels (Strong, Solid, Watch, Concern) with a one-line
reason and the number that drove it: Growth, Profitability, Cash generation, Balance sheet, Liquidity, Capital allocation, Earnings
quality, Concentration and risk, Outlook visibility. Give an overall financial-health statement in plain words.

**Red flags** are things that need a question asked. For each: what it is, the evidence (number and page), why it matters, severity
(High, Medium, Low) and what would confirm or dispel it. Typical flags: revenue concentration, receivables or inventory growing faster
than sales, margin help from one-offs, falling cash conversion, rising stock-comp, aggressive non-GAAP adjustments, accounting-policy
changes, debt maturities against cash, large purchase commitments, new litigation, changed risk language, auditor or controls issues,
guidance withdrawn, segment disclosure reduced. Also list **green flags** so the report is balanced.

**Inferences and next steps**: what the numbers and language suggest the business will do next (capital return, pricing, launches,
capex, M&A, restructuring, financing), what to watch next quarter, and questions to put to management. Every inference gets the
tag *Inference* and a confidence level; anything beyond the document gets *Speculation*.

## Step 5: report structure

**Part A, executive overview (one to two pages, written to be read alone)**
1. Title band: company, document, period, units, date of analysis, source.
2. Verdict panel: one-line financial-health grade and a three-sentence summary.
3. Key figures: four to eight KPI tiles with change versus prior period.
4. What the document says: five to seven bullets covering the period's story.
5. Financial health scorecard (table, with rating dots).
6. Red flags (ranked) and green flags.
7. Inferences and likely next steps, with confidence.
8. Questions to ask management.

**Part B, in-depth analysis** (new page; table of contents first)
1. Business and document map: what the document contains, where each topic sits.
2. Income statement: three-period table, margin trend chart, revenue and operating-income bridges.
3. Segments, products and geography: tables, mix and growth charts, contribution to growth.
4. Profitability and cost structure: opex ratios, operating leverage, incremental margin, one-offs.
5. Cash flow and earnings quality: FCF build, conversion, stock-comp, working-capital cycle.
6. Balance sheet and liquidity: summary table, net cash or debt, ratios, maturity and obligations table.
7. Capital allocation: buybacks, dividends, M&A, share-count effect, payout versus FCF.
8. Risks and disclosures: risk-factor map (risk, what is said, exposure, our read), legal, controls, accounting notes.
9. Outlook and scenarios: what to watch, simple sensitivities (state assumptions).
10. Appendix: full data tables, formulas, tie-outs, methodology, limitations, sources.

Every chart has a one-sentence takeaway above or below it. Every table states units. Every claim cites its page or section
(`p.27`, `Item 7`, `Note 8`). Use `.tag.fact`, `.tag.inf`, `.tag.spec` labels where fact, inference and speculation sit near
each other.

## Rules

- **Evidence first.** Never invent a number. If something is not in the document, say "not disclosed". Mark derived figures as
  calculated and show how.
- **Say what is odd.** Compare what the MD&A claims to what the tables show. Call out language that changed, hedges, and omissions.
- **Balanced.** Include strengths as well as problems. Rank red flags by severity; do not list twenty equal worries.
- **Not advice.** The report is analysis of a document, not investment, legal or tax advice, and gives no buy, sell or hold call or
  price target. Say so in the footer.
- **Be precise with units and periods.** Fiscal years are labelled FY plus the year-end date once; keep one unit per table.
- **Plain English.** Define a ratio the first time it appears. Short sentences. No filler.
- **Check it.** Before delivering, re-add totals, confirm every percentage, check that chart values match the tables, and confirm
  every colour comes from the navy palette.

## Build recipe

```python
import os, sys
sys.path.insert(0, os.path.expanduser("~/.claude/skills/document-analyst/assets"))
import charts                      # grouped_bars, line_chart, hbars, waterfall
RG = os.path.expanduser("~/.claude/skills/report-generator/assets")
CSS = open(RG + "/report.css").read() + open(os.path.expanduser("~/.claude/skills/document-analyst/assets/analysis.css")).read()
html = f'<!DOCTYPE html><html lang="en" data-palette="navy"><head><meta charset="utf-8"><title>{title}</title><style>{CSS}</style></head><body><div class="page">...</div></body></html>'
```

Building blocks (CSS classes): `.title-band` with `.meta`, `.verdict` (`.grade`, `.text`), `.kpis.four` with `.kpi` (`.value`, `.label`,
`.delta`), `table` / `table.tight` with `td.pos` and `td.neg`, `.scorecard` with `.dots` (`●●●●○`), `.flag` (`.mid`, `.low`),
`.good`, `.callout` and `.callout.example`, `.two` and `.three` columns, `.toc`, `.tag`, `.pb` (page break), `.footer`.

Print: `"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --no-pdf-header-footer --print-to-pdf=analysis.pdf analysis.html`

A complete worked example (Apple's FY2026 10-K) is in `samples/`.
