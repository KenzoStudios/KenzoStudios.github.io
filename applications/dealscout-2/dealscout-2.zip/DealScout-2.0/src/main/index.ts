import { app, shell, BrowserWindow, ipcMain, dialog } from 'electron'
import { join } from 'path'
import { writeFile } from 'fs'
import { electronApp, optimizer, is } from '@electron-toolkit/utils'
import Store from 'electron-store'

const store = new Store()

function createWindow(): void {
  const win = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    show: false,
    autoHideMenuBar: true,
    titleBarStyle: 'hiddenInset',
    backgroundColor: '#0d1117',
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false
    }
  })

  win.on('ready-to-show', () => { win.show() })

  win.webContents.setWindowOpenHandler((details) => {
    shell.openExternal(details.url)
    return { action: 'deny' }
  })

  if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
    win.loadURL(process.env['ELECTRON_RENDERER_URL'])
  } else {
    win.loadFile(join(__dirname, '../renderer/index.html'))
  }
}

// ── Export PDF ─────────────────────────────────────────────────────────────────

ipcMain.handle('export-pdf', async (event, companySlug?: string) => {
  const win = BrowserWindow.fromWebContents(event.sender)
  if (!win) return { success: false }

  // Build a clean filename: dealscout2_<slug>_analysis.pdf
  const slug     = companySlug ? companySlug.toLowerCase().replace(/[^a-z0-9]/g, '') : ''
  const baseName = slug ? `dealscout2_${slug}_analysis` : 'DealScout2-LBO-Analysis'

  const { filePath, canceled } = await dialog.showSaveDialog(win, {
    title: 'Export LBO Analysis',
    defaultPath: `${baseName}.pdf`,
    filters: [{ name: 'PDF Document', extensions: ['pdf'] }],
  })

  if (canceled || !filePath) return { success: false }

  const data = await win.webContents.printToPDF({
    printBackground: true,
    pageSize: 'A4',
    landscape: true,
    margins: { marginType: 'custom', top: 0.4, bottom: 0.4, left: 0.4, right: 0.4 },
  })

  return new Promise((resolve) => {
    writeFile(filePath, data, (err) => {
      resolve({ success: !err, filePath: filePath })
    })
  })
})

// ── Parse PDF ─────────────────────────────────────────────────────────────────

ipcMain.handle('parse-pdf', async (_, buffer: ArrayBuffer) => {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const pdfParse = require('pdf-parse')
    const buf = Buffer.from(buffer)
    // Try with no password first; fall back to empty-string password for
    // owner-password-only PDFs (common with SEC filings)
    let data: { text: string }
    try {
      data = await pdfParse(buf)
    } catch (inner: unknown) {
      const innerMsg = inner instanceof Error ? inner.message : ''
      if (innerMsg.toLowerCase().includes('password')) {
        data = await pdfParse(buf, { password: '' })
      } else {
        throw inner
      }
    }
    return { success: true, text: data.text as string }
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Unknown error parsing PDF'
    const isPassword = msg.toLowerCase().includes('password')
    return {
      success: false,
      error: isPassword
        ? 'This PDF is password-protected and cannot be parsed automatically. Try the Paste Text tab — copy the text from your PDF viewer and paste it there.'
        : msg,
    }
  }
})

// ── Deal Library ──────────────────────────────────────────────────────────────

ipcMain.handle('deals:get-all', () => {
  try {
    return store.get('deals', [])
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Failed to read deals'
    console.error('[deals:get-all]', msg)
    return []
  }
})

ipcMain.handle('deals:save', (_, deal: unknown) => {
  try {
    const arr = (store.get('deals', []) as unknown[]).slice()
    arr.unshift(deal)
    if (arr.length > 50) arr.length = 50
    store.set('deals', arr)
    return { success: true }
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Failed to save deal'
    return { success: false, error: msg }
  }
})

ipcMain.handle('deals:delete', (_, id: string) => {
  try {
    const arr = (store.get('deals', []) as Array<{ id: string }>).filter(d => d.id !== id)
    store.set('deals', arr)
    return { success: true }
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Failed to delete deal'
    return { success: false, error: msg }
  }
})

ipcMain.handle('deals:export', async (event, id: string) => {
  try {
    const arr = store.get('deals', []) as Array<{ id: string }>
    const deal = arr.find(d => d.id === id)
    if (!deal) return { success: false, error: 'Deal not found' }

    const win = BrowserWindow.fromWebContents(event.sender)
    if (!win) return { success: false, error: 'Window not found' }

    const { filePath, canceled } = await dialog.showSaveDialog(win, {
      title: 'Export Deal',
      defaultPath: `${(deal as any).name || 'deal'}.dealscout2`,
      filters: [{ name: 'DealScout 2.0 File', extensions: ['dealscout2'] }],
    })

    if (canceled || !filePath) return { success: false }

    return new Promise((resolve) => {
      writeFile(filePath, JSON.stringify(deal, null, 2), (err) => {
        resolve({ success: !err, filePath })
      })
    })
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Failed to export deal'
    return { success: false, error: msg }
  }
})

ipcMain.handle('deals:import', (_, json: string) => {
  try {
    const deal = JSON.parse(json)
    if (!deal || typeof deal !== 'object' || !deal.id || !deal.name || !deal.inputs) {
      return { success: false, error: 'Invalid deal file format' }
    }
    // Assign new ID to avoid collisions
    deal.id = `${Date.now()}-${Math.random().toString(36).slice(2)}`
    deal.savedAt = new Date().toISOString()

    const arr = (store.get('deals', []) as unknown[]).slice()
    arr.unshift(deal)
    if (arr.length > 50) arr.length = 50
    store.set('deals', arr)
    return { success: true, deal }
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Failed to import deal'
    return { success: false, error: msg }
  }
})

// ── App lifecycle ──────────────────────────────────────────────────────────────

app.whenReady().then(() => {
  electronApp.setAppUserModelId('com.pe.dealscout2')

  app.on('browser-window-created', (_, window) => {
    optimizer.watchWindowShortcuts(window)
  })

  createWindow()

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})
