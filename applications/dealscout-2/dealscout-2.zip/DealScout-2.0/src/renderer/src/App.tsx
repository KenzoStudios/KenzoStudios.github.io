import { useState } from 'react'
import StandardLBO from './components/StandardLBO'
import IRRMap from './components/IRRMap'
import FCFTab from './components/FCFTab'
import Scenarios from './components/Scenarios'
import PrintView from './components/PrintView'
import ImportPanel from './components/ImportPanel'
import DealLibrary from './components/DealLibrary'
import OperatingModel from './components/OperatingModel'
import WelcomeScreen, { ManualEntryData } from './components/WelcomeScreen'
import { LBOInputs, DEFAULT_LBO_INPUTS, OperatingModelState, DEFAULT_OP_YEAR } from './engine/lbo'

type Tab = 'lbo' | 'opmodel' | 'irrmap' | 'fcf' | 'scenarios'

declare global {
  interface Window {
    api: {
      exportPDF: (companySlug: string) => Promise<{ success: boolean; filePath?: string }>
      parsePDF: (buffer: ArrayBuffer) => Promise<{ success: boolean; text?: string; error?: string }>
      deals: {
        getAll:  () => Promise<any[]>
        save:    (deal: any) => Promise<{ success: boolean }>
        delete:  (id: string) => Promise<{ success: boolean }>
        export:  (id: string) => Promise<{ success: boolean }>
        import:  (json: string) => Promise<{ success: boolean; deal?: any }>
      }
    }
  }
}

function makeDefaultOpModel(ebitda: number, holdPeriod: number): OperatingModelState {
  const entryRevenue = ebitda / 0.25
  return {
    active: false,
    entryRevenue,
    entryEbitda: ebitda,
    yearData: Array.from({ length: holdPeriod }, () => ({ ...DEFAULT_OP_YEAR, overrides: {} })),
  }
}

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('lbo')
  const [inputs, setInputs] = useState<LBOInputs>(DEFAULT_LBO_INPUTS)
  const [showWelcome,     setShowWelcome]     = useState(true)
  const [welcomeIsReopen, setWelcomeIsReopen] = useState(false)
  const [showImportPanel, setShowImportPanel] = useState(false)
  const [showDealLibrary, setShowDealLibrary] = useState(false)
  const [sourceLabel, setSourceLabel] = useState<string | null>(null)
  const [opModel, setOpModel] = useState<OperatingModelState>(() =>
    makeDefaultOpModel(DEFAULT_LBO_INPUTS.ebitda, DEFAULT_LBO_INPUTS.holdPeriod)
  )

  // ── Company name (slug passed to PDF export) ──────────────────────────────
  const [companyName, setCompanyName] = useState('Not a Real Firm')
  const [editingName, setEditingName]  = useState(false)
  const [draftName, setDraftName]      = useState('')

  function startEditName() { setDraftName(companyName); setEditingName(true) }
  function commitName() {
    const t = draftName.trim()
    if (t) setCompanyName(t)
    setEditingName(false)
  }
  function cancelName() { setEditingName(false) }

  async function handleExport() {
    // Slug: lowercase, letters+digits only → "Not a Real Firm" → "notarealfirm"
    const slug = companyName.toLowerCase().replace(/[^a-z0-9]/g, '')
    await window.api.exportPDF(slug)
  }

  function handleImportApply(fields: {
    ebitda?: number
    da?: number
    capex?: number
    taxRate?: number
    sourceLabel: string
  }) {
    setInputs(prev => {
      const next = { ...prev }
      if (fields.ebitda   !== undefined) next.ebitda       = fields.ebitda
      // Use next.ebitda (already updated above) as the denominator so D&A/Capex
      // percentages work correctly even when EBITDA isn't in the same import batch
      if (fields.da       !== undefined) next.daPercent    = next.ebitda > 0 ? fields.da    / next.ebitda : prev.daPercent
      if (fields.capex    !== undefined) next.capexPercent = next.ebitda > 0 ? fields.capex / next.ebitda : prev.capexPercent
      if (fields.taxRate  !== undefined) next.taxRate      = fields.taxRate
      return next
    })
    if (fields.ebitda !== undefined) {
      setOpModel(prev => ({
        ...prev,
        entryEbitda: fields.ebitda!,
        entryRevenue: fields.ebitda! / 0.25,
      }))
    }
    setSourceLabel(fields.sourceLabel)
    setShowImportPanel(false)
  }

  function openWelcome() {
    setWelcomeIsReopen(true)
    setShowWelcome(true)
  }

  function closeWelcome() {
    setShowWelcome(false)
    setWelcomeIsReopen(false)
  }

  function handleWelcomePDF() {
    closeWelcome()
    setShowImportPanel(true)
  }

  function handleWelcomeManual({ companyName: name, inputs }: ManualEntryData) {
    if (name) setCompanyName(name)
    setInputs(inputs)
    setOpModel(makeDefaultOpModel(inputs.ebitda, inputs.holdPeriod))
    setSourceLabel(null)
    closeWelcome()
  }

  function handleWelcomePreset(presetInputs: LBOInputs) {
    setInputs(presetInputs)
    setOpModel(makeDefaultOpModel(presetInputs.ebitda, presetInputs.holdPeriod))
    closeWelcome()
  }

  function handleWelcomeDeal(dealInputs: LBOInputs, name: string) {
    const { ebitdaOverrides: _stripped, ...cleanInputs } = dealInputs as any
    if (name) setCompanyName(name)
    setInputs(cleanInputs)
    setOpModel(makeDefaultOpModel(cleanInputs.ebitda, cleanInputs.holdPeriod))
    setSourceLabel(null)
    closeWelcome()
  }

  function handleLoadDeal(dealInputs: LBOInputs, name: string) {
    // Strip any saved ebitdaOverrides — the Operating Model toggle starts OFF on load
    const { ebitdaOverrides: _stripped, ...cleanInputs } = dealInputs
    if (name) setCompanyName(name)
    setInputs(cleanInputs)
    setOpModel(makeDefaultOpModel(cleanInputs.ebitda, cleanInputs.holdPeriod))
    setSourceLabel(null)
    setShowDealLibrary(false)
    setActiveTab('lbo')
  }

  return (
    <>
      <div className="app no-print">
        <div className="titlebar">
          <div className="titlebar-drag" />

          {/* ── Inline-editable company name ── */}
          <div className="company-name-editor" style={{ WebkitAppRegion: 'no-drag' } as React.CSSProperties}>
            {editingName ? (
              <input
                className="company-name-input"
                value={draftName}
                autoFocus
                onChange={e => setDraftName(e.target.value)}
                onBlur={commitName}
                onKeyDown={e => {
                  if (e.key === 'Enter')  commitName()
                  if (e.key === 'Escape') cancelName()
                }}
              />
            ) : (
              <button
                className="company-name-display"
                onClick={startEditName}
                title="Click to rename"
              >
                {companyName}
              </button>
            )}
          </div>

          <div className="titlebar-divider" />

          <div className="tabs">
            <button className={`tab ${activeTab === 'lbo'       ? 'tab-active' : ''}`} onClick={() => setActiveTab('lbo')}>Standard LBO</button>
            <button className={`tab ${activeTab === 'opmodel'   ? 'tab-active' : ''}`} onClick={() => setActiveTab('opmodel')}>Operating Model</button>
            <button className={`tab ${activeTab === 'irrmap'    ? 'tab-active' : ''}`} onClick={() => setActiveTab('irrmap')}>IRR Map</button>
            <button className={`tab ${activeTab === 'fcf'       ? 'tab-active' : ''}`} onClick={() => setActiveTab('fcf')}>FCF Analysis</button>
            <button className={`tab ${activeTab === 'scenarios' ? 'tab-active' : ''}`} onClick={() => setActiveTab('scenarios')}>Scenarios</button>
          </div>
          <div className="titlebar-right" style={{ display: 'flex', alignItems: 'center', gap: 8, WebkitAppRegion: 'no-drag' } as React.CSSProperties}>
            <button className="export-btn" onClick={() => setShowImportPanel(true)}>Import</button>
            <button className="export-btn" onClick={() => setShowDealLibrary(v => !v)}>Library</button>
            <button className="export-btn export-btn-primary" onClick={handleExport} title="Export to PDF">Export PDF</button>
            <button className="app-name" onClick={openWelcome} title="Back to start">DealScout 2.0</button>
          </div>
        </div>

        <div className="content">
          {activeTab === 'lbo'       && <StandardLBO    inputs={inputs} setInputs={setInputs} sourceLabel={sourceLabel} />}
          {activeTab === 'opmodel'   && <OperatingModel inputs={inputs} setInputs={setInputs} opModel={opModel} setOpModel={setOpModel} />}
          {activeTab === 'irrmap'    && <IRRMap         inputs={inputs} setInputs={setInputs} opModel={opModel} />}
          {activeTab === 'fcf'       && <FCFTab         inputs={inputs} setInputs={setInputs} />}
          {activeTab === 'scenarios' && <Scenarios      inputs={inputs} setInputs={setInputs} />}
        </div>

        <div className="byline">© 2026 Oscar McKenna Brown. All rights reserved.</div>
      </div>

      {/* Import Panel modal */}
      {showImportPanel && (
        <ImportPanel
          onApply={handleImportApply}
          onClose={() => setShowImportPanel(false)}
        />
      )}

      {/* Deal Library slide-over */}
      {showDealLibrary && (
        <DealLibrary
          inputs={inputs}
          companyName={companyName}
          onLoadDeal={handleLoadDeal}
          onClose={() => setShowDealLibrary(false)}
        />
      )}

      {/* Rendered only when printing */}
      <PrintView inputs={inputs} companyName={companyName} />

      {/* Welcome / onboarding screen */}
      {showWelcome && (
        <WelcomeScreen
          onUploadPDF={handleWelcomePDF}
          onManualEntry={handleWelcomeManual}
          onPreset={handleWelcomePreset}
          onLoadDeal={handleWelcomeDeal}
          onSkip={closeWelcome}
          allowOutsideDismiss={welcomeIsReopen}
        />
      )}
    </>
  )
}
