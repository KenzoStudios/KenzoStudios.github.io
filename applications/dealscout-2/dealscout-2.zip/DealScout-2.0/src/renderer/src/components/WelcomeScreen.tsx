import { useState } from 'react'
import { LBOInputs, DEFAULT_LBO_INPUTS, runLBO } from '../engine/lbo'

// ─── Sector presets ────────────────────────────────────────────────────────────
export interface Preset {
  id:          string
  label:       string
  description: string
  tags:        string[]
  inputs:      LBOInputs
}

export const PRESETS: Preset[] = [
  {
    id: 'saas',
    label: 'SaaS / Tech',
    description: 'High-growth software with premium entry multiples, minimal capex and significant intangible D&A.',
    tags: ['High Growth', 'Low Capex', 'Premium Multiple'],
    inputs: { ebitda: 50, entryMultiple: 18, exitMultiple: 16, growthRate: 0.20, holdPeriod: 5, debtEbitda: 4.0, interestRate: 0.085, annualPaydown: 0.05, fees: 0.02, daPercent: 0.15, capexPercent: 0.05, taxRate: 0.25 },
  },
  {
    id: 'healthcare',
    label: 'Healthcare Services',
    description: 'Defensive recurring revenue with regulatory moats and resilient margins through the cycle.',
    tags: ['Defensive', 'Recurring Rev', 'Mid-market'],
    inputs: { ebitda: 30, entryMultiple: 11, exitMultiple: 11, growthRate: 0.10, holdPeriod: 5, debtEbitda: 5.0, interestRate: 0.09, annualPaydown: 0.05, fees: 0.02, daPercent: 0.10, capexPercent: 0.08, taxRate: 0.27 },
  },
  {
    id: 'industrials',
    label: 'Industrials',
    description: 'Asset-intensive manufacturers. Value creation through operational improvement and bolt-on M&A.',
    tags: ['Asset-Heavy', 'Cyclical', 'Op Improvement'],
    inputs: { ebitda: 40, entryMultiple: 8, exitMultiple: 8, growthRate: 0.05, holdPeriod: 5, debtEbitda: 4.5, interestRate: 0.085, annualPaydown: 0.05, fees: 0.02, daPercent: 0.12, capexPercent: 0.18, taxRate: 0.25 },
  },
  {
    id: 'consumer',
    label: 'Consumer / Retail',
    description: 'Brand-driven businesses with strong FCF conversion. Some multiple risk on exit.',
    tags: ['Brand Value', 'FCF Driven', 'Multiple Risk'],
    inputs: { ebitda: 35, entryMultiple: 10, exitMultiple: 9, growthRate: 0.07, holdPeriod: 5, debtEbitda: 4.5, interestRate: 0.085, annualPaydown: 0.05, fees: 0.02, daPercent: 0.08, capexPercent: 0.12, taxRate: 0.26 },
  },
  {
    id: 'b2b-services',
    label: 'B2B Services',
    description: 'Sticky contracted revenue, low capex intensity. Returns driven by margin expansion and re-rating.',
    tags: ['Low Capex', 'Sticky Rev', 'Margin Play'],
    inputs: { ebitda: 25, entryMultiple: 12, exitMultiple: 12, growthRate: 0.12, holdPeriod: 5, debtEbitda: 5.0, interestRate: 0.09, annualPaydown: 0.05, fees: 0.02, daPercent: 0.08, capexPercent: 0.06, taxRate: 0.25 },
  },
  {
    id: 'infrastructure',
    label: 'Infrastructure',
    description: 'Long-duration contracted cash flows with higher leverage capacity. Slower growth, stable returns.',
    tags: ['High Leverage', 'Stable CF', 'Long Hold'],
    inputs: { ebitda: 60, entryMultiple: 14, exitMultiple: 13, growthRate: 0.04, holdPeriod: 7, debtEbitda: 6.5, interestRate: 0.07, annualPaydown: 0.03, fees: 0.015, daPercent: 0.20, capexPercent: 0.25, taxRate: 0.22 },
  },
]

// ─── Manual entry form state ───────────────────────────────────────────────────
interface ManualForm {
  companyName:   string
  ebitda:        string
  entryMultiple: string
  exitMultiple:  string
  growthRate:    string   // stored as %, e.g. "5"
  holdPeriod:    string
  debtEbitda:    string
  interestRate:  string   // stored as %, e.g. "8"
  taxRate:       string   // stored as %, e.g. "25"
}

const D = DEFAULT_LBO_INPUTS
const DEFAULT_FORM: ManualForm = {
  companyName:   '',
  ebitda:        String(D.ebitda),
  entryMultiple: String(D.entryMultiple),
  exitMultiple:  String(D.exitMultiple),
  growthRate:    String(D.growthRate * 100),
  holdPeriod:    String(D.holdPeriod),
  debtEbitda:    String(D.debtEbitda),
  interestRate:  String(D.interestRate * 100),
  taxRate:       String(D.taxRate * 100),
}

export interface ManualEntryData {
  companyName: string
  inputs:      LBOInputs
}

// ─── Types ─────────────────────────────────────────────────────────────────────
type Step      = 'main' | 'manual' | 'presets' | 'library'
type Direction = 'forward' | 'back'

interface Props {
  onUploadPDF:          () => void
  onManualEntry:        (data: ManualEntryData) => void
  onPreset:             (inputs: LBOInputs) => void
  onLoadDeal:           (inputs: LBOInputs, name: string) => void
  onSkip:               () => void
  allowOutsideDismiss?: boolean
}

const DISMISS_MS = 300

// ─── Component ─────────────────────────────────────────────────────────────────
export default function WelcomeScreen({
  onUploadPDF, onManualEntry, onPreset, onLoadDeal, onSkip, allowOutsideDismiss
}: Props) {
  const [step,         setStep]         = useState<Step>('main')
  const [direction,    setDirection]    = useState<Direction>('forward')
  const [leaving,      setLeaving]      = useState(false)
  const [deals,        setDeals]        = useState<any[]>([])
  const [loadingDeals, setLoadingDeals] = useState(false)
  const [form,         setForm]         = useState<ManualForm>(DEFAULT_FORM)

  // ── Dismiss: animate out then fire callback ──────────────────────────────
  function dismiss(cb: () => void) {
    setLeaving(true)
    setTimeout(cb, DISMISS_MS)
  }

  // ── Step navigation ──────────────────────────────────────────────────────
  function goTo(next: Step, dir: Direction) {
    setDirection(dir)
    setStep(next)
  }

  async function goLibrary() {
    goTo('library', 'forward')
    setLoadingDeals(true)
    try {
      const all = await window.api.deals.getAll()
      setDeals(all)
    } finally {
      setLoadingDeals(false)
    }
  }

  function handleOverlayClick(e: React.MouseEvent<HTMLDivElement>) {
    if (allowOutsideDismiss && e.target === e.currentTarget && !leaving) {
      dismiss(onSkip)
    }
  }

  // ── Manual entry submit ──────────────────────────────────────────────────
  function submitManual(e: React.FormEvent) {
    e.preventDefault()
    const inputs: LBOInputs = {
      ...DEFAULT_LBO_INPUTS,                                   // keep da, capex, fees, paydown defaults
      ebitda:        Math.max(0.1, parseFloat(form.ebitda)        || D.ebitda),
      entryMultiple: Math.max(1,   parseFloat(form.entryMultiple)  || D.entryMultiple),
      exitMultiple:  Math.max(1,   parseFloat(form.exitMultiple)   || D.exitMultiple),
      growthRate:    (parseFloat(form.growthRate)  || D.growthRate  * 100) / 100,
      holdPeriod:    Math.round(Math.max(1, parseFloat(form.holdPeriod) || D.holdPeriod)),
      debtEbitda:    Math.max(0,   parseFloat(form.debtEbitda)    || D.debtEbitda),
      interestRate:  (parseFloat(form.interestRate) || D.interestRate * 100) / 100,
      taxRate:       (parseFloat(form.taxRate)       || D.taxRate       * 100) / 100,
    }
    dismiss(() => onManualEntry({ companyName: form.companyName.trim(), inputs }))
  }

  function field(key: keyof ManualForm) {
    return (val: string) => setForm(f => ({ ...f, [key]: val }))
  }

  return (
    <div
      className={`welcome-overlay${leaving ? ' welcome-leaving' : ''}`}
      onClick={handleOverlayClick}
    >
      <div className="welcome-modal">

        {/* ── Header ─────────────────────────────────────────────────────── */}
        <div className="welcome-header">
          <div className="welcome-wordmark">DealScout 2.0</div>
          <div className="welcome-tagline">Investment Screening &amp; Analysis</div>
        </div>

        {/* ── Animated body ──────────────────────────────────────────────── */}
        <div key={step} className={`welcome-body welcome-step-${direction}`}>

          {/* ── Main ─────────────────────────────────────────────────────── */}
          {step === 'main' && (
            <>
              <div className="welcome-grid">
                <WelcomeOption icon={<IconPDF />}    label="Upload PDF"      desc="Extract financials from a CIM or annual report" onClick={() => dismiss(onUploadPDF)} />
                <WelcomeOption icon={<IconEdit />}   label="Enter Data"      desc="Input key assumptions for a new deal"            onClick={() => goTo('manual', 'forward')} />
                <WelcomeOption icon={<IconGrid />}   label="Industry Preset" desc="Start from typical sector assumptions"           onClick={() => goTo('presets', 'forward')} />
                <WelcomeOption icon={<IconFolder />} label="Load Saved Deal" desc="Resume a deal from your library"                 onClick={goLibrary} />
              </div>
              <button className="welcome-skip" onClick={() => dismiss(onSkip)}>Skip →</button>
            </>
          )}

          {/* ── Manual entry form ─────────────────────────────────────────── */}
          {step === 'manual' && (
            <>
              <div className="welcome-sub-header">
                <button className="welcome-back-btn" onClick={() => goTo('main', 'back')}>← Back</button>
                <span className="welcome-sub-title">New Deal</span>
              </div>

              <form className="welcome-form" onSubmit={submitManual}>

                {/* Company name — full width */}
                <FormField label="Target Company Name">
                  <input
                    type="text"
                    className="welcome-form-input"
                    placeholder="e.g. Acme Corporation"
                    value={form.companyName}
                    onChange={e => field('companyName')(e.target.value)}
                    autoFocus
                  />
                </FormField>

                <div className="welcome-form-divider" />

                {/* Row 1 */}
                <div className="welcome-form-2col">
                  <FormField label="EBITDA" unit="$M">
                    <NumInput value={form.ebitda} onChange={field('ebitda')} min={0.1} step={1} />
                  </FormField>
                  <FormField label="Entry Multiple" unit="x EV/EBITDA">
                    <NumInput value={form.entryMultiple} onChange={field('entryMultiple')} min={1} step={0.5} />
                  </FormField>
                </div>

                {/* Row 2 */}
                <div className="welcome-form-2col">
                  <FormField label="Exit Multiple" unit="x EV/EBITDA">
                    <NumInput value={form.exitMultiple} onChange={field('exitMultiple')} min={1} step={0.5} />
                  </FormField>
                  <FormField label="EBITDA Growth" unit="% per year">
                    <NumInput value={form.growthRate} onChange={field('growthRate')} step={0.5} />
                  </FormField>
                </div>

                {/* Row 3 */}
                <div className="welcome-form-2col">
                  <FormField label="Hold Period" unit="years">
                    <NumInput value={form.holdPeriod} onChange={field('holdPeriod')} min={1} max={15} step={1} />
                  </FormField>
                  <FormField label="Debt / EBITDA" unit="x">
                    <NumInput value={form.debtEbitda} onChange={field('debtEbitda')} min={0} step={0.25} />
                  </FormField>
                </div>

                {/* Row 4 */}
                <div className="welcome-form-2col">
                  <FormField label="Interest Rate" unit="%">
                    <NumInput value={form.interestRate} onChange={field('interestRate')} min={0} step={0.25} />
                  </FormField>
                  <FormField label="Tax Rate" unit="%">
                    <NumInput value={form.taxRate} onChange={field('taxRate')} min={0} max={60} step={1} />
                  </FormField>
                </div>

                <button type="submit" className="welcome-form-submit">
                  Start Screening →
                </button>
              </form>
            </>
          )}

          {/* ── Presets ──────────────────────────────────────────────────── */}
          {step === 'presets' && (
            <>
              <div className="welcome-sub-header">
                <button className="welcome-back-btn" onClick={() => goTo('main', 'back')}>← Back</button>
                <span className="welcome-sub-title">Choose a sector</span>
              </div>
              <div className="welcome-presets-grid">
                {PRESETS.map(p => {
                  const res = runLBO(p.inputs)
                  const irr = res.valid ? (res.irr * 100).toFixed(1) + '%' : '—'
                  const irrClass = res.valid
                    ? res.irr >= 0.20 ? 'irr-green' : res.irr >= 0.15 ? 'irr-amber' : 'irr-red'
                    : ''
                  return (
                    <button key={p.id} className="welcome-preset-card" onClick={() => dismiss(() => onPreset(p.inputs))}>
                      <div className="welcome-preset-name">{p.label}</div>
                      <div className="welcome-preset-desc">{p.description}</div>
                      <div className="welcome-preset-footer">
                        <div className="welcome-preset-tags">
                          {p.tags.map(t => <span key={t} className="welcome-preset-tag">{t}</span>)}
                        </div>
                        <span className={`deal-card-irr-badge ${irrClass}`}>{irr}</span>
                      </div>
                    </button>
                  )
                })}
              </div>
            </>
          )}

          {/* ── Library ──────────────────────────────────────────────────── */}
          {step === 'library' && (
            <>
              <div className="welcome-sub-header">
                <button className="welcome-back-btn" onClick={() => goTo('main', 'back')}>← Back</button>
                <span className="welcome-sub-title">Your saved deals</span>
              </div>
              {loadingDeals ? (
                <div className="welcome-loading">Loading…</div>
              ) : deals.length === 0 ? (
                <div className="welcome-empty">No saved deals yet. Save a deal from the Library tab in the main app first.</div>
              ) : (
                <div className="welcome-deal-list">
                  {deals.map((d: any) => {
                    const res = runLBO(d.inputs ?? d)
                    const irr = res.valid ? (res.irr * 100).toFixed(1) + '%' : '—'
                    const irrClass = res.valid
                      ? res.irr >= 0.20 ? 'irr-green' : res.irr >= 0.15 ? 'irr-amber' : 'irr-red'
                      : ''
                    const saved = d.savedAt
                      ? new Date(d.savedAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
                      : ''
                    return (
                      <button key={d.id} className="welcome-deal-row" onClick={() => dismiss(() => onLoadDeal(d.inputs ?? d, d.name ?? ''))}>
                        <div className="welcome-deal-name">{d.name ?? 'Untitled Deal'}</div>
                        <div className="welcome-deal-right">
                          <span className={`deal-card-irr-badge ${irrClass}`}>{irr}</span>
                          {saved && <span className="welcome-deal-date">{saved}</span>}
                        </div>
                      </button>
                    )
                  })}
                </div>
              )}
            </>
          )}

        </div>{/* end welcome-body */}

        {/* ── Copyright footer ───────────────────────────────────────────── */}
        <div className="welcome-footer">
          <div className="welcome-copyright">© 2026 Oscar McKenna Brown. All rights reserved.</div>
        </div>

      </div>
    </div>
  )
}

// ─── Small helpers ─────────────────────────────────────────────────────────────
function FormField({ label, unit, children }: { label: string; unit?: string; children: React.ReactNode }) {
  return (
    <div className="welcome-form-field">
      <div className="welcome-form-label">
        {label}{unit && <span className="welcome-form-unit"> · {unit}</span>}
      </div>
      {children}
    </div>
  )
}

function NumInput({ value, onChange, min, max, step }: {
  value: string; onChange: (v: string) => void
  min?: number; max?: number; step?: number
}) {
  return (
    <input
      type="number"
      className="welcome-form-input"
      value={value}
      min={min}
      max={max}
      step={step}
      onChange={e => onChange(e.target.value)}
    />
  )
}

// ─── Option card ───────────────────────────────────────────────────────────────
function WelcomeOption({ icon, label, desc, onClick }: {
  icon: React.ReactNode; label: string; desc: string; onClick: () => void
}) {
  return (
    <button className="welcome-option" onClick={onClick}>
      <div className="welcome-option-icon">{icon}</div>
      <div className="welcome-option-text">
        <div className="welcome-option-label">{label}</div>
        <div className="welcome-option-desc">{desc}</div>
      </div>
    </button>
  )
}

// ─── SVG icons ────────────────────────────────────────────────────────────────
function IconPDF() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
      <polyline points="14 2 14 8 20 8"/>
      <line x1="12" y1="18" x2="12" y2="12"/>
      <polyline points="9 15 12 12 15 15"/>
    </svg>
  )
}
function IconEdit() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
    </svg>
  )
}
function IconGrid() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
      <rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>
    </svg>
  )
}
function IconFolder() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
    </svg>
  )
}
