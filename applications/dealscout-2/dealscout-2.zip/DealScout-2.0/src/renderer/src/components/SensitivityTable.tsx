import { useMemo } from 'react'
import { runLBO, LBOInputs } from '../engine/lbo'

interface Props {
  inputs: LBOInputs
  targetIRR: number
}

function fmtPct(n: number) { return (n * 100).toFixed(1) + '%' }

function cellClass(irr: number, targetIRR: number): string {
  if (irr <= -998) return 'sens-invalid'
  if (irr >= targetIRR + 0.05) return 'sens-strong'
  if (irr >= targetIRR)        return 'sens-ok'
  if (irr >= targetIRR - 0.05) return 'sens-warn'
  return 'sens-poor'
}

function snap(v: number, step: number) {
  return Math.round(v / step) * step
}

export default function SensitivityTable({ inputs, targetIRR }: Props) {
  const entryStep = 0.5
  const exitStep  = 0.5
  const baseEntry = snap(inputs.entryMultiple, entryStep)
  const baseExit  = snap(inputs.exitMultiple,  exitStep)

  const entryMults = useMemo(() => {
    const vals: number[] = []
    for (let i = -5; i <= 5; i++) {
      const v = Math.round((baseEntry + i * entryStep) * 100) / 100
      if (v >= 2 && v <= 25) vals.push(v)
    }
    return vals
  }, [baseEntry])

  const exitMults = useMemo(() => {
    const vals: number[] = []
    for (let i = -4; i <= 4; i++) {
      const v = Math.round((baseExit + i * exitStep) * 100) / 100
      if (v >= 2 && v <= 25) vals.push(v)
    }
    return vals
  }, [baseExit])

  const grid = useMemo(() => {
    return entryMults.map(em =>
      exitMults.map(exm => {
        const r = runLBO({ ...inputs, entryMultiple: em, exitMultiple: exm })
        return r.valid ? r.irr : -999
      })
    )
  }, [inputs, entryMults, exitMults])

  const curEntry = inputs.entryMultiple
  const curExit  = inputs.exitMultiple

  return (
    <div className="table-scroll">
      <table className="sens-table">
        <thead>
          <tr>
            <th className="sens-corner">Entry \ Exit</th>
            {exitMults.map(ex => (
              <th
                key={ex}
                className={Math.abs(ex - curExit) < 0.01 ? 'sens-highlight-col' : ''}
              >
                {ex.toFixed(1)}x
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {entryMults.map((em, ri) => (
            <tr key={em}>
              <td className={`sens-row-header ${Math.abs(em - curEntry) < 0.01 ? 'sens-highlight-row' : ''}`}>
                {em.toFixed(1)}x
              </td>
              {exitMults.map((ex, ci) => {
                const irr = grid[ri][ci]
                const isCur = Math.abs(em - curEntry) < 0.01 && Math.abs(ex - curExit) < 0.01
                return (
                  <td
                    key={ex}
                    className={`${cellClass(irr, targetIRR)} ${isCur ? 'sens-current' : ''}`}
                  >
                    {irr > -998 ? fmtPct(irr) : '—'}
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
