import { useEffect, useRef, useState } from 'react'
import { HeatmapCell } from '../engine/solver'

interface HeatmapProps {
  grid: HeatmapCell[][]
  entryMultiples: number[]
  growthRates: number[]
  targetIRR: number
  currentEntryMultiple: number
  currentGrowthRate: number
  // Optional custom axis formatters and labels (for Operating Mode)
  xFormatter?: (v: number) => string
  yFormatter?: (v: number) => string
  xAxisLabel?: string
  yAxisLabel?: string
  tooltipXLabel?: string
  tooltipYLabel?: string
}

interface TooltipState {
  x: number; y: number
  irr: number
  entryMultiple: number
  growthRate: number
}

/**
 * Muted diverging scale with sqrt easing so mid-range values are visibly coloured.
 * Neutral midpoint at target IRR → institutional green/red at extremes.
 * No neon, no near-black.
 */
function irrToColor(irr: number, targetIRR: number): string {
  if (!isFinite(irr) || irr < -0.5) return 'invalid'
  const spread = 0.22
  // sqrt easing: colour appears quickly near target, saturates smoothly at extremes
  if (irr >= targetIRR) {
    const t = Math.sqrt(Math.min(1, (irr - targetIRR) / spread))
    // neutral slate (24,36,48) → muted institutional green (40,148,86)
    return `rgb(${Math.round(24 + 16 * t)},${Math.round(36 + 112 * t)},${Math.round(48 + 38 * t)})`
  } else {
    const t = Math.sqrt(Math.min(1, (targetIRR - irr) / spread))
    // neutral slate (24,36,48) → muted institutional red (172,56,48)
    return `rgb(${Math.round(24 + 148 * t)},${Math.round(36 + 20 * t)},${Math.round(48 * (1 - t))})`
  }
}

function findContourEdges(grid: HeatmapCell[][], targetIRR: number) {
  const edges: { j: number; i: number }[] = []
  for (let j = 0; j < grid.length; j++) {
    for (let i = 0; i < grid[j].length - 1; i++) {
      if ((grid[j][i].irr - targetIRR) * (grid[j][i + 1].irr - targetIRR) <= 0) edges.push({ j, i })
    }
  }
  return edges
}

// PAD_T enlarged to accommodate the legend bar drawn above the cells
const PAD_L = 52, PAD_R = 22, PAD_T = 52, PAD_B = 44

export default function Heatmap({
  grid, entryMultiples, growthRates, targetIRR, currentEntryMultiple, currentGrowthRate,
  xFormatter, yFormatter, xAxisLabel, yAxisLabel, tooltipXLabel, tooltipYLabel,
}: HeatmapProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef    = useRef<HTMLCanvasElement>(null)
  const [tooltip, setTooltip] = useState<TooltipState | null>(null)

  useEffect(() => {
    const container = containerRef.current
    const canvas    = canvasRef.current
    if (!container || !canvas || grid.length === 0) return

    const draw = () => {
      const dpr  = window.devicePixelRatio || 1
      const logW = container.offsetWidth
      const logH = container.offsetHeight

      if (logW < 10 || logH < 10) return

      canvas.width  = logW * dpr
      canvas.height = logH * dpr
      canvas.style.width  = `${logW}px`
      canvas.style.height = `${logH}px`

      const ctx = canvas.getContext('2d')!
      ctx.scale(dpr, dpr)
      ctx.clearRect(0, 0, logW, logH)

      const plotW = logW - PAD_L - PAD_R
      const plotH = logH - PAD_T  - PAD_B

      const cols  = entryMultiples.length
      const rows  = growthRates.length
      const cellW = plotW / cols
      const cellH = plotH / rows

      // ── Legend bar — above the cells ───────────────────────────────────────
      const barH  = 9
      const barY  = 14
      const barX  = PAD_L
      const barW  = plotW

      const grad = ctx.createLinearGradient(barX, 0, barX + barW, 0)
      grad.addColorStop(0,    'rgb(172,56,48)')    // max red
      grad.addColorStop(0.38, 'rgb(72,28,32)')     // mid-red tint
      grad.addColorStop(0.5,  'rgb(24,36,48)')     // neutral (target)
      grad.addColorStop(0.62, 'rgb(26,88,56)')     // mid-green tint
      grad.addColorStop(1,    'rgb(40,148,86)')    // max green
      ctx.fillStyle = grad
      ctx.beginPath()
      ctx.roundRect(barX, barY, barW, barH, 3)
      ctx.fill()

      // Target marker on legend bar
      const targetX = barX + barW / 2
      ctx.strokeStyle = 'rgba(255,255,255,0.65)'
      ctx.lineWidth   = 1.5
      ctx.setLineDash([2, 3])
      ctx.beginPath()
      ctx.moveTo(targetX, barY - 1)
      ctx.lineTo(targetX, barY + barH + 1)
      ctx.stroke()
      ctx.setLineDash([])

      // Legend labels
      ctx.font         = '10px -apple-system, BlinkMacSystemFont, sans-serif'
      ctx.textBaseline = 'top'
      const labY = barY + barH + 5
      ctx.fillStyle = 'rgba(172,80,70,0.85)'; ctx.textAlign = 'left'
      ctx.fillText('Below target', barX, labY)
      ctx.fillStyle = 'rgba(255,255,255,0.38)'; ctx.textAlign = 'center'
      ctx.fillText(`${(targetIRR * 100).toFixed(0)}% IRR target`, targetX, labY)
      ctx.fillStyle = 'rgba(52,165,96,0.85)'; ctx.textAlign = 'right'
      ctx.fillText('Above target', barX + barW, labY)

      // ── Cell background ────────────────────────────────────────────────────
      ctx.fillStyle = '#0d1117'
      ctx.fillRect(PAD_L, PAD_T, plotW, plotH)

      // ── Cells ──────────────────────────────────────────────────────────────
      for (let j = 0; j < rows; j++) {
        for (let i = 0; i < cols; i++) {
          const cell  = grid[j][i]
          const x     = PAD_L + i * cellW
          const y     = PAD_T + (rows - 1 - j) * cellH
          const cw    = Math.ceil(cellW) + 1
          const ch    = Math.ceil(cellH) + 1
          const cx    = Math.floor(x)
          const cy    = Math.floor(y)
          const color = irrToColor(cell.irr, targetIRR)

          ctx.fillStyle = color === 'invalid' ? '#0a0e15' : color
          ctx.fillRect(cx, cy, cw, ch)
        }
      }

      // ── Subtle cell grid ───────────────────────────────────────────────────
      ctx.strokeStyle = 'rgba(0,0,0,0.20)'
      ctx.lineWidth   = 0.5
      for (let i = 1; i < cols; i++) {
        const x = PAD_L + i * cellW
        ctx.beginPath(); ctx.moveTo(x, PAD_T); ctx.lineTo(x, PAD_T + plotH); ctx.stroke()
      }
      for (let j = 1; j < rows; j++) {
        const y = PAD_T + j * cellH
        ctx.beginPath(); ctx.moveTo(PAD_L, y); ctx.lineTo(PAD_L + plotW, y); ctx.stroke()
      }

      // ── Target IRR contour ─────────────────────────────────────────────────
      const edges = findContourEdges(grid, targetIRR)
      // Glow pass
      ctx.lineWidth   = 7
      ctx.strokeStyle = 'rgba(255,255,255,0.07)'
      ctx.setLineDash([])
      for (const { j, i } of edges) {
        const x = PAD_L + (i + 0.5) * cellW
        const y = PAD_T + (rows - 1 - j) * cellH
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + cellH); ctx.stroke()
      }
      // Crisp line
      ctx.lineWidth   = 1.5
      ctx.strokeStyle = 'rgba(255,255,255,0.72)'
      ctx.setLineDash([4, 5])
      for (const { j, i } of edges) {
        const x = PAD_L + (i + 0.5) * cellW
        const y = PAD_T + (rows - 1 - j) * cellH
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + cellH); ctx.stroke()
      }
      ctx.setLineDash([])

      // ── X axis ─────────────────────────────────────────────────────────────
      ctx.fillStyle    = '#5a6a80'
      ctx.font         = '11px -apple-system, BlinkMacSystemFont, sans-serif'
      ctx.textAlign    = 'center'
      ctx.textBaseline = 'top'
      const fmtX = xFormatter ?? ((v: number) => v.toFixed(1) + 'x')
      const fmtY = yFormatter ?? ((v: number) => (v * 100).toFixed(0) + '%')
      const xLabel = xAxisLabel ?? 'Entry EV / EBITDA Multiple'
      const yLabel = yAxisLabel ?? 'EBITDA Growth Rate'

      const xStep = Math.max(1, Math.ceil(cols / 9))
      for (let i = 0; i < cols; i += xStep) {
        ctx.fillText(fmtX(entryMultiples[i]), PAD_L + (i + 0.5) * cellW, logH - PAD_B + 8)
      }
      ctx.fillStyle = '#2d3d50'
      ctx.fillText(xLabel, PAD_L + plotW / 2, logH - 14)

      // ── Y axis ─────────────────────────────────────────────────────────────
      ctx.textAlign    = 'right'
      ctx.textBaseline = 'middle'
      ctx.fillStyle    = '#5a6a80'
      const yStep = Math.max(1, Math.ceil(rows / 8))
      for (let j = 0; j < rows; j += yStep) {
        ctx.fillText(
          fmtY(growthRates[j]),
          PAD_L - 7,
          PAD_T + (rows - 1 - j) * cellH + cellH / 2
        )
      }
      ctx.save()
      ctx.translate(13, PAD_T + plotH / 2)
      ctx.rotate(-Math.PI / 2)
      ctx.textAlign    = 'center'
      ctx.fillStyle    = '#2d3d50'
      ctx.fillText(yLabel, 0, 0)
      ctx.restore()

      // ── Current assumption marker ──────────────────────────────────────────
      const xRange = entryMultiples[entryMultiples.length - 1] - entryMultiples[0]
      const yRange = growthRates[growthRates.length - 1]       - growthRates[0]
      const dotX   = PAD_L + ((currentEntryMultiple - entryMultiples[0]) / xRange) * plotW
      const dotY   = PAD_T + (1 - (currentGrowthRate - growthRates[0]) / yRange)   * plotH

      if (dotX >= PAD_L && dotX <= logW - PAD_R && dotY >= PAD_T && dotY <= logH - PAD_B) {
        ctx.beginPath(); ctx.arc(dotX, dotY, 10, 0, Math.PI * 2)
        ctx.fillStyle = 'rgba(0,0,0,0.50)'; ctx.fill()
        ctx.beginPath(); ctx.arc(dotX, dotY, 8, 0, Math.PI * 2)
        ctx.strokeStyle = 'rgba(255,255,255,0.90)'; ctx.lineWidth = 2; ctx.stroke()
        ctx.beginPath(); ctx.arc(dotX, dotY, 3.5, 0, Math.PI * 2)
        ctx.fillStyle = '#fff'; ctx.fill()

        ctx.font         = '500 11px -apple-system, BlinkMacSystemFont, sans-serif'
        ctx.textAlign    = 'left'
        ctx.textBaseline = 'middle'
        const label = 'Current'
        const lw    = ctx.measureText(label).width
        ctx.fillStyle = 'rgba(0,0,0,0.55)'
        ctx.fillRect(dotX + 13, dotY - 8, lw + 6, 16)
        ctx.fillStyle = 'rgba(255,255,255,0.92)'
        ctx.fillText(label, dotX + 16, dotY)
      }
    }

    draw()
    const ro = new ResizeObserver(draw)
    ro.observe(container)
    return () => ro.disconnect()
  }, [grid, entryMultiples, growthRates, targetIRR, currentEntryMultiple, currentGrowthRate, xFormatter, yFormatter, xAxisLabel, yAxisLabel])

  function handleMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    const container = containerRef.current
    if (!container || grid.length === 0) return

    const rect     = container.getBoundingClientRect()
    const mx       = e.clientX - rect.left
    const my       = e.clientY - rect.top
    const logW     = container.offsetWidth
    const logH     = container.offsetHeight
    const plotW    = logW - PAD_L - PAD_R
    const plotH    = logH - PAD_T - PAD_B
    const cols     = entryMultiples.length
    const rows     = growthRates.length
    const cellW    = plotW / cols
    const cellH    = plotH / rows

    const i        = Math.floor((mx - PAD_L) / cellW)
    const jFromTop = Math.floor((my - PAD_T) / cellH)
    const j        = (rows - 1) - jFromTop

    if (i >= 0 && i < cols && j >= 0 && j < rows && grid[j]?.[i]?.valid) {
      setTooltip({
        x: mx, y: my,
        irr:           grid[j][i].irr,
        entryMultiple: entryMultiples[i],
        growthRate:    growthRates[j],
      })
    } else {
      setTooltip(null)
    }
  }

  return (
    <div
      ref={containerRef}
      className="heatmap-container"
      style={{ padding: 0, position: 'relative' }}
      onMouseMove={handleMouseMove}
      onMouseLeave={() => setTooltip(null)}
    >
      <canvas ref={canvasRef} style={{ display: 'block', borderRadius: 8 }} />
      {tooltip && (
        <div style={{
          position:      'absolute',
          left:          tooltip.x + 14,
          top:           tooltip.y - 44,
          background:    'var(--bg-raised)',
          border:        '1px solid var(--border-mid)',
          borderRadius:  'var(--radius)',
          padding:       '6px 10px',
          pointerEvents: 'none',
          whiteSpace:    'nowrap',
          zIndex:        10,
          display:       'flex',
          flexDirection: 'column',
          gap:           3,
        }}>
          <div style={{
            fontSize:           12,
            fontFamily:         'var(--font-mono)',
            fontVariantNumeric: 'tabular-nums',
            fontWeight:         600,
            color:              tooltip.irr >= targetIRR ? '#3daa6a' : '#c94545',
          }}>
            {(tooltip.irr * 100).toFixed(1)}% IRR
          </div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
            {tooltipXLabel ?? 'entry'}: {(xFormatter ?? ((v: number) => v.toFixed(1) + 'x'))(tooltip.entryMultiple)}
            {' · '}
            {tooltipYLabel ?? 'growth'}: {(yFormatter ?? ((v: number) => (v * 100).toFixed(0) + '%'))(tooltip.growthRate)}
          </div>
        </div>
      )}
    </div>
  )
}
