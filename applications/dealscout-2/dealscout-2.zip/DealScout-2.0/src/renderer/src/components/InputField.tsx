import { useState, ReactNode } from 'react'
import InfoBadge from './InfoBadge'

interface InputFieldProps {
  label: ReactNode
  value: number
  onChange: (val: number) => void
  suffix?: string
  min?: number
  max?: number
  step?: number
  decimals?: number
  asPercent?: boolean  // store as decimal (0.05), display as % (5.0)
  tip?: string
}

export default function InputField({
  label,
  value,
  onChange,
  suffix,
  min,
  max,
  step = 0.1,
  decimals = 1,
  asPercent = false,
  tip,
}: InputFieldProps) {
  // null = not focused (show formatted prop value)
  // string = focused (free-form editing)
  const [draft, setDraft] = useState<string | null>(null)

  const displayNum = asPercent ? value * 100 : value
  const formatted = displayNum.toFixed(decimals)

  function commit(raw: string) {
    const parsed = parseFloat(raw)
    if (!isNaN(parsed)) {
      const stored = asPercent ? parsed / 100 : parsed
      const lo = min ?? -Infinity
      const hi = max ?? Infinity
      onChange(Math.min(hi, Math.max(lo, stored)))
    }
    // If empty / NaN — leave parent value unchanged, display will revert to formatted
  }

  function handleFocus(e: React.FocusEvent<HTMLInputElement>) {
    setDraft(formatted)
    // Select all so the user can just type the new value
    requestAnimationFrame(() => e.target.select())
  }

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setDraft(e.target.value)
  }

  function handleBlur() {
    if (draft !== null) commit(draft)
    setDraft(null)
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter') {
      e.currentTarget.blur()
      return
    }

    // Arrow key stepping while editing
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      e.preventDefault()
      const base = parseFloat(draft ?? formatted)
      if (isNaN(base)) return
      const displayStep = asPercent ? step * 100 : step
      const next = e.key === 'ArrowUp' ? base + displayStep : base - displayStep
      const stored = asPercent ? next / 100 : next
      const clamped = Math.min(max ?? Infinity, Math.max(min ?? -Infinity, stored))
      const newDisplay = asPercent ? clamped * 100 : clamped
      const newDraft = newDisplay.toFixed(decimals)
      setDraft(newDraft)
      onChange(clamped)
    }
  }

  const shownValue = draft !== null ? draft : formatted

  return (
    <div className="input-field">
      <label className="input-label">
        {label}
        {tip && <InfoBadge tip={tip} />}
      </label>
      <div className={`input-wrapper ${draft !== null ? 'input-focused' : ''}`}>
        <input
          type="text"
          inputMode="decimal"
          value={shownValue}
          onChange={handleChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          onKeyDown={handleKeyDown}
          className="input-control"
        />
        {suffix && <span className="input-suffix">{suffix}</span>}
      </div>
    </div>
  )
}
