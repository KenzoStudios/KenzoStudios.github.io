import { useMemo } from 'react'
import { runLBO, LBOInputs } from '../engine/lbo'
import InputField from './InputField'
import KPICard from './KPICard'
import FCFChart from './FCFChart'

interface Props {
  inputs: LBOInputs
  setInputs: React.Dispatch<React.SetStateAction<LBOInputs>>
}

function fmt(n: number, d = 1) { return n.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }) }
function fmtM(n: number)   { return '$' + fmt(n, 1) + 'M' }
function fmtPct(n: number) { return fmt(n * 100, 1) + '%' }
function fmtX(n: number)   { return fmt(n, 2) + 'x' }

function dscrColor(v: number): 'green' | 'yellow' | 'red' {
  if (v >= 2.0) return 'green'
  if (v >= 1.3) return 'yellow'
  return 'red'
}

export default function FCFTab({ inputs, setInputs }: Props) {
  function set<K extends keyof LBOInputs>(key: K) {
    return (val: number) => setInputs(prev => ({ ...prev, [key]: val }))
  }

  const debtEvPct   = inputs.debtEbitda / inputs.entryMultiple
  const setDebtByEV = (pct: number) => setInputs(prev => ({ ...prev, debtEbitda: pct * prev.entryMultiple }))

  const result = useMemo(() => runLBO(inputs), [inputs])

  const fcfYield = result.valid && result.equityAtEntry > 0
    ? result.totalLeveredFCF / result.equityAtEntry
    : 0

  const interestCoverage = result.valid && result.yearlyData.length > 0
    ? result.yearlyData.reduce((s, d) => s + (d.interest > 0 ? d.ebit / d.interest : 0), 0) / result.yearlyData.length
    : 0

  return (
    <div className="tab-layout">
      {/* ── Left: Inputs ────────────────────────────────────────────── */}
      <aside className="input-panel">
        <div className="panel-section">
          <div className="panel-section-title">P&amp;L Assumptions</div>
          <InputField label="D&A (% of EBITDA)"   value={inputs.daPercent}    onChange={set('daPercent')}    suffix="%" asPercent step={1} min={0} max={0.50} decimals={0}
            tip="Depreciation & Amortisation as % of EBITDA. Non-cash charge that reduces taxable income (tax shield) and adds back to free cash flow. Higher D&A improves FCF conversion." />
          <InputField label="Capex (% of EBITDA)"  value={inputs.capexPercent} onChange={set('capexPercent')} suffix="%" asPercent step={1} min={0} max={0.50} decimals={0}
            tip="Capital expenditure as % of EBITDA. Cash outflow that directly reduces levered FCF available for debt repayment. The gap between D&A and Capex is the maintenance capex burden." />
          <InputField label="Tax Rate"              value={inputs.taxRate}      onChange={set('taxRate')}      suffix="%" asPercent step={1} min={0} max={0.50} decimals={0}
            tip="Effective corporate tax rate. Applied to pre-tax profit (EBITDA − D&A − interest). Interest deductibility reduces the tax burden, which is a key LBO structural benefit." />
        </div>

        <div className="panel-section">
          <div className="panel-section-title">Deal Parameters</div>
          <InputField label="Current EBITDA"    value={inputs.ebitda}        onChange={set('ebitda')}        suffix="$M"  step={10}   decimals={0} min={1}
            tip="Entry EBITDA. Sets the scale for all cash flows — debt quantum, interest cost, and FCF all scale with this number." />
          <InputField label="Entry EV / EBITDA" value={inputs.entryMultiple} onChange={set('entryMultiple')} suffix="x"   step={0.25} min={1} max={30}
            tip="Entry purchase price multiple. Affects equity invested at entry, and thus FCF yield and DSCR calculations." />
          <InputField label="EBITDA Growth"     value={inputs.growthRate}    onChange={set('growthRate')}    suffix="%"   asPercent step={0.5} min={-0.20} max={0.50}
            tip="Annual compound EBITDA growth. Higher growth means larger EBITDA in later years — more FCF to sweep debt, improving DSCR over time." />
          <InputField label="Hold Period"       value={inputs.holdPeriod}   onChange={set('holdPeriod')}   suffix="yrs" step={1} decimals={0} min={1} max={15}
            tip="Number of years modelled. Determines how many annual FCF bars appear on the chart." />
        </div>

        <div className="panel-section">
          <div className="panel-section-title">Capital Structure</div>
          <InputField label="Debt / EBITDA"   value={inputs.debtEbitda}    onChange={set('debtEbitda')}    suffix="x"       step={0.25} min={0} max={15}
            tip="Initial leverage. Higher debt = more interest cost each year and a larger mandatory repayment burden, compressing FCF and DSCR." />
          <InputField label="Debt / EV"       value={debtEvPct}            onChange={setDebtByEV}          suffix="% of EV" asPercent step={1} min={0} max={0.98}
            tip="Debt as % of enterprise value. Linked to Debt/EBITDA via entry multiple — adjust either to change the capital structure." />
          <InputField label="Interest Rate"   value={inputs.interestRate}  onChange={set('interestRate')}  suffix="%"       asPercent step={0.25} min={0} max={0.30}
            tip="Annual interest cost on the debt. Directly reduces net income and FCF — the most visible drag on cash generation in the early years." />
          <InputField label="Annual Paydown"  value={inputs.annualPaydown} onChange={set('annualPaydown')} suffix="%"       asPercent step={1} min={0} max={1} decimals={0}
            tip="Mandatory annual principal repayment as % of original debt. Free cash above this amount is swept to further reduce the debt balance." />
        </div>
      </aside>

      {/* ── Right: Outputs ──────────────────────────────────────────── */}
      <main className="output-panel">
        {/* KPI row */}
        <div className="kpi-row">
          <KPICard label="Avg DSCR"         value={result.valid ? fmtX(result.avgDSCR) : '—'}    highlight={result.valid ? dscrColor(result.avgDSCR) : 'neutral'} large
            tip="Debt Service Coverage Ratio = EBITDA ÷ (Interest + Principal). Averaged across all years. Above 2.0x is comfortable; below 1.25x is typically considered stressed by lenders." />
          <KPICard label="Min DSCR"         value={result.valid ? fmtX(result.minDSCR) : '—'}    highlight={result.valid ? dscrColor(result.minDSCR) : 'neutral'} large sub={result.valid ? `Year ${result.minDSCRYear}` : undefined}
            tip="The weakest DSCR in any single year — the tightest point of the deal. This is year 1 in most LBOs due to peak interest cost and lowest EBITDA. Most covenants test this." />
          <KPICard label="Cumulative FCF"   value={result.valid ? fmtM(result.totalLeveredFCF) : '—'}
            tip="Total levered free cash flow generated across the hold period (Net Income + D&A − Capex, summed). This is the cash available for all debt repayment." />
          <KPICard label="FCF Yield"        value={result.valid ? fmtPct(fcfYield) : '—'}          sub="on entry equity"
            tip="Cumulative levered FCF as a % of equity invested at entry. A rough cash-on-cash return metric — higher means more of your equity is returned via cash generation, not just exit proceeds." />
          <KPICard label="Total Tax Paid"   value={result.valid ? fmtM(result.totalTaxPaid) : '—'}
            tip="Aggregate tax paid across the hold period. Leverage reduces this via interest deductibility — the tax shield is a meaningful component of LBO return generation." />
          <KPICard label="Cash Sweep"        value={result.valid ? fmtM(result.totalSweep) : '—'}   sub="extra debt repaid via FCF"
            tip="Additional debt repaid via cash sweep (free cash above mandatory amortisation). Higher sweep = faster deleveraging = lower debt at exit = more equity proceeds." />
          <KPICard label="Avg Int. Coverage" value={result.valid ? fmtX(interestCoverage) : '—'}    sub="EBIT / Interest"
            tip="EBIT ÷ Interest, averaged across years. Measures whether operating profit covers interest charges. Below 1.5x signals potential covenant stress; below 1.0x means EBIT doesn't cover interest." />
        </div>

        {/* Chart */}
        <div className="section-title" style={{ marginBottom: 8 }}>
          <span className="section-title-tag">Annual Free Cash Flow</span>
          <span className="section-subtitle"> · bars = levered FCF after debt service · amber line = DSCR coverage ratio</span>
        </div>
        <div className="chart-container">
          {result.valid
            ? <FCFChart yearlyData={result.yearlyData} entryEquity={result.equityAtEntry} />
            : <div className="chart-empty">Invalid deal structure — adjust inputs.</div>
          }
        </div>

        {/* Full P&L + FCF waterfall table */}
        {result.valid && (
          <div className="table-section">
            <div className="section-title" style={{ marginBottom: 8 }}><span className="section-title-tag">Annual P&amp;L &amp; Cash Flow</span></div>
            <div className="table-scroll">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Year</th>
                    <th>EBITDA</th>
                    <th>D&amp;A</th>
                    <th>EBIT</th>
                    <th>Interest</th>
                    <th>EBT</th>
                    <th>Tax</th>
                    <th>Net Income</th>
                    <th>Capex</th>
                    <th>Levered FCF</th>
                    <th>Mandatory</th>
                    <th>Sweep</th>
                    <th>Debt (EOY)</th>
                    <th>DSCR</th>
                    <th>Free Cash</th>
                  </tr>
                </thead>
                <tbody>
                  {result.yearlyData.map(row => (
                    <tr key={row.year}>
                      <td>Year {row.year}</td>
                      <td>{fmtM(row.ebitda)}</td>
                      <td className="dim">({fmtM(row.da)})</td>
                      <td>{fmtM(row.ebit)}</td>
                      <td className="dim">({fmtM(row.interest)})</td>
                      <td>{fmtM(row.ebt)}</td>
                      <td className="dim">({fmtM(row.tax)})</td>
                      <td>{fmtM(row.netIncome)}</td>
                      <td className="dim">({fmtM(row.capex)})</td>
                      <td className={row.leveredFCF >= 0 ? 'positive' : 'negative'}>{fmtM(row.leveredFCF)}</td>
                      <td className="dim">({fmtM(row.mandatoryPaydown)})</td>
                      <td className={row.sweepPaydown > 0 ? 'positive' : 'dim'}>
                        {row.sweepPaydown > 0 ? '(' + fmtM(row.sweepPaydown) + ')' : '—'}
                      </td>
                      <td>{fmtM(row.debt)}</td>
                      <td className={dscrColor(row.dscr) === 'green' ? 'positive' : dscrColor(row.dscr) === 'yellow' ? '' : 'negative'}>
                        {fmtX(row.dscr)}
                      </td>
                      <td className={row.freeCash >= 0 ? 'positive' : 'negative'}>{fmtM(row.freeCash)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Interpretation */}
        <div className={`interpretation-box ${result.valid && result.minDSCR >= 1.3 ? 'interpretation-green' : result.valid ? 'interpretation-red' : ''}`}>
          <div className="interpretation-icon">◆</div>
          <div className="interpretation-text">
            {!result.valid
              ? 'Invalid deal structure — equity at entry is zero or negative.'
              : (() => {
                  const dscrVerdict = result.minDSCR >= 2.0
                    ? `Debt service is comfortably covered throughout the hold period (min DSCR ${fmtX(result.minDSCR)} in Year ${result.minDSCRYear}).`
                    : result.minDSCR >= 1.3
                    ? `Debt service is adequately covered but tight at the low point (min DSCR ${fmtX(result.minDSCR)} in Year ${result.minDSCRYear}). Monitor covenant headroom.`
                    : `Debt service coverage is dangerously thin (min DSCR ${fmtX(result.minDSCR)} in Year ${result.minDSCRYear}). Risk of covenant breach — reduce leverage or improve FCF.`
                  const fcfVerdict = result.totalLeveredFCF > 0
                    ? `The business generates ${fmtM(result.totalLeveredFCF)} of cumulative levered FCF over the hold period (${fmtPct(fcfYield)} yield on equity).`
                    : `The business consumes ${fmtM(Math.abs(result.totalLeveredFCF))} of cash over the hold period — returns depend entirely on the exit multiple.`
                  return `${dscrVerdict} ${fcfVerdict} Total tax paid: ${fmtM(result.totalTaxPaid)}.`
                })()
            }
          </div>
        </div>
      </main>
    </div>
  )
}
