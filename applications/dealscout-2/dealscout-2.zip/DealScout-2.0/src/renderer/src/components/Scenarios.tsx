import { useState, useEffect } from 'react'
import { runLBO, LBOInputs, DEFAULT_LBO_INPUTS } from '../engine/lbo'

interface Props {
  inputs: LBOInputs
  setInputs: React.Dispatch<React.SetStateAction<LBOInputs>>
}

interface Scenario {
  id: string
  name: string
  inputs: LBOInputs
  irr: number
  moic: number
  valid: boolean
  savedAt: string
}

const STORAGE_KEY = 'dealscout2_scenarios'
const MAX_SCENARIOS = 6

function loadScenarios(): Scenario[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : []
  } catch { return [] }
}

function saveScenarios(scenarios: Scenario[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(scenarios))
}

function fmt(n: number, d = 1) { return n.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }) }
function fmtPct(n: number) { return fmt(n * 100, 1) + '%' }
function fmtX(n: number)   { return fmt(n, 2) + 'x' }
function fmtM(n: number)   { return '$' + fmt(n, 1) + 'M' }

function irrColor(irr: number): string {
  return irr >= 0.20 ? 'var(--green)' : irr >= 0.15 ? 'var(--yellow)' : 'var(--red)'
}

const PRESET_NAMES = ['Base Case', 'Bear Case', 'Bull Case', 'Scenario A', 'Scenario B', 'Scenario C']

export default function Scenarios({ inputs, setInputs }: Props) {
  const [scenarios, setScenarios] = useState<Scenario[]>(loadScenarios)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editName, setEditName] = useState('')

  useEffect(() => {
    saveScenarios(scenarios)
  }, [scenarios])

  function makeScenario(name: string, scenarioInputs: LBOInputs): Scenario {
    const result = runLBO(scenarioInputs)
    return {
      id:      crypto.randomUUID(),
      name,
      inputs:  { ...scenarioInputs },
      irr:     result.valid ? result.irr  : 0,
      moic:    result.valid ? result.moic : 0,
      valid:   result.valid,
      savedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: '2-digit' }),
    }
  }

  function saveCurrentScenario() {
    const used = new Set(scenarios.map(s => s.name))
    const name = PRESET_NAMES.find(n => !used.has(n)) ?? `Scenario ${scenarios.length + 1}`
    setScenarios(prev => [makeScenario(name, inputs), ...prev].slice(0, MAX_SCENARIOS))
  }

  function estimateScenarios() {
    // Strip ebitdaOverrides so growthRate changes actually affect the bear/bull EBITDA trajectories
    const { ebitdaOverrides: _stripped, ...baseInputs } = inputs
    const bearInputs: LBOInputs = {
      ...baseInputs,
      growthRate:   Math.max(-0.10, inputs.growthRate - 0.03),
      exitMultiple: Math.max(2,     inputs.exitMultiple - 1.0),
    }
    const bullInputs: LBOInputs = {
      ...baseInputs,
      growthRate:   Math.min(0.50,  inputs.growthRate + 0.03),
      exitMultiple: Math.min(25,    inputs.exitMultiple + 1.0),
    }
    const trio = [
      makeScenario('Bear Case', bearInputs),
      makeScenario('Base Case', inputs),
      makeScenario('Bull Case', bullInputs),
    ]
    // Replace any existing Bear/Base/Bull, append others, cap at MAX_SCENARIOS
    setScenarios(prev => {
      const kept = prev.filter(s => !['Bear Case', 'Base Case', 'Bull Case'].includes(s.name))
      return [...trio, ...kept].slice(0, MAX_SCENARIOS)
    })
  }

  function deleteScenario(id: string) {
    setScenarios(prev => prev.filter(s => s.id !== id))
  }

  function loadScenario(s: Scenario) {
    // Strip ebitdaOverrides — Operating Model toggle starts OFF when loading a scenario
    const { ebitdaOverrides: _stripped, ...cleanInputs } = s.inputs
    setInputs(cleanInputs)
  }

  function startRename(s: Scenario) {
    setEditingId(s.id)
    setEditName(s.name)
  }

  function commitRename(id: string) {
    if (editName.trim()) {
      setScenarios(prev => prev.map(s => s.id === id ? { ...s, name: editName.trim() } : s))
    }
    setEditingId(null)
  }

  function resetToDefault() {
    setInputs(DEFAULT_LBO_INPUTS)
  }

  const currentResult = runLBO(inputs)
  const currentIRR    = currentResult.valid ? currentResult.irr  : 0
  const currentMOIC   = currentResult.valid ? currentResult.moic : 0

  const compareFields: { label: string; key: keyof LBOInputs | 'irr' | 'moic'; format: (v: number) => string }[] = [
    { label: 'IRR',              key: 'irr',           format: fmtPct },
    { label: 'MOIC',             key: 'moic',          format: fmtX },
    { label: 'Entry EV/EBITDA',  key: 'entryMultiple', format: v => fmtX(v) },
    { label: 'Exit EV/EBITDA',   key: 'exitMultiple',  format: v => fmtX(v) },
    { label: 'EBITDA',           key: 'ebitda',        format: fmtM },
    { label: 'EBITDA Growth',    key: 'growthRate',     format: fmtPct },
    { label: 'Hold Period',      key: 'holdPeriod',     format: v => v + ' yrs' },
    { label: 'Debt / EBITDA',    key: 'debtEbitda',     format: fmtX },
    { label: 'Interest Rate',    key: 'interestRate',   format: fmtPct },
  ]

  return (
    <div className="tab-layout">
      {/* Left: saved scenario cards */}
      <aside className="input-panel scenarios-sidebar">
        <div className="panel-section">
          <div className="panel-section-title">Saved Scenarios ({scenarios.length}/{MAX_SCENARIOS})</div>

          <button
            className="scenario-save-btn"
            onClick={saveCurrentScenario}
            disabled={scenarios.length >= MAX_SCENARIOS}
          >
            + Save Current Inputs
          </button>

          <button
            className="scenario-estimate-btn"
            onClick={estimateScenarios}
            title="Generates Bear (−3% growth, −1x exit), Base, and Bull (+3% growth, +1x exit) from current inputs"
          >
            ⚡ Estimate Bear / Base / Bull
          </button>

          <div className="scenario-estimate-note">
            Bear: −3pp growth, −1x exit<br />
            Bull: +3pp growth, +1x exit
          </div>

          <button className="scenario-reset-btn" onClick={resetToDefault}>
            Reset to Defaults
          </button>
        </div>

        <div className="scenario-list">
          {scenarios.length === 0 && (
            <div className="scenario-empty">No saved scenarios yet. Adjust inputs and click "Save Current Inputs".</div>
          )}
          {scenarios.map(s => (
            <div
              key={s.id}
              className="scenario-card"
              onClick={() => loadScenario(s)}
              title="Click to load this scenario"
            >
              <div className="scenario-card-header">
                {editingId === s.id ? (
                  <input
                    className="scenario-name-input"
                    value={editName}
                    autoFocus
                    onChange={e => setEditName(e.target.value)}
                    onBlur={() => commitRename(s.id)}
                    onKeyDown={e => { if (e.key === 'Enter') commitRename(s.id); if (e.key === 'Escape') setEditingId(null) }}
                    onClick={e => e.stopPropagation()}
                  />
                ) : (
                  <span
                    className="scenario-name"
                    onDoubleClick={e => { e.stopPropagation(); startRename(s) }}
                    title="Double-click to rename"
                  >
                    {s.name}
                  </span>
                )}
                <button
                  className="scenario-delete"
                  onClick={e => { e.stopPropagation(); deleteScenario(s.id) }}
                  title="Delete scenario"
                >
                  ×
                </button>
              </div>
              <div className="scenario-card-stats">
                <span style={{ color: s.valid ? irrColor(s.irr) : 'var(--text-dim)' }}>
                  {s.valid ? fmtPct(s.irr) + ' IRR' : 'Invalid'}
                </span>
                <span style={{ color: 'var(--text-muted)' }}>
                  {s.valid ? fmtX(s.moic) + ' MOIC' : ''}
                </span>
              </div>
              <div className="scenario-card-meta">
                {s.inputs.entryMultiple.toFixed(1)}x entry · {(s.inputs.growthRate * 100).toFixed(0)}% growth · {s.savedAt}
              </div>
            </div>
          ))}
        </div>
      </aside>

      {/* Right: comparison table */}
      <main className="output-panel">
        <div className="section-title" style={{ marginBottom: 8 }}>
          <span className="section-title-tag">Scenario Comparison</span>
          <span className="section-subtitle"> · click a scenario card to load it · double-click name to rename</span>
        </div>

        {scenarios.length === 0 ? (
          <div className="scenario-table-empty">
            <div style={{ color: 'var(--text-dim)', fontSize: 14, textAlign: 'center', marginTop: 60 }}>
              Save scenarios using the panel on the left, then compare them here.
            </div>
          </div>
        ) : (
          <div className="table-scroll">
            <table className="data-table scenarios-table">
              <thead>
                <tr>
                  <th>Metric</th>
                  <th style={{ color: 'var(--accent)' }}>Current</th>
                  {scenarios.map(s => (
                    <th key={s.id}>{s.name}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {compareFields.map(f => {
                  const getCurrent = () => {
                    if (f.key === 'irr')  return currentResult.valid ? currentIRR  : null
                    if (f.key === 'moic') return currentResult.valid ? currentMOIC : null
                    return inputs[f.key as keyof LBOInputs] as number
                  }
                  const getScenario = (s: Scenario) => {
                    if (f.key === 'irr')  return s.valid ? s.irr  : null
                    if (f.key === 'moic') return s.valid ? s.moic : null
                    return s.inputs[f.key as keyof LBOInputs] as number
                  }
                  const curVal = getCurrent()
                  return (
                    <tr key={f.key}>
                      <td>{f.label}</td>
                      <td style={{ color: 'var(--accent)' }}>
                        {curVal !== null ? f.format(curVal) : '—'}
                      </td>
                      {scenarios.map(s => {
                        const v = getScenario(s)
                        const isIRR  = f.key === 'irr'
                        const isMOIC = f.key === 'moic'
                        const color  = isIRR && v !== null ? irrColor(v) :
                                       isMOIC && v !== null && curVal !== null
                                         ? v > curVal ? 'var(--green)' : v < curVal ? 'var(--red)' : ''
                                         : ''
                        return (
                          <td key={s.id} style={{ color: color || undefined }}>
                            {v !== null ? f.format(v) : '—'}
                          </td>
                        )
                      })}
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}

        <div className="interpretation-box" style={{ marginTop: 'auto' }}>
          <div className="interpretation-icon">◆</div>
          <div className="interpretation-text">
            {scenarios.length === 0
              ? 'Use the Scenario Manager to save and compare up to 6 deal structures side-by-side. Rename scenarios by double-clicking their name. Load any scenario back into the model with a single click.'
              : `Comparing ${scenarios.length} saved scenario${scenarios.length > 1 ? 's' : ''}. Current working inputs are shown in the first column. IRR is color-coded: green ≥ 20%, yellow ≥ 15%, red < 15%.`
            }
          </div>
        </div>
      </main>
    </div>
  )
}
