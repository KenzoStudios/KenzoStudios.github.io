import { useMemo } from 'react'
import { runLBO, LBOInputs } from '../engine/lbo'
import InputField from './InputField'
import KPICard from './KPICard'
import ValueBridge from './ValueBridge'
import ExitByYear from './ExitByYear'

interface Props {
  inputs: LBOInputs
  setInputs: React.Dispatch<React.SetStateAction<LBOInputs>>
  sourceLabel?: string | null
}

function fmt(n: number, d = 1) { return n.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }) }
function fmtPct(n: number) { return fmt(n * 100, 1) + '%' }
function fmtMx(n: number)  { return fmt(n, 1) + 'x' }
function fmtM(n: number)   { return '$' + fmt(n, 1) + 'M' }

function irrColor(irr: number): 'green' | 'yellow' | 'red' {
  return irr >= 0.20 ? 'green' : irr >= 0.15 ? 'yellow' : 'red'
}

function buildInterpretation(inputs: LBOInputs, irr: number, moic: number): string {
  const irrPct  = (irr * 100).toFixed(1)
  const moicFmt = moic.toFixed(2)
  const lev     = inputs.debtEbitda >= 5 ? 'significant leverage' : 'modest leverage'
  const growth  = inputs.growthRate >= 0.08 ? 'strong EBITDA growth' : inputs.growthRate >= 0.03 ? 'moderate EBITDA growth' : 'limited EBITDA growth'
  const mult    = inputs.exitMultiple > inputs.entryMultiple
    ? `multiple expansion (${fmtMx(inputs.entryMultiple)} → ${fmtMx(inputs.exitMultiple)})`
    : inputs.exitMultiple < inputs.entryMultiple
    ? `multiple contraction (${fmtMx(inputs.entryMultiple)} → ${fmtMx(inputs.exitMultiple)})`
    : 'flat multiple'
  const verdict = irr >= 0.20 ? 'a strong result' : irr >= 0.15 ? 'an acceptable result' : 'a below-target result'
  const taxNote = inputs.taxRate > 0 ? ` Tax rate of ${fmtPct(inputs.taxRate)} and capex of ${fmtPct(inputs.capexPercent)} of EBITDA are reflected in the FCF analysis.` : ''
  return `This deal generates a ${irrPct}% IRR (${moicFmt}x MOIC) — ${verdict}. Returns are driven by ${lev}, ${growth}, and ${mult} over ${inputs.holdPeriod} years.${taxNote}`
}

export default function StandardLBO({ inputs, setInputs, sourceLabel }: Props) {
  function set<K extends keyof LBOInputs>(key: K) {
    return (val: number) => setInputs(prev => ({ ...prev, [key]: val }))
  }

  // Debt/EV% ↔ Debt/EBITDA are bidirectionally linked via entry multiple
  const debtEvPct    = inputs.debtEbitda / inputs.entryMultiple
  const setDebtByEV  = (pct: number) => setInputs(prev => ({ ...prev, debtEbitda: pct * prev.entryMultiple }))

  const result = useMemo(() => runLBO(inputs), [inputs])
  const irr  = result.valid ? result.irr  : 0
  const moic = result.valid ? result.moic : 0

  return (
    <div className="tab-layout">
      <aside className="input-panel">
        <div className="panel-section">
          <div className="panel-section-title">Deal Parameters</div>
          <InputField
            label={<>Current EBITDA{sourceLabel && <span className="import-badge" style={{ marginLeft: 6 }}>{sourceLabel}</span>}</>}
            value={inputs.ebitda}
            onChange={set('ebitda')}
            suffix="$M"  step={10}   decimals={0} min={1}
            tip="Earnings Before Interest, Tax, Depreciation & Amortisation at entry. The fundamental scale of the business — all multiples and percentages are anchored to this number."
          />
          <InputField label="Entry EV / EBITDA" value={inputs.entryMultiple} onChange={set('entryMultiple')} suffix="x"   step={0.25} min={1} max={30}
            tip="Purchase price as a multiple of EBITDA. 8x means paying $800M for a $100M EBITDA business. Higher multiples compress IRR — even 0.5x can move returns by 1–2pp." />
          <InputField label="Exit EV / EBITDA"  value={inputs.exitMultiple}  onChange={set('exitMultiple')}  suffix="x"   step={0.25} min={1} max={30}
            tip="Assumed sale multiple at exit. Equal to entry = no multiple change. Above entry = expansion (adds value). Below entry = contraction (destroys value)." />
          <InputField label="EBITDA Growth"     value={inputs.growthRate}    onChange={set('growthRate')}    suffix="%"   asPercent step={0.5} min={-0.20} max={0.50}
            tip="Annual compound EBITDA growth applied over the hold period. One of the most powerful return drivers — a 2pp improvement in growth can add 3–5pp to IRR." />
          <InputField label="Hold Period"       value={inputs.holdPeriod}   onChange={set('holdPeriod')}   suffix="yrs" step={1} decimals={0} min={1} max={15}
            tip="Years from acquisition to exit. Shorter holds boost IRR (same gain, fewer years) but reduce MOIC. Longer holds allow more deleveraging and compounding." />
        </div>
        <div className="panel-section">
          <div className="panel-section-title">Capital Structure</div>
          <InputField label="Debt / EBITDA"      value={inputs.debtEbitda}    onChange={set('debtEbitda')}    suffix="x"   step={0.25} min={0} max={15}
            tip="Total debt drawn at close as a multiple of entry EBITDA. Standard LBO leverage is 4–6x. Higher leverage amplifies equity returns but reduces the margin of safety — watch DSCR." />
          <InputField label="Debt / EV"          value={debtEvPct}            onChange={setDebtByEV}          suffix="% of EV" asPercent step={1} min={0} max={0.98}
            tip="Debt as a percentage of total enterprise value. Linked to Debt/EBITDA via the entry multiple. Useful for comparing capital structures across different pricing environments." />
          <InputField label="Interest Rate"       value={inputs.interestRate}  onChange={set('interestRate')}  suffix="%"   asPercent step={0.25} min={0} max={0.30}
            tip="All-in annual interest cost on the debt facility (base rate + credit spread). Affects net income, free cash flow, and the speed of debt repayment via cash sweep." />
          <InputField label="Annual Debt Paydown" value={inputs.annualPaydown} onChange={set('annualPaydown')} suffix="%"   asPercent step={1} min={0} max={1} decimals={0}
            tip="Contractual principal amortisation per year as % of original debt drawn. Any free cash above this mandatory amount is swept to pay down additional debt." />
          <InputField label="Transaction Fees"    value={inputs.fees}          onChange={set('fees')}          suffix="%"   asPercent step={0.25} min={0} max={0.10}
            tip="Advisory, legal and financing fees incurred at close, as % of enterprise value. These are added to the equity cost at entry — increasing invested capital and reducing IRR." />
        </div>
        <div className="panel-section">
          <div className="panel-section-title">P&amp;L</div>
          <InputField label="D&A (% of EBITDA)"   value={inputs.daPercent}    onChange={set('daPercent')}    suffix="%" asPercent step={1} min={0} max={0.50} decimals={0}
            tip="Depreciation & Amortisation as a fraction of EBITDA. D&A is non-cash — it reduces taxable profit (tax shield) but adds back to free cash flow. Higher D&A = better FCF conversion." />
          <InputField label="Capex (% of EBITDA)"  value={inputs.capexPercent} onChange={set('capexPercent')} suffix="%" asPercent step={1} min={0} max={0.50} decimals={0}
            tip="Capital expenditure as a fraction of EBITDA. Cash outflow that reduces free cash available for debt repayment. High-capex businesses (manufacturing, infrastructure) have lower FCF conversion." />
          <InputField label="Tax Rate"              value={inputs.taxRate}      onChange={set('taxRate')}      suffix="%" asPercent step={1} min={0} max={0.50} decimals={0}
            tip="Effective corporate income tax rate applied to pre-tax profit each year. The interest deduction and D&A tax shield both reduce the tax burden, improving equity returns." />
        </div>
      </aside>

      <main className="output-panel">
        <div className="kpi-row">
          <KPICard label="IRR"             value={result.valid ? fmtPct(irr)           : '—'} highlight={result.valid ? irrColor(irr) : 'neutral'} large
            tip="Internal Rate of Return — the annualised equity return. Standard PE benchmark: 20%+ is strong, 15–20% acceptable, below 15% is typically below fund hurdle rates." />
          <KPICard label="MOIC"            value={result.valid ? moic.toFixed(2) + 'x' : '—'} highlight={result.valid ? irrColor(irr) : 'neutral'} large
            tip="Multiple of Invested Capital — exit equity ÷ entry equity. Complements IRR: the same 3.0x MOIC yields ~25% IRR over 5 years but only ~17% over 7 years." />
          <KPICard label="Entry EV"        value={fmtM(result.entryEV)}       sub={fmtMx(inputs.entryMultiple) + ' EV/EBITDA'}
            tip="Total enterprise value paid at acquisition = EBITDA × entry multiple. This is the headline deal size — split between debt drawn and equity invested." />
          <KPICard label="Equity at Entry" value={fmtM(result.equityAtEntry)} sub={'Debt: ' + fmtM(result.debtAtEntry)}
            tip="Cash equity invested by the sponsor = Entry EV + transaction fees − debt. This is the denominator for MOIC and the starting point for IRR calculation." />
          <KPICard label="Debt / EV"      value={fmtPct(debtEvPct)} sub={fmtMx(inputs.debtEbitda) + ' Debt/EBITDA'}
            tip="Debt as a % of entry enterprise value. Shown alongside Debt/EBITDA — the two metrics together characterise the capital structure from different angles." />
          <KPICard label="Exit EV"         value={result.valid ? fmtM(result.exitEV)     : '—'} sub={result.valid ? fmtMx(inputs.exitMultiple) + ' × ' + fmtM(result.exitEBITDA) : undefined}
            tip="Enterprise value at exit = exit EBITDA × exit multiple. Total proceeds from the sale — debt repayment comes out first, with the remainder flowing to equity." />
          <KPICard label="Exit Equity"     value={result.valid ? fmtM(result.exitEquity) : '—'} sub={result.valid ? 'Debt at exit: ' + fmtM(result.debtAtExit) : undefined}
            tip="Cash returned to equity at exit = Exit EV − remaining debt. Divided by Equity at Entry gives your MOIC. The higher the deleveraging, the larger this number." />
        </div>

        {result.valid && (
          <div className="table-section">
            <div className="section-title" style={{ marginBottom: 8 }}><span className="section-title-tag">Annual Progression</span></div>
            <div className="table-scroll">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Year</th>
                    <th>EBITDA</th>
                    <th>EBIT</th>
                    <th>Net Income</th>
                    <th>Levered FCF</th>
                    <th>Interest</th>
                    <th>Amort.</th>
                    <th>Sweep</th>
                    <th>Debt (EOY)</th>
                    <th>DSCR</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="table-entry-row">
                    <td>Entry</td>
                    <td>{fmtM(inputs.ebitda)}</td>
                    <td>{fmtM(inputs.ebitda * (1 - inputs.daPercent))}</td>
                    <td>—</td><td>—</td><td>—</td><td>—</td><td>—</td>
                    <td>{fmtM(result.debtAtEntry)}</td>
                    <td>—</td>
                  </tr>
                  {result.yearlyData.map(row => (
                    <tr key={row.year}>
                      <td>Year {row.year}</td>
                      <td>{fmtM(row.ebitda)}</td>
                      <td>{fmtM(row.ebit)}</td>
                      <td>{fmtM(row.netIncome)}</td>
                      <td className={row.leveredFCF >= 0 ? 'positive' : 'negative'}>{fmtM(row.leveredFCF)}</td>
                      <td className="dim">({fmtM(row.interest)})</td>
                      <td className="dim">({fmtM(row.mandatoryPaydown)})</td>
                      <td className={row.sweepPaydown > 0 ? 'positive' : 'dim'}>{row.sweepPaydown > 0 ? '(' + fmtM(row.sweepPaydown) + ')' : '—'}</td>
                      <td>{fmtM(row.debt)}</td>
                      <td>{row.dscr.toFixed(2)}x</td>
                    </tr>
                  ))}
                  <tr className="table-exit-row">
                    <td>Exit</td>
                    <td>{fmtM(result.exitEBITDA)}</td>
                    <td colSpan={6}>—</td>
                    <td>{fmtM(result.debtAtExit)}</td>
                    <td>—</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {result.valid && (
          <div className="table-section">
            <div className="section-title" style={{ marginBottom: 8 }}>
              <span className="section-title-tag">Returns Attribution</span>
              <span className="section-subtitle"> · waterfall from entry equity to exit equity</span>
            </div>
            <div className="value-bridge-container">
              <ValueBridge inputs={inputs} result={result} />
            </div>
          </div>
        )}

        {result.valid && (
          <div className="table-section">
            <div className="section-title" style={{ marginBottom: 8 }}>
              <span className="section-title-tag">Exit-by-Year Analysis</span>
              <span className="section-subtitle"> · ★ marks the selected hold period</span>
            </div>
            <ExitByYear inputs={inputs} />
          </div>
        )}

        <div className="interpretation-box">
          <div className="interpretation-icon">◆</div>
          <div className="interpretation-text">
            {result.valid
              ? buildInterpretation(inputs, irr, moic)
              : 'Invalid deal structure — equity at entry is zero or negative. Reduce the entry multiple or debt level.'}
          </div>
        </div>
      </main>
    </div>
  )
}
