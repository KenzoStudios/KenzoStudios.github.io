import InfoBadge from './InfoBadge'

interface KPICardProps {
  label: string
  value: string
  sub?: string
  highlight?: 'green' | 'red' | 'yellow' | 'neutral'
  large?: boolean
  tip?: string
}

export default function KPICard({ label, value, sub, highlight = 'neutral', large = false, tip }: KPICardProps) {
  return (
    <div className={`kpi-card kpi-${highlight} ${large ? 'kpi-large' : ''}`}>
      <div className="kpi-label">
        {label}
        {tip && <InfoBadge tip={tip} />}
      </div>
      <div className="kpi-value">{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  )
}
