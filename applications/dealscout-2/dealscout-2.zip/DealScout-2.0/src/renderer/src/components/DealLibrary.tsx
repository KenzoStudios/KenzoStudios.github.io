import { useState, useEffect, useRef, ChangeEvent } from 'react'
import { DealRecord, LBOInputs } from '../engine/lbo'
import { runLBO } from '../engine/lbo'

type SortKey = 'date' | 'irr' | 'name'

interface Props {
  inputs: LBOInputs
  companyName: string
  onLoadDeal: (inputs: LBOInputs, name: string) => void
  onClose: () => void
}

function irrBadgeClass(irr: number) {
  return irr >= 0.20 ? 'deal-card-irr-badge irr-green' : irr >= 0.15 ? 'deal-card-irr-badge irr-amber' : 'deal-card-irr-badge irr-red'
}

function fmtDate(iso: string) {
  try {
    return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
  } catch {
    return iso
  }
}

function fmtM(n: number) { return '$' + n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + 'M' }
function fmtPct(n: number) { return (n * 100).toFixed(1) + '%' }

const api = () => (window as any).api as {
  deals: {
    getAll: () => Promise<DealRecord[]>
    save: (d: DealRecord) => Promise<{ success: boolean }>
    delete: (id: string) => Promise<{ success: boolean }>
    export: (id: string) => Promise<{ success: boolean }>
    import: (json: string) => Promise<{ success: boolean; deal?: DealRecord }>
  }
}

export default function DealLibrary({ inputs, companyName, onLoadDeal, onClose }: Props) {
  const [deals, setDeals] = useState<DealRecord[]>([])
  const [sort, setSort] = useState<SortKey>('date')
  const [compareMode, setCompareMode] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [showCompare, setShowCompare] = useState(false)
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)
  const [saveName, setSaveName] = useState('')
  const [showSaveInput, setShowSaveInput] = useState(false)
  const importRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    loadDeals()
  }, [])

  async function loadDeals() {
    try {
      const all = await api().deals.getAll()
      setDeals(all || [])
    } catch (e) {
      console.error('Failed to load deals', e)
    }
  }

  async function handleSave() {
    if (!saveName.trim()) return
    const result = runLBO(inputs)
    const deal: DealRecord = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      name: saveName.trim(),
      savedAt: new Date().toISOString(),
      inputs,
      irr: result.irr,
      moic: result.moic,
      entryEV: result.entryEV,
      exitEquity: result.exitEquity,
      valid: result.valid,
    }
    try {
      await api().deals.save(deal)
      setSaveName('')
      setShowSaveInput(false)
      loadDeals()
    } catch (e) {
      console.error('Failed to save deal', e)
    }
  }

  async function handleDelete(id: string) {
    try {
      await api().deals.delete(id)
      setDeleteConfirm(null)
      setSelected(prev => { const n = new Set(prev); n.delete(id); return n })
      loadDeals()
    } catch (e) {
      console.error('Failed to delete deal', e)
    }
  }

  async function handleExport(id: string) {
    try {
      await api().deals.export(id)
    } catch (e) {
      console.error('Failed to export deal', e)
    }
  }

  async function handleImportFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    try {
      const text = await file.text()
      const result = await api().deals.import(text)
      if (result.success) loadDeals()
      else alert('Failed to import: invalid file format')
    } catch (err) {
      alert('Failed to import deal file')
    }
    e.target.value = ''
  }

  function toggleSelect(id: string) {
    setSelected(prev => {
      const n = new Set(prev)
      if (n.has(id)) n.delete(id)
      else if (n.size < 4) n.add(id)
      return n
    })
  }

  const sorted = [...deals].sort((a, b) => {
    if (sort === 'date') return new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime()
    if (sort === 'irr')  return b.irr - a.irr
    return a.name.localeCompare(b.name)
  })

  const compareDeals = deals.filter(d => selected.has(d.id))

  const compareRows = [
    { label: 'IRR',            fmt: (d: DealRecord) => fmtPct(d.irr) },
    { label: 'MOIC',           fmt: (d: DealRecord) => d.moic.toFixed(2) + 'x' },
    { label: 'Entry EV',       fmt: (d: DealRecord) => fmtM(d.entryEV) },
    { label: 'Exit Equity',    fmt: (d: DealRecord) => fmtM(d.exitEquity) },
    { label: 'Debt/EV',        fmt: (d: DealRecord) => fmtPct(d.inputs.debtEbitda / d.inputs.entryMultiple) },
    { label: 'Entry Multiple', fmt: (d: DealRecord) => d.inputs.entryMultiple.toFixed(1) + 'x' },
    { label: 'Exit Multiple',  fmt: (d: DealRecord) => d.inputs.exitMultiple.toFixed(1) + 'x' },
    { label: 'EBITDA Growth',  fmt: (d: DealRecord) => fmtPct(d.inputs.growthRate) + '/yr' },
    { label: 'Hold Period',    fmt: (d: DealRecord) => d.inputs.holdPeriod + ' yrs' },
  ]

  return (
    <>
      {/* Backdrop */}
      <div className="deal-library-overlay" onClick={onClose} />

      {/* Slide-over panel */}
      <div className="deal-library">
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text)' }}>Deal Library</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: 20, cursor: 'pointer', lineHeight: 1, padding: '0 2px' }}>×</button>
        </div>

        {/* Actions */}
        <div style={{ padding: '10px 12px', borderBottom: '1px solid var(--border)', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 6 }}>
          {showSaveInput ? (
            <div style={{ display: 'flex', gap: 6 }}>
              <input
                autoFocus
                type="text"
                value={saveName}
                onChange={e => setSaveName(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') handleSave(); if (e.key === 'Escape') setShowSaveInput(false) }}
                placeholder="Deal name…"
                style={{ flex: 1, background: 'var(--bg)', border: '1px solid var(--accent)', borderRadius: 4, color: 'var(--text)', padding: '5px 8px', fontSize: 12, outline: 'none' }}
              />
              <button onClick={handleSave} style={{ background: 'var(--accent)', border: 'none', color: '#fff', borderRadius: 4, padding: '5px 10px', fontSize: 12, cursor: 'pointer' }}>Save</button>
              <button onClick={() => setShowSaveInput(false)} style={{ background: 'var(--bg-raised)', border: '1px solid var(--border)', color: 'var(--text-muted)', borderRadius: 4, padding: '5px 8px', fontSize: 12, cursor: 'pointer' }}>✕</button>
            </div>
          ) : (
            <button
              onClick={() => { setSaveName(companyName); setShowSaveInput(true) }}
              style={{ width: '100%', background: 'var(--accent)', border: 'none', color: '#fff', borderRadius: 4, padding: '7px', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}
            >
              Save Current Deal
            </button>
          )}
          <div style={{ display: 'flex', gap: 6 }}>
            <button
              onClick={() => importRef.current?.click()}
              style={{ flex: 1, background: 'var(--bg-raised)', border: '1px solid var(--border)', color: 'var(--text-muted)', borderRadius: 4, padding: '5px', fontSize: 11, cursor: 'pointer' }}
            >
              Import .dealscout2
            </button>
            <button
              onClick={() => { setCompareMode(m => !m); setShowCompare(false); setSelected(new Set()) }}
              style={{ flex: 1, background: compareMode ? 'rgba(59,130,246,0.15)' : 'var(--bg-raised)', border: `1px solid ${compareMode ? 'var(--accent)' : 'var(--border)'}`, color: compareMode ? 'var(--accent)' : 'var(--text-muted)', borderRadius: 4, padding: '5px', fontSize: 11, cursor: 'pointer' }}
            >
              {compareMode ? 'Exit Compare' : 'Compare'}
            </button>
          </div>
          <input ref={importRef} type="file" accept=".dealscout2" style={{ display: 'none' }} onChange={handleImportFile} />
        </div>

        {/* Sort bar */}
        <div style={{ display: 'flex', gap: 4, padding: '8px 12px', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
          <span style={{ fontSize: 10, color: 'var(--text-dim)', alignSelf: 'center', marginRight: 4 }}>Sort:</span>
          {(['date', 'irr', 'name'] as SortKey[]).map(s => (
            <button
              key={s}
              onClick={() => setSort(s)}
              style={{
                background: sort === s ? 'var(--bg-raised)' : 'transparent',
                border: `1px solid ${sort === s ? 'var(--border-mid)' : 'transparent'}`,
                color: sort === s ? 'var(--text)' : 'var(--text-muted)',
                borderRadius: 4, padding: '2px 8px', fontSize: 11, cursor: 'pointer',
              }}
            >
              {s === 'date' ? 'Date' : s === 'irr' ? 'IRR' : 'Name'}
            </button>
          ))}
        </div>

        {/* List */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '8px 10px', display: 'flex', flexDirection: 'column', gap: 6 }}>
          {sorted.length === 0 && (
            <div style={{ color: 'var(--text-dim)', fontSize: 12, textAlign: 'center', marginTop: 24 }}>
              No saved deals yet.<br />Save the current model to build your library.
            </div>
          )}
          {sorted.map(deal => (
            <div
              key={deal.id}
              className="deal-card"
              onClick={() => { if (!compareMode) onLoadDeal(deal.inputs, deal.name) }}
            >
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 4 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  {compareMode && (
                    <input
                      type="checkbox"
                      checked={selected.has(deal.id)}
                      onChange={() => toggleSelect(deal.id)}
                      onClick={e => e.stopPropagation()}
                      style={{ cursor: 'pointer' }}
                    />
                  )}
                  <div style={{ fontWeight: 700, fontSize: 13, color: 'var(--text)' }}>{deal.name}</div>
                </div>
                <div style={{ display: 'flex', gap: 4 }}>
                  <button
                    title="Export"
                    onClick={e => { e.stopPropagation(); handleExport(deal.id) }}
                    style={{ background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer', fontSize: 13, padding: '0 2px' }}
                  >
                    ↓
                  </button>
                  {deleteConfirm === deal.id ? (
                    <>
                      <button onClick={e => { e.stopPropagation(); handleDelete(deal.id) }} style={{ background: 'var(--red-bg)', border: '1px solid var(--red-dim)', color: 'var(--red)', borderRadius: 3, padding: '1px 5px', fontSize: 10, cursor: 'pointer' }}>Delete</button>
                      <button onClick={e => { e.stopPropagation(); setDeleteConfirm(null) }} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: 12 }}>✕</button>
                    </>
                  ) : (
                    <button
                      title="Delete"
                      onClick={e => { e.stopPropagation(); setDeleteConfirm(deal.id) }}
                      style={{ background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer', fontSize: 14, padding: '0 2px' }}
                    >
                      🗑
                    </button>
                  )}
                </div>
              </div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 5 }}>
                EV: {fmtM(deal.entryEV)} · EBITDA: {fmtM(deal.inputs.ebitda)} · {deal.inputs.holdPeriod}yr hold
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span className={irrBadgeClass(deal.irr)}>{fmtPct(deal.irr)} IRR</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text)', fontWeight: 700 }}>{deal.moic.toFixed(2)}x MOIC</span>
              </div>
              <div style={{ fontSize: 10, color: 'var(--text-dim)', marginTop: 5 }}>{fmtDate(deal.savedAt)}</div>
            </div>
          ))}
        </div>

        {/* Compare action */}
        {compareMode && selected.size >= 2 && (
          <div style={{ padding: '10px 12px', borderTop: '1px solid var(--border)', flexShrink: 0 }}>
            <button
              onClick={() => setShowCompare(true)}
              style={{ width: '100%', background: 'var(--accent)', border: 'none', color: '#fff', borderRadius: 4, padding: '7px', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}
            >
              Compare {selected.size} Deals
            </button>
          </div>
        )}
      </div>

      {/* Comparison table — full-width overlay below library */}
      {showCompare && compareDeals.length >= 2 && (
        <div style={{
          position: 'fixed', right: 340, top: 0, bottom: 0, width: 500,
          background: 'var(--bg-surface)', borderLeft: '1px solid var(--border)',
          zIndex: 49, overflow: 'auto', padding: 20,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <div style={{ fontSize: 14, fontWeight: 700 }}>Deal Comparison</div>
            <button onClick={() => setShowCompare(false)} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: 18, cursor: 'pointer' }}>×</button>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12, fontFamily: 'var(--font-mono)' }}>
            <thead>
              <tr>
                <th style={{ textAlign: 'left', color: 'var(--text-dim)', fontSize: 10, padding: '6px 8px', borderBottom: '1px solid var(--border)', width: 120 }}>Metric</th>
                {compareDeals.map(d => (
                  <th key={d.id} style={{ textAlign: 'right', color: 'var(--text-muted)', fontSize: 11, padding: '6px 8px', borderBottom: '1px solid var(--border)' }}>{d.name}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {compareRows.map(row => (
                <tr key={row.label}>
                  <td style={{ color: 'var(--text-muted)', padding: '5px 8px', borderBottom: '1px solid var(--border)', fontSize: 11 }}>{row.label}</td>
                  {compareDeals.map(d => {
                    const isIrr = row.label === 'IRR'
                    const color = isIrr ? (d.irr >= 0.20 ? 'var(--green)' : d.irr >= 0.15 ? 'var(--yellow)' : 'var(--red)') : 'var(--text)'
                    return (
                      <td key={d.id} style={{ textAlign: 'right', padding: '5px 8px', borderBottom: '1px solid var(--border)', color }}>{row.fmt(d)}</td>
                    )
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  )
}
