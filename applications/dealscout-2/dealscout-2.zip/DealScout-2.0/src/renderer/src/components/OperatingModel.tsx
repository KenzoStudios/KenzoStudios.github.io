import { useMemo, useState, useRef, useEffect, FocusEvent, ChangeEvent } from 'react'
import { LBOInputs, OperatingModelState, OpYearData, DEFAULT_OP_YEAR, computeOpModel, runLBO } from '../engine/lbo'

interface Props {
  inputs: LBOInputs
  setInputs: React.Dispatch<React.SetStateAction<LBOInputs>>
  opModel: OperatingModelState
  setOpModel: React.Dispatch<React.SetStateAction<OperatingModelState>>
}

// ── Formatting helpers ─────────────────────────────────────────────────────────

function fmtM(n: number) { return '$' + n.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + 'M' }
function fmtPct(n: number) { return (n * 100).toFixed(1) + '%' }

// ── Editable cell component ────────────────────────────────────────────────────

interface EditCellProps {
  value: number
  display: string
  onChange: (v: number) => void
  isOverridden?: boolean
  readOnly?: boolean
  highlight?: 'ebitda' | 'fcf' | 'computed'
}

function EditCell({ value, display, onChange, isOverridden, readOnly, highlight }: EditCellProps) {
  const [editing, setEditing] = useState(false)
  const [raw, setRaw] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  function handleFocus(e: FocusEvent<HTMLInputElement>) {
    setEditing(true)
    setRaw(String(value))
    setTimeout(() => inputRef.current?.select(), 0)
  }

  function handleBlur() {
    setEditing(false)
    const n = parseFloat(raw)
    if (!isNaN(n) && n !== value) onChange(n)
  }

  function handleChange(e: ChangeEvent<HTMLInputElement>) {
    setRaw(e.target.value)
  }

  const bg = highlight === 'ebitda' ? 'rgba(59,130,246,0.08)'
    : highlight === 'fcf' ? 'rgba(34,197,94,0.08)'
    : 'transparent'

  const color = highlight === 'ebitda' ? 'var(--accent)'
    : highlight === 'fcf' ? 'var(--green)'
    : readOnly ? 'var(--text-dim)'
    : 'var(--text)'

  return (
    <td
      className={`op-model-cell${isOverridden ? ' op-model-override-dot' : ''}${readOnly ? ' op-model-computed' : ''}`}
      style={{ background: bg, textAlign: 'right', position: 'relative' }}
    >
      {isOverridden && (
        <span style={{
          position: 'absolute', top: 3, right: 3,
          width: 5, height: 5, borderRadius: '50%',
          background: 'var(--accent)', pointerEvents: 'none',
        }} />
      )}
      {readOnly ? (
        <span style={{ color, fontFamily: 'var(--font-mono)', fontSize: 12 }}>{display}</span>
      ) : (
        <input
          ref={inputRef}
          type="text"
          value={editing ? raw : display}
          onFocus={handleFocus}
          onBlur={handleBlur}
          onChange={handleChange}
          style={{
            background: 'transparent',
            border: 'none',
            outline: 'none',
            color,
            fontFamily: 'var(--font-mono)',
            fontSize: 12,
            width: '100%',
            textAlign: 'right',
            padding: '0 4px',
            cursor: 'text',
          }}
        />
      )}
    </td>
  )
}

// ── Main component ─────────────────────────────────────────────────────────────

export default function OperatingModel({ inputs, setInputs, opModel, setOpModel }: Props) {
  const n = inputs.holdPeriod

  // Ensure yearData length matches holdPeriod
  const yearData: OpYearData[] = useMemo(() => {
    const arr = [...opModel.yearData]
    while (arr.length < n) arr.push({ ...DEFAULT_OP_YEAR, overrides: {} })
    return arr.slice(0, n)
  }, [opModel.yearData, n])

  // Run base LBO for interest schedule
  const lboResult = useMemo(() => runLBO(inputs), [inputs])

  // Compute operating model
  const computed = useMemo(() =>
    computeOpModel(opModel.entryRevenue, opModel.entryEbitda, yearData, inputs.taxRate, lboResult.yearlyData),
    [opModel.entryRevenue, opModel.entryEbitda, yearData, inputs.taxRate, lboResult.yearlyData]
  )

  // Re-sync ebitdaOverrides whenever holdPeriod changes while the link is active
  useEffect(() => {
    if (!opModel.active) return
    const ebitdaOverrides = computed.map(c => c.ebitda)
    setInputs(prev => ({ ...prev, ebitdaOverrides }))
  }, [n]) // eslint-disable-line react-hooks/exhaustive-deps

  function updateYearField<K extends keyof OpYearData>(yearIdx: number, field: K, value: OpYearData[K]) {
    const newYearData = yearData.map((y, i) => i === yearIdx ? { ...y, [field]: value } : y)
    const newOpModel = { ...opModel, yearData: newYearData }

    if (newOpModel.active) {
      const newComputed = computeOpModel(newOpModel.entryRevenue, newOpModel.entryEbitda, newYearData, inputs.taxRate, lboResult.yearlyData)
      const ebitdaOverrides = newComputed.map(c => c.ebitda)
      setInputs(prev => ({ ...prev, ebitdaOverrides }))
    }
    setOpModel(newOpModel)
  }

  function setOverride(yearIdx: number, field: string, value: number) {
    const ov = { ...yearData[yearIdx].overrides, [field]: value }
    updateYearField(yearIdx, 'overrides', ov)
  }

  function clearOverride(yearIdx: number, field: string) {
    const ov = { ...yearData[yearIdx].overrides }
    delete ov[field]
    updateYearField(yearIdx, 'overrides', ov)
  }

  function toggleLink() {
    const newActive = !opModel.active
    setOpModel(prev => ({ ...prev, active: newActive }))
    if (newActive) {
      const ebitdaOverrides = computed.map(c => c.ebitda)
      setInputs(prev => ({ ...prev, ebitdaOverrides }))
    } else {
      setInputs(prev => {
        const next = { ...prev }
        delete next.ebitdaOverrides
        return next
      })
    }
  }

  // Row definitions
  const rows = [
    {
      label: 'Revenue',
      key: 'revenue',
      isEditable: true,
      getValue: (i: number) => computed[i]?.revenue ?? 0,
      getDisplay: (i: number) => fmtM(computed[i]?.revenue ?? 0),
      getEntry: () => fmtM(opModel.entryRevenue),
      onEdit: (yearIdx: number, v: number) => setOverride(yearIdx, 'revenue', v),
      isOverridden: (i: number) => 'revenue' in yearData[i].overrides,
    },
    {
      label: 'Revenue Growth %',
      key: 'revenueGrowthPct',
      isEditable: true,
      getValue: (i: number) => yearData[i].revenueGrowthPct,
      getDisplay: (i: number) => fmtPct(yearData[i].revenueGrowthPct),
      getEntry: () => '—',
      onEdit: (yearIdx: number, v: number) => updateYearField(yearIdx, 'revenueGrowthPct', v / 100),
      isOverridden: (i: number) => yearData[i].revenueGrowthPct !== DEFAULT_OP_YEAR.revenueGrowthPct,
    },
    {
      label: 'COGS',
      key: 'cogs',
      isEditable: true,
      getValue: (i: number) => computed[i]?.cogs ?? 0,
      getDisplay: (i: number) => `(${fmtM(computed[i]?.cogs ?? 0)})`,
      getEntry: () => '—',
      onEdit: (yearIdx: number, v: number) => {
        const rev = computed[yearIdx]?.revenue ?? 1
        updateYearField(yearIdx, 'cogsMarginPct', Math.abs(v) / rev)
      },
      isOverridden: (i: number) => yearData[i].cogsMarginPct !== DEFAULT_OP_YEAR.cogsMarginPct,
    },
    {
      label: 'Gross Profit',
      key: 'grossProfit',
      isEditable: false,
      getValue: (i: number) => computed[i]?.grossProfit ?? 0,
      getDisplay: (i: number) => fmtM(computed[i]?.grossProfit ?? 0),
      getEntry: () => '—',
      onEdit: () => {},
      isOverridden: (_i: number) => false,
      bold: true,
    },
    {
      label: 'SG&A',
      key: 'sga',
      isEditable: true,
      getValue: (i: number) => computed[i]?.sga ?? 0,
      getDisplay: (i: number) => `(${fmtM(computed[i]?.sga ?? 0)})`,
      getEntry: () => '—',
      onEdit: (yearIdx: number, v: number) => {
        const rev = computed[yearIdx]?.revenue ?? 1
        updateYearField(yearIdx, 'sgaMarginPct', Math.abs(v) / rev)
      },
      isOverridden: (i: number) => yearData[i].sgaMarginPct !== DEFAULT_OP_YEAR.sgaMarginPct,
    },
    {
      label: 'EBITDA',
      key: 'ebitda',
      isEditable: true,
      getValue: (i: number) => computed[i]?.ebitda ?? 0,
      getDisplay: (i: number) => fmtM(computed[i]?.ebitda ?? 0),
      getEntry: () => fmtM(opModel.entryEbitda),
      onEdit: (yearIdx: number, v: number) => setOverride(yearIdx, 'ebitda', v),
      isOverridden: (i: number) => 'ebitda' in yearData[i].overrides,
      highlight: 'ebitda' as const,
      bold: true,
    },
    {
      label: 'EBITDA Margin %',
      key: 'ebitdaMargin',
      isEditable: false,
      getValue: (i: number) => computed[i]?.ebitdaMargin ?? 0,
      getDisplay: (i: number) => fmtPct(computed[i]?.ebitdaMargin ?? 0),
      getEntry: () => fmtPct(opModel.entryEbitda / (opModel.entryRevenue || 1)),
    },
    {
      label: 'D&A',
      key: 'da',
      isEditable: true,
      getValue: (i: number) => computed[i]?.da ?? 0,
      getDisplay: (i: number) => fmtM(computed[i]?.da ?? 0),
      getEntry: () => '—',
      onEdit: (yearIdx: number, v: number) => {
        const ebitda = computed[yearIdx]?.ebitda ?? 1
        updateYearField(yearIdx, 'daPctOfEbitda', Math.abs(v) / ebitda)
      },
      isOverridden: (i: number) => yearData[i].daPctOfEbitda !== DEFAULT_OP_YEAR.daPctOfEbitda,
    },
    {
      label: 'EBIT',
      key: 'ebit',
      isEditable: false,
      getValue: (i: number) => computed[i]?.ebit ?? 0,
      getDisplay: (i: number) => fmtM(computed[i]?.ebit ?? 0),
      getEntry: () => '—',
    },
    {
      label: 'Interest Expense',
      key: 'interest',
      isEditable: false,
      getValue: (i: number) => computed[i]?.interest ?? 0,
      getDisplay: (i: number) => `(${fmtM(computed[i]?.interest ?? 0)})`,
      getEntry: () => '—',
    },
    {
      label: 'EBT',
      key: 'ebt',
      isEditable: false,
      getValue: (i: number) => computed[i]?.ebt ?? 0,
      getDisplay: (i: number) => fmtM(computed[i]?.ebt ?? 0),
      getEntry: () => '—',
    },
    {
      label: 'Tax',
      key: 'tax',
      isEditable: false,
      getValue: (i: number) => computed[i]?.tax ?? 0,
      getDisplay: (i: number) => `(${fmtM(computed[i]?.tax ?? 0)})`,
      getEntry: () => '—',
    },
    {
      label: 'Net Income',
      key: 'netIncome',
      isEditable: false,
      getValue: (i: number) => computed[i]?.netIncome ?? 0,
      getDisplay: (i: number) => fmtM(computed[i]?.netIncome ?? 0),
      getEntry: () => '—',
      bold: true,
    },
    {
      label: 'Capex',
      key: 'capex',
      isEditable: true,
      getValue: (i: number) => computed[i]?.capex ?? 0,
      getDisplay: (i: number) => `(${fmtM(computed[i]?.capex ?? 0)})`,
      getEntry: () => '—',
      onEdit: (yearIdx: number, v: number) => {
        const rev = computed[yearIdx]?.revenue ?? 1
        updateYearField(yearIdx, 'capexPctOfRevenue', Math.abs(v) / rev)
      },
      isOverridden: (i: number) => yearData[i].capexPctOfRevenue !== DEFAULT_OP_YEAR.capexPctOfRevenue,
    },
    {
      label: 'ΔWorking Capital',
      key: 'wcChange',
      isEditable: true,
      getValue: (i: number) => computed[i]?.wcChange ?? 0,
      getDisplay: (i: number) => `(${fmtM(computed[i]?.wcChange ?? 0)})`,
      getEntry: () => '—',
      onEdit: (yearIdx: number, v: number) => {
        const rev = computed[yearIdx]?.revenue ?? 1
        updateYearField(yearIdx, 'wcChangePctOfRevenue', Math.abs(v) / rev)
      },
      isOverridden: (i: number) => yearData[i].wcChangePctOfRevenue !== DEFAULT_OP_YEAR.wcChangePctOfRevenue,
    },
    {
      label: 'Levered FCF',
      key: 'leveredFCF',
      isEditable: false,
      getValue: (i: number) => computed[i]?.leveredFCF ?? 0,
      getDisplay: (i: number) => fmtM(computed[i]?.leveredFCF ?? 0),
      getEntry: () => '—',
      highlight: 'fcf' as const,
      bold: true,
    },
  ]

  return (
    <div style={{ display: 'flex', flexDirection: 'column', width: '100%', height: '100%', overflow: 'hidden' }}>
      {/* Controls strip */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 12, padding: '8px 16px',
        background: 'var(--bg-surface)', borderBottom: '1px solid var(--border)', flexShrink: 0,
      }}>
        <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Entry Revenue</div>
        <div className="input-wrapper" style={{ width: 120 }}>
          <input
            type="number"
            className="input-control"
            value={opModel.entryRevenue}
            onChange={e => setOpModel(prev => ({ ...prev, entryRevenue: parseFloat(e.target.value) || 0 }))}
          />
          <span className="input-suffix">$M</span>
        </div>
        <div style={{ fontSize: 12, color: 'var(--text-muted)', marginLeft: 8 }}>Entry EBITDA</div>
        <div className="input-wrapper" style={{ width: 120 }}>
          <input
            type="number"
            className="input-control"
            value={opModel.entryEbitda}
            onChange={e => {
              const v = parseFloat(e.target.value) || 0
              setOpModel(prev => ({ ...prev, entryEbitda: v }))
            }}
          />
          <span className="input-suffix">$M</span>
        </div>

        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Link to LBO Model</span>
          <button
            onClick={toggleLink}
            style={{
              background: opModel.active ? 'var(--accent)' : 'var(--bg-raised)',
              border: `1px solid ${opModel.active ? 'var(--accent)' : 'var(--border)'}`,
              color: opModel.active ? '#fff' : 'var(--text-muted)',
              borderRadius: 4, padding: '4px 12px', fontSize: 12, cursor: 'pointer', fontWeight: 600,
            }}
          >
            {opModel.active ? 'ON' : 'OFF'}
          </button>
        </div>
      </div>

      {/* Active banner */}
      {opModel.active && (
        <div style={{
          padding: '8px 16px', background: 'rgba(59,130,246,0.12)',
          borderBottom: '1px solid rgba(59,130,246,0.3)',
          color: 'var(--accent)', fontSize: 12, fontWeight: 500, flexShrink: 0,
        }}>
          Operating Model is live — EBITDA overrides active
        </div>
      )}

      {/* Grid */}
      <div style={{ flex: 1, overflowX: 'auto', overflowY: 'auto' }}>
        <table className="op-model-grid">
          <thead>
            <tr>
              <th style={{ width: 160, textAlign: 'left', position: 'sticky', left: 0, background: 'var(--bg-surface)', zIndex: 2 }}>Metric</th>
              <th style={{ textAlign: 'right', color: 'var(--text-dim)', minWidth: 110 }}>Entry</th>
              {Array.from({ length: n }, (_, i) => (
                <th key={i} style={{ textAlign: 'right', minWidth: 110 }}>Year {i + 1}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map(row => {
              const isBold = (row as any).bold
              const rowHighlight = (row as any).highlight as 'ebitda' | 'fcf' | undefined

              return (
                <tr
                  key={row.key}
                  className={
                    rowHighlight === 'ebitda' ? 'op-model-ebitda-row'
                    : rowHighlight === 'fcf' ? 'op-model-fcf-row'
                    : ''
                  }
                >
                  {/* Row label — frozen */}
                  <td style={{
                    position: 'sticky', left: 0,
                    background: rowHighlight === 'ebitda' ? 'rgba(59,130,246,0.06)' : rowHighlight === 'fcf' ? 'rgba(34,197,94,0.06)' : 'var(--bg-surface)',
                    zIndex: 1, fontWeight: isBold ? 700 : 400,
                    color: rowHighlight === 'ebitda' ? 'var(--accent)' : rowHighlight === 'fcf' ? 'var(--green)' : 'var(--text-muted)',
                    fontSize: 12,
                    paddingLeft: 8,
                  }}>
                    {row.label}
                  </td>

                  {/* Entry column (read-only grey) */}
                  <td style={{ textAlign: 'right', color: 'var(--text-dim)', fontFamily: 'var(--font-mono)', fontSize: 12, padding: '5px 10px' }}>
                    {(row as any).getEntry ? (row as any).getEntry() : '—'}
                  </td>

                  {/* Year columns */}
                  {Array.from({ length: n }, (_, i) => {
                    const isEditable = row.isEditable && row.onEdit
                    const isOverridden = row.isOverridden ? row.isOverridden(i) : false
                    const val = row.getValue(i)
                    const disp = row.getDisplay(i)

                    if (isEditable) {
                      return (
                        <EditCell
                          key={i}
                          value={val}
                          display={disp}
                          onChange={v => row.onEdit!(i, v)}
                          isOverridden={isOverridden}
                          highlight={rowHighlight}
                        />
                      )
                    }
                    return (
                      <td key={i} style={{
                        textAlign: 'right',
                        fontFamily: 'var(--font-mono)',
                        fontSize: 12,
                        fontWeight: isBold ? 700 : 400,
                        color: rowHighlight === 'ebitda' ? 'var(--accent)' : rowHighlight === 'fcf' ? 'var(--green)' : 'var(--text)',
                        padding: '5px 10px',
                      }}>
                        {disp}
                      </td>
                    )
                  })}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
