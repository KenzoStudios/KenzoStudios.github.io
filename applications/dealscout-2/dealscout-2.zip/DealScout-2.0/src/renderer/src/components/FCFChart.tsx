import { useEffect, useRef } from 'react'
import { YearlySnapshot } from '../engine/lbo'

interface FCFChartProps {
  yearlyData: YearlySnapshot[]
  entryEquity: number
}

export default function FCFChart({ yearlyData }: FCFChartProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef    = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const container = containerRef.current
    const canvas    = canvasRef.current
    if (!container || !canvas || yearlyData.length === 0) return

    const draw = () => {
      const dpr  = window.devicePixelRatio || 1
      const logW = container.offsetWidth
      const logH = 290

      canvas.width  = logW * dpr
      canvas.height = logH * dpr
      canvas.style.width  = `${logW}px`
      canvas.style.height = `${logH}px`

      const ctx = canvas.getContext('2d')!
      ctx.scale(dpr, dpr)
      ctx.clearRect(0, 0, logW, logH)

      const PAD_L = 62, PAD_R = 52, PAD_T = 40, PAD_B = 34
      const plotW = logW - PAD_L - PAD_R
      const plotH = logH - PAD_T - PAD_B

      const n    = yearlyData.length
      const gap  = plotW / n
      const barW = gap * 0.50

      // ── Data ──────────────────────────────────────────────────────────────
      const fcfs       = yearlyData.map(d => d.leveredFCF)
      const dscrValues = yearlyData.map(d => d.dscr)

      const barMax   = Math.max(0, ...fcfs) * 1.25
      const barMin   = Math.min(0, ...fcfs) * 1.1
      const barRange = barMax - barMin || 1

      const dscrPeak = Math.max(2.5, ...dscrValues)
      const dscrMax  = Math.min(10, dscrPeak * 1.18)

      function barY(v: number)  { return PAD_T + plotH - ((v - barMin) / barRange) * plotH }
      function dscrY(v: number) { return PAD_T + plotH - (Math.min(v, dscrMax) / dscrMax) * plotH }
      function barX(i: number)  { return PAD_L + i * gap + gap / 2 }

      const zeroY = barY(0)

      // ── Subtle horizontal grid ─────────────────────────────────────────────
      const GRID_COUNT = 4
      ctx.strokeStyle = 'rgba(255,255,255,0.04)'
      ctx.lineWidth = 1
      for (let t = 0; t <= GRID_COUNT; t++) {
        const v = barMin + (t / GRID_COUNT) * barRange
        const y = barY(v)
        ctx.beginPath()
        ctx.moveTo(PAD_L, y)
        ctx.lineTo(PAD_L + plotW, y)
        ctx.stroke()
      }

      // ── DSCR danger zone (below 1.0x coverage) ────────────────────────────
      const threshold1x = dscrY(1.0)
      if (threshold1x < PAD_T + plotH) {
        const grad = ctx.createLinearGradient(0, threshold1x, 0, PAD_T + plotH)
        grad.addColorStop(0, 'rgba(201,69,69,0.06)')
        grad.addColorStop(1, 'rgba(201,69,69,0.00)')
        ctx.fillStyle = grad
        ctx.fillRect(PAD_L, threshold1x, plotW, PAD_T + plotH - threshold1x)
      }

      // ── Zero line ──────────────────────────────────────────────────────────
      ctx.strokeStyle = 'rgba(255,255,255,0.12)'
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.moveTo(PAD_L, zeroY)
      ctx.lineTo(PAD_L + plotW, zeroY)
      ctx.stroke()

      // ── FCF bars ───────────────────────────────────────────────────────────
      for (let i = 0; i < n; i++) {
        const v    = fcfs[i]
        const x    = barX(i) - barW / 2
        const topY = v >= 0 ? barY(v) : zeroY
        const h    = Math.abs(barY(v) - zeroY)
        const pos  = v >= 0

        if (h < 1) continue

        // Body fill with subtle gradient
        const barGrad = ctx.createLinearGradient(0, topY, 0, topY + h)
        if (pos) {
          barGrad.addColorStop(0, 'rgba(61,170,106,0.30)')
          barGrad.addColorStop(1, 'rgba(61,170,106,0.10)')
        } else {
          barGrad.addColorStop(0, 'rgba(201,69,69,0.10)')
          barGrad.addColorStop(1, 'rgba(201,69,69,0.30)')
        }
        ctx.fillStyle = barGrad
        ctx.fillRect(x, topY, barW, h)

        // Side borders (U-shape, open at zero line)
        ctx.strokeStyle = pos ? 'rgba(61,170,106,0.55)' : 'rgba(201,69,69,0.55)'
        ctx.lineWidth = 1
        ctx.beginPath()
        if (pos) {
          ctx.moveTo(x, topY + h)
          ctx.lineTo(x, topY)
          ctx.lineTo(x + barW, topY)
          ctx.lineTo(x + barW, topY + h)
        } else {
          ctx.moveTo(x, topY)
          ctx.lineTo(x, topY + h)
          ctx.lineTo(x + barW, topY + h)
          ctx.lineTo(x + barW, topY)
        }
        ctx.stroke()

        // Top cap stripe
        const stripeH = Math.min(3, h)
        ctx.fillStyle = pos ? '#3daa6a' : '#c94545'
        ctx.globalAlpha = 0.90
        ctx.fillRect(x, pos ? topY : topY + h - stripeH, barW, stripeH)
        ctx.globalAlpha = 1.0
      }

      // ── DSCR 1.0× reference line ──────────────────────────────────────────

      // ── DSCR 1.0× reference line ──────────────────────────────────────────
      // (FCF value labels drawn after DSCR so they always win z-order)
      ctx.strokeStyle = 'rgba(200,155,60,0.22)'
      ctx.lineWidth   = 1
      ctx.setLineDash([3, 5])
      ctx.beginPath()
      ctx.moveTo(PAD_L, threshold1x)
      ctx.lineTo(PAD_L + plotW, threshold1x)
      ctx.stroke()
      ctx.setLineDash([])
      // "1.0×" anchor label
      ctx.fillStyle    = 'rgba(200,155,60,0.40)'
      ctx.font         = '9px -apple-system, BlinkMacSystemFont, sans-serif'
      ctx.textAlign    = 'left'
      ctx.textBaseline = 'middle'
      ctx.fillText('1.0×', PAD_L + plotW + 6, threshold1x)

      // ── DSCR line ──────────────────────────────────────────────────────────
      ctx.strokeStyle = 'rgba(200,155,60,0.80)'
      ctx.lineWidth   = 1.5
      ctx.lineJoin    = 'round'
      ctx.setLineDash([5, 4])
      ctx.beginPath()
      for (let i = 0; i < n; i++) {
        const x = barX(i)
        const y = dscrY(dscrValues[i])
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)
      }
      ctx.stroke()
      ctx.setLineDash([])

      // DSCR dots + inline labels (labels sit BELOW the dot, away from bar-top labels)
      for (let i = 0; i < n; i++) {
        const x = barX(i)
        const y = dscrY(dscrValues[i])
        ctx.beginPath()
        ctx.arc(x, y, 3, 0, Math.PI * 2)
        ctx.fillStyle = '#c89b3c'
        ctx.fill()
        ctx.fillStyle    = 'rgba(200,155,60,0.65)'
        ctx.font         = `500 10px 'SF Mono','Menlo',monospace`
        ctx.textAlign    = 'center'
        ctx.textBaseline = 'top'
        ctx.fillText(dscrValues[i].toFixed(1) + '×', x, y + 7)
      }

      // ── FCF value labels — drawn last so they always sit above everything ─
      for (let i = 0; i < n; i++) {
        const v    = fcfs[i]
        const pos  = v >= 0
        const topY = pos ? barY(v) : zeroY
        const h    = Math.abs(barY(v) - zeroY)
        if (h < 1) continue
        // Tiny knockout behind label so it reads cleanly over the DSCR line
        const label   = '$' + v.toFixed(1) + 'M'
        const fSize   = Math.max(10, Math.min(12, gap * 0.22))
        ctx.font      = `600 ${fSize}px 'SF Mono','Menlo',monospace`
        ctx.textAlign = 'center'
        const lw = ctx.measureText(label).width
        const lx = barX(i) - lw / 2 - 4
        const ly = pos ? topY - fSize - 11 : topY + h + 4
        const lh = fSize + 6
        ctx.fillStyle = 'rgba(13,17,23,0.72)'
        ctx.fillRect(lx, ly, lw + 8, lh)

        ctx.fillStyle    = pos ? '#3daa6a' : '#c94545'
        ctx.textBaseline = pos ? 'bottom' : 'top'
        ctx.fillText(label, barX(i), pos ? topY - 7 : topY + h + 7)
      }

      // ── X axis ────────────────────────────────────────────────────────────
      ctx.fillStyle    = '#5a6a80'
      ctx.font         = '11px -apple-system, BlinkMacSystemFont, sans-serif'
      ctx.textAlign    = 'center'
      ctx.textBaseline = 'top'
      for (let i = 0; i < n; i++) {
        ctx.fillText(`Year ${yearlyData[i].year}`, barX(i), PAD_T + plotH + 9)
      }

      // ── Left Y axis ───────────────────────────────────────────────────────
      ctx.fillStyle    = '#5a6a80'
      ctx.font         = '10px -apple-system, BlinkMacSystemFont, sans-serif'
      ctx.textAlign    = 'right'
      ctx.textBaseline = 'middle'
      for (let t = 0; t <= GRID_COUNT; t++) {
        const v = barMin + (t / GRID_COUNT) * barRange
        if (Math.abs(v) < 0.01 && barMin >= 0) continue   // skip $0M when all positive
        ctx.fillText('$' + v.toFixed(0) + 'M', PAD_L - 8, barY(v))
      }

      // Y axis label
      ctx.save()
      ctx.translate(11, PAD_T + plotH / 2)
      ctx.rotate(-Math.PI / 2)
      ctx.textAlign    = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillStyle    = '#2d3d50'
      ctx.font         = '10px -apple-system, BlinkMacSystemFont, sans-serif'
      ctx.fillText('Levered FCF ($M)', 0, 0)
      ctx.restore()

      // ── DSCR right axis label ─────────────────────────────────────────────
      ctx.save()
      ctx.translate(logW - 10, PAD_T + plotH / 2)
      ctx.rotate(Math.PI / 2)
      ctx.textAlign    = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillStyle    = 'rgba(200,155,60,0.35)'
      ctx.font         = '10px -apple-system, BlinkMacSystemFont, sans-serif'
      ctx.fillText('DSCR (×)', 0, 0)
      ctx.restore()

      // ── Legend ─────────────────────────────────────────────────────────────
      const legendItems: { label: string; type: 'bar' | 'dashed' }[] = [
        { label: 'Levered FCF', type: 'bar' },
        { label: 'DSCR',        type: 'dashed' },
      ]
      let lx = PAD_L
      const ly = PAD_T - 24
      ctx.font = '10px -apple-system, BlinkMacSystemFont, sans-serif'
      for (const item of legendItems) {
        if (item.type === 'dashed') {
          ctx.setLineDash([4, 3])
          ctx.strokeStyle = 'rgba(200,155,60,0.80)'
          ctx.lineWidth   = 1.5
          ctx.beginPath()
          ctx.moveTo(lx, ly); ctx.lineTo(lx + 16, ly)
          ctx.stroke()
          ctx.setLineDash([])
          ctx.beginPath()
          ctx.arc(lx + 8, ly, 2.5, 0, Math.PI * 2)
          ctx.fillStyle = '#c89b3c'
          ctx.fill()
        } else {
          ctx.fillStyle   = 'rgba(61,170,106,0.22)'
          ctx.strokeStyle = 'rgba(61,170,106,0.55)'
          ctx.lineWidth   = 1
          ctx.fillRect(lx, ly - 5, 16, 10)
          ctx.strokeRect(lx, ly - 5, 16, 10)
          ctx.fillStyle = '#3daa6a'
          ctx.fillRect(lx, ly - 5, 16, 3)
        }
        ctx.fillStyle    = '#5a6a80'
        ctx.textAlign    = 'left'
        ctx.textBaseline = 'middle'
        ctx.fillText(item.label, lx + 20, ly)
        lx += ctx.measureText(item.label).width + 44
      }
    }

    draw()
    const ro = new ResizeObserver(draw)
    ro.observe(container)
    return () => ro.disconnect()
  }, [yearlyData])

  return (
    <div ref={containerRef} style={{ width: '100%' }}>
      <canvas ref={canvasRef} style={{ display: 'block' }} />
    </div>
  )
}
