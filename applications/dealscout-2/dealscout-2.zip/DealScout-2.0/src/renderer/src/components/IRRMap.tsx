import { useState, useMemo, useRef, useEffect, useCallback } from 'react'
import { LBOInputs, OperatingModelState, runLBO } from '../engine/lbo'
import { solveInverseLBO } from '../engine/solver'
import InputField from './InputField'
import KPICard from './KPICard'
import Heatmap from './Heatmap'
import SensitivityTable from './SensitivityTable'

interface Props {
  inputs: LBOInputs
  setInputs: React.Dispatch<React.SetStateAction<LBOInputs>>
  opModel: OperatingModelState
}

function fmt(n: number, decimals = 1): string {
  return n.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })
}
function fmtPct(n: number): string { return fmt(n * 100, 1) + '%' }
function fmtMx(n: number): string  { return fmt(n, 1) + 'x' }
function fmtM(n: number): string   { return '$' + fmt(n, 1) + 'M' }

// ─── Driver definitions ────────────────────────────────────────────────────────

export type DriverKey =
  | 'revenueGrowthPct'
  | 'ebitdaMarginPct'
  | 'entryRevenue'
  | 'sgaMarginPct'
  | 'capexPctOfRevenue'
  | 'daPctOfEbitda'
  | 'wcChangePctOfRevenue'
  | 'exitMultiple'
  | 'interestRate'
  | 'holdPeriod'

interface Driver {
  key: DriverKey
  label: string
  shortLabel: string
  unit: 'pct' | 'x' | '$M' | 'yrs'
  step: number          // range step
  decimals: number
  getValue: (inputs: LBOInputs, opModel: OperatingModelState) => number
  format: (v: number) => string
}

const DRIVERS: Driver[] = [
  {
    key: 'revenueGrowthPct', label: 'Revenue Growth Rate', shortLabel: 'Rev Growth', unit: 'pct', step: 0.01, decimals: 0,
    getValue: (_, om) => om.yearData[0]?.revenueGrowthPct ?? 0.05,
    format: v => (v * 100).toFixed(0) + '%',
  },
  {
    key: 'ebitdaMarginPct', label: 'EBITDA Margin', shortLabel: 'EBITDA Margin', unit: 'pct', step: 0.01, decimals: 0,
    getValue: (_, om) => om.yearData[0]?.ebitdaMarginPct ?? 0.25,
    format: v => (v * 100).toFixed(0) + '%',
  },
  {
    key: 'entryRevenue', label: 'Revenue in Year 1', shortLabel: 'Entry Revenue', unit: '$M', step: 0,
    decimals: 0,
    getValue: (_, om) => om.entryRevenue,
    format: v => '$' + v.toFixed(0) + 'M',
  },
  {
    key: 'sgaMarginPct', label: 'SG&A as % of Revenue', shortLabel: 'SG&A %', unit: 'pct', step: 0.01, decimals: 0,
    getValue: (_, om) => om.yearData[0]?.sgaMarginPct ?? 0.20,
    format: v => (v * 100).toFixed(0) + '%',
  },
  {
    key: 'capexPctOfRevenue', label: 'Capex as % of Revenue', shortLabel: 'Capex %', unit: 'pct', step: 0.01, decimals: 0,
    getValue: (_, om) => om.yearData[0]?.capexPctOfRevenue ?? 0.05,
    format: v => (v * 100).toFixed(0) + '%',
  },
  {
    key: 'daPctOfEbitda', label: 'D&A as % of EBITDA', shortLabel: 'D&A %', unit: 'pct', step: 0.01, decimals: 0,
    getValue: (_, om) => om.yearData[0]?.daPctOfEbitda ?? 0.10,
    format: v => (v * 100).toFixed(0) + '%',
  },
  {
    key: 'wcChangePctOfRevenue', label: 'Working Capital as % of Revenue', shortLabel: 'WC %', unit: 'pct', step: 0.005, decimals: 1,
    getValue: (_, om) => om.yearData[0]?.wcChangePctOfRevenue ?? 0.02,
    format: v => (v * 100).toFixed(1) + '%',
  },
  {
    key: 'exitMultiple', label: 'Exit EV / EBITDA Multiple', shortLabel: 'Exit Multiple', unit: 'x', step: 0.5, decimals: 1,
    getValue: (inp) => inp.exitMultiple,
    format: v => v.toFixed(1) + 'x',
  },
  {
    key: 'interestRate', label: 'Interest Rate', shortLabel: 'Interest Rate', unit: 'pct', step: 0.005, decimals: 1,
    getValue: (inp) => inp.interestRate,
    format: v => (v * 100).toFixed(1) + '%',
  },
  {
    key: 'holdPeriod', label: 'Hold Period', shortLabel: 'Hold Period', unit: 'yrs', step: 1, decimals: 0,
    getValue: (inp) => inp.holdPeriod,
    format: v => v.toFixed(0) + ' yrs',
  },
]

function driverByKey(key: DriverKey): Driver {
  return DRIVERS.find(d => d.key === key)!
}

// ─── Range generation ──────────────────────────────────────────────────────────

function makeRange(driver: Driver, currentVal: number): number[] {
  if (driver.key === 'holdPeriod') {
    return [1, 2, 3, 4, 5, 6, 7]
  }
  if (driver.key === 'entryRevenue') {
    // 10% increments
    const step = Math.max(1, currentVal * 0.10)
    return Array.from({ length: 9 }, (_, i) => Math.max(0, currentVal + (i - 4) * step))
  }
  const step = driver.step
  return Array.from({ length: 9 }, (_, i) => Math.max(0, currentVal + (i - 4) * step))
}

// ─── Override application ──────────────────────────────────────────────────────

function applyDriverOverride(
  baseInputs: LBOInputs,
  baseOpModel: OperatingModelState,
  key: DriverKey,
  value: number
): { inputs: LBOInputs; opModel: OperatingModelState } {
  if (key === 'exitMultiple') return { inputs: { ...baseInputs, exitMultiple: value }, opModel: baseOpModel }
  if (key === 'interestRate') return { inputs: { ...baseInputs, interestRate: value }, opModel: baseOpModel }
  if (key === 'holdPeriod') {
    const hp = Math.round(value)
    return { inputs: { ...baseInputs, holdPeriod: hp, ebitdaOverrides: undefined }, opModel: baseOpModel }
  }
  if (key === 'entryRevenue') {
    return { inputs: baseInputs, opModel: { ...baseOpModel, entryRevenue: value } }
  }
  // OpModel year-driver: apply uniformly to all years
  const modYearData = baseOpModel.yearData.map(yd => ({ ...yd, [key]: value }))
  return { inputs: baseInputs, opModel: { ...baseOpModel, yearData: modYearData } }
}

function computeEbitdaOverrides(opModel: OperatingModelState, holdPeriod: number): number[] {
  let prevRevenue = opModel.entryRevenue
  const result: number[] = []
  const n = Math.min(holdPeriod, opModel.yearData.length)
  for (let i = 0; i < n; i++) {
    const yd = opModel.yearData[i]
    const revenue = prevRevenue * (1 + yd.revenueGrowthPct)
    const ebitda  = revenue * yd.ebitdaMarginPct
    result.push(ebitda)
    prevRevenue = revenue
  }
  // If holdPeriod > yearData.length, repeat last year pattern
  for (let i = n; i < holdPeriod; i++) {
    const yd = opModel.yearData[opModel.yearData.length - 1]
    const revenue = prevRevenue * (1 + yd.revenueGrowthPct)
    const ebitda  = revenue * yd.ebitdaMarginPct
    result.push(ebitda)
    prevRevenue = revenue
  }
  return result
}

const OP_DRIVERS: DriverKey[] = [
  'revenueGrowthPct', 'ebitdaMarginPct', 'entryRevenue',
  'sgaMarginPct', 'capexPctOfRevenue', 'daPctOfEbitda', 'wcChangePctOfRevenue',
]

function runIRRWithDrivers(
  baseInputs: LBOInputs,
  baseOpModel: OperatingModelState,
  overrides: Partial<Record<DriverKey, number>>
): { irr: number; moic: number; valid: boolean } {
  let inp = { ...baseInputs }
  let om  = { ...baseOpModel, yearData: [...baseOpModel.yearData] }

  for (const [key, value] of Object.entries(overrides) as [DriverKey, number][]) {
    const applied = applyDriverOverride(inp, om, key, value)
    inp = applied.inputs
    om  = applied.opModel
  }

  // Determine if we need ebitdaOverrides (any opModel driver was overridden)
  const needsOpModel = Object.keys(overrides).some(k => OP_DRIVERS.includes(k as DriverKey))
  if (needsOpModel) {
    const ebitdaOverrides = computeEbitdaOverrides(om, inp.holdPeriod)
    const entryEbitda = ebitdaOverrides[0] ?? baseOpModel.entryEbitda

    // Sync D&A and Capex from the (possibly overridden) OpModel into LBO inputs.
    // The LBO engine uses inputs.daPercent (% of EBITDA) and inputs.capexPercent (% of EBITDA),
    // so changes to the OpModel's daPctOfEbitda / capexPctOfRevenue must flow through here.
    // Use year-1 parameters as representative for the whole hold (simple approximation).
    const yd0 = om.yearData[0]
    const daPercent = yd0 ? yd0.daPctOfEbitda : inp.daPercent
    // capexPctOfRevenue → capexPercent (% of EBITDA): divide by ebitdaMarginPct
    const capexPercent = (yd0 && yd0.ebitdaMarginPct > 0)
      ? yd0.capexPctOfRevenue / yd0.ebitdaMarginPct
      : inp.capexPercent

    inp = { ...inp, ebitda: entryEbitda, ebitdaOverrides, daPercent, capexPercent }
  }

  const result = runLBO(inp)
  return { irr: result.irr, moic: result.moic, valid: result.valid }
}

// ─── Tornado chart (canvas) ────────────────────────────────────────────────────

interface TornadoProps {
  impacts: { driver: Driver; low: number; high: number; base: number }[]
  baseIRR: number
}

function TornadoChart({ impacts, baseIRR }: TornadoProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef    = useRef<HTMLCanvasElement>(null)

  const draw = useCallback(() => {
    const container = containerRef.current
    const canvas    = canvasRef.current
    if (!container || !canvas || impacts.length === 0) return

    const dpr  = window.devicePixelRatio || 1
    const logW = container.offsetWidth
    const n    = impacts.length
    const ROW_H = 28
    const PAD_L = 120
    const PAD_R = 16
    const PAD_T = 24
    const PAD_B = 16
    const logH = PAD_T + n * ROW_H + PAD_B

    container.style.height = `${logH}px`
    canvas.width  = logW * dpr
    canvas.height = logH * dpr
    canvas.style.width  = `${logW}px`
    canvas.style.height = `${logH}px`

    const ctx = canvas.getContext('2d')!
    ctx.scale(dpr, dpr)
    ctx.clearRect(0, 0, logW, logH)

    const plotW = logW - PAD_L - PAD_R

    // Compute max absolute impact for scale
    const maxAbs = Math.max(0.01, ...impacts.map(d => Math.max(Math.abs(d.high - d.base), Math.abs(d.low - d.base))))
    const scale  = (plotW / 2) / maxAbs

    // Center axis at mid
    const midX = PAD_L + plotW / 2

    // Axis label
    ctx.font         = '10px -apple-system, BlinkMacSystemFont, sans-serif'
    ctx.textAlign    = 'center'
    ctx.textBaseline = 'top'
    ctx.fillStyle    = 'rgba(255,255,255,0.22)'
    ctx.fillText(`Base IRR: ${(baseIRR * 100).toFixed(1)}%`, midX, 6)

    // Grid lines
    ctx.strokeStyle = 'rgba(255,255,255,0.05)'
    ctx.lineWidth   = 1
    for (let pp = 5; pp <= maxAbs * 100 + 4; pp += 5) {
      for (const sign of [-1, 1]) {
        const x = midX + sign * (pp / 100) * scale
        if (x < PAD_L || x > PAD_L + plotW) continue
        ctx.beginPath(); ctx.moveTo(x, PAD_T); ctx.lineTo(x, PAD_T + n * ROW_H); ctx.stroke()
      }
    }

    // Centre axis
    ctx.strokeStyle = 'rgba(255,255,255,0.18)'
    ctx.lineWidth   = 1
    ctx.beginPath(); ctx.moveTo(midX, PAD_T); ctx.lineTo(midX, PAD_T + n * ROW_H); ctx.stroke()

    // Bars
    for (let i = 0; i < n; i++) {
      const { driver, low, high, base } = impacts[i]
      const barY   = PAD_T + i * ROW_H
      const barH   = ROW_H * 0.48
      const centY  = barY + ROW_H / 2

      // Positive bar (high side)
      const highDelta = high - base
      const lowDelta  = base - low
      const posLen    = highDelta * scale
      const negLen    = lowDelta * scale

      // Green bar (high > base)
      if (posLen > 0.5) {
        ctx.fillStyle = 'rgba(61,170,106,0.75)'
        ctx.beginPath()
        ctx.roundRect(midX, centY - barH / 2, posLen, barH, 2)
        ctx.fill()
        // Label
        ctx.font         = '500 10px -apple-system, BlinkMacSystemFont, sans-serif'
        ctx.textAlign    = 'left'
        ctx.textBaseline = 'middle'
        ctx.fillStyle    = 'rgba(61,170,106,0.85)'
        ctx.fillText('+' + (highDelta * 100).toFixed(1) + 'pp', midX + posLen + 3, centY)
      }
      // Red bar (base > low)
      if (negLen > 0.5) {
        ctx.fillStyle = 'rgba(201,69,69,0.75)'
        ctx.beginPath()
        ctx.roundRect(midX - negLen, centY - barH / 2, negLen, barH, 2)
        ctx.fill()
        ctx.font         = '500 10px -apple-system, BlinkMacSystemFont, sans-serif'
        ctx.textAlign    = 'right'
        ctx.textBaseline = 'middle'
        ctx.fillStyle    = 'rgba(201,69,69,0.85)'
        ctx.fillText((lowDelta * 100).toFixed(1) + 'pp', midX - negLen - 3, centY)
      }

      // Driver label
      ctx.font         = '11px -apple-system, BlinkMacSystemFont, sans-serif'
      ctx.textAlign    = 'right'
      ctx.textBaseline = 'middle'
      ctx.fillStyle    = 'rgba(255,255,255,0.70)'
      ctx.fillText(driver.shortLabel, PAD_L - 8, centY)

      // Row separator
      if (i < n - 1) {
        ctx.strokeStyle = 'rgba(255,255,255,0.04)'
        ctx.lineWidth   = 1
        ctx.beginPath(); ctx.moveTo(0, barY + ROW_H); ctx.lineTo(logW, barY + ROW_H); ctx.stroke()
      }
    }
  }, [impacts, baseIRR])

  useEffect(() => {
    draw()
    const container = containerRef.current
    if (!container) return
    const ro = new ResizeObserver(draw)
    ro.observe(container)
    return () => ro.disconnect()
  }, [draw])

  return (
    <div ref={containerRef} style={{ position: 'relative', width: '100%' }}>
      <canvas ref={canvasRef} style={{ display: 'block' }} />
    </div>
  )
}

// ─── Edit Range Popover ────────────────────────────────────────────────────────

interface EditRangePopoverProps {
  driver: Driver
  range: number[]
  onChangeRange: (r: number[]) => void
  onClose: () => void
}

function EditRangePopover({ driver, range, onChangeRange, onClose }: EditRangePopoverProps) {
  const [draft, setDraft] = useState(range.map(v => driver.format(v)).join(', '))

  function tryApply() {
    const parts = draft.split(',').map(s => {
      const clean = s.trim().replace(/[^0-9.\-]/g, '')
      const n = parseFloat(clean)
      if (!isFinite(n)) return null
      // Convert back: if pct, divide by 100
      if (driver.unit === 'pct') return n / 100
      return n
    }).filter(v => v !== null) as number[]
    if (parts.length >= 2) onChangeRange(parts)
    onClose()
  }

  return (
    <div className="edit-range-popover" onMouseDown={e => e.stopPropagation()}>
      <div className="edit-range-title">Edit Range — {driver.label}</div>
      <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 6 }}>
        Comma-separated values, e.g. {driver.format(range[0])}, {driver.format(range[Math.floor(range.length / 2)])}, {driver.format(range[range.length - 1])}
      </div>
      <textarea
        className="edit-range-textarea"
        value={draft}
        onChange={e => setDraft(e.target.value)}
        rows={3}
        autoFocus
      />
      <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end', marginTop: 6 }}>
        <button className="edit-range-btn" onClick={onClose}>Cancel</button>
        <button className="edit-range-btn edit-range-btn-apply" onClick={tryApply}>Apply</button>
      </div>
    </div>
  )
}

// ─── Main component ────────────────────────────────────────────────────────────

export default function IRRMap({ inputs, setInputs, opModel }: Props) {
  type Mode = 'screen' | 'operating'
  const [mode, setMode]         = useState<Mode>('screen')
  const [targetIRR, setTargetIRR] = useState(0.20)

  // Operating Mode state
  const [xDriverKey, setXDriverKey] = useState<DriverKey>('exitMultiple')
  const [yDriverKey, setYDriverKey] = useState<DriverKey>('revenueGrowthPct')

  const xDriver = driverByKey(xDriverKey)
  const yDriver = driverByKey(yDriverKey)

  const xCurrentVal = useMemo(() => xDriver.getValue(inputs, opModel), [xDriver, inputs, opModel])
  const yCurrentVal = useMemo(() => yDriver.getValue(inputs, opModel), [yDriver, inputs, opModel])

  const [xRange, setXRange] = useState<number[]>(() => makeRange(xDriver, xCurrentVal))
  const [yRange, setYRange] = useState<number[]>(() => makeRange(yDriver, yCurrentVal))
  const [showEditX, setShowEditX] = useState(false)
  const [showEditY, setShowEditY] = useState(false)

  // Recompute ranges when driver changes
  function changeXDriver(key: DriverKey) {
    if (key === yDriverKey) setYDriverKey(xDriverKey)
    const d = driverByKey(key)
    const cv = d.getValue(inputs, opModel)
    setXDriverKey(key)
    setXRange(makeRange(d, cv))
    setShowEditX(false)
  }
  function changeYDriver(key: DriverKey) {
    if (key === xDriverKey) setXDriverKey(yDriverKey)
    const d = driverByKey(key)
    const cv = d.getValue(inputs, opModel)
    setYDriverKey(key)
    setYRange(makeRange(d, cv))
    setShowEditY(false)
  }

  function set<K extends keyof LBOInputs>(key: K) {
    return (val: number) => setInputs(prev => ({ ...prev, [key]: val }))
  }

  const debtEvPct   = inputs.debtEbitda / inputs.entryMultiple
  const setDebtByEV = (pct: number) => setInputs(prev => ({ ...prev, debtEbitda: pct * prev.entryMultiple }))

  // Screen mode result
  const screenResult = useMemo(() => solveInverseLBO({ targetIRR, ...inputs }), [targetIRR, inputs])

  const irrHighlight     = screenResult.dealWorks ? 'green' : 'red'
  const verdictHighlight = screenResult.dealWorks ? 'green' : 'red'

  // Operating Mode grid
  const opModeGrid = useMemo(() => {
    if (mode !== 'operating') return null
    const xVals = xRange
    const yVals = yRange

    // Base IRR for current assumptions in operating mode
    const baseResult = runIRRWithDrivers(inputs, opModel, {})
    const baseIRR = baseResult.irr

    const grid = yVals.map(yVal =>
      xVals.map(xVal => {
        const { irr, valid } = runIRRWithDrivers(inputs, opModel, { [xDriverKey]: xVal, [yDriverKey]: yVal })
        return { entryMultiple: xVal, growthRate: yVal, irr, valid }
      })
    )
    return { grid, xVals, yVals, baseIRR }
  }, [mode, inputs, opModel, xDriverKey, yDriverKey, xRange, yRange])

  // Tornado chart impacts — all drivers except X and Y
  const tornadoData = useMemo(() => {
    if (mode !== 'operating') return []
    const baseResult = runIRRWithDrivers(inputs, opModel, {})
    if (!baseResult.valid) return []
    const base = baseResult.irr

    return DRIVERS
      .filter(d => d.key !== xDriverKey && d.key !== yDriverKey)
      .map(d => {
        const cv   = d.getValue(inputs, opModel)
        const step = d.key === 'holdPeriod' ? 1 : d.key === 'entryRevenue' ? Math.max(1, cv * 0.10) : d.step
        const hi   = d.key === 'holdPeriod' ? Math.min(7, cv + 2) : cv + 2 * step
        const lo   = d.key === 'holdPeriod' ? Math.max(1, cv - 2) : Math.max(0, cv - 2 * step)
        const highIRR = runIRRWithDrivers(inputs, opModel, { [d.key]: hi }).irr
        const lowIRR  = runIRRWithDrivers(inputs, opModel, { [d.key]: lo }).irr
        return { driver: d, low: lowIRR, high: highIRR, base }
      })
      .filter(d => isFinite(d.low) && isFinite(d.high))
      .sort((a, b) => {
        const aSpan = Math.max(Math.abs(a.high - a.base), Math.abs(a.low - a.base))
        const bSpan = Math.max(Math.abs(b.high - b.base), Math.abs(b.low - b.base))
        return bSpan - aSpan
      })
  }, [mode, inputs, opModel, xDriverKey, yDriverKey])

  // Find current assumption cell in op mode grid
  const currentXIdx = useMemo(() => {
    if (!opModeGrid) return -1
    const cv = xCurrentVal
    let best = 0
    let bestDist = Infinity
    xRange.forEach((v, i) => { const d = Math.abs(v - cv); if (d < bestDist) { bestDist = d; best = i } })
    return best
  }, [opModeGrid, xCurrentVal, xRange])

  const currentYIdx = useMemo(() => {
    if (!opModeGrid) return -1
    const cv = yCurrentVal
    let best = 0
    let bestDist = Infinity
    yRange.forEach((v, i) => { const d = Math.abs(v - cv); if (d < bestDist) { bestDist = d; best = i } })
    return best
  }, [opModeGrid, yCurrentVal, yRange])

  const opModelActive = opModel.active

  return (
    <div className="tab-layout">
      <aside className="input-panel">
        <div className="panel-section">
          <div className="panel-section-title">Target</div>
          <InputField label="Target IRR" value={targetIRR} onChange={setTargetIRR} suffix="%" asPercent step={1} min={0.05} max={0.60} decimals={0}
            tip="Sets the return threshold for the entire map. Cells above this IRR appear green; below appear red. Also drives the max entry multiple and required growth calculations." />
        </div>

        {mode === 'screen' && (
          <>
            <div className="panel-section">
              <div className="panel-section-title">Deal Assumptions</div>
              <InputField label="Current EBITDA"    value={inputs.ebitda}        onChange={set('ebitda')}        suffix="$M"  step={10}   decimals={0} min={1}
                tip="Entry EBITDA — sets the scale of the deal. Changing this shifts the entire map." />
              <InputField label="Entry EV / EBITDA" value={inputs.entryMultiple} onChange={set('entryMultiple')} suffix="x"   step={0.25} min={1} max={20}
                tip="Current entry multiple — shown as the dot on the heatmap. The map explores how IRR changes as this varies across the X axis." />
              <InputField label="EBITDA Growth"     value={inputs.growthRate}    onChange={set('growthRate')}    suffix="%"   step={0.5}  min={-0.20} max={0.50} asPercent
                tip="Current EBITDA growth assumption — shown as the dot on the Y axis. The map explores the full growth range around this." />
              <InputField label="Hold Period"       value={inputs.holdPeriod}   onChange={set('holdPeriod')}   suffix="yrs" step={1}    decimals={0} min={1} max={15}
                tip="Years from acquisition to exit. Affects how much compounding and deleveraging occurs before the IRR is measured." />
              <InputField label="Exit Multiple"     value={inputs.exitMultiple}  onChange={set('exitMultiple')}  suffix="x"   step={0.25} min={1} max={30}
                tip="Assumed sale multiple at exit. Equal to entry = no multiple change. Above entry = expansion. Held constant across the heatmap unless selected as an axis." />
            </div>

            <div className="panel-section">
              <div className="panel-section-title">Capital Structure</div>
              <InputField label="Debt / EBITDA"   value={inputs.debtEbitda}    onChange={set('debtEbitda')}    suffix="x"       step={0.25} min={0} max={15}
                tip="Total leverage at entry as a multiple of EBITDA. Held fixed across the heatmap — affects equity invested and interest burden each year." />
              <InputField label="Debt / EV"       value={debtEvPct}            onChange={setDebtByEV}          suffix="% of EV" asPercent step={1} min={0} max={0.98}
                tip="Alternative leverage view — debt as % of enterprise value. Bidirectionally linked to Debt/EBITDA via the entry multiple." />
              <InputField label="Interest Rate"   value={inputs.interestRate}  onChange={set('interestRate')}  suffix="%"       step={0.25} min={0} max={0.30} asPercent
                tip="All-in annual interest cost. Higher rates reduce FCF and slow deleveraging, compressing the green region of the map." />
              <InputField label="Annual Paydown"  value={inputs.annualPaydown} onChange={set('annualPaydown')} suffix="%"       step={1}    min={0} max={1}    asPercent decimals={0}
                tip="Mandatory annual principal amortisation as % of original debt. Excess free cash is swept on top of this." />
              <InputField label="Transaction Fees" value={inputs.fees}         onChange={set('fees')}          suffix="%"       step={0.25} min={0} max={0.10} asPercent
                tip="Close costs as % of enterprise value. Added to equity at entry — increases invested capital and reduces IRR for every cell in the map." />
            </div>
          </>
        )}

        {mode === 'operating' && (
          <div className="panel-section">
            <div className="panel-section-title">Axis Drivers</div>

            {!opModelActive && (
              <div className="op-mode-notice">
                Operating Model is off — using sidebar inputs as base case.
              </div>
            )}

            {/* X Axis */}
            <div className="axis-driver-row">
              <div className="axis-driver-axis-label">X axis</div>
              <div style={{ flex: 1 }}>
                <select
                  className="axis-driver-select"
                  value={xDriverKey}
                  onChange={e => changeXDriver(e.target.value as DriverKey)}
                >
                  {DRIVERS.map(d => (
                    <option key={d.key} value={d.key}>{d.label}</option>
                  ))}
                </select>
                <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
                  <div className="axis-range-preview">
                    {xRange[0] !== undefined ? xDriver.format(xRange[0]) : ''} → {xRange[xRange.length - 1] !== undefined ? xDriver.format(xRange[xRange.length - 1]) : ''}
                  </div>
                  <button className="edit-range-trigger" onClick={() => setShowEditX(v => !v)}>Edit</button>
                </div>
                {showEditX && (
                  <EditRangePopover
                    driver={xDriver}
                    range={xRange}
                    onChangeRange={r => { setXRange(r); setShowEditX(false) }}
                    onClose={() => setShowEditX(false)}
                  />
                )}
              </div>
            </div>

            {/* Y Axis */}
            <div className="axis-driver-row">
              <div className="axis-driver-axis-label">Y axis</div>
              <div style={{ flex: 1 }}>
                <select
                  className="axis-driver-select"
                  value={yDriverKey}
                  onChange={e => changeYDriver(e.target.value as DriverKey)}
                >
                  {DRIVERS.map(d => (
                    <option key={d.key} value={d.key}>{d.label}</option>
                  ))}
                </select>
                <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
                  <div className="axis-range-preview">
                    {yRange[0] !== undefined ? yDriver.format(yRange[0]) : ''} → {yRange[yRange.length - 1] !== undefined ? yDriver.format(yRange[yRange.length - 1]) : ''}
                  </div>
                  <button className="edit-range-trigger" onClick={() => setShowEditY(v => !v)}>Edit</button>
                </div>
                {showEditY && (
                  <EditRangePopover
                    driver={yDriver}
                    range={yRange}
                    onChangeRange={r => { setYRange(r); setShowEditY(false) }}
                    onClose={() => setShowEditY(false)}
                  />
                )}
              </div>
            </div>
          </div>
        )}
      </aside>

      <main className="output-panel">
        {/* Mode toggle */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
          <div className="mode-toggle">
            <button
              className={`mode-toggle-btn${mode === 'screen' ? ' mode-toggle-active' : ''}`}
              onClick={() => setMode('screen')}
            >
              Screen Mode
            </button>
            <button
              className={`mode-toggle-btn${mode === 'operating' ? ' mode-toggle-active' : ''}`}
              onClick={() => setMode('operating')}
            >
              Operating Mode
            </button>
          </div>
          {mode === 'operating' && !opModelActive && (
            <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
              (Operating Model inactive — using base assumptions)
            </span>
          )}
        </div>

        {/* ── Screen Mode ─────────────────────────────────────────────────── */}
        {mode === 'screen' && (
          <>
            <div className="kpi-row">
              <KPICard label="Current IRR"       value={fmtPct(screenResult.currentIRR)} sub={`Target: ${fmtPct(targetIRR)}`} highlight={irrHighlight} large
                tip="IRR generated by the current combination of inputs. Coloured relative to your target — green means you're above it, red means you're below." />
              <KPICard label="Current MOIC"      value={screenResult.currentMOIC.toFixed(2) + 'x'} highlight={irrHighlight} large
                tip="Multiple of Invested Capital at the current inputs. Read alongside IRR — the same MOIC at a shorter hold period produces a higher IRR." />
              <KPICard label="Max Entry Multiple" value={screenResult.maxEntryMultiple !== null ? fmtMx(screenResult.maxEntryMultiple) : '—'} sub={screenResult.maxEntryEV !== null ? 'Max entry EV: ' + fmtM(screenResult.maxEntryEV) : undefined}
                tip="The highest price you could pay (as an EBITDA multiple) and still hit your target IRR, keeping all other assumptions fixed. Your bid ceiling." />
              <KPICard label="Required Growth"   value={screenResult.requiredGrowth !== null ? fmtPct(screenResult.requiredGrowth) : '—'} sub={`at ${fmtMx(inputs.entryMultiple)} entry`}
                tip="The minimum annual EBITDA growth needed to hit your target IRR at the current entry price. Compare to your base case to assess the margin of safety." />
              <KPICard label="Deal Verdict"      value={screenResult.dealWorks ? 'WORKS ✓' : 'DOES NOT WORK ✗'} highlight={verdictHighlight}
                tip="Whether the current assumptions clear your target IRR. If not, the interpretation below explains the gap and what would need to change." />
            </div>

            <div className="section-title" style={{ marginBottom: 8 }}>
              IRR Map — Entry Multiple × EBITDA Growth
              <span className="section-subtitle"> · dashed line = target IRR contour · dot = current assumptions</span>
            </div>
            <Heatmap
              grid={screenResult.grid}
              entryMultiples={screenResult.entryMultiples}
              growthRates={screenResult.growthRates}
              targetIRR={targetIRR}
              currentEntryMultiple={inputs.entryMultiple}
              currentGrowthRate={inputs.growthRate}
            />

            <div className="table-section">
              <div className="section-title" style={{ marginBottom: 8 }}>
                <span className="section-title-tag">Sensitivity Table — IRR by Entry × Exit Multiple</span>
                <span className="section-subtitle"> · current assumptions highlighted · color = vs. target IRR</span>
              </div>
              <SensitivityTable inputs={inputs} targetIRR={targetIRR} />
            </div>

            <div className={`interpretation-box ${screenResult.dealWorks ? 'interpretation-green' : 'interpretation-red'}`}>
              <div className="interpretation-icon">{screenResult.dealWorks ? '✓' : '✗'}</div>
              <div className="interpretation-text">{screenResult.verdict}</div>
            </div>
          </>
        )}

        {/* ── Operating Mode ───────────────────────────────────────────────── */}
        {mode === 'operating' && opModeGrid && (
          <>
            <div className="section-title" style={{ marginBottom: 8 }}>
              IRR Map — {xDriver.label} × {yDriver.label}
              <span className="section-subtitle"> · dashed line = target IRR contour · ring = current assumptions</span>
            </div>
            <Heatmap
              grid={opModeGrid.grid}
              entryMultiples={opModeGrid.xVals}
              growthRates={opModeGrid.yVals}
              targetIRR={targetIRR}
              currentEntryMultiple={opModeGrid.xVals[currentXIdx] ?? xCurrentVal}
              currentGrowthRate={opModeGrid.yVals[currentYIdx] ?? yCurrentVal}
              xFormatter={xDriver.format}
              yFormatter={yDriver.format}
              xAxisLabel={xDriver.label}
              yAxisLabel={yDriver.label}
              tooltipXLabel={xDriver.shortLabel}
              tooltipYLabel={yDriver.shortLabel}
            />

            <div className="table-section">
              <div className="section-title" style={{ marginBottom: 8 }}>
                <span className="section-title-tag">Driver Importance — IRR sensitivity to ±2 unit change per driver</span>
                <span className="section-subtitle"> · green = higher value improves IRR · red = higher value hurts IRR</span>
              </div>
              {tornadoData.length > 0 ? (
                <TornadoChart impacts={tornadoData} baseIRR={opModeGrid.baseIRR} />
              ) : (
                <div style={{ color: 'var(--text-muted)', fontSize: 13, padding: '12px 0' }}>
                  No driver data available.
                </div>
              )}
            </div>
          </>
        )}
      </main>
    </div>
  )
}
