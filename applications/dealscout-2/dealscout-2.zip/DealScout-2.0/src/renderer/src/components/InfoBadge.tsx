import { useState, useRef, useCallback } from 'react'
import { createPortal } from 'react-dom'

interface InfoBadgeProps {
  tip: string
}

interface Pos { x: number; y: number; above: boolean }

export default function InfoBadge({ tip }: InfoBadgeProps) {
  const [pos, setPos] = useState<Pos | null>(null)
  const ref = useRef<HTMLSpanElement>(null)

  const show = useCallback(() => {
    const el = ref.current
    if (!el) return
    const r = el.getBoundingClientRect()
    // Place tooltip to the right; if it would overflow viewport right, flip left
    const TOOLTIP_W = 240
    const spaceRight = window.innerWidth - r.right
    const x = spaceRight > TOOLTIP_W + 12 ? r.right + 8 : r.left - TOOLTIP_W - 8
    // Place below by default; if near bottom, place above
    const spaceBelow = window.innerHeight - r.bottom
    const above = spaceBelow < 80
    const y = above ? r.top - 6 : r.bottom + 6
    setPos({ x, y, above })
  }, [])

  const hide = useCallback(() => setPos(null), [])

  return (
    <>
      <span
        ref={ref}
        className="info-badge"
        onMouseEnter={show}
        onMouseLeave={hide}
        aria-label={tip}
      >
        i
      </span>
      {pos && createPortal(
        <div
          className="info-badge-tooltip"
          style={{
            left:      pos.x,
            top:       pos.y,
            transform: pos.above ? 'translateY(-100%)' : undefined,
          }}
        >
          {tip}
        </div>,
        document.body
      )}
    </>
  )
}
