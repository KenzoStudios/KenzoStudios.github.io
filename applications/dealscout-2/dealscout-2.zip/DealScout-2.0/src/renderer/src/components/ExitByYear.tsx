import { useMemo } from 'react'
import { runLBO, LBOInputs } from '../engine/lbo'

interface Props {
  inputs: LBOInputs
}

function fmt(n: number, d = 1) { return n.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }) }
function fmtM(n: number)   { return '$' + fmt(n, 1) + 'M' }
function fmtPct(n: number) { return fmt(n * 100, 1) + '%' }
function fmtX(n: number)   { return fmt(n, 2) + 'x' }

function irrColor(irr: number): string {
  return irr >= 0.20 ? 'positive' : irr >= 0.15 ? 'neutral' : 'negative'
}

export default function ExitByYear({ inputs }: Props) {
  const maxYear = Math.min(Math.max(inputs.holdPeriod + 3, 8), 15)

  const rows = useMemo(() => {
    return Array.from({ length: maxYear }, (_, i) => {
      const year   = i + 1
      const result = runLBO({ ...inputs, holdPeriod: year })
      return { year, result }
    })
  }, [inputs, maxYear])

  return (
    <div className="table-scroll">
      <table className="data-table">
        <thead>
          <tr>
            <th>Year</th>
            <th>Exit EBITDA</th>
            <th>Exit EV</th>
            <th>Debt at Exit</th>
            <th>Exit Equity</th>
            <th>MOIC</th>
            <th>IRR</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(({ year, result }) => {
            const isCurrent = year === inputs.holdPeriod
            return (
              <tr key={year} className={isCurrent ? 'table-exit-row' : ''}>
                <td>
                  {isCurrent ? <span style={{ color: '#3b82f6' }}>Year {year} ★</span> : `Year ${year}`}
                </td>
                {result.valid ? (
                  <>
                    <td>{fmtM(result.exitEBITDA)}</td>
                    <td>{fmtM(result.exitEV)}</td>
                    <td className="dim">{fmtM(result.debtAtExit)}</td>
                    <td>{fmtM(result.exitEquity)}</td>
                    <td>{fmtX(result.moic)}</td>
                    <td className={irrColor(result.irr)}>{fmtPct(result.irr)}</td>
                  </>
                ) : (
                  <td colSpan={6} style={{ color: 'var(--red)', textAlign: 'center' }}>Invalid — negative equity at exit</td>
                )}
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
