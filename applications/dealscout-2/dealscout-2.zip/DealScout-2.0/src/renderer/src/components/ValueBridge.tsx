import { LBOInputs, LBOOutputs } from '../engine/lbo'

interface Props {
  inputs: LBOInputs
  result: LBOOutputs
}

interface Row {
  label: string
  delta: number
  running: number
  type: 'start' | 'end' | 'pos' | 'neg'
}

function buildRows(inputs: LBOInputs, result: LBOOutputs): Row[] {
  const ebitdaGrowth = (result.exitEBITDA - inputs.ebitda) * inputs.exitMultiple
  const multipleChg  = inputs.ebitda * (inputs.exitMultiple - inputs.entryMultiple)
  const deleveraging = result.debtAtEntry - result.debtAtExit
  const fees         = -result.transactionFees

  let running = result.equityAtEntry
  const rows: Row[] = [
    { label: 'Entry Equity',  delta: result.equityAtEntry, running, type: 'start' },
  ]

  const push = (label: string, delta: number) => {
    running += delta
    rows.push({ label, delta, running, type: delta >= 0 ? 'pos' : 'neg' })
  }

  push('EBITDA Growth', ebitdaGrowth)
  push('Multiple Expansion / Contraction', multipleChg)
  push('Deleveraging', deleveraging)
  push('Transaction Fees', fees)

  rows.push({ label: 'Exit Equity', delta: result.exitEquity, running: result.exitEquity, type: 'end' })
  return rows
}

function fmtM(n: number) {
  const s = Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })
  return (n < 0 ? '−' : '') + '$' + s + 'M'
}
function fmtDelta(n: number) {
  const s = Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })
  return (n >= 0 ? '+' : '−') + '$' + s + 'M'
}

const COLORS: Record<Row['type'], { bar: string; text: string; bg: string }> = {
  start: { bar: '#3b82f6', text: '#3b82f6', bg: 'rgba(59,130,246,0.08)'  },
  end:   { bar: '#a78bfa', text: '#a78bfa', bg: 'rgba(167,139,250,0.08)' },
  pos:   { bar: '#3daa6a', text: '#3daa6a', bg: 'rgba(61,170,106,0.07)'  },
  neg:   { bar: '#c94545', text: '#c94545', bg: 'rgba(201,69,69,0.07)'   },
}

export default function ValueBridge({ inputs, result }: Props) {
  const rows   = buildRows(inputs, result)
  const maxAbs = Math.max(
    result.exitEquity,
    result.equityAtEntry,
    ...rows.filter(r => r.type !== 'start' && r.type !== 'end').map(r => Math.abs(r.delta))
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {rows.map((row, i) => {
        const c       = COLORS[row.type]
        const isTotal = row.type === 'start' || row.type === 'end'
        const pct     = Math.abs(isTotal ? row.delta : row.delta) / maxAbs * 100
        const separator = i === 0 || i === rows.length - 1

        return (
          <div
            key={i}
            style={{
              display: 'grid',
              gridTemplateColumns: '220px 1fr 90px 100px',
              alignItems: 'center',
              gap: 12,
              padding: '5px 0',
              borderTop: separator && i > 0 ? '1px solid var(--border)' : 'none',
            }}
          >
            {/* Label */}
            <div style={{
              fontSize: 12,
              color: isTotal ? c.text : 'var(--text-muted)',
              fontWeight: isTotal ? 700 : 500,
              paddingLeft: isTotal ? 0 : 12,
              whiteSpace: 'nowrap',
            }}>
              {!isTotal && (
                <span style={{ color: 'var(--text-dim)', marginRight: 6, fontSize: 11 }}>
                  {row.type === 'pos' ? '+' : '−'}
                </span>
              )}
              {row.label}
            </div>

            {/* Bar */}
            <div style={{ position: 'relative', height: 16 }}>
              <div style={{
                height: '100%',
                width: `${pct}%`,
                background: c.bg,
                border: `1px solid ${c.bar}`,
                borderRadius: 2,
                minWidth: Math.abs(row.delta) > 0.05 ? 4 : 0,
              }} />
            </div>

            {/* Delta / absolute value */}
            <div style={{
              fontFamily: 'var(--font-mono)',
              fontSize: 12,
              fontWeight: 600,
              color: c.text,
              textAlign: 'right',
              whiteSpace: 'nowrap',
            }}>
              {isTotal ? fmtM(row.delta) : fmtDelta(row.delta)}
            </div>

            {/* Running total */}
            <div style={{
              fontFamily: 'var(--font-mono)',
              fontSize: 11,
              color: isTotal ? c.text : 'var(--text-dim)',
              fontWeight: isTotal ? 700 : 400,
              textAlign: 'right',
              whiteSpace: 'nowrap',
            }}>
              {isTotal ? '' : fmtM(row.running)}
            </div>
          </div>
        )
      })}

      {/* Column headers (rendered at bottom as legend) */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '220px 1fr 90px 100px',
        gap: 12,
        paddingTop: 6,
        borderTop: '1px solid var(--border)',
      }}>
        <div style={{ fontSize: 10, color: 'var(--text-dim)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Driver</div>
        <div />
        <div style={{ fontSize: 10, color: 'var(--text-dim)', textTransform: 'uppercase', letterSpacing: '0.06em', textAlign: 'right' }}>Contribution</div>
        <div style={{ fontSize: 10, color: 'var(--text-dim)', textTransform: 'uppercase', letterSpacing: '0.06em', textAlign: 'right' }}>Cumulative</div>
      </div>
    </div>
  )
}
