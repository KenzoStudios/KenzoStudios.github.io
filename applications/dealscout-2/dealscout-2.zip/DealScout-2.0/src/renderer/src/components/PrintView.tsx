import { useMemo } from 'react'
import { runLBO, LBOInputs } from '../engine/lbo'

interface Props { inputs: LBOInputs; companyName: string }

function fmt(n: number, d = 1) { return n.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }) }
function fmtM(n: number)   { return '$' + fmt(n, 1) + 'M' }
function fmtPct(n: number) { return fmt(n * 100, 1) + '%' }
function fmtX(n: number)   { return fmt(n, 2) + 'x' }

export default function PrintView({ inputs, companyName }: Props) {
  const result = useMemo(() => runLBO(inputs), [inputs])

  if (!result.valid) return null

  const debtEvPct = inputs.debtEbitda / inputs.entryMultiple

  const bridgeRows = [
    { label: 'Entry Equity',   value: result.equityAtEntry, delta: null },
    { label: '+ EBITDA Growth', value: null, delta: (result.exitEBITDA - inputs.ebitda) * inputs.exitMultiple },
    { label: '+ Multiple Δ',   value: null, delta: inputs.ebitda * (inputs.exitMultiple - inputs.entryMultiple) },
    { label: '+ Deleveraging', value: null, delta: result.debtAtEntry - result.debtAtExit },
    { label: '− Fees',         value: null, delta: -result.transactionFees },
    { label: 'Exit Equity',    value: result.exitEquity, delta: null },
  ]

  const today = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })

  return (
    <div className="print-view">
      {/* Header */}
      <div className="pv-header">
        <div>
          <div className="pv-title">{companyName}</div>
          <div className="pv-subtitle">
            LBO Analysis · ${inputs.ebitda.toFixed(0)}M EBITDA · {inputs.entryMultiple.toFixed(1)}x entry · {inputs.holdPeriod}yr hold
          </div>
        </div>
        <div className="pv-header-right">
          <div className="pv-brand">DealScout 2.0</div>
          <div className="pv-date">{today}</div>
        </div>
      </div>

      {/* KPI grid */}
      <div className="pv-kpi-grid">
        {[
          { label: 'IRR',             value: fmtPct(result.irr),          accent: result.irr >= 0.20 ? 'green' : result.irr >= 0.15 ? 'amber' : 'red' },
          { label: 'MOIC',            value: fmtX(result.moic),           accent: result.irr >= 0.20 ? 'green' : result.irr >= 0.15 ? 'amber' : 'red' },
          { label: 'Entry EV',        value: fmtM(result.entryEV),        accent: 'neutral' },
          { label: 'Equity at Entry', value: fmtM(result.equityAtEntry),  accent: 'neutral' },
          { label: 'Debt / EV',       value: fmtPct(debtEvPct),           accent: 'neutral' },
          { label: 'Exit EV',         value: fmtM(result.exitEV),         accent: 'neutral' },
          { label: 'Exit Equity',     value: fmtM(result.exitEquity),     accent: 'neutral' },
          { label: 'Debt at Exit',    value: fmtM(result.debtAtExit),     accent: 'neutral' },
        ].map(k => (
          <div key={k.label} className={`pv-kpi pv-kpi-${k.accent}`}>
            <div className="pv-kpi-label">{k.label}</div>
            <div className="pv-kpi-value">{k.value}</div>
          </div>
        ))}
      </div>

      <div className="pv-two-col">
        {/* Returns Attribution */}
        <div className="pv-section">
          <div className="pv-section-title">Returns Attribution</div>
          <table className="pv-table">
            <tbody>
              {bridgeRows.map((r, i) => {
                const isTotal = r.value !== null
                const v = isTotal ? r.value! : r.delta!
                return (
                  <tr key={i} className={isTotal ? 'pv-total-row' : ''}>
                    <td>{r.label}</td>
                    <td style={{ textAlign: 'right', color: !isTotal && v < 0 ? '#dc2626' : !isTotal && v > 0 ? '#16a34a' : undefined }}>
                      {isTotal ? fmtM(v) : (v >= 0 ? '+' : '') + fmtM(v)}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        {/* Deal parameters */}
        <div className="pv-section">
          <div className="pv-section-title">Assumptions</div>
          <table className="pv-table">
            <tbody>
              {[
                ['EBITDA',           fmtM(inputs.ebitda)],
                ['Entry Multiple',   inputs.entryMultiple.toFixed(1) + 'x'],
                ['Exit Multiple',    inputs.exitMultiple.toFixed(1) + 'x'],
                ['EBITDA Growth',    fmtPct(inputs.growthRate) + ' p.a.'],
                ['Hold Period',      inputs.holdPeriod + ' years'],
                ['Debt / EBITDA',    inputs.debtEbitda.toFixed(1) + 'x'],
                ['Debt / EV',        fmtPct(debtEvPct)],
                ['Interest Rate',    fmtPct(inputs.interestRate)],
                ['Annual Paydown',   fmtPct(inputs.annualPaydown)],
                ['Tax Rate',         fmtPct(inputs.taxRate)],
              ].map(([l, v]) => (
                <tr key={l}>
                  <td>{l}</td>
                  <td style={{ textAlign: 'right', fontWeight: 600 }}>{v}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Annual Progression */}
      <div className="pv-section" style={{ marginTop: 20 }}>
        <div className="pv-section-title">Annual Progression</div>
        <table className="pv-table pv-full-table">
          <thead>
            <tr>
              <th>Year</th>
              <th>EBITDA</th>
              <th>EBIT</th>
              <th>Interest</th>
              <th>Net Income</th>
              <th>Levered FCF</th>
              <th>Mandatory</th>
              <th>Sweep</th>
              <th>Debt (EOY)</th>
              <th>DSCR</th>
            </tr>
          </thead>
          <tbody>
            {result.yearlyData.map(r => (
              <tr key={r.year}>
                <td>Year {r.year}</td>
                <td>{fmtM(r.ebitda)}</td>
                <td>{fmtM(r.ebit)}</td>
                <td>({fmtM(r.interest)})</td>
                <td>{fmtM(r.netIncome)}</td>
                <td style={{ color: r.leveredFCF >= 0 ? '#16a34a' : '#dc2626' }}>{fmtM(r.leveredFCF)}</td>
                <td>({fmtM(r.mandatoryPaydown)})</td>
                <td>{r.sweepPaydown > 0 ? '(' + fmtM(r.sweepPaydown) + ')' : '—'}</td>
                <td>{fmtM(r.debt)}</td>
                <td>{r.dscr.toFixed(2)}x</td>
              </tr>
            ))}
            <tr className="pv-total-row">
              <td>Exit</td>
              <td>{fmtM(result.exitEBITDA)}</td>
              <td colSpan={6} />
              <td>{fmtM(result.debtAtExit)}</td>
              <td>—</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="pv-footer">
        <span>Confidential — prepared with DealScout 2.0</span>
        <span>© 2026 Oscar McKenna Brown. All rights reserved.</span>
      </div>
    </div>
  )
}
