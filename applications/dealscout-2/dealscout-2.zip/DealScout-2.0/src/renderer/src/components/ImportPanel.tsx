import { useState, useRef, DragEvent, ChangeEvent } from 'react'
import { extractFinancials, ExtractedFinancials } from '../engine/extractor'
import { LBOInputs } from '../engine/lbo'

interface ImportFields {
  ebitda?: number
  da?: number
  capex?: number
  taxRate?: number
  sourceLabel: string
}

interface Props {
  onApply: (fields: ImportFields) => void
  onClose: () => void
}

interface ReviewRow {
  field: string
  key: keyof Omit<ExtractedFinancials, 'confidence' | 'inThousands'>
  detected: number | null
  snippet: string
  accepted: boolean
  override: string
}

type ImportTab = 'paste' | 'pdf' | 'manual'
type YearLabel = 'LTM' | 'FY2023' | 'FY2024' | 'FY2025'

// Keys that are actually applied to the LBO model — the rest are reference only
const APPLIED_KEYS: Set<string> = new Set(['ebitda', 'da', 'capex', 'taxRate'])

function buildReviewRows(data: ExtractedFinancials): ReviewRow[] {
  return [
    { field: 'Revenue ($M)',          key: 'revenue',         detected: data.revenue.value,         snippet: data.revenue.snippet,         accepted: false,                               override: '' },
    { field: 'EBITDA ($M)',           key: 'ebitda',          detected: data.ebitda.value,          snippet: data.ebitda.snippet,          accepted: data.ebitda.value !== null,          override: '' },
    { field: 'D&A ($M)',              key: 'da',              detected: data.da.value,              snippet: data.da.snippet,              accepted: data.da.value !== null,              override: '' },
    { field: 'Capex ($M)',            key: 'capex',           detected: data.capex.value,           snippet: data.capex.snippet,           accepted: data.capex.value !== null,           override: '' },
    { field: 'Net Income ($M)',       key: 'netIncome',       detected: data.netIncome.value,       snippet: data.netIncome.snippet,       accepted: false,                               override: '' },
    { field: 'Interest Expense ($M)', key: 'interestExpense', detected: data.interestExpense.value, snippet: data.interestExpense.snippet, accepted: false,                               override: '' },
    { field: 'Tax Rate',              key: 'taxRate',         detected: data.taxRate.value,         snippet: data.taxRate.snippet,         accepted: data.taxRate.value !== null,         override: '' },
  ]
}

function formatDetected(key: string, value: number | null): string {
  if (value === null) return '—'
  if (key === 'taxRate') return (value * 100).toFixed(1) + '%'
  return '$' + value.toFixed(1) + 'M'
}

export default function ImportPanel({ onApply, onClose }: Props) {
  const [tab, setTab] = useState<ImportTab>('paste')

  // Paste tab
  const [pasteText, setPasteText] = useState('')
  const [pasteRows, setPasteRows] = useState<ReviewRow[]>([])
  const [pasteExtracted, setPasteExtracted] = useState(false)

  // PDF tab
  const [pdfRows, setPdfRows] = useState<ReviewRow[]>([])
  const [pdfExtracted, setPdfExtracted] = useState(false)
  const [pdfLoading, setPdfLoading] = useState(false)
  const [pdfError, setPdfError] = useState('')
  const [isDragging, setIsDragging] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Manual tab
  const [manualYear, setManualYear] = useState<YearLabel>('LTM')
  const [manualFields, setManualFields] = useState({
    revenue: '', ebitda: '', da: '', capex: '', netIncome: '', interestExpense: '', taxRate: '',
  })

  // ── Paste tab handlers ───────────────────────────────────────────────────────

  function handleExtract() {
    const data = extractFinancials(pasteText)
    setPasteRows(buildReviewRows(data))
    setPasteExtracted(true)
  }

  function togglePasteRow(i: number) {
    setPasteRows(prev => prev.map((r, idx) => idx === i ? { ...r, accepted: !r.accepted } : r))
  }

  function setPasteOverride(i: number, val: string) {
    setPasteRows(prev => prev.map((r, idx) => idx === i ? { ...r, override: val } : r))
  }

  function applyRows(rows: ReviewRow[], label: string) {
    const fields: ImportFields = { sourceLabel: label }
    for (const row of rows) {
      if (!row.accepted) continue
      const raw = row.override.trim() !== '' ? parseFloat(row.override) : row.detected
      if (raw === null || isNaN(raw as number)) continue
      const val = raw as number
      if (row.key === 'ebitda')          fields.ebitda   = val
      if (row.key === 'da')              fields.da       = val
      if (row.key === 'capex')           fields.capex    = val
      if (row.key === 'taxRate')         fields.taxRate  = val
    }
    onApply(fields)
  }

  // ── PDF tab handlers ─────────────────────────────────────────────────────────

  async function processPDF(file: File) {
    setPdfLoading(true)
    setPdfError('')
    setPdfExtracted(false)
    setPdfRows([])
    try {
      const buffer = await file.arrayBuffer()
      const result = await (window as any).api.parsePDF(buffer) as { success: boolean; text?: string; error?: string }
      if (!result.success) {
        setPdfError(result.error || 'Failed to parse PDF')
        return
      }
      const text = result.text || ''
      if (text.trim().length < 100) {
        setPdfError('This PDF appears to be a scanned image — text could not be extracted. Please paste the text manually.')
        return
      }
      const data = extractFinancials(text)
      setPdfRows(buildReviewRows(data))
      setPdfExtracted(true)
    } catch (e: unknown) {
      setPdfError(e instanceof Error ? e.message : 'Unexpected error parsing PDF')
    } finally {
      setPdfLoading(false)
    }
  }

  function handleDragOver(e: DragEvent<HTMLDivElement>) {
    e.preventDefault()
    setIsDragging(true)
  }

  function handleDragLeave() {
    setIsDragging(false)
  }

  function handleDrop(e: DragEvent<HTMLDivElement>) {
    e.preventDefault()
    setIsDragging(false)
    const file = e.dataTransfer.files[0]
    if (file && file.type === 'application/pdf') {
      processPDF(file)
    }
  }

  function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (file) processPDF(file)
  }

  function togglePdfRow(i: number) {
    setPdfRows(prev => prev.map((r, idx) => idx === i ? { ...r, accepted: !r.accepted } : r))
  }

  function setPdfOverride(i: number, val: string) {
    setPdfRows(prev => prev.map((r, idx) => idx === i ? { ...r, override: val } : r))
  }

  // ── Manual tab handler ───────────────────────────────────────────────────────

  function handleManualApply() {
    const fields: ImportFields = { sourceLabel: `Manual / ${manualYear}` }
    const ebitda = parseFloat(manualFields.ebitda)
    const da     = parseFloat(manualFields.da)
    const capex  = parseFloat(manualFields.capex)
    const taxRate = parseFloat(manualFields.taxRate)
    if (!isNaN(ebitda))   fields.ebitda  = ebitda
    if (!isNaN(da))       fields.da      = da        // already in $M
    if (!isNaN(capex))    fields.capex   = capex
    if (!isNaN(taxRate))  fields.taxRate = taxRate / 100
    onApply(fields)
  }

  // ── Review table ─────────────────────────────────────────────────────────────

  function ReviewTable({ rows, onToggle, onOverride, sourceLabel }: {
    rows: ReviewRow[]
    onToggle: (i: number) => void
    onOverride: (i: number, v: string) => void
    sourceLabel: string
  }) {
    return (
      <div>
        <table className="import-review-table">
          <thead>
            <tr>
              <th>Field</th>
              <th>Detected Value</th>
              <th>Source Snippet</th>
              <th>Override</th>
              <th>Accept</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => {
              const isRef = !APPLIED_KEYS.has(row.key)
              return (
                <tr key={row.key} style={{ opacity: isRef ? 0.45 : row.accepted ? 1 : 0.55 }}>
                  <td>
                    {row.field}
                    {isRef && (
                      <span style={{ marginLeft: 6, fontSize: 9, color: 'var(--text-dim)', textTransform: 'uppercase', letterSpacing: '0.05em', verticalAlign: 'middle' }}>
                        ref
                      </span>
                    )}
                  </td>
                  <td style={{ fontFamily: 'var(--font-mono)', color: row.detected !== null ? 'var(--text)' : 'var(--text-dim)' }}>
                    {formatDetected(row.key, row.detected)}
                  </td>
                  <td style={{ fontSize: 10, color: 'var(--text-muted)', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {row.snippet || '—'}
                  </td>
                  <td>
                    {!isRef && (
                      <input
                        type="text"
                        value={row.override}
                        onChange={e => onOverride(i, e.target.value)}
                        placeholder="Override"
                        style={{ background: 'var(--bg)', border: '1px solid var(--border)', color: 'var(--text)', borderRadius: 4, padding: '2px 6px', width: 90, fontFamily: 'var(--font-mono)', fontSize: 12 }}
                      />
                    )}
                  </td>
                  <td style={{ textAlign: 'center' }}>
                    {!isRef && (
                      <input type="checkbox" checked={row.accepted} onChange={() => onToggle(i)} />
                    )}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        <div style={{ marginTop: 12, display: 'flex', justifyContent: 'flex-end' }}>
          <button
            className="export-btn"
            style={{ background: 'var(--accent)', color: '#fff', borderColor: 'var(--accent)' }}
            onClick={() => applyRows(rows, sourceLabel)}
          >
            Apply to Model
          </button>
        </div>
      </div>
    )
  }

  // ── Render ───────────────────────────────────────────────────────────────────

  return (
    <div className="import-panel-overlay" onClick={onClose}>
      <div className="import-panel" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 20px', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)' }}>Import Financial Data</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: 20, cursor: 'pointer', lineHeight: 1, padding: '0 4px' }}>×</button>
        </div>

        {/* Tabs */}
        <div className="import-tabs">
          {(['paste', 'pdf', 'manual'] as ImportTab[]).map(t => (
            <button
              key={t}
              className={`import-tab ${tab === t ? 'import-tab-active' : ''}`}
              onClick={() => setTab(t)}
            >
              {t === 'paste' ? 'Paste Text' : t === 'pdf' ? 'Upload PDF' : 'Manual Entry'}
            </button>
          ))}
        </div>

        {/* Body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px' }}>

          {/* ── Paste Text ── */}
          {tab === 'paste' && (
            <div>
              <textarea
                className="import-textarea"
                rows={14}
                value={pasteText}
                onChange={e => { setPasteText(e.target.value); setPasteExtracted(false) }}
                placeholder={`Paste 10-K, CIM, or earnings release text here.\n\nExample:\n  Revenue: $1,234M\n  EBITDA: $312M\n  Depreciation and Amortization: $45M\n  Capital Expenditures: $62M\n  Net Income: $198M\n  Interest Expense: $55M\n  Effective Tax Rate: 25%`}
              />
              <div style={{ marginTop: 10, display: 'flex', justifyContent: 'flex-end' }}>
                <button
                  className="export-btn"
                  onClick={handleExtract}
                  disabled={pasteText.trim().length === 0}
                >
                  Extract
                </button>
              </div>
              {pasteExtracted && (
                <div style={{ marginTop: 16 }}>
                  <ReviewTable rows={pasteRows} onToggle={togglePasteRow} onOverride={setPasteOverride} sourceLabel="Pasted Text" />
                </div>
              )}
            </div>
          )}

          {/* ── Upload PDF ── */}
          {tab === 'pdf' && (
            <div>
              <div
                className={`pdf-drop-zone${isDragging ? ' pdf-drop-zone-active' : ''}`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
              >
                {pdfLoading
                  ? <span style={{ color: 'var(--text-muted)' }}>Extracting text…</span>
                  : <>
                    <div style={{ fontSize: 32, marginBottom: 8, opacity: 0.5 }}>⬆</div>
                    <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>Drag & drop a PDF here or <span style={{ color: 'var(--accent)', cursor: 'pointer' }}>browse</span></div>
                    <div style={{ color: 'var(--text-dim)', fontSize: 11, marginTop: 4 }}>Accepts .pdf files</div>
                  </>
                }
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf"
                style={{ display: 'none' }}
                onChange={handleFileChange}
              />
              {pdfError && (
                <div style={{ marginTop: 12, padding: '10px 12px', background: 'var(--red-bg)', border: '1px solid var(--red-dim)', borderRadius: 6, color: 'var(--red)', fontSize: 12 }}>
                  {pdfError}
                </div>
              )}
              {pdfExtracted && (
                <div style={{ marginTop: 16 }}>
                  <ReviewTable rows={pdfRows} onToggle={togglePdfRow} onOverride={setPdfOverride} sourceLabel="PDF Import" />
                </div>
              )}
            </div>
          )}

          {/* ── Manual Entry ── */}
          {tab === 'manual' && (
            <div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 11, color: 'var(--text-muted)', display: 'block', marginBottom: 6 }}>Year / Period</label>
                <div style={{ display: 'flex', gap: 6 }}>
                  {(['LTM', 'FY2023', 'FY2024', 'FY2025'] as YearLabel[]).map(y => (
                    <button
                      key={y}
                      onClick={() => setManualYear(y)}
                      className={`import-tab ${manualYear === y ? 'import-tab-active' : ''}`}
                      style={{ padding: '4px 12px', fontSize: 12 }}
                    >
                      {y}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px 20px' }}>
                {[
                  { label: 'Revenue ($M)',           key: 'revenue',         suffix: '$M' },
                  { label: 'EBITDA ($M)',             key: 'ebitda',          suffix: '$M' },
                  { label: 'D&A ($M)',                key: 'da',              suffix: '$M' },
                  { label: 'Capex ($M)',              key: 'capex',           suffix: '$M' },
                  { label: 'Net Income ($M)',         key: 'netIncome',       suffix: '$M' },
                  { label: 'Interest Expense ($M)',   key: 'interestExpense', suffix: '$M' },
                  { label: 'Tax Rate',                key: 'taxRate',         suffix: '%' },
                ].map(f => (
                  <div key={f.key}>
                    <label style={{ fontSize: 11, color: 'var(--text-muted)', display: 'block', marginBottom: 4 }}>{f.label}</label>
                    <div className="input-wrapper">
                      <input
                        type="number"
                        className="input-control"
                        value={(manualFields as any)[f.key]}
                        onChange={e => setManualFields(prev => ({ ...prev, [f.key]: e.target.value }))}
                        placeholder="—"
                      />
                      <span className="input-suffix">{f.suffix}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ marginTop: 20, display: 'flex', justifyContent: 'flex-end' }}>
                <button
                  className="export-btn"
                  style={{ background: 'var(--accent)', color: '#fff', borderColor: 'var(--accent)' }}
                  onClick={handleManualApply}
                >
                  Apply to Model
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
