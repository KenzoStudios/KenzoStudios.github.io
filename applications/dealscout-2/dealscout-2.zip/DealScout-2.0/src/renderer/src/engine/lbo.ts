// ─── LBO Calculation Engine ───────────────────────────────────────────────────
//
// Single-tranche LBO with full P&L and cash sweep:
//   - Each year: mandatory amortisation (% of initial debt) + cash sweep
//   - Cash sweep: all free cash above mandatory repayment reduces debt further
//   - This makes interest rate, tax, D&A, capex ALL affect debtAtExit → IRR
//   - Exit via EV/EBITDA multiple (enterprise value basis)
//   - No taxes on exit assumed (standard PE simplification)
//   - All cash flows in $M

export interface LBOInputs {
  ebitda: number         // Entry EBITDA ($M)
  entryMultiple: number  // Entry EV / EBITDA (x)
  exitMultiple: number   // Exit EV / EBITDA (x)
  growthRate: number     // Annual EBITDA growth rate (decimal)
  holdPeriod: number     // Hold period (years)
  debtEbitda: number     // Debt / EBITDA at entry (x)
  interestRate: number   // Annual interest rate on debt (decimal)
  annualPaydown: number  // Mandatory amortisation — % of initial principal per year (decimal)
  fees: number           // Transaction fees as % of entry EV (decimal)
  daPercent: number      // D&A as % of EBITDA (decimal)
  capexPercent: number   // Capex as % of EBITDA (decimal)
  taxRate: number        // Effective tax rate (decimal)
  ebitdaOverrides?: number[]  // Per-year EBITDA overrides from operating model ($M, year 1..N)
}

export interface YearlySnapshot {
  year: number
  // Income statement
  ebitda: number
  da: number
  ebit: number
  interest: number
  ebt: number
  tax: number
  netIncome: number
  // Cash flow
  capex: number
  leveredFCF: number    // Net Income + D&A − Capex (free cash before debt repayment)
  mandatoryPaydown: number
  sweepPaydown: number  // additional paydown from cash sweep
  debtPaydown: number   // total = mandatory + sweep
  freeCash: number      // leveredFCF − total paydown (≈0 when fully swept, <0 = shortfall)
  // Balance sheet
  debt: number          // Debt at end of year
  // Coverage
  dscr: number          // EBITDA / (Interest + Total Paydown)
}

export interface LBOOutputs {
  entryEV: number
  transactionFees: number
  debtAtEntry: number
  equityAtEntry: number
  yearlyData: YearlySnapshot[]
  exitEBITDA: number
  exitEV: number
  debtAtExit: number
  exitEquity: number
  moic: number
  irr: number
  totalLeveredFCF: number
  totalTaxPaid: number
  totalSweep: number    // total additional debt paid via cash sweep
  avgDSCR: number
  minDSCR: number
  minDSCRYear: number
  valid: boolean
}

export function runLBO(inputs: LBOInputs): LBOOutputs {
  const {
    ebitda, entryMultiple, exitMultiple, growthRate, holdPeriod,
    debtEbitda, interestRate, annualPaydown, fees,
    daPercent, capexPercent, taxRate,
    ebitdaOverrides,
  } = inputs

  // ── Entry ─────────────────────────────────────────────────────────────────
  const entryEV         = ebitda * entryMultiple
  const transactionFees = entryEV * fees
  const debtAtEntry     = ebitda * debtEbitda
  const equityAtEntry   = entryEV + transactionFees - debtAtEntry

  if (equityAtEntry <= 0) return invalidOutput(inputs)

  // Mandatory amortisation amount per year (floor on principal repayment)
  const mandatoryAmount = debtAtEntry * annualPaydown

  // ── Annual model (iterative — each year's debt feeds into the next) ────────
  const yearlyData: YearlySnapshot[] = []
  let totalLeveredFCF = 0
  let totalTaxPaid    = 0
  let totalSweep      = 0
  let totalDSCR       = 0
  let minDSCR         = Infinity
  let minDSCRYear     = 1

  for (let year = 1; year <= holdPeriod; year++) {
    // P&L — use override if supplied by the operating model
    // Safe access: override only applied when an entry exists for this year index
    const ebitdaY  = (ebitdaOverrides && ebitdaOverrides[year - 1] !== undefined)
      ? ebitdaOverrides[year - 1]
      : ebitda * Math.pow(1 + growthRate, year)
    const daY      = ebitdaY * daPercent
    const ebitY    = ebitdaY - daY
    const capexY   = ebitdaY * capexPercent

    // Debt at start of year (previous EOY, or entry for year 1)
    const debtBOY  = year === 1 ? debtAtEntry : yearlyData[year - 2].debt

    // Interest on opening balance
    const interest = debtBOY * interestRate
    const ebt      = ebitY - interest
    const tax      = Math.max(0, ebt * taxRate)
    const netInc   = ebt - tax

    // Free cash available for debt repayment (after interest, before principal)
    const leveredFCF = netInc + daY - capexY

    // Mandatory amortisation (contractual floor, capped at outstanding balance)
    const mandatory = Math.min(mandatoryAmount, debtBOY)

    // Cash sweep: all free cash above mandatory goes to additional debt paydown
    // If leveredFCF < mandatory, there's a shortfall (freeCash < 0) — mandatory still happens
    const sweep     = Math.max(0, Math.min(leveredFCF - mandatory, debtBOY - mandatory))
    const totalPay  = mandatory + sweep
    const debtEOY   = Math.max(0, debtBOY - totalPay)

    // Post-sweep free cash (≈0 when swept, negative = shortfall)
    const freeCash  = leveredFCF - totalPay

    const debtService = interest + totalPay
    const dscr = debtService > 0 ? ebitdaY / debtService : Infinity

    totalLeveredFCF += leveredFCF
    totalTaxPaid    += tax
    totalSweep      += sweep
    totalDSCR       += dscr
    if (dscr < minDSCR) { minDSCR = dscr; minDSCRYear = year }

    yearlyData.push({
      year, ebitda: ebitdaY, da: daY, ebit: ebitY,
      interest, ebt, tax, netIncome: netInc,
      capex: capexY, leveredFCF,
      mandatoryPaydown: mandatory, sweepPaydown: sweep,
      debtPaydown: totalPay, freeCash,
      debt: debtEOY, dscr
    })
  }

  // ── Exit ──────────────────────────────────────────────────────────────────
  const exitEBITDA = (ebitdaOverrides && ebitdaOverrides[holdPeriod - 1] !== undefined)
    ? ebitdaOverrides[holdPeriod - 1]
    : ebitda * Math.pow(1 + growthRate, holdPeriod)
  const exitEV     = exitEBITDA * exitMultiple
  const debtAtExit = yearlyData[holdPeriod - 1].debt
  const exitEquity = exitEV - debtAtExit

  if (exitEquity <= 0) return invalidOutput(inputs)

  // ── Returns ───────────────────────────────────────────────────────────────
  const moic = exitEquity / equityAtEntry
  const irr  = Math.pow(moic, 1 / holdPeriod) - 1

  return {
    entryEV, transactionFees, debtAtEntry, equityAtEntry,
    yearlyData, exitEBITDA, exitEV, debtAtExit, exitEquity,
    moic, irr,
    totalLeveredFCF, totalTaxPaid, totalSweep,
    avgDSCR: totalDSCR / holdPeriod,
    minDSCR: minDSCR === Infinity ? 0 : minDSCR,
    minDSCRYear,
    valid: true
  }
}

function invalidOutput(inputs: LBOInputs): LBOOutputs {
  return {
    entryEV: inputs.ebitda * inputs.entryMultiple,
    transactionFees: 0, debtAtEntry: inputs.ebitda * inputs.debtEbitda,
    equityAtEntry: 0, yearlyData: [],
    exitEBITDA: 0, exitEV: 0, debtAtExit: 0, exitEquity: 0,
    moic: 0, irr: 0,
    totalLeveredFCF: 0, totalTaxPaid: 0, totalSweep: 0,
    avgDSCR: 0, minDSCR: 0, minDSCRYear: 1, valid: false
  }
}

// ─── Operating Model Types ─────────────────────────────────────────────────────

export interface OpYearData {
  revenueGrowthPct: number      // YoY %
  ebitdaMarginPct: number       // EBITDA / Revenue %
  daPctOfEbitda: number         // D&A / EBITDA %
  cogsMarginPct: number         // COGS / Revenue %
  sgaMarginPct: number          // SG&A / Revenue %
  capexPctOfRevenue: number     // Capex / Revenue %
  wcChangePctOfRevenue: number  // ΔWC / Revenue %
  overrides: Record<string, number>
}

export interface OperatingModelState {
  active: boolean
  entryRevenue: number
  entryEbitda: number
  yearData: OpYearData[]
}

export const DEFAULT_OP_YEAR: OpYearData = {
  revenueGrowthPct: 0.05,
  ebitdaMarginPct: 0.25,
  daPctOfEbitda: 0.10,
  cogsMarginPct: 0.55,
  sgaMarginPct: 0.20,
  capexPctOfRevenue: 0.05,
  wcChangePctOfRevenue: 0.02,
  overrides: {},
}

export interface OpYearComputed {
  year: number
  revenue: number
  cogs: number
  grossProfit: number
  sga: number
  ebitda: number
  ebitdaMargin: number
  da: number
  ebit: number
  interest: number
  ebt: number
  tax: number
  netIncome: number
  capex: number
  wcChange: number
  leveredFCF: number
}

export function computeOpModel(
  entryRevenue: number,
  entryEbitda: number,
  yearData: OpYearData[],
  taxRate: number,
  lboYearlyData: YearlySnapshot[],
): OpYearComputed[] {
  const results: OpYearComputed[] = []
  let prevRevenue = entryRevenue

  for (let i = 0; i < yearData.length; i++) {
    const yd = yearData[i]
    const ov = yd.overrides

    const revenue    = 'revenue'    in ov ? ov['revenue']    : prevRevenue * (1 + yd.revenueGrowthPct)
    const ebitda     = 'ebitda'     in ov ? ov['ebitda']     : revenue * yd.ebitdaMarginPct
    const cogs       = 'cogs'       in ov ? ov['cogs']       : revenue * yd.cogsMarginPct
    const grossProfit = revenue - cogs
    const sga        = 'sga'        in ov ? ov['sga']        : revenue * yd.sgaMarginPct
    const ebitdaMargin = revenue > 0 ? ebitda / revenue : 0
    const da         = 'da'         in ov ? ov['da']         : ebitda * yd.daPctOfEbitda
    const ebit       = ebitda - da
    const interest   = lboYearlyData[i] ? lboYearlyData[i].interest : 0
    const ebt        = ebit - interest
    const tax        = Math.max(0, ebt * taxRate)
    const netIncome  = ebt - tax
    const capex      = 'capex'      in ov ? ov['capex']      : revenue * yd.capexPctOfRevenue
    const wcChange   = 'wcChange'   in ov ? ov['wcChange']   : revenue * yd.wcChangePctOfRevenue
    const leveredFCF = netIncome + da - capex - wcChange

    results.push({
      year: i + 1,
      revenue, cogs, grossProfit, sga,
      ebitda, ebitdaMargin, da, ebit,
      interest, ebt, tax, netIncome,
      capex, wcChange, leveredFCF,
    })

    prevRevenue = revenue
  }

  return results
}

// ─── Deal Library Types ────────────────────────────────────────────────────────

export interface DealRecord {
  id: string
  name: string
  savedAt: string
  inputs: LBOInputs
  irr: number
  moic: number
  entryEV: number
  exitEquity: number
  valid: boolean
}

export const DEFAULT_LBO_INPUTS: LBOInputs = {
  ebitda: 100, entryMultiple: 8.0, exitMultiple: 8.5,
  growthRate: 0.05, holdPeriod: 5,
  debtEbitda: 5.0, interestRate: 0.08, annualPaydown: 0.10, fees: 0.02,
  daPercent: 0.10, capexPercent: 0.08, taxRate: 0.25
}
