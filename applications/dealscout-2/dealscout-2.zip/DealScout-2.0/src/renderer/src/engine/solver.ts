import { runLBO, LBOInputs } from './lbo'

export interface InverseLBOInputs {
  targetIRR: number
  ebitda: number
  holdPeriod: number
  exitMultiple: number
  debtEbitda: number
  interestRate: number
  annualPaydown: number
  fees: number
  daPercent: number
  capexPercent: number
  taxRate: number
  entryMultiple: number
  growthRate: number
}

export interface InverseLBOOutputs {
  maxEntryMultiple: number | null
  maxEntryEV: number | null
  requiredGrowth: number | null
  currentIRR: number
  currentMOIC: number
  dealWorks: boolean
  verdict: string
  grid: HeatmapCell[][]
  entryMultiples: number[]
  growthRates: number[]
}

export interface HeatmapCell {
  entryMultiple: number
  growthRate: number
  irr: number
  valid: boolean
}

function binarySearch(
  f: (x: number) => number,
  lo: number, hi: number,
  tolerance = 1e-6, maxIter = 120
): number | null {
  let fLo = f(lo), fHi = f(hi)
  if (!isFinite(fLo) || !isFinite(fHi)) return null
  if (fLo * fHi > 0) return null
  for (let i = 0; i < maxIter; i++) {
    if (hi - lo < tolerance) return (lo + hi) / 2
    const mid = (lo + hi) / 2
    const fMid = f(mid)
    if (!isFinite(fMid)) return null
    if (fMid === 0) return mid
    if (fLo * fMid < 0) { hi = mid; fHi = fMid }
    else                { lo = mid; fLo = fMid }
  }
  return (lo + hi) / 2
}

function irrAt(base: Omit<InverseLBOInputs, 'entryMultiple' | 'growthRate' | 'targetIRR'>, entryMultiple: number, growthRate: number): number {
  const result = runLBO({ ...base, entryMultiple, growthRate } as LBOInputs)
  return result.valid ? result.irr : -999
}

function minViableEntryMultiple(debtEbitda: number, fees: number): number {
  return debtEbitda / (1 + fees) + 0.05
}

function minViableGrowth(ebitda: number, debtEbitda: number, annualPaydown: number, holdPeriod: number, exitMultiple: number): number {
  // Conservative lower bound using straight-line paydown only (no cash sweep).
  // With sweep, debtAtExit is lower (better), so this bound is safe — the
  // actual minimum viable growth is at or below this value.
  const debt = ebitda * debtEbitda
  const debtAtExitWorstCase = Math.max(0, debt * (1 - holdPeriod * annualPaydown))
  const ratio = debtAtExitWorstCase / (ebitda * exitMultiple)
  if (ratio <= 0) return -0.99
  return Math.pow(ratio, 1 / holdPeriod) - 1 + 0.005
}

export function solveInverseLBO(inputs: InverseLBOInputs): InverseLBOOutputs {
  const { targetIRR, ebitda, holdPeriod, exitMultiple, debtEbitda, interestRate, annualPaydown, fees, daPercent, capexPercent, taxRate, entryMultiple, growthRate } = inputs
  const base = { ebitda, holdPeriod, exitMultiple, debtEbitda, interestRate, annualPaydown, fees, daPercent, capexPercent, taxRate }

  const currentResult = runLBO({ ...base, entryMultiple, growthRate } as LBOInputs)
  const currentIRR  = currentResult.valid ? currentResult.irr  : 0
  const currentMOIC = currentResult.valid ? currentResult.moic : 0
  const dealWorks   = currentResult.valid && currentIRR >= targetIRR

  const mLo = minViableEntryMultiple(debtEbitda, fees)
  const maxEntryMultiple = binarySearch(m => irrAt(base, m, growthRate) - targetIRR, mLo, 30.0)
  const maxEntryEV = maxEntryMultiple !== null ? ebitda * maxEntryMultiple : null

  const gLo = minViableGrowth(ebitda, debtEbitda, annualPaydown, holdPeriod, exitMultiple)
  const requiredGrowth = binarySearch(g => irrAt(base, entryMultiple, g) - targetIRR, Math.max(gLo, -0.50), 0.60)

  const irrPct = (currentIRR * 100).toFixed(1)
  const targetPct = (targetIRR * 100).toFixed(1)
  let verdict: string
  if (!currentResult.valid) {
    verdict = 'Deal is not viable — equity at entry is zero or negative. Reduce leverage or the entry multiple.'
  } else if (dealWorks) {
    const surplus = ((currentIRR - targetIRR) * 100).toFixed(1)
    verdict = `Deal works. Current IRR of ${irrPct}% exceeds the ${targetPct}% target by ${surplus}pp. You have headroom on price or can accept lower growth.`
  } else {
    const gap   = ((targetIRR - currentIRR) * 100).toFixed(1)
    const maxMx = maxEntryMultiple !== null ? maxEntryMultiple.toFixed(1) + 'x' : 'N/A'
    const reqG  = requiredGrowth !== null ? (requiredGrowth * 100).toFixed(1) + '%' : 'N/A'
    verdict = `Deal does not work. IRR of ${irrPct}% falls ${gap}pp short of the ${targetPct}% target. Max viable entry is ${maxMx}, or EBITDA growth must reach ${reqG}.`
  }

  // Start x-axis at or above the minimum viable entry multiple — no invalid left columns
  const xMin   = Math.ceil(mLo * 2) / 2                // round UP to nearest 0.5x above the valid floor
  const xMax   = xMin + 12                             // always show a 12-unit window
  const xSteps = 25
  const yMin = -0.05, yMax = 0.30, ySteps = 18

  const entryMultiples = Array.from({ length: xSteps + 1 }, (_, i) => xMin + (i / xSteps) * (xMax - xMin))
  const growthRates    = Array.from({ length: ySteps + 1 }, (_, j) => yMin + (j / ySteps) * (yMax - yMin))

  const grid: HeatmapCell[][] = growthRates.map(g =>
    entryMultiples.map(m => {
      const irr = irrAt(base, m, g)
      return { entryMultiple: m, growthRate: g, irr, valid: irr > -998 }
    })
  )

  return { maxEntryMultiple, maxEntryEV, requiredGrowth, currentIRR, currentMOIC, dealWorks, verdict, grid, entryMultiples, growthRates }
}
