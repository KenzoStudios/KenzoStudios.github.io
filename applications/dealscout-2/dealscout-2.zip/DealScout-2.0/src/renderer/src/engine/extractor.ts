// ─── Financial Data Extractor ─────────────────────────────────────────────────
// Pure regex-based extraction — no external libraries.

export interface ExtractedFinancials {
  revenue:         { value: number | null; snippet: string }
  ebitda:          { value: number | null; snippet: string }
  da:              { value: number | null; snippet: string }
  capex:           { value: number | null; snippet: string }
  netIncome:       { value: number | null; snippet: string }
  interestExpense: { value: number | null; snippet: string }
  taxRate:         { value: number | null; snippet: string }
  confidence:      'high' | 'medium' | 'low'
  inThousands:     boolean
}

// ── Scale detection ────────────────────────────────────────────────────────────
// Count occurrences to resolve conflicts (e.g. "in millions" for financials
// but "in thousands" for share counts in EPS tables).

function detectScale(text: string): { inThousands: boolean; inMillions: boolean } {
  const lower = text.toLowerCase()
  const millions  = (lower.match(/in\s+millions/g)  || []).length
  const thousands = (lower.match(/in\s+thousands/g) || []).length
  // If millions appears at all, treat the financials as millions.
  // "in thousands" only wins when millions never appears (true thousands-unit docs).
  const inMillions  = millions > 0
  const inThousands = thousands > 0 && !inMillions
  return { inThousands, inMillions }
}

// ── Number parsing ─────────────────────────────────────────────────────────────
// Handles: $1.2B / $1.2 billion / $1,234M / $1,234K / (1,234.5) / 1,234.5

function parseNumber(raw: string): number | null {
  if (!raw) return null
  const s = raw.trim()

  // Billions: $1.2B or "$1.2 billion"
  const billionMatch = s.match(/^\$?([\d,]+\.?\d*)\s*(?:billion|B)\b/i)
  if (billionMatch) {
    const n = parseFloat(billionMatch[1].replace(/,/g, ''))
    return isNaN(n) ? null : n * 1000
  }

  // Millions: $1,234M
  const millionMatch = s.match(/^\$?([\d,]+\.?\d*)\s*M\b/i)
  if (millionMatch) {
    const n = parseFloat(millionMatch[1].replace(/,/g, ''))
    return isNaN(n) ? null : n
  }

  // Thousands: $1,234K
  const thousandMatch = s.match(/^\$?([\d,]+\.?\d*)\s*K\b/i)
  if (thousandMatch) {
    const n = parseFloat(thousandMatch[1].replace(/,/g, ''))
    return isNaN(n) ? null : n / 1000
  }

  // Parenthesised negative: (1,234.5) or ($1,234)
  const parenMatch = s.match(/^\(\$?([\d,]+\.?\d*)\)$/)
  if (parenMatch) {
    const n = parseFloat(parenMatch[1].replace(/,/g, ''))
    return isNaN(n) ? null : -n
  }

  // Plain: $1,234.5 or 1234.5
  const plainMatch = s.match(/^\$?([\d,]+\.?\d*)$/)
  if (plainMatch) {
    const n = parseFloat(plainMatch[1].replace(/,/g, ''))
    return isNaN(n) ? null : n
  }

  return null
}

function hasExplicitScaleSuffix(raw: string): boolean {
  return /\d\s*(?:billion|B|M|K)\b/i.test(raw.trim())
}

// ── Window-based extraction ────────────────────────────────────────────────────
// Finds the label pattern, then scans the NEXT 300 characters for the first
// number token. This is much more robust than trying to match label + value
// in a single regex, especially for tabular data where values appear on the
// next line (common in SEC filings).

type NumResult = { value: number; raw: string; snippet: string } | null

function extractAfterLabel(text: string, labelRegex: RegExp, windowSize = 300): NumResult {
  const labelMatch = labelRegex.exec(text)
  if (!labelMatch) return null

  const snippetStart = Math.max(0, text.lastIndexOf('\n', labelMatch.index) + 1)
  const snippetEnd   = text.indexOf('\n', labelMatch.index + labelMatch[0].length)
  const snippet = text
    .slice(snippetStart, snippetEnd === -1 ? snippetStart + 120 : snippetEnd)
    .trim()
    .slice(0, 120)

  const window = text.slice(labelMatch.index + labelMatch[0].length, labelMatch.index + labelMatch[0].length + windowSize)

  // Match: optional whitespace/$/newline, then a number (plain or parenthesised).
  // IMPORTANT: plain numbers must start with \d (not comma) to avoid greedily
  // matching the comma in ", rest of label text" that follows partial label patterns.
  const numMatch = window.match(/[\s\n\r$:]*(\(\d[\d,]*\.?\d*\)|\d[\d,]*\.?\d*)/)
  if (!numMatch) return null

  const raw = numMatch[1].trim()
  const value = parseNumber(raw)
  if (value === null || value === 0) return null

  return { value, raw, snippet }
}

// ── Tax rate extraction ────────────────────────────────────────────────────────

function extractTaxRate(text: string): NumResult {
  // Look for percentage directly stated, e.g. "Effective tax rate  15.6%"
  const patterns = [
    /(effective\s+tax\s+rate)\s*[\s\n\r:$%]*(\d+\.?\d*)\s*%/im,
    /(income\s+tax\s+rate)\s*[\s\n\r:$%]*(\d+\.?\d*)\s*%/im,
  ]
  for (const p of patterns) {
    const m = p.exec(text)
    if (!m) continue
    const n = parseFloat(m[2])
    if (isNaN(n)) continue
    const snippetStart = Math.max(0, text.lastIndexOf('\n', m.index) + 1)
    const snippetEnd   = text.indexOf('\n', m.index + m[0].length)
    const snippet = text.slice(snippetStart, snippetEnd === -1 ? snippetStart + 120 : snippetEnd).trim().slice(0, 120)
    return { value: n / 100, raw: m[2] + '%', snippet }
  }
  return null
}

// ── Field definitions ──────────────────────────────────────────────────────────
// Multiple label patterns per field, tried in order of specificity.
// First successful extraction wins.

const LABEL_PATTERNS: Record<string, RegExp[]> = {
  revenue: [
    // ^ + m flag = only match at line start (table rows, not narrative)
    /^\s*total\s+net\s+sales\b/im,
    /^\s*total\s+revenues?\b/im,
    /^\s*net\s+revenues?\b/im,
    /^\s*net\s+sales\b/im,
    /^\s*revenues?\b/im,
  ],
  operatingIncome: [
    /^\s*operating\s+income\b/im,
    /^\s*income\s+from\s+operations\b/im,
  ],
  ebitda: [
    /^\s*adjusted\s+ebitda\b/im,
    /^\s*ebitda\b/im,
    /\badjusted\s+ebitda\b/im,
    /\bebitda\b/im,
  ],
  da: [
    /^\s*depreciation\s+and\s+amortization\b/im,
    /^\s*depreciation\s*[&]\s*amortization\b/im,
    /\bdepreciation\s+and\s+amortization\b/im,
  ],
  capex: [
    // Cash flow statement lines — these start with whitespace before the label
    /^\s*payments\s+for\s+acquisition\s+of\s+property/im,
    /^\s*purchases?\s+of\s+property,?\s*plant\s+and\s+equipment/im,
    /^\s*capital\s+expenditures\b/im,
    /^\s*capex\b/im,
    // Fallback: anywhere in text
    /payments\s+for\s+acquisition\s+of\s+property/im,
    /purchases?\s+of\s+property,?\s*plant\s+and\s+equipment/im,
    /capital\s+expenditures/im,
  ],
  netIncome: [
    /^\s*net\s+income\b/im,
    /^\s*net\s+earnings\b/im,
    /\bnet\s+income\b/im,
    /\bnet\s+earnings\b/im,
  ],
  interestExpense: [
    /^\s*interest\s+expense,?\s+net\b/im,
    /^\s*interest\s+expense\b/im,
    /\binterest\s+expense,?\s+net\b/im,
    /\binterest\s+expense\b/im,
  ],
}

// ── Main export ────────────────────────────────────────────────────────────────

export function extractFinancials(text: string): ExtractedFinancials {
  const { inThousands } = detectScale(text)

  function scale(v: number, raw: string): number {
    if (hasExplicitScaleSuffix(raw)) return v   // B/M/K already applied
    if (inThousands) return v * 0.001            // doc is in thousands → convert to $M
    return v                                     // doc is in millions (or unscaled) → keep
  }

  const result: ExtractedFinancials = {
    revenue:         { value: null, snippet: '' },
    ebitda:          { value: null, snippet: '' },
    da:              { value: null, snippet: '' },
    capex:           { value: null, snippet: '' },
    netIncome:       { value: null, snippet: '' },
    interestExpense: { value: null, snippet: '' },
    taxRate:         { value: null, snippet: '' },
    confidence:      'low',
    inThousands,
  }

  // ── Extract each numeric field via window scan ─────────────────────────────

  const numericFields = ['revenue', 'operatingIncome', 'ebitda', 'da', 'capex', 'netIncome', 'interestExpense'] as const
  const extracted: Partial<Record<typeof numericFields[number], NumResult>> = {}

  for (const field of numericFields) {
    const patterns = LABEL_PATTERNS[field] ?? []
    for (const labelPat of patterns) {
      const res = extractAfterLabel(text, labelPat)
      if (res) {
        extracted[field] = { ...res, value: Math.abs(scale(res.value, res.raw)) }
        break
      }
    }
  }

  // Capex is a cash outflow — force positive
  if (extracted.capex) extracted.capex = { ...extracted.capex, value: Math.abs(extracted.capex.value) }
  if (extracted.interestExpense) extracted.interestExpense = { ...extracted.interestExpense, value: Math.abs(extracted.interestExpense.value) }

  // ── Apply to result ───────────────────────────────────────────────────────

  if (extracted.revenue)         result.revenue         = { value: extracted.revenue.value,         snippet: extracted.revenue.snippet }
  if (extracted.da)              result.da              = { value: extracted.da.value,              snippet: extracted.da.snippet }
  if (extracted.capex)           result.capex           = { value: extracted.capex.value,           snippet: extracted.capex.snippet }
  if (extracted.netIncome)       result.netIncome       = { value: extracted.netIncome.value,       snippet: extracted.netIncome.snippet }
  if (extracted.interestExpense) result.interestExpense = { value: extracted.interestExpense.value, snippet: extracted.interestExpense.snippet }

  // EBITDA: prefer explicit, fall back to operatingIncome + D&A
  if (extracted.ebitda) {
    result.ebitda = { value: extracted.ebitda.value, snippet: extracted.ebitda.snippet }
  } else if (extracted.operatingIncome && extracted.da) {
    const ebitda = extracted.operatingIncome.value + extracted.da.value
    result.ebitda = {
      value:   ebitda,
      snippet: `Derived: Operating income ${extracted.operatingIncome.snippet} + D&A ${extracted.da.snippet}`,
    }
  }

  // ── Tax rate ──────────────────────────────────────────────────────────────

  const taxRes = extractTaxRate(text)
  if (taxRes) result.taxRate = { value: taxRes.value, snippet: taxRes.snippet }

  // ── Sanity filter: reject implausibly small values (< $0.1M) ─────────────
  // Prevents picking up footnote numbers, page numbers, etc.

  const MIN_VALID = 0.1
  const fieldsToSanitize: Array<keyof Omit<ExtractedFinancials, 'confidence' | 'inThousands' | 'taxRate'>> = [
    'revenue', 'ebitda', 'da', 'capex', 'netIncome', 'interestExpense',
  ]
  for (const f of fieldsToSanitize) {
    if (result[f].value !== null && Math.abs(result[f].value!) < MIN_VALID) {
      result[f] = { value: null, snippet: result[f].snippet }
    }
  }

  // ── Confidence scoring ────────────────────────────────────────────────────

  const scoreFields: Array<keyof Omit<ExtractedFinancials, 'confidence' | 'inThousands'>> = [
    'revenue', 'ebitda', 'da', 'capex', 'netIncome', 'interestExpense', 'taxRate',
  ]
  const found = scoreFields.filter(k => result[k].value !== null).length
  result.confidence = found >= 4 ? 'high' : found >= 2 ? 'medium' : 'low'

  return result
}
