import { contextBridge, ipcRenderer } from 'electron'
import { electronAPI } from '@electron-toolkit/preload'

const api = {
  exportPDF: (companySlug: string) => ipcRenderer.invoke('export-pdf', companySlug),
  parsePDF: (buffer: ArrayBuffer) => ipcRenderer.invoke('parse-pdf', buffer),
  deals: {
    getAll:  ()             => ipcRenderer.invoke('deals:get-all'),
    save:    (deal: unknown) => ipcRenderer.invoke('deals:save', deal),
    delete:  (id: string)   => ipcRenderer.invoke('deals:delete', id),
    export:  (id: string)   => ipcRenderer.invoke('deals:export', id),
    import:  (json: string) => ipcRenderer.invoke('deals:import', json),
  },
}

if (process.contextIsolated) {
  try {
    contextBridge.exposeInMainWorld('electron', electronAPI)
    contextBridge.exposeInMainWorld('api', api)
  } catch (error) {
    console.error(error)
  }
} else {
  // @ts-ignore
  window.electron = electronAPI
  // @ts-ignore
  window.api = api
}
