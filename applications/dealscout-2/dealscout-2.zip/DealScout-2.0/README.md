# DealScout 2.0

An offline LBO analyzer for private equity analysts, built as a macOS desktop app. It answers one question fast:
**"What needs to be true for this deal to work?"**

Everything runs on your own computer. There is no account, no AI service, no server and no network access: the
interface font is bundled, PDFs are read locally, and your deals are stored in a local file. Indicative estimates for
internal screening only; not investment advice.

## What it does

| Tab | What you get |
|---|---|
| **Standard LBO** | IRR, MOIC, entry EV, equity cheque, exit equity, an annual progression (EBITDA, EBIT, net income, levered FCF, interest, amortisation, cash sweep, debt, DSCR), a returns attribution waterfall and an exit-by-year table. |
| **Operating Model** | Revenue to levered FCF for each year of the hold, with per-year overrides. Switch "Link to LBO Model" on to drive the returns from it. |
| **IRR Map** | Set a target IRR and see the maximum entry multiple, the EBITDA growth needed, a verdict, a heatmap of IRR across entry multiple and growth, and a sensitivity table of entry against exit multiple. |
| **FCF Analysis** | Annual free cash flow with DSCR, cumulative FCF, FCF yield, interest cover, tax paid and cash sweep, with a plain-English read-out. |
| **Scenarios** | Save up to six scenarios, or generate bear, base and bull cases in one click, and compare them side by side. |

Also: **Import** (paste text or upload a PDF; revenue, EBITDA, D&A, capex, net income, interest and tax rate are pulled out
with rules and shown for you to accept or override), a **Deal Library** (up to 50 saved deals, compare, export and import
`.dealscout2` files), six **sector presets**, and **Export PDF** (A4 landscape).

## How it differs from DealScout

DealScout 2.0 is a smaller, sharper tool than the original DealScout web app. They are separate apps.

| | DealScout | DealScout 2.0 |
|---|---|---|
| **Question** | What is this company worth, and what price range makes sense? | What needs to be true for this LBO to work? |
| **Scope** | Broad first-pass valuation: DCF, LBO, trading comps, precedent transactions, NAV and sum of the parts, dividend discount models and more, blended on one football field with a suggested acquisition price range | One thing, in depth: LBO returns, the IRR map, free cash flow and debt service, scenarios |
| **Form** | Local web app (Python and Next.js) opened in your browser at 127.0.0.1 | Native desktop app (Electron), built for macOS |
| **AI** | Optional: connect Claude, OpenAI, Gemini and others to read documents and word the rationale | None. No keys, no usage costs, nothing leaves the computer |
| **Documents** | Reads PDF, Excel, Word, HTML, tagged filings and scans, with a review screen showing each value beside its source | Reads pasted text or a PDF with rules, and shows each detected value and its source snippet to accept or override |
| **Outputs** | Excel workbook with a live DCF, PDF tear sheet, PowerPoint one-pager, JSON | PDF export and `.dealscout2` deal files |
| **Setup** | uv and Node.js, then `./start.sh` | Node.js, then `npm install` and `npm run dev`, or build a `.dmg` |

## Run it

Needs Node.js 18 or later.

```bash
npm install
npm run dev
```

## Build the Mac app

```bash
npm run package
```

This writes a `.dmg` to `dist/`. The build targets Apple Silicon and Intel. Add a `resources/icon.icns` first for a
custom app icon (without one, the default Electron icon is used). The app is not code-signed, so macOS may ask you to
confirm opening it the first time.

## Model assumptions

- One debt tranche with a mandatory amortisation (a percentage of the initial debt each year) plus a cash sweep of all
  free cash above it, so interest, tax, D&A and capex all affect debt at exit and therefore IRR.
- Exit at an EV/EBITDA multiple; no tax on exit; transaction fees are added to the equity cost.
- Back-solving for the maximum entry multiple and the required growth uses a binary search.

## Project structure

```
src/main/           Electron main process: window, PDF export, PDF text extraction, deal storage
src/preload/        Bridge between the app and the main process
src/renderer/src/
  engine/           lbo.ts (calculation), solver.ts (IRR map back-solver), extractor.ts (text extraction)
  components/       One file per tab and panel
  assets/fonts/     Bundled Outfit font (SIL Open Font License)
```

Licence for the bundled Outfit font: SIL Open Font License 1.1.

© 2026 Oscar McKenna Brown. All rights reserved.
