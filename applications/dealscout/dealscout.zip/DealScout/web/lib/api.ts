// Thin fetch wrapper for the local FastAPI server. All data comes from /api on the same origin.

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public code?: string,
    public fieldErrors?: Record<string, string>,
  ) {
    super(message)
  }
}

interface ValidationIssue {
  loc?: (string | number)[]
  msg?: string
}

function describe(detail: unknown): { message: string; fields?: Record<string, string> } {
  if (typeof detail === "string") return { message: detail }
  if (Array.isArray(detail)) {
    const fields: Record<string, string> = {}
    const messages: string[] = []
    for (const issue of detail as ValidationIssue[]) {
      const field = issue.loc?.filter((p) => p !== "body").join(".") ?? ""
      const msg = (issue.msg ?? "Invalid value").replace(/^Value error, /, "")
      if (field) fields[field] = msg
      messages.push(field ? `${field}: ${msg}` : msg)
    }
    return { message: messages.join("; ") || "The request was not valid.", fields }
  }
  return { message: "The request failed." }
}

export async function api<T>(path: string, init: RequestInit & { json?: unknown } = {}): Promise<T> {
  const { json, headers, ...rest } = init
  let response: Response
  try {
    response = await fetch(path, {
      ...rest,
      headers: { Accept: "application/json", ...(json !== undefined ? { "Content-Type": "application/json" } : {}), ...headers },
      body: json !== undefined ? JSON.stringify(json) : rest.body,
    })
  } catch {
    throw new ApiError(0, "Can't reach the DealScout server. Is it still running in your terminal?", "offline")
  }
  if (response.status === 204) return undefined as T
  const text = await response.text()
  let body: Record<string, unknown> = {}
  try {
    body = text ? (JSON.parse(text) as Record<string, unknown>) : {}
  } catch {
    body = { detail: text.slice(0, 300) }
  }
  if (!response.ok) {
    const { message, fields } = describe(body.detail)
    throw new ApiError(response.status, message, (body.code as string | undefined) ?? undefined, fields)
  }
  return body as T
}
