// Types mirroring the FastAPI responses (api/src/dealscout_api). Keep in sync with the routes.

export type Perspective = "financial_sponsor" | "strategic"
export type DealMode = "quick" | "detailed"

export interface Deal {
  id: string
  name: string
  country: string
  country_name: string
  sector: string
  sector_name: string
  industry: string | null
  listed: boolean
  ticker: string | null
  reporting_currency: string
  analysis_currency: string
  valuation_date: string
  perspective: Perspective
  mode: DealMode
  status: string
  sector_template: string
  notes: string | null
  archived: boolean
  created_at: string
  updated_at: string
}

export interface DealInput {
  name: string
  country: string
  sector: string
  industry: string | null
  listed: boolean
  ticker: string | null
  reporting_currency: string
  analysis_currency: string | null
  valuation_date: string | null
  perspective: Perspective
  mode: DealMode
  notes?: string | null
}

export interface Country {
  code: string
  name: string
  currency: string
  standards: string[]
}

export interface Currency {
  code: string
  name: string
  decimals: number
}

export interface Sector {
  id: string
  name: string
  template: string
  profile: string
  industries: string[]
}

export interface Disclaimers {
  version: string
  short: string
  ai_report_notice: string
  print_footer: string
  full: string[]
}

export interface Meta {
  version: string
  disclaimers: Disclaimers
  reference: { countries: Country[]; currencies: Currency[]; sectors: Sector[] }
  taxonomy_version: string
}

export interface AuditEvent {
  id: number
  deal_id: string | null
  action: string
  actor: string
  detail: Record<string, unknown>
  at: string
}

export interface Preferences {
  user_name: string
  ai_enabled: boolean
  ai_send_scope: "located_pages" | "full_documents"
  monthly_spend_cap_usd: number | null
  retention_days: number | null
  defaults_stale_days: number
  number_locale: string
  onboarding_done: boolean
}

export interface SettingsResponse {
  preferences: Preferences
  data_folder: string
  key_storage: { backend: "keychain" | "file"; detail: string }
  env: { disable_ai: boolean; max_upload_mb: number }
}

export type ProviderField = "api_key" | "model" | "base_url" | "endpoint" | "deployment" | "api_version"

export interface ProviderSpec {
  id: string
  label: string
  tagline: string
  fields: ProviderField[]
  key_required: boolean
  key_page_url: string | null
  data_policy_url: string | null
  data_location_note: string
  env_vars: Record<string, string>
  default_model: string | null
  notes: string[]
  implemented: boolean
  available_in: string | null
  accuracy_tier: "high" | "medium" | "limited" | "untested"
}

export interface AIConnection {
  provider: string
  model: string | null
  base_url: string | null
  endpoint: string | null
  deployment: string | null
  api_version: string | null
  is_active: boolean
  is_writing: boolean
  last_test_at: string | null
  last_test_code: string | null
  last_test_message: string | null
  updated_at: string
}

export interface ProviderState {
  spec: ProviderSpec
  connection: AIConnection | null
  key: { present: boolean; source: "keychain" | "file" | "env" | "none"; last4: string | null }
  env_model: string | null
}

export interface AIStatus {
  enabled: boolean
  disabled_reason: string | null
  connected: boolean
  provider: string | null
  provider_label: string | null
  model: string | null
  last_test_code: string | null
  month_spend_usd: number
  monthly_spend_cap_usd: number | null
}

export interface ProvidersResponse {
  providers: ProviderState[]
  status: AIStatus
  key_storage?: { backend: string; detail: string }
}

export interface ConnectionResult {
  ok: boolean
  provider: string
  model: string | null
  code: "ok" | "invalid_key" | "out_of_credit" | "model_unavailable" | "rate_limited" | "unreachable" | "error"
  message: string
}

export interface ModelInfo {
  id: string
  display_name: string
  input_price_per_mtok: number | null
  output_price_per_mtok: number | null
  recommended: boolean
  capabilities: {
    native_pdf: boolean
    image_input: boolean
    structured_output: "strict" | "best_effort" | "none"
    max_context_tokens: number | null
  }
}

export interface UsageResponse {
  summary: {
    provider: string
    model: string
    purpose: string
    calls: number
    input_tokens: number
    output_tokens: number
    estimated_cost_usd: number | null
  }[]
  recent: unknown[]
}

// ── Milestone 2: financials, analysis, valuation ─────────────────────────────
export interface Period {
  id: string
  key: string
  kind: string
  fiscal_year: number | null
  end_date: string | null
  label: string | null
}

export interface GridCell {
  value: number
  kind: "entered" | "computed"
  source?: string
  updated_by?: string
  updated_at?: string
  entered_text?: string | null
  formula?: string | null
  note?: string | null
}

export interface GridRow {
  concept_id: string
  name: string
  definition: string
  sign: "positive" | "negative" | "either"
  unit: string
  aggregation: "leaf" | "sum" | "formula"
  indent: number
  formula: string | null
  cells: Record<string, GridCell>
}

export interface CheckResult {
  check_id: string
  label: string
  period_id: string
  status: "pass" | "fail" | "not_applicable"
  severity: "error" | "warning" | "info"
  expected: number | null
  actual: number | null
  difference: number | null
  tolerance: number | null
  message: string
}

export interface LtmPeriod {
  key: string
  label: string
  kind: "ltm"
  virtual: true
  inputs: string[]
}

export interface FinancialsResponse {
  periods: Period[]
  ltm_periods: LtmPeriod[]
  statements: { id: string; label: string; rows: GridRow[] }[]
  entry: { scale: number; decimal_hint: "." | "," | null; fiscal_year_end: string }
  currency: string
  checks: CheckResult[]
  check_summary: { pass: number; fail: number; not_applicable: number; errors: number; warnings: number }
  quick_scan: { minimum: string[]; missing: string[]; period: string | null }
}

export interface CellChangeInput {
  concept_id: string
  period_key: string
  value: number | null
  entered_text?: string | null
  reason?: string | null
}

export interface ValueChange {
  id: number
  old_value: number | null
  new_value: number | null
  old_source: string | null
  new_source: string | null
  reason: string | null
  actor: string
  at: string
}

export interface Derivation {
  kind: string
  formula: string | null
  inputs: { name: string; value: number | null; label?: string | null; note?: string | null }[]
  note: string | null
}

export interface Ratio {
  ratio_id: string
  label: string
  group: "growth" | "profitability" | "returns" | "cash" | "leverage" | "liquidity" | "efficiency" | "sector"
  period_id: string
  value: number | null
  unit: "pct" | "x" | "days" | "number" | "currency"
  definition: string
  higher_is_better: boolean | null
  derivation: Derivation
}

export interface AnalysisResponse {
  periods: string[]
  currency: string
  ratios: Ratio[]
  series: Record<string, Record<string, number | null>>
  revenue_cagr: { value: number | null; from: string | null; to: string | null }
  scores: { period: string | null; prior: string | null; items: ScoreResult[] }
  red_flags: RedFlag[]
  adjusted: AdjustedMetrics[]
  fx?: FxStatus
  /** narrative documents scanned for text-based warning signs */
  documents_scanned?: number
  /** sector KPIs for the deal's statement template (empty items for general corporates) */
  sector_kpis?: { template: string; label: string | null; items: Ratio[] }
  capital_structure?: CapitalStructure[]
}

export interface MaturityBucket {
  concept_id: string
  label: string
  amount: number | null
}

/** Capital structure and debt maturity profile at one balance-sheet date (engine `capital.py`). */
export interface CapitalStructure {
  period: string
  debt: number | null
  leases: number | null
  equity: number | null
  cash: number | null
  undrawn_facilities: number | null
  total_capital: number | null
  maturities: MaturityBucket[]
  maturities_total: number | null
  unallocated_debt: number | null
  liquidity_cover: number | null
}

export interface ResolvedAssumption {
  key: string
  label: string
  value: number | number[] | null
  source: "user" | "historical" | "default" | "convention" | "derived" | "missing"
  detail: string | null
  as_of: string | null
  stale: boolean
}

export interface Peer {
  name: string
  ticker?: string | null
  country?: string | null
  include: boolean
  market_cap?: number | null
  net_debt?: number | null
  enterprise_value?: number | null
  revenue?: number | null
  ebitda?: number | null
  ebit?: number | null
  net_income?: number | null
  book_equity?: number | null
  revenue_growth?: number | null
  ebitda_margin?: number | null
  // currency conversion and calendarisation (brief §7)
  currency?: string | null
  fiscal_year_end_month?: number | null
  revenue_next?: number | null
  ebitda_next?: number | null
  ebit_next?: number | null
  net_income_next?: number | null
  free_cash_flow_next?: number | null
  // EV/EBITDAR, PEG, EV/ARR, P/NAV and the current-year / next-year bases
  tangible_book_equity?: number | null
  free_cash_flow?: number | null
  rent_expense?: number | null
  eps_growth?: number | null
  arr?: number | null
  nav?: number | null
  revenue_cy?: number | null
  ebitda_cy?: number | null
  ebit_cy?: number | null
  net_income_cy?: number | null
  revenue_ny?: number | null
  ebitda_ny?: number | null
  ebit_ny?: number | null
  net_income_ny?: number | null
}

export type CompsBasis = "ltm" | "cy" | "ny"

export interface PeerStats {
  multiple_id: string
  label: string
  n: number
  values: Record<string, number>
  excluded: Record<string, string>
  min: number | null
  p25: number | null
  median: number | null
  mean: number | null
  p75: number | null
  max: number | null
  basis?: CompsBasis
}

export interface PeerSuggestion {
  name: string
  ticker: string | null
  exchange: string | null
  country: string | null
  reason: string | null
}

export interface PeerSuggestionsResponse {
  suggestions: PeerSuggestion[]
  source: string
  generated_at: string
  reasons_dropped: number
  note: string
}

export interface PeerCsvImport {
  provider: string
  peers: Peer[]
  quotes: { ticker: string; price: number | null; market_cap: number | null; currency: string | null; as_of: string | null; source: string }[]
  errors: { row: number; name: string | null; errors: string[] }[]
  warnings: string[]
}

export interface AssumptionsDoc {
  overrides: Record<string, unknown>
  peers: Peer[]
  notes: Record<string, string>
}

export interface MethodRange {
  method_id: string
  label: string
  equity_low: number
  equity_mid: number
  equity_high: number
  ev_low: number | null
  ev_mid: number | null
  ev_high: number | null
  weight: number
  included: boolean
  note: string | null
}

export interface PerShareRange {
  low: number
  mid: number
  high: number
}

export interface SensitivityTable {
  title: string
  row_label: string
  col_label: string
  rows: number[]
  cols: number[]
  values: (number | null)[][]
}

export interface ProjectionYear {
  label: string
  revenue: number
  revenue_growth: number
  ebitda: number
  ebitda_margin: number
  da: number
  ebit: number
  cash_taxes: number
  nopat: number
  capex: number
  change_in_nwc: number
  unlevered_fcf: number
  period_fraction: number
  discount_factor: number
  pv_fcf: number
}

export interface BridgeItem {
  key: string
  label: string
  amount: number
  included: boolean
  note: string | null
}

export interface ValuationResponse {
  deal: { id: string; name: string; currency: string; reporting_currency?: string; listed: boolean; sector: string; perspective: string }
  fx?: FxStatus
  peer_adjustments?: PeerAdjustment[]
  methods: MethodOutput[]
  market_points: MarketPoint[]
  dlom_applied: boolean
  normalisation: NormalisationSummary
  result: {
    base_period: string | null
    base_revenue: number | null
    base_ebitda: number | null
    tax_rate: number | null
    share_price: number | null
    assumptions: ResolvedAssumption[]
    missing: string[]
    wacc: null | {
      debt_to_equity: number
      unlevered_beta: number | null
      levered_beta: number
      cost_of_equity: number
      after_tax_cost_of_debt: number
      equity_weight: number
      debt_weight: number
      wacc: number
      derivation: Derivation
    }
    dcf: null | {
      projection: ProjectionYear[]
      sum_pv_fcf: number
      gordon: { method: string; value: number; pv: number; implied_cross_check: number | null }
      exit: { method: string; value: number; pv: number; implied_cross_check: number | null }
      terminal_method: string
      terminal_value_pv: number
      enterprise_value: number
      terminal_share_of_ev: number
      bridge: { enterprise_value: number; items: BridgeItem[]; net_debt_and_adjustments: number; equity_value: number }
      equity_value: number
      per_share: null | { value_per_share: number; diluted_shares: number; basic_shares: number }
      warnings: string[]
    }
    dcf_range: Record<string, number> | null
    comps: {
      multiple_id: string
      label: string
      target_metric: number | null
      multiple_low: number | null
      multiple_mid: number | null
      multiple_high: number | null
      equity_low: number | null
      equity_mid: number | null
      equity_high: number | null
      note: string | null
    }[]
    football_field: null | {
      methods: MethodRange[]
      weights_normalised: Record<string, number>
      blended_equity_low: number | null
      blended_equity_mid: number | null
      blended_equity_high: number | null
      blended_per_share: PerShareRange | null
      method_per_share: Record<string, PerShareRange>
      market_cap: number | null
      share_price: number | null
      warnings: string[]
    }
    market_cap: number | null
    warnings: string[]
  }
  sensitivities: SensitivityTable[]
  scenarios: null | {
    scenarios: ScenarioResult[]
    probability_weighted_ev: number
    probability_weighted_equity: number
  }
  /** why the scenarios could not be run (e.g. a shift pushes WACC below terminal growth) */
  scenarios_error?: string | null
  peer_stats: {
    multiple_id: string
    label: string
    n: number
    values: Record<string, number>
    excluded: Record<string, string>
    min: number | null
    p25: number | null
    median: number | null
    mean: number | null
    p75: number | null
    max: number | null
  }[]
  peer_stats_by_basis?: Partial<Record<CompsBasis, PeerStats[]>>
  comps_basis?: CompsBasis
  defaults: { version: string; as_of: string | null }
}

export interface PastePreview {
  periods: { key: string; kind: string; raw: string }[]
  scale: { factor: number; label: string; matched: string } | null
  rows: {
    label: string
    values: Record<string, number | null>
    concept_id: string | null
    ambiguous_numbers: boolean
    candidates: { id: string; name: string }[]
  }[]
  unmatched: number
  warnings: string[]
  concepts: { id: string; name: string; statement: string }[]
}

// ── Milestone 3: documents, extraction jobs, review ──────────────────────────
export type DocumentStatus = "uploaded" | "processing" | "processed" | "unsupported" | "paused" | "failed"

export interface LocatedStatement {
  page: number
  score: number
  consolidated: boolean | null
  reasons: string[]
}

export interface UnmappedRow {
  id: number
  label: string
  page: number
  statement: string
  values: Record<string, string>
  candidates: string[]
  reason: string
  scale_factor: number
}

export interface MissingItem {
  concept_id: string
  reason: string
}

export interface DocumentMeta {
  statements?: Record<string, LocatedStatement[]>
  warnings?: string[]
  periods?: string[]
  not_found?: MissingItem[]
  rejected?: MissingItem[]
  ai_used?: boolean
  decimal_hint?: string
  unmapped?: UnmappedRow[]
  entity_name?: string | null
  currency?: string | null
  report_member?: string | null
  tagged_facts?: number
  ocr_pages?: number
  page_size?: [number, number] | null
}

export interface DealDocument {
  id: string
  deal_id: string
  filename: string
  size_bytes: number
  sha256: string
  kind: string
  page_count: number
  scanned_pages: number
  language: string | null
  doc_type: string | null
  status: DocumentStatus
  job_id: string | null
  meta: DocumentMeta
  uploaded_at: string
  uploaded_by: string
  job: Pick<Job, "id" | "status" | "message" | "error_code" | "steps"> | null
}

export interface JobStep {
  key: string
  label: string
  status: "pending" | "running" | "done" | "failed" | "skipped"
  detail: string | null
}

export interface Job {
  id: string
  kind: string
  status: "queued" | "running" | "paused" | "done" | "failed"
  steps: JobStep[]
  message: string | null
  error_code: string | null
  deal_id: string | null
  updated_at: string
}

export interface ReviewItem {
  id: number
  document_id: string
  concept_id: string
  concept_name: string
  statement: string
  unit: string
  period_key: string
  value: number
  value_as_written: string
  label: string
  page: number | null
  bbox: [number, number, number, number] | null
  cell_ref: string | null
  sheet: string | null
  scale_factor: number
  scale_label: string | null
  confidence: number
  method: string
  mapping: string
  provider: string | null
  model: string | null
  rationale: string | null
  notes: string[]
  status: "pending" | "accepted" | "rejected"
  decided_by: string | null
  decided_at: string | null
  current_value: number | null
  current_source: string | null
  conflicts: boolean
  superseded_by: string | null
}

export interface CrossDocumentDifference {
  concept_id: string
  period_key: string
  preferred_item_id: number
  preferred_document: string
  values: { item_id: number; document: string; value: number; value_as_written: string; status: string }[]
}

export interface ReviewResponse {
  documents: DealDocument[]
  items: ReviewItem[]
  checks: CheckResult[]
  cross_document: CrossDocumentDifference[]
  core: { concept_id: string; name: string }[]
  counts?: Record<string, number>
}

export interface ReviewAction {
  item_id: number
  action: "accept" | "reject" | "edit"
  value?: number
  reason?: string
}

export interface TaxonomyConcept {
  id: string
  name: string
  statement: string
  definition: string
  sign: "positive" | "negative" | "either"
  unit: string
  aggregation: string
}

// ── Milestone 5: valuation methods, scores, normalisation ────────────────────
export type MethodGroup = "lbo" | "precedents" | "nav" | "fi" | "strategic" | "other"

export interface MethodOutput<R = unknown> {
  id: string
  label: string
  group: MethodGroup
  status: "ready" | "needs_input" | "error"
  missing: string[]
  message: string | null
  result: R | null
  range: MethodRange | null
}

export interface MarketPoint {
  label: string
  price: number | null
  equity: number
}

export interface Adjustment {
  id: string
  period_key: string
  label: string
  category: "restructuring" | "impairment" | "litigation" | "disposal_gain" | "transaction_costs" | "other"
  amount: number
  affects_ebitda: boolean | null
  confirmed: boolean
  source: "user" | "ai_suggested"
  rationale: string | null
  document_id: string | null
  page: number | null
  value_as_written: string | null
}

export interface AdjustedMetrics {
  period: string
  reported_ebitda: number | null
  adjusted_ebitda: number | null
  reported_ebit: number | null
  adjusted_ebit: number | null
  ebitda_adjustment: number
  ebit_adjustment: number
  items: Adjustment[]
}

export interface NormalisationSummary {
  use_adjusted_ebitda: boolean
  applied: boolean
  base_period: string | null
  metrics: AdjustedMetrics | null
  pending_suggestions: number
}

export interface ScoreResult {
  name: string
  variant: string | null
  value: number | null
  zone: string | null
  components: Record<string, number | null>
  missing: string[]
  note: string | null
}

export interface FlagEvidence {
  document_id: string
  filename: string
  page: number
  snippet: string
}

export interface RedFlag {
  id: string
  signal: string
  period: string
  metric: number | null
  threshold: string
  severity: "high" | "medium" | "none"
  explanation: string
  /** "document": found in the text of an uploaded document (evidence carries page and quote) */
  source?: "figures" | "document"
  evidence?: FlagEvidence[]
}

export type TrancheKind =
  | "revolver"
  | "term_loan_a"
  | "term_loan_b"
  | "senior_notes"
  | "high_yield"
  | "mezzanine"
  | "seller_note"
  | "other"

export interface Tranche {
  name: string
  kind: TrancheKind
  size_x_ebitda: number | null
  amount: number | null
  rate_type: "fixed" | "floating"
  fixed_rate: number | null
  margin: number | null
  base_rate_floor: number
  amortization_pct: number
  pik: boolean
  sweep: boolean | null
  priority: number
  fee_pct: number
  commitment: number | null
}

export interface OperatingYear {
  label: string
  revenue: number
  ebitda: number
  da: number
  capex: number
  change_in_nwc: number
}

export interface LBOSettings {
  entry_multiple: number | null
  entry_price_per_share: number | null
  transaction_fee_pct: number
  minimum_cash: number
  tranches: Tranche[]
  rollover_equity: number
  management_promote_pct: number
  base_rate: number | null
  interest_on_average: boolean
  cash_sweep_pct: number
  exit_year: number | null
  exit_multiple: number | null
  exit_cost_pct: number
  dividend_recap_year: number | null
  dividend_recap_x_ebitda: number
  max_leverage: number | null
  min_interest_coverage: number | null
  target_irr: number | null
  target_moic: number | null
  sponsor_case: OperatingYear[] | null
}

export interface Transaction {
  announced: string
  target: string
  acquirer: string
  country: string | null
  sector: string | null
  ev: number | null
  revenue: number | null
  ebitda: number | null
  ebit: number | null
  ev_revenue: number | null
  ev_ebitda: number | null
  ev_ebit: number | null
  premium_paid: number | null
  stake_acquired: number | null
  consideration: "cash" | "stock" | "mixed" | "unknown"
  include: boolean
  source: string
}

export interface PrecedentSettings {
  transactions: Transaction[]
  filters: { since: string | null; countries: string[]; min_ev: number | null; max_ev: number | null; half_life_years: number | null }
  multiple: "ev_revenue" | "ev_ebitda" | "ev_ebit"
}

export interface NAVLine {
  name: string
  side: "asset" | "liability"
  book_value: number
  method: "book" | "appraisal" | "cap_rate" | "multiple" | "transaction"
  fair_value: number | null
  noi: number | null
  cap_rate: number | null
  metric: number | null
  multiple: number | null
  taxable: boolean
}

export interface Segment {
  name: string
  metric_label: string
  metric: number | null
  multiple_low: number | null
  multiple_mid: number | null
  multiple_high: number | null
  value: number | null
}

export interface RecoveryLine {
  name: string
  book_value: number
  recovery_low: number
  recovery_high: number
}

export interface ReplacementLine {
  name: string
  replacement_cost: number
  physical_obsolescence: number
  functional_obsolescence: number
  economic_obsolescence: number
}

export interface MethodsDoc {
  lbo: LBOSettings
  precedents: PrecedentSettings
  nav: { lines: NAVLine[]; deferred_tax_on_gains: boolean; tax_rate: number | null; holding_discount: number }
  sotp: {
    segments: Segment[]
    non_core_assets: number
    corporate_costs: number
    corporate_cost_multiple: number
    conglomerate_discount: number
  }
  fi: {
    ddm: null | { current_dividend: number | null; high_growth: number; years: number; terminal_growth: number | null; cost_of_equity: number | null }
    residual_income: null | { roe: number[]; payout_ratio: number; terminal_growth: number; cost_of_equity: number | null }
    fcfe: null | { net_income: number[]; net_borrowing: number[] | null; terminal_growth: number | null; cost_of_equity: number | null }
    apv: null | {
      unlevered_cost_of_equity: number | null
      debt_balances: number[] | null
      cost_of_debt: number | null
      expected_distress_cost: number
    }
    ptbv_low: number | null
    ptbv_mid: number | null
    ptbv_high: number | null
  }
  synergies: null | {
    cost_synergies: number
    revenue_synergies: number
    revenue_synergy_margin: number
    phasing: number[]
    integration_costs: number[]
    probability: number
    share_paid_away: number
    discount_rate: number | null
    terminal_growth: number | null
  }
  accretion: null | {
    acquirer_net_income: number
    acquirer_shares: number
    acquirer_share_price: number
    purchase_equity_value: number | null
    cash_share: number
    debt_share: number
    stock_share: number
    interest_on_new_debt: number
    foregone_interest_on_cash: number
    amortisation_of_intangibles: number
    transaction_costs: number
    use_synergies: boolean
  }
  liquidation: { assets: RecoveryLine[]; wind_down_costs: number }
  replacement: { lines: ReplacementLine[] }
  dlom: null | { low: number; mid: number; high: number; applies_to: "all_methods" | "market_methods" }
  market: { high_52w: number | null; low_52w: number | null; vwap_30d: number | null; vwap_90d: number | null; analyst_targets: number[] }
  normalisation: { adjustments: Adjustment[]; use_adjusted_ebitda: boolean }
  premium: null | { low: number; high: number; source: string }
  rationale: Record<string, unknown> | null
  scenarios: ScenarioDef[]
}

export type MethodSection = keyof MethodsDoc

export interface TrancheYear {
  name: string
  opening: number
  drawn: number
  interest_cash: number
  interest_pik: number
  mandatory: number
  sweep: number
  closing: number
  rate: number
}

export interface LBOScheduleYear {
  label: string
  ebitda: number
  capex: number
  change_in_nwc: number
  cash_taxes: number
  operating_cash_flow: number
  cash_interest: number
  pik_interest: number
  mandatory_repayment: number
  sweep: number
  revolver_draw: number
  dividend: number
  closing_cash: number
  total_debt: number
  net_debt: number
  leverage: number | null
  interest_coverage: number | null
  tranches: TrancheYear[]
  breaches: string[]
}

export interface LBOReturns {
  equity_invested: number
  proceeds: number
  irr: number | null
  moic: number | null
  cash_flows: number[]
}

export interface MaxPrice {
  target_irr: number
  target_moic: number | null
  entry_multiple: number | null
  entry_ev: number | null
  equity_purchase_price: number | null
  note: string | null
}

export interface LBOResultPayload {
  case: {
    entry_ev: number
    entry_multiple: number
    equity_purchase_price: number
    sources: { label: string; amount: number }[]
    uses: { label: string; amount: number }[]
    total_debt_at_close: number
    leverage_at_close: number
    schedule: LBOScheduleYear[]
    exit_multiple: number
    exit_ev: number
    exit_net_debt: number
    exit_equity: number
    sponsor: LBOReturns
    rollover: LBOReturns | null
    covenant_breaches: string[]
    warnings: string[]
  }
  max_price: MaxPrice
  band: { low: MaxPrice; high: MaxPrice }
  sensitivities: SensitivityTable[]
  inputs: {
    entry_ev: number
    entry_multiple: number
    entry_source: "price_per_share" | "multiple" | "dcf"
    base_rate: number | null
    target_irr: number
    target_moic: number | null
    exit_year: number
    operating_case: "sponsor" | "dcf"
  }
  notes: string[]
}


// ── Milestone 6: acquisition price ───────────────────────────────────────────
export interface SuitabilityRow {
  method_id: string
  label: string
  relevance: "primary" | "secondary" | "reference" | "not_suitable"
  weight: number
  suggested_weight: number
  overridden: boolean
  available: boolean
  normalised_weight: number | null
  reason: string
}

export interface PriceCheck {
  label: string
  status: "pass" | "warn" | "fail" | "n/a"
  detail: string
}

export interface RecommendationResponse {
  deal: { id: string; currency: string; reporting_currency?: string; listed: boolean; perspective: string }
  fx?: FxStatus
  suitability: SuitabilityRow[]
  recommendation: null | {
    equity_low: number
    equity_mid: number
    equity_high: number
    per_share: [number, number, number] | null
    ev_low: number
    ev_mid: number
    ev_high: number
    implied: Record<string, [number | null, number | null, number | null]>
    premium_to_market: [number, number, number] | null
    premium_to_vwap: [number, number, number] | null
    checks: PriceCheck[]
    bridge_at_mid: BridgeItem[]
    high_end_method: string | null
    synergy_paid_away: number | null
  }
  data_quality: { score: number; grade: "A" | "B" | "C" | "D"; components: Record<string, number>; notes: string[] }
  rationale: null | {
    bullets: string[]
    risks: string[]
    high_end: string[]
    source: string
    generated_at: string | null
    rejected: number
    stale: boolean
    previous_source?: string | null
  }
  football_field: ValuationResponse["result"]["football_field"]
  market_points: MarketPoint[]
  premium: null | { low: number; high: number; source: string }
}

// ── currency conversion (brief §7) ────────────────────────────────────────────
export interface FxRate {
  rate: number
  as_of: string
  source: string
}

export interface PeriodRates {
  period_id: string
  average: FxRate | null
  closing: FxRate | null
}

export interface PeerRate extends FxRate {
  currency: string
}

export interface FxStatus {
  from: string
  to: string
  needed: boolean
  converted: boolean
  currency: string
  notes: string[]
  missing: { period_id: string; kind: "average" | "closing"; concepts: string[] }[]
  message: string | null
}

export interface FxDoc {
  reporting_currency: string
  analysis_currency: string
  needs_conversion: boolean
  periods: { key: string; end_date: string | null; needs: ("average" | "closing")[] }[]
  rates: PeriodRates[]
  peer_rates: PeerRate[]
  peer_currencies: string[]
  missing_peer_currencies: string[]
  status: FxStatus
}

export interface PeerAdjustment {
  name: string
  currency: string | null
  converted: boolean
  fx_note: string | null
  missing_rate: boolean
  calendarised: boolean
  calendar_note: string | null
  weights: [number, number] | null
}

// ── custom DCF scenarios ─────────────────────────────────────────────────────
export interface ScenarioDef {
  name: string
  probability: number
  growth_shift: number
  margin_shift: number
  wacc_shift: number
  exit_multiple_shift: number
  terminal_growth_shift: number
}

export interface ScenarioResult {
  name: string
  probability: number
  enterprise_value: number
  equity_value: number
  wacc?: number | null
  terminal_growth?: number | null
  exit_multiple?: number | null
}

// ── saved versions of a deal ─────────────────────────────────────────────────
export interface VersionResults {
  dcf_enterprise_value: number | null
  blended_equity_low: number | null
  blended_equity_mid: number | null
  blended_equity_high: number | null
  methods: string[]
}

export interface DealVersion {
  id: string
  name: string
  note: string | null
  kind: "manual" | "before_restore"
  created_at: string
  created_by: string
  results: VersionResults
  counts: { periods: number; values: number }
}

export interface VersionComparison {
  version: DealVersion
  periods: { added: string[]; removed: string[] }
  values: {
    period_key: string
    concept_id: string
    label: string
    version: number | null
    current: number | null
    change: number | null
  }[]
  values_total: number
  inputs: { section: string; key: string; version: unknown; current: unknown }[]
  inputs_total: number
  results: { key: string; version: number | null; current: number | null; change: number | null; change_pct: number | null }[]
  methods: { version: string[]; current: string[] }
}
