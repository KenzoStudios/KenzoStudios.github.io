"use client"

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"

import { api } from "@/lib/api"
import type {
  AIStatus,
  AnalysisResponse,
  AssumptionsDoc,
  CellChangeInput,
  FinancialsResponse,
  FxDoc,
  PastePreview,
  ValuationResponse,
  ValueChange,
  AuditEvent,
  ConnectionResult,
  Deal,
  DealDocument,
  Job,
  MethodSection,
  RecommendationResponse,
  MethodsDoc,
  ReviewAction,
  ReviewResponse,
  DealVersion,
  VersionComparison,
  TaxonomyConcept,
  DealInput,
  Meta,
  ModelInfo,
  Preferences,
  ProvidersResponse,
  SettingsResponse,
  UsageResponse,
  PeerCsvImport,
  PeerSuggestionsResponse,
} from "@/lib/types"

export const keys = {
  meta: ["meta"] as const,
  deals: (params: DealFilters) => ["deals", params] as const,
  deal: (id: string) => ["deal", id] as const,
  audit: (id: string) => ["deal", id, "audit"] as const,
  settings: ["settings"] as const,
  providers: ["ai", "providers"] as const,
  aiStatus: ["ai", "status"] as const,
  models: (provider: string) => ["ai", "models", provider] as const,
  usage: ["ai", "usage"] as const,
}

export interface DealFilters {
  q?: string
  sector?: string
  country?: string
  listed?: "all" | "listed" | "private"
  archived?: boolean
  sort?: "updated" | "name" | "created"
}

function dealQuery(f: DealFilters): string {
  const params = new URLSearchParams()
  if (f.q) params.set("q", f.q)
  if (f.sector) params.set("sector", f.sector)
  if (f.country) params.set("country", f.country)
  if (f.listed && f.listed !== "all") params.set("listed", String(f.listed === "listed"))
  if (f.archived) params.set("archived", "true")
  if (f.sort) params.set("sort", f.sort)
  const qs = params.toString()
  return qs ? `?${qs}` : ""
}

export const useMeta = () =>
  useQuery({ queryKey: keys.meta, queryFn: () => api<Meta>("/api/meta"), staleTime: Infinity })

export const useDeals = (filters: DealFilters) =>
  useQuery({
    queryKey: keys.deals(filters),
    queryFn: () => api<{ items: Deal[]; total: number }>(`/api/deals${dealQuery(filters)}`),
    placeholderData: (previous) => previous,
  })

export const useDeal = (id: string | null) =>
  useQuery({ queryKey: keys.deal(id ?? ""), queryFn: () => api<Deal>(`/api/deals/${id}`), enabled: !!id })

export const useDealAudit = (id: string) =>
  useQuery({ queryKey: keys.audit(id), queryFn: () => api<AuditEvent[]>(`/api/deals/${id}/audit`) })

export function useDealMutations() {
  const qc = useQueryClient()
  const invalidate = () => qc.invalidateQueries({ queryKey: ["deals"] })
  return {
    create: useMutation({
      mutationFn: (input: DealInput) => api<Deal>("/api/deals", { method: "POST", json: input }),
      onSuccess: invalidate,
    }),
    update: useMutation({
      mutationFn: ({ id, changes }: { id: string; changes: Partial<DealInput> & { archived?: boolean } }) =>
        api<Deal>(`/api/deals/${id}`, { method: "PATCH", json: changes }),
      onSuccess: (deal) => {
        qc.setQueryData(keys.deal(deal.id), deal)
        qc.invalidateQueries({ queryKey: keys.audit(deal.id) })
        invalidate()
      },
    }),
    duplicate: useMutation({
      mutationFn: (id: string) => api<Deal>(`/api/deals/${id}/duplicate`, { method: "POST" }),
      onSuccess: invalidate,
    }),
    remove: useMutation({
      mutationFn: (id: string) => api<void>(`/api/deals/${id}`, { method: "DELETE" }),
      onSuccess: (_, id) => {
        qc.removeQueries({ queryKey: keys.deal(id) })
        invalidate()
      },
    }),
  }
}

export const useSettings = () =>
  useQuery({ queryKey: keys.settings, queryFn: () => api<SettingsResponse>("/api/settings") })

export function useSavePreferences() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (changes: Partial<Preferences>) => api<Preferences>("/api/settings", { method: "PATCH", json: changes }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: keys.settings })
      qc.invalidateQueries({ queryKey: ["ai"] })
    },
  })
}

export const useProviders = () =>
  useQuery({ queryKey: keys.providers, queryFn: () => api<ProvidersResponse>("/api/ai/providers") })

export const useAIStatus = () =>
  useQuery({ queryKey: keys.aiStatus, queryFn: () => api<AIStatus>("/api/ai/status"), staleTime: 30_000 })

export const useModels = (provider: string, enabled: boolean) =>
  useQuery({
    queryKey: keys.models(provider),
    queryFn: () => api<ModelInfo[]>(`/api/ai/connections/${provider}/models`),
    enabled,
    retry: false,
    staleTime: 5 * 60_000,
  })

export const useUsage = () => useQuery({ queryKey: keys.usage, queryFn: () => api<UsageResponse>("/api/ai/usage") })

export function useAIMutations() {
  const qc = useQueryClient()
  const refresh = () => qc.invalidateQueries({ queryKey: ["ai"] })
  return {
    save: useMutation({
      mutationFn: ({ provider, body }: { provider: string; body: Record<string, unknown> }) =>
        api<ProvidersResponse>(`/api/ai/connections/${provider}`, { method: "PUT", json: body }),
      onSuccess: refresh,
    }),
    test: useMutation({
      mutationFn: (provider: string) =>
        api<ConnectionResult>(`/api/ai/connections/${provider}/test`, { method: "POST" }),
      onSettled: refresh,
    }),
    activate: useMutation({
      mutationFn: (provider: string) => api<AIStatus>(`/api/ai/connections/${provider}/activate`, { method: "POST" }),
      onSuccess: refresh,
    }),
    removeKey: useMutation({
      mutationFn: (provider: string) => api<void>(`/api/ai/connections/${provider}/key`, { method: "DELETE" }),
      onSuccess: refresh,
    }),
  }
}

// ── Milestone 2 ─────────────────────────────────────────────────────────────
export const financialKeys = {
  grid: (id: string) => ["deal", id, "financials"] as const,
  history: (id: string, concept: string, period: string) => ["deal", id, "history", concept, period] as const,
  analysis: (id: string) => ["deal", id, "analysis"] as const,
  assumptions: (id: string) => ["deal", id, "assumptions"] as const,
  valuation: (id: string) => ["deal", id, "valuation"] as const,
}

export const useFinancials = (dealId: string) =>
  useQuery({ queryKey: financialKeys.grid(dealId), queryFn: () => api<FinancialsResponse>(`/api/deals/${dealId}/financials`) })

export const useValueHistory = (dealId: string, concept: string | null, period: string | null) =>
  useQuery({
    queryKey: financialKeys.history(dealId, concept ?? "", period ?? ""),
    queryFn: () =>
      api<ValueChange[]>(
        `/api/deals/${dealId}/financials/history?concept_id=${encodeURIComponent(concept ?? "")}&period_key=${encodeURIComponent(period ?? "")}`,
      ),
    enabled: !!concept && !!period,
  })

export function useFinancialMutations(dealId: string) {
  const qc = useQueryClient()
  const setGrid = (grid: FinancialsResponse) => {
    qc.setQueryData(financialKeys.grid(dealId), grid)
    qc.invalidateQueries({ queryKey: financialKeys.analysis(dealId) })
    qc.invalidateQueries({ queryKey: financialKeys.valuation(dealId) })
    qc.invalidateQueries({ queryKey: ["deal", dealId, "history"] })
    qc.invalidateQueries({ queryKey: ["deal", dealId, "fx"] }) // which FX rates are needed follows the data
    qc.invalidateQueries({ queryKey: keys.audit(dealId) })
  }
  return {
    cells: useMutation({
      mutationFn: (body: { changes: CellChangeInput[]; source?: "manual" | "paste" | "template" }) =>
        api<FinancialsResponse>(`/api/deals/${dealId}/financials/cells`, { method: "PUT", json: body }),
      onSuccess: setGrid,
    }),
    entry: useMutation({
      mutationFn: (body: Partial<FinancialsResponse["entry"]>) =>
        api<FinancialsResponse>(`/api/deals/${dealId}/financials/entry`, { method: "PATCH", json: body }),
      onSuccess: setGrid,
    }),
    addPeriod: useMutation({
      mutationFn: (body: { key: string; kind?: string }) =>
        api<FinancialsResponse>(`/api/deals/${dealId}/periods`, { method: "POST", json: body }),
      onSuccess: setGrid,
    }),
    removePeriod: useMutation({
      mutationFn: (key: string) => api<FinancialsResponse>(`/api/deals/${dealId}/periods/${key}`, { method: "DELETE" }),
      onSuccess: setGrid,
    }),
    paste: useMutation({
      mutationFn: (body: { text: string; decimal_hint?: "." | "," | null }) =>
        api<PastePreview>(`/api/deals/${dealId}/financials/paste`, { method: "POST", json: body }),
    }),
    uploadTemplate: useMutation({
      mutationFn: async ({ file, apply }: { file: File; apply: boolean }) => {
        const form = new FormData()
        form.append("file", file)
        return api<TemplatePreview>(`/api/deals/${dealId}/template?apply=${apply}`, { method: "POST", body: form })
      },
      onSuccess: (result) => {
        if (result.applied) {
          qc.invalidateQueries({ queryKey: financialKeys.grid(dealId) })
          qc.invalidateQueries({ queryKey: financialKeys.analysis(dealId) })
          qc.invalidateQueries({ queryKey: financialKeys.valuation(dealId) })
      qc.invalidateQueries({ queryKey: ["deal", dealId, "recommendation"] })
        }
      },
    }),
  }
}

export interface TemplatePreview {
  applied: boolean
  units: string
  cells: number
  periods: string[]
  new_periods: string[]
  warnings: string[]
  counts?: Record<string, number>
}

export const useAnalysis = (dealId: string) =>
  useQuery({ queryKey: financialKeys.analysis(dealId), queryFn: () => api<AnalysisResponse>(`/api/deals/${dealId}/analysis`) })

export const useAssumptions = (dealId: string) =>
  useQuery({
    queryKey: financialKeys.assumptions(dealId),
    queryFn: () => api<AssumptionsDoc>(`/api/deals/${dealId}/assumptions`),
  })

export function useSaveAssumptions(dealId: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: Partial<AssumptionsDoc>) =>
      api<AssumptionsDoc>(`/api/deals/${dealId}/assumptions`, { method: "PUT", json: body }),
    onSuccess: (doc) => {
      qc.setQueryData(financialKeys.assumptions(dealId), doc)
      qc.invalidateQueries({ queryKey: financialKeys.valuation(dealId) })
      qc.invalidateQueries({ queryKey: ["deal", dealId, "recommendation"] })
      qc.invalidateQueries({ queryKey: keys.audit(dealId) })
    },
  })
}

export const methodKeys = {
  doc: (id: string) => ["deal", id, "methods"] as const,
}

export const useMethods = (dealId: string) =>
  useQuery({ queryKey: methodKeys.doc(dealId), queryFn: () => api<MethodsDoc>(`/api/deals/${dealId}/methods`) })

/** Save one section of the method inputs, then rerun the valuation (and the analysis, for one-off adjustments). */
export function useSaveMethodSection(dealId: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ section, value }: { section: MethodSection; value: unknown }) =>
      api<MethodsDoc>(`/api/deals/${dealId}/methods/${section}`, { method: "PUT", json: value }),
    onSuccess: (doc) => {
      qc.setQueryData(methodKeys.doc(dealId), doc)
      qc.invalidateQueries({ queryKey: financialKeys.valuation(dealId) })
      qc.invalidateQueries({ queryKey: ["deal", dealId, "recommendation"] })
      qc.invalidateQueries({ queryKey: financialKeys.analysis(dealId) })
      qc.invalidateQueries({ queryKey: keys.audit(dealId) })
    },
  })
}

export function useSuggestOneOffs(dealId: string) {
  return useMutation({
    mutationFn: () => api<Job>(`/api/deals/${dealId}/normalisation/suggest`, { method: "POST" }),
  })
}

export const recommendationKey = (id: string) => ["deal", id, "recommendation"] as const

export const useRecommendation = (dealId: string) =>
  useQuery({
    queryKey: recommendationKey(dealId),
    queryFn: () => api<RecommendationResponse>(`/api/deals/${dealId}/recommendation`),
    placeholderData: (previous) => previous,
  })

export function useWriteRationale(dealId: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: () => api<RecommendationResponse>(`/api/deals/${dealId}/recommendation/rationale`, { method: "POST" }),
    onSuccess: (data) => {
      qc.setQueryData(recommendationKey(dealId), data)
      qc.invalidateQueries({ queryKey: keys.audit(dealId) })
    },
  })
}

export const useValuation = (dealId: string) =>
  useQuery({
    queryKey: financialKeys.valuation(dealId),
    queryFn: () => api<ValuationResponse>(`/api/deals/${dealId}/valuation`),
    placeholderData: (previous) => previous,
  })

// ── documents and review (Milestone 3) ──────────────────────────────────────
export const documentKeys = {
  list: (dealId: string) => ["deal", dealId, "documents"] as const,
  review: (dealId: string) => ["deal", dealId, "review"] as const,
  job: (jobId: string) => ["job", jobId] as const,
}

export const useDocuments = (dealId: string) =>
  useQuery({
    queryKey: documentKeys.list(dealId),
    queryFn: () => api<DealDocument[]>(`/api/deals/${dealId}/documents`),
    // keep polling while anything is being read
    refetchInterval: (query) => (query.state.data?.some((d) => d.status === "processing") ? 1500 : false),
  })

export const useJob = (jobId: string | null, active: boolean) =>
  useQuery({
    queryKey: documentKeys.job(jobId ?? ""),
    queryFn: () => api<Job>(`/api/jobs/${jobId}`),
    enabled: !!jobId,
    refetchInterval: active ? 1000 : false,
  })

export const useReview = (dealId: string) =>
  useQuery({ queryKey: documentKeys.review(dealId), queryFn: () => api<ReviewResponse>(`/api/deals/${dealId}/review`) })

export function useDocumentMutations(dealId: string) {
  const qc = useQueryClient()
  const refresh = () => {
    qc.invalidateQueries({ queryKey: documentKeys.list(dealId) })
    qc.invalidateQueries({ queryKey: documentKeys.review(dealId) })
    qc.invalidateQueries({ queryKey: keys.audit(dealId) })
  }
  return {
    upload: useMutation({
      mutationFn: (files: File[]) => {
        const body = new FormData()
        files.forEach((file) => body.append("files", file, file.name))
        return api<{ documents: DealDocument[]; rejected: string[] }>(`/api/deals/${dealId}/documents`, {
          method: "POST",
          body,
        })
      },
      onSuccess: async (result) => {
        // a list fetch started before the upload may still be in flight with the old (empty) answer: cancel it,
        // show the new documents at once, then refresh (the list polls while they are being read)
        await qc.cancelQueries({ queryKey: documentKeys.list(dealId) })
        qc.setQueryData<DealDocument[]>(documentKeys.list(dealId), (old = []) => [
          ...old.filter((d) => !result.documents.some((n) => n.id === d.id)),
          ...result.documents,
        ])
        refresh()
      },
    }),
    rerun: useMutation({
      mutationFn: (documentId: string) =>
        api<DealDocument>(`/api/deals/${dealId}/documents/${documentId}/extract`, { method: "POST" }),
      onSuccess: refresh,
    }),
    remove: useMutation({
      mutationFn: (documentId: string) => api<void>(`/api/deals/${dealId}/documents/${documentId}`, { method: "DELETE" }),
      onSuccess: refresh,
    }),
    resumeJob: useMutation({
      mutationFn: (jobId: string) => api<Job>(`/api/jobs/${jobId}/resume`, { method: "POST" }),
      onSuccess: refresh,
    }),
  }
}

export function useReviewMutations(dealId: string) {
  const qc = useQueryClient()
  const after = (data: ReviewResponse) => {
    qc.setQueryData(documentKeys.review(dealId), data)
    qc.invalidateQueries({ queryKey: financialKeys.grid(dealId) })
    qc.invalidateQueries({ queryKey: financialKeys.analysis(dealId) })
    qc.invalidateQueries({ queryKey: financialKeys.valuation(dealId) })
    qc.invalidateQueries({ queryKey: keys.audit(dealId) })
  }
  return {
    decide: useMutation({
      mutationFn: (body: { actions?: ReviewAction[]; accept_all_above?: number }) =>
        api<ReviewResponse>(`/api/deals/${dealId}/review`, { method: "POST", json: body }),
      onSuccess: after,
    }),
    mapRow: useMutation({
      mutationFn: (body: { document_id: string; row_id: number; concept_id: string }) =>
        api<ReviewResponse>(`/api/deals/${dealId}/review/map-row`, { method: "POST", json: body }),
      onSuccess: after,
    }),
  }
}

export const useTaxonomy = () =>
  useQuery({
    queryKey: ["taxonomy"],
    queryFn: () => api<{ version: string; concepts: TaxonomyConcept[] }>("/api/taxonomy"),
    staleTime: Infinity,
  })

// ── FX rates (brief §7) ──────────────────────────────────────────────────────
export const fxKey = (id: string) => ["deal", id, "fx"] as const

export const useFx = (dealId: string) =>
  useQuery({ queryKey: fxKey(dealId), queryFn: () => api<FxDoc>(`/api/deals/${dealId}/fx`) })

export function useSaveFx(dealId: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: Pick<FxDoc, "rates" | "peer_rates">) => api<FxDoc>(`/api/deals/${dealId}/fx`, { method: "PUT", json: body }),
    onSuccess: (doc) => {
      qc.setQueryData(fxKey(dealId), doc)
      qc.invalidateQueries({ queryKey: financialKeys.valuation(dealId) })
      qc.invalidateQueries({ queryKey: financialKeys.analysis(dealId) })
      qc.invalidateQueries({ queryKey: recommendationKey(dealId) })
      qc.invalidateQueries({ queryKey: keys.audit(dealId) })
    },
  })
}

/** Peer sourcing: AI-suggested names (no figures) and the CSV market data connector. Neither saves peers. */
export function usePeerSourcing(dealId: string) {
  const qc = useQueryClient()
  return {
    suggest: useMutation({
      mutationFn: () => api<PeerSuggestionsResponse>(`/api/deals/${dealId}/peers/suggest`, { method: "POST" }),
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: keys.audit(dealId) })
      },
    }),
    importCsv: useMutation({
      mutationFn: ({ file, scale }: { file: File; scale: number }) => {
        const form = new FormData()
        form.append("file", file)
        return api<PeerCsvImport>(`/api/deals/${dealId}/peers/import?scale=${scale}`, { method: "POST", body: form })
      },
    }),
  }
}

// ── saved versions of a deal ──────────────────────────────────────────────────
export const versionKeys = {
  list: (id: string) => ["deal", id, "versions"] as const,
  compare: (id: string, versionId: string) => ["deal", id, "versions", versionId, "compare"] as const,
}

export const useVersions = (dealId: string) =>
  useQuery({ queryKey: versionKeys.list(dealId), queryFn: () => api<DealVersion[]>(`/api/deals/${dealId}/versions`) })

export const useVersionComparison = (dealId: string, versionId: string | null) =>
  useQuery({
    queryKey: versionKeys.compare(dealId, versionId ?? ""),
    queryFn: () => api<VersionComparison>(`/api/deals/${dealId}/versions/${versionId}/compare`),
    enabled: !!versionId,
    staleTime: 0,
  })

export function useVersionMutations(dealId: string) {
  const qc = useQueryClient()
  return {
    save: useMutation({
      mutationFn: (body: { name: string; note?: string }) =>
        api<DealVersion>(`/api/deals/${dealId}/versions`, { method: "POST", json: body }),
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: versionKeys.list(dealId) })
        qc.invalidateQueries({ queryKey: keys.audit(dealId) })
      },
    }),
    restore: useMutation({
      mutationFn: (versionId: string) =>
        api<{ restored: DealVersion; backup: DealVersion }>(`/api/deals/${dealId}/versions/${versionId}/restore`, {
          method: "POST",
        }),
      // a restore replaces the deal's inputs: every view of the deal reloads
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: ["deal", dealId] })
        qc.invalidateQueries({ queryKey: ["deals"] })
      },
    }),
  }
}
