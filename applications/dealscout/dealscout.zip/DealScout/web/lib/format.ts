// Display formatting. Numbers follow the user's locale setting but stay consistent within a deal.

const DEFAULT_LOCALE = "en-US"

export function formatDate(iso: string | null | undefined, locale = DEFAULT_LOCALE): string {
  if (!iso) return "—"
  const date = iso.length === 10 ? new Date(`${iso}T00:00:00`) : new Date(iso)
  if (Number.isNaN(date.getTime())) return "—"
  return date.toLocaleDateString(locale, { year: "numeric", month: "short", day: "2-digit" })
}

export function formatRelative(iso: string, now = Date.now()): string {
  const then = new Date(iso).getTime()
  const seconds = Math.round((then - now) / 1000)
  const rtf = new Intl.RelativeTimeFormat(DEFAULT_LOCALE, { numeric: "auto" })
  const abs = Math.abs(seconds)
  if (abs < 60) return rtf.format(seconds, "second")
  if (abs < 3600) return rtf.format(Math.round(seconds / 60), "minute")
  if (abs < 86400) return rtf.format(Math.round(seconds / 3600), "hour")
  if (abs < 86400 * 30) return rtf.format(Math.round(seconds / 86400), "day")
  return formatDate(iso)
}

export function formatUsd(value: number | null | undefined, digits = 2): string {
  if (value === null || value === undefined) return "cost unknown"
  return new Intl.NumberFormat(DEFAULT_LOCALE, {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(value)
}

export function formatInt(value: number | null | undefined, locale = DEFAULT_LOCALE): string {
  if (value === null || value === undefined) return "—"
  return new Intl.NumberFormat(locale, { maximumFractionDigits: 0 }).format(value)
}

export const PERSPECTIVE_LABEL = { financial_sponsor: "Financial sponsor", strategic: "Strategic buyer" } as const
export const MODE_LABEL = { quick: "Quick Scan", detailed: "Detailed" } as const

// ── financial numbers ──────────────────────────────────────────────────────────
export const SCALE_LABEL: Record<number, string> = { 1: "", 1000: "k", 1000000: "m", 1000000000: "bn" }
export const SCALE_NAME: Record<number, string> = { 1: "units", 1000: "thousands", 1000000: "millions", 1000000000: "billions" }

/** Accounting format: thousands separators, negatives in parentheses, en dash for zero. */
export function formatAccounting(value: number | null | undefined, decimals = 1, locale = DEFAULT_LOCALE): string {
  if (value === null || value === undefined || Number.isNaN(value)) return ""
  if (value === 0) return "–" // a dash means exactly zero; tiny non-zero values still show their sign
  const text = new Intl.NumberFormat(locale, { minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(
    Math.abs(value),
  )
  return value < 0 ? `(${text})` : text
}

export function formatScaled(value: number | null | undefined, scale: number, decimals = 1): string {
  if (value === null || value === undefined) return ""
  return formatAccounting(value / scale, decimals)
}

export function formatPct(value: number | null | undefined, decimals = 1): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return "n/m"
  const text = (Math.abs(value) * 100).toFixed(decimals)
  return value < 0 ? `(${text}%)` : `${text}%`
}

export function formatMultiple(value: number | null | undefined, decimals = 1): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return "n/m"
  return `${value.toFixed(decimals)}x`
}

/** Compact money for headlines and charts, e.g. EUR 1.24bn. */
export function formatMoneyCompact(value: number | null | undefined, currency: string): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return "n/m"
  const abs = Math.abs(value)
  const [div, suffix] = abs >= 1e9 ? [1e9, "bn"] : abs >= 1e6 ? [1e6, "m"] : abs >= 1e3 ? [1e3, "k"] : [1, ""]
  const text = (abs / div).toLocaleString(DEFAULT_LOCALE, { maximumFractionDigits: abs / div >= 100 ? 0 : 1 })
  return `${value < 0 ? "−" : ""}${currency} ${text}${suffix}`
}

/**
 * Parse what an analyst types into a grid cell: 1,234.5 · 1.234,5 · (1,234) · -1234 · 1 234 · 12% · – (zero).
 * Returns undefined when the text is not a number (the edit is rejected, never guessed).
 */
export function parseCellInput(text: string, decimalHint: "." | "," | null = null): number | null | undefined {
  let s = text.trim().replace(/[    ']/g, "")
  if (s === "") return null
  if (["–", "-", "—", "−"].includes(s)) return 0
  let negative = false
  if (s.startsWith("(") && s.endsWith(")")) {
    negative = true
    s = s.slice(1, -1)
  }
  if (/^[-−–]/.test(s)) {
    negative = true
    s = s.slice(1)
  }
  if (/[-−]$/.test(s)) {
    negative = true
    s = s.slice(0, -1)
  }
  const percent = s.endsWith("%")
  if (percent) s = s.slice(0, -1)
  if (!/^[\d.,]+$/.test(s)) return undefined
  if (s.includes(",") && s.includes(".")) {
    const decimal = s.lastIndexOf(",") > s.lastIndexOf(".") ? "," : "."
    s = s.replaceAll(decimal === "," ? "." : ",", "").replace(decimal, ".")
  } else if (s.includes(",") || s.includes(".")) {
    const sep = s.includes(",") ? "," : "."
    const groups = s.split(sep)
    const grouped =
      groups.length > 2 ||
      (groups.length === 2 && groups[1].length === 3 && (sep === "," ? decimalHint !== "," : decimalHint === ","))
    s = grouped ? s.replaceAll(sep, "") : s.replace(sep, ".")
  }
  const value = Number(s)
  if (!Number.isFinite(value)) return undefined
  return (negative ? -value : value) / (percent ? 100 : 1)
}
