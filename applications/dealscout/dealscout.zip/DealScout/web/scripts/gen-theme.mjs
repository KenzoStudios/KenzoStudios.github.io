// Generates app/palette.generated.css (and lib/*.generated.json) from data/design/palette.json and data/legal/disclaimers.json — the single palette shared by the web UI,
// charts, Excel, PDF and PPTX. Runs automatically before `npm run dev` and `npm run build`.
import { copyFileSync, cpSync, existsSync, readFileSync, writeFileSync } from "node:fs"
import { dirname, resolve } from "node:path"
import { fileURLToPath } from "node:url"

const here = dirname(fileURLToPath(import.meta.url))
const palette = JSON.parse(readFileSync(resolve(here, "../../data/design/palette.json"), "utf8"))

const lines = []
const emit = (prefix, obj) => {
  for (const [key, value] of Object.entries(obj)) {
    const isColor = (v) => typeof v === "string" && /^#[0-9a-f]{3,8}$/i.test(v)
    if (isColor(value)) lines.push(`  --ds-${prefix}-${key.replaceAll("_", "-")}: ${value};`)
    else if (Array.isArray(value) && value.every(isColor))
      value.forEach((v, i) => lines.push(`  --ds-${prefix}-${key.replaceAll("_", "-")}-${i + 1}: ${v};`))
  }
}
emit("brand", palette.brand)
emit("grey", palette.grey)
emit("sem", palette.semantic)
emit("chart", palette.chart)

const css = `/* GENERATED from data/design/palette.json by scripts/gen-theme.mjs — do not edit by hand. */\n:root {\n${lines.join("\n")}\n}\n`
writeFileSync(resolve(here, "../app/palette.generated.css"), css)
writeFileSync(resolve(here, "../lib/palette.generated.json"), JSON.stringify(palette, null, 2) + "\n")
const disclaimers = readFileSync(resolve(here, "../../data/legal/disclaimers.json"), "utf8")
writeFileSync(resolve(here, "../lib/disclaimers.generated.json"), disclaimers)
// The PDF viewer's worker is served as a static file next to the export (no CDN at runtime).
// Character maps (CJK), standard font data, colour profiles and image decoders go alongside it.
const pdfjsRoot = resolve(here, "../node_modules/pdfjs-dist")
const worker = resolve(pdfjsRoot, "build/pdf.worker.min.mjs")
if (existsSync(worker)) {
  copyFileSync(worker, resolve(here, "../public/pdf.worker.min.mjs"))
  for (const dir of ["cmaps", "standard_fonts", "iccs", "wasm"])
    cpSync(resolve(pdfjsRoot, dir), resolve(here, `../public/pdfjs/${dir}`), { recursive: true })
}
console.log(`palette: ${lines.length} tokens written; disclaimers copied; pdf worker ${existsSync(worker) ? "copied" : "missing"}`)
