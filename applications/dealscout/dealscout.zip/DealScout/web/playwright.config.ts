import { defineConfig, devices } from "@playwright/test"
import os from "node:os"
import path from "node:path"

// End-to-end tests run the real app (FastAPI + the static web build) on its own port with a throwaway data folder.
// Build the web app first (`npm run build`); `npm run e2e` does both.
const port = 8020
const dataDir = path.join(os.tmpdir(), `dealscout-e2e-${Date.now()}`)

export default defineConfig({
  testDir: "./e2e",
  timeout: 120_000,
  expect: { timeout: 20_000 },
  fullyParallel: false,
  workers: 1,
  reporter: [["list"]],
  use: {
    baseURL: `http://127.0.0.1:${port}`,
    viewport: { width: 1440, height: 900 },
    acceptDownloads: true,
    trace: "retain-on-failure",
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"], viewport: { width: 1440, height: 900 } } }],
  webServer: {
    command: "uv run --frozen dealscout",
    cwd: "..",
    url: `http://127.0.0.1:${port}/api/health`,
    timeout: 120_000,
    reuseExistingServer: false,
    env: {
      DEALSCOUT_PORT: String(port),
      DEALSCOUT_DATA_DIR: dataDir,
      DEALSCOUT_OPEN_BROWSER: "0",
      DEALSCOUT_TEST_NO_KEYRING: "1",
    },
  },
})
