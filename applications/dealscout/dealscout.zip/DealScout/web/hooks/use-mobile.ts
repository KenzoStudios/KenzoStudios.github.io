import * as React from "react"

const MOBILE_BREAKPOINT = 768
const query = `(max-width: ${MOBILE_BREAKPOINT - 1}px)`

function subscribe(onChange: () => void) {
  const mql = window.matchMedia(query)
  mql.addEventListener("change", onChange)
  return () => mql.removeEventListener("change", onChange)
}

export function useIsMobile() {
  return React.useSyncExternalStore(
    subscribe,
    () => window.matchMedia(query).matches,
    () => false,
  )
}

/** True while `query` matches (e.g. "(max-width: 1099px)"); false during static rendering. */
export function useMediaQuery(mediaQuery: string) {
  const subscribeTo = React.useCallback(
    (onChange: () => void) => {
      const mql = window.matchMedia(mediaQuery)
      mql.addEventListener("change", onChange)
      return () => mql.removeEventListener("change", onChange)
    },
    [mediaQuery],
  )
  return React.useSyncExternalStore(
    subscribeTo,
    () => window.matchMedia(mediaQuery).matches,
    () => false,
  )
}
