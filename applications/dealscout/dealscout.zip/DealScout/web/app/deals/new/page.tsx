import type { Metadata } from "next"

import { NewDealPage } from "@/components/deals/new-deal-page"

export const metadata: Metadata = { title: "New deal" }

export default function Page() {
  return <NewDealPage />
}
