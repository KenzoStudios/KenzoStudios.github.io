import { Suspense } from "react"
import type { Metadata } from "next"

import { DealPage } from "@/components/deals/deal-page"
import { Skeleton } from "@/components/ui/skeleton"

export const metadata: Metadata = { title: "Deal" }

// Deal pages are routed client-side (/deal?id=…) because a static export cannot pre-build a page per deal.
export default function Page() {
  return (
    <Suspense fallback={<Skeleton className="m-6 h-40" />}>
      <DealPage />
    </Suspense>
  )
}
