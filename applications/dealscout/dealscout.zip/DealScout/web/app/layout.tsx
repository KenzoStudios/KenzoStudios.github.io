import type { Metadata, Viewport } from "next"
import "@fontsource-variable/inter"

import "./globals.css"
import { Providers } from "@/components/providers"
import { AppShell } from "@/components/shell/app-shell"

export const metadata: Metadata = {
  title: { default: "DealScout", template: "%s · DealScout" },
  description: "First-pass company analysis and indicative acquisition price range. Runs locally.",
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0d141f" },
  ],
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning className="antialiased">
      <body>
        <Providers>
          <AppShell>{children}</AppShell>
        </Providers>
      </body>
    </html>
  )
}
