import type { Metadata } from "next"

import { ConnectAIPage } from "@/components/settings/connect-ai-page"

export const metadata: Metadata = { title: "Connect AI" }

export default function Page() {
  return <ConnectAIPage />
}
