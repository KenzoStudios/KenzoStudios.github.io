import { Suspense } from "react"

import { DealsPage } from "@/components/deals/deals-page"
import { Skeleton } from "@/components/ui/skeleton"

export default function Page() {
  return (
    <Suspense fallback={<Skeleton className="m-6 h-40" />}>
      <DealsPage />
    </Suspense>
  )
}
