import { LinkButton } from "@/components/common/link-button"
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyTitle } from "@/components/ui/empty"

export default function NotFound() {
  return (
    <Empty className="m-6 border">
      <EmptyHeader>
        <EmptyTitle>Page not found</EmptyTitle>
        <EmptyDescription>This address doesn&apos;t exist in DealScout.</EmptyDescription>
      </EmptyHeader>
      <EmptyContent>
        <LinkButton href="/" variant="outline">
          Back to deals
        </LinkButton>
      </EmptyContent>
    </Empty>
  )
}
