import { execFileSync } from "node:child_process"
import fs from "node:fs"
import path from "node:path"
import { fileURLToPath } from "node:url"

import { expect, type Page, test } from "@playwright/test"

// Brief §16: create deal → upload → review → value → export. With SCREENSHOTS=1 the run also refreshes the README
// screenshots in docs/screenshots.
const here = path.dirname(fileURLToPath(import.meta.url))
const shots = process.env.SCREENSHOTS === "1" ? path.resolve(here, "../../docs/screenshots") : null

async function shot(page: Page, name: string) {
  if (!shots) return
  fs.mkdirSync(shots, { recursive: true })
  await page.waitForTimeout(600) // let charts finish their 200 ms animation
  await page.screenshot({ path: path.join(shots, `${name}.png`), style: '[data-slot="toast-viewport"] { display: none !important; }' })
}

function syntheticReport(dir: string): string {
  fs.mkdirSync(dir, { recursive: true })
  const file = path.join(dir, "fictional-annual-report-2025.pdf")
  execFileSync(
    "uv",
    ["run", "--frozen", "python", "-c",
     `import sys; from dealscout_extraction.synthetic import english_annual_report; open(sys.argv[1], "wb").write(english_annual_report())`,
     file],
    { cwd: path.resolve(here, "../..") },
  )
  return file
}

test("create a deal, read a report, review, value and export", async ({ page }, info) => {
  const report = syntheticReport(info.outputDir)

  // create deal
  await page.goto("/")
  await page.getByRole("link", { name: "New deal" }).first().click()
  await page.getByLabel("Company name").fill("Northwind Components plc (fictional)")
  await page.locator("#deal-country").fill("United Kingdom")
  await page.keyboard.press("Enter")
  await page.locator("#deal-sector").click()
  await page.getByRole("option", { name: "Industrials & capital goods" }).click()
  await shot(page, "01-new-deal")
  await page.getByRole("button", { name: "Create deal" }).click()
  await expect(page.getByRole("heading", { level: 1, name: /Northwind Components/ })).toBeVisible()

  // upload and wait for the rules-based reading to finish (no AI connected)
  await page.getByRole("tab", { name: "Documents" }).click()
  await expect(page.getByRole("button", { name: "Choose files", exact: true })).toBeVisible() // tab rendered and hydrated
  await page.locator('input[type="file"]').setInputFiles(report)
  await expect(page.getByRole("button", { name: "Review values" })).toBeVisible({ timeout: 60_000 })
  await shot(page, "02-documents")

  // review: accept the high-confidence values
  await page.getByRole("tab", { name: /Review/ }).click()
  const accept = page.getByRole("button", { name: /Accept all high-confidence/ })
  await expect(accept).toBeEnabled()
  await shot(page, "03-review")
  await accept.click()
  await expect(page.getByRole("button", { name: /Accept all high-confidence \(0\)/ })).toBeVisible()

  // value: the report has no D&A, capex or interest line, so the DCF asks for those (it never guesses);
  // enter them in the assumptions panel the way an analyst would
  await page.getByRole("tab", { name: "Valuation" }).click()
  await expect(page.getByText("No suggested price yet")).toBeVisible()
  await page.getByRole("tab", { name: /Summary & DCF/ }).click()
  for (const [label, value] of [
    ["EBITDA margin", "16"],
    ["D&A % of revenue", "4"],
    ["Capex % of revenue", "5"],
    ["Pre-tax cost of debt", "6"],
  ]) {
    await page.getByRole("button", { name: `${label}: not set. Edit` }).click()
    await page.getByLabel(`${label} in percent`).fill(value)
    await page.keyboard.press("Enter")
    await expect(page.getByRole("button", { name: new RegExp(`^${label.replace(/[&%]/g, ".")}( by year)?: [0-9]`) })).toBeVisible()
  }
  await page.getByRole("tab", { name: "Acquisition price" }).click()
  await expect(page.getByText("Suggested acquisition price range, 100% of equity")).toBeVisible()
  await expect(page.getByText(/Data quality/).first()).toBeVisible()
  await shot(page, "04-acquisition-price")
  await page.getByRole("tab", { name: /Summary & DCF/ }).click()
  await expect(page.getByText("Football field").first()).toBeVisible()
  await shot(page, "05-valuation-summary")
  await page.getByRole("tab", { name: "Analysis" }).click()
  await expect(page.getByText("Early warning signs")).toBeVisible()
  await shot(page, "06-analysis")

  // export: Create Excel downloads a checked workbook
  const download = page.waitForEvent("download")
  await page.getByRole("button", { name: "Create Excel" }).click()
  const file = await download
  expect(file.suggestedFilename()).toMatch(/^DealScout_Northwind_Components.*\.xlsx$/)
  const saved = path.join(info.outputDir, file.suggestedFilename())
  await file.saveAs(saved)
  expect(fs.statSync(saved).size).toBeGreaterThan(10_000)
  await expect(page.getByText("Excel workbook created")).toBeVisible()
})
