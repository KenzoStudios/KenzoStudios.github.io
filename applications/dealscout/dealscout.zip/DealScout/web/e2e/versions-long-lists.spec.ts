import { expect, test } from "@playwright/test"

// Saved versions (save, compare, restore with an automatic backup), Detailed mode's per-year drivers, custom
// scenarios, and the virtualised deals list with 2,000 rows.
const M = 1e6

test("versions, detailed mode and scenarios on a seeded deal", async ({ page, request }) => {
  const deal = await (
    await request.post("/api/deals", {
      data: { name: "Versioned Industrial AG (fictional)", country: "DE", sector: "industrials", reporting_currency: "EUR", valuation_date: "2026-03-31" },
    })
  ).json()
  const rows: Record<string, Record<string, number>> = {
    revenue: { FY2023: 800 * M, FY2024: 900 * M, FY2025: 1000 * M },
    ebitda: { FY2023: 120 * M, FY2024: 140 * M, FY2025: 160 * M },
    da_total: { FY2023: -32 * M, FY2024: -36 * M, FY2025: -40 * M },
    capex: { FY2023: -40 * M, FY2024: -45 * M, FY2025: -50 * M },
    lt_debt: { FY2025: 300 * M },
    cash: { FY2025: 100 * M },
    total_equity: { FY2025: 700 * M },
    shares_outstanding: { FY2025: 50 * M },
  }
  const changes = Object.entries(rows).flatMap(([concept_id, byPeriod]) =>
    Object.entries(byPeriod).map(([period_key, value]) => ({ concept_id, period_key, value })),
  )
  await request.put(`/api/deals/${deal.id}/financials/cells`, { data: { changes } })
  await request.put(`/api/deals/${deal.id}/assumptions`, {
    data: { overrides: { risk_free_rate: 0.03, equity_risk_premium: 0.05, unlevered_beta: 0.9, tax_rate: 0.3, pre_tax_cost_of_debt: 0.05, country_risk_premium: 0 } },
  })

  // save a version
  await page.goto(`/deal?id=${deal.id}&tab=activity`)
  await page.getByRole("button", { name: "Save version" }).click()
  await page.getByLabel("Name").fill("IC draft")
  await page.getByRole("dialog").getByRole("button", { name: "Save version" }).click()
  await expect(page.getByRole("cell", { name: "IC draft", exact: true })).toBeVisible()

  // Detailed mode: per-year capex
  await page.getByRole("tab", { name: "Summary" }).click()
  await page.getByRole("group", { name: "Mode" }).getByRole("button", { name: "Detailed" }).click()
  await expect(page.getByText("Switched to Detailed")).toBeVisible()
  await page.getByRole("tab", { name: "Valuation" }).click()
  await expect(page.getByRole("tab", { name: /LBO/ })).toBeVisible() // every method tab in Detailed mode
  await page.getByRole("tab", { name: /Summary & DCF/ }).click()
  const capex = page.getByRole("textbox", { name: /^Capex % of revenue 2026E in percent$/ })
  await capex.fill("8")
  await page.getByRole("form", { name: /Capex % of revenue by year/ }).getByRole("button", { name: "Set years" }).click()
  await expect(capex).toHaveValue("8")

  // custom scenarios: probabilities must add up to 100%
  await page.getByRole("button", { name: "Add scenario" }).click()
  await expect(page.getByText(/Probabilities add up to 100%/)).toBeVisible()
  await page.getByRole("textbox", { name: "Scenario 4 name" }).fill("Rate shock")
  await page.getByRole("textbox", { name: /^Rate shock: Probability/ }).fill("10")
  await expect(page.getByText(/they must add up to 100%/)).toBeVisible()
  await page.getByRole("textbox", { name: /^base: Probability/ }).fill("40")
  await page.getByRole("textbox", { name: /^Rate shock: WACC/ }).fill("1.5")
  await page.getByRole("button", { name: "Save and run" }).click()
  await expect(page.getByText("Scenarios saved")).toBeVisible()
  const v = await (await request.get(`/api/deals/${deal.id}/valuation`)).json()
  expect(v.scenarios.scenarios.map((x: { name: string }) => x.name)).toEqual(["bear", "base", "bull", "Rate shock"])

  // compare with the version, then restore it (the current state is saved first)
  await page.getByRole("tab", { name: "Versions and activity" }).click()
  await page.getByRole("button", { name: "Compare IC draft with current" }).click()
  await expect(page.getByRole("heading", { name: "Compare with current" })).toBeVisible()
  await expect(page.getByRole("cell", { name: "Capex % of revenue" })).toBeVisible()
  await page.keyboard.press("Escape")
  await page.getByRole("button", { name: "Restore IC draft" }).click()
  await page.getByRole("button", { name: "Restore version" }).click()
  await expect(page.getByText("Version restored")).toBeVisible()
  await expect(page.getByText("Before restoring 'IC draft'", { exact: true })).toBeVisible()
  await expect(page.getByText("Automatic", { exact: true })).toBeVisible()
})

test("the deals list stays virtualised with 2,000 deals", async ({ page }) => {
  // the list endpoint is answered in the browser so the test measures the UI, not 2,000 inserts
  const total = 2000
  const items = Array.from({ length: total }, (_, i) => ({
    id: `bulk${i}`,
    name: `Bulk deal ${String(i).padStart(4, "0")}`,
    country: "GB",
    country_name: "United Kingdom",
    sector: "industrials",
    sector_name: "Industrials & capital goods",
    industry: i % 3 ? null : "A rather long industry description that has to truncate",
    listed: i % 5 === 0,
    ticker: i % 5 === 0 ? `BLK${i}` : null,
    reporting_currency: "GBP",
    analysis_currency: "GBP",
    valuation_date: "2026-03-31",
    perspective: "financial_sponsor",
    mode: "quick",
    status: "draft",
    sector_template: "general",
    notes: null,
    archived: false,
    created_at: "2026-11-01T10:00:00Z",
    updated_at: "2026-11-01T10:00:00Z",
  }))
  await page.route(/\/api\/deals(\?.*)?$/, (route) =>
    route.request().method() === "GET" ? route.fulfill({ json: { items, total } }) : route.continue(),
  )
  await page.goto("/")
  const main = page.locator("#main")
  await expect(main.getByRole("link", { name: "Bulk deal 0000" })).toBeVisible()
  await expect(page.getByText("2000 deals")).toBeVisible()
  const rendered = await main.locator("tbody tr[data-index]").count()
  expect(rendered).toBeGreaterThan(5)
  expect(rendered).toBeLessThan(120) // only the rows in view (plus overscan) are in the DOM

  // keyboard: ↓ moves between company links and scrolls the list; the header stays in view
  await main.getByRole("link", { name: "Bulk deal 0000" }).focus()
  await page.keyboard.press("ArrowDown")
  for (let i = 0; i < 39; i++) await page.keyboard.press("ArrowDown")
  await expect(main.getByRole("link", { name: "Bulk deal 0040" })).toBeFocused()
  await expect(page.getByRole("columnheader", { name: "Company" })).toBeInViewport()

  // scrolling to the end renders the last rows
  await main.locator("tbody").first().evaluate((el) => el.closest("div.overflow-auto")?.scrollTo({ top: 1e7 }))
  await expect(main.getByRole("link", { name: "Bulk deal 1999" })).toBeVisible()
  expect(await main.locator("tbody tr[data-index]").count()).toBeLessThan(120)
})

test("the review table stays virtualised with 2,500 values", async ({ page, request }) => {
  const deal = await (
    await request.post("/api/deals", {
      data: { name: "Long review (fictional)", country: "GB", sector: "industrials", reporting_currency: "GBP" },
    })
  ).json()
  const statements = ["income_statement", "balance_sheet", "cash_flow"]
  const items = Array.from({ length: 2500 }, (_, i) => ({
    id: i + 1,
    document_id: "doc1",
    concept_id: "revenue",
    concept_name: `Line item ${String(i).padStart(4, "0")}`,
    statement: statements[Math.floor(i / 1000)],
    unit: "currency",
    period_key: "FY2025",
    value: (i + 1) * 1e6,
    value_as_written: String(i + 1),
    label: `Printed label ${i}`,
    page: 1,
    bbox: null,
    cell_ref: `B${i + 2}`,
    sheet: "Data",
    scale_factor: 1e6,
    scale_label: "millions",
    confidence: 0.6,
    method: "table_rules",
    mapping: "exact",
    provider: null,
    model: null,
    rationale: null,
    notes: [],
    status: "pending",
    decided_by: null,
    decided_at: null,
    current_value: null,
    current_source: null,
    conflicts: false,
    superseded_by: null,
  }))
  const documents = [
    {
      id: "doc1", deal_id: deal.id, filename: "big-workbook.xlsx", size_bytes: 1, sha256: "x", kind: "xlsx", page_count: 1,
      scanned_pages: 0, language: "en", doc_type: null, status: "processed", job_id: null, meta: {},
      uploaded_at: "2026-11-01T10:00:00Z", uploaded_by: "Analyst", job: null,
    },
  ]
  await page.route(`**/api/deals/${deal.id}/review`, (route) =>
    route.request().method() === "GET"
      ? route.fulfill({ json: { documents, items, checks: [], cross_document: [], core: [] } })
      : route.continue(),
  )
  await page.goto(`/deal?id=${deal.id}&tab=review`)
  const table = page.getByRole("table", { name: "Values read from documents" })
  await expect(table.getByText("Line item 0000")).toBeVisible()
  expect(await table.locator("tbody tr[data-index]").count()).toBeLessThan(120)

  // keyboard: click the first row, then ↓ / J select and scroll; the selection follows in the URL
  await table.getByText("Line item 0000").click()
  for (let i = 0; i < 30; i++) await page.keyboard.press(i % 2 ? "ArrowDown" : "j")
  await expect(page).toHaveURL(/item=31/)
  await expect(table.locator('tr[aria-current="true"]')).toContainText("Line item 0030")
  await expect(table.locator('tr[aria-current="true"]')).toBeFocused()
  await expect(table.getByRole("columnheader", { name: "Line item" })).toBeInViewport()

  // a deep link to a value far down the list scrolls it into view, under its statement heading
  await page.goto(`/deal?id=${deal.id}&tab=review&item=2400`)
  await expect(table.getByText("Line item 2399")).toBeInViewport()
  await page.goto(`/deal?id=${deal.id}&tab=review&item=2005`)
  await expect(table.getByText("Line item 2004")).toBeInViewport()
  await expect(table.getByRole("columnheader", { name: "Cash flow statement" })).toBeAttached()
})
