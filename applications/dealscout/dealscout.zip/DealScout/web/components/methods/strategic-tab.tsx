"use client"

import * as React from "react"

import { formatAccounting, formatPct } from "@/lib/format"
import type { MethodOutput, MethodsDoc, ValuationResponse } from "@/lib/types"

import {
  DataTable,
  MethodStatus,
  NumField,
  NumListField,
  RangeLine,
  SectionForm,
  StatTiles,
  StatusBadge,
  SwitchField,
  useMethodsContext,
  useMoney,
  useSectionDraft,
} from "./kit"

interface SynergyResult {
  rows: { year: number; synergy_ebitda: number; integration_costs: number; after_tax: number; pv: number }[]
  pv_explicit: number
  pv_terminal: number
  value_before_probability: number
  value: number
  paid_away: number
  retained: number
  discount_rate: number
}

interface AccretionResult {
  standalone_eps: number
  pro_forma_net_income: number
  new_shares: number
  pro_forma_shares: number
  pro_forma_eps: number
  accretion: number
  breakeven_synergies: number | null
  purchase_equity_value: number
  price_source: "entered" | "blended"
  pre_tax_synergies: number
  target_net_income: number
}

function SynergyInputs({ doc }: { doc: MethodsDoc }) {
  const state = useSectionDraft("synergies", doc.synergies)
  const d = state.draft
  type S = NonNullable<MethodsDoc["synergies"]>
  const set = <K extends keyof S>(key: K, value: S[K]) => state.update((x) => (x ? { ...x, [key]: value } : x))
  return (
    <SectionForm
      title="Synergies"
      description="Run-rate synergies phased in, less one-off integration costs, taxed, risked for delivery and discounted."
      state={state}
    >
      <SwitchField
        label="Value synergies"
        checked={d !== null && d !== undefined}
        onChange={(on) =>
          state.replace(
            on
              ? {
                  cost_synergies: 0,
                  revenue_synergies: 0,
                  revenue_synergy_margin: 0,
                  phasing: [0.33, 0.67, 1],
                  integration_costs: [],
                  probability: 1,
                  share_paid_away: 0,
                  discount_rate: null,
                  terminal_growth: null,
                }
              : null,
          )
        }
      />
      {d ? (
        <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <NumField label="Cost synergies / year" kind="money" value={d.cost_synergies} nullable={false} min={0} onChange={(x) => set("cost_synergies", x ?? 0)} description="Run-rate, pre-tax" />
          <NumField label="Revenue synergies / year" kind="money" value={d.revenue_synergies} nullable={false} min={0} onChange={(x) => set("revenue_synergies", x ?? 0)} />
          <NumField label="… EBITDA margin on them" kind="pct" value={d.revenue_synergy_margin} nullable={false} min={0} max={1} onChange={(x) => set("revenue_synergy_margin", x ?? 0)} />
          <NumField label="Probability of delivery" kind="pct" value={d.probability} nullable={false} min={0} max={1} onChange={(x) => set("probability", x ?? 1)} />
          <NumField label="Share paid to the seller" kind="pct" value={d.share_paid_away} nullable={false} min={0} max={1} onChange={(x) => set("share_paid_away", x ?? 0)} />
          <NumField label="Discount rate" kind="pct" value={d.discount_rate} placeholder="WACC" onChange={(x) => set("discount_rate", x)} />
          <div className="sm:col-span-2">
            <NumListField label="Phasing (% of run-rate by year)" kind="pct" values={d.phasing} onChange={(p) => set("phasing", p.length ? p : [1])} description="E.g. 33; 67; 100" />
          </div>
          <div className="sm:col-span-2">
            <NumListField label="Integration costs by year" kind="money" values={d.integration_costs} onChange={(c) => set("integration_costs", c)} description="One-off, positive numbers" />
          </div>
          <NumField label="Terminal growth" kind="pct" value={d.terminal_growth} placeholder="DCF" onChange={(x) => set("terminal_growth", x)} />
        </div>
      ) : null}
    </SectionForm>
  )
}

function AccretionInputs({ doc }: { doc: MethodsDoc }) {
  const state = useSectionDraft("accretion", doc.accretion)
  const d = state.draft
  type A = NonNullable<MethodsDoc["accretion"]>
  const set = <K extends keyof A>(key: K, value: A[K]) => state.update((x) => (x ? { ...x, [key]: value } : x))
  const mixError = d && Math.abs(d.cash_share + d.debt_share + d.stock_share - 1) > 1e-6
  return (
    <SectionForm
      title="Accretion / dilution"
      description="The acquirer's pro-forma earnings per share after buying the target with cash, new debt and/or shares."
      state={state}
    >
      <SwitchField
        label="Run accretion / dilution"
        checked={d !== null && d !== undefined}
        onChange={(on) =>
          state.replace(
            on
              ? {
                  acquirer_net_income: 0,
                  acquirer_shares: 1,
                  acquirer_share_price: 1,
                  purchase_equity_value: null,
                  cash_share: 0,
                  debt_share: 0,
                  stock_share: 1,
                  interest_on_new_debt: 0,
                  foregone_interest_on_cash: 0,
                  amortisation_of_intangibles: 0,
                  transaction_costs: 0,
                  use_synergies: true,
                }
              : null,
          )
        }
        description="Needs the acquirer's figures."
      />
      {d ? (
        <>
          <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
            <NumField label="Acquirer net income" kind="money" value={d.acquirer_net_income} nullable={false} onChange={(x) => set("acquirer_net_income", x ?? 0)} />
            <NumField label="Acquirer shares (m)" kind="number" value={d.acquirer_shares === null ? null : d.acquirer_shares / 1e6} nullable={false} min={0.000001} onChange={(x) => set("acquirer_shares", (x ?? 0) * 1e6)} />
            <NumField label="Acquirer share price" kind="price" value={d.acquirer_share_price} nullable={false} min={0.0001} onChange={(x) => set("acquirer_share_price", x ?? 1)} />
            <NumField label="Price for the target's equity" kind="money" value={d.purchase_equity_value} min={0} placeholder="Blended mid" onChange={(x) => set("purchase_equity_value", x)} />
            <NumField label="Transaction costs" kind="money" value={d.transaction_costs} nullable={false} min={0} onChange={(x) => set("transaction_costs", x ?? 0)} />
            <NumField label="Amortisation of acquired intangibles" kind="money" value={d.amortisation_of_intangibles} nullable={false} min={0} onChange={(x) => set("amortisation_of_intangibles", x ?? 0)} description="Pre-tax, per year" />
          </div>
          <fieldset className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
            <legend className="mb-2 text-xs font-semibold text-muted-foreground">Consideration (must add up to 100%)</legend>
            <NumField label="Cash" kind="pct" value={d.cash_share} nullable={false} min={0} max={1} onChange={(x) => set("cash_share", x ?? 0)} />
            <NumField label="New debt" kind="pct" value={d.debt_share} nullable={false} min={0} max={1} onChange={(x) => set("debt_share", x ?? 0)} />
            <NumField label="Shares" kind="pct" value={d.stock_share} nullable={false} min={0} max={1} onChange={(x) => set("stock_share", x ?? 0)} />
            <NumField label="Interest on new debt" kind="pct" value={d.interest_on_new_debt} nullable={false} min={0} onChange={(x) => set("interest_on_new_debt", x ?? 0)} />
            <NumField label="Interest lost on cash" kind="pct" value={d.foregone_interest_on_cash} nullable={false} min={0} onChange={(x) => set("foregone_interest_on_cash", x ?? 0)} />
            <div className="lg:pt-5">
              <SwitchField label="Include synergies" checked={d.use_synergies} onChange={(x) => set("use_synergies", x)} />
            </div>
          </fieldset>
          {mixError ? (
            <p role="alert" className="text-xs text-negative">
              Cash, debt and shares add up to {formatPct(d.cash_share + d.debt_share + d.stock_share, 0)}; they must add up to 100%.
            </p>
          ) : null}
        </>
      ) : null}
    </SectionForm>
  )
}

export function StrategicTab({ doc, v }: { doc: MethodsDoc; v: ValuationResponse }) {
  const { currency } = useMethodsContext()
  const money = useMoney()
  const syn = v.methods.find((m) => m.id === "strategic") as MethodOutput<SynergyResult> | undefined
  const acc = v.methods.find((m) => m.id === "accretion") as MethodOutput<AccretionResult> | undefined
  const s = syn?.result
  const a = acc?.result
  const eps = (x: number) => `${currency} ${formatAccounting(x, 2)}`
  return (
    <div className="flex flex-col gap-6">
      <section aria-label="Synergies" className="flex flex-col gap-4">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-semibold">Strategic value</h3>
          <StatusBadge output={syn} />
        </div>
        {syn?.status !== "ready" ? <MethodStatus output={syn} what="Synergy valuation" /> : null}
        {s ? (
          <>
            <RangeLine output={syn} />
            <StatTiles
              items={[
                { label: "Synergy value (risked)", value: money.compact(s.value), hint: `${money.compact(s.value_before_probability)} before the probability haircut` },
                { label: "Paid to the seller", value: money.compact(s.paid_away) },
                { label: "Kept by the buyer", value: money.compact(s.retained) },
                { label: "Discount rate", value: formatPct(s.discount_rate) },
              ]}
            />
            <DataTable
              caption={`Synergy cash flows (${money.unit})`}
              head={["Year", "Synergy EBITDA", "Integration costs", "After tax", "Present value"]}
              rows={[
                ...s.rows.map((r) => [`Year ${r.year}`, money.scaled(r.synergy_ebitda), money.scaled(-r.integration_costs), money.scaled(r.after_tax), money.scaled(r.pv)]),
                ["Terminal value", "", "", "", money.scaled(s.pv_terminal)],
              ]}
            />
          </>
        ) : null}
        <SynergyInputs doc={doc} />
      </section>
      <section aria-label="Accretion and dilution" className="flex flex-col gap-4">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-semibold">Accretion / dilution</h3>
          <StatusBadge output={acc} />
        </div>
        {acc?.status !== "ready" ? <MethodStatus output={acc} what="Accretion / dilution" /> : null}
        {a ? (
          <StatTiles
            items={[
              {
                label: a.accretion >= 0 ? "EPS accretion" : "EPS dilution",
                value: formatPct(Math.abs(a.accretion)),
                hint: `${eps(a.standalone_eps)} → ${eps(a.pro_forma_eps)}`,
              },
              { label: "New shares issued", value: `${formatAccounting(a.new_shares / 1e6, 1)}m`, hint: `${formatAccounting(a.pro_forma_shares / 1e6, 1)}m in total` },
              {
                label: "Break-even synergies",
                value: a.breakeven_synergies === null ? "n/m" : money.compact(a.breakeven_synergies),
                hint: "Pre-tax, per year, for EPS-neutral",
              },
              { label: "Price paid", value: money.compact(a.purchase_equity_value), hint: a.price_source === "blended" ? "Blended mid value" : "As entered" },
            ]}
          />
        ) : null}
        <AccretionInputs doc={doc} />
      </section>
    </div>
  )
}
