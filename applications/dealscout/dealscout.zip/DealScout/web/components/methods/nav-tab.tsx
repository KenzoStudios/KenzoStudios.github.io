"use client"

import * as React from "react"

import { formatAccounting, formatPct } from "@/lib/format"
import type { MethodOutput, MethodsDoc, NAVLine, Segment, ValuationResponse } from "@/lib/types"

import {
  type Column,
  DataTable,
  ListEditor,
  MethodStatus,
  NumField,
  RangeLine,
  SectionForm,
  SwitchField,
  useMethodsContext,
  useMoney,
  useSectionDraft,
} from "./kit"

interface NAVResult {
  lines: { name: string; side: string; book_value: number; fair_value: number; revaluation: number; method: string }[]
  book_nav: number
  revaluation_gain: number
  deferred_tax: number
  nav_before_discount: number
  holding_discount: number
  nav: number
  nav_per_share: number | null
  premium_to_nav: number | null
}

interface SOTPResult {
  segments: { name: string; low: number; mid: number; high: number }[]
  gross_ev: [number, number, number]
  corporate_costs_capitalised: number
  non_core_assets: number
  ev_before_discount: [number, number, number]
  conglomerate_discount: [number, number, number]
  ev: [number, number, number]
  equity: [number, number, number]
}

const METHOD_LABEL: Record<NAVLine["method"], string> = {
  book: "Book value",
  appraisal: "Appraisal",
  cap_rate: "Cap rate on NOI",
  multiple: "Multiple",
  transaction: "Recent transaction",
}

const NAV_COLUMNS: Column<NAVLine>[] = [
  { key: "name", header: "Asset or liability", kind: "text", width: "11rem" },
  {
    key: "side",
    header: "Side",
    kind: "select",
    options: [
      { value: "asset", label: "Asset" },
      { value: "liability", label: "Liability" },
    ],
    width: "6.5rem",
  },
  { key: "book_value", header: "Book value", kind: "money", nullable: false, width: "7rem" },
  {
    key: "method",
    header: "Revalued by",
    kind: "select",
    options: Object.entries(METHOD_LABEL).map(([value, label]) => ({ value, label })),
    width: "9.5rem",
  },
  { key: "fair_value", header: "Appraised / deal value", kind: "money", width: "7rem" },
  { key: "noi", header: "NOI", kind: "money", width: "6rem" },
  { key: "cap_rate", header: "Cap rate", kind: "pct", width: "5.5rem" },
  { key: "metric", header: "Metric", kind: "money", width: "6rem" },
  { key: "multiple", header: "Multiple", kind: "multiple", width: "5.5rem" },
  { key: "taxable", header: "Taxed gain", kind: "check", width: "4rem" },
]

const SEGMENT_COLUMNS: Column<Segment>[] = [
  { key: "name", header: "Segment", kind: "text", width: "10rem" },
  { key: "metric_label", header: "Metric", kind: "text", width: "6rem" },
  { key: "metric", header: "Metric value", kind: "money", width: "7rem" },
  { key: "multiple_low", header: "Low x", kind: "multiple", width: "5rem" },
  { key: "multiple_mid", header: "Mid x", kind: "multiple", width: "5rem" },
  { key: "multiple_high", header: "High x", kind: "multiple", width: "5rem" },
  { key: "value", header: "Or a value", kind: "money", width: "7rem", hint: "E.g. from a separate DCF" },
]

function NavInputs({ doc }: { doc: MethodsDoc }) {
  const state = useSectionDraft("nav", doc.nav)
  const d = state.draft
  if (!d) return null
  return (
    <SectionForm
      title="Net asset value"
      description="Start from the book balance sheet and revalue each asset and liability with its own method."
      state={state}
    >
      <ListEditor
        caption="Assets and liabilities"
        rows={d.lines}
        onChange={(lines) => state.update((x) => ({ ...x, lines }))}
        columns={NAV_COLUMNS}
        newRow={(): NAVLine => ({ name: "", side: "asset", book_value: 0, method: "book", fair_value: null, noi: null, cap_rate: null, metric: null, multiple: null, taxable: true })}
        addLabel="Add line"
        rowLabel={(r, i) => r.name || `Line ${i + 1}`}
        empty="No lines yet. Add each material asset and liability with its book value, then choose how to revalue it."
      />
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="sm:pt-5">
          <SwitchField
            label="Deduct deferred tax on gains"
            checked={d.deferred_tax_on_gains}
            onChange={(x) => state.update((y) => ({ ...y, deferred_tax_on_gains: x }))}
          />
        </div>
        <NumField
          label="Tax rate on gains"
          kind="pct"
          value={d.tax_rate}
          min={0}
          max={1}
          placeholder="Valuation rate"
          onChange={(x) => state.update((y) => ({ ...y, tax_rate: x }))}
        />
        <NumField
          label="Holding-company discount"
          kind="pct"
          value={d.holding_discount}
          nullable={false}
          min={0}
          max={0.99}
          onChange={(x) => state.update((y) => ({ ...y, holding_discount: x ?? 0 }))}
        />
      </div>
    </SectionForm>
  )
}

function SotpInputs({ doc }: { doc: MethodsDoc }) {
  const state = useSectionDraft("sotp", doc.sotp)
  const d = state.draft
  if (!d) return null
  return (
    <SectionForm
      title="Sum of the parts"
      description="Value each segment with its own multiple (or a value from another method), then deduct capitalised head-office costs and net debt."
      state={state}
    >
      <ListEditor
        caption="Segments"
        rows={d.segments}
        onChange={(segments) => state.update((x) => ({ ...x, segments }))}
        columns={SEGMENT_COLUMNS}
        newRow={() => ({ name: "", metric_label: "EBITDA", metric: null, multiple_low: null, multiple_mid: null, multiple_high: null, value: null })}
        addLabel="Add segment"
        rowLabel={(r, i) => r.name || `Segment ${i + 1}`}
        empty="No segments yet."
      />
      <div className="grid gap-3 sm:grid-cols-4">
        <NumField label="Non-core assets" kind="money" value={d.non_core_assets} nullable={false} onChange={(x) => state.update((y) => ({ ...y, non_core_assets: x ?? 0 }))} />
        <NumField label="Corporate costs / year" kind="money" value={d.corporate_costs} nullable={false} min={0} onChange={(x) => state.update((y) => ({ ...y, corporate_costs: x ?? 0 }))} />
        <NumField label="… capitalised at" kind="multiple" value={d.corporate_cost_multiple} nullable={false} min={0} onChange={(x) => state.update((y) => ({ ...y, corporate_cost_multiple: x ?? 0 }))} />
        <NumField label="Conglomerate discount" kind="pct" value={d.conglomerate_discount} nullable={false} min={0} max={0.99} onChange={(x) => state.update((y) => ({ ...y, conglomerate_discount: x ?? 0 }))} />
      </div>
    </SectionForm>
  )
}

export function NavTab({ doc, v }: { doc: MethodsDoc; v: ValuationResponse }) {
  const { currency } = useMethodsContext()
  const money = useMoney()
  const nav = v.methods.find((m) => m.id === "nav") as MethodOutput<NAVResult> | undefined
  const sotp = v.methods.find((m) => m.id === "sotp") as MethodOutput<SOTPResult> | undefined
  const n = nav?.result
  const s = sotp?.result
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-4">
        <MethodStatus output={nav} what="Net asset value" />
        {n ? (
          <>
            <RangeLine output={nav} />
            <div className="grid gap-4 lg:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
              <DataTable
                caption={`Revaluation (${money.unit})`}
                head={["Line", "Method", "Book", "Fair value", "Revaluation"]}
                rows={n.lines.map((l) => [
                  `${l.side === "liability" ? "− " : ""}${l.name}`,
                  METHOD_LABEL[l.method as NAVLine["method"]] ?? l.method,
                  money.scaled(l.book_value),
                  money.scaled(l.fair_value),
                  money.scaled(l.revaluation),
                ])}
              />
              <DataTable
                caption={`Net asset value (${money.unit})`}
                head={["", "Amount"]}
                emphasise={[3, 5]}
                rows={[
                  ["Book NAV", money.scaled(n.book_nav)],
                  ["+ Revaluation gain", money.scaled(n.revaluation_gain)],
                  ["− Deferred tax on gains", money.scaled(-n.deferred_tax)],
                  ["NAV before discount", money.scaled(n.nav_before_discount)],
                  ["− Holding-company discount", money.scaled(-n.holding_discount)],
                  ["NAV", money.scaled(n.nav)],
                  ...(n.nav_per_share !== null ? [["NAV per share", `${currency} ${formatAccounting(n.nav_per_share, 2)}`]] : []),
                  ...(n.premium_to_nav !== null
                    ? [[n.premium_to_nav >= 0 ? "Share price premium to NAV" : "Share price discount to NAV", formatPct(Math.abs(n.premium_to_nav))]]
                    : []),
                ]}
              />
            </div>
          </>
        ) : null}
        <NavInputs doc={doc} />
      </div>
      <div className="flex flex-col gap-4">
        <MethodStatus output={sotp} what="Sum of the parts" />
        {s ? (
          <>
            <RangeLine output={sotp} />
            <DataTable
              caption={`Sum of the parts (${money.unit})`}
              head={["", "Low", "Mid", "High"]}
              emphasise={[s.segments.length, s.segments.length + 4, s.segments.length + 5]}
              rows={[
                ...s.segments.map((seg) => [seg.name, money.scaled(seg.low), money.scaled(seg.mid), money.scaled(seg.high)]),
                ["Segments", ...s.gross_ev.map((x) => money.scaled(x))],
                ["− Capitalised corporate costs", ...s.gross_ev.map(() => money.scaled(-s.corporate_costs_capitalised))],
                ["+ Non-core assets", ...s.gross_ev.map(() => money.scaled(s.non_core_assets))],
                ["− Conglomerate discount", ...s.conglomerate_discount.map((x) => money.scaled(-x))],
                ["Enterprise value", ...s.ev.map((x) => money.scaled(x))],
                ["Equity value (after net debt)", ...s.equity.map((x) => money.scaled(x))],
              ]}
            />
          </>
        ) : null}
        <SotpInputs doc={doc} />
      </div>
    </div>
  )
}
