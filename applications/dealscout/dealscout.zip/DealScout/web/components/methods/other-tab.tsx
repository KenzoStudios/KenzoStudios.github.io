"use client"

import * as React from "react"

import { formatAccounting } from "@/lib/format"
import type { MethodOutput, MethodsDoc, RecoveryLine, ReplacementLine, ValuationResponse } from "@/lib/types"

import {
  type Column,
  DataTable,
  ListEditor,
  MethodStatus,
  NumField,
  NumListField,
  RangeLine,
  SectionForm,
  SelectField,
  SwitchField,
  useMethodsContext,
  useMoney,
  useSectionDraft,
} from "./kit"

const RECOVERY_COLUMNS: Column<RecoveryLine>[] = [
  { key: "name", header: "Asset class", kind: "text", width: "11rem" },
  { key: "book_value", header: "Book value", kind: "money", nullable: false, width: "7rem" },
  { key: "recovery_low", header: "Recovery low", kind: "pct", nullable: false, width: "6rem" },
  { key: "recovery_high", header: "Recovery high", kind: "pct", nullable: false, width: "6rem" },
]

const REPLACEMENT_COLUMNS: Column<ReplacementLine>[] = [
  { key: "name", header: "Asset", kind: "text", width: "11rem" },
  { key: "replacement_cost", header: "Cost to replace", kind: "money", nullable: false, width: "7rem" },
  { key: "physical_obsolescence", header: "Physical", kind: "pct", nullable: false, width: "5.5rem" },
  { key: "functional_obsolescence", header: "Functional", kind: "pct", nullable: false, width: "5.5rem" },
  { key: "economic_obsolescence", header: "Economic", kind: "pct", nullable: false, width: "5.5rem" },
]

function LiquidationInputs({ doc }: { doc: MethodsDoc }) {
  const state = useSectionDraft("liquidation", doc.liquidation)
  const d = state.draft
  if (!d) return null
  return (
    <SectionForm title="Liquidation value" description="Book value × recovery rate by asset class, less liabilities and wind-down costs." state={state}>
      <ListEditor
        caption="Assets and recovery rates"
        rows={d.assets}
        onChange={(assets) => state.update((x) => ({ ...x, assets }))}
        columns={RECOVERY_COLUMNS}
        newRow={() => ({ name: "", book_value: 0, recovery_low: 0, recovery_high: 0 })}
        addLabel="Add asset class"
        rowLabel={(r, i) => r.name || `Asset ${i + 1}`}
      />
      <div className="grid gap-3 sm:grid-cols-4">
        <NumField label="Wind-down costs" kind="money" value={d.wind_down_costs} nullable={false} min={0} onChange={(x) => state.update((y) => ({ ...y, wind_down_costs: x ?? 0 }))} />
      </div>
    </SectionForm>
  )
}

function ReplacementInputs({ doc }: { doc: MethodsDoc }) {
  const state = useSectionDraft("replacement", doc.replacement)
  const d = state.draft
  if (!d) return null
  return (
    <SectionForm title="Replacement cost" description="Cost to rebuild the asset base, less physical, functional and economic obsolescence." state={state}>
      <ListEditor
        caption="Assets to replace"
        rows={d.lines}
        onChange={(lines) => state.update(() => ({ lines }))}
        columns={REPLACEMENT_COLUMNS}
        newRow={() => ({ name: "", replacement_cost: 0, physical_obsolescence: 0, functional_obsolescence: 0, economic_obsolescence: 0 })}
        addLabel="Add asset"
        rowLabel={(r, i) => r.name || `Asset ${i + 1}`}
      />
    </SectionForm>
  )
}

function DlomInputs({ doc, listed }: { doc: MethodsDoc; listed: boolean }) {
  const state = useSectionDraft("dlom", doc.dlom)
  const d = state.draft
  type D = NonNullable<MethodsDoc["dlom"]>
  const set = <K extends keyof D>(key: K, value: D[K]) => state.update((x) => (x ? { ...x, [key]: value } : x))
  return (
    <SectionForm
      title="Discount for lack of marketability"
      description={listed ? "Listed deal: the discount is stored but not applied." : "Private company: enter your own rates. DealScout has no sourced default."}
      state={state}
    >
      <SwitchField
        label="Apply a marketability discount"
        checked={!!d}
        onChange={(on) => state.replace(on ? { low: 0, mid: 0, high: 0, applies_to: "market_methods" } : null)}
      />
      {d ? (
        <div className="grid gap-3 sm:grid-cols-4">
          <NumField label="Low" kind="pct" value={d.low} nullable={false} min={0} max={0.99} onChange={(x) => set("low", x ?? 0)} />
          <NumField label="Mid" kind="pct" value={d.mid} nullable={false} min={0} max={0.99} onChange={(x) => set("mid", x ?? 0)} />
          <NumField label="High" kind="pct" value={d.high} nullable={false} min={0} max={0.99} onChange={(x) => set("high", x ?? 0)} />
          <SelectField
            label="Applies to"
            value={d.applies_to}
            options={[
              { value: "market_methods", label: "Trading comps" },
              { value: "all_methods", label: "All methods" },
            ]}
            onChange={(x) => set("applies_to", x)}
          />
        </div>
      ) : null}
    </SectionForm>
  )
}

function MarketInputs({ doc }: { doc: MethodsDoc }) {
  const state = useSectionDraft("market", doc.market)
  const d = state.draft
  if (!d) return null
  type M = MethodsDoc["market"]
  const set = <K extends keyof M>(key: K, value: M[K]) => state.update((x) => ({ ...x, [key]: value }))
  return (
    <SectionForm title="Market reference points" description="For listed targets, from your own price data. Shown on the football field context, not weighted." state={state}>
      <div className="grid gap-3 sm:grid-cols-4">
        <NumField label="52-week high" kind="price" value={d.high_52w} min={0} onChange={(x) => set("high_52w", x)} />
        <NumField label="52-week low" kind="price" value={d.low_52w} min={0} onChange={(x) => set("low_52w", x)} />
        <NumField label="VWAP 30 days" kind="price" value={d.vwap_30d} min={0} onChange={(x) => set("vwap_30d", x)} />
        <NumField label="VWAP 90 days" kind="price" value={d.vwap_90d} min={0} onChange={(x) => set("vwap_90d", x)} />
        <div className="sm:col-span-2">
          <NumListField label="Analyst price targets" kind="price" values={d.analyst_targets} onChange={(t) => set("analyst_targets", t)} description="Separate with semicolons" />
        </div>
      </div>
    </SectionForm>
  )
}

export function OtherTab({ doc, v }: { doc: MethodsDoc; v: ValuationResponse }) {
  const { currency } = useMethodsContext()
  const money = useMoney()
  const liq = v.methods.find((m) => m.id === "liquidation") as
    | MethodOutput<{ proceeds_low: number; proceeds_high: number; equity_low: number; equity_high: number; liabilities: number }>
    | undefined
  const rep = v.methods.find((m) => m.id === "replacement") as MethodOutput<{ enterprise_value: number; equity_value: number }> | undefined
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-4">
        <MethodStatus output={liq} what="Liquidation value" />
        {liq?.result ? (
          <>
            <RangeLine output={liq} />
            <DataTable
              caption={`Liquidation (${money.unit})`}
              head={["", "Low", "High"]}
              emphasise={[2]}
              rows={[
                ["Recovered from assets", money.scaled(liq.result.proceeds_low), money.scaled(liq.result.proceeds_high)],
                ["Liabilities ranking ahead (plus wind-down costs)", money.scaled(liq.result.liabilities), money.scaled(liq.result.liabilities)],
                ["To shareholders (never below zero)", money.scaled(liq.result.equity_low), money.scaled(liq.result.equity_high)],
              ]}
            />
          </>
        ) : null}
        <LiquidationInputs doc={doc} />
      </div>
      <div className="flex flex-col gap-4">
        <MethodStatus output={rep} what="Replacement cost" />
        {rep?.result ? <RangeLine output={rep} /> : null}
        <ReplacementInputs doc={doc} />
      </div>
      <DlomInputs doc={doc} listed={v.deal.listed} />
      <div className="flex flex-col gap-4">
        {v.market_points.length ? (
          <DataTable
            caption="Market reference points"
            head={["", "Per share", "All shares"]}
            rows={v.market_points.map((p) => [p.label, p.price === null ? "" : `${currency} ${formatAccounting(p.price, 2)}`, money.compact(p.equity)])}
          />
        ) : null}
        <MarketInputs doc={doc} />
      </div>
    </div>
  )
}
