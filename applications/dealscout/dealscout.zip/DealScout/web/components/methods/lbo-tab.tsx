"use client"

import * as React from "react"
import { TriangleAlertIcon } from "lucide-react"

import { DebtPaydownChart, LeverageChart } from "@/components/charts/lbo-charts"
import { SensitivityHeatmap } from "@/components/charts/valuation-charts"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { formatMultiple, formatPct } from "@/lib/format"
import type { LBOResultPayload, LBOSettings, MethodOutput, MethodsDoc, OperatingYear, Tranche, ValuationResponse } from "@/lib/types"

import {
  type Column,
  DataTable,
  ListEditor,
  MethodStatus,
  NumField,
  RangeLine,
  SectionForm,
  StatTiles,
  SwitchField,
  useMethodsContext,
  useMoney,
  useSectionDraft,
} from "./kit"

const KIND_OPTIONS = [
  { value: "revolver", label: "Revolver" },
  { value: "term_loan_a", label: "Term loan A" },
  { value: "term_loan_b", label: "Term loan B" },
  { value: "senior_notes", label: "Senior notes" },
  { value: "high_yield", label: "High yield" },
  { value: "mezzanine", label: "Mezzanine" },
  { value: "seller_note", label: "Seller note" },
  { value: "other", label: "Other" },
]

const TRANCHE_COLUMNS: Column<Tranche>[] = [
  { key: "name", header: "Tranche", kind: "text", width: "9rem" },
  { key: "kind", header: "Type", kind: "select", options: KIND_OPTIONS, width: "8.5rem" },
  { key: "size_x_ebitda", header: "Size × EBITDA", kind: "multiple", width: "6.5rem", hint: "Or enter an amount" },
  { key: "amount", header: "or amount", kind: "money", width: "6.5rem" },
  {
    key: "rate_type",
    header: "Rate",
    kind: "select",
    options: [
      { value: "floating", label: "Base + margin" },
      { value: "fixed", label: "Fixed" },
    ],
    width: "8rem",
  },
  { key: "margin", header: "Margin", kind: "pct", width: "5.5rem" },
  { key: "fixed_rate", header: "Fixed rate", kind: "pct", width: "5.5rem" },
  { key: "base_rate_floor", header: "Floor", kind: "pct", width: "5rem", nullable: false },
  { key: "amortization_pct", header: "Amort. / yr", kind: "pct", width: "5.5rem", nullable: false, hint: "% of original principal" },
  { key: "pik", header: "PIK", kind: "check", width: "3rem" },
  { key: "priority", header: "Sweep order", kind: "int", width: "4.5rem", nullable: false },
  { key: "fee_pct", header: "Fee", kind: "pct", width: "5rem", nullable: false },
  { key: "commitment", header: "Commitment", kind: "money", width: "6.5rem", hint: "Revolver facility size" },
]

const NEW_TRANCHE = (): Tranche => ({
  name: "New tranche",
  kind: "term_loan_b",
  size_x_ebitda: null,
  amount: null,
  rate_type: "floating",
  fixed_rate: null,
  margin: null, // never pre-filled: market margins are not sourced
  base_rate_floor: 0,
  amortization_pct: 0,
  pik: false,
  sweep: null,
  priority: 1,
  fee_pct: 0,
  commitment: null,
})

const CASE_COLUMNS: Column<OperatingYear>[] = [
  { key: "label", header: "Year", kind: "text", width: "5rem" },
  { key: "revenue", header: "Revenue", kind: "money", nullable: false, width: "7rem" },
  { key: "ebitda", header: "EBITDA", kind: "money", nullable: false, width: "7rem" },
  { key: "da", header: "D&A", kind: "money", nullable: false, width: "6rem" },
  { key: "capex", header: "Capex", kind: "money", nullable: false, width: "6rem" },
  { key: "change_in_nwc", header: "Increase in NWC", kind: "money", nullable: false, width: "7rem" },
]

function LboInputs({ doc, v }: { doc: MethodsDoc; v: ValuationResponse }) {
  const state = useSectionDraft("lbo", doc.lbo)
  const d = state.draft
  if (!d) return null
  const set = <K extends keyof LBOSettings>(key: K, value: LBOSettings[K]) => state.update((x) => ({ ...x, [key]: value }))
  const projection = v.result.dcf?.projection ?? []
  return (
    <SectionForm
      title="Deal and financing inputs"
      description="Leverage, margins and fees are your financing terms: DealScout has no sourced market figures for them and never fills them in."
      state={state}
    >
      <fieldset className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <legend className="mb-2 text-xs font-semibold text-muted-foreground">Entry</legend>
        <NumField
          label="Entry EV / EBITDA"
          kind="multiple"
          value={d.entry_multiple}
          onChange={(x) => set("entry_multiple", x)}
          min={0.1}
          placeholder="DCF value"
          description="Empty: the DCF enterprise value"
        />
        <NumField
          label="Or price per share"
          kind="price"
          value={d.entry_price_per_share}
          onChange={(x) => set("entry_price_per_share", x)}
          min={0}
          description="Overrides the multiple"
        />
        <NumField label="Transaction fees (% EV)" kind="pct" value={d.transaction_fee_pct} nullable={false} max={0.2} onChange={(x) => set("transaction_fee_pct", x ?? 0)} />
        <NumField label="Minimum cash" kind="money" value={d.minimum_cash} nullable={false} min={0} onChange={(x) => set("minimum_cash", x ?? 0)} />
        <NumField label="Rollover equity" kind="money" value={d.rollover_equity} nullable={false} min={0} onChange={(x) => set("rollover_equity", x ?? 0)} />
        <NumField label="Management promote" kind="pct" value={d.management_promote_pct} nullable={false} max={0.5} onChange={(x) => set("management_promote_pct", x ?? 0)} description="Share of exit equity" />
      </fieldset>

      <fieldset className="flex flex-col gap-3">
        <legend className="mb-2 text-xs font-semibold text-muted-foreground">Debt tranches</legend>
        <ListEditor
          caption="Debt tranches"
          rows={d.tranches}
          onChange={(rows) => set("tranches", rows)}
          columns={TRANCHE_COLUMNS}
          newRow={() => {
            // each tranche needs its own name (the schedule tracks balances by name)
            const taken = new Set(d.tranches.map((t) => t.name.trim().toLowerCase()))
            let n = d.tranches.length + 1
            while (taken.has(`tranche ${n}`)) n += 1
            return { ...NEW_TRANCHE(), name: `Tranche ${n}` }
          }}
          addLabel="Add tranche"
          rowLabel={(r) => r.name || "Tranche"}
          max={12}
          empty="No debt yet. Add the tranches of your financing structure (size, rate, amortisation)."
        />
        <p className="text-xs text-muted-foreground">
          Revolver and term loans are repaid from excess cash in sweep order; notes, high yield, mezzanine and seller notes are repaid at exit.
          A revolver with a commitment is drawn only to cover shortfalls.
        </p>
        <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <NumField
            label="Base rate"
            kind="pct"
            value={d.base_rate}
            onChange={(x) => set("base_rate", x)}
            min={0}
            max={1}
            placeholder="Sourced"
            description="Empty: SOFR, EURIBOR 3M or SONIA by currency"
          />
          <NumField label="Cash sweep" kind="pct" value={d.cash_sweep_pct} nullable={false} min={0} max={1} onChange={(x) => set("cash_sweep_pct", x ?? 1)} description="Share of excess cash" />
          <div className="sm:col-span-2 lg:col-span-4 lg:pt-5">
            <SwitchField
              label="Interest on average balances"
              checked={d.interest_on_average}
              onChange={(x) => set("interest_on_average", x)}
              description="Solves the circular link between interest and cash by iteration; off uses opening balances."
            />
          </div>
        </div>
      </fieldset>

      <fieldset className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <legend className="mb-2 text-xs font-semibold text-muted-foreground">Exit, returns and covenants</legend>
        <NumField label="Exit year" kind="int" value={d.exit_year} min={1} max={15} onChange={(x) => set("exit_year", x)} placeholder="5" />
        <NumField label="Exit EV / EBITDA" kind="multiple" value={d.exit_multiple} min={0.1} onChange={(x) => set("exit_multiple", x)} placeholder="= entry" />
        <NumField label="Exit costs (% EV)" kind="pct" value={d.exit_cost_pct} nullable={false} max={0.1} onChange={(x) => set("exit_cost_pct", x ?? 0)} />
        <NumField label="Target IRR" kind="pct" value={d.target_irr} onChange={(x) => set("target_irr", x)} placeholder="20 (convention)" />
        <NumField label="Target MOIC" kind="multiple" value={d.target_moic} min={0.1} onChange={(x) => set("target_moic", x)} description="Optional, with the IRR" />
        <NumField label="Max net debt / EBITDA" kind="multiple" value={d.max_leverage} min={0.1} onChange={(x) => set("max_leverage", x)} description="Covenant" />
        <NumField label="Min EBITDA / interest" kind="multiple" value={d.min_interest_coverage} min={0.1} onChange={(x) => set("min_interest_coverage", x)} description="Covenant" />
        <NumField label="Dividend recap year" kind="int" value={d.dividend_recap_year} min={1} max={15} onChange={(x) => set("dividend_recap_year", x)} />
        <NumField label="Recap size × EBITDA" kind="multiple" value={d.dividend_recap_x_ebitda} nullable={false} min={0} onChange={(x) => set("dividend_recap_x_ebitda", x ?? 0)} />
      </fieldset>

      <fieldset className="flex flex-col gap-3">
        <legend className="mb-2 text-xs font-semibold text-muted-foreground">Operating case</legend>
        <SwitchField
          label="Use a separate sponsor case"
          checked={d.sponsor_case !== null}
          onChange={(on) =>
            set(
              "sponsor_case",
              on
                ? projection.map((y) => ({ label: y.label, revenue: y.revenue, ebitda: y.ebitda, da: y.da, capex: y.capex, change_in_nwc: y.change_in_nwc }))
                : null,
            )
          }
          description="Off: the LBO reuses the DCF projection. On: starts from it, then edit the years."
        />
        {d.sponsor_case !== null ? (
          <ListEditor
            caption="Sponsor case"
            rows={d.sponsor_case}
            onChange={(rows) => set("sponsor_case", rows)}
            columns={CASE_COLUMNS}
            newRow={() => ({ label: `Y${(d.sponsor_case?.length ?? 0) + 1}`, revenue: 0, ebitda: 0, da: 0, capex: 0, change_in_nwc: 0 })}
            addLabel="Add year"
            rowLabel={(r) => r.label}
            max={15}
          />
        ) : null}
      </fieldset>
    </SectionForm>
  )
}

function LboResults({ output, covenant }: { output: MethodOutput<LBOResultPayload>; covenant: number | null }) {
  const { scale } = useMethodsContext()
  const money = useMoney()
  const r = output.result
  if (!r) return null
  const c = r.case
  const t = r.inputs.target_irr
  const schedule = c.schedule
  const line = (label: string, values: (number | null)[], fmt: (v: number | null) => string = money.scaled) => [label, ...values.map((x) => fmt(x))]
  const x = (v: number | null) => formatMultiple(v)
  return (
    <div className="flex flex-col gap-4">
      <RangeLine output={output} />
      <StatTiles
        items={[
          { label: "Sponsor IRR", value: formatPct(c.sponsor.irr), hint: `MOIC ${formatMultiple(c.sponsor.moic, 2)} at ${formatMultiple(r.inputs.entry_multiple)} entry` },
          {
            label: `Max price for ${formatPct(t, 0)} IRR`,
            value: r.max_price.equity_purchase_price === null ? "n/m" : money.compact(r.max_price.equity_purchase_price),
            hint: r.max_price.entry_multiple ? `${formatMultiple(r.max_price.entry_multiple)} EV / EBITDA` : r.max_price.note,
          },
          { label: "Leverage at close", value: formatMultiple(c.leverage_at_close), hint: `Debt ${money.compact(c.total_debt_at_close)}` },
          { label: "Exit equity", value: money.compact(c.exit_equity), hint: `Year ${r.inputs.exit_year} at ${formatMultiple(c.exit_multiple)}` },
        ]}
      />
      {r.notes.length || c.warnings.length ? (
        <ul className="flex flex-col gap-0.5 text-xs text-muted-foreground">
          {[...r.notes, ...c.warnings].map((n) => <li key={n}>{n}</li>)}
        </ul>
      ) : null}
      {c.covenant_breaches.length ? (
        <Alert className="border-warning/40 bg-warning-bg">
          <TriangleAlertIcon className="text-warning" />
          <AlertTitle>Covenant breaches</AlertTitle>
          <AlertDescription>
            <ul className="list-disc pl-4">{c.covenant_breaches.map((b) => <li key={b}>{b}</li>)}</ul>
          </AlertDescription>
        </Alert>
      ) : null}
      <div className="grid gap-6 lg:grid-cols-2">
        <DebtPaydownChart lbo={r} scale={scale} unit={money.unit} />
        <LeverageChart lbo={r} covenant={covenant} />
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <DataTable caption={`Sources (${money.unit})`} head={["Source", "Amount"]} rows={c.sources.map((s) => [s.label, money.scaled(s.amount)])} />
        <DataTable caption={`Uses (${money.unit})`} head={["Use", "Amount"]} rows={c.uses.map((s) => [s.label, money.scaled(s.amount)])} />
      </div>
      <DataTable
        caption={`Debt schedule and cash flow (${money.unit})`}
        head={["", ...schedule.map((y) => y.label)]}
        emphasise={[4, 12, 13]}
        rows={[
          line("EBITDA", schedule.map((y) => y.ebitda)),
          line("− Capex", schedule.map((y) => -y.capex)),
          line("− Increase in NWC", schedule.map((y) => -y.change_in_nwc)),
          line("− Cash taxes", schedule.map((y) => -y.cash_taxes)),
          line("Cash flow before financing", schedule.map((y) => y.operating_cash_flow)),
          line("− Cash interest", schedule.map((y) => -y.cash_interest)),
          line("PIK interest (accrued)", schedule.map((y) => y.pik_interest)),
          line("− Mandatory repayment", schedule.map((y) => -y.mandatory_repayment)),
          line("− Cash sweep", schedule.map((y) => -y.sweep)),
          line("+ Revolver draw", schedule.map((y) => y.revolver_draw)),
          line("− Dividend (recap)", schedule.map((y) => -y.dividend)),
          line("Closing cash", schedule.map((y) => y.closing_cash)),
          line("Total debt", schedule.map((y) => y.total_debt)),
          line("Net debt", schedule.map((y) => y.net_debt)),
          line("Net debt / EBITDA", schedule.map((y) => y.leverage), x),
          line("EBITDA / cash interest", schedule.map((y) => y.interest_coverage), x),
        ]}
      />
      <DataTable
        caption={`Returns (${money.unit})`}
        head={["", "Invested", "Proceeds", "IRR", "MOIC"]}
        rows={[
          ["Sponsor", money.scaled(c.sponsor.equity_invested), money.scaled(c.sponsor.proceeds), formatPct(c.sponsor.irr), formatMultiple(c.sponsor.moic, 2)],
          ...(c.rollover
            ? [["Management / rollover", money.scaled(c.rollover.equity_invested), money.scaled(c.rollover.proceeds), formatPct(c.rollover.irr), formatMultiple(c.rollover.moic, 2)]]
            : []),
        ]}
      />
      <section aria-labelledby="lbo-sens" className="flex flex-col gap-2">
        <h3 id="lbo-sens" className="text-sm font-semibold">Sponsor IRR sensitivities</h3>
        <p className="text-xs text-muted-foreground">
          Teal is above the {formatPct(t, 0)} target, rose below; the outlined cell is the case above.
        </p>
        <div className="grid gap-6 lg:grid-cols-2">
          {r.sensitivities.map((grid) => (
            <SensitivityHeatmap
              key={grid.title}
              table={grid}
              currency=""
              rowFormat={(v) => formatMultiple(v)}
              colFormat={(v) => formatMultiple(v)}
              valueFormat={(v) => formatPct(v)}
              center={t}
              centerLabel="target"
            />
          ))}
        </div>
      </section>
    </div>
  )
}

export function LboTab({ doc, v }: { doc: MethodsDoc; v: ValuationResponse }) {
  const output = v.methods.find((m) => m.id === "lbo") as MethodOutput<LBOResultPayload> | undefined
  const formRef = React.useRef<HTMLDivElement>(null)
  return (
    <div className="flex flex-col gap-6">
      {output?.status !== "ready" ? (
        <div className="flex flex-col gap-2">
          <MethodStatus output={output} what="The LBO" />
          {output?.status === "needs_input" ? (
            <div>
              <Button variant="outline" size="sm" onClick={() => formRef.current?.querySelector<HTMLInputElement>("input")?.focus()}>
                Go to the inputs
              </Button>
            </div>
          ) : null}
        </div>
      ) : null}
      {output?.result ? <LboResults output={output} covenant={doc.lbo.max_leverage} /> : null}
      <div ref={formRef}>
        <LboInputs doc={doc} v={v} />
      </div>
    </div>
  )
}
