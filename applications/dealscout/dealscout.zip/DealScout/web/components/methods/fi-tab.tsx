"use client"

import * as React from "react"

import { formatMultiple, formatPct } from "@/lib/format"
import type { MethodOutput, MethodsDoc, ValuationResponse } from "@/lib/types"

import {
  DataTable,
  MethodStatus,
  NumField,
  NumListField,
  RangeLine,
  SectionForm,
  StatusBadge,
  SwitchField,
  useMoney,
  useSectionDraft,
} from "./kit"

type FI = MethodsDoc["fi"]

interface ValueResult {
  value: number
  pv_explicit: number
  pv_terminal: number
  terminal_share: number
  cost_of_equity?: number
  book_value?: number
  dividend?: number
}

interface APVResult {
  unlevered_value: number
  pv_tax_shields: number
  distress_cost: number
  enterprise_value: number
  equity_value: number
  unlevered_cost_of_equity: number
  cost_of_debt: number
  debt_source: "entered" | "lbo"
}

function ValueSummary({ output, extra }: { output: MethodOutput<ValueResult> | undefined; extra?: [string, string][] }) {
  const money = useMoney()
  const r = output?.result
  if (!r) return null
  return (
    <DataTable
      caption={`${output.label} (${money.unit})`}
      head={["", "Amount"]}
      emphasise={[2]}
      rows={[
        ["PV of the explicit period", money.scaled(r.pv_explicit)],
        ["PV of the terminal value", `${money.scaled(r.pv_terminal)} (${formatPct(r.terminal_share, 0)} of value)`],
        ["Equity value", money.scaled(r.value)],
        ...(r.cost_of_equity !== undefined ? [["Cost of equity", formatPct(r.cost_of_equity)] as [string, string]] : []),
        ...(extra ?? []),
      ]}
    />
  )
}

function Block({ title, output, children }: { title: string; output: MethodOutput | undefined; children: React.ReactNode }) {
  return (
    <section className="flex flex-col gap-3" aria-label={title}>
      <div className="flex items-center gap-2">
        <h3 className="text-sm font-semibold">{title}</h3>
        <StatusBadge output={output} />
      </div>
      {output?.status === "ready" ? null : <MethodStatus output={output} what={title} />}
      {children}
    </section>
  )
}

function FiInputs({ doc, v }: { doc: MethodsDoc; v: ValuationResponse }) {
  const state = useSectionDraft("fi", doc.fi)
  const d = state.draft
  if (!d) return null
  const set = <K extends keyof FI>(key: K, value: FI[K]) => state.update((x) => ({ ...x, [key]: value }))
  const years = v.result.dcf?.projection.length ?? 5
  return (
    <SectionForm
      title="Inputs"
      description="Empty rates use the cost of equity from the WACC build and the DCF terminal growth."
      state={state}
    >
      <fieldset className="flex flex-col gap-3">
        <legend className="mb-2 text-xs font-semibold text-muted-foreground">Dividend discount (two-stage)</legend>
        <SwitchField
          label="Use a dividend discount model"
          checked={d.ddm !== null}
          onChange={(on) => set("ddm", on ? { current_dividend: null, high_growth: 0, years: 5, terminal_growth: null, cost_of_equity: null } : null)}
        />
        {d.ddm ? (
          <div className="grid gap-3 sm:grid-cols-5">
            <NumField label="Current dividends" kind="money" value={d.ddm.current_dividend} min={0} placeholder="Last year paid" onChange={(x) => set("ddm", { ...d.ddm!, current_dividend: x })} />
            <NumField label="High growth" kind="pct" value={d.ddm.high_growth} nullable={false} onChange={(x) => set("ddm", { ...d.ddm!, high_growth: x ?? 0 })} />
            <NumField label="… for years" kind="int" value={d.ddm.years} nullable={false} min={0} max={30} onChange={(x) => set("ddm", { ...d.ddm!, years: x ?? 0 })} />
            <NumField label="Terminal growth" kind="pct" value={d.ddm.terminal_growth} placeholder="DCF" onChange={(x) => set("ddm", { ...d.ddm!, terminal_growth: x })} />
            <NumField label="Cost of equity" kind="pct" value={d.ddm.cost_of_equity} placeholder="WACC build" onChange={(x) => set("ddm", { ...d.ddm!, cost_of_equity: x })} />
          </div>
        ) : null}
      </fieldset>

      <fieldset className="flex flex-col gap-3">
        <legend className="mb-2 text-xs font-semibold text-muted-foreground">Residual income</legend>
        <SwitchField
          label="Use residual income"
          checked={d.residual_income !== null}
          onChange={(on) => set("residual_income", on ? { roe: [], payout_ratio: 0, terminal_growth: 0, cost_of_equity: null } : null)}
        />
        {d.residual_income ? (
          <div className="grid gap-3 sm:grid-cols-4">
            <div className="sm:col-span-2">
              <NumListField
                label="Return on equity by year (%)"
                kind="pct"
                values={d.residual_income.roe}
                onChange={(roe) => set("residual_income", { ...d.residual_income!, roe })}
                description="E.g. 12; 12.5; 13 (one per year, up to 30)"
              />
            </div>
            <NumField label="Payout ratio" kind="pct" value={d.residual_income.payout_ratio} nullable={false} min={0} max={1} onChange={(x) => set("residual_income", { ...d.residual_income!, payout_ratio: x ?? 0 })} />
            <NumField label="Residual income growth" kind="pct" value={d.residual_income.terminal_growth} nullable={false} onChange={(x) => set("residual_income", { ...d.residual_income!, terminal_growth: x ?? 0 })} description="0 = held flat" />
            <NumField label="Cost of equity" kind="pct" value={d.residual_income.cost_of_equity} placeholder="WACC build" onChange={(x) => set("residual_income", { ...d.residual_income!, cost_of_equity: x })} />
          </div>
        ) : null}
      </fieldset>

      <fieldset className="grid gap-3 sm:grid-cols-3">
        <legend className="mb-2 text-xs font-semibold text-muted-foreground">Price / tangible book (multiples you choose)</legend>
        <NumField label="Low" kind="multiple" value={d.ptbv_low} min={0.01} onChange={(x) => set("ptbv_low", x)} />
        <NumField label="Mid" kind="multiple" value={d.ptbv_mid} min={0.01} onChange={(x) => set("ptbv_mid", x)} />
        <NumField label="High" kind="multiple" value={d.ptbv_high} min={0.01} onChange={(x) => set("ptbv_high", x)} />
      </fieldset>

      <fieldset className="flex flex-col gap-3">
        <legend className="mb-2 text-xs font-semibold text-muted-foreground">Free cash flow to equity</legend>
        <SwitchField
          label="Use FCFE"
          checked={d.fcfe !== null}
          onChange={(on) => set("fcfe", on ? { net_income: [], net_borrowing: null, terminal_growth: null, cost_of_equity: null } : null)}
          description={`Reuses the DCF's D&A, capex and working capital; enter net income for up to ${years} years.`}
        />
        {d.fcfe ? (
          <div className="grid gap-3 sm:grid-cols-4">
            <NumListField label="Net income by year" kind="money" values={d.fcfe.net_income} onChange={(net_income) => set("fcfe", { ...d.fcfe!, net_income })} />
            <NumListField label="Net borrowing by year" kind="money" values={d.fcfe.net_borrowing} onChange={(nb) => set("fcfe", { ...d.fcfe!, net_borrowing: nb.length ? nb : null })} description="Empty: none" />
            <NumField label="Terminal growth" kind="pct" value={d.fcfe.terminal_growth} placeholder="DCF" onChange={(x) => set("fcfe", { ...d.fcfe!, terminal_growth: x })} />
            <NumField label="Cost of equity" kind="pct" value={d.fcfe.cost_of_equity} placeholder="WACC build" onChange={(x) => set("fcfe", { ...d.fcfe!, cost_of_equity: x })} />
          </div>
        ) : null}
      </fieldset>

      <fieldset className="flex flex-col gap-3">
        <legend className="mb-2 text-xs font-semibold text-muted-foreground">Adjusted present value (highly leveraged situations)</legend>
        <SwitchField
          label="Use APV"
          checked={d.apv !== null}
          onChange={(on) => set("apv", on ? { unlevered_cost_of_equity: null, debt_balances: null, cost_of_debt: null, expected_distress_cost: 0 } : null)}
          description="Unlevered DCF value plus the PV of interest tax shields, less expected distress costs."
        />
        {d.apv ? (
          <div className="grid gap-3 sm:grid-cols-4">
            <NumField label="Unlevered cost of equity" kind="pct" value={d.apv.unlevered_cost_of_equity} placeholder="Pre-tax WACC" onChange={(x) => set("apv", { ...d.apv!, unlevered_cost_of_equity: x })} />
            <NumListField label="Debt by year" kind="money" values={d.apv.debt_balances} onChange={(b) => set("apv", { ...d.apv!, debt_balances: b.length ? b : null })} description="Empty: the LBO debt schedule" />
            <NumField label="Pre-tax cost of debt" kind="pct" value={d.apv.cost_of_debt} placeholder="WACC build" onChange={(x) => set("apv", { ...d.apv!, cost_of_debt: x })} />
            <NumField label="Expected distress costs" kind="money" value={d.apv.expected_distress_cost} nullable={false} min={0} onChange={(x) => set("apv", { ...d.apv!, expected_distress_cost: x ?? 0 })} />
          </div>
        ) : null}
      </fieldset>
    </SectionForm>
  )
}

export function FiTab({ doc, v }: { doc: MethodsDoc; v: ValuationResponse }) {
  const money = useMoney()
  const get = <R,>(id: string) => v.methods.find((m) => m.id === id) as MethodOutput<R> | undefined
  const ddm = get<ValueResult>("ddm")
  const ri = get<ValueResult>("residual_income")
  const ptbv = get<{ book_equity: number; goodwill: number; intangibles: number; multiples: [number, number, number] }>("ptbv")
  const fcfe = get<ValueResult>("fcfe")
  const apv = get<APVResult>("apv")
  const bank = ["banks", "insurance"].includes(v.deal.sector)
  return (
    <div className="flex flex-col gap-6">
      <p className="text-sm text-muted-foreground">
        {bank
          ? "For banks and insurers these methods replace EV/EBITDA and the FCFF DCF, and carry the weight in the blended value."
          : "These equity methods suit banks and insurers; for other companies they are shown for reference with no weight."}
      </p>
      <div className="grid gap-6 xl:grid-cols-2">
        <Block title="Dividend discount" output={ddm}>
          <RangeLine output={ddm} />
          <ValueSummary output={ddm} extra={ddm?.result?.dividend !== undefined ? [["Dividends in the base year", money.scaled(ddm.result.dividend)]] : undefined} />
        </Block>
        <Block title="Residual income" output={ri}>
          <RangeLine output={ri} />
          <ValueSummary output={ri} extra={ri?.result?.book_value !== undefined ? [["Opening book equity", money.scaled(ri.result.book_value)]] : undefined} />
        </Block>
        <Block title="Price / tangible book" output={ptbv}>
          <RangeLine output={ptbv} />
          {ptbv?.result ? (
            <DataTable
              caption={`Tangible book (${money.unit})`}
              head={["", "Amount"]}
              rows={[
                ["Book equity", money.scaled(ptbv.result.book_equity)],
                ["− Goodwill", money.scaled(-ptbv.result.goodwill)],
                ["− Other intangibles", money.scaled(-ptbv.result.intangibles)],
                ["Multiples (low / mid / high)", ptbv.result.multiples.map((m) => formatMultiple(m, 2)).join(" / ")],
              ]}
            />
          ) : null}
        </Block>
        <Block title="Free cash flow to equity" output={fcfe}>
          <RangeLine output={fcfe} />
          <ValueSummary output={fcfe} />
        </Block>
        <Block title="Adjusted present value" output={apv}>
          <RangeLine output={apv} />
          {apv?.result ? (
            <DataTable
              caption={`APV (${money.unit})`}
              head={["", "Amount"]}
              emphasise={[3, 4]}
              rows={[
                [`Unlevered value (at ${formatPct(apv.result.unlevered_cost_of_equity)})`, money.scaled(apv.result.unlevered_value)],
                [`+ PV of interest tax shields (debt: ${apv.result.debt_source === "lbo" ? "LBO schedule" : "entered"})`, money.scaled(apv.result.pv_tax_shields)],
                ["− Expected distress costs", money.scaled(-apv.result.distress_cost)],
                ["Enterprise value", money.scaled(apv.result.enterprise_value)],
                ["Equity value", money.scaled(apv.result.equity_value)],
              ]}
            />
          ) : null}
        </Block>
      </div>
      <FiInputs doc={doc} v={v} />
    </div>
  )
}
