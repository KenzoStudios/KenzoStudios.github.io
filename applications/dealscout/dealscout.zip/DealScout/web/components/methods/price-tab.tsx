"use client"

import { FxNote } from "@/components/common/fx-note"
import * as React from "react"
import { CheckIcon, CircleAlertIcon, LoaderCircleIcon, MinusIcon, RotateCcwIcon, SparklesIcon, TriangleAlertIcon } from "lucide-react"

import { BridgeWaterfall } from "@/components/charts/price-charts"
import { FootballFieldChart, type FootballRow } from "@/components/charts/valuation-charts"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CockpitSkeleton } from "@/components/deals/cockpit"
import { ApiError } from "@/lib/api"
import { formatAccounting, formatMultiple, formatPct } from "@/lib/format"
import { useAssumptions, useMethods, useRecommendation, useSaveAssumptions, useWriteRationale } from "@/lib/queries"
import type { PriceCheck, RecommendationResponse, SuitabilityRow } from "@/lib/types"

import { NumField, NumInput, SectionForm, StatTiles, useMethodsContext, useMoney, useSectionDraft } from "./kit"

const RELEVANCE: Record<SuitabilityRow["relevance"], { label: string; variant: "default" | "secondary" | "outline" | "negative" }> = {
  primary: { label: "Primary", variant: "default" },
  secondary: { label: "Secondary", variant: "secondary" },
  reference: { label: "Reference", variant: "outline" },
  not_suitable: { label: "Not suitable", variant: "negative" },
}

const CHECK: Record<PriceCheck["status"], { label: string; variant: "positive" | "warning" | "negative" | "outline"; icon: React.ReactNode }> = {
  pass: { label: "Pass", variant: "positive", icon: <CheckIcon aria-hidden /> },
  warn: { label: "Check", variant: "warning", icon: <TriangleAlertIcon aria-hidden /> },
  fail: { label: "Fail", variant: "negative", icon: <CircleAlertIcon aria-hidden /> },
  "n/a": { label: "Not tested", variant: "outline", icon: <MinusIcon aria-hidden /> },
}

const GRADE_VARIANT = { A: "positive", B: "positive", C: "warning", D: "negative" } as const

function Headline({ r }: { r: RecommendationResponse }) {
  const { currency } = useMethodsContext()
  const money = useMoney()
  const rec = r.recommendation!
  const dq = r.data_quality
  return (
    <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_16rem]">
      <div className="rounded-lg border bg-band px-4 py-3">
        <p className="text-xs font-medium text-muted-foreground">Suggested acquisition price range, 100% of equity</p>
        <p className="mt-1 text-2xl font-semibold tracking-tight tabular-nums">
          {money.compact(rec.equity_low)} to {money.compact(rec.equity_high)}
          <span className="ml-2 text-base font-normal text-muted-foreground">mid {money.compact(rec.equity_mid)}</span>
        </p>
        {rec.per_share ? (
          <p className="mt-0.5 text-sm tabular-nums">
            Per diluted share: {currency} {formatAccounting(rec.per_share[0], 2)} to {formatAccounting(rec.per_share[2], 2)} (mid{" "}
            {formatAccounting(rec.per_share[1], 2)})
          </p>
        ) : (
          <p className="mt-0.5 text-xs text-muted-foreground">No per-share values: the share count is unknown.</p>
        )}
        <p className="mt-1 text-xs text-muted-foreground">
          The weighted blend of the methods below. Indicative, for screening; not investment advice.
        </p>
      </div>
      <div className="flex flex-col gap-1 rounded-lg border px-4 py-3" aria-label="Data quality">
        <p className="text-xs font-medium text-muted-foreground">Data quality</p>
        <p className="flex items-baseline gap-2">
          <span className="text-2xl font-semibold tabular-nums">{dq.score}</span>
          <span className="text-sm text-muted-foreground">/ 100</span>
          <Badge variant={GRADE_VARIANT[dq.grade]} className="ml-auto">Grade {dq.grade}</Badge>
        </p>
        <p className="text-xs text-muted-foreground">
          Data confidence {formatPct(dq.components.data_confidence, 0)} · company-specific assumptions{" "}
          {formatPct(dq.components.specific_assumptions, 0)} · complete {formatPct(dq.components.completeness, 0)}
        </p>
        {dq.notes.map((n) => <p key={n} className="text-xs">{n}</p>)}
      </div>
    </div>
  )
}

function Implied({ r }: { r: RecommendationResponse }) {
  const money = useMoney()
  const rec = r.recommendation!
  const items = [
    { label: "Enterprise value at mid", value: money.compact(rec.ev_mid), hint: `${money.compact(rec.ev_low)} to ${money.compact(rec.ev_high)}` },
    ...Object.entries(rec.implied).map(([name, [lo, mid, hi]]) => ({
      label: `Implied ${name}`,
      value: formatMultiple(mid),
      hint: `${formatMultiple(lo)} to ${formatMultiple(hi)}`,
    })),
  ]
  if (rec.premium_to_market) {
    items.push({ label: "Premium to market value", value: formatPct(rec.premium_to_market[1], 0), hint: `${formatPct(rec.premium_to_market[0], 0)} to ${formatPct(rec.premium_to_market[2], 0)}` })
  }
  if (rec.premium_to_vwap) {
    items.push({ label: "Premium to VWAP", value: formatPct(rec.premium_to_vwap[1], 0), hint: `${formatPct(rec.premium_to_vwap[0], 0)} to ${formatPct(rec.premium_to_vwap[2], 0)}` })
  }
  return <StatTiles items={items} />
}

function Checks({ checks }: { checks: PriceCheck[] }) {
  if (!checks.length) {
    return <p className="text-sm text-muted-foreground">No checks apply yet: they need a listed price, a ready LBO or synergies.</p>
  }
  return (
    <ul className="flex flex-col divide-y rounded-lg border" aria-label="Price checks">
      {checks.map((c) => {
        const s = CHECK[c.status]
        return (
          <li key={c.label} className="flex flex-wrap items-start gap-x-3 gap-y-1 px-3 py-2">
            <Badge variant={s.variant} className="mt-0.5 h-5 text-[11px]">{s.icon}{s.label}</Badge>
            <span className="text-sm font-medium">{c.label}</span>
            <span className="basis-full text-sm text-muted-foreground sm:basis-auto sm:flex-1">{c.detail}</span>
          </li>
        )
      })}
    </ul>
  )
}

function Rationale({ dealId, r }: { dealId: string; r: RecommendationResponse }) {
  const write = useWriteRationale(dealId)
  const rat = r.rationale!
  const ai = rat.source !== "template"
  return (
    <section aria-labelledby="rationale-title" className="flex flex-col gap-3 rounded-lg border p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 id="rationale-title" className="text-sm font-semibold">Rationale</h3>
          <p className="text-xs text-muted-foreground">
            {ai ? `Written by ${rat.source}${rat.generated_at ? ` on ${new Date(rat.generated_at).toLocaleString()}` : ""}. ` : "Standard wording. "}
            Every number comes from the engine; the AI only writes the sentences{rat.rejected ? ` (${rat.rejected} sentence${rat.rejected === 1 ? "" : "s"} with numbers of its own were discarded)` : ""}.
          </p>
        </div>
        <Button variant="outline" size="sm" disabled={write.isPending} onClick={() => write.mutate()}>
          {write.isPending ? <LoaderCircleIcon data-icon="inline-start" className="animate-spin" /> : <SparklesIcon data-icon="inline-start" />}
          {write.isPending ? "Writing…" : ai ? "Rewrite with AI" : "Write with AI"}
        </Button>
      </div>
      {rat.stale ? (
        <Alert>
          <TriangleAlertIcon />
          <AlertTitle>Inputs changed since the AI wrote the rationale</AlertTitle>
          <AlertDescription>Showing the standard wording for the current figures. Rewrite to update the AI version.</AlertDescription>
        </Alert>
      ) : null}
      {write.error ? (
        <Alert variant="destructive">
          <CircleAlertIcon />
          <AlertTitle>The rationale was not written</AlertTitle>
          <AlertDescription>{(write.error as ApiError).message}</AlertDescription>
        </Alert>
      ) : null}
      <ul className="flex list-disc flex-col gap-1 pl-5 text-sm">{rat.bullets.map((b) => <li key={b}>{b}</li>)}</ul>
      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <h4 className="mb-1 text-xs font-semibold">Key risks</h4>
          <ul className="flex list-disc flex-col gap-1 pl-5 text-sm">{rat.risks.map((b) => <li key={b}>{b}</li>)}</ul>
        </div>
        <div>
          <h4 className="mb-1 text-xs font-semibold">What would need to be true for the high end</h4>
          <ul className="flex list-disc flex-col gap-1 pl-5 text-sm">
            {rat.high_end.length ? rat.high_end.map((b) => <li key={b}>{b}</li>) : <li>No single method sets the high end.</li>}
          </ul>
        </div>
      </div>
    </section>
  )
}

function Weights({ dealId, rows }: { dealId: string; rows: SuitabilityRow[] }) {
  const { data: doc } = useAssumptions(dealId)
  const save = useSaveAssumptions(dealId)
  const stored = React.useMemo(() => (doc?.overrides?.method_weights ?? {}) as Record<string, number>, [doc])
  const [draft, setDraft] = React.useState<Record<string, number> | null>(null)
  const user = draft ?? stored
  const dirty = draft !== null
  const persist = async () => {
    try {
      await save.mutateAsync({ overrides: { ...(doc?.overrides ?? {}), method_weights: user } })
      setDraft(null)
    } catch {
      // shown below
    }
  }
  return (
    <section aria-labelledby="weights-title" className="flex min-w-0 flex-col gap-3 rounded-lg border p-4">
      <div>
        <h3 id="weights-title" className="text-sm font-semibold">Method suitability and weights</h3>
        <p className="text-xs text-muted-foreground">
          Pre-filled from the sector, the buyer type and whether the company makes a profit. Weights are relative; methods without results
          are left out of the blend.
        </p>
      </div>
      <div className="relative overflow-x-auto rounded-lg border">
        <table className="w-full text-[13px] tabular-nums">
          <thead className="bg-muted text-xs text-muted-foreground">
            <tr>
              <th className="px-3 py-1.5 text-left font-medium">Method</th>
              <th className="px-3 py-1.5 text-left font-medium">Suitability</th>
              <th className="px-3 py-1.5 text-left font-medium">Why</th>
              <th className="px-3 py-1.5 text-right font-medium">Weight</th>
              <th className="px-3 py-1.5 text-right font-medium">Share of blend</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => {
              const rel = RELEVANCE[row.relevance]
              const value = user[row.method_id] ?? row.suggested_weight
              const overridden = row.method_id in user
              return (
                <tr key={row.method_id} className={row.available ? "border-t align-top" : "border-t align-top text-muted-foreground"}>
                  <th scope="row" className="px-3 py-1.5 text-left font-normal">
                    {row.label}
                    {!row.available ? <span className="block text-xs">No result yet</span> : null}
                  </th>
                  <td className="px-3 py-1.5"><Badge variant={rel.variant} className="h-5 text-[11px]">{rel.label}</Badge></td>
                  <td className="max-w-96 min-w-56 px-3 py-1.5 text-xs">{row.reason}</td>
                  <td className="px-3 py-1">
                    <div className="flex items-center justify-end gap-1">
                      <NumInput
                        kind="number"
                        label={`${row.label} weight`}
                        value={value}
                        nullable={false}
                        min={0}
                        max={10}
                        className="w-20"
                        onChange={(v) => setDraft({ ...user, [row.method_id]: v ?? 0 })}
                      />
                      <Button
                        variant="ghost"
                        size="icon-xs"
                        aria-label={`Reset ${row.label} to the suggested weight`}
                        disabled={!overridden}
                        onClick={() => {
                          const next = { ...user }
                          delete next[row.method_id]
                          setDraft(next)
                        }}
                      >
                        <RotateCcwIcon />
                      </Button>
                    </div>
                  </td>
                  <td className="px-3 py-1.5 text-right">{row.normalised_weight ? formatPct(row.normalised_weight, 0) : "–"}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Button size="sm" disabled={!dirty || save.isPending} onClick={() => void persist()}>
          {save.isPending ? <LoaderCircleIcon data-icon="inline-start" className="animate-spin" /> : null}
          {save.isPending ? "Saving…" : "Save weights and rerun"}
        </Button>
        <Button variant="ghost" size="sm" disabled={!dirty || save.isPending} onClick={() => setDraft(null)}>Discard changes</Button>
        <span aria-live="polite" className="text-xs text-muted-foreground">{dirty ? "Unsaved changes" : null}</span>
        {save.error ? <span role="alert" className="text-xs text-negative">{(save.error as ApiError).message}</span> : null}
      </div>
    </section>
  )
}

function PremiumInputs({ dealId }: { dealId: string }) {
  const { data: doc } = useMethods(dealId)
  const state = useSectionDraft("premium", doc?.premium)
  const d = state.draft
  return (
    <SectionForm
      title="Typical control premium"
      description="Premia paid in comparable public takeovers in this market. DealScout has no sourced default; enter your own range and its source."
      state={state}
    >
      <div className="grid gap-3 sm:grid-cols-3">
        <NumField label="Low" kind="pct" value={d?.low ?? null} min={-0.5} max={3} onChange={(x) => state.replace(x === null ? null : { low: x, high: d?.high ?? x, source: d?.source ?? "Entered by the analyst" })} />
        <NumField label="High" kind="pct" value={d?.high ?? null} min={-0.5} max={3} onChange={(x) => state.replace(x === null ? null : { low: d?.low ?? x, high: x, source: d?.source ?? "Entered by the analyst" })} />
        <div className="flex flex-col gap-1">
          <label htmlFor="premium-source" className="text-xs font-medium">Source</label>
          <input
            id="premium-source"
            className="h-7 rounded-lg border border-input bg-transparent px-2.5 text-sm"
            autoComplete="off"
            value={d?.source ?? ""}
            disabled={!d}
            onChange={(e) => d && state.replace({ ...d, source: e.target.value })}
          />
        </div>
      </div>
    </SectionForm>
  )
}

export function PriceTab({ dealId, listed }: { dealId: string; listed: boolean }) {
  const { data: r, isPending, isError, error } = useRecommendation(dealId)
  const { currency } = useMethodsContext()
  if (isPending) return <CockpitSkeleton />
  if (isError || !r) {
    return (
      <Alert variant="destructive">
        <CircleAlertIcon />
        <AlertTitle>The recommendation could not be built</AlertTitle>
        <AlertDescription>{error?.message}</AlertDescription>
      </Alert>
    )
  }
  const ff = r.football_field
  const rows: FootballRow[] = ff
    ? [
        ...ff.methods.filter((m) => m.included && (ff.weights_normalised[m.method_id] ?? 0) > 0).map((m) => ({ label: m.label, low: m.equity_low, mid: m.equity_mid, high: m.equity_high })),
        ...ff.methods.filter((m) => m.included && !(ff.weights_normalised[m.method_id] ?? 0)).map((m) => ({ label: `${m.label} (reference)`, low: m.equity_low, mid: m.equity_mid, high: m.equity_high })),
      ]
    : []
  const rec = r.recommendation
  return (
    <div className="flex flex-col gap-6">
      <FxNote fx={r.fx} />
      {rec ? (
        <>
          <Headline r={r} />
          <Implied r={r} />
          {rows.length ? (
            <FootballFieldChart
              title="Football field with the suggested offer"
              rows={rows}
              currency={currency}
              unitLabel={`Equity value (${currency})`}
              offer={{ low: rec.equity_low, high: rec.equity_high }}
              reference={ff?.market_cap ? { label: "Market cap", value: ff.market_cap } : null}
              markers={r.market_points.map((p) => ({ label: p.label, value: p.equity }))}
            />
          ) : null}
          {r.market_points.length ? (
            <p className="-mt-4 text-xs text-muted-foreground">
              Shaded band: suggested offer. Dashed line: market cap. Dotted lines: {r.market_points.map((p) => p.label.toLowerCase()).join(", ")}{" "}
              (hover for names; exact values in the table view).
            </p>
          ) : null}
          <section aria-labelledby="checks-title" className="flex flex-col gap-2">
            <h3 id="checks-title" className="text-sm font-semibold">Checks at the suggested price</h3>
            <Checks checks={rec.checks} />
          </section>
          {r.rationale ? <Rationale dealId={dealId} r={r} /> : null}
          <BridgeWaterfall ev={rec.ev_mid} equity={rec.equity_mid} items={rec.bridge_at_mid} currency={currency} />
        </>
      ) : (
        <Alert>
          <TriangleAlertIcon />
          <AlertTitle>No suggested price yet</AlertTitle>
          <AlertDescription>Complete at least one weighted method (for example the DCF on the Summary tab) to see a price range.</AlertDescription>
        </Alert>
      )}
      <Weights dealId={dealId} rows={r.suitability} />
      {listed ? <PremiumInputs dealId={dealId} /> : null}
    </div>
  )
}
