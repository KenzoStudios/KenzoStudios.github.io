"use client"

import * as React from "react"
import type * as echarts from "echarts"

import { baseOption, type ChartTokens, EChart, esc } from "@/components/charts/echart"
import { Field, FieldDescription, FieldLabel } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { formatMultiple, formatPct } from "@/lib/format"
import type { MethodOutput, MethodsDoc, PrecedentSettings, Transaction, ValuationResponse } from "@/lib/types"

import {
  type Column,
  DataTable,
  ListEditor,
  MethodStatus,
  NumField,
  RangeLine,
  SectionForm,
  SelectField,
  StatTiles,
  useMoney,
  useSectionDraft,
} from "./kit"

interface PrecedentResult {
  label: string
  target_metric: number | null
  stats: {
    n: number
    values: Record<string, number>
    weights: Record<string, number>
    excluded: Record<string, string>
    p25: number | null
    median: number | null
    p75: number | null
    mean: number | null
    median_premium: number | null
  }
  ev_low: number | null
  ev_mid: number | null
  ev_high: number | null
  note: string
}

const COLUMNS: Column<Transaction>[] = [
  { key: "announced", header: "Announced", kind: "date", width: "8.5rem" },
  { key: "target", header: "Target", kind: "text", width: "10rem" },
  { key: "acquirer", header: "Acquirer", kind: "text", width: "9rem" },
  { key: "country", header: "Country", kind: "text", width: "4.5rem", nullable: true, hint: "Two-letter code" },
  { key: "ev", header: "EV", kind: "money", width: "6.5rem" },
  { key: "revenue", header: "Revenue", kind: "money", width: "6.5rem" },
  { key: "ebitda", header: "EBITDA", kind: "money", width: "6.5rem" },
  { key: "ebit", header: "EBIT", kind: "money", width: "6.5rem" },
  { key: "ev_ebitda", header: "EV/EBITDA as reported", kind: "multiple", width: "6rem", hint: "When the metrics are not disclosed" },
  { key: "premium_paid", header: "Premium", kind: "pct", width: "5.5rem" },
  { key: "stake_acquired", header: "Stake", kind: "pct", width: "5.5rem" },
  {
    key: "consideration",
    header: "Paid in",
    kind: "select",
    options: [
      { value: "unknown", label: "Unknown" },
      { value: "cash", label: "Cash" },
      { value: "stock", label: "Stock" },
      { value: "mixed", label: "Mixed" },
    ],
    width: "6.5rem",
  },
  { key: "include", header: "Use", kind: "check", width: "3rem" },
  { key: "source", header: "Source", kind: "text", width: "10rem" },
]

const NEW_TRANSACTION = (): Transaction => ({
  announced: new Date().toISOString().slice(0, 10),
  target: "",
  acquirer: "",
  country: null,
  sector: null,
  ev: null,
  revenue: null,
  ebitda: null,
  ebit: null,
  ev_revenue: null,
  ev_ebitda: null,
  ev_ebit: null,
  premium_paid: null,
  stake_acquired: null,
  consideration: "unknown",
  include: true,
  source: "",
})

/** One dot per transaction on a multiple axis, the interquartile range shaded and the median marked. */
function MultiplesStrip({ result }: { result: PrecedentResult }) {
  const entries = Object.entries(result.stats.values)
  const build = React.useCallback(
    (t: ChartTokens): echarts.EChartsOption => ({
      ...baseOption(t),
      grid: { left: 8, right: 16, top: 24, bottom: 28, containLabel: true },
      xAxis: {
        type: "value",
        scale: true,
        axisLabel: { color: t.axis, formatter: (v: number) => `${v.toFixed(1)}x` },
        splitLine: { lineStyle: { color: t.grid } },
        name: result.label,
        nameLocation: "middle",
        nameGap: 22,
        nameTextStyle: { color: t.axis, fontSize: 11 },
      },
      yAxis: { type: "category", data: [""], show: false },
      tooltip: {
        ...baseOption(t).tooltip,
        formatter: (p: unknown) => {
          const d = p as { data: { name: string; value: [number, number] } }
          return `<strong>${esc(d.data.name)}</strong><br/>${formatMultiple(d.data.value[0])} · weight ${formatPct(result.stats.weights[d.data.name] ?? 0, 0)}`
        },
      },
      series: [
        {
          type: "scatter",
          data: entries.map(([name, value]) => ({ name, value: [value, 0] })),
          symbolSize: 10,
          itemStyle: { color: t.categorical[0], borderColor: t.surface, borderWidth: 2, opacity: 0.9 },
          markArea:
            result.stats.p25 !== null && result.stats.p75 !== null
              ? {
                  silent: true,
                  itemStyle: { color: t.grid, opacity: 0.6 },
                  label: { show: true, position: "top", color: t.muted, fontSize: 11, formatter: "25th to 75th percentile" },
                  data: [[{ xAxis: result.stats.p25 }, { xAxis: result.stats.p75 }]],
                }
              : undefined,
          markLine:
            result.stats.median !== null
              ? {
                  symbol: "none",
                  silent: true,
                  lineStyle: { color: t.text, width: 1.5 },
                  label: { formatter: `Median ${formatMultiple(result.stats.median)}`, color: t.text, fontSize: 11 },
                  data: [{ xAxis: result.stats.median }],
                }
              : undefined,
        },
      ],
    }),
    [entries, result],
  )
  if (!entries.length) return null
  return (
    <EChart
      title="Transaction multiples"
      height={150}
      build={build}
      table={
        <DataTable
          caption="Multiples used"
          head={["Transaction", "Multiple", "Weight"]}
          rows={entries.map(([name, value]) => [name, formatMultiple(value), formatPct(result.stats.weights[name] ?? 0, 0)])}
        />
      }
    />
  )
}

function Inputs({ doc }: { doc: MethodsDoc }) {
  const state = useSectionDraft("precedents", doc.precedents)
  const d = state.draft
  const countriesId = React.useId()
  if (!d) return null
  const setFilter = <K extends keyof PrecedentSettings["filters"]>(key: K, value: PrecedentSettings["filters"][K]) =>
    state.update((x) => ({ ...x, filters: { ...x.filters, [key]: value } }))
  return (
    <SectionForm
      title="Transactions"
      description="Enter comparable acquisitions from your own sources. Multiples paid in control transactions include a control premium."
      state={state}
    >
      <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <SelectField
          label="Multiple"
          value={d.multiple}
          options={[
            { value: "ev_ebitda", label: "EV / EBITDA" },
            { value: "ev_revenue", label: "EV / Revenue" },
            { value: "ev_ebit", label: "EV / EBIT" },
          ]}
          onChange={(m) => state.update((x) => ({ ...x, multiple: m }))}
        />
        <Field className="gap-1">
          <FieldLabel className="text-xs font-medium" htmlFor={`${countriesId}-since`}>Announced since</FieldLabel>
          <Input
            id={`${countriesId}-since`}
            type="date"
            autoComplete="off"
            className="h-7"
            value={d.filters.since ?? ""}
            onChange={(e) => setFilter("since", e.target.value || null)}
          />
        </Field>
        <Field className="gap-1">
          <FieldLabel className="text-xs font-medium" htmlFor={countriesId}>Countries</FieldLabel>
          <Input
            id={countriesId}
            className="h-7 uppercase"
            autoComplete="off"
            spellCheck={false}
            value={d.filters.countries.join(", ")}
            onChange={(e) =>
              setFilter(
                "countries",
                e.target.value.split(/[,\s]+/).map((c) => c.trim().toLowerCase()).filter(Boolean),
              )
            }
          />
          <FieldDescription className="text-xs">Codes, e.g. DE, FR. Empty: all</FieldDescription>
        </Field>
        <NumField label="Min EV" kind="money" value={d.filters.min_ev} onChange={(x) => setFilter("min_ev", x)} />
        <NumField label="Max EV" kind="money" value={d.filters.max_ev} onChange={(x) => setFilter("max_ev", x)} />
        <NumField
          label="Recency half-life (years)"
          kind="number"
          value={d.filters.half_life_years}
          min={0.1}
          onChange={(x) => setFilter("half_life_years", x)}
          description="Empty: equal weights"
        />
      </div>
      <ListEditor
        caption="Precedent transactions"
        rows={d.transactions}
        onChange={(rows) => state.update((x) => ({ ...x, transactions: rows }))}
        columns={COLUMNS}
        newRow={NEW_TRANSACTION}
        addLabel="Add transaction"
        rowLabel={(r, i) => r.target || `Transaction ${i + 1}`}
        empty="No transactions yet. Add each deal with its date, EV and the target's metrics (or the multiple as reported)."
      />
    </SectionForm>
  )
}

export function PrecedentsTab({ doc, v }: { doc: MethodsDoc; v: ValuationResponse }) {
  const output = v.methods.find((m) => m.id === "precedents") as MethodOutput<PrecedentResult> | undefined
  const money = useMoney()
  const r = output?.result
  return (
    <div className="flex flex-col gap-6">
      <MethodStatus output={output} what="Precedent transactions" />
      {r ? (
        <div className="flex flex-col gap-4">
          <RangeLine output={output} />
          <StatTiles
            items={[
              { label: "Transactions used", value: r.stats.n, hint: Object.keys(r.stats.excluded).length ? `${Object.keys(r.stats.excluded).length} excluded` : undefined },
              { label: `Median ${r.label}`, value: formatMultiple(r.stats.median), hint: `Mean ${formatMultiple(r.stats.mean)}` },
              { label: "25th to 75th percentile", value: `${formatMultiple(r.stats.p25)} to ${formatMultiple(r.stats.p75)}` },
              { label: "Median premium paid", value: r.stats.median_premium === null ? "n/m" : formatPct(r.stats.median_premium), hint: "Listed targets only" },
            ]}
          />
          <MultiplesStrip result={r} />
          {Object.keys(r.stats.excluded).length ? (
            <DataTable
              caption="Excluded transactions"
              head={["Transaction", "Reason"]}
              rows={Object.entries(r.stats.excluded).map(([name, reason]) => [name, reason])}
            />
          ) : null}
          <DataTable
            caption={`Implied enterprise value (${money.unit})`}
            head={["", "Low (25th)", "Mid (median)", "High (75th)"]}
            rows={[
              ["Target metric × multiple", money.scaled(r.ev_low), money.scaled(r.ev_mid), money.scaled(r.ev_high)],
            ]}
          />
        </div>
      ) : null}
      <Inputs doc={doc} />
    </div>
  )
}
