"use client"

import * as React from "react"
import { CheckIcon, CircleAlertIcon, LoaderCircleIcon, PlusIcon, Trash2Icon, TriangleAlertIcon } from "lucide-react"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Field, FieldDescription, FieldLabel } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select"
import { Switch } from "@/components/ui/switch"
import { ApiError } from "@/lib/api"
import { formatAccounting, formatMoneyCompact, parseCellInput, SCALE_LABEL } from "@/lib/format"
import { useSaveMethodSection } from "@/lib/queries"
import type { MethodOutput, MethodSection, MethodsDoc } from "@/lib/types"
import { cn } from "@/lib/utils"

// ── context: deal, currency and the money entry scale ─────────────────────────
interface MethodsContextValue {
  dealId: string
  currency: string
  scale: number // money is typed in the deal's entry scale (e.g. millions)
}

const MethodsContext = React.createContext<MethodsContextValue>({ dealId: "", currency: "", scale: 1e6 })

export function MethodsProvider({ value, children }: { value: MethodsContextValue; children: React.ReactNode }) {
  return <MethodsContext.Provider value={value}>{children}</MethodsContext.Provider>
}

export const useMethodsContext = () => React.useContext(MethodsContext)

export function moneyUnit(currency: string, scale: number): string {
  return `${currency} ${SCALE_LABEL[scale] ?? ""}`.trim()
}

// ── numbers ───────────────────────────────────────────────────────────────────
export type NumKind = "pct" | "multiple" | "money" | "number" | "int" | "price"

const SUFFIX: Record<NumKind, string> = { pct: "%", multiple: "x", money: "", number: "", int: "", price: "" }

export function toText(value: number | null | undefined, kind: NumKind, scale: number): string {
  if (value === null || value === undefined) return ""
  const shown = kind === "pct" ? value * 100 : kind === "money" ? value / scale : value
  return String(+shown.toFixed(kind === "int" ? 0 : 4))
}

/** The stored value for what was typed: null when empty, undefined when it is not a number. */
export function fromText(text: string, kind: NumKind, scale: number): number | null | undefined {
  const parsed = parseCellInput(text)
  if (parsed === null || parsed === undefined) return parsed
  if (kind === "pct") return parsed / 100
  if (kind === "money") return parsed * scale
  if (kind === "int") return Number.isInteger(parsed) ? parsed : undefined
  return parsed
}

export function NumInput({
  value,
  onChange,
  kind,
  label,
  id,
  nullable = true,
  min,
  max,
  placeholder,
  className,
}: {
  value: number | null | undefined
  onChange: (value: number | null) => void
  kind: NumKind
  label: string
  id?: string
  nullable?: boolean
  min?: number
  max?: number
  placeholder?: string
  className?: string
}) {
  const { scale } = useMethodsContext()
  const [text, setText] = React.useState(() => toText(value, kind, scale))
  const [error, setError] = React.useState<string | null>(null)
  const focused = React.useRef(false)
  const textOnFocus = React.useRef("")
  React.useEffect(() => {
    if (!focused.current) {
      setText(toText(value, kind, scale))
      setError(null)
    }
  }, [value, kind, scale])
  const commit = () => {
    // focusing and leaving a field must not rewrite the stored value through display rounding
    if (text === textOnFocus.current && !error) return
    const parsed = fromText(text, kind, scale)
    if (parsed === undefined) return setError("Enter a number")
    if (parsed === null && !nullable) return setError("Required")
    if (parsed !== null && min !== undefined && parsed < min) return setError(`At least ${toText(min, kind, scale)}${SUFFIX[kind]}`)
    if (parsed !== null && max !== undefined && parsed > max) return setError(`At most ${toText(max, kind, scale)}${SUFFIX[kind]}`)
    setError(null)
    if (parsed !== value) onChange(parsed)
  }
  return (
    <span className={cn("relative inline-flex w-full items-center gap-1", className)}>
      <Input
        id={id}
        value={text}
        inputMode="decimal"
        autoComplete="off"
        spellCheck={false}
        placeholder={placeholder}
        aria-label={id ? undefined : label}
        aria-invalid={error ? true : undefined}
        title={error ?? undefined}
        className="h-7 min-w-14 text-right tabular-nums"
        onFocus={(e) => {
          focused.current = true
          textOnFocus.current = e.currentTarget.value
          const input = e.currentTarget
          requestAnimationFrame(() => input.select()) // after the click's mouseup; typing replaces the value
        }}
        onChange={(e) => {
          setText(e.target.value)
          setError(null)
        }}
        onBlur={() => {
          focused.current = false
          commit()
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault()
            commit()
          }
        }}
      />
      {SUFFIX[kind] ? <span className="w-3 shrink-0 text-xs text-muted-foreground" aria-hidden>{SUFFIX[kind]}</span> : null}
      {error ? (
        <span role="alert" className="absolute top-full right-0 z-10 rounded-sm bg-negative-bg px-1 text-[11px] whitespace-nowrap text-negative">
          <span className="sr-only">{label}: </span>
          {error}
        </span>
      ) : null}
    </span>
  )
}

export function NumField({
  label,
  description,
  className,
  ...props
}: React.ComponentProps<typeof NumInput> & { description?: React.ReactNode }) {
  const id = React.useId()
  return (
    <Field className={cn("gap-1", className)}>
      <FieldLabel htmlFor={id} className="text-xs font-medium">{label}</FieldLabel>
      <NumInput id={id} label={label} {...props} />
      {description ? <FieldDescription className="text-xs">{description}</FieldDescription> : null}
    </Field>
  )
}

export function SwitchField({
  label,
  checked,
  onChange,
  description,
}: {
  label: string
  checked: boolean
  onChange: (value: boolean) => void
  description?: React.ReactNode
}) {
  const id = React.useId()
  return (
    <Field orientation="horizontal" className="items-start gap-2">
      <Switch id={id} checked={checked} onCheckedChange={(v) => onChange(!!v)} className="mt-0.5" />
      <div className="flex flex-col gap-0.5">
        <FieldLabel htmlFor={id} className="text-sm font-normal">{label}</FieldLabel>
        {description ? <FieldDescription className="text-xs">{description}</FieldDescription> : null}
      </div>
    </Field>
  )
}

export function SelectField<V extends string>({
  label,
  value,
  options,
  onChange,
  description,
}: {
  label: string
  value: V
  options: { value: V; label: string }[]
  onChange: (value: V) => void
  description?: React.ReactNode
}) {
  const id = React.useId()
  return (
    <Field className="gap-1">
      <FieldLabel htmlFor={id} className="text-xs font-medium">{label}</FieldLabel>
      <NativeSelect id={id} size="sm" value={value} onChange={(e) => onChange(e.target.value as V)} className="w-full">
        {options.map((o) => <NativeSelectOption key={o.value} value={o.value}>{o.label}</NativeSelectOption>)}
      </NativeSelect>
      {description ? <FieldDescription className="text-xs">{description}</FieldDescription> : null}
    </Field>
  )
}

/** A comma-separated list of numbers (e.g. ROE by year), each in the given kind. */
export function NumListField({
  label,
  values,
  onChange,
  kind,
  description,
}: {
  label: string
  values: number[] | null
  onChange: (values: number[]) => void
  kind: NumKind
  description?: React.ReactNode
}) {
  const { scale } = useMethodsContext()
  const id = React.useId()
  const show = (vs: number[] | null) => (vs ?? []).map((v) => toText(v, kind, scale)).join("; ")
  const [editing, setText] = React.useState<string | null>(null)
  const text = editing ?? show(values)
  const [error, setError] = React.useState<string | null>(null)
  const commit = () => {
    const parts = text.split(/[;\n]/).map((p) => p.trim()).filter(Boolean)
    const parsed = parts.map((p) => fromText(p, kind, scale))
    if (parsed.some((v) => v === undefined || v === null)) return setError("Separate numbers with semicolons")
    setError(null)
    setText(null)
    onChange(parsed as number[])
  }
  return (
    <Field className="gap-1">
      <FieldLabel htmlFor={id} className="text-xs font-medium">{label}</FieldLabel>
      <Input
        id={id}
        value={text}
        autoComplete="off"
        spellCheck={false}
        aria-invalid={error ? true : undefined}
        className="h-7 tabular-nums"
        onChange={(e) => {
          setText(e.target.value)
          setError(null)
        }}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault() // commit this field first; Enter must not save the form with the old list
            commit()
          }
        }}
      />
      {error ? <p role="alert" className="text-xs text-negative">{error}</p> : null}
      {description ? <FieldDescription className="text-xs">{description}</FieldDescription> : null}
    </Field>
  )
}

// ── list editor (tranches, transactions, assets, segments, adjustments) ────────
export interface Column<T> {
  key: keyof T & string
  header: string
  kind: NumKind | "text" | "date" | "select" | "check"
  options?: { value: string; label: string }[]
  nullable?: boolean
  width?: string
  hint?: string
}

export function ListEditor<T extends object>({
  caption,
  rows,
  onChange,
  columns,
  newRow,
  addLabel,
  rowLabel,
  max = 300,
  empty,
}: {
  caption: string
  rows: T[]
  onChange: (rows: T[]) => void
  columns: Column<T>[]
  newRow: () => T
  addLabel: string
  rowLabel: (row: T, index: number) => string
  max?: number
  empty?: React.ReactNode
}) {
  const set = (i: number, key: keyof T, value: unknown) =>
    onChange(rows.map((r, j) => (j === i ? ({ ...r, [key]: value } as T) : r)))
  return (
    <div className="flex flex-col gap-2">
      <div className="relative overflow-x-auto rounded-lg border">
        <table className="w-full text-[13px] tabular-nums">
          <caption className="sr-only">{caption}</caption>
          <thead className="bg-muted text-xs text-muted-foreground">
            <tr>
              {columns.map((c) => (
                <th key={c.key} scope="col" className={cn("px-2 py-1.5 font-medium", c.kind === "text" || c.kind === "date" || c.kind === "select" ? "text-left" : "text-right")} style={{ minWidth: c.width }} title={c.hint}>
                  {c.header}
                </th>
              ))}
              <th className="w-9 px-1"><span className="sr-only">Remove</span></th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={columns.length + 1} className="px-3 py-4 text-center text-sm text-muted-foreground">{empty ?? "Nothing entered yet."}</td>
              </tr>
            ) : null}
            {rows.map((row, i) => {
              const name = rowLabel(row, i)
              return (
                <tr key={i} className="border-t">
                  {columns.map((c) => {
                    const value = (row as Record<string, unknown>)[c.key]
                    const label = `${name}: ${c.header}`
                    return (
                      <td key={c.key} className="px-1.5 py-1">
                        {c.kind === "text" || c.kind === "date" ? (
                          <Input
                            type={c.kind === "date" ? "date" : "text"}
                            value={(value as string | null) ?? ""}
                            aria-label={label}
                            autoComplete="off"
                            className="h-7"
                            onChange={(e) => set(i, c.key, c.nullable && !e.target.value ? null : e.target.value)}
                          />
                        ) : c.kind === "select" ? (
                          <NativeSelect size="sm" value={value as string} aria-label={label} onChange={(e) => set(i, c.key, e.target.value)} className="w-full">
                            {(c.options ?? []).map((o) => <NativeSelectOption key={o.value} value={o.value}>{o.label}</NativeSelectOption>)}
                          </NativeSelect>
                        ) : c.kind === "check" ? (
                          <div className="flex justify-end pr-2">
                            <Checkbox checked={!!value} aria-label={label} onCheckedChange={(v) => set(i, c.key, !!v)} />
                          </div>
                        ) : (
                          <NumInput
                            kind={c.kind}
                            label={label}
                            value={value as number | null}
                            nullable={c.nullable ?? true}
                            onChange={(v) => set(i, c.key, v === null && !(c.nullable ?? true) ? 0 : v)}
                          />
                        )}
                      </td>
                    )
                  })}
                  <td className="px-1 py-1 text-right">
                    <Button variant="ghost" size="icon-xs" aria-label={`Remove ${name}`} onClick={() => onChange(rows.filter((_, j) => j !== i))}>
                      <Trash2Icon />
                    </Button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      <div>
        <Button variant="outline" size="sm" disabled={rows.length >= max} onClick={() => onChange([...rows, newRow()])}>
          <PlusIcon data-icon="inline-start" />
          {addLabel}
        </Button>
      </div>
    </div>
  )
}

// ── section drafts: edit locally, save and rerun explicitly ─────────────────────
export function useSectionDraft<S extends MethodSection>(section: S, current: MethodsDoc[S] | undefined) {
  const { dealId } = useMethodsContext()
  const save = useSaveMethodSection(dealId)
  // while there are no unsaved edits the draft is the stored value, so a refetch shows through
  const [edited, setEdited] = React.useState<{ value: MethodsDoc[S] | undefined } | null>(null)
  const [saved, setSaved] = React.useState(false)
  const dirty = edited !== null
  const draft = edited ? edited.value : current
  React.useEffect(() => {
    if (!dirty) return
    const warn = (e: BeforeUnloadEvent) => e.preventDefault()
    window.addEventListener("beforeunload", warn)
    return () => window.removeEventListener("beforeunload", warn)
  }, [dirty])
  const update = React.useCallback(
    (fn: (d: MethodsDoc[S]) => MethodsDoc[S]) => {
      setEdited((e) => {
        const base = e ? e.value : current
        return { value: base === undefined || base === null ? base : fn(base) }
      })
      setSaved(false)
    },
    [current],
  )
  const replace = React.useCallback((value: MethodsDoc[S]) => {
    setEdited({ value })
    setSaved(false)
  }, [])
  const submit = async (value: MethodsDoc[S] | undefined = draft) => {
    try {
      await save.mutateAsync({ section, value })
      setEdited(null)
      setSaved(true)
    } catch {
      // the error is shown next to the button; the input is kept
    }
  }
  const discard = () => {
    setEdited(null)
    save.reset()
  }
  return { draft, update, replace, dirty, saved, submit, discard, pending: save.isPending, error: save.error as ApiError | null }
}

export function SectionForm({
  title,
  description,
  state,
  children,
  saveLabel = "Save and run",
  extraActions,
}: {
  title: string
  description?: React.ReactNode
  state: Pick<ReturnType<typeof useSectionDraft>, "dirty" | "saved" | "pending" | "error" | "discard"> & { submit: () => Promise<void> }
  children: React.ReactNode
  saveLabel?: string
  extraActions?: React.ReactNode
}) {
  const titleId = React.useId()
  return (
    <section aria-labelledby={titleId} className="flex min-w-0 flex-col gap-3 rounded-lg border p-4">
      <div className="flex flex-col gap-0.5">
        <h3 id={titleId} className="text-sm font-semibold">{title}</h3>
        {description ? <p className="text-xs text-muted-foreground">{description}</p> : null}
      </div>
      <form
        className="flex min-w-0 flex-col gap-4"
        onSubmit={(e) => {
          e.preventDefault()
          void state.submit()
        }}
      >
        {children}
        {state.error ? (
          <Alert variant="destructive">
            <CircleAlertIcon />
            <AlertTitle>Not saved</AlertTitle>
            <AlertDescription>{state.error.message}</AlertDescription>
          </Alert>
        ) : null}
        <div className="flex flex-wrap items-center gap-2">
          <Button type="submit" size="sm" disabled={state.pending || !state.dirty}>
            {state.pending ? <LoaderCircleIcon data-icon="inline-start" className="animate-spin" /> : null}
            {state.pending ? "Saving…" : saveLabel}
          </Button>
          <Button type="button" variant="ghost" size="sm" disabled={!state.dirty || state.pending} onClick={state.discard}>
            Discard changes
          </Button>
          {extraActions}
          <span aria-live="polite" className="text-xs text-muted-foreground">
            {state.dirty ? "Unsaved changes" : state.saved ? (
              <span className="inline-flex items-center gap-1"><CheckIcon className="size-3.5 text-positive" aria-hidden />Saved, results updated</span>
            ) : null}
          </span>
        </div>
      </form>
    </section>
  )
}

// ── results ─────────────────────────────────────────────────────────────────────
export function MethodStatus({ output, what }: { output: MethodOutput | undefined; what?: string }) {
  if (!output) return null
  if (output.status === "error") {
    return (
      <Alert variant="destructive">
        <CircleAlertIcon />
        <AlertTitle>{output.label} could not run</AlertTitle>
        <AlertDescription>{output.message}</AlertDescription>
      </Alert>
    )
  }
  if (output.status === "needs_input") {
    return (
      <Alert>
        <TriangleAlertIcon />
        <AlertTitle>{what ?? output.label} needs more input</AlertTitle>
        <AlertDescription>
          <ul className="list-disc pl-4">
            {output.missing.map((m) => <li key={m}>{m.charAt(0).toUpperCase() + m.slice(1)}</li>)}
          </ul>
        </AlertDescription>
      </Alert>
    )
  }
  return null
}

export function StatusBadge({ output }: { output: MethodOutput | undefined }) {
  if (!output) return null
  if (output.status === "ready") {
    return (
      <Badge variant="positive" className="h-5 text-[11px]">
        <CheckIcon aria-hidden />
        Ready
      </Badge>
    )
  }
  if (output.status === "error") {
    return (
      <Badge variant="negative" className="h-5 text-[11px]">
        <CircleAlertIcon aria-hidden />
        Error
      </Badge>
    )
  }
  return <Badge variant="outline" className="h-5 text-[11px] text-muted-foreground">Needs input</Badge>
}

export function RangeLine({ output }: { output: MethodOutput | undefined }) {
  const { currency } = useMethodsContext()
  const r = output?.range
  if (!r) return null
  return (
    <div className="rounded-lg border bg-band px-4 py-3">
      <p className="text-xs font-medium text-muted-foreground">{r.label}: equity value range</p>
      <p className="mt-1 text-xl font-semibold tracking-tight tabular-nums">
        {r.equity_low === r.equity_high
          ? formatMoneyCompact(r.equity_mid, currency)
          : `${formatMoneyCompact(r.equity_low, currency)} to ${formatMoneyCompact(r.equity_high, currency)}`}
        {r.equity_low !== r.equity_high ? (
          <span className="ml-2 text-sm font-normal text-muted-foreground">mid {formatMoneyCompact(r.equity_mid, currency)}</span>
        ) : null}
      </p>
      <p className="mt-1 text-xs text-muted-foreground">
        Default weight in the blended value: {r.weight ? `${+r.weight.toFixed(2)}` : "0 (reference only)"}.{r.note ? ` ${r.note}` : ""}
      </p>
    </div>
  )
}

export function StatTiles({ items }: { items: { label: string; value: React.ReactNode; hint?: React.ReactNode }[] }) {
  return (
    <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border bg-border sm:grid-cols-4">
      {items.map((s) => (
        <div key={s.label} className="flex flex-col gap-0.5 bg-background px-3 py-2">
          <dt className="text-xs text-muted-foreground">{s.label}</dt>
          <dd className="text-base font-semibold tabular-nums">{s.value}</dd>
          {s.hint ? <dd className="text-xs text-muted-foreground">{s.hint}</dd> : null}
        </div>
      ))}
    </dl>
  )
}

export function DataTable({
  caption,
  head,
  rows,
  emphasise = [],
}: {
  caption: string
  head: string[]
  rows: React.ReactNode[][]
  emphasise?: number[]
}) {
  return (
    <div className="relative overflow-x-auto rounded-lg border">
      <table className="w-full text-[13px] tabular-nums">
        <caption className="border-b px-3 py-1.5 text-left text-xs font-semibold">{caption}</caption>
        <thead className="bg-muted text-xs text-muted-foreground">
          <tr>
            {head.map((h, i) => <th key={`${h}-${i}`} scope="col" className={cn("px-3 py-1.5 font-medium", i ? "text-right" : "text-left")}>{h}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className={cn("border-t", emphasise.includes(i) && "font-semibold")}>
              {r.map((c, j) => (j === 0 ? (
                <th key={j} scope="row" className="px-3 py-1 text-left font-normal">
                  <span className="line-clamp-2 max-w-72 min-w-24 break-words" title={typeof c === "string" ? c : undefined}>{c}</span>
                </th>
              ) : (
                <td key={j} className="px-3 py-1 text-right whitespace-nowrap">{c}</td>
              )))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export function useMoney() {
  const { currency, scale } = useMethodsContext()
  return React.useMemo(
    () => ({
      unit: moneyUnit(currency, scale),
      scaled: (v: number | null | undefined, d = 1) => (v === null || v === undefined ? "n/m" : formatAccounting(v / scale, d)),
      compact: (v: number | null | undefined) => formatMoneyCompact(v, currency),
    }),
    [currency, scale],
  )
}
