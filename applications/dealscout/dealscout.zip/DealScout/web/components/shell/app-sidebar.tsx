"use client"

import Link from "next/link"
import { usePathname, useSearchParams } from "next/navigation"
import { BotIcon, BriefcaseBusinessIcon, PlusIcon, Settings2Icon, type LucideIcon } from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSkeleton,
  SidebarRail,
} from "@/components/ui/sidebar"
import { useDeals } from "@/lib/queries"

interface NavItem {
  href: string
  label: string
  icon: LucideIcon
  match: (path: string) => boolean
}

const PRIMARY: NavItem[] = [
  { href: "/", label: "Deals", icon: BriefcaseBusinessIcon, match: (p) => p === "/" },
  { href: "/deals/new", label: "New deal", icon: PlusIcon, match: (p) => p.startsWith("/deals/new") },
]

const SETTINGS: NavItem[] = [
  { href: "/settings/ai", label: "Connect AI", icon: BotIcon, match: (p) => p.startsWith("/settings/ai") },
  { href: "/settings", label: "Settings", icon: Settings2Icon, match: (p) => p === "/settings" },
]

function Logo() {
  return (
    <Link
      href="/"
      className="flex items-center gap-2 rounded-md px-1.5 py-1 outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring"
    >
      <span
        aria-hidden
        className="flex size-7 shrink-0 items-center justify-center rounded-md bg-sidebar-primary text-[13px] font-bold text-sidebar-primary-foreground"
      >
        DS
      </span>
      <span className="truncate text-sm font-semibold tracking-tight text-sidebar-accent-foreground group-data-[collapsible=icon]:hidden">
        DealScout
      </span>
    </Link>
  )
}

function NavGroup({ label, items, path }: { label: string; items: NavItem[]; path: string }) {
  return (
    <SidebarGroup>
      <SidebarGroupLabel>{label}</SidebarGroupLabel>
      <SidebarGroupContent>
        <SidebarMenu>
          {items.map((item) => (
            <SidebarMenuItem key={item.href}>
              <SidebarMenuButton render={<Link href={item.href} />} isActive={item.match(path)} tooltip={item.label}>
                <item.icon />
                <span>{item.label}</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  )
}

function RecentDeals({ path }: { path: string }) {
  const params = useSearchParams()
  const activeId = path === "/deal" ? params.get("id") : null
  const { data, isPending } = useDeals({ sort: "updated" })
  const recent = data?.items.slice(0, 6) ?? []
  return (
    <SidebarGroup className="group-data-[collapsible=icon]:hidden">
      <SidebarGroupLabel>Recent deals</SidebarGroupLabel>
      <SidebarGroupContent>
        <SidebarMenu>
          {isPending
            ? Array.from({ length: 3 }, (_, i) => (
                <SidebarMenuItem key={i}>
                  <SidebarMenuSkeleton />
                </SidebarMenuItem>
              ))
            : recent.map((deal) => (
                <SidebarMenuItem key={deal.id}>
                  <SidebarMenuButton
                    render={<Link href={`/deal?id=${deal.id}`} />}
                    isActive={deal.id === activeId}
                    size="sm"
                    title={deal.name}
                  >
                    <span className="truncate">{deal.name}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
          {!isPending && recent.length === 0 ? (
            <li className="px-2 py-1 text-xs text-sidebar-foreground/70">No deals yet</li>
          ) : null}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  )
}

export function AppSidebar() {
  const path = usePathname()
  return (
    <Sidebar collapsible="icon">
      <SidebarHeader>
        <Logo />
      </SidebarHeader>
      <SidebarContent>
        <NavGroup label="Workspace" items={PRIMARY} path={path} />
        <RecentDeals path={path} />
        <NavGroup label="Setup" items={SETTINGS} path={path} />
      </SidebarContent>
      <SidebarFooter className="px-3 pb-3 text-[11px] leading-snug text-sidebar-foreground/70 group-data-[collapsible=icon]:hidden">
        Runs only on this computer. Documents never leave it except the pages you send to your own AI provider.
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
