"use client"

import { MoonIcon, SunIcon } from "lucide-react"
import { useTheme } from "next-themes"

import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"

export function ThemeToggle() {
  const { resolvedTheme, setTheme } = useTheme()
  const next = resolvedTheme === "dark" ? "light" : "dark"
  return (
    <Tooltip>
      <TooltipTrigger
        render={<Button variant="ghost" size="icon-sm" aria-label={`Switch to ${next} mode`} onClick={() => setTheme(next)} />}
      >
        <SunIcon className="hidden dark:block" aria-hidden />
        <MoonIcon className="dark:hidden" aria-hidden />
      </TooltipTrigger>
      <TooltipContent>
        Switch to {next} mode <span className="ml-1 opacity-70">D</span>
      </TooltipContent>
    </Tooltip>
  )
}
