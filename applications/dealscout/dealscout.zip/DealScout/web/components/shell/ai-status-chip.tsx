"use client"

import Link from "next/link"
import { CircleAlertIcon, CircleCheckIcon, CircleDashedIcon, CircleSlashIcon } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import { useAIStatus } from "@/lib/queries"

/** Header chip: which AI is connected (or why none is). Colour is always paired with an icon and text. */
export function AIStatusChip() {
  const { data, isPending, isError } = useAIStatus()
  if (isPending) return <Badge variant="outline" className="h-6 w-28 animate-pulse" aria-label="Loading AI status" />
  let variant: "positive" | "warning" | "outline" = "outline"
  let Icon = CircleDashedIcon
  let label = "AI not connected"
  let tip = "Connect your own AI provider to read documents. You can also continue without AI."
  if (isError) {
    variant = "warning"
    Icon = CircleAlertIcon
    label = "Status unavailable"
    tip = "Could not read the AI status from the local server."
  } else if (data && !data.enabled) {
    Icon = CircleSlashIcon
    label = "AI off"
    tip = data.disabled_reason ?? "AI features are off."
  } else if (data?.connected) {
    const failing = data.last_test_code && data.last_test_code !== "ok"
    variant = failing ? "warning" : "positive"
    Icon = failing ? CircleAlertIcon : CircleCheckIcon
    label = `${data.provider_label ?? data.provider}${data.model ? ` · ${data.model}` : ""}`
    tip = failing ? "The last connection test failed. Open Connect AI to fix it." : "Connected AI provider and model."
  }
  return (
    <Tooltip>
      <TooltipTrigger
        render={
          <Link
            href="/settings/ai"
            className="rounded-md outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={`AI status: ${label}. Open Connect AI.`}
          />
        }
      >
        <Badge variant={variant} className="h-6 max-w-[16rem] gap-1.5">
          <Icon aria-hidden />
          <span className="truncate">{label}</span>
        </Badge>
      </TooltipTrigger>
      <TooltipContent>{tip}</TooltipContent>
    </Tooltip>
  )
}
