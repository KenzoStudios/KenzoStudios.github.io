"use client"

import * as React from "react"

import { DisclaimerBar } from "@/components/common/disclaimer"
import { Separator } from "@/components/ui/separator"
import { SidebarInset, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar"

import { AIStatusChip } from "./ai-status-chip"
import { AppSidebar } from "./app-sidebar"
import { CommandMenu } from "./command-menu"
import { ThemeToggle } from "./theme-toggle"

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <SidebarProvider>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:rounded-md focus:bg-background focus:px-3 focus:py-2 focus:text-sm focus:shadow"
      >
        Skip to content
      </a>
      <React.Suspense fallback={null}>
        <AppSidebar />
      </React.Suspense>
      <SidebarInset className="min-h-dvh min-w-0">
        <header className="sticky top-0 z-10 flex h-12 shrink-0 items-center gap-2 border-b bg-background/95 px-3 backdrop-blur supports-[backdrop-filter]:bg-background/80 md:px-4">
          <SidebarTrigger />
          <Separator orientation="vertical" className="mr-1 h-5" />
          <div className="min-w-0 flex-1">
            <CommandMenu />
          </div>
          <AIStatusChip />
          <ThemeToggle />
        </header>
        <main id="main" className="flex min-w-0 flex-1 flex-col">
          {children}
        </main>
        <DisclaimerBar />
      </SidebarInset>
    </SidebarProvider>
  )
}
