"use client"

import * as React from "react"
import { useRouter } from "next/navigation"
import { BotIcon, BriefcaseBusinessIcon, MoonIcon, PlusIcon, SearchIcon, Settings2Icon } from "lucide-react"
import { useTheme } from "next-themes"

import { Button } from "@/components/ui/button"
import {
  Command,
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandShortcut,
} from "@/components/ui/command"
import { Kbd } from "@/components/ui/kbd"
import { useDeals } from "@/lib/queries"

export function CommandMenu() {
  const [open, setOpen] = React.useState(false)
  const router = useRouter()
  const { resolvedTheme, setTheme } = useTheme()
  const { data } = useDeals({ sort: "updated" })

  React.useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() === "k" && (event.metaKey || event.ctrlKey)) {
        event.preventDefault()
        setOpen((value) => !value)
      }
    }
    document.addEventListener("keydown", onKey)
    return () => document.removeEventListener("keydown", onKey)
  }, [])

  const go = (href: string) => {
    setOpen(false)
    router.push(href)
  }

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        className="w-full max-w-64 justify-start text-muted-foreground sm:w-64"
        onClick={() => setOpen(true)}
      >
        <SearchIcon data-icon="inline-start" />
        <span className="truncate">Search deals and commands</span>
        <Kbd className="ml-auto hidden sm:inline-flex">⌘K</Kbd>
      </Button>
      <CommandDialog open={open} onOpenChange={setOpen} title="Search" description="Jump to a deal or run a command">
        <Command>
          <CommandInput placeholder="Type a deal name or a command…" />
          <CommandList>
            <CommandEmpty>Nothing matches. Try another name.</CommandEmpty>
            <CommandGroup heading="Actions">
              <CommandItem onSelect={() => go("/deals/new")}>
                <PlusIcon />
                New deal
              </CommandItem>
              <CommandItem onSelect={() => go("/")}>
                <BriefcaseBusinessIcon />
                All deals
              </CommandItem>
              <CommandItem onSelect={() => go("/settings/ai")}>
                <BotIcon />
                Connect AI
              </CommandItem>
              <CommandItem onSelect={() => go("/settings")}>
                <Settings2Icon />
                Settings
              </CommandItem>
              <CommandItem
                onSelect={() => {
                  setTheme(resolvedTheme === "dark" ? "light" : "dark")
                  setOpen(false)
                }}
              >
                <MoonIcon />
                Toggle dark mode
                <CommandShortcut>D</CommandShortcut>
              </CommandItem>
            </CommandGroup>
            {data?.items.length ? (
              <CommandGroup heading="Deals">
                {data.items.slice(0, 50).map((deal) => (
                  <CommandItem key={deal.id} value={`${deal.name} ${deal.ticker ?? ""} ${deal.id}`} onSelect={() => go(`/deal?id=${deal.id}`)}>
                    <BriefcaseBusinessIcon />
                    <span className="truncate">{deal.name}</span>
                    <span className="ml-auto text-xs text-muted-foreground">{deal.sector_name}</span>
                  </CommandItem>
                ))}
              </CommandGroup>
            ) : null}
          </CommandList>
        </Command>
      </CommandDialog>
    </>
  )
}
