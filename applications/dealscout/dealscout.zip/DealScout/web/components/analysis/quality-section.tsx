"use client"

import * as React from "react"
import { CheckIcon, CircleAlertIcon, LoaderCircleIcon, PlusIcon, SparklesIcon, Trash2Icon, TriangleAlertIcon } from "lucide-react"

import { MethodsProvider, moneyUnit, NumInput, SwitchField, useMethodsContext, useSectionDraft } from "@/components/methods/kit"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select"
import { useQueryClient } from "@tanstack/react-query"
import { ApiError } from "@/lib/api"
import { formatAccounting, formatPct } from "@/lib/format"
import { methodKeys, useFinancials, useJob, useMethods, useSuggestOneOffs } from "@/lib/queries"
import type { Adjustment, AnalysisResponse, Deal, FlagEvidence, RedFlag, ScoreResult } from "@/lib/types"

const SEVERITY: Record<RedFlag["severity"], { label: string; variant: "negative" | "warning" | "positive"; icon: React.ReactNode }> = {
  high: { label: "High", variant: "negative", icon: <CircleAlertIcon aria-hidden /> },
  medium: { label: "Medium", variant: "warning", icon: <TriangleAlertIcon aria-hidden /> },
  none: { label: "No concern", variant: "positive", icon: <CheckIcon aria-hidden /> },
}

const ZONE: Record<string, { label: string; variant: "negative" | "warning" | "positive" }> = {
  safe: { label: "Safe zone", variant: "positive" },
  grey: { label: "Grey zone", variant: "warning" },
  distress: { label: "Distress zone", variant: "negative" },
}

function scoreBand(s: ScoreResult): { label: string; variant: "negative" | "warning" | "positive" } | null {
  if (s.value === null || s.missing.length) return null // no band on a partial score
  if (s.zone && ZONE[s.zone]) return ZONE[s.zone]
  if (s.name === "Piotroski F") return s.value >= 7 ? { label: "Strong", variant: "positive" } : s.value <= 3 ? { label: "Weak", variant: "negative" } : { label: "Middling", variant: "warning" }
  if (s.name === "Beneish M") return s.value > -1.78 ? { label: "Possible manipulation", variant: "negative" } : { label: "Unlikely manipulator", variant: "positive" }
  return null
}

function Scores({ data }: { data: AnalysisResponse }) {
  const items = data.scores.items
  if (!items.length) return null
  return (
    <section aria-labelledby="scores-title" className="flex flex-col gap-2">
      <h2 id="scores-title" className="text-sm font-semibold">Scores ({data.scores.period}{data.scores.prior ? ` vs ${data.scores.prior}` : ""})</h2>
      <div className="grid gap-3 md:grid-cols-3">
        {items.map((s) => {
          const band = scoreBand(s)
          return (
            <div key={s.name} className="flex flex-col gap-1 rounded-lg border px-3 py-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-muted-foreground">{s.name}{s.variant ? ` (${s.variant.replaceAll("_", " ")})` : ""}</span>
                {band ? <Badge variant={band.variant} className="h-5 text-[11px]">{band.label}</Badge> : null}
              </div>
              <span className="text-lg font-semibold tabular-nums">{s.value === null ? "n/m" : s.name === "Piotroski F" ? `${s.value} of 9${s.missing.length ? " (partial)" : ""}` : formatAccounting(s.value, 2)}</span>
              {s.missing.length ? <span className="text-xs text-muted-foreground">Missing: {s.missing.join(", ")}</span> : null}
              {s.note ? <span className="text-xs text-muted-foreground">{s.note}</span> : null}
            </div>
          )
        })}
      </div>
    </section>
  )
}

/** The original file opens at the page (PDF viewers honour #page=N); HTML filings open their sanitised view. */
function evidenceHref(dealId: string, e: FlagEvidence): string {
  const base = `/api/deals/${dealId}/documents/${e.document_id}`
  return /\.(x?html?|zip)$/i.test(e.filename) ? `${base}/view` : `${base}/file#page=${e.page}`
}

function Evidence({ dealId, evidence }: { dealId: string; evidence: FlagEvidence[] }) {
  return (
    <ul className="mt-0.5 flex flex-col gap-0.5 text-xs">
      {evidence.map((e) => (
        <li key={`${e.document_id}-${e.page}`} className="min-w-0">
          <Tooltip>
            <TooltipTrigger
              render={
                <a
                  href={evidenceHref(dealId, e)}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-block max-w-64 truncate align-bottom text-link underline-offset-2 hover:underline focus-visible:rounded-sm focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
                />
              }
            >
              p. {e.page}, {e.filename}
              <span className="sr-only">. Quote: {e.snippet}</span>
            </TooltipTrigger>
            <TooltipContent className="max-w-sm text-left leading-snug">“{e.snippet}”</TooltipContent>
          </Tooltip>
        </li>
      ))}
    </ul>
  )
}

function flagMetric(f: RedFlag): React.ReactNode {
  if (f.source === "document") {
    return f.metric === null ? <span className="text-muted-foreground">Text</span> : formatPct(f.metric)
  }
  return f.metric === null ? "n/m" : formatAccounting(f.metric, 2)
}

function Flags({ flags, dealId, scanned }: { flags: RedFlag[]; dealId: string; scanned?: number }) {
  return (
    <section aria-labelledby="flags-title" className="flex flex-col gap-2">
      <div className="flex flex-wrap items-baseline justify-between gap-x-3">
        <h2 id="flags-title" className="text-sm font-semibold">Early warning signs</h2>
        <p className="text-xs text-muted-foreground">
          From the figures{scanned ? ` and the text of ${scanned} document${scanned === 1 ? "" : "s"}` : ""}. Text signs are found by phrase rules; read the quoted page before relying on them.
        </p>
      </div>
      <div className="relative overflow-x-auto rounded-lg border">
        <table className="w-full text-[13px] tabular-nums">
          <thead className="bg-muted text-xs text-muted-foreground">
            <tr>
              <th className="px-3 py-1.5 text-left font-medium">Signal</th>
              <th className="px-3 py-1.5 text-left font-medium">Period</th>
              <th className="px-3 py-1.5 text-right font-medium">Metric</th>
              <th className="px-3 py-1.5 text-left font-medium">Threshold</th>
              <th className="px-3 py-1.5 text-left font-medium">Severity</th>
              <th className="px-3 py-1.5 text-left font-medium">Why it matters</th>
            </tr>
          </thead>
          <tbody>
            {flags.length === 0 ? (
              <tr><td colSpan={6} className="px-3 py-4 text-center text-muted-foreground">No signal could be tested with the figures entered so far.</td></tr>
            ) : null}
            {flags.map((f) => {
              const sev = SEVERITY[f.severity]
              return (
                <tr key={`${f.id}-${f.period}-${f.evidence?.[0]?.document_id ?? ""}`} className="border-t align-top">
                  <th scope="row" className="px-3 py-1.5 text-left font-normal">
                    {f.signal}
                    {f.source === "document" && f.evidence?.length ? <Evidence dealId={dealId} evidence={f.evidence} /> : null}
                  </th>
                  <td className="px-3 py-1.5">{f.period}</td>
                  <td className="px-3 py-1.5 text-right">{flagMetric(f)}</td>
                  <td className="px-3 py-1.5">{f.threshold}</td>
                  <td className="px-3 py-1.5"><Badge variant={sev.variant} className="h-5 text-[11px]">{sev.icon}{sev.label}</Badge></td>
                  <td className="px-3 py-1.5 text-muted-foreground">{f.explanation}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </section>
  )
}

const CATEGORIES: { value: Adjustment["category"]; label: string }[] = [
  { value: "restructuring", label: "Restructuring" },
  { value: "impairment", label: "Impairment" },
  { value: "litigation", label: "Litigation" },
  { value: "disposal_gain", label: "Disposal gain/loss" },
  { value: "transaction_costs", label: "Transaction costs" },
  { value: "other", label: "Other" },
]

function Normalisation({ deal, data }: { deal: Deal; data: AnalysisResponse }) {
  const { data: doc } = useMethods(deal.id)
  const state = useSectionDraft("normalisation", doc?.normalisation)
  const suggest = useSuggestOneOffs(deal.id)
  const [jobId, setJobId] = React.useState<string | null>(null)
  const job = useJob(jobId, !!jobId)
  const qc = useQueryClient()
  React.useEffect(() => {
    if (job.data && ["done", "failed", "paused"].includes(job.data.status)) {
      qc.invalidateQueries({ queryKey: methodKeys.doc(deal.id) })
    }
  }, [job.data, qc, deal.id])
  const { scale, currency } = useMethodsContext()
  const d = state.draft
  if (!d) return null
  const setRow = (i: number, patch: Partial<Adjustment>) =>
    state.update((x) => ({ ...x, adjustments: x.adjustments.map((a, j) => (j === i ? { ...a, ...patch } : a)) }))
  const running = !!jobId && (!job.data || job.data.status === "queued" || job.data.status === "running")
  return (
    <section aria-labelledby="norm-title" className="flex flex-col gap-3 rounded-lg border p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 id="norm-title" className="text-sm font-semibold">One-off items and adjusted EBITDA</h2>
          <p className="text-xs text-muted-foreground">
            A cost is negative, a gain positive. Only confirmed items change adjusted figures. AI suggestions are checked against the page they cite.
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          disabled={suggest.isPending || running || state.dirty}
          title={state.dirty ? "Save or discard your changes first: new suggestions are added to the saved list" : undefined}
          onClick={async () => {
            try {
              const j = await suggest.mutateAsync()
              setJobId(j.id)
            } catch {
              /* shown below */
            }
          }}
        >
          {running ? <LoaderCircleIcon data-icon="inline-start" className="animate-spin" /> : <SparklesIcon data-icon="inline-start" />}
          {running ? "Reading documents…" : "Suggest with AI"}
        </Button>
      </div>
      {suggest.error ? (
        <Alert variant="destructive"><CircleAlertIcon /><AlertTitle>AI suggestions unavailable</AlertTitle><AlertDescription>{(suggest.error as ApiError).message}</AlertDescription></Alert>
      ) : null}
      {job.data?.status === "failed" || job.data?.status === "paused" ? (
        <Alert variant="destructive"><CircleAlertIcon /><AlertTitle>The AI search stopped</AlertTitle><AlertDescription>{job.data.message}</AlertDescription></Alert>
      ) : null}
      <div className="relative overflow-x-auto rounded-lg border">
        <table className="w-full text-[13px] tabular-nums">
          <thead className="bg-muted text-xs text-muted-foreground">
            <tr>
              <th className="px-2 py-1.5 text-left font-medium">Confirmed</th>
              <th className="px-2 py-1.5 text-left font-medium">Period</th>
              <th className="px-2 py-1.5 text-left font-medium">Item</th>
              <th className="px-2 py-1.5 text-left font-medium">Category</th>
              <th className="px-2 py-1.5 text-right font-medium">Effect on profit</th>
              <th className="px-2 py-1.5 text-left font-medium">In EBITDA</th>
              <th className="px-2 py-1.5 text-left font-medium">Source</th>
              <th className="w-9"><span className="sr-only">Remove</span></th>
            </tr>
          </thead>
          <tbody>
            {d.adjustments.length === 0 ? (
              <tr><td colSpan={8} className="px-3 py-4 text-center text-muted-foreground">No one-off items. Add one, or ask the AI to look through the documents.</td></tr>
            ) : null}
            {d.adjustments.map((a, i) => (
              <tr key={a.id} className="border-t align-top">
                <td className="px-2 py-1"><Checkbox checked={a.confirmed} aria-label={`Confirm ${a.label}`} onCheckedChange={(v) => setRow(i, { confirmed: !!v })} /></td>
                <td className="px-2 py-1">
                  <NativeSelect size="sm" className="min-w-24" value={a.period_key} aria-label={`${a.label}: period`} onChange={(e) => setRow(i, { period_key: e.target.value })}>
                    {[...new Set([...data.periods, a.period_key])].map((p) => <NativeSelectOption key={p} value={p}>{p}</NativeSelectOption>)}
                  </NativeSelect>
                </td>
                <td className="px-2 py-1">
                  <Input className="h-7 min-w-44" value={a.label} aria-label={`Item ${i + 1}: description`} autoComplete="off" onChange={(e) => setRow(i, { label: e.target.value })} />
                  {a.rationale ? <p className="mt-0.5 line-clamp-2 max-w-80 break-words text-xs text-muted-foreground" title={a.rationale}>{a.rationale}</p> : null}
                </td>
                <td className="px-2 py-1">
                  <NativeSelect size="sm" className="min-w-36" value={a.category} aria-label={`${a.label}: category`} onChange={(e) => setRow(i, { category: e.target.value as Adjustment["category"] })}>
                    {CATEGORIES.map((c) => <NativeSelectOption key={c.value} value={c.value}>{c.label}</NativeSelectOption>)}
                  </NativeSelect>
                </td>
                <td className="px-2 py-1 min-w-28"><NumInput kind="money" label={`${a.label}: amount`} value={a.amount} nullable={false} onChange={(v) => setRow(i, { amount: v ?? 0 })} /></td>
                <td className="px-2 py-1">
                  <Checkbox
                    checked={a.affects_ebitda ?? a.category !== "impairment"}
                    aria-label={`${a.label}: sits within EBITDA`}
                    onCheckedChange={(v) => setRow(i, { affects_ebitda: !!v })}
                  />
                </td>
                <td className="px-2 py-1 text-xs">
                  {a.source === "ai_suggested" ? (
                    <Badge variant={a.confirmed ? "secondary" : "warning"} className="h-5 text-[11px]">
                      AI{a.page ? `, p. ${a.page}` : ""}{a.value_as_written ? `: ${a.value_as_written}` : ""}
                    </Badge>
                  ) : "You"}
                </td>
                <td className="px-1 py-1">
                  <Button variant="ghost" size="icon-xs" aria-label={`Remove ${a.label}`} onClick={() => state.update((x) => ({ ...x, adjustments: x.adjustments.filter((_, j) => j !== i) }))}>
                    <Trash2Icon />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <Button
          variant="outline"
          size="sm"
          onClick={() =>
            state.update((x) => ({
              ...x,
              adjustments: [
                ...x.adjustments,
                {
                  id: Math.random().toString(16).slice(2, 14),
                  period_key: data.periods[data.periods.length - 1] ?? "",
                  label: "New item",
                  category: "other",
                  amount: 0,
                  affects_ebitda: null,
                  confirmed: false,
                  source: "user",
                  rationale: null,
                  document_id: null,
                  page: null,
                  value_as_written: null,
                },
              ],
            }))
          }
        >
          <PlusIcon data-icon="inline-start" />
          Add item
        </Button>
        <SwitchField
          label="Value on adjusted EBITDA and EBIT"
          checked={d.use_adjusted_ebitda}
          onChange={(x) => state.update((y) => ({ ...y, use_adjusted_ebitda: x }))}
        />
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Button size="sm" disabled={!state.dirty || state.pending} onClick={() => void state.submit()}>
          {state.pending ? <LoaderCircleIcon data-icon="inline-start" className="animate-spin" /> : null}
          Save adjustments
        </Button>
        <Button variant="ghost" size="sm" disabled={!state.dirty || state.pending} onClick={state.discard}>Discard changes</Button>
        <span aria-live="polite" className="text-xs text-muted-foreground">{state.dirty ? "Unsaved changes" : state.saved ? "Saved" : null}</span>
        {state.error ? <span role="alert" className="text-xs text-negative">{state.error.message}</span> : null}
      </div>
      <table className="w-full max-w-2xl text-[13px] tabular-nums">
        <caption className="mb-1 text-left text-xs font-semibold">Reported to adjusted</caption>
        <thead className="text-xs text-muted-foreground">
          <tr><th className="text-left font-medium">Period</th><th className="text-right font-medium">Reported EBITDA</th><th className="text-right font-medium">Adjustments</th><th className="text-right font-medium">Adjusted EBITDA</th><th className="text-right font-medium">Adjusted EBIT</th></tr>
        </thead>
        <tbody>
          {data.adjusted.map((m) => (
            <tr key={m.period} className="border-t">
              <th scope="row" className="py-1 text-left font-normal">{m.period}</th>
              <td className="text-right">{formatAccounting(m.reported_ebitda === null ? null : m.reported_ebitda / scale, 1)}</td>
              <td className="text-right">{formatAccounting(m.ebitda_adjustment / scale, 1)}</td>
              <td className="text-right font-semibold">{formatAccounting(m.adjusted_ebitda === null ? null : m.adjusted_ebitda / scale, 1)}</td>
              <td className="text-right">{formatAccounting(m.adjusted_ebit === null ? null : m.adjusted_ebit / scale, 1)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="text-xs text-muted-foreground">Figures in {moneyUnit(currency, scale)}.{d.use_adjusted_ebitda ? " The valuation uses the adjusted figures." : ""}</p>
    </section>
  )
}

export function QualitySection({ deal, data }: { deal: Deal; data: AnalysisResponse }) {
  const { data: grid } = useFinancials(deal.id)
  return (
    <MethodsProvider value={{ dealId: deal.id, currency: data.currency, scale: grid?.entry.scale ?? 1e6 }}>
      <div className="flex flex-col gap-6">
        <Scores data={data} />
        <Flags flags={data.red_flags} dealId={deal.id} scanned={data.documents_scanned} />
        <Normalisation deal={deal} data={data} />
      </div>
    </MethodsProvider>
  )
}

