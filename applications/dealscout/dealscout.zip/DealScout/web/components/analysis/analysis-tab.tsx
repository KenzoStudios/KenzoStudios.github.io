"use client"

import { FxNote } from "@/components/common/fx-note"
import * as React from "react"

import { CapitalStructureChart, DebtMaturityChart, capitalPeriods } from "@/components/charts/capital-charts"
import { RevenueEbitdaChart } from "@/components/charts/valuation-charts"
import { Sparkline } from "@/components/charts/sparkline"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Skeleton } from "@/components/ui/skeleton"
import { formatAccounting, formatMoneyCompact, formatMultiple, formatPct } from "@/lib/format"
import { useAnalysis } from "@/lib/queries"
import { QualitySection } from "./quality-section"
import { SectorKpis } from "./sector-kpis"
import type { Deal, Ratio } from "@/lib/types"

const GROUPS: { id: Ratio["group"]; label: string }[] = [
  { id: "growth", label: "Growth" },
  { id: "profitability", label: "Profitability" },
  { id: "returns", label: "Returns" },
  { id: "cash", label: "Cash generation" },
  { id: "leverage", label: "Leverage & coverage" },
  { id: "liquidity", label: "Liquidity" },
  { id: "efficiency", label: "Efficiency" },
]

export function formatRatio(r: Pick<Ratio, "unit" | "value">, currency: string): string {
  if (r.value === null) return "n/m"
  switch (r.unit) {
    case "pct":
      return formatPct(r.value)
    case "x":
      return formatMultiple(r.value)
    case "days":
      return `${formatAccounting(r.value, 0)} d`
    case "currency":
      return formatMoneyCompact(r.value, currency)
    default:
      return formatAccounting(r.value, 2)
  }
}

export function RatioCell({ ratio, currency }: { ratio: Ratio; currency: string }) {
  return (
    <Popover>
      <PopoverTrigger
        render={
          <button
            type="button"
            className="w-full rounded-sm px-1 text-right tabular-nums hover:bg-muted focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
            aria-label={`${ratio.label} ${ratio.period_id}: ${formatRatio(ratio, currency)}. Show how it is calculated.`}
          />
        }
      >
        <span className={ratio.value === null ? "text-muted-foreground" : undefined}>{formatRatio(ratio, currency)}</span>
      </PopoverTrigger>
      <PopoverContent className="w-80 text-sm">
        <p className="font-medium">
          {ratio.label} · {ratio.period_id}
        </p>
        <p className="mt-1 text-muted-foreground">{ratio.definition}</p>
        {ratio.derivation.formula ? <code className="mt-2 block font-mono text-xs">{ratio.derivation.formula}</code> : null}
        {ratio.derivation.inputs.length ? (
          <dl className="mt-2 grid grid-cols-[auto_1fr] gap-x-3 gap-y-0.5 text-xs tabular-nums">
            {ratio.derivation.inputs.map((i) => (
              <React.Fragment key={i.name}>
                <dt className="text-muted-foreground">{i.name.replaceAll("_", " ")}</dt>
                <dd className="text-right">
                  {i.value === null
                    ? "missing"
                    : Math.abs(i.value) < 5 && i.name.includes("rate")
                      ? formatPct(i.value)
                      : Math.abs(i.value) >= 1000
                        ? formatMoneyCompact(i.value, currency)
                        : formatAccounting(i.value, 2)}
                </dd>
              </React.Fragment>
            ))}
          </dl>
        ) : null}
        {ratio.derivation.note ? <p className="mt-2 text-xs text-warning">{ratio.derivation.note}</p> : null}
      </PopoverContent>
    </Popover>
  )
}

export function AnalysisTab({ deal }: { deal: Deal }) {
  const { data, isPending, isError, error } = useAnalysis(deal.id)
  if (isPending) return <Skeleton className="h-96 w-full" />
  if (isError || !data) {
    return (
      <Alert variant="destructive">
        <AlertTitle>Analysis could not be loaded</AlertTitle>
        <AlertDescription>{error?.message}</AlertDescription>
      </Alert>
    )
  }
  const latest = data.periods[data.periods.length - 1]
  const get = (id: string, period = latest) => data.ratios.find((r) => r.ratio_id === id && r.period_id === period)
  const hasData = Object.values(data.series.revenue ?? {}).some((v) => v !== null)
  if (!hasData) {
    return (
      <Alert>
        <AlertTitle>No figures yet</AlertTitle>
        <AlertDescription>Enter at least revenue for one year on the Data tab; ratios and charts appear here.</AlertDescription>
      </Alert>
    )
  }
  const tiles: { label: string; value: string; hint: string }[] = [
    {
      label: "Revenue CAGR",
      value: formatPct(data.revenue_cagr.value),
      hint: data.revenue_cagr.from ? `${data.revenue_cagr.from} to ${data.revenue_cagr.to}` : "needs two years",
    },
    { label: "EBITDA margin", value: formatRatio(get("ebitda_margin") ?? { unit: "pct", value: null }, data.currency), hint: latest },
    { label: "ROIC", value: formatRatio(get("roic") ?? { unit: "pct", value: null }, data.currency), hint: latest },
    { label: "Net debt ÷ EBITDA", value: formatRatio(get("net_debt_to_ebitda") ?? { unit: "x", value: null }, data.currency), hint: latest },
    { label: "FCF conversion", value: formatRatio(get("fcf_conversion_ebitda") ?? { unit: "pct", value: null }, data.currency), hint: `${latest}, of EBITDA` },
  ]
  const capital = capitalPeriods(data.capital_structure)
  const maturity = [...(data.capital_structure ?? [])].reverse().find((c) => c.maturities_total !== null)
  return (
    <div className="flex flex-col gap-6">
      <FxNote fx={data.fx} />
      <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border bg-border sm:grid-cols-3 lg:grid-cols-5">
        {tiles.map((t) => (
          <div key={t.label} className="bg-background px-4 py-3">
            <dt className="text-xs text-muted-foreground">{t.label}</dt>
            <dd className="mt-1 text-xl font-semibold tabular-nums">{t.value}</dd>
            <dd className="text-xs text-muted-foreground">{t.hint}</dd>
          </div>
        ))}
      </dl>
      <RevenueEbitdaChart
        labels={data.periods}
        revenue={data.periods.map((p) => data.series.revenue?.[p] ?? null)}
        ebitda={data.periods.map((p) => data.series.ebitda?.[p] ?? null)}
        projected={data.periods.map(() => false)}
        currency={data.currency}
      />
      {capital.length ? (
        <div className="grid gap-6 lg:grid-cols-2">
          <CapitalStructureChart items={capital} currency={data.currency} />
          {maturity ? (
            <DebtMaturityChart item={maturity} currency={data.currency} />
          ) : (
            <p className="self-center text-sm text-muted-foreground">
              No debt maturity profile yet. Enter debt due within 1 year, 1 to 2, 2 to 5 and after 5 years (Capital
              structure and memo items on the Data tab) to compare maturities with cash and undrawn facilities.
            </p>
          )}
        </div>
      ) : null}
      <div className="relative overflow-x-auto rounded-lg border">
        <table className="w-full text-[13px]">
          <caption className="sr-only">Financial ratios by period. Select a value to see how it is calculated.</caption>
          <thead className="sticky top-0 bg-muted text-xs text-muted-foreground">
            <tr>
              <th scope="col" className="min-w-56 px-3 py-2 text-left font-medium">Ratio</th>
              <th scope="col" className="px-3 py-2 text-left font-medium">Trend</th>
              {data.periods.map((p) => (
                <th key={p} scope="col" className="min-w-24 px-3 py-2 text-right font-medium">{p}</th>
              ))}
            </tr>
          </thead>
          {GROUPS.map((group) => {
            const ids = [...new Set(data.ratios.filter((r) => r.group === group.id).map((r) => r.ratio_id))]
            if (!ids.length) return null
            return (
              <tbody key={group.id}>
                <tr>
                  <th colSpan={data.periods.length + 2} scope="colgroup" className="border-t bg-band px-3 py-1.5 text-left text-xs font-semibold">
                    {group.label}
                  </th>
                </tr>
                {ids.map((id) => {
                  const series = data.periods.map((p) => get(id, p))
                  const first = series.find(Boolean)
                  return (
                    <tr key={id} className="border-t hover:bg-muted/50">
                      <th scope="row" className="px-3 py-1 text-left font-normal" title={first?.definition}>{first?.label}</th>
                      <td className="px-3 py-1"><Sparkline values={series.map((s) => s?.value ?? null)} /></td>
                      {series.map((r, i) => (
                        <td key={data.periods[i]} className="px-2 py-0.5">{r ? <RatioCell ratio={r} currency={data.currency} /> : null}</td>
                      ))}
                    </tr>
                  )
                })}
              </tbody>
            )
          })}
        </table>
      </div>
      <SectorKpis data={data} />
      <QualitySection deal={deal} data={data} />
      <p className="text-xs text-muted-foreground">
        Ratios use period-end balances unless averages are stated. ROIC uses invested capital = equity + debt (incl. leases) − cash; see
        each value for its inputs. “n/m” means not meaningful (missing input or a zero/negative base).
      </p>
    </div>
  )
}
