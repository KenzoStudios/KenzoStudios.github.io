"use client"

import { Sparkline } from "@/components/charts/sparkline"
import type { AnalysisResponse, Ratio } from "@/lib/types"
import { RatioCell } from "./analysis-tab"

/**
 * Sector KPIs (brief §8) for the deal's sector template only (bank, insurer, SaaS, real estate, retail).
 * Same table conventions as the ratio table: select a value to see whether it was computed or reported.
 */
export function SectorKpis({ data }: { data: AnalysisResponse }) {
  const sector = data.sector_kpis
  if (!sector || !sector.items.length) return null
  const ids = [...new Set(sector.items.map((k) => k.ratio_id))]
  const get = (id: string, period: string): Ratio | undefined =>
    sector.items.find((k) => k.ratio_id === id && k.period_id === period)
  const anyValue = sector.items.some((k) => k.value !== null)
  return (
    <section aria-labelledby="sector-kpis-title" className="flex flex-col gap-2">
      <div className="flex flex-wrap items-baseline justify-between gap-x-3">
        <h2 id="sector-kpis-title" className="text-sm font-semibold">{sector.label ?? "Sector KPIs"}</h2>
        <p className="text-xs text-muted-foreground">
          Computed from their inputs when available, otherwise as reported. Enter them under Sector KPIs on the Data tab.
        </p>
      </div>
      <div className="relative overflow-x-auto rounded-lg border">
        <table className="w-full text-[13px]">
          <caption className="sr-only">{sector.label ?? "Sector KPIs"} by period. Select a value to see how it is calculated.</caption>
          <thead className="bg-muted text-xs text-muted-foreground">
            <tr>
              <th scope="col" className="min-w-56 px-3 py-2 text-left font-medium">KPI</th>
              <th scope="col" className="px-3 py-2 text-left font-medium">Trend</th>
              {data.periods.map((p) => (
                <th key={p} scope="col" className="min-w-24 px-3 py-2 text-right font-medium">{p}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {ids.map((id) => {
              const series = data.periods.map((p) => get(id, p))
              const first = series.find(Boolean)
              return (
                <tr key={id} className="border-t hover:bg-muted/50">
                  <th scope="row" className="px-3 py-1 text-left font-normal" title={first?.definition}>{first?.label}</th>
                  <td className="px-3 py-1"><Sparkline values={series.map((s) => s?.value ?? null)} /></td>
                  {series.map((r, i) => (
                    <td key={data.periods[i]} className="px-2 py-0.5">{r ? <RatioCell ratio={r} currency={data.currency} /> : null}</td>
                  ))}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      {anyValue ? null : (
        <p className="text-xs text-muted-foreground">No sector KPI entered yet; “n/m” cells say which inputs are missing.</p>
      )}
    </section>
  )
}
