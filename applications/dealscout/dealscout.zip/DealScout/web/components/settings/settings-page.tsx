"use client"

import * as React from "react"
import { FolderOpenIcon, KeyRoundIcon } from "lucide-react"

import { LinkButton } from "@/components/common/link-button"
import { PageHeader } from "@/components/common/page-header"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Field, FieldContent, FieldDescription, FieldError, FieldGroup, FieldLabel, FieldTitle } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { InputGroup, InputGroupAddon, InputGroupInput, InputGroupText } from "@/components/ui/input-group"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Skeleton } from "@/components/ui/skeleton"
import { Switch } from "@/components/ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/toast"
import { api } from "@/lib/api"
import { formatInt, formatUsd } from "@/lib/format"
import { useAIStatus, useSavePreferences, useSettings, useUsage } from "@/lib/queries"
import type { Preferences } from "@/lib/types"

function useSaver() {
  const save = useSavePreferences()
  return async (changes: Partial<Preferences>, label: string) => {
    try {
      await save.mutateAsync(changes)
      toast.add({ title: `${label} saved`, type: "success" })
      return true
    } catch (error) {
      toast.add({ title: `${label} not saved`, description: (error as Error).message, type: "error" })
      return false
    }
  }
}

function ProfileCard({ prefs }: { prefs: Preferences }) {
  const saver = useSaver()
  const [name, setName] = React.useState(prefs.user_name)
  const [error, setError] = React.useState<string | null>(null)
  return (
    <Card>
      <CardHeader>
        <CardTitle>Your name</CardTitle>
        <CardDescription>Recorded against every override and edit in each deal&apos;s audit log.</CardDescription>
      </CardHeader>
      <CardContent>
        <form
          className="flex flex-col gap-3 sm:flex-row sm:items-end"
          onSubmit={async (event) => {
            event.preventDefault()
            if (!name.trim()) return setError("Enter the name to record in audit logs.")
            setError(null)
            await saver({ user_name: name.trim() }, "Name")
          }}
        >
          <Field data-invalid={!!error || undefined} className="sm:max-w-sm">
            <FieldLabel htmlFor="user-name">Name shown in audit logs</FieldLabel>
            <Input id="user-name" autoComplete="name" value={name} maxLength={120} aria-invalid={!!error || undefined} onChange={(e) => setName(e.target.value)} />
            <FieldError>{error}</FieldError>
          </Field>
          <Button type="submit" variant="outline" disabled={name.trim() === prefs.user_name}>
            Save name
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

function AICard({ prefs, disabledByEnv }: { prefs: Preferences; disabledByEnv: boolean }) {
  const saver = useSaver()
  const { data: status } = useAIStatus()
  const [cap, setCap] = React.useState(prefs.monthly_spend_cap_usd?.toString() ?? "")
  const capValue = cap.trim() === "" ? null : Number(cap)
  const capInvalid = capValue !== null && (!Number.isFinite(capValue) || capValue < 0)
  return (
    <Card>
      <CardHeader>
        <CardTitle>AI features</CardTitle>
        <CardDescription>What may be sent to your connected AI provider, and how much it may cost.</CardDescription>
      </CardHeader>
      <CardContent>
        <FieldGroup>
          {disabledByEnv ? (
            <Alert>
              <AlertTitle>AI is disabled by configuration</AlertTitle>
              <AlertDescription>DEALSCOUT_DISABLE_AI=1 is set in .env. Remove it and restart to use AI features.</AlertDescription>
            </Alert>
          ) : null}
          <Field orientation="horizontal">
            <FieldContent>
              <FieldLabel htmlFor="ai-enabled">Use AI to read documents and write summaries</FieldLabel>
              <FieldDescription>
                When off, nothing is sent to any AI provider. Tagged filings, rules-based extraction and manual entry still work.
              </FieldDescription>
            </FieldContent>
            <Switch
              id="ai-enabled"
              checked={prefs.ai_enabled}
              disabled={disabledByEnv}
              onCheckedChange={(checked) => saver({ ai_enabled: checked }, checked ? "AI turned on" : "AI turned off")}
            />
          </Field>
          <Field>
            <FieldTitle id="send-scope-label">What may be sent</FieldTitle>
            <RadioGroup
              aria-labelledby="send-scope-label"
              value={prefs.ai_send_scope}
              onValueChange={(value) => saver({ ai_send_scope: value as Preferences["ai_send_scope"] }, "Sending scope")}
            >
              <Field orientation="horizontal">
                <RadioGroupItem value="located_pages" id="scope-located" />
                <FieldContent>
                  <FieldLabel htmlFor="scope-located">Only the pages DealScout located (recommended)</FieldLabel>
                  <FieldDescription>Statements and the notes needed for a value. Cheaper and sends less confidential text.</FieldDescription>
                </FieldContent>
              </Field>
              <Field orientation="horizontal">
                <RadioGroupItem value="full_documents" id="scope-full" />
                <FieldContent>
                  <FieldLabel htmlFor="scope-full">Whole documents</FieldLabel>
                  <FieldDescription>Better qualitative summaries; higher cost and more text leaves this computer.</FieldDescription>
                </FieldContent>
              </Field>
            </RadioGroup>
          </Field>
          <form
            className="flex flex-col gap-3 sm:flex-row sm:items-end"
            onSubmit={async (event) => {
              event.preventDefault()
              if (capInvalid) return
              await saver({ monthly_spend_cap_usd: capValue }, "Spend cap")
            }}
          >
            <Field data-invalid={capInvalid || undefined} className="sm:max-w-xs">
              <FieldLabel htmlFor="spend-cap">Monthly spend cap</FieldLabel>
              <InputGroup>
                <InputGroupAddon>
                  <InputGroupText>US$</InputGroupText>
                </InputGroupAddon>
                <InputGroupInput
                  id="spend-cap"
                  inputMode="decimal"
                  placeholder="No cap"
                  value={cap}
                  aria-invalid={capInvalid || undefined}
                  onChange={(e) => setCap(e.target.value)}
                />
              </InputGroup>
              <FieldDescription>
                AI calls stop once this month&apos;s estimated spend reaches the cap.
                {status ? ` Spent so far this month: ${formatUsd(status.month_spend_usd)}.` : ""}
              </FieldDescription>
              <FieldError>{capInvalid ? "Enter a positive amount, or leave empty for no cap." : null}</FieldError>
            </Field>
            <Button type="submit" variant="outline" disabled={capInvalid || capValue === prefs.monthly_spend_cap_usd}>
              Save cap
            </Button>
          </form>
        </FieldGroup>
      </CardContent>
    </Card>
  )
}

function DataCard({ folder, keyStorage }: { folder: string; keyStorage: { backend: string; detail: string } }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Local data</CardTitle>
        <CardDescription>
          Your database, documents, cache and exports stay in this folder on this computer, outside the DealScout code.
          Turn on full-disk encryption (FileVault or BitLocker) to protect them.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <code className="min-w-0 flex-1 truncate rounded-md border bg-muted px-2 py-1.5 font-mono text-xs" title={folder}>
            {folder}
          </code>
          <Button
            variant="outline"
            size="sm"
            onClick={() =>
              api("/api/settings/open-data-folder", { method: "POST" }).catch((error: Error) =>
                toast.add({ title: "Could not open the folder", description: error.message, type: "error" }),
              )
            }
          >
            <FolderOpenIcon data-icon="inline-start" />
            Open folder
          </Button>
        </div>
        <div className="flex items-start gap-2 text-sm">
          <KeyRoundIcon aria-hidden className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
          <p>
            <span className="font-medium">AI keys:</span> {keyStorage.detail}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

function UsageCard() {
  const { data, isPending } = useUsage()
  return (
    <Card>
      <CardHeader>
        <CardTitle>AI usage</CardTitle>
        <CardDescription>Estimated from each provider&apos;s published prices; your provider&apos;s bill is authoritative.</CardDescription>
      </CardHeader>
      <CardContent>
        {isPending ? (
          <Skeleton className="h-20 w-full" />
        ) : !data?.summary.length ? (
          <p className="text-sm text-muted-foreground">No AI calls yet.</p>
        ) : (
          <div className="relative overflow-x-auto rounded-md border">
            <Table className="text-[13px]">
              <TableHeader>
                <TableRow>
                  <TableHead>Provider · model</TableHead>
                  <TableHead>Purpose</TableHead>
                  <TableHead className="text-right">Calls</TableHead>
                  <TableHead className="text-right">Input tokens</TableHead>
                  <TableHead className="text-right">Output tokens</TableHead>
                  <TableHead className="text-right">Est. cost</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.summary.map((row) => (
                  <TableRow key={`${row.provider}-${row.model}-${row.purpose}`}>
                    <TableCell className="max-w-64 truncate">
                      {row.provider} · {row.model}
                    </TableCell>
                    <TableCell>{row.purpose.replaceAll("_", " ")}</TableCell>
                    <TableCell className="text-right">{formatInt(row.calls)}</TableCell>
                    <TableCell className="text-right">{formatInt(row.input_tokens)}</TableCell>
                    <TableCell className="text-right">{formatInt(row.output_tokens)}</TableCell>
                    <TableCell className="text-right">{formatUsd(row.estimated_cost_usd, 4)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export function SettingsPage() {
  const { data, isPending, isError, error } = useSettings()
  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-5 p-4 md:p-6">
      <PageHeader
        title="Settings"
        description="Preferences for this computer. Per-deal assumptions are set inside each deal."
        actions={
          <LinkButton href="/settings/ai" variant="outline">
            Connect AI
          </LinkButton>
        }
      />
      {isPending ? (
        <div className="flex flex-col gap-4" aria-hidden>
          <Skeleton className="h-36 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      ) : isError ? (
        <Alert variant="destructive">
          <AlertTitle>Settings could not be loaded</AlertTitle>
          <AlertDescription>{error.message}</AlertDescription>
        </Alert>
      ) : (
        <>
          <ProfileCard prefs={data.preferences} />
          <AICard prefs={data.preferences} disabledByEnv={data.env.disable_ai} />
          <DataCard folder={data.data_folder} keyStorage={data.key_storage} />
          <UsageCard />
        </>
      )}
    </div>
  )
}
