"use client"

import * as React from "react"
import {
  CircleAlertIcon,
  CircleCheckIcon,
  ExternalLinkIcon,
  EyeIcon,
  EyeOffIcon,
  InfoIcon,
  KeyRoundIcon,
  ShieldCheckIcon,
} from "lucide-react"

import { PageHeader } from "@/components/common/page-header"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { InputGroup, InputGroupAddon, InputGroupButton, InputGroupInput } from "@/components/ui/input-group"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import { Spinner } from "@/components/ui/spinner"
import { toast } from "@/components/ui/toast"
import { formatUsd } from "@/lib/format"
import { useAIMutations, useModels, useProviders } from "@/lib/queries"
import type { ConnectionResult, ProviderState } from "@/lib/types"
import { cn } from "@/lib/utils"

const SOURCE_LABEL = { keychain: "OS keychain", file: "local key file", env: ".env file", none: "" } as const

const KEY_PLACEHOLDER: Record<string, string> = {
  anthropic: "sk-ant-…",
  openai: "sk-…",
  gemini: "AIza…",
  xai: "xai-…",
  perplexity: "pplx-…",
  custom: "Optional: only if your endpoint needs one…",
}

const RESULT_HELP: Record<ConnectionResult["code"], string> = {
  ok: "",
  invalid_key: "Check that you copied the whole key from the provider's developer console, then save it again.",
  out_of_credit: "Add credit or a payment method in the provider's console, then test again.",
  model_unavailable: "Choose another model from the list; this one is retired or not enabled for your key.",
  rate_limited: "The provider is limiting requests. Wait a minute and test again.",
  unreachable: "Check your internet connection or company proxy, then test again.",
  error: "Read the message above; if it persists, try another model.",
}

function ProviderStatus({ state }: { state: ProviderState }) {
  if (!state.spec.implemented) return <Badge variant="outline">{state.spec.available_in}</Badge>
  if (state.connection?.is_active) {
    const failing = state.connection.last_test_code && state.connection.last_test_code !== "ok"
    return failing ? (
      <Badge variant="warning">
        <CircleAlertIcon aria-hidden />
        Test failed
      </Badge>
    ) : (
      <Badge variant="positive">
        <CircleCheckIcon aria-hidden />
        Active
      </Badge>
    )
  }
  if (state.key.present) return <Badge variant="secondary">Key saved</Badge>
  return null
}

function ProviderList({
  providers,
  selected,
  onSelect,
}: {
  providers: ProviderState[]
  selected: string
  onSelect: (id: string) => void
}) {
  return (
    <RadioGroup aria-label="AI provider" value={selected} onValueChange={(v) => onSelect(v as string)} className="gap-2">
      {providers.map((state) => (
        <label
          key={state.spec.id}
          htmlFor={`provider-${state.spec.id}`}
          className={cn(
            "flex cursor-pointer items-start gap-3 rounded-lg border p-3 transition-colors hover:bg-muted",
            selected === state.spec.id && "border-ring bg-muted",
          )}
        >
          <RadioGroupItem id={`provider-${state.spec.id}`} value={state.spec.id} className="mt-0.5" />
          <span className="flex min-w-0 flex-1 flex-col gap-0.5">
            <span className="flex flex-wrap items-center gap-2">
              <span className="text-sm font-medium">{state.spec.label}</span>
              {state.spec.id === "anthropic" ? <Badge variant="secondary">Recommended</Badge> : null}
              <ProviderStatus state={state} />
            </span>
            <span className="text-xs text-muted-foreground">{state.spec.tagline}</span>
          </span>
        </label>
      ))}
    </RadioGroup>
  )
}

function SubscriptionNote({ state }: { state: ProviderState }) {
  return (
    <Alert>
      <InfoIcon />
      <AlertTitle>A chat subscription is not an API key</AlertTitle>
      <AlertDescription>
        <p>
          Claude Pro/Max, ChatGPT Plus/Pro, Gemini in Google One, SuperGrok, Copilot Pro and Perplexity Pro only work in their
          own apps. DealScout needs an API key from the provider&apos;s developer console (or your company&apos;s Azure / Google
          Cloud setup), which is billed separately per use. DealScout never signs in to a chat subscription for you.
        </p>
        {state.spec.key_page_url ? (
          <p className="mt-2">
            <a
              href={state.spec.key_page_url}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex items-center gap-1 font-medium text-link underline-offset-2 hover:underline"
            >
              Get an API key from {state.spec.label}
              <ExternalLinkIcon aria-hidden className="size-3.5" />
              <span className="sr-only">(opens in a new tab)</span>
            </a>
          </p>
        ) : null}
      </AlertDescription>
    </Alert>
  )
}

function ModelField({
  state,
  value,
  onChange,
}: {
  state: ProviderState
  value: string
  onChange: (value: string) => void
}) {
  const canList = state.spec.implemented && !!state.connection && (state.key.present || !state.spec.key_required)
  const { data: models, isFetching, isError, error } = useModels(state.spec.id, canList)
  const items = models?.map((m) => ({ value: m.id, label: m.display_name })) ?? []
  return (
    <Field>
      <FieldLabel htmlFor="ai-model">Model</FieldLabel>
      {models && models.length ? (
        <Select items={items} value={value || null} onValueChange={(v) => onChange((v as string) ?? "")}>
          <SelectTrigger id="ai-model" className="w-full">
            <SelectValue placeholder="Choose a model" />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              {models.map((m) => (
                <SelectItem key={m.id} value={m.id}>
                  <span className="truncate" translate="no">{m.display_name}</span>
                  <span className="ml-auto flex items-center gap-2 pl-3 text-xs text-muted-foreground">
                    {m.recommended ? "Recommended" : null}
                    {m.input_price_per_mtok !== null && m.output_price_per_mtok !== null
                      ? `${formatUsd(m.input_price_per_mtok)} / ${formatUsd(m.output_price_per_mtok)} per M tokens`
                      : null}
                  </span>
                </SelectItem>
              ))}
            </SelectGroup>
          </SelectContent>
        </Select>
      ) : (
        <Input
          id="ai-model"
          value={value}
          spellCheck={false}
          autoComplete="off"
          onChange={(e) => onChange(e.target.value)}
          placeholder={state.spec.default_model ?? "Model name"}
        />
      )}
      <FieldDescription>
        {isFetching
          ? "Loading this provider's current model list…"
          : isError
            ? `Could not load the model list (${(error as Error).message}). Type a model name instead.`
            : canList
              ? "From the provider's current model list, with published prices."
              : state.spec.key_required
                ? "Save your key to load the provider's current model list."
                : "Save the endpoint to load its model list."}
      </FieldDescription>
    </Field>
  )
}

function ProviderPanel({ state, keyBackend }: { state: ProviderState; keyBackend: string }) {
  const { save, test, activate, removeKey } = useAIMutations()
  const [apiKey, setApiKey] = React.useState("")
  const [showKey, setShowKey] = React.useState(false)
  const [replacing, setReplacing] = React.useState(!state.key.present)
  const [model, setModel] = React.useState(state.connection?.model ?? state.env_model ?? state.spec.default_model ?? "")
  const [endpoint, setEndpoint] = React.useState(state.connection?.endpoint ?? "")
  const [deployment, setDeployment] = React.useState(state.connection?.deployment ?? "")
  const [result, setResult] = React.useState<ConnectionResult | null>(null)
  const [keyError, setKeyError] = React.useState<string | null>(null)
  const [endpointError, setEndpointError] = React.useState<string | null>(null)
  const [deploymentError, setDeploymentError] = React.useState<string | null>(null)
  const [baseUrl, setBaseUrl] = React.useState(state.connection?.base_url ?? "")
  const [baseUrlError, setBaseUrlError] = React.useState<string | null>(null)
  const needsBaseUrl = state.spec.fields.includes("base_url")
  const needsEndpoint = state.spec.fields.includes("endpoint")
  const needsModel = state.spec.fields.includes("model")
  const busy = save.isPending || test.isPending
  const disabled = !state.spec.implemented

  async function saveAndTest(event: React.FormEvent) {
    event.preventDefault()
    setResult(null)
    if (state.spec.key_required && !state.key.present && !apiKey.trim()) {
      setKeyError("Paste your API key from the provider's developer console.")
      return
    }
    setKeyError(null)
    if (needsBaseUrl) {
      const bad = !/^https?:\/\/[^\s/]+/.test(baseUrl.trim())
      setBaseUrlError(bad ? "Enter the endpoint's base URL, e.g. http://localhost:11434/v1" : null)
      if (bad) return
    }
    if (needsEndpoint) {
      const badEndpoint = !/^https:\/\/[^\s/]+/.test(endpoint.trim())
      setEndpointError(badEndpoint ? "Enter the resource endpoint, starting with https://" : null)
      setDeploymentError(deployment.trim() ? null : "Enter the deployment name your IT team gave you.")
      if (badEndpoint || !deployment.trim()) return
    }
    try {
      await save.mutateAsync({
        provider: state.spec.id,
        body: {
          api_key: apiKey.trim() || null,
          model: needsModel ? model.trim() || null : null,
          ...(needsEndpoint ? { endpoint: endpoint.trim(), deployment: deployment.trim() } : {}),
          ...(needsBaseUrl ? { base_url: baseUrl.trim() } : {}),
          activate: true,
        },
      })
      setApiKey("")
      setReplacing(false)
      const outcome = await test.mutateAsync(state.spec.id)
      setResult(outcome)
      if (outcome.ok) toast.add({ title: `${state.spec.label} connected`, description: outcome.model ?? undefined, type: "success" })
    } catch (error) {
      setResult({ ok: false, provider: state.spec.id, model, code: "error", message: (error as Error).message })
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex flex-wrap items-center gap-2">
          {state.spec.label}
          <ProviderStatus state={state} />
        </CardTitle>
        <CardDescription>{state.spec.tagline}</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        {disabled ? (
          <Alert>
            <InfoIcon />
            <AlertTitle>Support for {state.spec.label} arrives in {state.spec.available_in}</AlertTitle>
            <AlertDescription>Until then, connect another provider or continue without AI.</AlertDescription>
          </Alert>
        ) : null}
        {state.spec.notes.map((note) => (
          <p key={note} className="rounded-md border bg-muted px-3 py-2 text-sm">
            {note}
          </p>
        ))}
        <SubscriptionNote state={state} />

        <form onSubmit={saveAndTest} className="flex flex-col gap-5">
          <FieldGroup>
            <Field data-invalid={!!keyError || undefined} data-disabled={disabled || undefined}>
              <FieldLabel htmlFor="ai-key">API key</FieldLabel>
              {state.key.present && !replacing ? (
                <div className="flex flex-wrap items-center gap-2">
                  <span className="inline-flex items-center gap-2 rounded-md border bg-muted px-2.5 py-1.5 font-mono text-xs">
                    <KeyRoundIcon aria-hidden className="size-3.5" />
                    ••••{state.key.last4}
                  </span>
                  <span className="text-xs text-muted-foreground">Stored in your {SOURCE_LABEL[state.key.source]}</span>
                  <Button type="button" variant="outline" size="sm" onClick={() => setReplacing(true)}>
                    Replace key
                  </Button>
                  {state.key.source !== "env" ? (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="text-destructive"
                      onClick={async () => {
                        await removeKey.mutateAsync(state.spec.id)
                        setReplacing(true)
                        setResult(null)
                        toast.add({ title: "Key removed", description: `${state.spec.label} key deleted from this computer.` })
                      }}
                    >
                      Remove key
                    </Button>
                  ) : null}
                </div>
              ) : (
                <InputGroup>
                  <InputGroupInput
                    id="ai-key"
                    type={showKey ? "text" : "password"}
                    autoComplete="off"
                    spellCheck={false}
                    disabled={disabled}
                    placeholder={KEY_PLACEHOLDER[state.spec.id] ?? "Paste your API key…"}
                    value={apiKey}
                    aria-invalid={!!keyError || undefined}
                    onChange={(e) => setApiKey(e.target.value)}
                  />
                  <InputGroupAddon align="inline-end">
                    <InputGroupButton
                      size="icon-xs"
                      aria-label={showKey ? "Hide key" : "Show key"}
                      onClick={() => setShowKey((v) => !v)}
                      disabled={disabled}
                    >
                      {showKey ? <EyeOffIcon /> : <EyeIcon />}
                    </InputGroupButton>
                  </InputGroupAddon>
                </InputGroup>
              )}
              <FieldDescription>
                {keyBackend === "file"
                  ? "No OS keychain is available, so the key is saved in a file in DealScout's data folder that only your user account can read."
                  : "Saved in your operating system's keychain."}{" "}
                Never stored in the DealScout database, logs or exports, and never shown again in full.
              </FieldDescription>
              <FieldError>{keyError}</FieldError>
            </Field>
            {!disabled && needsBaseUrl ? (
              <Field data-invalid={!!baseUrlError || undefined}>
                <FieldLabel htmlFor="ai-base-url">Base URL</FieldLabel>
                <Input
                  id="ai-base-url"
                  name="base_url"
                  type="url"
                  inputMode="url"
                  spellCheck={false}
                  autoComplete="off"
                  placeholder="http://localhost:11434/v1…"
                  value={baseUrl}
                  aria-invalid={!!baseUrlError || undefined}
                  onChange={(e) => setBaseUrl(e.target.value)}
                />
                <FieldDescription>
                  Ollama: http://localhost:11434/v1 · LM Studio: http://localhost:1234/v1 · or your company AI gateway.
                </FieldDescription>
                <FieldError>{baseUrlError}</FieldError>
              </Field>
            ) : null}
            {!disabled && needsEndpoint ? (
              <>
                <Field data-invalid={!!endpointError || undefined}>
                  <FieldLabel htmlFor="ai-endpoint">Endpoint</FieldLabel>
                  <Input
                    id="ai-endpoint"
                    name="endpoint"
                    type="url"
                    inputMode="url"
                    spellCheck={false}
                    autoComplete="off"
                    placeholder="https://your-resource.openai.azure.com…"
                    value={endpoint}
                    aria-invalid={!!endpointError || undefined}
                    onChange={(e) => setEndpoint(e.target.value)}
                  />
                  <FieldDescription>In the Azure portal: open the resource, then Keys and Endpoint.</FieldDescription>
                  <FieldError>{endpointError}</FieldError>
                </Field>
                <Field data-invalid={!!deploymentError || undefined}>
                  <FieldLabel htmlFor="ai-deployment">Deployment name</FieldLabel>
                  <Input
                    id="ai-deployment"
                    name="deployment"
                    spellCheck={false}
                    autoComplete="off"
                    placeholder="e.g. gpt-6-1-sol…"
                    value={deployment}
                    aria-invalid={!!deploymentError || undefined}
                    onChange={(e) => setDeployment(e.target.value)}
                  />
                  <FieldDescription>The name your company gave the model deployment, not the model itself.</FieldDescription>
                  <FieldError>{deploymentError}</FieldError>
                </Field>
              </>
            ) : null}
            {!disabled && needsModel ? <ModelField state={state} value={model} onChange={setModel} /> : null}
          </FieldGroup>

          {result ? (
            result.ok ? (
              <Alert role="status">
                <CircleCheckIcon className="text-positive" />
                <AlertTitle>Connection works</AlertTitle>
                <AlertDescription>{result.message}</AlertDescription>
              </Alert>
            ) : (
              <Alert variant="destructive" role="alert">
                <CircleAlertIcon />
                <AlertTitle>Connection test failed</AlertTitle>
                <AlertDescription>
                  <p>{result.message}</p>
                  <p className="mt-1">{RESULT_HELP[result.code]}</p>
                </AlertDescription>
              </Alert>
            )
          ) : state.connection?.last_test_code && state.connection.last_test_code !== "ok" ? (
            <Alert variant="destructive">
              <CircleAlertIcon />
              <AlertTitle>The last test failed</AlertTitle>
              <AlertDescription>{state.connection.last_test_message}</AlertDescription>
            </Alert>
          ) : null}

          <div className="flex flex-wrap items-center gap-2">
            <Button type="submit" disabled={disabled || busy}>
              {busy ? <Spinner data-icon="inline-start" /> : null}
              {test.isPending ? "Testing…" : "Save and test connection"}
            </Button>
            {state.connection && !state.connection.is_active && !disabled ? (
              <Button
                type="button"
                variant="outline"
                onClick={() => activate.mutate(state.spec.id)}
                disabled={activate.isPending}
              >
                Use this provider
              </Button>
            ) : null}
          </div>
        </form>
      </CardContent>
      <CardFooter className="flex-col items-start gap-2 border-t text-xs text-muted-foreground">
        <p className="flex items-start gap-2">
          <ShieldCheckIcon aria-hidden className="mt-0.5 size-3.5 shrink-0" />
          <span>
            {state.spec.data_location_note}{" "}
            {state.spec.data_policy_url ? (
              <a
                href={state.spec.data_policy_url}
                target="_blank"
                rel="noreferrer noopener"
                className="font-medium text-link underline-offset-2 hover:underline"
              >
                Data-use policy<span className="sr-only"> (opens in a new tab)</span>
              </a>
            ) : null}
          </span>
        </p>
        <p>Tested extraction accuracy: {state.spec.accuracy_tier}. Every AI-extracted value is checked on the review screen.</p>
      </CardFooter>
    </Card>
  )
}

export function ConnectAIPage() {
  const { data, isPending, isError, error } = useProviders()
  const [selected, setSelected] = React.useState<string | null>(null)
  const current = selected ?? data?.status.provider ?? "anthropic"
  const state = data?.providers.find((p) => p.spec.id === current)

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-5 p-4 md:p-6">
      <PageHeader
        title="Connect AI"
        description="Bring your own AI. DealScout reads documents only with the provider and key you connect here, billed to your account. You can also continue without AI."
      />
      {data?.status && !data.status.enabled ? (
        <Alert>
          <InfoIcon />
          <AlertTitle>AI features are off</AlertTitle>
          <AlertDescription>{data.status.disabled_reason}</AlertDescription>
        </Alert>
      ) : null}
      {isPending ? (
        <div className="grid gap-4 lg:grid-cols-[22rem_minmax(0,1fr)]" aria-hidden>
          <Skeleton className="h-96" />
          <Skeleton className="h-96" />
        </div>
      ) : isError ? (
        <Alert variant="destructive">
          <AlertTitle>Providers could not be loaded</AlertTitle>
          <AlertDescription>{error.message}</AlertDescription>
        </Alert>
      ) : (
        <div className="grid items-start gap-4 lg:grid-cols-[22rem_minmax(0,1fr)]">
          <ProviderList providers={data.providers} selected={current} onSelect={setSelected} />
          {state ? <ProviderPanel key={state.spec.id} state={state} keyBackend={data.key_storage?.backend ?? "keychain"} /> : null}
        </div>
      )}
    </div>
  )
}
