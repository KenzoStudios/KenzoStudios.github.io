"use client"

import * as React from "react"
import { DownloadIcon, PlusIcon, SparklesIcon, Trash2Icon, UploadIcon } from "lucide-react"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Switch } from "@/components/ui/switch"
import { toast } from "@/components/ui/toast"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { ApiError } from "@/lib/api"
import { formatAccounting, formatMultiple, parseCellInput, SCALE_NAME } from "@/lib/format"
import { useAssumptions, usePeerSourcing, useSaveAssumptions } from "@/lib/queries"
import type { CompsBasis, Peer, PeerAdjustment, PeerCsvImport, PeerStats, PeerSuggestion, ValuationResponse } from "@/lib/types"

/** Which peers were converted or calendarised, with the rate or weights used (or why they were left out). */
function PeerBasis({ adjustment: a }: { adjustment?: PeerAdjustment }) {
  if (!a) return <span className="text-muted-foreground">Save to check</span>
  const parts: React.ReactNode[] = []
  if (a.missing_rate) {
    parts.push(
      <Badge key="fx" variant="warning" title={a.fx_note ?? undefined}>
        No {a.currency} rate: excluded
      </Badge>,
    )
  } else if (a.converted) {
    parts.push(<Badge key="fx" variant="outline" title={a.fx_note ?? undefined}>{a.currency} converted</Badge>)
  }
  if (a.calendarised && a.weights) {
    parts.push(
      <Badge key="cal" variant="outline" title={a.calendar_note ?? undefined}>
        Calendarised {a.weights[0].toFixed(2)} / {a.weights[1].toFixed(2)}
      </Badge>,
    )
  } else if (a.calendar_note) {
    parts.push(<span key="cal" className="text-muted-foreground">{a.calendar_note}</span>)
  }
  if (!parts.length) return <span className="text-muted-foreground">As entered</span>
  return <span className="flex flex-wrap gap-1">{parts}</span>
}

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

type FieldSpec = { key: keyof Peer; label: string; pct?: boolean }

// Column sets keep the grid narrow: every figure is kept in the draft whichever set is on screen.
const COLUMN_SETS: Record<"core" | "forward" | "calendar" | "sector", { label: string; fields: FieldSpec[] }> = {
  core: {
    label: "LTM",
    fields: [
      { key: "enterprise_value", label: "EV" },
      { key: "market_cap", label: "Market cap" },
      { key: "revenue", label: "Revenue" },
      { key: "ebitda", label: "EBITDA" },
      { key: "ebit", label: "EBIT" },
      { key: "net_income", label: "Net income" },
      { key: "revenue_growth", label: "Growth %", pct: true },
      { key: "ebitda_margin", label: "Margin %", pct: true },
    ],
  },
  forward: {
    label: "Forward",
    fields: [
      { key: "revenue_cy", label: "Revenue CY" },
      { key: "ebitda_cy", label: "EBITDA CY" },
      { key: "ebit_cy", label: "EBIT CY" },
      { key: "net_income_cy", label: "Net inc. CY" },
      { key: "revenue_ny", label: "Revenue NY" },
      { key: "ebitda_ny", label: "EBITDA NY" },
      { key: "ebit_ny", label: "EBIT NY" },
      { key: "net_income_ny", label: "Net inc. NY" },
      { key: "eps_growth", label: "EPS growth %", pct: true },
    ],
  },
  calendar: {
    // the peer's following fiscal year, used to calendarise a peer with a different year-end (brief §7)
    label: "Next FY",
    fields: [
      { key: "revenue_next", label: "Revenue next FY" },
      { key: "ebitda_next", label: "EBITDA next FY" },
      { key: "ebit_next", label: "EBIT next FY" },
      { key: "net_income_next", label: "Net inc. next FY" },
    ],
  },
  sector: {
    label: "Sector",
    fields: [
      { key: "rent_expense", label: "Rent / lease" },
      { key: "arr", label: "ARR" },
      { key: "nav", label: "NAV" },
      { key: "book_equity", label: "Book equity" },
      { key: "net_debt", label: "Net debt" },
    ],
  },
}
const ALL_FIELDS: FieldSpec[] = Object.values(COLUMN_SETS).flatMap((s) => s.fields)
type ColumnSet = keyof typeof COLUMN_SETS

const CORE_STATS = ["ev_revenue", "ev_ebitda", "ev_ebit", "pe"]
const EXTRA_STATS = ["ev_ebitdar", "peg", "ev_arr", "p_nav", "pb"]
const BASIS_LABEL: Record<CompsBasis, string> = { ltm: "LTM", cy: "Current year", ny: "Next year" }

/** One editable row: the text in each cell plus the stored peer, so fields this editor does not show survive a save. */
interface Row {
  base: Peer
  name: string
  ticker: string
  currency: string
  fyEnd: string
  include: boolean
  cells: Record<string, string>
}

function toRow(p: Peer, scale: number): Row {
  const cells: Record<string, string> = {}
  for (const f of ALL_FIELDS) {
    const v = p[f.key] as number | null | undefined
    cells[f.key] = v === null || v === undefined ? "" : f.pct ? String(+(v * 100).toFixed(3)) : String(+(v / scale).toFixed(4))
  }
  return {
    base: p,
    name: p.name,
    ticker: p.ticker ?? "",
    currency: p.currency ?? "",
    fyEnd: p.fiscal_year_end_month ? String(p.fiscal_year_end_month) : "",
    include: p.include !== false, cells }
}

export function PeersEditor({
  dealId,
  currency,
  scale,
  stats,
  statsByBasis,
  basis,
  excludeOutliers,
  adjustments = [],
}: {
  dealId: string
  currency: string
  scale: number
  stats: ValuationResponse["peer_stats"]
  statsByBasis?: Partial<Record<CompsBasis, PeerStats[]>>
  basis: CompsBasis
  excludeOutliers: boolean
  adjustments?: PeerAdjustment[]
}) {
  const adjustmentOf = new Map(adjustments.map((a) => [a.name, a]))
  const { data: doc } = useAssumptions(dealId)
  const save = useSaveAssumptions(dealId)
  const sourcing = usePeerSourcing(dealId)
  const [drafts, setDrafts] = React.useState<Row[] | null>(null)
  const [columns, setColumns] = React.useState<ColumnSet>("core")
  const [suggestions, setSuggestions] = React.useState<{ items: PeerSuggestion[]; source: string; note: string } | null>(null)
  const [csvResult, setCsvResult] = React.useState<PeerCsvImport | null>(null)
  const fileInput = React.useRef<HTMLInputElement>(null)
  const current = drafts ?? (doc?.peers ?? []).map((p) => toRow(p, scale))
  const dirty = drafts !== null
  const fields = COLUMN_SETS[columns].fields

  const setRow = (i: number, patch: Partial<Row>) => setDrafts(current.map((d, j) => (j === i ? { ...d, ...patch } : d)))
  const setCell = (i: number, key: string, value: string) => setRow(i, { cells: { ...current[i].cells, [key]: value } })
  const taken = new Set(current.flatMap((r) => [r.name.trim().toLowerCase(), r.ticker.trim().toLowerCase()]).filter(Boolean))

  const persist = async () => {
    const invalid: string[] = []
    const peers: Peer[] = current
      .filter((d) => d.name.trim())
      .map((d) => {
        const code = d.currency.trim().toUpperCase()
        if (code && !/^[A-Z]{3}$/.test(code)) invalid.push(`${d.name} currency`)
        const peer: Peer = {
          ...d.base,
          name: d.name.trim(),
          ticker: d.ticker.trim() || null,
          include: d.include,
          currency: code || null,
          fiscal_year_end_month: d.fyEnd ? Number(d.fyEnd) : null,
        }
        for (const f of ALL_FIELDS) {
          const parsed = parseCellInput(d.cells[f.key] ?? "")
          if (parsed === undefined) invalid.push(`${d.name} ${f.label}`)
          const value = parsed === null || parsed === undefined ? null : f.pct ? parsed / 100 : parsed * scale
          ;(peer as unknown as Record<string, unknown>)[f.key] = value
        }
        return peer
      })
    if (invalid.length) {
      toast.add({ title: "Some peer figures are not numbers", description: invalid.slice(0, 4).join(", "), type: "error" })
      return
    }
    await save.mutateAsync({ peers })
    setDrafts(null)
    toast.add({ title: "Peers saved", type: "success" })
  }

  const addSuggestion = (s: PeerSuggestion) => {
    const peer: Peer = { name: s.name, ticker: s.ticker, country: s.country, include: true }
    setDrafts([...current, toRow(peer, scale)])
  }

  const suggest = async () => {
    try {
      const result = await sourcing.suggest.mutateAsync()
      setSuggestions({ items: result.suggestions, source: result.source, note: result.note })
    } catch (error) {
      toast.add({ title: "Could not suggest peers", description: (error as ApiError).message, type: "error" })
    }
  }

  const importCsv = async (file: File) => {
    try {
      const result = await sourcing.importCsv.mutateAsync({ file, scale })
      setCsvResult(result)
      if (result.peers.length) setDrafts([...current, ...result.peers.map((p) => toRow(p, scale))])
      toast.add({
        title: `${result.peers.length} peer${result.peers.length === 1 ? "" : "s"} added from CSV`,
        description: result.errors.length ? `${result.errors.length} row(s) skipped. Review, then save the peers.` : "Review, then save the peers.",
        type: result.errors.length ? "warning" : "success",
      })
    } catch (error) {
      toast.add({ title: "CSV not imported", description: (error as ApiError).message, type: "error" })
    }
  }

  const basisStats = statsByBasis?.[basis] ?? stats
  const shown = basisStats.filter((s) => CORE_STATS.includes(s.multiple_id) || (EXTRA_STATS.includes(s.multiple_id) && s.n > 0))
  return (
    <section aria-labelledby="peers-title" className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 id="peers-title" className="text-sm font-semibold">Trading comparables</h2>
          <p className="text-xs text-muted-foreground">
            Amounts in {SCALE_NAME[scale]}, in {currency} unless you give the peer its own currency (then converted with the rate entered
            in the Currency section of the Data tab). A peer with a different fiscal year-end is calendarised to the target&apos;s year-end
            from its next fiscal year figures. CY and NY are the current and next financial year; rent is entered as a positive cost.
          </p>
        </div>
        <label htmlFor="exclude-outliers" className="flex items-center gap-2 text-sm">
          <Switch
            id="exclude-outliers"
            checked={excludeOutliers}
            onCheckedChange={(checked) => save.mutate({ overrides: { ...(doc?.overrides ?? {}), exclude_peer_outliers: checked } })}
          />
          Exclude outliers (1.5×IQR)
        </label>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <span id="peer-columns-label" className="text-xs text-muted-foreground">Columns</span>
        <ToggleGroup
          variant="outline"
          size="sm"
          aria-labelledby="peer-columns-label"
          value={[columns]}
          onValueChange={(v: string[]) => v[0] && setColumns(v[0] as ColumnSet)}
        >
          {(Object.keys(COLUMN_SETS) as ColumnSet[]).map((k) => (
            <ToggleGroupItem key={k} value={k}>{COLUMN_SETS[k].label}</ToggleGroupItem>
          ))}
        </ToggleGroup>
      </div>

      <div className="relative overflow-x-auto rounded-lg border">
        <table className="w-full text-[13px]">
          <thead className="bg-muted text-xs text-muted-foreground">
            <tr>
              <th className="w-8 px-2 py-2"><span className="sr-only">Include</span></th>
              <th className="min-w-44 px-2 py-2 text-left">Company</th>
              <th className="min-w-20 px-2 py-2 text-left">Ticker</th>
              <th className="min-w-16 px-2 py-2 text-left">Currency</th>
              <th className="min-w-20 px-2 py-2 text-left">FY ends</th>
              {fields.map((f) => (
                <th key={f.key} className="min-w-24 px-2 py-2 text-right">{f.label}</th>
              ))}
              <th className="min-w-40 px-2 py-2 text-left">Basis</th>
              <th className="w-10"><span className="sr-only">Remove</span></th>
            </tr>
          </thead>
          <tbody>
            {current.map((d, i) => (
              <tr key={i} className="border-t">
                <td className="px-2 py-1">
                  <Checkbox aria-label={`Include ${d.name || "peer"}`} checked={d.include} onCheckedChange={(c) => setRow(i, { include: !!c })} />
                </td>
                <td className="px-1 py-1">
                  <input aria-label="Peer name" value={d.name} onChange={(e) => setRow(i, { name: e.target.value })}
                    className="h-7 w-full rounded-md border border-transparent bg-transparent px-2 hover:border-input focus:border-ring focus:outline-none" />
                </td>
                <td className="px-1 py-1">
                  <input aria-label={`${d.name} ticker`} value={d.ticker} onChange={(e) => setRow(i, { ticker: e.target.value })}
                    className="h-7 w-full rounded-md border border-transparent bg-transparent px-2 uppercase hover:border-input focus:border-ring focus:outline-none" />
                </td>
                <td className="px-1 py-1">
                  <input aria-label={`${d.name} currency`} value={d.currency} maxLength={3} placeholder={currency} spellCheck={false}
                    onChange={(e) => setRow(i, { currency: e.target.value.toUpperCase() })}
                    className="h-7 w-16 rounded-md border border-transparent bg-transparent px-2 font-mono hover:border-input focus:border-ring focus:outline-none" />
                </td>
                <td className="px-1 py-1">
                  <select aria-label={`${d.name} fiscal year-end month`} value={d.fyEnd}
                    onChange={(e) => setRow(i, { fyEnd: e.target.value })}
                    className="h-7 rounded-md border border-transparent bg-transparent px-1 hover:border-input focus:border-ring focus:outline-none">
                    <option value="">Same as target</option>
                    {MONTHS.map((m, k) => <option key={m} value={String(k + 1)}>{m}</option>)}
                  </select>
                </td>
                {fields.map((f) => (
                  <td key={f.key} className="px-1 py-1">
                    <input aria-label={`${d.name} ${f.label}`} inputMode="decimal" value={d.cells[f.key] ?? ""} onChange={(e) => setCell(i, f.key, e.target.value)}
                      className="h-7 w-full rounded-md border border-transparent bg-transparent px-2 text-right tabular-nums hover:border-input focus:border-ring focus:outline-none" />
                  </td>
                ))}
                <td className="px-2 py-1 text-xs">
                  <PeerBasis adjustment={adjustmentOf.get(d.name.trim())} />
                </td>
                <td className="px-1">
                  <Button variant="ghost" size="icon-xs" aria-label={`Remove ${d.name || "peer"}`} onClick={() => setDrafts(current.filter((_, j) => j !== i))}>
                    <Trash2Icon />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button variant="outline" size="sm" onClick={() => setDrafts([...current, toRow({ name: "", include: true }, scale)])}>
          <PlusIcon data-icon="inline-start" />
          Add peer
        </Button>
        <Button variant="outline" size="sm" disabled={sourcing.suggest.isPending} onClick={() => void suggest()}>
          <SparklesIcon data-icon="inline-start" />
          {sourcing.suggest.isPending ? "Asking AI…" : "Suggest peers with AI"}
        </Button>
        <Button variant="outline" size="sm" disabled={sourcing.importCsv.isPending} onClick={() => fileInput.current?.click()}>
          <UploadIcon data-icon="inline-start" />
          {sourcing.importCsv.isPending ? "Importing…" : "Import peers from CSV"}
        </Button>
        <input
          ref={fileInput}
          type="file"
          accept=".csv,text/csv"
          className="sr-only"
          tabIndex={-1}
          aria-label="Peer CSV file"
          onChange={(e) => {
            const file = e.target.files?.[0]
            e.target.value = ""
            if (file) void importCsv(file)
          }}
        />
        <Button variant="ghost" size="sm" nativeButton={false} render={<a href="/api/market-data/peers-template.csv" download />}>
          <DownloadIcon data-icon="inline-start" />
          CSV template
        </Button>
        <Button size="sm" disabled={!dirty || save.isPending} onClick={() => void persist()}>Save peers</Button>
        {dirty ? <Button variant="ghost" size="sm" onClick={() => setDrafts(null)}>Discard changes</Button> : null}
      </div>

      {csvResult && (csvResult.errors.length || csvResult.warnings.length) ? (
        <Alert>
          <AlertTitle>CSV import: {csvResult.peers.length} added, {csvResult.errors.length} skipped</AlertTitle>
          <AlertDescription>
            <ul className="flex flex-col gap-0.5 text-xs">
              {csvResult.errors.slice(0, 12).map((e) => (
                <li key={e.row}>Row {e.row}{e.name ? ` (${e.name})` : ""}: {e.errors.join(" ")}</li>
              ))}
              {csvResult.warnings.map((w) => <li key={w}>{w}</li>)}
            </ul>
            <Button variant="link" size="xs" className="px-0" onClick={() => setCsvResult(null)}>Dismiss</Button>
          </AlertDescription>
        </Alert>
      ) : null}

      {suggestions ? (
        <div className="flex flex-col gap-2 rounded-lg border border-dashed p-3" aria-labelledby="peer-suggestions-title">
          <div className="flex flex-wrap items-center gap-2">
            <h3 id="peer-suggestions-title" className="text-sm font-semibold">Suggested peers</h3>
            <Badge variant="outline">AI suggestions to verify</Badge>
            <span className="text-xs text-muted-foreground">{suggestions.source}</span>
            <Button variant="ghost" size="xs" className="ml-auto" onClick={() => setSuggestions(null)}>Hide</Button>
          </div>
          <p className="text-xs text-muted-foreground">{suggestions.note} Added peers start with blank figures.</p>
          {suggestions.items.length ? (
            <ul className="flex flex-col divide-y">
              {suggestions.items.map((s) => {
                const added = taken.has(s.name.toLowerCase()) || (!!s.ticker && taken.has(s.ticker.toLowerCase()))
                return (
                  <li key={s.name} className="flex flex-wrap items-center gap-x-3 gap-y-1 py-1.5">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium">
                        {s.name}
                        <span className="ml-2 text-xs font-normal text-muted-foreground">
                          {[s.ticker, s.exchange, s.country].filter(Boolean).join(" · ") || "Ticker not given"}
                        </span>
                      </p>
                      {s.reason ? <p className="text-xs text-muted-foreground">{s.reason}</p> : null}
                    </div>
                    <Button variant="outline" size="xs" disabled={added} onClick={() => addSuggestion(s)} aria-label={`Add ${s.name} as a peer`}>
                      {added ? "Added" : <><PlusIcon data-icon="inline-start" />Add</>}
                    </Button>
                  </li>
                )
              })}
            </ul>
          ) : (
            <p className="text-xs text-muted-foreground">No new peers were suggested.</p>
          )}
        </div>
      ) : null}

      <div className="flex flex-wrap items-center gap-2">
        <span id="comps-basis-label" className="text-xs text-muted-foreground">Multiples basis</span>
        <ToggleGroup
          variant="outline"
          size="sm"
          aria-labelledby="comps-basis-label"
          value={[basis]}
          onValueChange={(v: string[]) => v[0] && v[0] !== basis && save.mutate({ overrides: { ...(doc?.overrides ?? {}), comps_basis: v[0] } })}
        >
          {(Object.keys(BASIS_LABEL) as CompsBasis[]).map((b) => (
            <ToggleGroupItem key={b} value={b}>{BASIS_LABEL[b]}</ToggleGroupItem>
          ))}
        </ToggleGroup>
        <TargetEpsGrowth
          key={String(doc?.overrides?.target_eps_growth ?? "")}
          value={typeof doc?.overrides?.target_eps_growth === "number" ? doc.overrides.target_eps_growth : null}
          onSave={(g) => save.mutate({ overrides: { ...(doc?.overrides ?? {}), target_eps_growth: g } })}
        />
        {basis !== "ltm" ? (
          <span className="text-xs text-muted-foreground">
            Target figures come from the DCF projection. P / B, EV / ARR and P / NAV are the same on every basis; EV / EBITDAR is LTM only.
          </span>
        ) : null}
      </div>
      {shown.some((s) => s.n) ? (
        <div className="relative overflow-x-auto rounded-lg border">
          <table className="w-full text-[13px] tabular-nums">
            <caption className="sr-only">Peer multiple statistics, {BASIS_LABEL[basis]} basis</caption>
            <thead className="bg-muted text-xs text-muted-foreground">
              <tr>
                {["Multiple", "n", "Min", "25th pct", "Median", "Mean", "75th pct", "Max"].map((h, i) => (
                  <th key={h} className={i ? "px-2 py-2 text-right" : "px-2 py-2 text-left"}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {shown.map((s) => (
                <tr key={s.multiple_id} className="border-t">
                  <th scope="row" className="px-2 py-1 text-left font-normal" title={Object.entries(s.excluded).map(([k, v]) => `${k}: ${v}`).join("\n")}>
                    {s.label}
                    {Object.keys(s.excluded).length ? <span className="ml-1 text-xs text-muted-foreground">({Object.keys(s.excluded).length} excluded)</span> : null}
                  </th>
                  <td className="px-2 py-1 text-right">{formatAccounting(s.n, 0)}</td>
                  {[s.min, s.p25, s.median, s.mean, s.p75, s.max].map((v, i) => (
                    <td key={i} className={i === 2 ? "px-2 py-1 text-right font-semibold" : "px-2 py-1 text-right"}>
                      {formatMultiple(v, s.multiple_id === "peg" || s.multiple_id === "p_nav" || s.multiple_id === "pb" ? 2 : 1)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">No meaningful peer multiples on the {BASIS_LABEL[basis].toLowerCase()} basis yet.</p>
      )}
    </section>
  )
}

/** The target's expected EPS growth, used only to apply the peer PEG (no default: the analyst enters it). */
function TargetEpsGrowth({ value, onSave }: { value: number | null; onSave: (growth: number | null) => void }) {
  const [text, setText] = React.useState(value === null ? "" : String(+(value * 100).toFixed(2)))
  const commit = () => {
    const parsed = parseCellInput(text)
    if (parsed === undefined) {
      toast.add({ title: "Target EPS growth is not a number", type: "error" })
      return
    }
    const next = parsed === null ? null : parsed / 100
    if (next !== value) onSave(next)
  }
  return (
    <label className="flex items-center gap-2 text-xs text-muted-foreground">
      Target EPS growth % (for PEG)
      <input
        inputMode="decimal"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => e.key === "Enter" && commit()}
        className="h-7 w-16 rounded-md border border-input bg-transparent px-2 text-right text-[13px] tabular-nums text-foreground focus:border-ring focus:outline-none"
      />
    </label>
  )
}
