"use client"

import * as React from "react"
import { CircleCheckIcon, PlusIcon, Trash2Icon, TriangleAlertIcon } from "lucide-react"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/toast"
import { parseCellInput } from "@/lib/format"
import { useSaveMethodSection } from "@/lib/queries"
import type { ScenarioDef } from "@/lib/types"

const MAX = 6

type Field = "probability" | "growth_shift" | "margin_shift" | "wacc_shift" | "terminal_growth_shift" | "exit_multiple_shift"

const COLUMNS: { field: Field; label: string; unit: string; hint: string }[] = [
  { field: "probability", label: "Probability", unit: "%", hint: "Probability in percent" },
  { field: "growth_shift", label: "Growth", unit: "pp", hint: "Revenue growth shift in percentage points, every year" },
  { field: "margin_shift", label: "Margin", unit: "pp", hint: "EBITDA margin shift in percentage points, every year" },
  { field: "wacc_shift", label: "WACC", unit: "pp", hint: "WACC shift in percentage points" },
  { field: "exit_multiple_shift", label: "Exit multiple", unit: "x", hint: "Exit EV/EBITDA shift in turns" },
  { field: "terminal_growth_shift", label: "Terminal g", unit: "pp", hint: "Terminal growth shift in percentage points" },
]

const DEFAULT_SCENARIOS: ScenarioDef[] = [
  { name: "bear", probability: 0.25, growth_shift: -0.02, margin_shift: -0.02, wacc_shift: 0, exit_multiple_shift: 0, terminal_growth_shift: 0 },
  { name: "base", probability: 0.5, growth_shift: 0, margin_shift: 0, wacc_shift: 0, exit_multiple_shift: 0, terminal_growth_shift: 0 },
  { name: "bull", probability: 0.25, growth_shift: 0.02, margin_shift: 0.02, wacc_shift: 0, exit_multiple_shift: 0, terminal_growth_shift: 0 },
]

interface Row {
  name: string
  values: Record<Field, string>
}

const isMultiple = (f: Field) => f === "exit_multiple_shift"

function toText(f: Field, v: number): string {
  return isMultiple(f) ? String(+v.toFixed(4)) : String(+(v * 100).toFixed(4))
}

function toRows(scenarios: ScenarioDef[]): Row[] {
  return scenarios.map((s) => ({
    name: s.name,
    values: Object.fromEntries(COLUMNS.map((c) => [c.field, toText(c.field, s[c.field] ?? 0)])) as Record<Field, string>,
  }))
}

/** Text typed in a cell to a decimal (percent and percentage points ÷ 100; the multiple shift stays in turns). */
function parse(f: Field, text: string): number | undefined {
  const clean = text.trim().replace(/(pp|%|x)$/i, "").trim()
  if (clean === "") return 0
  const n = parseCellInput(clean)
  if (n === undefined || n === null) return undefined
  return isMultiple(f) ? n : n / 100
}

export function ScenarioEditor({
  dealId,
  scenarios,
  serverError,
}: {
  dealId: string
  scenarios: ScenarioDef[]
  serverError?: string | null
}) {
  const save = useSaveMethodSection(dealId)
  const saved = React.useMemo(() => toRows(scenarios), [scenarios])
  const [rows, setRows] = React.useState<Row[]>(saved)
  const [error, setError] = React.useState<string | null>(null)
  const [lastSaved, setLastSaved] = React.useState(saved)
  if (lastSaved !== saved) {
    // the stored scenarios changed (saved here, restored from a version …): show them
    setLastSaved(saved)
    setRows(saved)
  }
  const dirty = JSON.stringify(rows) !== JSON.stringify(saved)

  React.useEffect(() => {
    if (!dirty) return
    const warn = (e: BeforeUnloadEvent) => e.preventDefault()
    window.addEventListener("beforeunload", warn)
    return () => window.removeEventListener("beforeunload", warn)
  }, [dirty])

  const parsed = rows.map((r) => COLUMNS.map((c) => parse(c.field, r.values[c.field])))
  const total = parsed.reduce((sum, p) => sum + (p[0] ?? 0), 0)
  const sumOk = Math.abs(total - 1) < 1e-4
  const invalidCell = parsed.some((p) => p.some((x) => x === undefined))
  const names = rows.map((r) => r.name.trim().toLowerCase())
  const nameProblem = names.some((n) => !n)
    ? "Give every scenario a name."
    : names.some((n, i) => names.indexOf(n) !== i)
      ? "Give each scenario its own name."
      : null

  const update = (i: number, change: Partial<Row> | { field: Field; text: string }) => {
    setError(null)
    setRows((prev) =>
      prev.map((r, j) =>
        j !== i ? r : "field" in change ? { ...r, values: { ...r.values, [change.field]: change.text } } : { ...r, ...change },
      ),
    )
  }

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    if (invalidCell) return setError("Some cells are not numbers.")
    if (nameProblem) return setError(nameProblem)
    if (!sumOk) return setError(`Probabilities must add up to 100% (they add up to ${(total * 100).toFixed(1)}%).`)
    const value: ScenarioDef[] = rows.map((r, i) => ({
      name: r.name.trim(),
      ...(Object.fromEntries(COLUMNS.map((c, k) => [c.field, parsed[i][k] as number])) as Record<Field, number>),
    }))
    try {
      await save.mutateAsync({ section: "scenarios", value })
      toast.add({ title: "Scenarios saved", description: "The DCF scenarios were run again.", type: "success" })
    } catch (e) {
      setError((e as Error).message)
    }
  }

  return (
    <section aria-labelledby="scenario-editor-title" className="flex flex-col gap-2">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 id="scenario-editor-title" className="text-sm font-semibold">Scenarios</h3>
        <p className="text-xs text-muted-foreground">Shifts to the base case; growth and margin shift every projection year.</p>
      </div>
      {serverError ? (
        <Alert variant="destructive">
          <TriangleAlertIcon />
          <AlertTitle>The scenarios could not be run</AlertTitle>
          <AlertDescription>{serverError}</AlertDescription>
        </Alert>
      ) : null}
      <form onSubmit={submit} className="flex flex-col gap-2" noValidate>
        <div className="relative overflow-x-auto rounded-lg border">
          <table className="w-full text-[13px] tabular-nums">
            <thead className="bg-muted text-xs text-muted-foreground">
              <tr>
                <th scope="col" className="px-2 py-1.5 text-left font-medium">Name</th>
                {COLUMNS.map((c) => (
                  <th key={c.field} scope="col" className="px-1 py-1.5 text-right font-medium whitespace-nowrap" title={c.hint}>
                    {c.label} <span className="font-normal">({c.unit})</span>
                  </th>
                ))}
                <th scope="col" className="w-8"><span className="sr-only">Remove</span></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className="border-t">
                  <td className="px-1 py-1">
                    <Input
                      value={r.name}
                      maxLength={40}
                      aria-label={`Scenario ${i + 1} name`}
                      aria-invalid={!r.name.trim() || undefined}
                      className="h-7 min-w-24 px-1.5 text-[13px]"
                      onChange={(e) => update(i, { name: e.target.value })}
                    />
                  </td>
                  {COLUMNS.map((c, k) => (
                    <td key={c.field} className="px-1 py-1">
                      <Input
                        value={r.values[c.field]}
                        inputMode="decimal"
                        aria-label={`${r.name || `Scenario ${i + 1}`}: ${c.hint}`}
                        aria-invalid={parsed[i][k] === undefined || undefined}
                        className="h-7 w-16 px-1.5 text-right text-[13px] tabular-nums"
                        onChange={(e) => update(i, { field: c.field, text: e.target.value })}
                      />
                    </td>
                  ))}
                  <td className="px-1 py-1">
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon-xs"
                      aria-label={`Remove ${r.name || `scenario ${i + 1}`}`}
                      disabled={rows.length <= 1}
                      onClick={() => setRows((prev) => prev.filter((_, j) => j !== i))}
                    >
                      <Trash2Icon />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="flex items-center gap-1.5 text-xs" aria-live="polite">
            {sumOk ? (
              <>
                <CircleCheckIcon aria-hidden className="size-3.5 text-positive" />
                Probabilities add up to 100%
              </>
            ) : (
              <>
                <TriangleAlertIcon aria-hidden className="size-3.5 text-warning" />
                Probabilities add up to {(total * 100).toFixed(1)}%; they must add up to 100%
              </>
            )}
          </p>
          <div className="flex flex-wrap gap-1">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              disabled={rows.length >= MAX}
              title={rows.length >= MAX ? `Up to ${MAX} scenarios` : undefined}
              onClick={() =>
                setRows((prev) => [
                  ...prev,
                  { name: `Scenario ${prev.length + 1}`, values: toRows([{ ...DEFAULT_SCENARIOS[1], probability: 0 }])[0].values },
                ])
              }
            >
              <PlusIcon data-icon="inline-start" />
              Add scenario
            </Button>
            <Button type="button" variant="ghost" size="sm" onClick={() => setRows(toRows(DEFAULT_SCENARIOS))}>
              Use bear, base, bull
            </Button>
            {dirty ? (
              <Button type="button" variant="outline" size="sm" onClick={() => setRows(saved)}>
                Discard changes
              </Button>
            ) : null}
            <Button type="submit" size="sm" disabled={!dirty || save.isPending}>
              Save and run
            </Button>
          </div>
        </div>
        {error ? (
          <p role="alert" className="text-xs text-destructive">
            {error}
          </p>
        ) : dirty ? (
          <p className="text-xs text-muted-foreground">Unsaved changes.</p>
        ) : null}
      </form>
    </section>
  )
}
