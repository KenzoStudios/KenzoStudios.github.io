"use client"

import * as React from "react"
import { MessageSquareIcon, Redo2Icon, RotateCcwIcon, TriangleAlertIcon, Undo2Icon } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/toast"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import { formatAccounting, formatMoneyCompact, formatMultiple, formatPct, parseCellInput } from "@/lib/format"
import { useAssumptions, useSaveAssumptions } from "@/lib/queries"
import type { DealMode, ResolvedAssumption } from "@/lib/types"

type Kind = "pct" | "number" | "multiple" | "years"

const EDITABLE: Record<string, Kind> = {
  revenue_growth: "pct", ebitda_margin: "pct", da_pct_revenue: "pct", capex_pct_revenue: "pct", nwc_pct_revenue: "pct",
  tax_rate: "pct", risk_free_rate: "pct", equity_risk_premium: "pct", country_risk_premium: "pct", size_premium: "pct",
  company_specific_premium: "pct", pre_tax_cost_of_debt: "pct", target_debt_to_capital: "pct", terminal_growth: "pct",
  unlevered_beta: "number", levered_beta: "number", exit_multiple: "multiple", projection_years: "years",
}

const SECTIONS: { title: string; keys: string[] }[] = [
  { title: "Operating drivers", keys: ["base_revenue", "projection_years", "revenue_growth", "ebitda_margin", "da_pct_revenue", "capex_pct_revenue", "nwc_pct_revenue", "tax_rate"] },
  { title: "Discount rate", keys: ["risk_free_rate", "equity_risk_premium", "country_risk_premium", "unlevered_beta", "levered_beta", "size_premium", "company_specific_premium", "pre_tax_cost_of_debt", "target_debt_to_capital", "wacc"] },
  { title: "Terminal value", keys: ["terminal_growth", "exit_multiple", "terminal_method"] },
]

/** Drivers that Detailed mode sets year by year (a list override); Quick mode keeps one value or a fade. */
const PER_YEAR = ["revenue_growth", "ebitda_margin", "da_pct_revenue", "capex_pct_revenue", "nwc_pct_revenue"]
/** Rows Quick mode tucks away unless they are set, missing or the analyst asks for every assumption. */
const ADVANCED = ["levered_beta", "size_premium", "company_specific_premium", "target_debt_to_capital"]

const SOURCE: Record<ResolvedAssumption["source"], { label: string; variant: "secondary" | "outline" | "negative" | "warning" }> = {
  user: { label: "You", variant: "secondary" },
  historical: { label: "History", variant: "outline" },
  default: { label: "Default", variant: "outline" },
  convention: { label: "Convention", variant: "outline" },
  derived: { label: "Derived", variant: "outline" },
  missing: { label: "Missing", variant: "negative" },
}

function show(a: ResolvedAssumption, currency: string): string {
  const fmtOne = (v: number) => {
    const kind = EDITABLE[a.key]
    if (a.key === "wacc" || kind === "pct") return formatPct(v)
    if (kind === "multiple") return formatMultiple(v)
    if (kind === "years") return `${v} years`
    if (a.key === "base_revenue") return formatMoneyCompact(v, currency)
    return formatAccounting(v, 2)
  }
  if (a.value === null) return a.source === "missing" ? "—" : ""
  if (Array.isArray(a.value)) {
    const first = a.value[0]
    const last = a.value[a.value.length - 1]
    return Math.abs(first - last) < 1e-9 ? fmtOne(first) : `${fmtOne(first)} → ${fmtOne(last)}`
  }
  return fmtOne(a.value)
}

function toEditText(a: ResolvedAssumption): string {
  const v = Array.isArray(a.value) ? a.value[0] : a.value
  if (v === null || v === undefined) return ""
  return EDITABLE[a.key] === "pct" ? String(+(v * 100).toFixed(4)) : String(+v.toFixed(4))
}

function AssumptionRow({
  a,
  currency,
  overridden,
  note,
  onSet,
  onReset,
  onNote,
}: {
  a: ResolvedAssumption
  currency: string
  overridden: boolean
  note?: string
  onSet: (key: string, value: number) => void
  onReset: (key: string) => void
  onNote: (key: string, note: string) => void
}) {
  const kind = EDITABLE[a.key]
  const [editing, setEditing] = React.useState(false)
  const [text, setText] = React.useState("")
  const [error, setError] = React.useState(false)
  const [draftNote, setDraftNote] = React.useState(note ?? "")
  const source = SOURCE[a.source]
  const commit = () => {
    const parsed = parseCellInput(text)
    if (parsed === undefined || parsed === null) {
      setError(true)
      return
    }
    const value = kind === "pct" ? parsed / 100 : kind === "years" ? Math.round(parsed) : parsed
    if (kind === "years" && (value < 3 || value > 15)) {
      setError(true)
      return
    }
    onSet(a.key, value)
    setEditing(false)
  }
  return (
    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-x-3 gap-y-0.5 border-t px-3 py-2 first:border-t-0">
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-sm">{a.label}</span>
          <Badge variant={source.variant} className="h-5 text-[11px]">{source.label}</Badge>
          {a.stale ? (
            <Badge variant="warning" className="h-5 text-[11px]">
              <TriangleAlertIcon aria-hidden />
              Older than 90 days
            </Badge>
          ) : null}
        </div>
        {a.detail ? (
          <p className="text-xs text-muted-foreground">
            {a.detail}
            {a.as_of ? ` · as of ${a.as_of}` : ""}
          </p>
        ) : null}
        {note ? <p className="mt-0.5 text-xs italic">Note: {note}</p> : null}
      </div>
      <div className="flex items-center gap-1">
        {editing && kind ? (
          <form
            className="flex items-center gap-1"
            onSubmit={(e) => {
              e.preventDefault()
              commit()
            }}
          >
            <Input
              autoFocus
              value={text}
              inputMode="decimal"
              aria-label={`${a.label}${kind === "pct" ? " in percent" : ""}`}
              aria-invalid={error || undefined}
              className="h-7 w-24 text-right tabular-nums"
              onChange={(e) => {
                setText(e.target.value)
                setError(false)
              }}
              onKeyDown={(e) => e.key === "Escape" && setEditing(false)}
            />
            <span className="w-4 text-xs text-muted-foreground">{kind === "pct" ? "%" : kind === "multiple" ? "x" : ""}</span>
            <Button type="submit" size="sm">Set</Button>
          </form>
        ) : (
          <button
            type="button"
            disabled={!kind}
            onClick={() => {
              setText(toEditText(a))
              setEditing(true)
            }}
            className="min-w-24 rounded-sm px-2 py-0.5 text-right text-sm font-medium tabular-nums enabled:hover:bg-muted focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none disabled:cursor-default"
            aria-label={(() => {
              const shown = a.value === null || a.value === undefined ? "not set" : show(a, currency) || "not set"
              return kind ? `${a.label}: ${shown}. Edit` : `${a.label}: ${shown}`
            })()}
          >
            {show(a, currency) || <span className="text-negative">Enter</span>}
          </button>
        )}
        {overridden ? (
          <Tooltip>
            <TooltipTrigger render={<Button variant="ghost" size="icon-xs" aria-label={`Reset ${a.label} to the default`} onClick={() => onReset(a.key)} />}>
              <RotateCcwIcon />
            </TooltipTrigger>
            <TooltipContent>Reset to history / default</TooltipContent>
          </Tooltip>
        ) : null}
        <Popover>
          <PopoverTrigger render={<Button variant="ghost" size="icon-xs" aria-label={`Note on ${a.label}`} />}>
            <MessageSquareIcon className={note ? "text-link" : undefined} />
          </PopoverTrigger>
          <PopoverContent className="w-72">
            <form
              className="flex flex-col gap-2"
              onSubmit={(e) => {
                e.preventDefault()
                onNote(a.key, draftNote)
              }}
            >
              <label htmlFor={`note-${a.key}`} className="text-sm font-medium">Note on {a.label.toLowerCase()}</label>
              <Textarea id={`note-${a.key}`} rows={3} value={draftNote} onChange={(e) => setDraftNote(e.target.value)} />
              <Button type="submit" size="sm">Save note</Button>
            </form>
          </PopoverContent>
        </Popover>
      </div>
    </div>
  )
}

function perYearValues(a: ResolvedAssumption, years: number): (number | null)[] {
  const v = a.value
  if (v === null || v === undefined) return Array.from({ length: years }, () => null)
  const list = Array.isArray(v) ? v : [v]
  return Array.from({ length: years }, (_, t) => list[Math.min(t, list.length - 1)] ?? null)
}

function PerYearRow({
  a,
  labels,
  overridden,
  onSet,
  onReset,
}: {
  a: ResolvedAssumption
  labels: string[]
  overridden: boolean
  onSet: (key: string, value: number[]) => void
  onReset: (key: string) => void
}) {
  const values = perYearValues(a, labels.length)
  // the parent keys this row by its values, so a saved change remounts it with fresh text
  const initial = values.map((v) => (v === null ? "" : String(+(v * 100).toFixed(2))))
  const [texts, setTexts] = React.useState(initial)
  const [errors, setErrors] = React.useState<boolean[]>([])
  const dirty = texts.some((t, i) => t !== initial[i])
  const source = SOURCE[a.source]
  const commit = () => {
    const parsed = texts.map((t) => parseCellInput(t))
    const bad = parsed.map((x) => x === undefined || x === null)
    if (bad.some(Boolean)) {
      setErrors(bad)
      return
    }
    onSet(a.key, parsed.map((x) => (x as number) / 100))
  }
  return (
    <div className="flex flex-col gap-1.5 border-t px-3 py-2 first:border-t-0">
      <div className="flex flex-wrap items-center justify-between gap-1.5">
        <span className="flex flex-wrap items-center gap-1.5">
          <span id={`py-${a.key}`} className="text-sm">{a.label.replace(/ by year$/, "")} by year</span>
          <Badge variant={source.variant} className="h-5 text-[11px]">{source.label}</Badge>
        </span>
        {overridden ? (
          <Tooltip>
            <TooltipTrigger render={<Button variant="ghost" size="icon-xs" aria-label={`Reset ${a.label} to the default`} onClick={() => onReset(a.key)} />}>
              <RotateCcwIcon />
            </TooltipTrigger>
            <TooltipContent>Reset to history / default</TooltipContent>
          </Tooltip>
        ) : null}
      </div>
      {a.detail ? <p className="text-xs text-muted-foreground">{a.detail}</p> : null}
      <form
        className="flex flex-col gap-1.5"
        aria-labelledby={`py-${a.key}`}
        onSubmit={(e) => {
          e.preventDefault()
          commit()
        }}
      >
        <div className="grid grid-cols-[repeat(auto-fill,minmax(4.25rem,1fr))] gap-1">
          {labels.map((label, t) => (
            <label key={label} className="flex flex-col gap-0.5 text-[11px] text-muted-foreground">
              {label}
              <Input
                value={texts[t] ?? ""}
                inputMode="decimal"
                aria-label={`${a.label.replace(/ by year$/, "")} ${label} in percent`}
                aria-invalid={errors[t] || undefined}
                className="h-7 px-1.5 text-right text-[13px] tabular-nums"
                onChange={(e) => {
                  const next = [...texts]
                  next[t] = e.target.value
                  setTexts(next)
                  setErrors([])
                }}
                onKeyDown={(e) => {
                  if (e.key === "Escape") setTexts(initial)
                }}
              />
            </label>
          ))}
        </div>
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs text-muted-foreground" role={errors.some(Boolean) ? "alert" : undefined}>
            {errors.some(Boolean) ? "Enter a percentage for every year." : "Percent of revenue or growth, per year."}
          </span>
          <span className="flex gap-1">
            {dirty ? (
              <Button type="button" variant="ghost" size="sm" onClick={() => setTexts(initial)}>
                Discard
              </Button>
            ) : null}
            <Button type="submit" size="sm" variant={dirty ? "default" : "outline"} disabled={!dirty}>
              Set years
            </Button>
          </span>
        </div>
      </form>
    </div>
  )
}

export function AssumptionsPanel({
  dealId,
  assumptions,
  currency,
  mode = "quick",
  yearLabels,
}: {
  dealId: string
  assumptions: ResolvedAssumption[]
  currency: string
  /** Detailed mode edits the operating drivers year by year and shows every assumption */
  mode?: DealMode
  /** labels of the projection years (e.g. 2026E), used by the per-year editors */
  yearLabels?: string[]
}) {
  const { data: doc } = useAssumptions(dealId)
  const [showAll, setShowAll] = React.useState(false)
  const detailed = mode === "detailed"
  const years = (() => {
    const y = assumptions.find((a) => a.key === "projection_years")?.value
    return typeof y === "number" && y >= 3 && y <= 15 ? y : 5
  })()
  const labels =
    yearLabels && yearLabels.length === years ? yearLabels : Array.from({ length: years }, (_, t) => `Year ${t + 1}`)
  const save = useSaveAssumptions(dealId)
  const undo = React.useRef<Record<string, unknown>[]>([])
  const redo = React.useRef<Record<string, unknown>[]>([])
  const [depth, setDepth] = React.useState({ undo: 0, redo: 0 })
  const overrides = doc?.overrides ?? {}

  const write = async (next: Record<string, unknown>, history: "new" | "undo" | "redo" = "new") => {
    const before = overrides
    try {
      await save.mutateAsync({ overrides: next })
      if (history === "new") {
        undo.current.push(before)
        redo.current = []
      } else if (history === "undo") redo.current.push(before)
      else undo.current.push(before)
      setDepth({ undo: undo.current.length, redo: redo.current.length })
    } catch (error) {
      toast.add({ title: "Assumption not saved", description: (error as Error).message, type: "error" })
    }
  }
  const byKey = new Map(assumptions.map((a) => [a.key, a]))
  const setValue = (key: string, value: unknown) => write({ ...overrides, [key]: value })
  const reset = (key: string) => {
    const next = { ...overrides }
    delete next[key]
    void write(next)
  }

  return (
    <section aria-labelledby="assumptions-title" className="flex flex-col gap-3">
      <div className="flex items-center justify-between gap-2">
        <h2 id="assumptions-title" className="text-sm font-semibold">Assumptions</h2>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon-sm" aria-label="Undo assumption change" disabled={!depth.undo || save.isPending}
            onClick={() => { const prev = undo.current.pop(); if (prev) void write(prev, "undo") }}>
            <Undo2Icon />
          </Button>
          <Button variant="ghost" size="icon-sm" aria-label="Redo assumption change" disabled={!depth.redo || save.isPending}
            onClick={() => { const next = redo.current.pop(); if (next) void write(next, "redo") }}>
            <Redo2Icon />
          </Button>
        </div>
      </div>
      {SECTIONS.map((section) => {
        const items = section.keys
          .map((k) => byKey.get(k))
          .filter((a): a is ResolvedAssumption => !!a)
          .filter((a) => detailed || showAll || !ADVANCED.includes(a.key) || a.key in overrides || a.source === "missing")
        if (!items.length) return null
        return (
          <div key={section.title} className="rounded-lg border">
            <h3 className="border-b bg-band px-3 py-1.5 text-xs font-semibold">{section.title}</h3>
            {items.map((a) =>
              a.key === "terminal_method" ? (
                <div key={a.key} className="flex items-center justify-between gap-3 border-t px-3 py-2">
                  <span className="text-sm">Terminal value method</span>
                  <Select
                    items={[
                      { value: "gordon", label: "Gordon growth" },
                      { value: "exit_multiple", label: "Exit multiple" },
                      { value: "average", label: "Average of both" },
                    ]}
                    value={(overrides.terminal_method as string) ?? "gordon"}
                    onValueChange={(v) => void setValue("terminal_method", v)}
                  >
                    <SelectTrigger size="sm" className="w-40" aria-label="Terminal value method"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectItem value="gordon">Gordon growth</SelectItem>
                        <SelectItem value="exit_multiple">Exit multiple</SelectItem>
                        <SelectItem value="average">Average of both</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>
              ) : detailed && PER_YEAR.includes(a.key) ? (
                <PerYearRow
                  key={`${a.key}:${JSON.stringify(a.value)}:${labels.join()}`}
                  a={a}
                  labels={labels}
                  overridden={a.key in overrides}
                  onSet={(k, v) => void setValue(k, v)}
                  onReset={reset}
                />
              ) : (
                <AssumptionRow
                  key={a.key}
                  a={a}
                  currency={currency}
                  overridden={a.key in overrides}
                  note={doc?.notes?.[a.key]}
                  onSet={(k, v) => void setValue(k, v)}
                  onReset={reset}
                  onNote={(k, n) => void save.mutateAsync({ notes: { ...(doc?.notes ?? {}), [k]: n } })}
                />
              ),
            )}
          </div>
        )
      })}
      {!detailed ? (
        <Button variant="link" size="sm" className="self-start px-0" aria-expanded={showAll} onClick={() => setShowAll((x) => !x)}>
          {showAll ? "Show fewer assumptions" : "Show every assumption"}
        </Button>
      ) : null}
      {detailed || showAll ? (
      <div className="rounded-lg border">
        <h3 className="border-b bg-band px-3 py-1.5 text-xs font-semibold">Conventions</h3>
        {[
          { key: "mid_year", label: "Mid-year discounting", value: overrides.mid_year !== false },
          { key: "include_leases", label: "Lease liabilities in net debt (IFRS 16 / ASC 842 basis)", value: overrides.include_leases !== false },
          { key: "include_pensions", label: "Pension deficit as debt", value: overrides.include_pensions !== false },
          { key: "include_provisions", label: "Provisions as debt", value: overrides.include_provisions === true },
        ].map((toggle) => (
          <label key={toggle.key} htmlFor={`toggle-${toggle.key}`} className="flex cursor-pointer items-center justify-between gap-3 border-t px-3 py-2 first:border-t-0">
            <span className="text-sm">{toggle.label}</span>
            <Switch id={`toggle-${toggle.key}`} checked={toggle.value} onCheckedChange={(checked) => void setValue(toggle.key, checked)} />
          </label>
        ))}
      </div>
      ) : null}
    </section>
  )
}
