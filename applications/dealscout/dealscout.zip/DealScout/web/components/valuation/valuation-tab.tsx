"use client"

import * as React from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { TriangleAlertIcon } from "lucide-react"

import {
  FootballFieldChart,
  type FootballRow,
  RevenueEbitdaChart,
  ScenarioBars,
  SensitivityHeatmap,
} from "@/components/charts/valuation-charts"
import { FxNote } from "@/components/common/fx-note"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { formatAccounting, formatMoneyCompact, formatMultiple, formatPct } from "@/lib/format"
import { useAnalysis, useAssumptions, useFinancials, useMethods, useValuation } from "@/lib/queries"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FiTab } from "@/components/methods/fi-tab"
import { MethodsProvider, StatusBadge } from "@/components/methods/kit"
import { LboTab } from "@/components/methods/lbo-tab"
import { NavTab } from "@/components/methods/nav-tab"
import { OtherTab } from "@/components/methods/other-tab"
import { PrecedentsTab } from "@/components/methods/precedents-tab"
import { PriceTab } from "@/components/methods/price-tab"
import { StrategicTab } from "@/components/methods/strategic-tab"
import type { Deal, ProjectionYear, ValuationResponse } from "@/lib/types"

import { AssumptionsPanel } from "./assumptions-panel"
import { PeersEditor } from "./peers-editor"
import { ScenarioEditor } from "./scenario-editor"

function Headline({ v, perShare }: { v: ValuationResponse; perShare: boolean }) {
  const ff = v.result.football_field
  const cur = v.deal.currency
  if (!ff || ff.blended_equity_mid === null) return null
  const ps = ff.blended_per_share
  const value = (lo: number, mid: number, hi: number, digits = 2) =>
    perShare && ps
      ? `${cur} ${formatAccounting(lo, digits)} to ${formatAccounting(hi, digits)} (mid ${formatAccounting(mid, digits)})`
      : `${formatMoneyCompact(lo, cur)} to ${formatMoneyCompact(hi, cur)} (mid ${formatMoneyCompact(mid, cur)})`
  return (
    <div className="rounded-lg border bg-band px-4 py-3">
      <p className="text-xs font-medium text-muted-foreground">Indicative equity value range (weighted across methods)</p>
      <p className="mt-1 text-2xl font-semibold tracking-tight tabular-nums">
        {perShare && ps
          ? value(ps.low, ps.mid, ps.high)
          : value(ff.blended_equity_low as number, ff.blended_equity_mid, ff.blended_equity_high as number)}
      </p>
      <p className="mt-1 text-xs text-muted-foreground">
        {perShare && ps ? "Per diluted share. " : "100% of equity. "}
        A screening range; the Acquisition price tab adds premia, LBO affordability, synergies and the rationale.
      </p>
    </div>
  )
}

function WaccTable({ v }: { v: ValuationResponse }) {
  const w = v.result.wacc
  if (!w) return null
  const inputs = Object.fromEntries(w.derivation.inputs.map((i) => [i.name, i.value]))
  const rows: [string, string][] = [
    ["Risk-free rate", formatPct(inputs.risk_free_rate)],
    ["× Levered beta" + (w.unlevered_beta !== null ? ` (β unlevered ${w.unlevered_beta.toFixed(2)}, D/E ${formatPct(w.debt_to_equity)})` : ""), w.levered_beta.toFixed(2)],
    ["× Equity risk premium", formatPct(inputs.equity_risk_premium)],
    ["+ Country risk premium", formatPct(inputs.country_risk_premium)],
    ["+ Size and specific premia", formatPct((inputs.size_premium ?? 0) + (inputs.company_specific_premium ?? 0))],
    ["= Cost of equity", formatPct(w.cost_of_equity)],
    ["Pre-tax cost of debt × (1 − tax)", `${formatPct(inputs.pre_tax_cost_of_debt)} × (1 − ${formatPct(inputs.tax_rate)}) = ${formatPct(w.after_tax_cost_of_debt)}`],
    ["Weights: equity / debt", `${formatPct(w.equity_weight, 0)} / ${formatPct(w.debt_weight, 0)}`],
    ["= WACC", formatPct(w.wacc, 2)],
  ]
  return (
    <section aria-labelledby="wacc-title">
      <h2 id="wacc-title" className="mb-2 text-sm font-semibold">WACC build-up</h2>
      <table className="w-full text-[13px] tabular-nums">
        <tbody>
          {rows.map(([label, value]) => (
            <tr key={label} className={label.startsWith("=") ? "border-t font-semibold" : "border-t"}>
              <th scope="row" className="py-1 pr-3 text-left font-normal">{label}</th>
              <td className="py-1 text-right">{value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  )
}

function DcfDetail({ v }: { v: ValuationResponse }) {
  const d = v.result.dcf
  if (!d) return null
  const cur = v.deal.currency
  const m = (x: number) => formatAccounting(x / 1e6, 1)
  const lines: [string, (y: ProjectionYear) => string][] = [
    ["Revenue", (y) => m(y.revenue)],
    ["  growth", (y) => formatPct(y.revenue_growth)],
    ["EBITDA", (y) => m(y.ebitda)],
    ["  margin", (y) => formatPct(y.ebitda_margin)],
    ["− D&A", (y) => m(-y.da)],
    ["EBIT", (y) => m(y.ebit)],
    ["− Cash taxes", (y) => m(-y.cash_taxes)],
    ["+ D&A", (y) => m(y.da)],
    ["− Capex", (y) => m(-y.capex)],
    ["− Increase in NWC", (y) => m(-y.change_in_nwc)],
    ["Unlevered free cash flow", (y) => m(y.unlevered_fcf)],
    ["Period fraction", (y) => y.period_fraction.toFixed(2)],
    ["Discount factor", (y) => y.discount_factor.toFixed(3)],
    ["PV of FCF", (y) => m(y.pv_fcf)],
  ]
  return (
    <section aria-labelledby="dcf-title" className="flex flex-col gap-3">
      <h2 id="dcf-title" className="text-sm font-semibold">DCF (FCFF), {cur} m</h2>
      <div className="relative overflow-x-auto rounded-lg border">
        <table className="w-full text-[13px] tabular-nums">
          <thead className="bg-muted text-xs text-muted-foreground">
            <tr>
              <th className="px-3 py-2 text-left font-medium">{cur} m</th>
              {d.projection.map((y) => <th key={y.label} className="px-3 py-2 text-right font-medium">{y.label}</th>)}
            </tr>
          </thead>
          <tbody>
            {lines.map(([label, fn]) => (
              <tr key={label} className={["Unlevered free cash flow", "EBITDA", "EBIT"].includes(label) ? "border-t font-semibold" : "border-t"}>
                <th scope="row" className={label.startsWith("  ") ? "py-1 pr-3 pl-6 text-left font-normal italic text-muted-foreground" : "py-1 pr-3 pl-3 text-left font-normal"}>
                  {label.trim()}
                </th>
                {d.projection.map((y) => <td key={y.label} className={label.startsWith("  ") ? "px-3 py-1 text-right italic text-muted-foreground" : "px-3 py-1 text-right"}>{fn(y)}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <table className="text-[13px] tabular-nums">
          <caption className="mb-1 text-left text-xs font-semibold">Terminal value cross-check</caption>
          <tbody>
            <tr className="border-t"><th scope="row" className="py-1 text-left font-normal">Gordon growth TV (PV)</th><td className="text-right">{formatMoneyCompact(d.gordon.value, cur)} ({formatMoneyCompact(d.gordon.pv, cur)})</td></tr>
            <tr className="border-t"><th scope="row" className="py-1 text-left font-normal">… implies exit EV/EBITDA</th><td className="text-right">{formatMultiple(d.gordon.implied_cross_check)}</td></tr>
            <tr className="border-t"><th scope="row" className="py-1 text-left font-normal">Exit-multiple TV (PV)</th><td className="text-right">{formatMoneyCompact(d.exit.value, cur)} ({formatMoneyCompact(d.exit.pv, cur)})</td></tr>
            <tr className="border-t"><th scope="row" className="py-1 text-left font-normal">… implies perpetual growth</th><td className="text-right">{formatPct(d.exit.implied_cross_check)}</td></tr>
            <tr className="border-t"><th scope="row" className="py-1 text-left font-normal">Terminal value share of EV</th><td className="text-right">{formatPct(d.terminal_share_of_ev, 0)}</td></tr>
          </tbody>
        </table>
        <table className="text-[13px] tabular-nums">
          <caption className="mb-1 text-left text-xs font-semibold">Enterprise value to equity value</caption>
          <tbody>
            <tr className="border-t font-semibold"><th scope="row" className="py-1 text-left">Enterprise value</th><td className="text-right">{formatMoneyCompact(d.enterprise_value, cur)}</td></tr>
            {d.bridge.items.filter((i) => i.amount !== 0).map((i) => (
              <tr key={i.key} className="border-t">
                <th scope="row" className="py-1 text-left font-normal">{i.amount < 0 ? "− " : "+ "}{i.label}</th>
                <td className="text-right">{formatMoneyCompact(Math.abs(i.amount), cur)}</td>
              </tr>
            ))}
            <tr className="border-t font-semibold"><th scope="row" className="py-1 text-left">Equity value</th><td className="text-right">{formatMoneyCompact(d.equity_value, cur)}</td></tr>
            {d.per_share ? (
              <tr className="border-t"><th scope="row" className="py-1 text-left font-normal">Per diluted share ({formatAccounting(d.per_share.diluted_shares / 1e6, 1)}m shares)</th><td className="text-right">{cur} {formatAccounting(d.per_share.value_per_share, 2)}</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </section>
  )
}

const METHOD_TABS = [
  { value: "price", label: "Acquisition price", ids: [] as string[] },
  { value: "summary", label: "Summary & DCF", ids: [] as string[] },
  { value: "lbo", label: "LBO", ids: ["lbo"] },
  { value: "precedents", label: "Precedents", ids: ["precedents"] },
  { value: "nav", label: "NAV / SOTP", ids: ["nav", "sotp"] },
  { value: "fi", label: "Financial institutions", ids: ["ddm", "residual_income", "ptbv", "fcfe", "apv"] },
  { value: "strategic", label: "Strategic", ids: ["strategic", "accretion"] },
  { value: "other", label: "Other", ids: ["liquidation", "replacement"] },
]

/** Quick Scan keeps these tabs in view; the others appear once they hold a result, or with "Show all methods". */
const QUICK_TABS = ["price", "summary"]

export function ValuationTab({ deal }: { deal: Deal }) {
  const { data: v } = useValuation(deal.id)
  const { data: doc } = useMethods(deal.id)
  const { data: grid } = useFinancials(deal.id)
  const params = useSearchParams()
  const router = useRouter()
  const [showAll, setShowAll] = React.useState(false)
  const requested = params.get("method") ?? "price"
  const tab = METHOD_TABS.some((t) => t.value === requested) ? requested : "price"
  const setTab = (value: string) => {
    const next = new URLSearchParams(params.toString())
    next.set("method", value)
    router.replace(`/deal?${next.toString()}`, { scroll: false })
  }
  if (!v || !doc) return <ValuationSummary deal={deal} />
  const ctx = { dealId: deal.id, currency: v.deal.currency, scale: grid?.entry.scale ?? 1e6 }
  const readyIn = (ids: string[]) => {
    const outs = v.methods.filter((m) => ids.includes(m.id))
    return outs.find((m) => m.status === "ready") ?? outs.find((m) => m.status === "error") ?? outs[0]
  }
  const quick = deal.mode !== "detailed"
  const visible = METHOD_TABS.filter(
    (t) => !quick || showAll || QUICK_TABS.includes(t.value) || t.value === tab || readyIn(t.ids)?.status === "ready",
  )
  const hidden = METHOD_TABS.length - visible.length
  return (
    <MethodsProvider value={ctx}>
      <Tabs value={tab} onValueChange={(x) => setTab(x as string)} className="gap-4">
        <div className="flex max-w-full flex-wrap items-center gap-x-3 gap-y-1">
        <TabsList variant="line" className="relative max-w-full justify-start overflow-x-auto" aria-label="Valuation methods">
          {visible.map((t) => (
            <TabsTrigger key={t.value} value={t.value} className="gap-1.5">
              {t.label}
              {t.ids.length ? <StatusBadge output={readyIn(t.ids)} /> : null}
            </TabsTrigger>
          ))}
        </TabsList>
        {quick && (hidden > 0 || showAll) ? (
          <Button variant="link" size="sm" className="px-0" aria-expanded={showAll} onClick={() => setShowAll((x) => !x)}>
            {showAll ? "Show fewer methods" : `Show all methods (${hidden} more)`}
          </Button>
        ) : null}
        </div>
        <TabsContent value="price"><PriceTab dealId={deal.id} listed={v.deal.listed} /></TabsContent>
        <TabsContent value="summary"><ValuationSummary deal={deal} /></TabsContent>
        <TabsContent value="lbo"><LboTab doc={doc} v={v} /></TabsContent>
        <TabsContent value="precedents"><PrecedentsTab doc={doc} v={v} /></TabsContent>
        <TabsContent value="nav"><NavTab doc={doc} v={v} /></TabsContent>
        <TabsContent value="fi"><FiTab doc={doc} v={v} /></TabsContent>
        <TabsContent value="strategic"><StrategicTab doc={doc} v={v} /></TabsContent>
        <TabsContent value="other"><OtherTab doc={doc} v={v} /></TabsContent>
      </Tabs>
    </MethodsProvider>
  )
}

function ValuationSummary({ deal }: { deal: Deal }) {
  const { data: v, isPending, isError, error, isFetching } = useValuation(deal.id)
  const { data: analysis } = useAnalysis(deal.id)
  const { data: grid } = useFinancials(deal.id)
  const { data: doc } = useAssumptions(deal.id)
  const { data: methodsDoc } = useMethods(deal.id)
  const [basis, setBasis] = React.useState<"equity" | "per_share">("equity")
  if (isPending) return <Skeleton className="h-[32rem] w-full" />
  if (isError || !v) {
    return (
      <Alert variant="destructive">
        <AlertTitle>The valuation could not be run</AlertTitle>
        <AlertDescription>{error?.message}</AlertDescription>
      </Alert>
    )
  }
  const r = v.result
  const ff = r.football_field
  const cur = v.deal.currency
  const missingLabels = r.assumptions.filter((a) => a.source === "missing").map((a) => a.label)
  const perShareAvailable = !!ff?.blended_per_share
  const showPerShare = basis === "per_share" && perShareAvailable
  const ffRows: FootballRow[] = ff
    ? [
        ...ff.methods.filter((m) => m.included).map((m) => {
          const ps = ff.method_per_share[m.method_id]
          return showPerShare && ps
            ? { label: m.label, low: ps.low, mid: ps.mid, high: ps.high }
            : { label: m.label, low: m.equity_low, mid: m.equity_mid, high: m.equity_high }
        }),
        ...(ff.blended_equity_low !== null
          ? [showPerShare && ff.blended_per_share
              ? { label: "Blended (weighted)", ...ff.blended_per_share, blended: true }
              : { label: "Blended (weighted)", low: ff.blended_equity_low, mid: ff.blended_equity_mid as number, high: ff.blended_equity_high as number, blended: true }]
          : []),
      ]
    : []
  const reference = showPerShare
    ? ff?.share_price ? { label: "Share price", value: ff.share_price } : null
    : ff?.market_cap ? { label: "Market cap", value: ff.market_cap } : null
  const hist = analysis?.periods ?? []
  const proj = r.dcf?.projection ?? []

  return (
    <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_24rem]" aria-busy={isFetching}>
      <div className="flex min-w-0 flex-col gap-6">
        <FxNote fx={v.fx} />
        {missingLabels.length ? (
          <Alert>
            <TriangleAlertIcon />
            <AlertTitle>Some inputs are needed before the DCF can run</AlertTitle>
            <AlertDescription>
              Missing: {missingLabels.join(", ")}. Enter the figures on the Data tab, or set the assumptions in the panel. Nothing is
              guessed in their place.
            </AlertDescription>
          </Alert>
        ) : null}
        {r.warnings.length ? (
          <ul className="flex flex-col gap-1 rounded-lg border border-warning/40 bg-warning-bg px-3 py-2 text-sm" aria-label="Valuation warnings">
            {r.warnings.map((w) => (
              <li key={w} className="flex items-start gap-2">
                <TriangleAlertIcon aria-hidden className="mt-0.5 size-4 shrink-0 text-warning" />
                <span>{w}</span>
              </li>
            ))}
          </ul>
        ) : null}
        <Headline v={v} perShare={showPerShare} />
        {ffRows.length ? (
          <div className="flex flex-col gap-2">
            {perShareAvailable ? (
              <ToggleGroup variant="outline" size="sm" aria-label="Value basis" value={[basis]} onValueChange={(val: string[]) => val[0] && setBasis(val[0] as typeof basis)}>
                <ToggleGroupItem value="equity">100% equity</ToggleGroupItem>
                <ToggleGroupItem value="per_share">Per share</ToggleGroupItem>
              </ToggleGroup>
            ) : null}
            <FootballFieldChart rows={ffRows} currency={cur} unitLabel={showPerShare ? `${cur} per share` : `Equity value (${cur})`} reference={reference} perShare={showPerShare} />
          </div>
        ) : null}
        {r.dcf && hist.length ? (
          <RevenueEbitdaChart
            labels={[...hist.map((p) => `${p}A`), ...proj.map((y) => y.label)]}
            revenue={[...hist.map((p) => analysis?.series.revenue?.[p] ?? null), ...proj.map((y) => y.revenue)]}
            ebitda={[...hist.map((p) => analysis?.series.ebitda?.[p] ?? null), ...proj.map((y) => y.ebitda)]}
            projected={[...hist.map(() => false), ...proj.map(() => true)]}
            currency={cur}
          />
        ) : null}
        <div className="grid gap-6 lg:grid-cols-2">
          <WaccTable v={v} />
          {v.scenarios ? <ScenarioBars scenarios={v.scenarios.scenarios} weighted={v.scenarios.probability_weighted_ev} currency={cur} /> : null}
        </div>
        {r.dcf && methodsDoc ? (
          <ScenarioEditor dealId={deal.id} scenarios={methodsDoc.scenarios ?? []} serverError={v.scenarios_error} />
        ) : null}
        <DcfDetail v={v} />
        {v.sensitivities.length ? (
          <section aria-labelledby="sens-title" className="flex flex-col gap-3">
            <h2 id="sens-title" className="text-sm font-semibold">Sensitivities (enterprise value)</h2>
            <div className="grid gap-6 lg:grid-cols-2">
              <SensitivityHeatmap table={v.sensitivities[0]} currency={cur} rowFormat={(x) => formatPct(x)} colFormat={(x) => formatPct(x)} />
              <SensitivityHeatmap table={v.sensitivities[1]} currency={cur} rowFormat={(x) => formatPct(x)} colFormat={(x) => formatMultiple(x)} />
              <SensitivityHeatmap
                table={v.sensitivities[2]}
                currency={cur}
                rowFormat={(x) => `${x >= 0 ? "+" : ""}${(x * 100).toFixed(0)}pp`}
                colFormat={(x) => `${x >= 0 ? "+" : ""}${(x * 100).toFixed(0)}pp`}
              />
            </div>
          </section>
        ) : null}
        <PeersEditor
          dealId={deal.id}
          currency={cur}
          scale={grid?.entry.scale ?? 1e6}
          stats={v.peer_stats}
          adjustments={v.peer_adjustments ?? []}
          statsByBasis={v.peer_stats_by_basis}
          basis={v.comps_basis ?? "ltm"}
          excludeOutliers={doc?.overrides?.exclude_peer_outliers === true}
        />
        <p className="text-xs text-muted-foreground">
          Market defaults version {v.defaults.version} (as of {v.defaults.as_of ?? "unknown"}). Every default shows its source and date in
          the assumptions panel; values older than 90 days are flagged.
        </p>
      </div>
      <aside className="xl:sticky xl:top-16 xl:max-h-[calc(100dvh-5rem)] xl:overflow-y-auto">
        <AssumptionsPanel
          dealId={deal.id}
          assumptions={r.assumptions}
          currency={cur}
          mode={deal.mode}
          yearLabels={proj.map((y) => y.label)}
        />
      </aside>
    </div>
  )
}
