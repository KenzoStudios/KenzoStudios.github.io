"use client"

import * as React from "react"
import { ExternalLinkIcon } from "lucide-react"

import { Skeleton } from "@/components/ui/skeleton"

/**
 * A tagged filing or HTML report in a fully sandboxed frame (no scripts, no same-origin access). The server serves a
 * sanitised copy where every tagged fact and table cell has an id; selecting a value only changes the URL fragment,
 * so the document scrolls to it and highlights it (CSS :target) without reloading.
 */
export function HtmlViewer({ url, target, label }: { url: string; target: string | null; label: string }) {
  const [loaded, setLoaded] = React.useState<string | null>(null)
  const src = target ? `${url}#${encodeURIComponent(target)}` : url
  return (
    <div className="relative flex h-full min-h-0 w-full flex-col">
      <div className="flex items-center justify-end border-b px-2 py-1.5">
        <a
          href={src}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-xs font-medium text-link underline-offset-2 hover:underline"
        >
          Open in a new tab
          <ExternalLinkIcon aria-hidden className="size-3" />
        </a>
      </div>
      {loaded !== url ? <Skeleton className="absolute inset-x-3 top-12 bottom-3" /> : null}
      <iframe
        key={url}
        src={src}
        title={label}
        sandbox=""
        referrerPolicy="no-referrer"
        className="min-h-0 w-full flex-1 border-0 bg-white"
        onLoad={() => setLoaded(url)}
      />
    </div>
  )
}
