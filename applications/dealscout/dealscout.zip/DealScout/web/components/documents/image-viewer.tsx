"use client"

import * as React from "react"

/** An uploaded image of a statement with the OCR'd value boxed (coordinates in page points, scaled to the image). */
export function ImageViewer({
  url,
  highlight,
  pageSize,
  label,
}: {
  url: string
  highlight: [number, number, number, number] | null
  pageSize: [number, number] | null
  label: string
}) {
  const box =
    highlight && pageSize
      ? {
          left: `${(highlight[0] / pageSize[0]) * 100}%`,
          top: `${(highlight[1] / pageSize[1]) * 100}%`,
          width: `${((highlight[2] - highlight[0]) / pageSize[0]) * 100}%`,
          height: `${((highlight[3] - highlight[1]) / pageSize[1]) * 100}%`,
        }
      : null
  return (
    <div className="h-full min-h-0 overflow-auto bg-muted/40 p-3" role="region" tabIndex={0} aria-label={label}>
      <div className="relative mx-auto w-full max-w-3xl">
        {/* eslint-disable-next-line @next/next/no-img-element -- a local, uploaded document image */}
        <img src={url} alt={label} className="block h-auto w-full bg-white" />
        {box ? (
          <div aria-hidden className="pointer-events-none absolute rounded-[2px] ring-2 ring-ring ring-offset-1" style={box} />
        ) : null}
      </div>
    </div>
  )
}
