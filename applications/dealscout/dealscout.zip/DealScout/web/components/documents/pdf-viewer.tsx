"use client"

import * as React from "react"
import { ChevronLeftIcon, ChevronRightIcon, MinusIcon, PlusIcon } from "lucide-react"
import type { PDFDocumentLoadingTask, PDFDocumentProxy, RenderTask } from "pdfjs-dist"

import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"

type BBox = [number, number, number, number]

let pdfjsPromise: Promise<typeof import("pdfjs-dist")> | null = null
function loadPdfjs() {
  // The worker is copied to /public at build time (scripts/gen-theme.mjs): no CDN at runtime.
  pdfjsPromise ??= import("pdfjs-dist").then((pdfjs) => {
    pdfjs.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs"
    return pdfjs
  })
  return pdfjsPromise
}

const ZOOMS = [0.75, 1, 1.25, 1.5, 2] as const

/**
 * Renders one page of a stored PDF and highlights the cell a value was read from (value box plus a faint band
 * across its row). Coordinates are PDF points with a top-left origin, as PyMuPDF reports them.
 */
export function PdfViewer({
  url,
  page,
  highlight,
  onPageChange,
  label,
}: {
  url: string
  page: number
  highlight: BBox | null
  onPageChange: (page: number) => void
  label: string
}) {
  const containerRef = React.useRef<HTMLDivElement>(null)
  const canvasRef = React.useRef<HTMLCanvasElement>(null)
  // state is keyed by what it was computed for, so a new file or page never shows stale results
  const [loaded, setLoaded] = React.useState<{ url: string; doc: PDFDocumentProxy | null; error: string | null }>({
    url: "",
    doc: null,
    error: null,
  })
  const [width, setWidth] = React.useState(0)
  const [zoom, setZoom] = React.useState<(typeof ZOOMS)[number]>(1)
  const [drawn, setDrawn] = React.useState<{ key: string; rect: { box: BBox; size: [number, number] } | null }>({
    key: "",
    rect: null,
  })
  const doc = loaded.url === url ? loaded.doc : null
  const error = loaded.url === url ? loaded.error : null
  const renderKey = `${url}|${page}|${width}|${zoom}|${highlight?.join(",") ?? ""}`
  const rect = drawn.key === renderKey ? drawn.rect : null
  const rendering = drawn.key !== renderKey

  React.useEffect(() => {
    let cancelled = false
    let task: PDFDocumentLoadingTask | null = null
    loadPdfjs()
      .then((pdfjs) => {
        task = pdfjs.getDocument({
          url,
          cMapUrl: "/pdfjs/cmaps/",
          cMapPacked: true,
          standardFontDataUrl: "/pdfjs/standard_fonts/",
          iccUrl: "/pdfjs/iccs/",
          wasmUrl: "/pdfjs/wasm/",
        })
        return task.promise
      })
      .then((pdf) => {
        if (!cancelled) setLoaded({ url, doc: pdf, error: null })
      })
      .catch((e: Error) => {
        if (!cancelled) setLoaded({ url, doc: null, error: e.message || "The PDF could not be opened." })
      })
    return () => {
      cancelled = true
      void task?.destroy()
    }
  }, [url])

  React.useEffect(() => {
    const node = containerRef.current
    if (!node) return
    const observer = new ResizeObserver(([entry]) => setWidth(Math.floor(entry.contentRect.width)))
    observer.observe(node)
    return () => observer.disconnect()
  }, [])

  React.useEffect(() => {
    if (!doc || !width || !canvasRef.current) return
    let task: RenderTask | null = null
    let cancelled = false
    const target = Math.min(Math.max(page, 1), doc.numPages)
    void doc.getPage(target).then((pdfPage) => {
      if (cancelled || !canvasRef.current) return
      const base = pdfPage.getViewport({ scale: 1 })
      const viewport = pdfPage.getViewport({ scale: (width / base.width) * zoom })
      const ratio = window.devicePixelRatio || 1
      const canvas = canvasRef.current
      canvas.width = Math.floor(viewport.width * ratio)
      canvas.height = Math.floor(viewport.height * ratio)
      canvas.style.width = `${Math.floor(viewport.width)}px`
      canvas.style.height = `${Math.floor(viewport.height)}px`
      task = pdfPage.render({
        canvas,
        viewport,
        transform: ratio === 1 ? undefined : [ratio, 0, 0, ratio, 0, 0],
      })
      task.promise
        .then(() => {
          if (cancelled) return
          if (!highlight) return setDrawn({ key: renderKey, rect: null })
          const [vx0, , , vy1] = pdfPage.view
          const [x0, y0, x1, y1] = highlight
          const [a, b] = viewport.convertToViewportPoint(vx0 + x0, vy1 - y1) as [number, number]
          const [c, d] = viewport.convertToViewportPoint(vx0 + x1, vy1 - y0) as [number, number]
          setDrawn({
            key: renderKey,
            rect: {
              box: [Math.min(a, c), Math.min(b, d), Math.abs(c - a), Math.abs(d - b)],
              size: [viewport.width, viewport.height],
            },
          })
        })
        .catch(() => undefined) // cancelled by a newer render
    })
    return () => {
      cancelled = true
      task?.cancel()
    }
  }, [doc, page, width, zoom, highlight, renderKey])

  // bring the highlight into view
  React.useEffect(() => {
    if (!rect || !containerRef.current) return
    const node = containerRef.current
    const top = rect.box[1] - node.clientHeight / 3
    const left = rect.box[0] + rect.box[2] / 2 - node.clientWidth / 2
    node.scrollTo({ top: Math.max(0, top), left: Math.max(0, left), behavior: "instant" as ScrollBehavior })
  }, [rect])

  const pages = doc?.numPages ?? 0
  return (
    <div className="flex h-full min-h-0 w-full min-w-0 flex-col overflow-hidden">
      <div className="flex items-center gap-1 border-b px-2 py-1.5">
        <Button
          variant="ghost"
          size="icon-sm"
          aria-label="Previous page"
          disabled={page <= 1}
          onClick={() => onPageChange(page - 1)}
        >
          <ChevronLeftIcon />
        </Button>
        <span className="min-w-24 text-center text-xs tabular-nums text-muted-foreground" aria-live="polite">
          Page {page}
          {pages ? ` of ${pages}` : ""}
        </span>
        <Button
          variant="ghost"
          size="icon-sm"
          aria-label="Next page"
          disabled={!pages || page >= pages}
          onClick={() => onPageChange(page + 1)}
        >
          <ChevronRightIcon />
        </Button>
        <div className="ml-auto flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Zoom out"
            disabled={zoom === ZOOMS[0]}
            onClick={() => setZoom(ZOOMS[Math.max(0, ZOOMS.indexOf(zoom) - 1)])}
          >
            <MinusIcon />
          </Button>
          <span className="w-11 text-center text-xs tabular-nums text-muted-foreground">{Math.round(zoom * 100)}%</span>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Zoom in"
            disabled={zoom === ZOOMS[ZOOMS.length - 1]}
            onClick={() => setZoom(ZOOMS[Math.min(ZOOMS.length - 1, ZOOMS.indexOf(zoom) + 1)])}
          >
            <PlusIcon />
          </Button>
        </div>
      </div>
      <div
        ref={containerRef}
        role="region"
        tabIndex={0}
        className="relative min-h-0 w-full min-w-0 flex-1 overflow-auto overscroll-contain bg-muted/40 outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-inset"
        aria-label={label}
      >
        {error ? (
          <p role="alert" className="p-4 text-sm text-destructive">
            {error}
          </p>
        ) : null}
        {!doc && !error ? <Skeleton className="m-3 h-[70vh]" /> : null}
        <div className="relative mx-auto w-fit">
          <canvas ref={canvasRef} className="block bg-white" aria-hidden />
          {rect && !rendering ? (
            <>
              <div
                aria-hidden
                className="pointer-events-none absolute left-0 bg-ring/10"
                style={{ top: rect.box[1] - 2, height: rect.box[3] + 4, width: rect.size[0] }}
              />
              <div
                aria-hidden
                className="pointer-events-none absolute rounded-[2px] ring-2 ring-ring ring-offset-1"
                style={{ left: rect.box[0] - 3, top: rect.box[1] - 2, width: rect.box[2] + 6, height: rect.box[3] + 4 }}
              />
            </>
          ) : null}
        </div>
      </div>
    </div>
  )
}
