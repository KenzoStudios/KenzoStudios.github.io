"use client"

import * as React from "react"
import Link from "next/link"
import {
  CircleAlertIcon,
  CircleCheckIcon,
  CircleDashedIcon,
  CircleXIcon,
  FileSpreadsheetIcon,
  FileTextIcon,
  FileUpIcon,
  LoaderCircleIcon,
  RotateCwIcon,
  SparklesIcon,
  Trash2Icon,
} from "lucide-react"

import { LinkButton } from "@/components/common/link-button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { Skeleton } from "@/components/ui/skeleton"
import { toast } from "@/components/ui/toast"
import { formatRelative } from "@/lib/format"
import { useAIStatus, useDocumentMutations, useDocuments } from "@/lib/queries"
import type { Deal, DealDocument, JobStep } from "@/lib/types"
import { cn } from "@/lib/utils"

const ACCEPT = ".pdf,.xlsx,.xls,.csv,.docx,.zip,.htm,.html,.xhtml,.xbrl,.xml,.png,.jpg,.jpeg"
const DOC_TYPE_LABEL: Record<string, string> = {
  annual_report: "Annual report",
  interim_report: "Interim report",
  audited_accounts: "Audited accounts",
  management_accounts: "Management accounts",
  investor_presentation: "Investor presentation",
  prospectus: "Prospectus",
  other: "Other document",
}
function languageName(code: string): string {
  try {
    return new Intl.DisplayNames([navigator.language || "en"], { type: "language" }).of(code) ?? code
  } catch {
    return code
  }
}

function formatBytes(bytes: number): string {
  const kb = bytes < 1024 * 1024
  const value = kb ? Math.max(1, Math.round(bytes / 1024)) : bytes / 1024 / 1024
  const text = new Intl.NumberFormat(undefined, { maximumFractionDigits: kb ? 0 : 1 }).format(value)
  return `${text}\u00a0${kb ? "KB" : "MB"}`
}

function StepIcon({ status }: { status: JobStep["status"] }) {
  if (status === "done") return <CircleCheckIcon aria-hidden className="size-3.5 text-positive" />
  if (status === "running") return <LoaderCircleIcon aria-hidden className="size-3.5 animate-spin text-link" />
  if (status === "failed") return <CircleXIcon aria-hidden className="size-3.5 text-negative" />
  return <CircleDashedIcon aria-hidden className="size-3.5 text-muted-foreground" />
}

function Steps({ steps }: { steps: JobStep[] }) {
  const done = steps.filter((s) => s.status === "done").length
  return (
    <ol className="flex flex-col gap-1" aria-label={`Step ${Math.min(done + 1, steps.length)} of ${steps.length}`}>
      {steps.map((step) => (
        <li key={step.key} className="flex items-start gap-2 text-xs">
          <span className="mt-0.5">
            <StepIcon status={step.status} />
          </span>
          <span className={cn("min-w-0", step.status === "pending" && "text-muted-foreground")}>
            {step.label}
            <span className="sr-only"> ({step.status})</span>
            {step.detail ? <span className="block break-words text-muted-foreground">{step.detail}</span> : null}
          </span>
        </li>
      ))}
    </ol>
  )
}

function StatusBadge({ doc }: { doc: DealDocument }) {
  switch (doc.status) {
    case "processed":
      return <Badge variant="positive">Read</Badge>
    case "processing":
    case "uploaded":
      return (
        <Badge variant="outline">
          <LoaderCircleIcon aria-hidden className="animate-spin" />
          Reading…
        </Badge>
      )
    case "paused":
      return <Badge variant="warning">Paused</Badge>
    case "failed":
      return <Badge variant="negative">Failed</Badge>
    default:
      return <Badge variant="outline">Not read yet</Badge>
  }
}

function DocumentRow({ deal, doc }: { deal: Deal; doc: DealDocument }) {
  const { rerun, remove, resumeJob } = useDocumentMutations(deal.id)
  const [confirming, setConfirming] = React.useState(false)
  const pending = doc.status === "processing" || doc.status === "uploaded"
  const statements = Object.entries(doc.meta.statements ?? {})
  const Icon = doc.kind === "pdf" ? FileTextIcon : FileSpreadsheetIcon
  const unsupported = doc.status === "unsupported"
  return (
    <li className="grid gap-3 border-b px-4 py-3 last:border-b-0 md:grid-cols-[minmax(0,2fr)_minmax(0,2fr)_auto]">
      <div className="flex min-w-0 items-start gap-3">
        <Icon aria-hidden className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
        <div className="min-w-0">
          <p className="truncate text-sm font-medium" title={doc.filename}>
            {doc.filename}
          </p>
          <p className="text-xs text-muted-foreground">
            {[
              doc.doc_type ? DOC_TYPE_LABEL[doc.doc_type] ?? doc.doc_type : null,
              doc.page_count
                ? `${doc.page_count} ${["html", "xbrl", "docx"].includes(doc.kind) ? "tables" : "pages"}`
                : null,
              doc.meta.tagged_facts ? `${doc.meta.tagged_facts} tagged facts` : null,
              doc.meta.entity_name ?? null,
              doc.language ? languageName(doc.language) : null,
              formatBytes(doc.size_bytes),
              `added ${formatRelative(doc.uploaded_at)}`,
            ]
              .filter(Boolean)
              .join(" · ")}
          </p>
          <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
            <StatusBadge doc={doc} />
            {doc.meta.ai_used ? (
              <Badge variant="outline">
                <SparklesIcon aria-hidden />
                AI read the notes
              </Badge>
            ) : null}
            {doc.scanned_pages ? (
              <Badge variant={doc.meta.ocr_pages ? "outline" : "warning"}>
                {doc.meta.ocr_pages ? `${doc.meta.ocr_pages} pages read with OCR` : `${doc.scanned_pages} scanned pages`}
              </Badge>
            ) : null}
            {doc.kind === "xbrl" ? <Badge variant="outline">Tagged filing</Badge> : null}
          </div>
        </div>
      </div>
      <div className="min-w-0 text-sm">
        {pending && doc.job ? <Steps steps={doc.job.steps} /> : null}
        {doc.status === "paused" || doc.status === "failed" ? (
          <p className="text-sm text-destructive" role="alert">
            {doc.job?.message ?? "Reading stopped."} The values already read from the tables are kept.
          </p>
        ) : null}
        {unsupported ? (
          <p className="text-xs text-muted-foreground">
            This file type is not read. It is stored with the deal.
          </p>
        ) : null}
        {doc.status === "processed" ? (
          statements.length ? (
            <ul className="flex flex-col gap-0.5 text-xs">
              {statements.map(([statement, located]) => (
                <li key={statement} className="truncate">
                  <span className="text-muted-foreground">{statement.replaceAll("_", " ")}: </span>
                  p. {located.map((l) => l.page).join(", ")}
                  {located[0]?.consolidated === true ? " · consolidated" : located[0]?.consolidated === false ? " · parent only" : ""}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-xs text-muted-foreground">No financial statements were recognised in this file.</p>
          )
        ) : null}
        {doc.meta.warnings?.length ? (
          <ul className="mt-1 flex flex-col gap-0.5 text-xs text-warning">
            {doc.meta.warnings.slice(0, 3).map((w) => (
              <li key={w}>{w}</li>
            ))}
          </ul>
        ) : null}
      </div>
      <div className="flex flex-wrap items-start gap-1.5 md:justify-end">
        {doc.status === "processed" ? (
          <LinkButton href={`/deal?id=${deal.id}&tab=review&doc=${doc.id}`} size="sm">
            Review values
          </LinkButton>
        ) : null}
        {doc.status === "paused" && doc.job ? (
          <Button size="sm" onClick={() => resumeJob.mutate(doc.job!.id)} disabled={resumeJob.isPending}>
            Resume
          </Button>
        ) : null}
        {!unsupported ? (
          <Button
            size="sm"
            variant="outline"
            disabled={pending || rerun.isPending}
            onClick={() =>
              rerun.mutate(doc.id, {
                onSuccess: () => toast.add({ title: "Reading again", description: doc.filename }),
                onError: (e) => toast.add({ title: "Could not start", description: e.message, type: "error" }),
              })
            }
          >
            <RotateCwIcon aria-hidden />
            Read again
          </Button>
        ) : null}
        <Button size="sm" variant="ghost" aria-label={`Delete ${doc.filename}`} onClick={() => setConfirming(true)}>
          <Trash2Icon aria-hidden />
        </Button>
        <AlertDialog open={confirming} onOpenChange={setConfirming}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete {doc.filename}?</AlertDialogTitle>
              <AlertDialogDescription>
                The file is removed from this computer with its values still waiting for review. Values you already
                accepted stay in the data grid, with their source noted in the history. This cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Keep it</AlertDialogCancel>
              <AlertDialogAction
                variant="destructive"
                onClick={() =>
                  remove.mutate(doc.id, {
                    onSuccess: () => toast.add({ title: "Document deleted", description: doc.filename }),
                  })
                }
              >
                Delete document
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </li>
  )
}

export function DocumentsTab({ deal }: { deal: Deal }) {
  const { data: docs, isPending, isError, error } = useDocuments(deal.id)
  const { data: ai } = useAIStatus()
  const { upload } = useDocumentMutations(deal.id)
  const inputRef = React.useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = React.useState(false)
  const [rejected, setRejected] = React.useState<string[]>([])

  function send(files: File[]) {
    if (!files.length) return
    setRejected([])
    upload.mutate(files, {
      onSuccess: (result) => {
        setRejected(result.rejected)
        if (result.documents.length)
          toast.add({
            title: `${result.documents.length} file${result.documents.length > 1 ? "s" : ""} added`,
            description: "Reading the statements now. You can keep working meanwhile.",
            type: "success",
          })
      },
      onError: (e) => toast.add({ title: "Upload failed", description: e.message, type: "error" }),
    })
  }

  const processed = docs?.filter((d) => d.status === "processed").length ?? 0
  return (
    <div className="flex flex-col gap-4">
      {ai && !ai.connected ? (
        <Alert>
          <SparklesIcon />
          <AlertTitle>No AI connected: tables and the line-item dictionary will be used</AlertTitle>
          <AlertDescription>
            <p>
              Primary statements are read either way. With AI connected, DealScout also maps unusual labels and searches
              the notes for missing items, and every AI value is checked against the page before you see it.
            </p>
            <p className="mt-2 flex flex-wrap gap-2">
              <LinkButton href="/settings/ai" size="sm">
                Connect AI
              </LinkButton>
              <span className="self-center text-xs text-muted-foreground">
                or continue without AI; you can read documents again after connecting.
              </span>
            </p>
          </AlertDescription>
        </Alert>
      ) : null}

      <div
        className={cn(
          "flex flex-col items-center justify-center gap-2 rounded-lg border border-dashed px-4 py-8 text-center transition-colors",
          dragging && "border-ring bg-muted",
        )}
        onDragOver={(e) => {
          e.preventDefault()
          setDragging(true)
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault()
          setDragging(false)
          send(Array.from(e.dataTransfer.files))
        }}
      >
        <FileUpIcon aria-hidden className="size-6 text-muted-foreground" />
        <p className="text-sm font-medium">Drop annual reports, interim reports or management accounts here</p>
        <p className="max-w-prose text-xs text-muted-foreground">
          PDF, Excel, CSV, Word, HTML, tagged filings (SEC iXBRL, ESEF packages, XBRL) and images. A ZIP data-room export
          is opened into its files. Scans need Tesseract or an AI that reads images. Up to 200&nbsp;MB per file. Files stay
          on this computer; only selected pages go to your AI provider.
        </p>
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={ACCEPT}
          className="sr-only"
          aria-label="Choose files to upload"
          onChange={(e) => {
            send(Array.from(e.target.files ?? []))
            e.target.value = ""
          }}
        />
        <Button size="sm" onClick={() => inputRef.current?.click()} disabled={upload.isPending}>
          {upload.isPending ? <LoaderCircleIcon aria-hidden className="animate-spin" /> : null}
          {upload.isPending ? "Uploading…" : "Choose files"}
        </Button>
      </div>

      {rejected.length ? (
        <Alert variant="destructive" role="alert">
          <CircleAlertIcon />
          <AlertTitle>Some files were not added</AlertTitle>
          <AlertDescription>
            <ul className="list-disc pl-4">
              {rejected.map((r) => (
                <li key={r} className="break-words">
                  {r}
                </li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      ) : null}

      {isPending ? (
        <Skeleton className="h-24 w-full" />
      ) : isError ? (
        <p className="text-sm text-destructive">{error.message}</p>
      ) : docs.length === 0 ? (
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <FileTextIcon />
            </EmptyMedia>
            <EmptyTitle>No documents yet</EmptyTitle>
            <EmptyDescription>
              Upload a report above, or{" "}
              <Link href={`/deal?id=${deal.id}&tab=data`} className="font-medium text-link underline-offset-2 hover:underline">
                type or paste the numbers
              </Link>{" "}
              instead.
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        <section aria-label="Documents" className="rounded-lg border">
          <div className="flex items-center justify-between gap-2 border-b px-4 py-2">
            <h2 className="text-sm font-medium">
              Documents <span className="text-muted-foreground">({docs.length})</span>
            </h2>
            {processed ? (
              <LinkButton href={`/deal?id=${deal.id}&tab=review`} size="sm" variant="outline">
                Review all values
              </LinkButton>
            ) : null}
          </div>
          <ul>
            {docs.map((doc) => (
              <DocumentRow key={doc.id} deal={deal} doc={doc} />
            ))}
          </ul>
        </section>
      )}
    </div>
  )
}
