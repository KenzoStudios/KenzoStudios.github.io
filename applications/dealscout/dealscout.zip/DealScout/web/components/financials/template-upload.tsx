"use client"

import * as React from "react"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Spinner } from "@/components/ui/spinner"
import { toast } from "@/components/ui/toast"
import { type TemplatePreview, useFinancialMutations } from "@/lib/queries"

export function TemplateUpload({ dealId, children }: { dealId: string; children: React.ReactNode }) {
  const { uploadTemplate } = useFinancialMutations(dealId)
  const [open, setOpen] = React.useState(false)
  const [file, setFile] = React.useState<File | null>(null)
  const [preview, setPreview] = React.useState<TemplatePreview | null>(null)
  const [error, setError] = React.useState<string | null>(null)

  const check = async (chosen: File) => {
    setFile(chosen)
    setError(null)
    try {
      setPreview(await uploadTemplate.mutateAsync({ file: chosen, apply: false }))
    } catch (e) {
      setPreview(null)
      setError((e as Error).message)
    }
  }

  const apply = async () => {
    if (!file) return
    try {
      const result = await uploadTemplate.mutateAsync({ file, apply: true })
      toast.add({
        title: "Template imported",
        description: `${result.counts?.created ?? 0} added, ${result.counts?.updated ?? 0} updated.`,
        type: "success",
      })
      setOpen(false)
      setFile(null)
      setPreview(null)
    } catch (e) {
      setError((e as Error).message)
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setFile(null); setPreview(null); setError(null) } }}>
      <DialogTrigger render={<Button variant="outline" size="sm" />}>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Upload a filled-in template</DialogTitle>
          <DialogDescription>
            Use the Excel template downloaded from this page. Only typed figures are imported; formula subtotals are recomputed.
          </DialogDescription>
        </DialogHeader>
        <label className="flex flex-col gap-2 text-sm font-medium">
          Template file (.xlsx)
          <input
            type="file"
            accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            className="text-sm file:mr-3 file:rounded-md file:border file:bg-muted file:px-3 file:py-1.5"
            onChange={(e) => {
              const chosen = e.target.files?.[0]
              if (chosen) void check(chosen)
            }}
          />
        </label>
        {uploadTemplate.isPending && !preview ? (
          <p className="flex items-center gap-2 text-sm text-muted-foreground"><Spinner /> Reading the workbook…</p>
        ) : null}
        {error ? (
          <Alert variant="destructive">
            <AlertTitle>This file could not be imported</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : null}
        {preview ? (
          <div className="flex flex-col gap-2 text-sm">
            <p>
              <span className="font-medium">{preview.cells}</span> figures in {preview.units} across {preview.periods.join(", ") || "no periods"}.
              {preview.new_periods.length ? ` New periods will be added: ${preview.new_periods.join(", ")}.` : ""}
            </p>
            {preview.warnings.length ? (
              <ul className="list-disc pl-5 text-xs text-muted-foreground">
                {preview.warnings.slice(0, 8).map((w) => <li key={w}>{w}</li>)}
              </ul>
            ) : null}
          </div>
        ) : null}
        <DialogFooter>
          <Button onClick={apply} disabled={!preview || !preview.cells || uploadTemplate.isPending}>
            {uploadTemplate.isPending && preview ? <Spinner data-icon="inline-start" /> : null}
            Import {preview?.cells ?? 0} figures
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
