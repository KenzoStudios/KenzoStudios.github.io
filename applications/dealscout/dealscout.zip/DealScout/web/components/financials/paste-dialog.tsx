"use client"

import * as React from "react"

import { SearchSelect } from "@/components/common/search-select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Field, FieldDescription, FieldLabel } from "@/components/ui/field"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Spinner } from "@/components/ui/spinner"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/toast"
import { formatAccounting, SCALE_NAME } from "@/lib/format"
import { useFinancialMutations } from "@/lib/queries"
import type { FinancialsResponse, PastePreview } from "@/lib/types"

const SCALES = [1, 1000, 1000000, 1000000000]

export function PasteDialog({ dealId, grid, children }: { dealId: string; grid: FinancialsResponse; children: React.ReactNode }) {
  const { paste, cells, addPeriod } = useFinancialMutations(dealId)
  const [open, setOpen] = React.useState(false)
  const [text, setText] = React.useState("")
  const [decimal, setDecimal] = React.useState<"auto" | "." | ",">("auto")
  const [preview, setPreview] = React.useState<PastePreview | null>(null)
  const [mapping, setMapping] = React.useState<Record<number, string | null>>({})
  const [include, setInclude] = React.useState<Record<number, boolean>>({})
  const [scale, setScale] = React.useState<number>(grid.entry.scale)
  const [importing, setImporting] = React.useState(false)
  const rowsByConcept = new Map(grid.statements.flatMap((s) => s.rows).map((r) => [r.concept_id, r]))

  const reset = () => {
    setText("")
    setPreview(null)
    setMapping({})
    setInclude({})
  }

  const runPreview = async () => {
    const result = await paste.mutateAsync({ text, decimal_hint: decimal === "auto" ? null : decimal })
    setPreview(result)
    setMapping(Object.fromEntries(result.rows.map((r, i) => [i, r.concept_id])))
    setInclude(Object.fromEntries(result.rows.map((r, i) => [i, !!r.concept_id])))
    if (result.scale) setScale(result.scale.factor)
  }

  const runImport = async () => {
    if (!preview) return
    setImporting(true)
    try {
      const existing = new Set(grid.periods.map((p) => p.key))
      for (const period of preview.periods) {
        if (!existing.has(period.key) && period.kind !== "projection") {
          await addPeriod.mutateAsync({ key: period.key, kind: period.kind })
        }
      }
      const changes = preview.rows.flatMap((row, i) => {
        const concept = mapping[i]
        if (!include[i] || !concept) return []
        const meta = rowsByConcept.get(concept)
        return Object.entries(row.values)
          .filter(([key, v]) => v !== null && preview.periods.some((p) => p.key === key && p.kind !== "projection"))
          .map(([period_key, v]) => {
            const scaled = meta && meta.unit !== "currency" ? (v as number) : (v as number) * scale
            const value = meta?.sign === "negative" ? -Math.abs(scaled) : scaled
            return { concept_id: concept, period_key, value, entered_text: String(v), reason: "Pasted from Excel" }
          })
      })
      if (!changes.length) {
        toast.add({ title: "Nothing to import", description: "Map at least one row to a line item.", type: "warning" })
        return
      }
      await cells.mutateAsync({ changes, source: "paste" })
      toast.add({ title: "Table imported", description: `${changes.length} values added or updated.`, type: "success" })
      setOpen(false)
      reset()
    } catch (error) {
      toast.add({ title: "Import failed", description: (error as Error).message, type: "error" })
    } finally {
      setImporting(false)
    }
  }

  const conceptOptions = React.useMemo(
    () => (preview?.concepts ?? []).map((c) => ({ value: c.id, label: c.name, hint: c.statement.replace("_", " ") })),
    [preview],
  )

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) reset() }}>
      <DialogTrigger render={<Button variant="outline" size="sm" />}>{children}</DialogTrigger>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle>Paste a table from Excel</DialogTitle>
          <DialogDescription>
            Copy the statement including its header row (years such as 2025, FY24, H1 2026). DealScout detects periods, units and
            line items; you confirm before anything is saved.
          </DialogDescription>
        </DialogHeader>
        {!preview ? (
          <div className="flex flex-col gap-3">
            <Field>
              <FieldLabel htmlFor="paste-text">Copied cells</FieldLabel>
              <Textarea
                id="paste-text"
                rows={10}
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder={"Line item\t2025\t2024\nRevenue\t1,234.5\t1,100.0\nCost of sales\t(800.1)\t(700.0)"}
                className="font-mono text-xs"
                spellCheck={false}
              />
            </Field>
            <Field className="max-w-xs">
              <FieldLabel htmlFor="paste-decimal">Decimal separator</FieldLabel>
              <Select
                items={[
                  { value: "auto", label: "Detect automatically" },
                  { value: ".", label: "Point (1,234.5)" },
                  { value: ",", label: "Comma (1.234,5)" },
                ]}
                value={decimal}
                onValueChange={(v) => setDecimal(v as typeof decimal)}
              >
                <SelectTrigger id="paste-decimal" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectItem value="auto">Detect automatically</SelectItem>
                    <SelectItem value=".">Point (1,234.5)</SelectItem>
                    <SelectItem value=",">Comma (1.234,5)</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
            </Field>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {preview.warnings.map((w) => (
              <Alert key={w}>
                <AlertTitle>Check before importing</AlertTitle>
                <AlertDescription>{w}</AlertDescription>
              </Alert>
            ))}
            <Field className="max-w-xs">
              <FieldLabel htmlFor="paste-scale">Units of the pasted figures</FieldLabel>
              <Select
                items={SCALES.map((s) => ({ value: String(s), label: `${grid.currency} ${SCALE_NAME[s]}` }))}
                value={String(scale)}
                onValueChange={(v) => setScale(Number(v))}
              >
                <SelectTrigger id="paste-scale" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    {SCALES.map((s) => (
                      <SelectItem key={s} value={String(s)}>
                        {grid.currency} {SCALE_NAME[s]}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
              <FieldDescription>
                {preview.scale ? `Detected “${preview.scale.matched}”.` : "No unit statement found in the pasted text."}
              </FieldDescription>
            </Field>
            <div className="relative overflow-x-auto rounded-md border">
              <table className="w-full text-[13px]">
                <thead className="bg-muted text-xs text-muted-foreground">
                  <tr>
                    <th className="w-10 px-2 py-2"><span className="sr-only">Import</span></th>
                    <th className="px-2 py-2 text-left">Pasted label</th>
                    <th className="min-w-56 px-2 py-2 text-left">Line item</th>
                    {preview.periods.map((p) => (
                      <th key={p.key} className="px-2 py-2 text-right">{p.key}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {preview.rows.map((row, i) => (
                    <tr key={i} className="border-t">
                      <td className="px-2 py-1">
                        <Checkbox
                          aria-label={`Import ${row.label}`}
                          checked={!!include[i]}
                          disabled={!mapping[i]}
                          onCheckedChange={(checked) => setInclude({ ...include, [i]: !!checked })}
                        />
                      </td>
                      <td className="max-w-56 truncate px-2 py-1" title={row.label}>{row.label}</td>
                      <td className="px-2 py-1">
                        <SearchSelect
                          options={[
                            ...row.candidates.map((c) => ({ value: c.id, label: c.name, hint: "suggested" })),
                            ...conceptOptions.filter((o) => !row.candidates.some((c) => c.id === o.value)),
                          ]}
                          value={mapping[i] ?? null}
                          onChange={(v) => {
                            setMapping({ ...mapping, [i]: v })
                            setInclude({ ...include, [i]: !!v })
                          }}
                          placeholder={row.candidates.length ? "Choose…" : "Not recognised: choose…"}
                        />
                      </td>
                      {preview.periods.map((p) => (
                        <td key={p.key} className="px-2 py-1 text-right tabular-nums">
                          {formatAccounting(row.values[p.key] ?? null, 1)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-muted-foreground">
              {preview.rows.length} rows · {preview.unmatched} not recognised. Costs are stored as negatives whatever their pasted sign.
              Projection columns (e.g. 2027E) are skipped.
            </p>
          </div>
        )}
        <DialogFooter>
          {preview ? (
            <>
              <Button variant="ghost" onClick={() => setPreview(null)} disabled={importing}>
                Back
              </Button>
              <Button onClick={runImport} disabled={importing}>
                {importing ? <Spinner data-icon="inline-start" /> : null}
                Import {Object.values(include).filter(Boolean).length} rows
              </Button>
            </>
          ) : (
            <Button onClick={runPreview} disabled={!text.trim() || paste.isPending}>
              {paste.isPending ? <Spinner data-icon="inline-start" /> : null}
              Preview
            </Button>
          )}
        </DialogFooter>
        {paste.isError ? <p role="alert" className="text-sm text-destructive">{paste.error.message}</p> : null}
      </DialogContent>
    </Dialog>
  )
}
