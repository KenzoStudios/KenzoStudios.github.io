"use client"

import * as React from "react"
import { useRouter, useSearchParams } from "next/navigation"
import {
  CheckCircle2Icon,
  CircleDashedIcon,
  CircleXIcon,
  ClipboardPasteIcon,
  DownloadIcon,
  PlusIcon,
  Redo2Icon,
  TriangleAlertIcon,
  Undo2Icon,
  UploadIcon,
} from "lucide-react"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/components/ui/toast"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import { formatScaled, SCALE_NAME } from "@/lib/format"
import { useFinancialMutations, useFinancials, useValueHistory } from "@/lib/queries"
import type { CellChangeInput, Deal, FinancialsResponse, GridRow } from "@/lib/types"

import { CurrencySection } from "./currency-section"
import { PasteDialog } from "./paste-dialog"
import { StatementGrid, type GridPosition } from "./statement-grid"
import { TemplateUpload } from "./template-upload"

const SCALES = [1, 1000, 1000000, 1000000000] as const

function inverseOf(grid: FinancialsResponse, changes: CellChangeInput[]): CellChangeInput[] {
  const rows = new Map(grid.statements.flatMap((s) => s.rows).map((r) => [r.concept_id, r]))
  return changes.map((c) => {
    const cell = rows.get(c.concept_id)?.cells[c.period_key]
    return { concept_id: c.concept_id, period_key: c.period_key, value: cell?.kind === "entered" ? cell.value : null, reason: "Undo" }
  })
}

function AddPeriod({ dealId }: { dealId: string }) {
  const { addPeriod } = useFinancialMutations(dealId)
  const [open, setOpen] = React.useState(false)
  const [key, setKey] = React.useState("")
  const [error, setError] = React.useState<string | null>(null)
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger render={<Button variant="outline" size="sm" />}>
        <PlusIcon data-icon="inline-start" />
        Period
      </PopoverTrigger>
      <PopoverContent className="w-72">
        <form
          className="flex flex-col gap-2"
          onSubmit={async (e) => {
            e.preventDefault()
            setError(null)
            try {
              await addPeriod.mutateAsync({ key: key.trim().toUpperCase() })
              setKey("")
              setOpen(false)
            } catch (err) {
              setError((err as Error).message)
            }
          }}
        >
          <label htmlFor="new-period" className="text-sm font-medium">
            Add a period
          </label>
          <Input
            id="new-period"
            value={key}
            onChange={(e) => setKey(e.target.value)}
            placeholder="FY2022, H1-2026, Q3-2025…"
            autoComplete="off"
            spellCheck={false}
            aria-invalid={!!error || undefined}
          />
          {error ? (
            <p role="alert" className="text-xs text-destructive">
              {error}
            </p>
          ) : (
            <p className="text-xs text-muted-foreground">Full years are used for valuation; interim periods feed LTM later.</p>
          )}
          <Button type="submit" size="sm" disabled={!key.trim() || addPeriod.isPending}>
            Add period
          </Button>
        </form>
      </PopoverContent>
    </Popover>
  )
}

function QuickScanChecklist({ grid, onJump }: { grid: FinancialsResponse; onJump: (concept: string) => void }) {
  const names = new Map(grid.statements.flatMap((s) => s.rows).map((r) => [r.concept_id, r.name]))
  const missing = new Set(grid.quick_scan.missing)
  const done = grid.quick_scan.minimum.length - missing.size
  return (
    <Card size="sm">
      <CardHeader>
        <CardTitle>Quick Scan minimum</CardTitle>
        <CardDescription>
          {done} of {grid.quick_scan.minimum.length} for {grid.quick_scan.period ?? "the latest year"}. Everything else is defaulted and
          labelled as such.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="flex flex-col gap-1 text-sm">
          {grid.quick_scan.minimum.map((concept) => (
            <li key={concept}>
              <button
                type="button"
                onClick={() => onJump(concept)}
                className="flex w-full items-center gap-2 rounded-sm px-1 py-0.5 text-left hover:bg-muted focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              >
                {missing.has(concept) ? (
                  <CircleDashedIcon aria-hidden className="size-4 shrink-0 text-muted-foreground" />
                ) : (
                  <CheckCircle2Icon aria-hidden className="size-4 shrink-0 text-positive" />
                )}
                <span className="truncate">{names.get(concept) ?? concept}</span>
                <span className="sr-only">{missing.has(concept) ? "missing" : "entered"}</span>
              </button>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

function ChecksPanel({ grid }: { grid: FinancialsResponse }) {
  const failing = grid.checks.filter((c) => c.status === "fail")
  const passing = grid.checks.filter((c) => c.status === "pass").length
  return (
    <Card size="sm">
      <CardHeader>
        <CardTitle>Reconciliation checks</CardTitle>
        <CardDescription>
          {passing} passed · {grid.check_summary.errors} errors · {grid.check_summary.warnings} warnings
        </CardDescription>
      </CardHeader>
      <CardContent>
        {failing.length === 0 ? (
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <CheckCircle2Icon aria-hidden className="size-4 text-positive" />
            {passing ? "Every applicable check passes." : "Checks run as soon as the figures they need are entered."}
          </p>
        ) : (
          <ul className="flex max-h-72 flex-col gap-2 overflow-y-auto text-sm" aria-label="Failed checks">
            {failing.map((c) => (
              <li key={`${c.check_id}-${c.period_id}`} className="flex items-start gap-2">
                {c.severity === "error" ? (
                  <CircleXIcon aria-hidden className="mt-0.5 size-4 shrink-0 text-negative" />
                ) : (
                  <TriangleAlertIcon aria-hidden className="mt-0.5 size-4 shrink-0 text-warning" />
                )}
                <span className="min-w-0">
                  <span className="font-medium">
                    {c.severity === "error" ? "Error" : "Warning"} · {c.period_id}
                  </span>{" "}
                  <span className="text-muted-foreground">{c.message}</span>
                  {c.difference !== null ? (
                    <span className="block text-xs text-muted-foreground tabular-nums">
                      Expected {formatScaled(c.expected, grid.entry.scale)} · actual {formatScaled(c.actual, grid.entry.scale)} ·
                      difference {formatScaled(c.difference, grid.entry.scale)}
                    </span>
                  ) : null}
                </span>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  )
}

function CellInspector({ dealId, grid, row, periodKey }: { dealId: string; grid: FinancialsResponse; row: GridRow; periodKey: string }) {
  const cell = row.cells[periodKey]
  const { data: history } = useValueHistory(dealId, row.concept_id, periodKey)
  const scale = grid.entry.scale
  return (
    <Card size="sm" aria-live="polite">
      <CardHeader>
        <CardTitle className="truncate" title={row.name}>
          {row.name} · {periodKey}
        </CardTitle>
        <CardDescription>{row.definition}</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-2 text-sm">
        {!cell ? (
          <p className="text-muted-foreground">Not entered. Type a value or paste from Excel.</p>
        ) : cell.kind === "computed" ? (
          <p>
            Computed: <code className="font-mono text-xs">{cell.formula}</code>
            {cell.note ? <span className="block text-xs text-warning">{cell.note}</span> : null}
          </p>
        ) : (
          <p>
            Entered {cell.source === "manual" ? "by hand" : `from ${cell.source}`} by {cell.updated_by}
            {cell.entered_text ? (
              <>
                {" "}
                as <code className="font-mono text-xs">{cell.entered_text}</code>
              </>
            ) : null}
            . Stored as {grid.currency} {formatScaled(cell.value, 1, 0)}.
          </p>
        )}
        {row.sign === "negative" ? (
          <p className="text-xs text-muted-foreground">A cost or outflow: type it as a positive amount; it is stored as negative.</p>
        ) : null}
        {history && history.length > 0 ? (
          <div>
            <p className="mb-1 text-xs font-medium text-muted-foreground">History</p>
            <ol className="flex flex-col gap-1 text-xs">
              {history.slice(0, 8).map((h) => (
                <li key={h.id} className="tabular-nums">
                  {new Date(h.at).toLocaleString()} · {h.actor}: {h.old_value === null ? "—" : formatScaled(h.old_value, scale)} →{" "}
                  {h.new_value === null ? "cleared" : formatScaled(h.new_value, scale)}
                  {h.reason ? <span className="text-muted-foreground"> ({h.reason})</span> : null}
                </li>
              ))}
            </ol>
          </div>
        ) : null}
      </CardContent>
    </Card>
  )
}

export function DataTab({ deal }: { deal: Deal }) {
  const { data: grid, isPending, isError, error, refetch } = useFinancials(deal.id)
  const { cells, entry } = useFinancialMutations(deal.id)
  // the statement sub-tab lives in the URL (&stmt=balance_sheet) so links and the back button keep it
  const params = useSearchParams()
  const router = useRouter()
  const statementId = params.get("stmt") ?? "income_statement"
  const setStatementId = (id: string) => {
    const next = new URLSearchParams(params.toString())
    next.set("stmt", id)
    router.replace(`/deal?${next.toString()}`, { scroll: false })
  }
  const [selected, setSelected] = React.useState<GridPosition | null>(null)
  const undoStack = React.useRef<CellChangeInput[][]>([])
  const redoStack = React.useRef<CellChangeInput[][]>([])
  const [depth, setDepth] = React.useState({ undo: 0, redo: 0 })
  const sync = () => setDepth({ undo: undoStack.current.length, redo: redoStack.current.length })

  if (isPending) return <Skeleton className="h-96 w-full" />
  if (isError || !grid) {
    return (
      <Alert variant="destructive">
        <AlertTitle>Financial data could not be loaded</AlertTitle>
        <AlertDescription>
          {error?.message}{" "}
          <Button variant="outline" size="sm" className="ml-2" onClick={() => refetch()}>
            Try again
          </Button>
        </AlertDescription>
      </Alert>
    )
  }

  const statement = grid.statements.find((s) => s.id === statementId) ?? grid.statements[0]
  const selectedRow = selected ? statement.rows[selected.row] : null
  const selectedPeriod = selected ? grid.periods[selected.col]?.key : null

  const save = async (changes: CellChangeInput[], record: "undo" | "redo" | "new" = "new") => {
    const inverse = inverseOf(grid, changes)
    try {
      await cells.mutateAsync({ changes, source: "manual" })
      if (record === "new") {
        undoStack.current.push(inverse)
        redoStack.current = []
      } else if (record === "undo") {
        redoStack.current.push(inverse)
      } else {
        undoStack.current.push(inverse)
      }
      sync()
    } catch (err) {
      toast.add({ title: "Not saved", description: (err as Error).message, type: "error" })
    }
  }
  const undo = () => {
    const batch = undoStack.current.pop()
    if (batch) void save(batch, "undo")
  }
  const redo = () => {
    const batch = redoStack.current.pop()
    if (batch) void save(batch, "redo")
  }
  const jumpTo = (concept: string) => {
    const target = grid.statements.find((s) => s.rows.some((r) => r.concept_id === concept))
    if (!target) return
    setStatementId(target.id)
    const row = target.rows.findIndex((r) => r.concept_id === concept)
    const col = Math.max(grid.periods.findIndex((p) => p.key === grid.quick_scan.period), 0)
    setSelected({ row, col })
    requestAnimationFrame(() => document.querySelector<HTMLElement>(`[data-cell="${row}-${col}"]`)?.focus())
  }

  return (
    <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_20rem]">
      <div className="flex min-w-0 flex-col gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <Tabs className="max-w-full overflow-x-auto" value={statement.id} onValueChange={(v) => { setStatementId(v as string); setSelected(null) }}>
            <TabsList>
              {grid.statements.map((s) => (
                <TabsTrigger key={s.id} value={s.id}>
                  {s.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <Select
              items={SCALES.map((s) => ({ value: String(s), label: `${grid.currency} ${SCALE_NAME[s]}` }))}
              value={String(grid.entry.scale)}
              onValueChange={(v) => entry.mutate({ scale: Number(v) })}
            >
              <SelectTrigger size="sm" aria-label="Units for entering and showing figures" className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {SCALES.map((s) => (
                    <SelectItem key={s} value={String(s)}>
                      {grid.currency} {SCALE_NAME[s]}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
            <Tooltip>
              <TooltipTrigger
                render={<Button variant="ghost" size="icon-sm" aria-label="Undo" disabled={!depth.undo} onClick={undo} />}
              >
                <Undo2Icon />
              </TooltipTrigger>
              <TooltipContent>Undo (Ctrl/Cmd+Z)</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger
                render={<Button variant="ghost" size="icon-sm" aria-label="Redo" disabled={!depth.redo} onClick={redo} />}
              >
                <Redo2Icon />
              </TooltipTrigger>
              <TooltipContent>Redo (Ctrl/Cmd+Shift+Z)</TooltipContent>
            </Tooltip>
            <AddPeriod dealId={deal.id} />
            <PasteDialog dealId={deal.id} grid={grid}>
              <ClipboardPasteIcon data-icon="inline-start" />
              Paste table
            </PasteDialog>
            <Button variant="outline" size="sm" nativeButton={false} render={<a href={`/api/deals/${deal.id}/template.xlsx`} download />}>
              <DownloadIcon data-icon="inline-start" />
              Excel template
            </Button>
            <TemplateUpload dealId={deal.id}>
              <UploadIcon data-icon="inline-start" />
              Upload filled template
            </TemplateUpload>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">
          Figures in {grid.currency} {SCALE_NAME[grid.entry.scale]} (per-share in {grid.currency}, share counts in units). Type costs and
          outflows as positive amounts. <span className="italic">Italic</span> figures are computed from their lines; type over them to
          record the reported subtotal.
          {cells.isPending ? <Badge variant="outline" className="ml-2">Saving…</Badge> : null}
        </p>
        <StatementGrid
          rows={statement.rows}
          periods={grid.periods}
          ltmPeriods={grid.ltm_periods ?? []}
          scale={grid.entry.scale}
          decimalHint={grid.entry.decimal_hint}
          checks={grid.checks}
          selected={selected}
          onSelect={setSelected}
          onCommit={(changes) => void save(changes)}
          onUndo={undo}
          onRedo={redo}
          caption={`${statement.label}, ${grid.currency} ${SCALE_NAME[grid.entry.scale]}`}
        />
        <div id="currency">
          <CurrencySection dealId={deal.id} />
        </div>
      </div>
      <aside className="flex flex-col gap-3" aria-label="Data checks and details">
        {selectedRow && selectedPeriod ? (
          <CellInspector dealId={deal.id} grid={grid} row={selectedRow} periodKey={selectedPeriod} />
        ) : null}
        <QuickScanChecklist grid={grid} onJump={jumpTo} />
        <ChecksPanel grid={grid} />
      </aside>
    </div>
  )
}
