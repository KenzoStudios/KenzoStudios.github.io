"use client"

import * as React from "react"
import { AlertTriangleIcon, CircleXIcon, FunctionSquareIcon } from "lucide-react"

import { formatScaled, parseCellInput } from "@/lib/format"
import type { CellChangeInput, CheckResult, GridRow, LtmPeriod, Period } from "@/lib/types"
import { cn } from "@/lib/utils"

/** Units whose values are entered in the sheet scale (currency); others are entered as-is. */
const SCALED_UNITS = new Set(["currency"])

export interface GridPosition {
  row: number
  col: number
}

/** The signed value stored for what the analyst typed: costs and outflows can be typed as positive amounts. */
export function storedValue(row: GridRow, typed: number, scale: number): number {
  const scaled = SCALED_UNITS.has(row.unit) ? typed * scale : typed
  return row.sign === "negative" ? -Math.abs(scaled) : scaled
}

function displayValue(row: GridRow, value: number, scale: number): string {
  if (row.unit === "percent") return `${(value * 100).toFixed(1)}%`
  if (row.unit === "per_share") return formatScaled(value, 1, 2)
  if (row.unit === "shares" || row.unit === "count") return formatScaled(value, 1, 0)
  return formatScaled(value, scale, 1)
}

function editText(row: GridRow, value: number | undefined, scale: number): string {
  if (value === undefined) return ""
  if (row.unit === "percent") return String(+(value * 100).toFixed(6)) + "%"
  const shown = SCALED_UNITS.has(row.unit) ? value / scale : value
  const magnitude = row.sign === "negative" ? Math.abs(shown) : shown
  return String(+magnitude.toFixed(6))
}

export function StatementGrid({
  rows,
  periods,
  ltmPeriods = [],
  scale,
  decimalHint,
  checks,
  selected,
  onSelect,
  onCommit,
  onUndo,
  onRedo,
  disabled,
  caption,
}: {
  rows: GridRow[]
  periods: Period[]
  ltmPeriods?: LtmPeriod[]
  scale: number
  decimalHint: "." | "," | null
  checks: CheckResult[]
  selected: GridPosition | null
  onSelect: (position: GridPosition | null) => void
  onCommit: (changes: CellChangeInput[]) => void
  onUndo: () => void
  onRedo: () => void
  disabled?: boolean
  caption: string
}) {
  type EditState = { position: GridPosition; text: string; error: boolean } | null
  const [editing, setEditingState] = React.useState<EditState>(null)
  // A ref mirrors the edit state so keystrokes that arrive before React re-renders (fast typing) are not lost.
  const editingRef = React.useRef<EditState>(null)
  const setEditing = React.useCallback((next: EditState) => {
    editingRef.current = next
    setEditingState(next)
  }, [])
  const tableRef = React.useRef<HTMLTableElement>(null)
  const inputRef = React.useRef<HTMLInputElement>(null)
  const committedRef = React.useRef(false)

  const flags = React.useMemo(() => {
    const map = new Map<string, CheckResult[]>()
    for (const check of checks) {
      if (check.status !== "fail") continue
      const [, concept] = check.check_id.split(":")
      const targets =
        check.check_id === "balance_sheet_balances"
          ? ["total_assets", "total_liabilities_and_equity"]
          : check.check_id === "cash_roll_forward" || check.check_id === "cash_ties_to_balance_sheet"
            ? ["cash_ending"]
            : check.check_id === "net_income_ties"
              ? ["cf_net_income"]
              : concept
                ? [concept]
                : []
      for (const target of targets) {
        const key = `${target}|${check.period_id}`
        map.set(key, [...(map.get(key) ?? []), check])
      }
    }
    return map
  }, [checks])

  React.useEffect(() => {
    if (editing) inputRef.current?.focus()
  }, [editing])

  const focusCell = React.useCallback((position: GridPosition) => {
    const cell = tableRef.current?.querySelector<HTMLElement>(`[data-cell="${position.row}-${position.col}"]`)
    cell?.focus()
  }, [])

  const move = (position: GridPosition, dRow: number, dCol: number) => {
    const next = {
      row: Math.min(Math.max(position.row + dRow, 0), rows.length - 1),
      col: Math.min(Math.max(position.col + dCol, 0), periods.length - 1),
    }
    onSelect(next)
    requestAnimationFrame(() => focusCell(next))
  }

  const commitEdit = (dRow: number, dCol: number) => {
    const current = editingRef.current
    if (!current || committedRef.current) return
    const { position, text } = current
    const row = rows[position.row]
    const period = periods[position.col]
    const parsed = parseCellInput(text, decimalHint)
    if (parsed === undefined) {
      setEditing({ ...current, error: true })
      return
    }
    committedRef.current = true
    const existing = row.cells[period.key]
    const currentEntered = existing?.kind === "entered" ? existing.value : undefined
    const next = parsed === null ? null : storedValue(row, parsed, scale)
    if (next !== (currentEntered ?? null)) {
      onCommit([{ concept_id: row.concept_id, period_key: period.key, value: next, entered_text: text.trim() || null }])
    }
    setEditing(null)
    move(position, dRow, dCol)
  }

  const startEdit = (position: GridPosition, initial?: string) => {
    if (disabled) return
    const row = rows[position.row]
    const cell = row.cells[periods[position.col].key]
    const text = initial ?? editText(row, cell?.kind === "entered" ? cell.value : undefined, scale)
    committedRef.current = false
    setEditing({ position, text, error: false })
  }

  const onCellKeyDown = (event: React.KeyboardEvent, position: GridPosition) => {
    // Keys typed in the edit box bubble up to the cell: the box handles its own keys.
    if (event.target !== event.currentTarget) return
    const mod = event.metaKey || event.ctrlKey
    const pending = editingRef.current
    if (pending) {
      // the edit box is opening; keep the keystrokes typed meanwhile
      if (!mod && event.key.length === 1) {
        event.preventDefault()
        setEditing({ ...pending, text: pending.text + event.key, error: false })
      } else if (event.key === "Enter" || event.key === "Tab") {
        event.preventDefault()
        commitEdit(event.key === "Enter" ? 1 : 0, event.key === "Tab" ? 1 : 0)
      } else if (event.key === "Escape") {
        committedRef.current = true
        setEditing(null)
      }
      return
    }
    if (mod && event.key.toLowerCase() === "z") {
      event.preventDefault()
      if (event.shiftKey) onRedo()
      else onUndo()
      return
    }
    if (mod && event.key.toLowerCase() === "y") {
      event.preventDefault()
      onRedo()
      return
    }
    switch (event.key) {
      case "ArrowUp":
        event.preventDefault()
        return move(position, -1, 0)
      case "ArrowDown":
        event.preventDefault()
        return move(position, 1, 0)
      case "ArrowLeft":
        event.preventDefault()
        return move(position, 0, -1)
      case "ArrowRight":
        event.preventDefault()
        return move(position, 0, 1)
      case "Tab":
        if (position.col < periods.length - 1 || event.shiftKey) {
          event.preventDefault()
          return move(position, 0, event.shiftKey ? -1 : 1)
        }
        return
      case "Enter":
      case "F2":
        event.preventDefault()
        return startEdit(position)
      case "Delete":
      case "Backspace": {
        event.preventDefault()
        const row = rows[position.row]
        const period = periods[position.col]
        if (row.cells[period.key]?.kind === "entered") {
          onCommit([{ concept_id: row.concept_id, period_key: period.key, value: null }])
        }
        return
      }
      case "Escape":
        return onSelect(null)
    }
    if (!mod && event.key.length === 1 && /[\d.,()\-−%]/.test(event.key)) {
      event.preventDefault()
      startEdit(position, event.key)
    }
  }

  const onPaste = (event: React.ClipboardEvent, position: GridPosition) => {
    if (disabled || editing || event.target !== event.currentTarget) return
    const text = event.clipboardData.getData("text/plain")
    if (!text) return
    event.preventDefault()
    const lines = text.replace(/\r/g, "").split("\n").filter((line, i, all) => line !== "" || i < all.length - 1)
    const changes: CellChangeInput[] = []
    lines.forEach((line, dr) => {
      line.split("\t").forEach((raw, dc) => {
        const row = rows[position.row + dr]
        const period = periods[position.col + dc]
        if (!row || !period || row.aggregation === "formula") return
        const parsed = parseCellInput(raw, decimalHint)
        if (parsed === undefined) return
        changes.push({
          concept_id: row.concept_id,
          period_key: period.key,
          value: parsed === null ? null : storedValue(row, parsed, scale),
          entered_text: raw.trim() || null,
        })
      })
    })
    if (changes.length) onCommit(changes)
  }

  return (
    <div className="relative overflow-auto rounded-lg border" style={{ maxHeight: "calc(100dvh - 15rem)" }}>
      <table ref={tableRef} className="w-full border-separate border-spacing-0 text-[13px]" role="grid" aria-label={caption}>
        <caption className="sr-only">
          {caption}. Arrow keys move, Enter or typing edits, Delete clears, Ctrl or Cmd+Z undoes. Costs can be typed as positive
          amounts.
        </caption>
        <thead className="sticky top-0 z-20">
          <tr>
            <th
              scope="col"
              className="sticky left-0 z-30 min-w-64 border-b bg-muted px-3 py-2 text-left text-xs font-medium text-muted-foreground"
            >
              Line item
            </th>
            {periods.map((p) => (
              <th
                key={p.key}
                scope="col"
                className="min-w-28 border-b bg-muted px-3 py-2 text-right text-xs font-medium text-muted-foreground"
              >
                <span translate="no">{p.label ?? p.key}</span>
                {p.end_date ? <span className="block text-[10px] font-normal">{p.end_date}</span> : null}
              </th>
            ))}
            {ltmPeriods.map((p) => (
              <th
                key={p.key}
                scope="col"
                title={`Last twelve months: ${p.inputs[0]} + ${p.inputs[1]} − ${p.inputs[2]}. Computed, not editable.`}
                className="min-w-28 border-b border-l bg-muted px-3 py-2 text-right text-xs font-medium text-muted-foreground"
              >
                <span translate="no">{p.label}</span>
                <span className="block text-[10px] font-normal">computed</span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, r) => {
            const subtotal = row.aggregation !== "leaf"
            return (
              <tr key={row.concept_id} className={cn("group/row", subtotal && "font-medium")}>
                <th
                  scope="row"
                  title={row.definition}
                  className={cn(
                    "sticky left-0 z-10 max-w-80 truncate border-b bg-background px-3 py-1.5 text-left font-normal group-hover/row:bg-muted",
                    subtotal && "font-semibold",
                  )}
                  style={{ paddingLeft: `${0.75 + row.indent * 1.1}rem` }}
                >
                  {row.name}
                  {row.sign === "negative" ? <span className="sr-only"> (cost or outflow: type as a positive amount)</span> : null}
                </th>
                {periods.map((period, c) => {
                  const cell = row.cells[period.key]
                  const isSelected = selected?.row === r && selected?.col === c
                  const isEditing = editing?.position.row === r && editing?.position.col === c
                  const cellFlags = flags.get(`${row.concept_id}|${period.key}`) ?? []
                  const severity = cellFlags.some((f) => f.severity === "error") ? "error" : cellFlags.length ? "warning" : null
                  const computed = cell?.kind === "computed"
                  const label = `${row.name}, ${period.key}: ${cell ? displayValue(row, cell.value, scale) : "empty"}${
                    computed ? " (computed)" : ""
                  }${severity ? `: ${cellFlags.map((f) => f.message).join(" ")}` : ""}`
                  return (
                    <td
                      key={period.key}
                      data-cell={`${r}-${c}`}
                      role="gridcell"
                      tabIndex={isSelected || (!selected && r === 0 && c === 0) ? 0 : -1}
                      aria-selected={isSelected}
                      aria-label={label}
                      title={severity ? cellFlags.map((f) => f.message).join("\n") : computed ? `Computed: ${cell.formula ?? ""}` : undefined}
                      onClick={() => onSelect({ row: r, col: c })}
                      onDoubleClick={() => startEdit({ row: r, col: c })}
                      onKeyDown={(e) => onCellKeyDown(e, { row: r, col: c })}
                      onPaste={(e) => onPaste(e, { row: r, col: c })}
                      className={cn(
                        "relative h-8 border-b px-3 text-right tabular-nums outline-none group-hover/row:bg-muted/60",
                        computed && "text-muted-foreground italic",
                        cell?.kind === "entered" && cell.source !== "manual" && "text-link",
                        severity === "error" && "bg-negative-bg",
                        severity === "warning" && "bg-warning-bg",
                        isSelected && "z-10 ring-2 ring-ring ring-inset",
                      )}
                    >
                      {isEditing && editing ? (
                        <input
                          ref={inputRef}
                          value={editing.text}
                          inputMode="decimal"
                          aria-label={`Edit ${row.name}, ${period.key}`}
                          aria-invalid={editing.error || undefined}
                          className={cn(
                            "absolute inset-0 w-full bg-background px-3 text-right tabular-nums outline-none ring-2 ring-ring ring-inset",
                            editing.error && "ring-destructive",
                          )}
                          onChange={(e) => setEditing({ ...editing, text: e.target.value, error: false })}
                          onFocus={(e) => {
                            const end = e.currentTarget.value.length
                            e.currentTarget.setSelectionRange(end, end)
                          }}
                          onBlur={() => commitEdit(0, 0)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault()
                              commitEdit(e.shiftKey ? -1 : 1, 0)
                            } else if (e.key === "Tab") {
                              e.preventDefault()
                              commitEdit(0, e.shiftKey ? -1 : 1)
                            } else if (e.key === "Escape") {
                              e.preventDefault()
                              committedRef.current = true
                              setEditing(null)
                              focusCell({ row: r, col: c })
                            }
                          }}
                        />
                      ) : (
                        <span className="inline-flex items-center justify-end gap-1">
                          {severity === "error" ? (
                            <CircleXIcon aria-hidden className="size-3.5 shrink-0 text-negative" />
                          ) : severity === "warning" ? (
                            <AlertTriangleIcon aria-hidden className="size-3.5 shrink-0 text-warning" />
                          ) : computed ? (
                            <FunctionSquareIcon aria-hidden className="size-3 shrink-0 opacity-60" />
                          ) : null}
                          {cell ? displayValue(row, cell.value, scale) : ""}
                        </span>
                      )}
                    </td>
                  )
                })}
                {ltmPeriods.map((p) => {
                  const cell = row.cells[p.key]
                  return (
                    <td
                      key={p.key}
                      title={cell ? `Computed: ${cell.formula ?? ""}` : undefined}
                      aria-label={`${row.name}, ${p.label}: ${cell ? displayValue(row, cell.value, scale) : "empty"} (computed)`}
                      className="h-8 border-b border-l px-3 text-right text-muted-foreground italic tabular-nums group-hover/row:bg-muted/60"
                    >
                      {cell ? displayValue(row, cell.value, scale) : ""}
                    </td>
                  )
                })}
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
