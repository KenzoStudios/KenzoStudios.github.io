"use client"

import * as React from "react"
import { PlusIcon, Trash2Icon, TriangleAlertIcon } from "lucide-react"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/toast"
import { parseCellInput } from "@/lib/format"
import { useFx, useSaveFx } from "@/lib/queries"
import type { FxDoc, FxRate, PeerRate, PeriodRates } from "@/lib/types"

type Kind = "average" | "closing"
type RateDraft = { rate: string; as_of: string; source: string }
type PeriodDraft = Record<Kind, RateDraft>
type PeerDraft = RateDraft & { currency: string }

const EMPTY: RateDraft = { rate: "", as_of: "", source: "" }
const BLANK_PERIOD: PeriodDraft = { average: EMPTY, closing: EMPTY }

const toDraft = (r: FxRate | null | undefined): RateDraft =>
  r ? { rate: String(r.rate), as_of: r.as_of, source: r.source } : { ...EMPTY }

function draftsFrom(doc: FxDoc): { periods: Record<string, PeriodDraft>; peers: PeerDraft[] } {
  const periods: Record<string, PeriodDraft> = {}
  for (const p of doc.periods) {
    const stored = doc.rates.find((r) => r.period_id === p.key)
    periods[p.key] = { average: toDraft(stored?.average), closing: toDraft(stored?.closing) }
  }
  const peers: PeerDraft[] = doc.peer_rates.map((r) => ({ currency: r.currency, ...toDraft(r) }))
  for (const c of doc.missing_peer_currencies) peers.push({ currency: c, ...EMPTY })
  return { periods, peers }
}

/** A filled rate, `null` when left blank, or an error message. */
function parseRate(d: RateDraft, label: string): FxRate | null | string {
  const blank = !d.rate.trim() && !d.as_of.trim() && !d.source.trim()
  if (blank) return null
  const rate = parseCellInput(d.rate)
  if (rate === undefined || rate === null || rate <= 0) return `${label}: the rate must be a positive number`
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d.as_of)) return `${label}: enter the date the rate applies to`
  if (!d.source.trim()) return `${label}: say where the rate comes from`
  return { rate, as_of: d.as_of, source: d.source.trim() }
}

const cellInput =
  "h-7 w-full rounded-md border border-input bg-transparent px-2 text-[13px] focus:border-ring focus:outline-none aria-invalid:border-destructive"

function RateInputs({ label, value, onChange, needed }: { label: string; value: RateDraft; onChange: (v: RateDraft) => void; needed: boolean }) {
  const missing = needed && !value.rate.trim()
  return (
    <>
      <td className="px-1 py-1">
        <input aria-label={`${label} rate`} inputMode="decimal" value={value.rate} placeholder={needed ? "Needed" : ""}
          aria-invalid={missing || undefined} onChange={(e) => onChange({ ...value, rate: e.target.value })}
          className={`${cellInput} text-right tabular-nums`} />
      </td>
      <td className="px-1 py-1">
        <input aria-label={`${label} date`} type="date" value={value.as_of} onChange={(e) => onChange({ ...value, as_of: e.target.value })}
          className={`${cellInput} tabular-nums`} />
      </td>
      <td className="px-1 py-1">
        <input aria-label={`${label} source`} value={value.source} placeholder="e.g. central bank reference rate" maxLength={300}
          onChange={(e) => onChange({ ...value, source: e.target.value })} className={cellInput} />
      </td>
    </>
  )
}

export function CurrencySection({ dealId }: { dealId: string }) {
  const { data: doc, isPending, isError, error } = useFx(dealId)
  const save = useSaveFx(dealId)
  const [draft, setDraft] = React.useState<ReturnType<typeof draftsFrom> | null>(null)
  if (isPending) return null
  if (isError || !doc) {
    return (
      <Alert variant="destructive">
        <AlertTitle>Currency settings could not be loaded</AlertTitle>
        <AlertDescription>{error?.message}</AlertDescription>
      </Alert>
    )
  }
  const current = draft ?? draftsFrom(doc)
  const dirty = draft !== null
  const from = doc.reporting_currency
  const to = doc.analysis_currency
  const showPeers = current.peers.length > 0 || doc.peer_currencies.length > 0

  const persist = async () => {
    const errors: string[] = []
    const rates: PeriodRates[] = []
    for (const [key, d] of Object.entries(current.periods)) {
      const average = parseRate(d.average, `${key} average`)
      const closing = parseRate(d.closing, `${key} closing`)
      for (const r of [average, closing]) if (typeof r === "string") errors.push(r)
      if (typeof average !== "string" && typeof closing !== "string" && (average || closing)) {
        rates.push({ period_id: key, average, closing })
      }
    }
    const peer_rates: PeerRate[] = []
    for (const d of current.peers) {
      const code = d.currency.trim().toUpperCase()
      const r = parseRate(d, code || "Peer currency")
      if (typeof r === "string") errors.push(r)
      else if (r) {
        if (!/^[A-Z]{3}$/.test(code)) errors.push(`"${d.currency}" is not a three-letter currency code`)
        else peer_rates.push({ currency: code, ...r })
      }
    }
    if (errors.length) {
      toast.add({ title: "Some rates are incomplete", description: errors.slice(0, 4).join("; "), type: "error" })
      return
    }
    try {
      await save.mutateAsync({ rates, peer_rates })
      setDraft(null)
      toast.add({ title: "Rates saved", type: "success" })
    } catch (err) {
      toast.add({ title: "Rates not saved", description: (err as Error).message, type: "error" })
    }
  }

  const setPeriod = (key: string, kind: Kind, v: RateDraft) =>
    setDraft({ ...current, periods: { ...current.periods, [key]: { ...(current.periods[key] ?? BLANK_PERIOD), [kind]: v } } })
  const setPeer = (i: number, v: PeerDraft) => setDraft({ ...current, peers: current.peers.map((p, j) => (j === i ? v : p)) })

  if (!doc.needs_conversion && !showPeers) {
    return (
      <Card size="sm">
        <CardHeader>
          <CardTitle>Currency</CardTitle>
          <CardDescription>
            Reported and analysed in {from}: no conversion needed. To analyse in another currency, change the analysis currency in the
            deal details; peers reported in other currencies can be given a currency in the peers table.
          </CardDescription>
        </CardHeader>
      </Card>
    )
  }

  return (
    <Card size="sm" aria-labelledby="currency-title">
      <CardHeader>
        <CardTitle id="currency-title">Currency</CardTitle>
        <CardDescription>
          {doc.needs_conversion ? (
            <>
              Reported in {from}, analysed in {to}. Enter each rate as {to} per 1 {from}, with the date it applies to and its source:
              the average rate for the year converts the income statement and cash flow, the closing rate converts the balance sheet.
              DealScout never assumes a rate.
            </>
          ) : (
            <>Reported and analysed in {from}.</>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        {doc.status.message ? (
          <Alert>
            <TriangleAlertIcon aria-hidden />
            <AlertTitle>Rates missing</AlertTitle>
            <AlertDescription>{doc.status.message}</AlertDescription>
          </Alert>
        ) : doc.status.converted ? (
          <p className="text-xs text-muted-foreground">
            <Badge variant="positive" className="mr-2">Converted</Badge>
            The analysis, valuation and price are shown in {to}.
          </p>
        ) : null}
        {doc.needs_conversion ? (
          <div className="relative overflow-x-auto rounded-lg border">
            <table className="w-full min-w-[56rem] text-[13px]">
              <caption className="sr-only">FX rates per period, {to} per 1 {from}</caption>
              <thead className="bg-muted text-xs text-muted-foreground">
                <tr>
                  <th rowSpan={2} className="px-2 py-1 text-left font-medium">Period</th>
                  <th colSpan={3} className="px-2 py-1 text-left font-medium">Average rate (income and cash flow)</th>
                  <th colSpan={3} className="border-l px-2 py-1 text-left font-medium">Closing rate (balance sheet)</th>
                </tr>
                <tr>
                  {["Rate", "Date", "Source", "Rate", "Date", "Source"].map((h, i) => (
                    <th key={i} className={`px-2 py-1 text-left font-normal ${i === 3 ? "border-l" : ""}`}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {doc.periods.map((p) => (
                  <tr key={p.key} className="border-t">
                    <th scope="row" className="px-2 py-1 text-left font-medium whitespace-nowrap">
                      {p.key}
                      {p.needs.length === 0 ? <span className="block text-xs font-normal text-muted-foreground">No figures yet</span> : null}
                    </th>
                    <RateInputs label={`${p.key} average`} value={(current.periods[p.key] ?? BLANK_PERIOD).average} needed={p.needs.includes("average")}
                      onChange={(v) => setPeriod(p.key, "average", v)} />
                    <RateInputs label={`${p.key} closing`} value={(current.periods[p.key] ?? BLANK_PERIOD).closing} needed={p.needs.includes("closing")}
                      onChange={(v) => setPeriod(p.key, "closing", v)} />
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
        {showPeers ? (
          <div className="flex flex-col gap-2">
            <p className="text-xs text-muted-foreground">
              Peer currencies: {to} per 1 unit of the peer&apos;s currency. One rate converts all of a peer&apos;s figures, so its multiples do
              not change; a peer whose currency has no rate is left out of the statistics until one is entered.
            </p>
            <div className="relative overflow-x-auto rounded-lg border">
              <table className="w-full min-w-[40rem] text-[13px]">
                <caption className="sr-only">FX rates for peer currencies</caption>
                <thead className="bg-muted text-xs text-muted-foreground">
                  <tr>
                    {["Currency", `Rate (${to} per unit)`, "Date", "Source", ""].map((h, i) => (
                      <th key={i} className="px-2 py-1 text-left font-medium">{h ? h : <span className="sr-only">Remove</span>}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {current.peers.map((d, i) => (
                    <tr key={i} className="border-t">
                      <td className="w-24 px-1 py-1">
                        <input aria-label="Peer currency code" value={d.currency} maxLength={3} spellCheck={false}
                          onChange={(e) => setPeer(i, { ...d, currency: e.target.value.toUpperCase() })} className={`${cellInput} font-mono`} />
                      </td>
                      <RateInputs label={d.currency || "Peer currency"} value={d} needed={doc.missing_peer_currencies.includes(d.currency)}
                        onChange={(v) => setPeer(i, { ...d, ...v })} />
                      <td className="w-10 px-1">
                        <Button variant="ghost" size="icon-xs" aria-label={`Remove ${d.currency || "rate"}`}
                          onClick={() => setDraft({ ...current, peers: current.peers.filter((_, j) => j !== i) })}>
                          <Trash2Icon />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : null}
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={() => setDraft({ ...current, peers: [...current.peers, { currency: "", ...EMPTY }] })}>
            <PlusIcon data-icon="inline-start" />
            Peer currency
          </Button>
          <Button size="sm" disabled={!dirty || save.isPending} onClick={() => void persist()}>Save rates</Button>
          {dirty ? <Button variant="ghost" size="sm" onClick={() => setDraft(null)}>Discard changes</Button> : null}
        </div>
      </CardContent>
    </Card>
  )
}
