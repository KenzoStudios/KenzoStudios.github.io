"use client"

import * as React from "react"
import { GitCompareArrowsIcon, HistoryIcon, SaveIcon } from "lucide-react"

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Skeleton } from "@/components/ui/skeleton"
import { Spinner } from "@/components/ui/spinner"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/toast"
import { formatMoneyCompact, formatPct } from "@/lib/format"
import { useVersionComparison, useVersionMutations, useVersions } from "@/lib/queries"
import type { DealVersion, VersionComparison } from "@/lib/types"

const RESULT_LABEL: Record<string, string> = {
  blended_equity_low: "Equity value, low",
  blended_equity_mid: "Equity value, mid",
  blended_equity_high: "Equity value, high",
  dcf_enterprise_value: "DCF enterprise value",
}

const SECTION_LABEL: Record<string, string> = {
  deal: "Deal details",
  overrides: "Assumptions",
  peers: "Peers",
  notes: "Notes",
  entry: "Entry settings",
  methods: "Method inputs",
  assumptions: "Other settings",
}

const INPUT_LABEL: Record<string, string> = {
  projection_years: "Explicit forecast years",
  revenue_growth: "Revenue growth",
  ebitda_margin: "EBITDA margin",
  da_pct_revenue: "D&A % of revenue",
  capex_pct_revenue: "Capex % of revenue",
  nwc_pct_revenue: "Net working capital % of revenue",
  tax_rate: "Tax rate",
  risk_free_rate: "Risk-free rate",
  equity_risk_premium: "Equity risk premium",
  country_risk_premium: "Country risk premium",
  unlevered_beta: "Unlevered beta",
  levered_beta: "Levered beta",
  size_premium: "Size premium",
  company_specific_premium: "Company-specific premium",
  pre_tax_cost_of_debt: "Pre-tax cost of debt",
  target_debt_to_capital: "Target debt to capital",
  terminal_growth: "Terminal growth",
  exit_multiple: "Exit EV/EBITDA",
  terminal_method: "Terminal value method",
  mid_year: "Mid-year discounting",
  method_weights: "Method weights",
  valuation_date: "Valuation date",
  reporting_currency: "Reporting currency",
  analysis_currency: "Analysis currency",
  scenarios: "DCF scenarios",
}

function inputLabel(key: string): string {
  const text = INPUT_LABEL[key] ?? key.replaceAll("_", " ")
  return text.charAt(0).toUpperCase() + text.slice(1)
}

function range(v: DealVersion, currency: string): string {
  const r = v.results
  if (r.blended_equity_low === null || r.blended_equity_high === null) return "No price yet"
  return `${formatMoneyCompact(r.blended_equity_low, currency)} to ${formatMoneyCompact(r.blended_equity_high, currency)}`
}

/** assumption keys stored as decimals and shown as percentages */
const PCT_KEYS = new Set([
  "revenue_growth", "ebitda_margin", "da_pct_revenue", "capex_pct_revenue", "nwc_pct_revenue", "tax_rate",
  "risk_free_rate", "equity_risk_premium", "country_risk_premium", "size_premium", "company_specific_premium",
  "pre_tax_cost_of_debt", "target_debt_to_capital", "terminal_growth",
])

function showInput(value: unknown, key = ""): string {
  if (value === null || value === undefined || value === "") return "not set"
  if (typeof value === "boolean") return value ? "Yes" : "No"
  if (PCT_KEYS.has(key)) {
    if (typeof value === "number") return formatPct(value)
    if (Array.isArray(value) && value.every((x) => typeof x === "number")) return value.map((x) => formatPct(x)).join(", ")
  }
  if (typeof value === "number") return value.toLocaleString(undefined, { maximumFractionDigits: 4 })
  if (typeof value === "string") return value.length > 80 ? `${value.slice(0, 80)}…` : value
  if (Array.isArray(value) && value.every((x) => typeof x === "number")) {
    return value.map((x) => x.toLocaleString(undefined, { maximumFractionDigits: 4 })).join(", ")
  }
  if (Array.isArray(value)) return `${value.length} item${value.length === 1 ? "" : "s"}`
  return "set (several fields)"
}

function signed(change: number | null, currency: string): string {
  if (change === null) return "n/a"
  if (change === 0) return "no change"
  return `${change > 0 ? "+" : ""}${formatMoneyCompact(change, currency)}`
}

function SaveVersionDialog({
  open,
  onOpenChange,
  dealId,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  dealId: string
}) {
  const { save } = useVersionMutations(dealId)
  // the panel remounts this dialog (new key) every time it opens, so the fields start fresh
  const [name, setName] = React.useState(() => `Version of ${new Date().toLocaleDateString()}`)
  const [note, setNote] = React.useState("")
  const [error, setError] = React.useState<string | null>(null)
  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!name.trim()) {
      setError("Give the version a name.")
      return
    }
    try {
      const v = await save.mutateAsync({ name: name.trim(), note: note.trim() || undefined })
      onOpenChange(false)
      toast.add({ title: "Version saved", description: v.name, type: "success" })
    } catch (e) {
      setError((e as Error).message)
    }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <form onSubmit={submit} className="flex flex-col gap-4">
          <DialogHeader>
            <DialogTitle>Save a version</DialogTitle>
            <DialogDescription>
              Keeps a copy of the periods, values with their sources, assumptions, peers, notes and method inputs, with the
              price range as it stands now. Saved versions are never changed.
            </DialogDescription>
          </DialogHeader>
          <FieldGroup>
            <Field data-invalid={!!error || undefined}>
              <FieldLabel htmlFor="version-name">Name</FieldLabel>
              <Input
                id="version-name"
                autoFocus
                maxLength={120}
                value={name}
                aria-invalid={!!error || undefined}
                onChange={(e) => {
                  setName(e.target.value)
                  setError(null)
                }}
              />
              {error ? <FieldError>{error}</FieldError> : null}
            </Field>
            <Field>
              <FieldLabel htmlFor="version-note">Note (optional)</FieldLabel>
              <Textarea id="version-note" rows={3} maxLength={2000} value={note} onChange={(e) => setNote(e.target.value)} />
              <FieldDescription>For example: before management meeting, or IC draft.</FieldDescription>
            </Field>
          </FieldGroup>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={save.isPending}>
              {save.isPending ? <Spinner data-icon="inline-start" /> : <SaveIcon data-icon="inline-start" />}
              Save version
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

function Comparison({ c, currency }: { c: VersionComparison; currency: string }) {
  const nothing =
    !c.values_total && !c.inputs_total && !c.periods.added.length && !c.periods.removed.length
  return (
    <div className="flex flex-col gap-5">
      <section aria-labelledby="cmp-results" className="flex flex-col gap-2">
        <h3 id="cmp-results" className="text-sm font-semibold">Results</h3>
        <div className="relative overflow-x-auto rounded-lg border">
          <Table className="text-[13px]">
            <TableHeader>
              <TableRow>
                <TableHead>Result</TableHead>
                <TableHead className="text-right">Version</TableHead>
                <TableHead className="text-right">Current</TableHead>
                <TableHead className="text-right">Change</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {c.results.map((r) => (
                <TableRow key={r.key}>
                  <TableCell>{RESULT_LABEL[r.key] ?? r.key.replaceAll("_", " ")}</TableCell>
                  <TableCell className="text-right">{formatMoneyCompact(r.version, currency)}</TableCell>
                  <TableCell className="text-right">{formatMoneyCompact(r.current, currency)}</TableCell>
                  <TableCell className="text-right">
                    {signed(r.change, currency)}
                    {r.change_pct !== null && r.change !== 0 ? (
                      <span className="ml-1 text-muted-foreground">({r.change_pct > 0 ? "+" : ""}{formatPct(r.change_pct)})</span>
                    ) : null}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        {c.methods.version.join() !== c.methods.current.join() ? (
          <p className="text-xs text-muted-foreground">
            Methods in the price: version {c.methods.version.length}, now {c.methods.current.length}.
          </p>
        ) : null}
      </section>

      {nothing ? (
        <p className="text-sm text-muted-foreground">The inputs are the same as in this version.</p>
      ) : null}

      {c.periods.added.length || c.periods.removed.length ? (
        <section aria-labelledby="cmp-periods" className="flex flex-col gap-1 text-sm">
          <h3 id="cmp-periods" className="text-sm font-semibold">Periods</h3>
          {c.periods.added.length ? <p>Added since: {c.periods.added.join(", ")}</p> : null}
          {c.periods.removed.length ? <p>Removed since: {c.periods.removed.join(", ")}</p> : null}
        </section>
      ) : null}

      {c.inputs_total ? (
        <section aria-labelledby="cmp-inputs" className="flex flex-col gap-2">
          <h3 id="cmp-inputs" className="text-sm font-semibold">
            Assumptions and settings changed ({c.inputs_total})
          </h3>
          <div className="relative overflow-x-auto rounded-lg border">
            <Table className="text-[13px]">
              <TableHeader>
                <TableRow>
                  <TableHead>Where</TableHead>
                  <TableHead>Item</TableHead>
                  <TableHead>Version</TableHead>
                  <TableHead>Current</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {c.inputs.map((d) => (
                  <TableRow key={`${d.section}:${d.key}`}>
                    <TableCell className="text-muted-foreground">{SECTION_LABEL[d.section] ?? d.section}</TableCell>
                    <TableCell className="max-w-48 truncate" title={d.key}>{inputLabel(d.key)}</TableCell>
                    <TableCell className="max-w-48 truncate">{showInput(d.version, d.key)}</TableCell>
                    <TableCell className="max-w-48 truncate">{showInput(d.current, d.key)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          {c.inputs_total > c.inputs.length ? (
            <p className="text-xs text-muted-foreground">Showing the first {c.inputs.length}.</p>
          ) : null}
        </section>
      ) : null}

      {c.values_total ? (
        <section aria-labelledby="cmp-values" className="flex flex-col gap-2">
          <h3 id="cmp-values" className="text-sm font-semibold">Financial values changed ({c.values_total})</h3>
          <div className="relative max-h-96 overflow-auto rounded-lg border">
            <Table className="text-[13px]">
              <TableHeader className="sticky top-0 bg-muted">
                <TableRow>
                  <TableHead>Line item</TableHead>
                  <TableHead>Period</TableHead>
                  <TableHead className="text-right">Version</TableHead>
                  <TableHead className="text-right">Current</TableHead>
                  <TableHead className="text-right">Change</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {c.values.map((d) => (
                  <TableRow key={`${d.period_key}:${d.concept_id}`}>
                    <TableCell className="max-w-56 truncate" title={d.label}>{d.label}</TableCell>
                    <TableCell>{d.period_key}</TableCell>
                    <TableCell className="text-right">{d.version === null ? "not entered" : formatMoneyCompact(d.version, currency)}</TableCell>
                    <TableCell className="text-right">{d.current === null ? "removed" : formatMoneyCompact(d.current, currency)}</TableCell>
                    <TableCell className="text-right">{d.change === null ? "n/a" : signed(d.change, currency)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          {c.values_total > c.values.length ? (
            <p className="text-xs text-muted-foreground">Showing the first {c.values.length}.</p>
          ) : null}
        </section>
      ) : null}
    </div>
  )
}

function CompareSheet({
  dealId,
  version,
  currency,
  onClose,
}: {
  dealId: string
  version: DealVersion | null
  currency: string
  onClose: () => void
}) {
  const { data, isPending, isError, error } = useVersionComparison(dealId, version?.id ?? null)
  return (
    <Sheet open={!!version} onOpenChange={(open) => !open && onClose()}>
      <SheetContent className="w-full overflow-y-auto data-[side=right]:sm:max-w-2xl">
        <SheetHeader>
          <SheetTitle>Compare with current</SheetTitle>
          <SheetDescription>
            {version ? `"${version.name}", saved ${new Date(version.created_at).toLocaleString()}, against the deal as it is now.` : null}
          </SheetDescription>
        </SheetHeader>
        <div className="px-4 pb-6">
          {isPending ? (
            <Skeleton className="h-64 w-full" />
          ) : isError ? (
            <Alert variant="destructive">
              <AlertTitle>The comparison could not be made</AlertTitle>
              <AlertDescription>{error.message}</AlertDescription>
            </Alert>
          ) : (
            <Comparison c={data} currency={currency} />
          )}
        </div>
      </SheetContent>
    </Sheet>
  )
}

export function VersionsPanel({ dealId, currency }: { dealId: string; currency: string }) {
  const { data, isPending, isError, error } = useVersions(dealId)
  const { restore } = useVersionMutations(dealId)
  const [saving, setSaving] = React.useState(false)
  const [saveKey, setSaveKey] = React.useState(0)
  const [comparing, setComparing] = React.useState<DealVersion | null>(null)
  const [restoring, setRestoring] = React.useState<DealVersion | null>(null)

  return (
    <section aria-labelledby="versions-title" className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 id="versions-title" className="text-sm font-semibold">Saved versions</h2>
          <p className="text-xs text-muted-foreground">
            Snapshots of the inputs and the price range. Compare one with the deal now, or restore it.
          </p>
        </div>
        <Button
          size="sm"
          onClick={() => {
            setSaveKey((k) => k + 1)
            setSaving(true)
          }}
        >
          <SaveIcon data-icon="inline-start" />
          Save version
        </Button>
      </div>
      {isPending ? (
        <Skeleton className="h-24 w-full" />
      ) : isError ? (
        <p className="text-sm text-destructive">{error.message}</p>
      ) : !data.length ? (
        <p className="rounded-lg border border-dashed px-3 py-4 text-sm text-muted-foreground">
          No versions yet. Save one before changing assumptions to keep a record you can return to.
        </p>
      ) : (
        <div className="relative overflow-x-auto rounded-lg border">
          <Table className="text-[13px]">
            <TableHeader>
              <TableRow>
                <TableHead className="w-44">Saved</TableHead>
                <TableHead>Name</TableHead>
                <TableHead className="hidden md:table-cell">Price range (equity)</TableHead>
                <TableHead className="w-0"><span className="sr-only">Actions</span></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((v) => (
                <TableRow key={v.id}>
                  <TableCell className="whitespace-nowrap text-muted-foreground">
                    {new Date(v.created_at).toLocaleString()}
                    <span className="block text-xs">{v.created_by}</span>
                  </TableCell>
                  <TableCell className="max-w-72 whitespace-normal">
                    <span className="flex flex-wrap items-center gap-1.5">
                      <span className="font-medium break-words">{v.name}</span>
                      {v.kind === "before_restore" ? (
                        <Badge variant="outline" className="h-5 text-[11px]">
                          <HistoryIcon aria-hidden />
                          Automatic
                        </Badge>
                      ) : null}
                    </span>
                    {v.note ? <span className="block text-xs break-words text-muted-foreground">{v.note}</span> : null}
                    <span className="block text-xs text-muted-foreground md:hidden">{range(v, currency)}</span>
                  </TableCell>
                  <TableCell className="hidden tabular-nums md:table-cell">
                    {range(v, currency)}
                    {v.results.blended_equity_mid !== null ? (
                      <span className="block text-xs text-muted-foreground">
                        mid {formatMoneyCompact(v.results.blended_equity_mid, currency)}
                      </span>
                    ) : null}
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end gap-1">
                      <Button variant="outline" size="sm" onClick={() => setComparing(v)} aria-label={`Compare ${v.name} with current`}>
                        <GitCompareArrowsIcon data-icon="inline-start" />
                        Compare with current
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => setRestoring(v)} aria-label={`Restore ${v.name}`}>
                        Restore
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <SaveVersionDialog key={saveKey} open={saving} onOpenChange={setSaving} dealId={dealId} />
      <CompareSheet dealId={dealId} version={comparing} currency={currency} onClose={() => setComparing(null)} />
      <AlertDialog open={!!restoring} onOpenChange={(open) => !open && setRestoring(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Restore &ldquo;{restoring?.name}&rdquo;?</AlertDialogTitle>
            <AlertDialogDescription>
              The current periods, values, assumptions, peers, notes and method inputs are replaced by this version. The deal
              as it is now is saved first as an automatic version, so you can undo this by restoring that one.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={restore.isPending}>Keep current</AlertDialogCancel>
            <AlertDialogAction
              disabled={restore.isPending || !restoring}
              onClick={async (event: React.MouseEvent) => {
                event.preventDefault()
                if (!restoring) return
                try {
                  const out = await restore.mutateAsync(restoring.id)
                  setRestoring(null)
                  toast.add({
                    title: "Version restored",
                    description: `The previous state was saved as "${out.backup.name}".`,
                    type: "success",
                  })
                } catch (e) {
                  toast.add({ title: "Could not restore the version", description: (e as Error).message, type: "error" })
                }
              }}
            >
              {restore.isPending ? <Spinner data-icon="inline-start" /> : null}
              Restore version
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  )
}
