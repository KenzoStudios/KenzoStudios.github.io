"use client"

import * as React from "react"
import Link from "next/link"
import { usePathname, useRouter, useSearchParams } from "next/navigation"
import { useVirtualizer } from "@tanstack/react-virtual"
import { CreateExcelMenuItem, ImportDealButton } from "@/components/deals/export-controls"
import {
  ArchiveIcon,
  ArchiveRestoreIcon,
  BotIcon,
  BriefcaseBusinessIcon,
  CopyIcon,
  EllipsisIcon,
  FilterXIcon,
  PlusIcon,
  SearchIcon,
  Trash2Icon,
} from "lucide-react"

import { LinkButton } from "@/components/common/link-button"
import { PageHeader } from "@/components/common/page-header"
import { Alert, AlertAction, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { InputGroup, InputGroupAddon, InputGroupInput } from "@/components/ui/input-group"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import { TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/toast"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { formatDate, formatRelative, MODE_LABEL } from "@/lib/format"
import { useAIStatus, useDealMutations, useDeals, useMeta, useSavePreferences, useSettings, type DealFilters } from "@/lib/queries"
import type { Deal } from "@/lib/types"

import { DeleteDealDialog } from "./delete-deal-dialog"

function useDebounced<T>(value: T, ms: number): T {
  const [debounced, setDebounced] = React.useState(value)
  React.useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), ms)
    return () => clearTimeout(timer)
  }, [value, ms])
  return debounced
}

const ALL = "__all__"

function ConnectAIBanner() {
  const { data: status } = useAIStatus()
  const { data: settings } = useSettings()
  const save = useSavePreferences()
  if (!status || !settings || status.connected || !status.enabled || settings.preferences.onboarding_done) return null
  return (
    <Alert>
      <BotIcon />
      <AlertTitle>Connect your own AI to read documents</AlertTitle>
      <AlertDescription>
        <p>
          DealScout ships without an AI account. Connect the provider your company allows (Claude is recommended), or
          continue without AI: tagged filings, rules-based extraction and manual entry still work.
        </p>
      </AlertDescription>
      <div className="col-start-2 mt-2 flex flex-wrap gap-2">
        <LinkButton href="/settings/ai" size="sm">
          Connect AI
        </LinkButton>
        <Button variant="outline" size="sm" onClick={() => save.mutate({ onboarding_done: true })}>
          Continue without AI
        </Button>
      </div>
    </Alert>
  )
}

function RowActions({ deal, onDelete }: { deal: Deal; onDelete: (deal: Deal) => void }) {
  const router = useRouter()
  const { duplicate, update } = useDealMutations()
  return (
    <DropdownMenu>
      <DropdownMenuTrigger render={<Button variant="ghost" size="icon-sm" aria-label={`Actions for ${deal.name}`} />}>
        <EllipsisIcon />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuGroup>
          <CreateExcelMenuItem dealId={deal.id} />
          <DropdownMenuItem
            onClick={async () => {
              try {
                const copy = await duplicate.mutateAsync(deal.id)
                toast.add({ title: "Deal duplicated", description: copy.name, type: "success" })
                router.push(`/deal?id=${copy.id}`)
              } catch (error) {
                toast.add({ title: "Could not duplicate", description: String((error as Error).message), type: "error" })
              }
            }}
          >
            <CopyIcon />
            Duplicate
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={async () => {
              await update.mutateAsync({ id: deal.id, changes: { archived: !deal.archived } })
              toast.add({
                title: deal.archived ? "Deal restored" : "Deal archived",
                description: deal.name,
                actionProps: deal.archived
                  ? undefined
                  : {
                      children: "Undo",
                      onClick: () => update.mutate({ id: deal.id, changes: { archived: false } }),
                    },
              })
            }}
          >
            {deal.archived ? <ArchiveRestoreIcon /> : <ArchiveIcon />}
            {deal.archived ? "Restore" : "Archive"}
          </DropdownMenuItem>
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
          <DropdownMenuItem variant="destructive" onClick={() => onDelete(deal)}>
            <Trash2Icon />
            Delete permanently…
          </DropdownMenuItem>
        </DropdownMenuGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

function DealsTableSkeleton() {
  return (
    <div className="flex flex-col gap-2 p-3" aria-hidden>
      {Array.from({ length: 6 }, (_, i) => (
        <Skeleton key={i} className="h-8 w-full" />
      ))}
    </div>
  )
}

const ROW_ESTIMATE = 41 // px: one 13 px line plus padding; rows with an industry line are measured

/**
 * The deals table, virtualised so thousands of deals scroll smoothly: only the rows in view (plus a margin) are in
 * the DOM; spacer rows keep the scroll height. The header stays sticky inside the table's own scroll area, and
 * ↑/↓ move between company links (scrolling the next row into view first).
 */
function DealsTable({ deals, onDelete }: { deals: Deal[]; onDelete: (deal: Deal) => void }) {
  const router = useRouter()
  const scrollRef = React.useRef<HTMLDivElement>(null)
  // eslint-disable-next-line react-hooks/incompatible-library -- no React Compiler here; read fresh every render
  const virtualizer = useVirtualizer({
    count: deals.length,
    getScrollElement: () => scrollRef.current,
    estimateSize: () => ROW_ESTIMATE,
    overscan: 12,
    getItemKey: (index) => deals[index].id,
  })
  const items = virtualizer.getVirtualItems()
  const top = items.length ? items[0].start : 0
  const bottom = items.length ? virtualizer.getTotalSize() - items[items.length - 1].end : 0

  const focusRow = (index: number) => {
    if (index < 0 || index >= deals.length) return
    virtualizer.scrollToIndex(index, { align: "auto" })
    // focus at once when the row is rendered (it usually is: overscan), else after the virtualizer renders it
    const tryFocus = (attempt: number) => {
      const link = scrollRef.current?.querySelector<HTMLAnchorElement>(`tr[data-index="${index}"] a`)
      if (link) link.focus({ preventScroll: true })
      else if (attempt < 5) requestAnimationFrame(() => tryFocus(attempt + 1))
    }
    tryFocus(0)
  }

  return (
    <div
      ref={scrollRef}
      className="relative max-h-[calc(100dvh-15rem)] min-h-40 overflow-auto"
      onKeyDown={(event) => {
        if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return
        const row = (event.target as HTMLElement).closest<HTMLTableRowElement>("tr[data-index]")
        if (!row || (event.target as HTMLElement).closest("[role=menu]")) return
        event.preventDefault()
        focusRow(Number(row.dataset.index) + (event.key === "ArrowDown" ? 1 : -1))
      }}
    >
      <table className="w-full caption-bottom text-[13px]" aria-rowcount={deals.length + 1}>
        <TableHeader className="sticky top-0 z-10 bg-muted">
          <TableRow aria-rowindex={1}>
            <TableHead className="min-w-56">Company</TableHead>
            <TableHead className="hidden sm:table-cell">Sector</TableHead>
            <TableHead className="hidden md:table-cell">Country</TableHead>
            <TableHead className="hidden lg:table-cell">Currency</TableHead>
            <TableHead className="hidden text-right lg:table-cell">Valuation date</TableHead>
            <TableHead className="hidden xl:table-cell">Mode</TableHead>
            <TableHead className="hidden text-right sm:table-cell">Updated</TableHead>
            <TableHead className="w-10">
              <span className="sr-only">Actions</span>
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {top > 0 ? (
            <tr aria-hidden style={{ height: top }} />
          ) : null}
          {items.map((item) => {
            const deal = deals[item.index]
            return (
              <TableRow
                key={item.key}
                data-index={item.index}
                ref={virtualizer.measureElement}
                aria-rowindex={item.index + 2}
                className="cursor-pointer"
                onClick={(event) => {
                  if ((event.target as HTMLElement).closest("button,a,[role=menuitem]")) return
                  router.push(`/deal?id=${deal.id}`)
                }}
              >
                <TableCell className="max-w-80">
                  <div className="flex min-w-0 items-center gap-2">
                    <Link
                      href={`/deal?id=${deal.id}`}
                      className="truncate rounded-sm font-medium text-foreground outline-none hover:underline focus-visible:ring-2 focus-visible:ring-ring"
                      title={deal.name}
                    >
                      {deal.name}
                    </Link>
                    {deal.listed ? (
                      <Badge variant="outline" className="shrink-0 font-mono text-[11px]" translate="no">
                        {deal.ticker ?? "Listed"}
                      </Badge>
                    ) : null}
                    {deal.archived ? (
                      <Badge variant="secondary" className="shrink-0">
                        Archived
                      </Badge>
                    ) : null}
                  </div>
                  {deal.industry ? <div className="truncate text-xs text-muted-foreground">{deal.industry}</div> : null}
                </TableCell>
                <TableCell className="hidden max-w-48 truncate sm:table-cell" title={deal.sector_name}>
                  {deal.sector_name}
                </TableCell>
                <TableCell className="hidden md:table-cell">{deal.country_name}</TableCell>
                <TableCell className="hidden font-mono text-xs lg:table-cell">
                  {deal.reporting_currency}
                  {deal.analysis_currency !== deal.reporting_currency ? ` → ${deal.analysis_currency}` : ""}
                </TableCell>
                <TableCell className="hidden text-right lg:table-cell">{formatDate(deal.valuation_date)}</TableCell>
                <TableCell className="hidden xl:table-cell">{MODE_LABEL[deal.mode]}</TableCell>
                <TableCell className="hidden text-right text-muted-foreground sm:table-cell" title={new Date(deal.updated_at).toLocaleString()}>
                  {formatRelative(deal.updated_at)}
                </TableCell>
                <TableCell>
                  <RowActions deal={deal} onDelete={onDelete} />
                </TableCell>
              </TableRow>
            )
          })}
          {bottom > 0 ? (
            <tr aria-hidden style={{ height: bottom }} />
          ) : null}
        </TableBody>
      </table>
    </div>
  )
}

export function DealsPage() {
  const router = useRouter()
  const pathname = usePathname()
  const params = useSearchParams()
  const { data: meta } = useMeta()
  // Filters live in the URL so a filtered view can be bookmarked, shared and survives reloads.
  const [search, setSearch] = React.useState(params.get("q") ?? "")
  const [sector, setSector] = React.useState<string>(params.get("sector") ?? ALL)
  const [listed, setListed] = React.useState<DealFilters["listed"]>(
    (["listed", "private"].includes(params.get("listing") ?? "") ? params.get("listing") : "all") as DealFilters["listed"],
  )
  const [archived, setArchived] = React.useState(params.get("archived") === "1")
  const [sort, setSort] = React.useState<NonNullable<DealFilters["sort"]>>(
    (["name", "created"].includes(params.get("sort") ?? "") ? params.get("sort") : "updated") as NonNullable<DealFilters["sort"]>,
  )
  const [toDelete, setToDelete] = React.useState<Deal | null>(null)
  const q = useDebounced(search, 200)

  React.useEffect(() => {
    const next = new URLSearchParams()
    if (q) next.set("q", q)
    if (sector !== ALL) next.set("sector", sector)
    if (listed && listed !== "all") next.set("listing", listed)
    if (archived) next.set("archived", "1")
    if (sort !== "updated") next.set("sort", sort)
    const qs = next.toString()
    router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false })
  }, [q, sector, listed, archived, sort, pathname, router])

  const filters: DealFilters = { q, sector: sector === ALL ? undefined : sector, listed, archived, sort }
  const { data, isPending, isError, error, refetch, isFetching } = useDeals(filters)
  const filtered = !!q || sector !== ALL || listed !== "all"
  const sectorItems = [{ value: ALL, label: "All sectors" }, ...(meta?.reference.sectors.map((s) => ({ value: s.id, label: s.name })) ?? [])]

  return (
    <div className="flex flex-col gap-5 p-4 md:p-6">
      <PageHeader
        title="Deals"
        description="Each deal is a first-pass screen of one target company: data, analysis, valuation range and exports."
        actions={
          <>
            <ImportDealButton />
            <LinkButton href="/deals/new">
              <PlusIcon data-icon="inline-start" />
              New deal
            </LinkButton>
          </>
        }
      />
      <ConnectAIBanner />

      <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
        <InputGroup className="lg:max-w-xs">
          <InputGroupAddon>
            <SearchIcon />
          </InputGroupAddon>
          <InputGroupInput
            type="search"
            aria-label="Search deals by name, ticker or industry"
            placeholder="Search name, ticker, industry…"
            name="deal-search"
            autoComplete="off"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </InputGroup>
        <Select items={sectorItems} value={sector} onValueChange={(v) => setSector((v as string) ?? ALL)}>
          <SelectTrigger aria-label="Filter by sector" className="w-full lg:w-56">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              {sectorItems.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {s.label}
                </SelectItem>
              ))}
            </SelectGroup>
          </SelectContent>
        </Select>
        <ToggleGroup
          variant="outline"
          size="sm"
          aria-label="Listing status"
          value={[listed ?? "all"]}
          onValueChange={(v: string[]) => v[0] && setListed(v[0] as DealFilters["listed"])}
        >
          <ToggleGroupItem value="all">All</ToggleGroupItem>
          <ToggleGroupItem value="listed">Listed</ToggleGroupItem>
          <ToggleGroupItem value="private">Private</ToggleGroupItem>
        </ToggleGroup>
        <div className="flex items-center gap-2 lg:ml-auto">
          <Select
            items={[
              { value: "updated", label: "Recently updated" },
              { value: "name", label: "Name, A to Z" },
              { value: "created", label: "Recently created" },
            ]}
            value={sort}
            onValueChange={(v) => setSort((v as typeof sort) ?? "updated")}
          >
            <SelectTrigger aria-label="Sort deals" size="sm" className="w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectItem value="updated">Recently updated</SelectItem>
                <SelectItem value="name">Name, A to Z</SelectItem>
                <SelectItem value="created">Recently created</SelectItem>
              </SelectGroup>
            </SelectContent>
          </Select>
          <Button variant={archived ? "secondary" : "ghost"} size="sm" aria-pressed={archived} onClick={() => setArchived((a) => !a)}>
            <ArchiveIcon data-icon="inline-start" />
            {archived ? "Showing archived" : "Archived"}
          </Button>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border" aria-busy={isFetching}>
        {isPending ? (
          <DealsTableSkeleton />
        ) : isError ? (
          <Alert variant="destructive" className="m-3 w-auto">
            <AlertTitle>Deals could not be loaded</AlertTitle>
            <AlertDescription>{error.message}</AlertDescription>
            <AlertAction>
              <Button variant="outline" size="sm" onClick={() => refetch()}>
                Try again
              </Button>
            </AlertAction>
          </Alert>
        ) : data.items.length === 0 ? (
          filtered || archived ? (
            <Empty className="py-12">
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <FilterXIcon />
                </EmptyMedia>
                <EmptyTitle>{archived ? "No archived deals" : "No deals match these filters"}</EmptyTitle>
                <EmptyDescription>
                  {archived ? "Archived deals appear here." : "Clear the search or filters to see every deal."}
                </EmptyDescription>
              </EmptyHeader>
              <EmptyContent>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearch("")
                    setSector(ALL)
                    setListed("all")
                    setArchived(false)
                  }}
                >
                  Clear filters
                </Button>
              </EmptyContent>
            </Empty>
          ) : (
            <Empty className="py-14">
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <BriefcaseBusinessIcon />
                </EmptyMedia>
                <EmptyTitle>No deals yet</EmptyTitle>
                <EmptyDescription>
                  Create a deal for the company you want to screen, then upload its reports or type in the key numbers.
                </EmptyDescription>
              </EmptyHeader>
              <EmptyContent>
                <LinkButton href="/deals/new">
                  <PlusIcon data-icon="inline-start" />
                  Create your first deal
                </LinkButton>
              </EmptyContent>
            </Empty>
          )
        ) : (
          <DealsTable deals={data.items} onDelete={setToDelete} />
        )}
      </div>
      {data && data.items.length > 0 ? (
        <p className="text-xs text-muted-foreground" aria-live="polite">
          {data.total} {data.total === 1 ? "deal" : "deals"}
          {filtered ? " match the filters" : ""}
        </p>
      ) : null}

      <DeleteDealDialog deal={toDelete} open={!!toDelete} onOpenChange={(open) => !open && setToDelete(null)} />
    </div>
  )
}
