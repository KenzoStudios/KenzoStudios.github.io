"use client"

import * as React from "react"
import { useRouter } from "next/navigation"
import { useQueryClient } from "@tanstack/react-query"
import { ChevronDownIcon, FileJsonIcon, FileSpreadsheetIcon, FileTextIcon, LoaderCircleIcon, PresentationIcon, UploadIcon } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { toast } from "@/components/ui/toast"
import { api, ApiError } from "@/lib/api"

export type ExportFormat = "xlsx" | "pdf" | "pptx" | "json"

const LABEL: Record<ExportFormat, string> = {
  xlsx: "Excel workbook",
  pdf: "PDF tear sheet",
  pptx: "PowerPoint one-pager",
  json: "JSON deal file",
}

/** Fetch an export and save it; errors (including a workbook that failed its checks) come back as a toast. */
export async function downloadExport(dealId: string, format: ExportFormat): Promise<void> {
  let response: Response
  try {
    response = await fetch(`/api/deals/${dealId}/export/${format}`)
  } catch {
    throw new ApiError(0, "Can't reach the DealScout server. Is it still running in your terminal?", "offline")
  }
  if (!response.ok) {
    let message = `The ${LABEL[format]} could not be created.`
    try {
      const body = (await response.json()) as { detail?: string }
      if (typeof body.detail === "string") message = body.detail
    } catch {
      // keep the generic message
    }
    throw new ApiError(response.status, message)
  }
  const blob = await response.blob()
  const name = /filename="([^"]+)"/.exec(response.headers.get("content-disposition") ?? "")?.[1] ?? `deal.${format}`
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = name
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 10_000)
}

function useExport(dealId: string) {
  const [pending, setPending] = React.useState<ExportFormat | null>(null)
  const run = async (format: ExportFormat) => {
    setPending(format)
    try {
      await downloadExport(dealId, format)
      toast.add({
        title: `${LABEL[format]} created`,
        description: format === "xlsx" ? "Checked for formula errors and recalculated before download." : "Saved to your downloads.",
        type: "success",
      })
    } catch (error) {
      toast.add({ title: `${LABEL[format]} not created`, description: (error as Error).message, type: "error" })
    } finally {
      setPending(null)
    }
  }
  return { pending, run }
}

/** The prominent "Create Excel" button and the menu with the other formats, for the deal header. */
export function ExportControls({ dealId }: { dealId: string }) {
  const { pending, run } = useExport(dealId)
  return (
    <>
      <Button size="sm" disabled={pending !== null} onClick={() => run("xlsx")}>
        {pending === "xlsx" ? <LoaderCircleIcon data-icon="inline-start" className="animate-spin" /> : <FileSpreadsheetIcon data-icon="inline-start" />}
        {pending === "xlsx" ? "Creating Excel…" : "Create Excel"}
      </Button>
      <DropdownMenu>
        <DropdownMenuTrigger render={<Button variant="outline" size="sm" disabled={pending !== null} />}>
          {pending && pending !== "xlsx" ? <LoaderCircleIcon data-icon="inline-start" className="animate-spin" /> : null}
          Export
          <ChevronDownIcon data-icon="inline-end" />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuGroup>
            <DropdownMenuItem onClick={() => run("pdf")}>
              <FileTextIcon />
              PDF tear sheet
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => run("pptx")}>
              <PresentationIcon />
              PowerPoint one-pager
            </DropdownMenuItem>
          </DropdownMenuGroup>
          <DropdownMenuSeparator />
          <DropdownMenuGroup>
            <DropdownMenuItem onClick={() => run("json")}>
              <FileJsonIcon />
              JSON deal file
            </DropdownMenuItem>
          </DropdownMenuGroup>
        </DropdownMenuContent>
      </DropdownMenu>
    </>
  )
}

/** "Create Excel" inside a deal's row menu on the deals list. */
export function CreateExcelMenuItem({ dealId }: { dealId: string }) {
  const { run } = useExport(dealId)
  return (
    <DropdownMenuItem onClick={() => run("xlsx")}>
      <FileSpreadsheetIcon />
      Create Excel
    </DropdownMenuItem>
  )
}

/** Import a JSON deal file exported from DealScout; reports whether the results were reproduced. */
export function ImportDealButton() {
  const router = useRouter()
  const qc = useQueryClient()
  const input = React.useRef<HTMLInputElement>(null)
  const [pending, setPending] = React.useState(false)
  const onFile = async (file: File) => {
    setPending(true)
    try {
      const body = JSON.parse(await file.text()) as unknown
      const out = await api<{ id: string; name: string; reproduced: boolean; differences: string[] }>("/api/deals/import", {
        method: "POST",
        json: body,
      })
      qc.invalidateQueries({ queryKey: ["deals"] })
      toast.add(
        out.reproduced
          ? { title: "Deal imported", description: `${out.name}: results match the file.`, type: "success" }
          : { title: "Deal imported with differences", description: out.differences.slice(0, 2).join("; "), type: "warning" },
      )
      router.push(`/deal?id=${out.id}`)
    } catch (error) {
      const message = error instanceof SyntaxError ? "The file is not valid JSON." : (error as Error).message
      toast.add({ title: "Import failed", description: message, type: "error" })
    } finally {
      setPending(false)
      if (input.current) input.current.value = ""
    }
  }
  return (
    <>
      <input
        ref={input}
        type="file"
        accept="application/json,.json"
        className="sr-only"
        tabIndex={-1}
        aria-hidden
        onChange={(e) => {
          const file = e.target.files?.[0]
          if (file) void onFile(file)
        }}
      />
      <Button variant="outline" disabled={pending} onClick={() => input.current?.click()}>
        {pending ? <LoaderCircleIcon data-icon="inline-start" className="animate-spin" /> : <UploadIcon data-icon="inline-start" />}
        {pending ? "Importing…" : "Import deal file"}
      </Button>
    </>
  )
}
