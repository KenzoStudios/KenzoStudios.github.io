"use client"

import * as React from "react"

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Spinner } from "@/components/ui/spinner"
import { toast } from "@/components/ui/toast"
import { useDealMutations } from "@/lib/queries"
import type { Deal } from "@/lib/types"

/** Hard delete is permanent (brief §15), so this is a confirm dialog naming the deal — not an undo toast. */
export function DeleteDealDialog({
  deal,
  open,
  onOpenChange,
  onDeleted,
}: {
  deal: Pick<Deal, "id" | "name"> | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onDeleted?: () => void
}) {
  const { remove } = useDealMutations()
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete “{deal?.name}” permanently?</AlertDialogTitle>
          <AlertDialogDescription>
            The deal, its uploaded documents, extracted values, AI usage records and its audit history are erased from this
            computer. This cannot be undone. To keep it out of the way instead, archive it.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={remove.isPending}>Keep deal</AlertDialogCancel>
          <AlertDialogAction
            variant="destructive"
            disabled={remove.isPending || !deal}
            onClick={async (event: React.MouseEvent) => {
              event.preventDefault()
              if (!deal) return
              try {
                await remove.mutateAsync(deal.id)
                onOpenChange(false)
                toast.add({ title: "Deal deleted", description: `“${deal.name}” and its files were erased.` })
                onDeleted?.()
              } catch (error) {
                toast.add({
                  title: "Could not delete the deal",
                  description: error instanceof Error ? error.message : "Try again.",
                  type: "error",
                })
              }
            }}
          >
            {remove.isPending ? <Spinner data-icon="inline-start" /> : null}
            Delete deal
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
