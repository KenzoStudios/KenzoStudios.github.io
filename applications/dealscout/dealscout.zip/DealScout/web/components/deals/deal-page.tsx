"use client"

import * as React from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import {
  ArchiveIcon,
  ArchiveRestoreIcon,
  ClipboardPasteIcon,
  CopyIcon,
  FileUpIcon,
  HistoryIcon,
  KeyboardIcon,
  PencilIcon,
  SearchXIcon,
  Trash2Icon,
} from "lucide-react"

import { LinkButton } from "@/components/common/link-button"
import { PageHeader } from "@/components/common/page-header"
import { Alert, AlertAction, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Skeleton } from "@/components/ui/skeleton"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { toast } from "@/components/ui/toast"
import { formatDate, MODE_LABEL, PERSPECTIVE_LABEL } from "@/lib/format"
import { useAIStatus, useDeal, useDealAudit, useDealMutations, useMeta, useReview } from "@/lib/queries"
import type { AuditEvent, Deal, DealMode } from "@/lib/types"

import { AnalysisTab } from "@/components/analysis/analysis-tab"
import { DataTab } from "@/components/financials/data-tab"
import { ValuationTab } from "@/components/valuation/valuation-tab"
import { ExportControls } from "@/components/deals/export-controls"
import { Cockpit } from "@/components/deals/cockpit"
import { DocumentsTab } from "@/components/documents/documents-tab"
import { ReviewTab } from "@/components/review/review-tab"

import { DealForm } from "./deal-form"
import { DeleteDealDialog } from "./delete-deal-dialog"
import { VersionsPanel } from "./versions-panel"


function Facts({ deal }: { deal: Deal }) {
  const rows: [string, React.ReactNode][] = [
    ["Country", deal.country_name],
    ["Sector", deal.sector_name],
    ["Industry", deal.industry ?? "—"],
    ["Listing", deal.listed ? `Listed${deal.ticker ? ` · ${deal.ticker}` : ""}` : "Private"],
    ["Reporting currency", deal.reporting_currency],
    ["Analysis currency", deal.analysis_currency],
    ["Valuation date", formatDate(deal.valuation_date)],
    ["Perspective", PERSPECTIVE_LABEL[deal.perspective]],
    ["Statement template", deal.sector_template.replace("_", " ")],
  ]
  return (
    <dl className="grid grid-cols-[minmax(0,10rem)_minmax(0,1fr)] gap-x-4 gap-y-2 text-sm">
      {rows.map(([label, value]) => (
        <React.Fragment key={label}>
          <dt className="text-muted-foreground">{label}</dt>
          <dd className="min-w-0 truncate" title={typeof value === "string" ? value : undefined}>{value}</dd>
        </React.Fragment>
      ))}
    </dl>
  )
}

const MODE_HELP: Record<DealMode, string> = {
  quick:
    "Quick Scan: one growth fade and single driver values, the main valuation tabs, other methods behind Show all methods.",
  detailed:
    "Detailed: growth, margin, D&A, capex and working capital set year by year, the full assumptions panel and every method tab.",
}

function ModeSwitch({ deal }: { deal: Deal }) {
  const { update } = useDealMutations()
  return (
    <div className="flex flex-col gap-1.5">
      <span id="mode-switch-label" className="text-sm text-muted-foreground">Mode</span>
      <ToggleGroup
        variant="outline"
        size="sm"
        aria-labelledby="mode-switch-label"
        value={[deal.mode]}
        disabled={update.isPending}
        onValueChange={(v: string[]) => {
          const mode = v[0] as DealMode | undefined
          if (!mode || mode === deal.mode) return
          update.mutate(
            { id: deal.id, changes: { mode } },
            {
              onSuccess: () => toast.add({ title: `Switched to ${MODE_LABEL[mode]}`, type: "success" }),
              onError: (e) => toast.add({ title: "Mode not changed", description: e.message, type: "error" }),
            },
          )
        }}
      >
        <ToggleGroupItem value="quick">Quick Scan</ToggleGroupItem>
        <ToggleGroupItem value="detailed">Detailed</ToggleGroupItem>
      </ToggleGroup>
      <p className="text-xs text-muted-foreground">{MODE_HELP[deal.mode]}</p>
    </div>
  )
}

function AddData({ dealId }: { dealId: string }) {
  const { data: ai } = useAIStatus()
  return (
    <div className="grid gap-3 lg:grid-cols-3">
      <Card className="lg:col-span-1">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileUpIcon aria-hidden className="size-4" />
            Upload documents
          </CardTitle>
          <CardDescription>
            Annual and interim reports, management accounts, filings (PDF, Excel, XBRL…). Your connected AI reads them and
            every number links back to its page.
          </CardDescription>
        </CardHeader>
        <CardFooter className="mt-auto flex-col items-start gap-2">
          <LinkButton href={`/deal?id=${dealId}&tab=documents`} size="sm">
            Upload documents
          </LinkButton>
          {ai && !ai.connected ? (
            <p className="text-xs text-muted-foreground">
              No AI connected yet.{" "}
              <Link href="/settings/ai" className="font-medium text-link underline-offset-2 hover:underline">
                Connect AI
              </Link>{" "}
              or continue without AI.
            </p>
          ) : null}
        </CardFooter>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <KeyboardIcon aria-hidden className="size-4" />
            Enter numbers
          </CardTitle>
          <CardDescription>
            A spreadsheet-style grid of standard line items. Minimum for a Quick Scan: revenue, EBITDA, D&A, capex, net
            debt, shares and price.
          </CardDescription>
        </CardHeader>
        <CardFooter className="mt-auto">
          <LinkButton href={`/deal?id=${dealId}&tab=data`} size="sm">Open the data grid</LinkButton>
        </CardFooter>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ClipboardPasteIcon aria-hidden className="size-4" />
            Paste from Excel
          </CardTitle>
          <CardDescription>
            Paste a statement and DealScout detects the periods and units. A blank Excel template is also available.
          </CardDescription>
        </CardHeader>
        <CardFooter className="mt-auto">
          <LinkButton href={`/deal?id=${dealId}&tab=data`} size="sm" variant="outline">Paste or upload a template</LinkButton>
        </CardFooter>
      </Card>
    </div>
  )
}

function PendingCount({ dealId }: { dealId: string }) {
  const { data } = useReview(dealId)
  const pending = data?.items.filter((i) => i.status === "pending").length ?? 0
  if (!pending) return null
  return (
    <span className="ml-1 rounded-full bg-muted px-1.5 text-[11px] tabular-nums text-muted-foreground">
      {pending}
      <span className="sr-only"> values to review</span>
    </span>
  )
}

const ACTION_LABEL: Record<string, string> = {
  method_inputs_changed: "Valuation method inputs changed",
  one_offs_suggested: "AI suggested one-off items",
  rationale_written: "AI wrote the price rationale",
  export_created: "Export created",
  deal_imported: "Deal imported from a file",
  deal_created: "Created the deal",
  document_uploaded: "Uploaded a document",
  document_deleted: "Deleted a document",
  extraction_reviewed: "Reviewed extracted values",
  deal_updated: "Edited deal details",
  deal_duplicated: "Created as a duplicate",
  version_saved: "Saved a version",
  version_restored: "Restored a version",
}

function Activity({ dealId }: { dealId: string }) {
  const { data, isPending, isError, error } = useDealAudit(dealId)
  if (isPending) return <Skeleton className="h-32 w-full" />
  if (isError) return <p className="text-sm text-destructive">{error.message}</p>
  if (!data.length) return <p className="text-sm text-muted-foreground">No activity recorded yet.</p>
  return (
    <div className="relative overflow-x-auto rounded-lg border">
      <Table className="text-[13px]">
        <TableHeader>
          <TableRow>
            <TableHead className="w-44">When</TableHead>
            <TableHead className="w-40">Who</TableHead>
            <TableHead>What</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((event: AuditEvent) => {
            const changes = (event.detail.changes ?? {}) as Record<string, { old: string; new: string }>
            return (
              <TableRow key={event.id}>
                <TableCell className="whitespace-nowrap text-muted-foreground">{new Date(event.at).toLocaleString()}</TableCell>
                <TableCell className="max-w-40 truncate">{event.actor}</TableCell>
                <TableCell className="whitespace-normal">
                  {ACTION_LABEL[event.action] ?? event.action.replaceAll("_", " ")}
                  {Object.keys(changes).length ? (
                    <ul className="mt-1 flex flex-col gap-0.5 text-xs text-muted-foreground">
                      {Object.entries(changes).map(([field, change]) => (
                        <li key={field} className="break-words">
                          <span className="font-medium text-foreground">{field.replaceAll("_", " ")}</span>: {change.old || "—"} →{" "}
                          {change.new || "—"}
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </TableCell>
              </TableRow>
            )
          })}
        </TableBody>
      </Table>
    </div>
  )
}

export function DealPage() {
  const params = useSearchParams()
  const router = useRouter()
  const id = params.get("id")
  const requested = params.get("tab")
  const tab = ["overview", "documents", "review", "data", "analysis", "valuation", "activity"].includes(requested ?? "")
    ? (requested as string)
    : "overview"
  const { data: deal, isPending, isError, error, refetch } = useDeal(id)
  const { data: meta } = useMeta()
  const { update, duplicate } = useDealMutations()
  const [editing, setEditing] = React.useState(false)
  const [deleting, setDeleting] = React.useState(false)

  if (!id || (isError && (error as { status?: number }).status === 404)) {
    return (
      <Empty className="m-6 border">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <SearchXIcon />
          </EmptyMedia>
          <EmptyTitle>Deal not found</EmptyTitle>
          <EmptyDescription>It may have been deleted, or the link is incomplete.</EmptyDescription>
        </EmptyHeader>
        <EmptyContent>
          <LinkButton href="/" variant="outline">
            Back to deals
          </LinkButton>
        </EmptyContent>
      </Empty>
    )
  }
  if (isPending) {
    return (
      <div className="flex flex-col gap-4 p-4 md:p-6" aria-busy>
        <Skeleton className="h-8 w-72" />
        <Skeleton className="h-5 w-96" />
        <Skeleton className="h-48 w-full" />
      </div>
    )
  }
  if (isError) {
    return (
      <Alert variant="destructive" className="m-6 w-auto">
        <AlertTitle>The deal could not be loaded</AlertTitle>
        <AlertDescription>{error.message}</AlertDescription>
        <AlertAction>
          <Button variant="outline" size="sm" onClick={() => refetch()}>
            Try again
          </Button>
        </AlertAction>
      </Alert>
    )
  }

  return (
    <div className="flex flex-col gap-5 p-4 md:p-6">
      <PageHeader
        eyebrow={
          <span className="flex flex-wrap items-center gap-1.5">
            <span>{deal.sector_name}</span>
            <span aria-hidden>·</span>
            <span>{deal.country_name}</span>
            {deal.listed ? <Badge variant="outline" className="font-mono" translate="no">{deal.ticker ?? "Listed"}</Badge> : null}
            {deal.archived ? <Badge variant="secondary">Archived</Badge> : null}
          </span>
        }
        title={<span title={deal.name}>{deal.name}</span>}
        description={`${PERSPECTIVE_LABEL[deal.perspective]} view · ${MODE_LABEL[deal.mode]} · valuation date ${formatDate(deal.valuation_date)} · ${deal.reporting_currency}${deal.analysis_currency !== deal.reporting_currency ? ` → ${deal.analysis_currency}` : ""}`}
        actions={
          <>
            <ExportControls dealId={deal.id} />
            <LinkButton href={`/deal?id=${deal.id}&tab=activity`} variant="outline" size="sm">
              <HistoryIcon data-icon="inline-start" />
              Versions
            </LinkButton>
            <Button variant="outline" size="sm" onClick={() => setEditing(true)}>
              <PencilIcon data-icon="inline-start" />
              Edit details
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={duplicate.isPending}
              onClick={async () => {
                const copy = await duplicate.mutateAsync(deal.id)
                toast.add({ title: "Deal duplicated", description: copy.name, type: "success" })
                router.push(`/deal?id=${copy.id}`)
              }}
            >
              <CopyIcon data-icon="inline-start" />
              Duplicate
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => update.mutate({ id: deal.id, changes: { archived: !deal.archived } })}
            >
              {deal.archived ? <ArchiveRestoreIcon data-icon="inline-start" /> : <ArchiveIcon data-icon="inline-start" />}
              {deal.archived ? "Restore" : "Archive"}
            </Button>
            <Button variant="ghost" size="sm" className="text-destructive" onClick={() => setDeleting(true)}>
              <Trash2Icon data-icon="inline-start" />
              Delete
            </Button>
          </>
        }
      />

      <Tabs
        value={tab}
        onValueChange={(value) => {
          const next = new URLSearchParams(params.toString())
          next.set("tab", value as string)
          if (value !== "review") {
            next.delete("item")
            next.delete("doc")
          }
          if (value !== "valuation") next.delete("method")
          if (value !== "data") next.delete("stmt")
          router.replace(`/deal?${next.toString()}`, { scroll: false })
        }}
      >
        <TabsList className="max-w-full justify-start overflow-x-auto">
          <TabsTrigger value="overview">Summary</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="review">
            Review
            <PendingCount dealId={deal.id} />
          </TabsTrigger>
          <TabsTrigger value="data">Data</TabsTrigger>
          <TabsTrigger value="analysis">Analysis</TabsTrigger>
          <TabsTrigger value="valuation">Valuation</TabsTrigger>
          <TabsTrigger value="activity">Versions and activity</TabsTrigger>
        </TabsList>
        <TabsContent value="documents" className="pt-3">
          {tab === "documents" ? <DocumentsTab deal={deal} /> : null}
        </TabsContent>
        <TabsContent value="review" className="pt-3">
          {tab === "review" ? <ReviewTab deal={deal} /> : null}
        </TabsContent>
        <TabsContent value="data" className="pt-3">
          {tab === "data" ? <DataTab deal={deal} /> : null}
        </TabsContent>
        <TabsContent value="analysis" className="pt-3">
          {tab === "analysis" ? <AnalysisTab deal={deal} /> : null}
        </TabsContent>
        <TabsContent value="valuation" className="pt-3">
          {tab === "valuation" ? <ValuationTab deal={deal} /> : null}
        </TabsContent>
        <TabsContent value="overview" className="flex flex-col gap-6 pt-3">
          {tab === "overview" ? <Cockpit deal={deal} /> : null}
          <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,22rem)]">
            <section aria-labelledby="add-data" className="flex flex-col gap-3">
              <h2 id="add-data" className="text-sm font-semibold">
                Add data
              </h2>
              <AddData dealId={deal.id} />
            </section>
            <section aria-labelledby="facts" className="flex flex-col gap-3">
              <h2 id="facts" className="text-sm font-semibold">
                Deal details
              </h2>
              <Card size="sm">
                <CardContent className="flex flex-col gap-4">
                  <Facts deal={deal} />
                  <ModeSwitch deal={deal} />
                </CardContent>
              </Card>
              {deal.notes ? (
                <Card size="sm">
                  <CardHeader>
                    <CardTitle>Notes</CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm whitespace-pre-wrap break-words">{deal.notes}</CardContent>
                </Card>
              ) : null}
            </section>
          </div>
        </TabsContent>
        <TabsContent value="activity" className="flex flex-col gap-6 pt-3">
          {tab === "activity" ? <VersionsPanel dealId={deal.id} currency={deal.reporting_currency} /> : null}
          <section aria-labelledby="activity-title" className="flex flex-col gap-3">
            <h2 id="activity-title" className="text-sm font-semibold">Activity log</h2>
            <Activity dealId={deal.id} />
          </section>
        </TabsContent>
      </Tabs>

      <Sheet open={editing} onOpenChange={setEditing}>
        <SheetContent className="w-full overflow-y-auto sm:max-w-xl">
          <SheetHeader>
            <SheetTitle>Edit deal details</SheetTitle>
            <SheetDescription>Changes are recorded in the deal&apos;s activity log under your name.</SheetDescription>
          </SheetHeader>
          {meta ? (
            <div className="px-4 pb-6">
              <DealForm
                meta={meta}
                deal={deal}
                formId="edit-deal-form"
                submitLabel="Save changes"
                onCancel={() => setEditing(false)}
                onSubmit={async (input) => {
                  await update.mutateAsync({ id: deal.id, changes: input })
                  setEditing(false)
                  toast.add({ title: "Deal updated", type: "success" })
                }}
              />
            </div>
          ) : null}
        </SheetContent>
      </Sheet>
      <DeleteDealDialog deal={deal} open={deleting} onOpenChange={setDeleting} onDeleted={() => router.push("/")} />
    </div>
  )
}
