"use client"

import { useRouter } from "next/navigation"

import { PageHeader } from "@/components/common/page-header"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Skeleton } from "@/components/ui/skeleton"
import { toast } from "@/components/ui/toast"
import { useDealMutations, useMeta } from "@/lib/queries"

import { DealForm } from "./deal-form"

export function NewDealPage() {
  const router = useRouter()
  const { data: meta, isPending, isError, error } = useMeta()
  const { create } = useDealMutations()
  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col gap-6 p-4 md:p-6">
      <PageHeader
        eyebrow="Step 1 of 9 · Create a deal"
        title="New deal"
        description="Tell DealScout which company you are screening. Next you will add its documents or key numbers."
      />
      {isPending ? (
        <div className="flex flex-col gap-4" aria-hidden>
          {Array.from({ length: 6 }, (_, i) => (
            <Skeleton key={i} className="h-14 w-full" />
          ))}
        </div>
      ) : isError ? (
        <Alert variant="destructive">
          <AlertTitle>Reference data could not be loaded</AlertTitle>
          <AlertDescription>{error.message}</AlertDescription>
        </Alert>
      ) : (
        <DealForm
          meta={meta}
          submitLabel="Create deal"
          onCancel={() => router.push("/")}
          onSubmit={async (input) => {
            const deal = await create.mutateAsync(input)
            toast.add({ title: "Deal created", description: deal.name, type: "success" })
            router.push(`/deal?id=${deal.id}`)
          }}
        />
      )}
    </div>
  )
}
