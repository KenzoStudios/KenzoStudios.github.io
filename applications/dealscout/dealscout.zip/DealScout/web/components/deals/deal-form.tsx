"use client"

import * as React from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { Controller, useForm, useWatch } from "react-hook-form"
import { z } from "zod"

import { SearchSelect, type Option } from "@/components/common/search-select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import {
  Field,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLabel,
  FieldLegend,
  FieldSet,
} from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Spinner } from "@/components/ui/spinner"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { ApiError } from "@/lib/api"
import type { Deal, DealInput, Meta } from "@/lib/types"

/** Local calendar date (not UTC) as YYYY-MM-DD. */
const today = () => {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`
}

const schema = z.object({
    name: z.string().trim().min(1, "Enter the target company's name.").max(200, "Keep the name under 200 characters."),
    country: z.string({ error: "Choose the country." }).length(2, "Choose the country."),
    sector: z.string({ error: "Choose a sector." }).min(1, "Choose a sector."),
    industry: z.string().max(120).optional(),
    listed: z.boolean(),
    ticker: z.string().max(30).optional(),
    reporting_currency: z.string({ error: "Choose the reporting currency." }).length(3, "Choose the reporting currency."),
    analysis_currency: z.string({ error: "Choose the analysis currency." }).length(3, "Choose the analysis currency."),
    valuation_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Enter a valid date."),
    perspective: z.enum(["financial_sponsor", "strategic"]),
    mode: z.enum(["quick", "detailed"]),
    notes: z.string().max(5000).optional(),
  })

export type DealFormValues = z.infer<typeof schema>

function defaults(deal?: Deal): DealFormValues {
  return {
    name: deal?.name ?? "",
    country: deal?.country ?? "",
    sector: deal?.sector ?? "",
    industry: deal?.industry ?? "",
    listed: deal?.listed ?? false,
    ticker: deal?.ticker ?? "",
    reporting_currency: deal?.reporting_currency ?? "",
    analysis_currency: deal?.analysis_currency ?? "",
    valuation_date: deal?.valuation_date ?? today(),
    perspective: deal?.perspective ?? "financial_sponsor",
    mode: deal?.mode ?? "quick",
    notes: deal?.notes ?? "",
  }
}

export function toInput(values: DealFormValues): DealInput {
  return {
    name: values.name.trim(),
    country: values.country,
    sector: values.sector,
    industry: values.industry?.trim() || null,
    listed: values.listed,
    ticker: values.listed ? values.ticker?.trim() || null : null,
    reporting_currency: values.reporting_currency,
    analysis_currency: values.analysis_currency,
    valuation_date: values.valuation_date,
    perspective: values.perspective,
    mode: values.mode,
    notes: values.notes?.trim() || null,
  }
}

export function DealForm({
  meta,
  deal,
  submitLabel,
  onSubmit,
  onCancel,
  formId = "deal-form",
}: {
  meta: Meta
  deal?: Deal
  submitLabel: string
  onSubmit: (input: DealInput) => Promise<unknown>
  onCancel?: () => void
  formId?: string
}) {
  const form = useForm<DealFormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaults(deal),
    mode: "onTouched",
  })
  const [serverError, setServerError] = React.useState<string | null>(null)
  const errorRef = React.useRef<HTMLDivElement>(null)
  const isDirty = form.formState.isDirty
  const isSubmitted = form.formState.isSubmitSuccessful

  // Focus the first field on desktop only (autofocus on phones pops the keyboard over the form).
  React.useEffect(() => {
    if (!deal && window.matchMedia("(pointer: fine)").matches) form.setFocus("name")
  }, [deal, form])

  // Warn before leaving with unsaved edits.
  React.useEffect(() => {
    if (!isDirty || isSubmitted) return
    const onBeforeUnload = (event: BeforeUnloadEvent) => event.preventDefault()
    window.addEventListener("beforeunload", onBeforeUnload)
    return () => window.removeEventListener("beforeunload", onBeforeUnload)
  }, [isDirty, isSubmitted])
  React.useEffect(() => {
    if (serverError) errorRef.current?.focus()
  }, [serverError])
  const touchedCurrency = React.useRef({ reporting: !!deal, analysis: !!deal })

  const { countries, currencies, sectors } = meta.reference
  const countryOptions: Option[] = React.useMemo(
    () => countries.map((c) => ({ value: c.code, label: c.name, hint: c.code })).sort((a, b) => a.label.localeCompare(b.label)),
    [countries],
  )
  const currencyOptions: Option[] = React.useMemo(
    () => currencies.map((c) => ({ value: c.code, label: `${c.code}: ${c.name}` })),
    [currencies],
  )
  const sector = useWatch({ control: form.control, name: "sector" })
  const listed = useWatch({ control: form.control, name: "listed" })
  const industries = sectors.find((s) => s.id === sector)?.industries ?? []

  function onCountryChange(code: string | null) {
    form.setValue("country", code ?? "", { shouldValidate: true, shouldDirty: true })
    const currency = countries.find((c) => c.code === code)?.currency
    if (!currency) return
    if (!touchedCurrency.current.reporting) {
      form.setValue("reporting_currency", currency, { shouldValidate: true })
      if (!touchedCurrency.current.analysis) form.setValue("analysis_currency", currency, { shouldValidate: true })
    }
  }

  async function submit(values: DealFormValues) {
    setServerError(null)
    try {
      await onSubmit(toInput(values))
    } catch (error) {
      if (error instanceof ApiError && error.fieldErrors) {
        for (const [field, message] of Object.entries(error.fieldErrors)) {
          if (field in values) form.setError(field as keyof DealFormValues, { message })
        }
      }
      setServerError(error instanceof Error ? error.message : "Saving failed. Try again.")
    }
  }

  const err = form.formState.errors
  const submitting = form.formState.isSubmitting

  return (
    <form id={formId} noValidate onSubmit={form.handleSubmit(submit)} className="flex flex-col gap-6">
      {serverError ? (
        <Alert variant="destructive" ref={errorRef} tabIndex={-1} role="alert">
          <AlertTitle>The deal was not saved</AlertTitle>
          <AlertDescription>{serverError}</AlertDescription>
        </Alert>
      ) : null}

      <FieldSet>
        <FieldLegend>Target</FieldLegend>
        <FieldGroup>
          <Field data-invalid={!!err.name || undefined}>
            <FieldLabel htmlFor="deal-name">Company name</FieldLabel>
            <Input
              id="deal-name"
              autoComplete="organization"
              aria-invalid={!!err.name || undefined}
              {...form.register("name")}
            />
            <FieldError errors={[err.name]} />
          </Field>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field data-invalid={!!err.country || undefined}>
              <FieldLabel htmlFor="deal-country">Country</FieldLabel>
              <Controller
                control={form.control}
                name="country"
                render={({ field }) => (
                  <SearchSelect
                    id="deal-country"
                    options={countryOptions}
                    value={field.value || null}
                    onChange={onCountryChange}
                    placeholder="Search countries…"
                    invalid={!!err.country}
                    emptyText="No country matches."
                  />
                )}
              />
              <FieldError errors={[err.country]} />
            </Field>

            <Field data-invalid={!!err.sector || undefined}>
              <FieldLabel htmlFor="deal-sector">Sector</FieldLabel>
              <Controller
                control={form.control}
                name="sector"
                render={({ field }) => (
                  <Select
                    items={sectors.map((s) => ({ value: s.id, label: s.name }))}
                    value={field.value || null}
                    onValueChange={(value) => field.onChange(value ?? "")}
                  >
                    <SelectTrigger id="deal-sector" className="w-full" aria-invalid={!!err.sector || undefined}>
                      <SelectValue placeholder="Choose a sector" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        {sectors.map((s) => (
                          <SelectItem key={s.id} value={s.id}>
                            {s.name}
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                )}
              />
              <FieldError errors={[err.sector]} />
            </Field>
          </div>

          <Field>
            <FieldLabel htmlFor="deal-industry">Industry</FieldLabel>
            <Input id="deal-industry" list="deal-industry-options" autoComplete="off" {...form.register("industry")} />
            <datalist id="deal-industry-options">
              {industries.map((i) => (
                <option key={i} value={i} />
              ))}
            </datalist>
            <FieldDescription>
              {industries.length ? "Pick a suggestion or type your own." : "Optional. Choose a sector for suggestions."}
            </FieldDescription>
          </Field>

          <div className="grid gap-4 sm:grid-cols-2 sm:items-start">
            <Field orientation="horizontal" className="sm:pt-6">
              <Controller
                control={form.control}
                name="listed"
                render={({ field }) => (
                  <Switch id="deal-listed" checked={field.value} onCheckedChange={(checked) => field.onChange(checked)} />
                )}
              />
              <FieldLabel htmlFor="deal-listed">Listed company</FieldLabel>
            </Field>
            <Field data-disabled={!listed || undefined}>
              <FieldLabel htmlFor="deal-ticker">Ticker</FieldLabel>
              <Input
                id="deal-ticker"
                autoComplete="off"
                spellCheck={false}
                disabled={!listed}
                placeholder={listed ? "e.g. SIE…" : "Private company"}
                className="uppercase placeholder:normal-case"
                {...form.register("ticker")}
              />
              <FieldDescription>Optional, used for market reference points.</FieldDescription>
            </Field>
          </div>
        </FieldGroup>
      </FieldSet>

      <FieldSet>
        <FieldLegend>Analysis</FieldLegend>
        <FieldGroup>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field data-invalid={!!err.reporting_currency || undefined}>
              <FieldLabel htmlFor="deal-rep-ccy">Reporting currency</FieldLabel>
              <Controller
                control={form.control}
                name="reporting_currency"
                render={({ field }) => (
                  <SearchSelect
                    id="deal-rep-ccy"
                    options={currencyOptions}
                    value={field.value || null}
                    onChange={(code) => {
                      touchedCurrency.current.reporting = true
                      field.onChange(code ?? "")
                      if (!touchedCurrency.current.analysis && code) form.setValue("analysis_currency", code, { shouldValidate: true })
                    }}
                    placeholder="e.g. EUR…"
                    invalid={!!err.reporting_currency}
                  />
                )}
              />
              <FieldDescription>The currency of the financial statements.</FieldDescription>
              <FieldError errors={[err.reporting_currency]} />
            </Field>
            <Field data-invalid={!!err.analysis_currency || undefined}>
              <FieldLabel htmlFor="deal-ana-ccy">Analysis currency</FieldLabel>
              <Controller
                control={form.control}
                name="analysis_currency"
                render={({ field }) => (
                  <SearchSelect
                    id="deal-ana-ccy"
                    options={currencyOptions}
                    value={field.value || null}
                    onChange={(code) => {
                      touchedCurrency.current.analysis = true
                      field.onChange(code ?? "")
                    }}
                    placeholder="e.g. USD…"
                    invalid={!!err.analysis_currency}
                  />
                )}
              />
              <FieldDescription>Valuation outputs are shown in this currency.</FieldDescription>
              <FieldError errors={[err.analysis_currency]} />
            </Field>
          </div>

          <Field data-invalid={!!err.valuation_date || undefined} className="sm:max-w-[calc(50%-0.5rem)]">
            <FieldLabel htmlFor="deal-date">Valuation date</FieldLabel>
            <Input id="deal-date" type="date" aria-invalid={!!err.valuation_date || undefined} {...form.register("valuation_date")} />
            <FieldError errors={[err.valuation_date]} />
          </Field>

          <Field>
            <FieldLabel id="deal-perspective-label">Buyer perspective</FieldLabel>
            <Controller
              control={form.control}
              name="perspective"
              render={({ field }) => (
                <ToggleGroup
                  variant="outline"
                  aria-labelledby="deal-perspective-label"
                  value={[field.value]}
                  onValueChange={(v: string[]) => v[0] && field.onChange(v[0])}
                >
                  <ToggleGroupItem value="financial_sponsor">Financial sponsor</ToggleGroupItem>
                  <ToggleGroupItem value="strategic">Strategic buyer</ToggleGroupItem>
                </ToggleGroup>
              )}
            />
            <FieldDescription>Sponsors are anchored by LBO returns; strategic buyers can pay away part of the synergies.</FieldDescription>
          </Field>

          <Field>
            <FieldLabel id="deal-mode-label">Mode</FieldLabel>
            <Controller
              control={form.control}
              name="mode"
              render={({ field }) => (
                <ToggleGroup
                  variant="outline"
                  aria-labelledby="deal-mode-label"
                  value={[field.value]}
                  onValueChange={(v: string[]) => v[0] && field.onChange(v[0])}
                >
                  <ToggleGroupItem value="quick">Quick Scan</ToggleGroupItem>
                  <ToggleGroupItem value="detailed">Detailed</ToggleGroupItem>
                </ToggleGroup>
              )}
            />
            <FieldDescription>Quick Scan uses one growth fade and single driver values; Detailed sets each projection year and shows every method. You can switch later.</FieldDescription>
          </Field>

          <Field>
            <FieldLabel htmlFor="deal-notes">Notes</FieldLabel>
            <Textarea id="deal-notes" rows={3} {...form.register("notes")} />
          </Field>
        </FieldGroup>
      </FieldSet>

      <div className="flex flex-wrap items-center justify-end gap-2 border-t pt-4">
        {onCancel ? (
          <Button type="button" variant="ghost" onClick={onCancel} disabled={submitting}>
            Cancel
          </Button>
        ) : null}
        <Button type="submit" disabled={submitting}>
          {submitting ? <Spinner data-icon="inline-start" /> : null}
          {submitLabel}
        </Button>
      </div>
    </form>
  )
}
