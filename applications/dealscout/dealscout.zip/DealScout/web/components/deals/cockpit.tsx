"use client"

import * as React from "react"
import Link from "next/link"
import { ArrowRightIcon, CheckIcon, CircleAlertIcon, ListChecksIcon, TriangleAlertIcon } from "lucide-react"

import { FootballFieldChart, type FootballRow } from "@/components/charts/valuation-charts"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { formatAccounting, formatMoneyCompact, formatMultiple, formatPct } from "@/lib/format"
import { useAnalysis, useRecommendation, useReview, useValuation } from "@/lib/queries"
import type { Deal, LBOResultPayload, MethodOutput, RecommendationResponse, ValuationResponse } from "@/lib/types"
import { cn } from "@/lib/utils"

/** Where each method's inputs live on the Valuation tab. */
const METHOD_SUBTAB: Record<string, string> = {
  dcf: "summary",
  comps_ev_revenue: "summary",
  comps_ev_ebitda: "summary",
  comps_ev_ebit: "summary",
  comps_pe: "summary",
  comps_pb: "summary",
  lbo: "lbo",
  precedents: "precedents",
  nav: "nav",
  sotp: "nav",
  ddm: "fi",
  residual_income: "fi",
  ptbv: "fi",
  fcfe: "fi",
  apv: "fi",
  strategic: "strategic",
  liquidation: "other",
  replacement: "other",
}

const GRADE_VARIANT = { A: "positive", B: "positive", C: "warning", D: "negative" } as const

export interface TodoItem {
  key: string
  label: string
  detail: string
  href: string
  tone: "high" | "medium" | "info"
}

/** Everything still standing between the analyst and a defensible price, most important first. */
export function buildTodos(
  dealId: string,
  v: ValuationResponse | undefined,
  r: RecommendationResponse | undefined,
  analysis: { red_flags: { id: string; signal: string; period: string; severity: string }[] } | undefined,
  pendingReview: number,
): TodoItem[] {
  const href = (tab: string, method?: string) => `/deal?id=${dealId}&tab=${tab}${method ? `&method=${method}` : ""}`
  const out: TodoItem[] = []
  if (pendingReview > 0) {
    out.push({ key: "review", label: `Review ${pendingReview} extracted value${pendingReview === 1 ? "" : "s"}`, detail: "Only accepted values reach the analysis.", href: href("review"), tone: "high" })
  }
  const missing = v?.result.assumptions.filter((a) => a.source === "missing").map((a) => a.label) ?? []
  if (missing.length) {
    out.push({ key: "dcf", label: "Enter the missing DCF inputs", detail: missing.slice(0, 4).join(", ") + (missing.length > 4 ? "…" : ""), href: href("valuation", "summary"), tone: "high" })
  }
  for (const s of r?.suitability ?? []) {
    if (s.relevance === "primary" && !s.available && s.method_id !== "dcf") {
      out.push({ key: `method-${s.method_id}`, label: `Complete ${s.label}`, detail: s.reason, href: href("valuation", METHOD_SUBTAB[s.method_id] ?? "price"), tone: "medium" })
    }
  }
  for (const c of r?.recommendation?.checks ?? []) {
    if (c.status === "warn" || c.status === "fail") {
      out.push({ key: `check-${c.label}`, label: `Resolve: ${c.label}`, detail: c.detail, href: href("valuation", "price"), tone: c.status === "fail" ? "high" : "medium" })
    }
  }
  const pendingOneOffs = v?.normalisation?.pending_suggestions ?? 0
  if (pendingOneOffs > 0) {
    out.push({ key: "oneoffs", label: `Confirm ${pendingOneOffs} suggested one-off item${pendingOneOffs === 1 ? "" : "s"}`, detail: "AI suggestions change nothing until you confirm them.", href: href("analysis"), tone: "medium" })
  }
  for (const f of analysis?.red_flags ?? []) {
    if (f.severity === "high" || f.severity === "medium") {
      out.push({ key: `flag-${f.id}-${f.period}`, label: `Check ${f.signal.toLowerCase()}`, detail: `Early warning sign, ${f.period}.`, href: href("analysis"), tone: f.severity === "high" ? "high" : "medium" })
    }
  }
  if (r?.rationale?.stale) {
    out.push({ key: "rationale", label: "Rewrite the price rationale", detail: "Inputs changed since the AI wrote it.", href: href("valuation", "price"), tone: "info" })
  }
  const rank = { high: 0, medium: 1, info: 2 }
  return out.sort((a, b) => rank[a.tone] - rank[b.tone])
}

function Kpi({ label, value, hint }: { label: string; value: React.ReactNode; hint?: React.ReactNode }) {
  return (
    <div className="flex min-w-0 flex-col gap-0.5 bg-background px-3 py-2.5">
      <dt className="truncate text-xs text-muted-foreground">{label}</dt>
      <dd className="text-lg font-semibold tabular-nums">{value}</dd>
      {hint ? <dd className="truncate text-xs text-muted-foreground">{hint}</dd> : null}
    </div>
  )
}

function Todos({ items }: { items: TodoItem[] }) {
  return (
    <section aria-labelledby="todo-title" className="flex min-w-0 flex-col gap-2">
      <h2 id="todo-title" className="flex items-center gap-1.5 text-sm font-semibold">
        <ListChecksIcon aria-hidden className="size-4" />
        To do
        {items.length ? <span className="text-xs font-normal text-muted-foreground">({items.length})</span> : null}
      </h2>
      {items.length === 0 ? (
        <p className="flex items-center gap-2 rounded-lg border px-3 py-3 text-sm">
          <CheckIcon aria-hidden className="size-4 text-positive" />
          Nothing outstanding. Export the analysis when you&rsquo;re ready.
        </p>
      ) : (
        <ul className="divide-y rounded-lg border">
          {items.slice(0, 8).map((t) => (
            <li key={t.key}>
              <Link
                href={t.href}
                className="group flex items-start gap-2.5 px-3 py-2 outline-none hover:bg-muted/60 focus-visible:bg-muted/60 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-inset"
              >
                {t.tone === "high" ? (
                  <CircleAlertIcon aria-hidden className="mt-0.5 size-4 shrink-0 text-negative" />
                ) : t.tone === "medium" ? (
                  <TriangleAlertIcon aria-hidden className="mt-0.5 size-4 shrink-0 text-warning" />
                ) : (
                  <ArrowRightIcon aria-hidden className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
                )}
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-medium group-hover:underline">{t.label}</span>
                  <span className="line-clamp-2 block text-xs text-muted-foreground">{t.detail}</span>
                </span>
                <span className="sr-only">{t.tone === "high" ? "(important)" : t.tone === "medium" ? "(to check)" : ""}</span>
              </Link>
            </li>
          ))}
        </ul>
      )}
      {items.length > 8 ? <p className="text-xs text-muted-foreground">And {items.length - 8} more on the tabs.</p> : null}
    </section>
  )
}

export function CockpitSkeleton() {
  return (
    <div className="flex flex-col gap-4" aria-busy aria-label="Loading the deal summary">
      <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_15rem]">
        <Skeleton className="h-28 w-full" />
        <Skeleton className="h-28 w-full" />
      </div>
      <div className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border sm:grid-cols-3 lg:grid-cols-5">
        {Array.from({ length: 5 }, (_, i) => (
          <Skeleton key={i} className="h-[4.5rem] rounded-none" />
        ))}
      </div>
      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
        <Skeleton className="h-64 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    </div>
  )
}

export function Cockpit({ deal }: { deal: Deal }) {
  const { data: r, isPending: rPending } = useRecommendation(deal.id)
  const { data: v } = useValuation(deal.id)
  const { data: analysis } = useAnalysis(deal.id)
  const { data: review } = useReview(deal.id)
  if (rPending) return <CockpitSkeleton />
  const cur = r?.deal.currency ?? analysis?.currency ?? deal.reporting_currency // the analysis currency once converted
  const rec = r?.recommendation
  const pending = review?.items.filter((i) => i.status === "pending").length ?? 0
  const todos = buildTodos(deal.id, v, r, analysis, pending)
  const latest = analysis?.periods[analysis.periods.length - 1]
  const ratio = (id: string) => analysis?.ratios.find((x) => x.ratio_id === id && x.period_id === latest)?.value ?? null
  const lbo = v?.methods.find((m) => m.id === "lbo") as MethodOutput<LBOResultPayload> | undefined
  const warnings = analysis?.red_flags.filter((f) => f.severity !== "none") ?? []
  const dq = r?.data_quality
  const ff = r?.football_field
  const rows: FootballRow[] = ff
    ? ff.methods
        .filter((m) => m.included && (ff.weights_normalised[m.method_id] ?? 0) > 0)
        .map((m) => ({ label: m.label, low: m.equity_low, mid: m.equity_mid, high: m.equity_high }))
    : []

  return (
    <div className="flex flex-col gap-4">
      {/* the answer: price range and how much to trust it */}
      <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_15rem]">
        <section aria-label="Suggested acquisition price" className="rounded-lg border bg-band px-4 py-3">
          <p className="text-xs font-medium text-muted-foreground">Suggested acquisition price, 100% of equity</p>
          {rec ? (
            <>
              <p className="mt-1 text-2xl font-semibold tracking-tight tabular-nums">
                {formatMoneyCompact(rec.equity_low, cur)} to {formatMoneyCompact(rec.equity_high, cur)}
                <span className="ml-2 text-base font-normal text-muted-foreground">mid {formatMoneyCompact(rec.equity_mid, cur)}</span>
              </p>
              <p className="mt-0.5 text-sm text-muted-foreground tabular-nums">
                {rec.per_share
                  ? `${cur} ${formatAccounting(rec.per_share[0], 2)} to ${formatAccounting(rec.per_share[2], 2)} per diluted share`
                  : "No per-share values: the share count is unknown."}
                {rec.implied["EV / EBITDA"][1] ? ` · ${formatMultiple(rec.implied["EV / EBITDA"][1])} EBITDA at mid` : ""}
              </p>
              <Link href={`/deal?id=${deal.id}&tab=valuation&method=price`} className="mt-1 inline-flex items-center gap-1 text-xs text-link hover:underline">
                Checks, rationale and weights
                <ArrowRightIcon aria-hidden className="size-3" />
              </Link>
            </>
          ) : (
            <p className="mt-1 text-sm">
              No price yet. Work through the to-do list: the range appears as soon as one weighted method has its inputs.
            </p>
          )}
        </section>
        {dq ? (
          <section aria-label="Data quality" className="flex flex-col gap-1 rounded-lg border px-4 py-3">
            <p className="text-xs font-medium text-muted-foreground">Data quality</p>
            <p className="flex items-baseline gap-2">
              <span className="text-2xl font-semibold tabular-nums">{dq.score}</span>
              <span className="text-sm text-muted-foreground">/ 100</span>
              <Badge variant={GRADE_VARIANT[dq.grade]} className="ml-auto">Grade {dq.grade}</Badge>
            </p>
            <p className="text-xs text-muted-foreground">{dq.notes[0] ?? "Figures are confident and assumptions company-specific."}</p>
          </section>
        ) : null}
      </div>

      {/* five headline numbers */}
      <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border bg-border sm:grid-cols-3 lg:grid-cols-5">
        <Kpi
          label={`Revenue (${cur})`}
          value={v?.result.base_revenue != null ? formatMoneyCompact(v.result.base_revenue, cur) : "–"}
          hint={v?.result.base_period ?? "No figures yet"}
        />
        <Kpi label="EBITDA margin" value={formatPct(ratio("ebitda_margin"))} hint={latest} />
        <Kpi label="Net debt / EBITDA" value={formatMultiple(ratio("net_debt_to_ebitda"))} hint={latest} />
        <Kpi
          label="LBO sponsor IRR"
          value={lbo?.result ? formatPct(lbo.result.case.sponsor.irr) : "–"}
          hint={lbo?.result ? `at ${formatMultiple(lbo.result.inputs.entry_multiple)} entry, your financing` : "Enter financing on the LBO tab"}
        />
        <Kpi
          label="Warning signs"
          value={
            <span className={cn("inline-flex items-center gap-1", warnings.some((w) => w.severity === "high") && "text-negative")}>
              {warnings.length ? <TriangleAlertIcon aria-hidden className="size-4" /> : <CheckIcon aria-hidden className="size-4 text-positive" />}
              {warnings.length}
            </span>
          }
          hint={warnings.length ? `${warnings.filter((w) => w.severity === "high").length} high` : "None from the rules tested"}
        />
      </dl>

      {/* the evidence and what is left to do */}
      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
        <div className="min-w-0">
          {rows.length && rec ? (
            <FootballFieldChart
              title="Football field"
              rows={rows}
              currency={cur}
              unitLabel={`Equity value (${cur})`}
              offer={{ low: rec.equity_low, high: rec.equity_high }}
              reference={ff?.market_cap ? { label: "Market cap", value: ff.market_cap } : null}
            />
          ) : (
            <div className="flex h-full min-h-40 flex-col items-center justify-center gap-1 rounded-lg border border-dashed px-4 py-8 text-center">
              <p className="text-sm font-medium">The football field appears with the first valuation</p>
              <p className="text-xs text-muted-foreground">Each method you complete adds a bar; the suggested offer is shaded across them.</p>
            </div>
          )}
        </div>
        <Todos items={todos} />
      </div>
    </div>
  )
}
