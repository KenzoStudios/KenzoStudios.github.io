"use client"

import * as React from "react"
import type * as echarts from "echarts"

import { formatMoneyCompact } from "@/lib/format"
import type { BridgeItem } from "@/lib/types"

import { baseOption, type ChartTokens, EChart, esc } from "./echart"

/**
 * Enterprise value to equity value at the suggested mid price. Totals are solid bars from zero; each bridge item floats
 * from the running total (chart geometry only — the amounts come from the engine). Debt-like items and cash-like
 * items use the two poles of the diverging palette and carry a sign in their label, so colour is never the only cue.
 */
export function BridgeWaterfall({
  ev,
  equity,
  items,
  currency,
}: {
  ev: number
  equity: number
  items: BridgeItem[]
  currency: string
}) {
  const steps = React.useMemo(() => items.filter((i) => i.included && i.amount !== 0), [items])
  const build = React.useCallback(
    (t: ChartTokens): echarts.EChartsOption => {
      const labels = ["Enterprise value", ...steps.map((s) => s.label), "Equity value"]
      const base: number[] = []
      const size: { value: number; itemStyle: { color: string; borderRadius: number } }[] = []
      let running = ev
      base.push(0)
      size.push({ value: ev, itemStyle: { color: t.emphasis, borderRadius: 4 } })
      for (const s of steps) {
        const next = running + s.amount
        base.push(Math.min(running, next))
        size.push({
          value: Math.abs(s.amount),
          itemStyle: { color: s.amount < 0 ? t.diverging[0] : t.diverging[t.diverging.length - 1], borderRadius: 2 },
        })
        running = next
      }
      base.push(0)
      size.push({ value: equity, itemStyle: { color: t.emphasis, borderRadius: 4 } })
      const signed = [ev, ...steps.map((s) => s.amount), equity]
      return {
        ...baseOption(t),
        grid: { left: 8, right: 8, top: 24, bottom: 8, containLabel: true },
        xAxis: {
          type: "category",
          data: labels,
          axisTick: { show: false },
          axisLine: { lineStyle: { color: t.grid } },
          axisLabel: { color: t.axis, interval: 0, width: 90, overflow: "break", fontSize: 11 },
        },
        yAxis: {
          type: "value",
          axisLabel: { color: t.axis, formatter: (v: number) => formatMoneyCompact(v, "").trim() },
          splitLine: { lineStyle: { color: t.grid } },
        },
        tooltip: {
          ...baseOption(t).tooltip,
          trigger: "axis",
          axisPointer: { type: "shadow" },
          formatter: (p: unknown) => {
            const i = (p as { dataIndex: number }[])[0].dataIndex
            const v = signed[i]
            const isStep = i > 0 && i < labels.length - 1
            return `<strong>${esc(labels[i])}</strong><br/>${isStep && v > 0 ? "+" : ""}${formatMoneyCompact(v, currency)}`
          },
        },
        series: [
          { type: "bar", stack: "w", data: base, itemStyle: { color: "transparent" }, silent: true, barMaxWidth: 48 },
          {
            type: "bar",
            stack: "w",
            data: size,
            barMaxWidth: 48,
            label: {
              show: true,
              position: "top",
              color: t.muted,
              fontSize: 11,
              formatter: (p: { dataIndex: number }) => {
                const v = signed[p.dataIndex]
                const isStep = p.dataIndex > 0 && p.dataIndex < labels.length - 1
                return `${isStep && v > 0 ? "+" : ""}${formatMoneyCompact(v, "").trim()}`
              },
            },
          },
        ],
      }
    },
    [ev, equity, steps, currency],
  )
  return (
    <EChart
      title="Enterprise value to equity value at the mid price"
      height={260}
      build={build}
      table={
        <table className="w-full text-[13px] tabular-nums">
          <tbody>
            <tr className="border-t font-semibold"><th scope="row" className="px-2 py-1 text-left">Enterprise value</th><td className="px-2 py-1 text-right">{formatMoneyCompact(ev, currency)}</td></tr>
            {steps.map((s) => (
              <tr key={s.key} className="border-t">
                <th scope="row" className="px-2 py-1 text-left font-normal">{s.amount < 0 ? "− " : "+ "}{s.label}</th>
                <td className="px-2 py-1 text-right">{formatMoneyCompact(Math.abs(s.amount), currency)}</td>
              </tr>
            ))}
            <tr className="border-t font-semibold"><th scope="row" className="px-2 py-1 text-left">Equity value</th><td className="px-2 py-1 text-right">{formatMoneyCompact(equity, currency)}</td></tr>
          </tbody>
        </table>
      }
    />
  )
}
