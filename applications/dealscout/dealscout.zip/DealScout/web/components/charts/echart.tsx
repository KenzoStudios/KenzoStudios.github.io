"use client"

import * as React from "react"
import * as echarts from "echarts"
import { DownloadIcon, TableIcon } from "lucide-react"
import { useTheme } from "next-themes"

import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuGroup, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import palette from "@/lib/palette.generated.json"

export type ChartMode = "light" | "dark"

export interface ChartTokens {
  mode: ChartMode
  categorical: string[]
  sequential: string[]
  diverging: string[]
  grid: string
  axis: string
  text: string
  emphasis: string
  surface: string
  muted: string
}

export function chartTokens(mode: ChartMode): ChartTokens {
  const c = palette.chart as Record<string, string | string[]>
  const pick = (key: string) => c[`${key}_${mode}`]
  return {
    mode,
    categorical: pick("categorical") as string[],
    sequential: pick("sequential") as string[],
    diverging: pick("diverging") as string[],
    grid: pick("grid") as string,
    axis: pick("axis") as string,
    text: pick("text") as string,
    emphasis: pick("emphasis") as string,
    surface: mode === "dark" ? "#121b28" : "#ffffff",
    muted: mode === "dark" ? "#93a0b1" : "#4e5866",
  }
}

/**
 * Escape text for ECharts tooltips: custom tooltip formatters return HTML, and names can come from documents,
 * imported deal files or the analyst (transaction targets, peers, method labels). Always wrap them.
 */
export function esc(text: unknown): string {
  return echarts.format.encodeHTML(String(text ?? ""))
}

export function baseOption(t: ChartTokens): echarts.EChartsOption {
  return {
    backgroundColor: "transparent",
    textStyle: { fontFamily: "Inter Variable, system-ui, sans-serif", color: t.text, fontSize: 12 },
    animationDuration: 200,
    animationDurationUpdate: 150,
    tooltip: {
      backgroundColor: t.surface,
      borderColor: t.grid,
      textStyle: { color: t.text, fontSize: 12 },
      extraCssText: "box-shadow:0 4px 16px rgba(0,0,0,.12);border-radius:6px;",
    },
  }
}

/**
 * ECharts in a responsive container. Re-themes on light/dark switch. Every chart offers PNG/SVG download and a table
 * view (charts are never the only way to read the numbers).
 */
export function EChart({
  build,
  height = 280,
  title,
  table,
  className,
}: {
  build: (t: ChartTokens) => echarts.EChartsOption
  height?: number
  title: string
  table?: React.ReactNode
  className?: string
}) {
  const ref = React.useRef<HTMLDivElement>(null)
  const chartRef = React.useRef<echarts.ECharts | null>(null)
  const { resolvedTheme } = useTheme()
  const mode: ChartMode = resolvedTheme === "dark" ? "dark" : "light"
  const [showTable, setShowTable] = React.useState(false)

  React.useEffect(() => {
    if (!ref.current || showTable) return
    const chart = echarts.init(ref.current, undefined, { renderer: "svg" })
    chartRef.current = chart
    const observer = new ResizeObserver(() => chart.resize())
    observer.observe(ref.current)
    return () => {
      observer.disconnect()
      chart.dispose()
      chartRef.current = null
    }
  }, [showTable])

  React.useEffect(() => {
    if (showTable) return
    chartRef.current?.setOption(build(chartTokens(mode)), { notMerge: true })
  }, [build, mode, showTable])

  const download = (type: "png" | "svg") => {
    const chart = chartRef.current
    if (!chart) return
    const url =
      type === "svg"
        ? `data:image/svg+xml;charset=utf-8,${encodeURIComponent(chart.renderToSVGString())}`
        : chart.getDataURL({ type: "png", pixelRatio: 2, backgroundColor: chartTokens(mode).surface })
    const a = document.createElement("a")
    a.href = url
    a.download = `${title.replace(/[^a-z0-9]+/gi, "_").toLowerCase()}.${type === "svg" ? "svg" : "png"}`
    a.click()
  }

  return (
    <figure className={className}>
      <div className="flex items-center justify-between gap-2">
        <figcaption className="text-sm font-medium">{title}</figcaption>
        <div className="flex items-center gap-1">
          {table ? (
            <Button variant="ghost" size="sm" aria-pressed={showTable} onClick={() => setShowTable((v) => !v)}>
              <TableIcon data-icon="inline-start" />
              {showTable ? "Chart" : "Table"}
            </Button>
          ) : null}
          {!showTable ? (
            <DropdownMenu>
              <DropdownMenuTrigger render={<Button variant="ghost" size="icon-sm" aria-label={`Download ${title}`} />}>
                <DownloadIcon />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuGroup>
                  <DropdownMenuItem onClick={() => download("png")}>Download PNG</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => download("svg")}>Download SVG</DropdownMenuItem>
                </DropdownMenuGroup>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : null}
        </div>
      </div>
      {showTable ? (
        <div className="relative mt-2 overflow-x-auto">{table}</div>
      ) : (
        <div ref={ref} role="img" aria-label={`${title} chart. Use the Table button for the underlying figures.`} style={{ height }} />
      )}
    </figure>
  )
}
