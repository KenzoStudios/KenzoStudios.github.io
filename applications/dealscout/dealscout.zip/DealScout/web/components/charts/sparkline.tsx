"use client"

/** Tiny inline trend line (SVG, no axes) for ratio tables. Decorative: the numbers sit beside it. */
export function Sparkline({ values, width = 64, height = 18 }: { values: (number | null)[]; width?: number; height?: number }) {
  const points = values.map((v, i) => ({ v, i })).filter((p): p is { v: number; i: number } => p.v !== null && Number.isFinite(p.v))
  if (points.length < 2) return <span className="inline-block" style={{ width, height }} aria-hidden />
  const min = Math.min(...points.map((p) => p.v))
  const max = Math.max(...points.map((p) => p.v))
  const span = max - min || 1
  const x = (i: number) => (i / Math.max(values.length - 1, 1)) * (width - 4) + 2
  const y = (v: number) => height - 2 - ((v - min) / span) * (height - 4)
  const d = points.map((p, idx) => `${idx ? "L" : "M"}${x(p.i).toFixed(1)},${y(p.v).toFixed(1)}`).join(" ")
  const last = points[points.length - 1]
  return (
    <svg width={width} height={height} aria-hidden className="inline-block overflow-visible align-middle text-chart-1">
      <path d={d} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" />
      <circle cx={x(last.i)} cy={y(last.v)} r={2} fill="currentColor" />
    </svg>
  )
}
