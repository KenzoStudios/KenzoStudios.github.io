"use client"

import * as React from "react"
import type * as echarts from "echarts"

import { formatAccounting, formatMultiple } from "@/lib/format"
import type { LBOResultPayload } from "@/lib/types"

import { baseOption, type ChartTokens, EChart } from "./echart"

function Table({ head, rows }: { head: string[]; rows: (string | number)[][] }) {
  return (
    <table className="w-full text-[13px] tabular-nums">
      <thead className="text-xs text-muted-foreground">
        <tr>{head.map((h, i) => <th key={h} className={i ? "px-2 py-1 text-right" : "px-2 py-1 text-left"}>{h}</th>)}</tr>
      </thead>
      <tbody>
        {rows.map((r, i) => (
          <tr key={i} className="border-t">
            {r.map((c, j) => <td key={j} className={j ? "px-2 py-1 text-right" : "px-2 py-1"}>{c}</td>)}
          </tr>
        ))}
      </tbody>
    </table>
  )
}

/**
 * Debt outstanding by tranche at close and at each year end. Stacked bars (one per year, discrete balances), tranche
 * colours in the fixed categorical order of the financing structure; a legend for ≥ 2 tranches and the total above
 * each bar.
 */
export function DebtPaydownChart({
  lbo,
  scale,
  unit,
}: {
  lbo: LBOResultPayload
  scale: number
  unit: string
}) {
  const { names, labels, balances, totals } = React.useMemo(() => {
    const schedule = lbo.case.schedule
    const names = schedule[0]?.tranches.map((t) => t.name) ?? []
    const labels = ["Close", ...schedule.map((y) => y.label)]
    const balances = names.map((name) => [
      schedule[0]?.tranches.find((t) => t.name === name)?.opening ?? 0,
      ...schedule.map((y) => y.tranches.find((t) => t.name === name)?.closing ?? 0),
    ])
    // chart labels only: the stacked total shown above each bar
    const totals = labels.map((_, i) => balances.reduce((sum, b) => sum + b[i], 0))
    return { names, labels, balances, totals }
  }, [lbo])
  const fmt = React.useCallback((v: number) => formatAccounting(v / scale, 0), [scale])
  const build = React.useCallback(
    (t: ChartTokens): echarts.EChartsOption => ({
      ...baseOption(t),
      grid: { left: 8, right: 8, top: names.length > 1 ? 36 : 16, bottom: 8, containLabel: true },
      legend: names.length > 1 ? { top: 0, left: 0, icon: "roundRect", itemWidth: 10, itemHeight: 10, textStyle: { color: t.text, fontSize: 12 } } : undefined,
      xAxis: { type: "category", data: labels, axisTick: { show: false }, axisLine: { lineStyle: { color: t.grid } }, axisLabel: { color: t.axis } },
      yAxis: {
        type: "value",
        axisLabel: { color: t.axis, formatter: (v: number) => fmt(v) },
        splitLine: { lineStyle: { color: t.grid } },
        name: unit,
        nameTextStyle: { color: t.axis, fontSize: 11, align: "left" },
      },
      tooltip: {
        ...baseOption(t).tooltip,
        trigger: "axis",
        axisPointer: { type: "shadow" },
        valueFormatter: (v) => `${fmt(Number(v))} ${unit}`,
      },
      series: names.map((name, k) => ({
        name,
        type: "bar" as const,
        stack: "debt",
        barMaxWidth: 36,
        data: balances[k],
        itemStyle: {
          color: t.categorical[k % t.categorical.length],
          borderColor: t.surface,
          borderWidth: 1, // the 2px surface gap between stacked segments (1px each side)
          borderRadius: k === names.length - 1 ? [4, 4, 0, 0] : 0,
        },
        emphasis: { focus: "series" as const },
        label:
          k === names.length - 1
            ? {
                show: true,
                position: "top" as const,
                color: t.muted,
                fontSize: 11,
                formatter: (p: { dataIndex: number }) => fmt(totals[p.dataIndex]),
              }
            : undefined,
      })),
    }),
    [names, labels, balances, totals, fmt, unit],
  )
  return (
    <EChart
      title="Debt paydown by tranche"
      height={260}
      build={build}
      table={<Table head={["Tranche", ...labels]} rows={[...names.map((n, k) => [n, ...balances[k].map(fmt)]), ["Total", ...totals.map(fmt)]]} />}
    />
  )
}

/** Net debt / EBITDA by year, with the leverage covenant as a dashed reference line. One series: no legend. */
export function LeverageChart({ lbo, covenant }: { lbo: LBOResultPayload; covenant: number | null }) {
  const { labels, values } = React.useMemo(
    () => ({
      labels: ["Close", ...lbo.case.schedule.map((y) => y.label)],
      values: [lbo.case.leverage_at_close, ...lbo.case.schedule.map((y) => y.leverage)],
    }),
    [lbo],
  )
  const build = React.useCallback(
    (t: ChartTokens): echarts.EChartsOption => ({
      ...baseOption(t),
      grid: { left: 8, right: 64, top: 16, bottom: 8, containLabel: true },
      xAxis: { type: "category", data: labels, boundaryGap: false, axisTick: { show: false }, axisLine: { lineStyle: { color: t.grid } }, axisLabel: { color: t.axis } },
      yAxis: {
        type: "value",
        min: 0,
        // keep the covenant line on the chart even when leverage stays below it
        max: covenant ? (extent: { max: number }) => Math.ceil(Math.max(extent.max, covenant) * 1.1) : undefined,
        axisLabel: { color: t.axis, formatter: (v: number) => `${v.toFixed(1)}x` },
        splitLine: { lineStyle: { color: t.grid } },
      },
      tooltip: {
        ...baseOption(t).tooltip,
        trigger: "axis",
        axisPointer: { type: "line", lineStyle: { color: t.axis } },
        valueFormatter: (v) => (v === null || v === undefined ? "n/m" : formatMultiple(Number(v))),
      },
      series: [
        {
          name: "Net debt / EBITDA",
          type: "line",
          data: values,
          symbol: "circle",
          symbolSize: 8,
          lineStyle: { width: 2, color: t.categorical[0] },
          itemStyle: { color: t.categorical[0], borderColor: t.surface, borderWidth: 2 },
          label: {
            show: true,
            position: "top",
            color: t.muted,
            fontSize: 11,
            formatter: (p: { dataIndex: number }) =>
              p.dataIndex === 0 || p.dataIndex === values.length - 1 ? formatMultiple(values[p.dataIndex]) : "",
          },
          markLine: covenant
            ? {
                symbol: "none",
                silent: true,
                lineStyle: { color: t.text, type: "dashed", width: 1.5 },
                label: { formatter: `Covenant ${formatMultiple(covenant)}`, color: t.text, fontSize: 11, position: "end" },
                data: [{ yAxis: covenant }],
              }
            : undefined,
        },
      ],
    }),
    [labels, values, covenant],
  )
  return (
    <EChart
      title="Leverage (net debt / EBITDA)"
      height={220}
      build={build}
      table={
        <Table
          head={["Year", "Net debt / EBITDA", "EBITDA / cash interest"]}
          rows={labels.map((l, i) => [
            l,
            formatMultiple(values[i]),
            i === 0 ? "" : formatMultiple(lbo.case.schedule[i - 1].interest_coverage),
          ])}
        />
      }
    />
  )
}
