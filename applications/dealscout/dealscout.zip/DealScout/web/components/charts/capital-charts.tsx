"use client"

import * as React from "react"
import type * as echarts from "echarts"

import { formatMoneyCompact, formatMultiple, formatPct } from "@/lib/format"
import type { CapitalStructure } from "@/lib/types"

import { baseOption, type ChartTokens, EChart } from "./echart"

function Table({ head, rows }: { head: string[]; rows: (string | number)[][] }) {
  return (
    <table className="w-full text-[13px] tabular-nums">
      <thead className="text-xs text-muted-foreground">
        <tr>{head.map((h, i) => <th key={h} className={i ? "px-2 py-1 text-right" : "px-2 py-1 text-left"}>{h}</th>)}</tr>
      </thead>
      <tbody>
        {rows.map((r, i) => (
          <tr key={i} className="border-t">
            {r.map((c, j) => <td key={j} className={j ? "px-2 py-1 text-right" : "px-2 py-1"}>{c}</td>)}
          </tr>
        ))}
      </tbody>
    </table>
  )
}

const PARTS = [
  { key: "debt", label: "Borrowings" },
  { key: "leases", label: "Lease liabilities" },
  { key: "equity", label: "Book equity" },
] as const

/** Periods with at least one of borrowings, leases or equity. */
export function capitalPeriods(items: CapitalStructure[] | undefined): CapitalStructure[] {
  return (items ?? []).filter((c) => c.debt !== null || c.leases !== null || c.equity !== null)
}

/**
 * Capital structure by balance-sheet date: borrowings, lease liabilities and book equity as stacked bars in a fixed
 * categorical order, 2px surface gap between segments, the debt share of capital labelled above each bar.
 */
export function CapitalStructureChart({ items, currency }: { items: CapitalStructure[]; currency: string }) {
  const { labels, values, share } = React.useMemo(() => {
    const labels = items.map((c) => c.period)
    const values = PARTS.map((p) => items.map((c) => Math.max(c[p.key] ?? 0, 0)))
    const share = items.map((c) =>
      c.total_capital ? (Math.max(c.debt ?? 0, 0) + Math.max(c.leases ?? 0, 0)) / c.total_capital : null,
    )
    return { labels, values, share }
  }, [items])
  const fmt = React.useCallback((v: number) => formatMoneyCompact(v, currency), [currency])
  const build = React.useCallback(
    (t: ChartTokens): echarts.EChartsOption => ({
      ...baseOption(t),
      grid: { left: 8, right: 8, top: 40, bottom: 8, containLabel: true },
      legend: { top: 0, left: 0, icon: "roundRect", itemWidth: 10, itemHeight: 10, textStyle: { color: t.text, fontSize: 12 } },
      xAxis: { type: "category", data: labels, axisTick: { show: false }, axisLine: { lineStyle: { color: t.grid } }, axisLabel: { color: t.axis } },
      yAxis: {
        type: "value",
        axisLabel: { color: t.axis, formatter: (v: number) => fmt(v) },
        splitLine: { lineStyle: { color: t.grid } },
      },
      tooltip: {
        ...baseOption(t).tooltip,
        trigger: "axis",
        axisPointer: { type: "shadow" },
        valueFormatter: (v) => fmt(Number(v)),
      },
      series: PARTS.map((p, k) => ({
        name: p.label,
        type: "bar" as const,
        stack: "capital",
        barMaxWidth: 40,
        data: values[k],
        itemStyle: {
          color: t.categorical[k],
          borderColor: t.surface,
          borderWidth: 1,
          borderRadius: k === PARTS.length - 1 ? [4, 4, 0, 0] : 0,
        },
        emphasis: { focus: "series" as const },
        label:
          k === PARTS.length - 1
            ? {
                show: true,
                position: "top" as const,
                color: t.muted,
                fontSize: 11,
                formatter: (q: { dataIndex: number }) => (share[q.dataIndex] === null ? "" : `Debt ${formatPct(share[q.dataIndex], 0)}`),
              }
            : undefined,
      })),
    }),
    [labels, values, share, fmt],
  )
  return (
    <EChart
      title="Capital structure"
      height={260}
      build={build}
      table={
        <Table
          head={["Item", ...labels]}
          rows={[
            ...PARTS.map((p) => [p.label, ...items.map((c) => (c[p.key] === null ? "n/a" : fmt(c[p.key] as number)))]),
            ["Cash and short-term investments", ...items.map((c) => (c.cash === null ? "n/a" : fmt(c.cash)))],
            ["Debt and leases share of capital", ...share.map((s) => (s === null ? "n/m" : formatPct(s)))],
          ]}
        />
      }
    />
  )
}

/**
 * Debt maturity profile: borrowings due in each bucket as bars, with available liquidity (cash plus undrawn
 * facilities) as a dashed reference line so near-term maturities can be read against it. Bars due within a year
 * above liquidity carry a "Above liquidity" label (never colour alone).
 */
export function DebtMaturityChart({ item, currency }: { item: CapitalStructure; currency: string }) {
  const liquidity = (item.cash ?? 0) + (item.undrawn_facilities ?? 0)
  const fmt = React.useCallback((v: number) => formatMoneyCompact(v, currency), [currency])
  const labels = item.maturities.map((b) => b.label)
  const amounts = item.maturities.map((b) => b.amount ?? 0)
  const build = React.useCallback(
    (t: ChartTokens): echarts.EChartsOption => ({
      ...baseOption(t),
      grid: { left: 8, right: 96, top: 24, bottom: 8, containLabel: true },
      xAxis: { type: "category", data: labels, axisTick: { show: false }, axisLine: { lineStyle: { color: t.grid } }, axisLabel: { color: t.axis } },
      yAxis: {
        type: "value",
        max: (extent: { max: number }) => Math.max(extent.max, liquidity) * 1.15,
        axisLabel: { color: t.axis, formatter: (v: number) => fmt(v) },
        splitLine: { lineStyle: { color: t.grid } },
      },
      tooltip: {
        ...baseOption(t).tooltip,
        trigger: "axis",
        axisPointer: { type: "shadow" },
        valueFormatter: (v) => fmt(Number(v)),
      },
      series: [
        {
          name: "Debt due",
          type: "bar",
          barMaxWidth: 48,
          data: amounts.map((v, i) => ({
            value: v,
            itemStyle: { color: i === 0 && v > liquidity ? t.diverging[0] : t.categorical[0], borderRadius: [4, 4, 0, 0] },
          })),
          label: {
            show: true,
            position: "top",
            color: t.muted,
            fontSize: 11,
            formatter: (q: { dataIndex: number; value: unknown }) =>
              q.dataIndex === 0 && Number(q.value) > liquidity ? `${fmt(Number(q.value))} · above liquidity` : fmt(Number(q.value)),
          },
          markLine: {
            symbol: "none",
            silent: true,
            lineStyle: { color: t.text, type: "dashed", width: 1.5 },
            label: { formatter: `Liquidity ${fmt(liquidity)}`, color: t.text, fontSize: 11, position: "end" },
            data: [{ yAxis: liquidity }],
          },
        },
      ],
    }),
    [labels, amounts, liquidity, fmt],
  )
  return (
    <EChart
      title={`Debt maturity profile (${item.period})`}
      height={240}
      build={build}
      table={
        <Table
          head={["Due", "Amount"]}
          rows={[
            ...item.maturities.map((b) => [b.label, b.amount === null ? "n/a" : fmt(b.amount)]),
            ["Cash and short-term investments", item.cash === null ? "n/a" : fmt(item.cash)],
            ["Undrawn committed facilities", item.undrawn_facilities === null ? "n/a" : fmt(item.undrawn_facilities)],
            ["Liquidity cover of debt due within 1 year", item.liquidity_cover === null ? "n/m" : formatMultiple(item.liquidity_cover)],
            ...(item.unallocated_debt ? [["Debt not in the maturity note", fmt(item.unallocated_debt)]] : []),
          ]}
        />
      }
    />
  )
}
