"use client"

import * as React from "react"
import type * as echarts from "echarts"

import { formatAccounting, formatMoneyCompact, formatPct } from "@/lib/format"
import type { MethodRange, SensitivityTable } from "@/lib/types"

import { baseOption, type ChartTokens, EChart, esc } from "./echart"

function SimpleTable({ head, rows }: { head: string[]; rows: (string | number)[][] }) {
  return (
    <table className="w-full text-[13px] tabular-nums">
      <thead className="text-xs text-muted-foreground">
        <tr>{head.map((h, i) => <th key={h} className={i ? "px-2 py-1 text-right" : "px-2 py-1 text-left"}>{h}</th>)}</tr>
      </thead>
      <tbody>
        {rows.map((r, i) => (
          <tr key={i} className="border-t">
            {r.map((c, j) => <td key={j} className={j ? "px-2 py-1 text-right" : "px-2 py-1"}>{c}</td>)}
          </tr>
        ))}
      </tbody>
    </table>
  )
}

export interface FootballRow {
  label: string
  low: number
  mid: number
  high: number
  blended?: boolean
}

export function FootballFieldChart({
  rows,
  currency,
  unitLabel,
  reference,
  perShare,
  offer,
  markers = [],
  title = "Football field",
}: {
  rows: FootballRow[]
  currency: string
  unitLabel: string
  reference?: { label: string; value: number } | null
  perShare?: boolean
  /** The suggested offer range, drawn as a band behind the bars. */
  offer?: { low: number; high: number } | null
  /** Market reference points (52-week high/low, VWAP, analyst target) as thin dotted lines. */
  markers?: { label: string; value: number }[]
  title?: string
}) {
  const fmt = React.useCallback(
    (v: number) => (perShare ? `${currency} ${formatAccounting(v, 2)}` : formatMoneyCompact(v, currency)),
    [currency, perShare],
  )
  // method labels take about a third of the chart, between 90 and 210 px, so bars keep room on a phone
  const box = React.useRef<HTMLDivElement>(null)
  const [labelWidth, setLabelWidth] = React.useState(210)
  React.useEffect(() => {
    const el = box.current
    if (!el) return
    const observer = new ResizeObserver(([entry]) =>
      setLabelWidth(Math.round(Math.max(90, Math.min(210, entry.contentRect.width * 0.32)))),
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [])
  const build = React.useCallback(
    (t: ChartTokens): echarts.EChartsOption => {
      const ordered = [...rows].reverse() // first method at the top
      const labels = ordered.map((r) => r.label)
      const values = ordered
        .flatMap((r) => [r.low, r.high])
        .concat(reference ? [reference.value] : [], offer ? [offer.low, offer.high] : [], markers.map((m) => m.value))
      const min = Math.min(...values)
      const max = Math.max(...values)
      const pad = (max - min) * 0.12 || Math.abs(max) * 0.1 || 1
      return {
        ...baseOption(t),
        grid: { left: 8, right: labelWidth < 150 ? 64 : 96, top: 8, bottom: 28, containLabel: true },
        xAxis: {
          type: "value",
          min: Math.max(0, min - pad),
          max: max + pad,
          axisLabel: { color: t.axis, formatter: (v: number) => fmt(v), hideOverlap: true },
          splitLine: { lineStyle: { color: t.grid } },
          name: unitLabel,
          nameLocation: "middle",
          nameGap: 22,
          nameTextStyle: { color: t.axis, fontSize: 11 },
        },
        yAxis: {
          type: "category",
          data: labels,
          axisLabel: { color: t.text, width: labelWidth, overflow: "truncate" },
          axisTick: { show: false },
          axisLine: { lineStyle: { color: t.grid } },
        },
        tooltip: {
          ...baseOption(t).tooltip,
          trigger: "axis",
          axisPointer: { type: "shadow" },
          formatter: (params: unknown) => {
            const first = (params as { dataIndex: number }[])[0]
            const r = ordered[first.dataIndex]
            return `<strong>${esc(r.label)}</strong><br/>Low ${fmt(r.low)} · Mid ${fmt(r.mid)} · High ${fmt(r.high)}`
          },
        },
        series: [
          { type: "bar", stack: "range", data: ordered.map((r) => r.low), itemStyle: { color: "transparent" }, silent: true, barWidth: 16 },
          {
            type: "bar",
            stack: "range",
            barWidth: 16,
            data: ordered.map((r) => ({
              value: r.high - r.low,
              itemStyle: { color: r.blended ? t.emphasis : t.categorical[0], borderRadius: 4 },
            })),
            label: {
              show: true,
              position: "right",
              color: t.muted,
              fontSize: 11,
              formatter: (p: { dataIndex: number }) => {
                const r = ordered[p.dataIndex]
                const short = (v: number) => (perShare ? formatAccounting(v, 2) : formatMoneyCompact(v, "").trim())
                return `${short(r.low)} to ${short(r.high)}`
              },
            },
          },
          {
            type: "scatter",
            symbol: "rect",
            symbolSize: [3, 22],
            data: ordered.map((r, i) => [r.mid, i]),
            itemStyle: { color: t.surface, borderColor: t.text, borderWidth: 1 },
            z: 5,
            tooltip: { show: false },
          },
          ...(offer
            ? [
                {
                  type: "line" as const,
                  data: [],
                  markArea: {
                    silent: true,
                    itemStyle: { color: t.categorical[1], opacity: 0.14 },
                    label: { show: true, position: "insideBottom" as const, color: t.text, fontSize: 11, formatter: "Suggested offer" },
                    data: [[{ xAxis: offer.low }, { xAxis: offer.high }]] as never,
                  },
                },
              ]
            : []),
          ...(markers.length
            ? [
                {
                  type: "line" as const,
                  data: [],
                  markLine: {
                    symbol: "none",
                    silent: true,
                    lineStyle: { color: t.muted, type: "dotted" as const, width: 1 },
                    // names on hover only: several markers sit close together and their labels would collide
                    label: { show: false, color: t.text, fontSize: 11, formatter: (p: { name: string }) => p.name },
                    emphasis: { label: { show: true } },
                    data: markers.map((m) => ({ name: m.label, xAxis: m.value })),
                  },
                },
              ]
            : []),
          ...(reference
            ? [
                {
                  type: "line" as const,
                  data: [],
                  markLine: {
                    symbol: "none",
                    silent: true,
                    lineStyle: { color: t.text, type: "dashed" as const, width: 1.5 },
                    label: { formatter: `${reference.label}\n${fmt(reference.value)}`, color: t.text, fontSize: 11 },
                    data: [{ xAxis: reference.value }],
                  },
                },
              ]
            : []),
        ],
      }
    },
    [rows, reference, fmt, unitLabel, perShare, offer, markers, labelWidth],
  )
  return (
    <div ref={box} className="min-w-0">
      <EChart
      title={title}
      height={Math.max(160, rows.length * 44 + 60)}
      build={build}
      table={
        <SimpleTable
          head={["Method", "Low", "Mid", "High"]}
          rows={[
            ...rows.map((r) => [r.label, fmt(r.low), fmt(r.mid), fmt(r.high)]),
            ...(offer ? [["Suggested offer", fmt(offer.low), "", fmt(offer.high)]] : []),
            ...markers.map((m) => [m.label, "", fmt(m.value), ""]),
          ]}
        />
      }
    />
    </div>
  )
}

export function SensitivityHeatmap({
  table,
  currency,
  rowFormat,
  colFormat,
  valueFormat,
  center,
  centerLabel = "base",
}: {
  table: SensitivityTable
  currency: string
  rowFormat: (v: number) => string
  colFormat: (v: number) => string
  /** Cell values; money by default. */
  valueFormat?: (v: number) => string
  /** The value the diverging scale is centred on (default: the base cell), e.g. the target IRR. */
  center?: number
  centerLabel?: string
}) {
  const build = React.useCallback(
    (t: ChartTokens): echarts.EChartsOption => {
      const mid = Math.floor(table.rows.length / 2)
      const midC = Math.floor(table.cols.length / 2)
      const fmtValue = valueFormat ?? ((v: number) => formatMoneyCompact(v, "").trim())
      const base = center ?? table.values[mid]?.[midC] ?? null
      const data: [number, number, number | null][] = []
      table.values.forEach((row, r) => row.forEach((v, c) => data.push([c, r, v])))
      const finite = data.map((d) => d[2]).filter((v): v is number => v !== null)
      // spread relative to the data (money and IRRs differ by orders of magnitude); never zero
      const spread = base !== null && finite.length ? Math.max(...finite.map((v) => Math.abs(v - base))) || Math.abs(base) || 1 : 1
      return {
        ...baseOption(t),
        grid: { left: 8, right: 8, top: 8, bottom: 40, containLabel: true },
        xAxis: {
          type: "category",
          data: table.cols.map(colFormat),
          name: table.col_label,
          nameLocation: "middle",
          nameGap: 26,
          nameTextStyle: { color: t.axis, fontSize: 11 },
          axisLabel: { color: t.axis },
          axisTick: { show: false },
          splitArea: { show: false },
        },
        yAxis: {
          type: "category",
          data: table.rows.map(rowFormat),
          name: table.row_label,
          nameTextStyle: { color: t.axis, fontSize: 11 },
          axisLabel: { color: t.axis },
          axisTick: { show: false },
          inverse: true,
        },
        visualMap: {
          show: false,
          min: (base ?? 0) - spread,
          max: (base ?? 0) + spread,
          inRange: { color: t.diverging },
        },
        tooltip: {
          ...baseOption(t).tooltip,
          formatter: (p: unknown) => {
            const d = (p as { data: [number, number, number | null] }).data
            const v = table.values[d[1]][d[0]]
            const vs =
              base === null || v === null
                ? ""
                : valueFormat
                  ? ` (${v >= base ? "+" : "−"}${(Math.abs(v - base) * 100).toFixed(1)}pp vs ${centerLabel})`
                  : ` (${formatPct(v / base - 1)} vs ${centerLabel})`
            return `${esc(table.row_label)} ${esc(rowFormat(table.rows[d[1]]))} · ${esc(table.col_label)} ${esc(colFormat(table.cols[d[0]]))}<br/><strong>${
              v === null ? "n/m" : valueFormat ? valueFormat(v) : formatMoneyCompact(v, currency)
            }</strong>${vs}`
          },
        },
        series: [
          {
            type: "heatmap",
            data: data.map(([c, r, v]) => ({
              value: [c, r, v ?? base ?? 0],
              itemStyle: {
                ...(v === null ? { color: t.grid } : {}), // not meaningful: neutral fill, "n/m" label
                ...(r === mid && c === midC ? { borderColor: t.text, borderWidth: 2 } : { borderColor: t.surface, borderWidth: 2 }),
              },
            })),
            label: {
              show: true,
              fontSize: 11,
              color: t.text,
              formatter: (p: unknown) => {
                const [c, r] = (p as { data: { value: [number, number, number] } }).data.value
                const v = table.values[r][c]
                return v === null ? "n/m" : fmtValue(v)
              },
            },
          },
        ],
      }
    },
    [table, currency, rowFormat, colFormat, valueFormat, center, centerLabel],
  )
  return (
    <EChart
      title={table.title}
      height={260}
      build={build}
      table={
        <SimpleTable
          head={[`${table.row_label} \\ ${table.col_label}`, ...table.cols.map(colFormat)]}
          rows={table.rows.map((r, i) => [
            rowFormat(r),
            ...table.values[i].map((v) => (v === null ? "n/m" : valueFormat ? valueFormat(v) : formatMoneyCompact(v, currency))),
          ])}
        />
      }
    />
  )
}

export function ScenarioBars({
  scenarios,
  weighted,
  currency,
}: {
  scenarios: { name: string; probability: number; enterprise_value: number }[]
  weighted: number
  currency: string
}) {
  const build = React.useCallback(
    (t: ChartTokens): echarts.EChartsOption => ({
      ...baseOption(t),
      grid: { left: 8, right: 16, top: 24, bottom: 8, containLabel: true },
      xAxis: {
        type: "category",
        data: scenarios.map((s) => `${s.name[0].toUpperCase()}${s.name.slice(1)} (${Math.round(s.probability * 100)}%)`),
        axisLabel: { color: t.text },
        axisTick: { show: false },
        axisLine: { lineStyle: { color: t.grid } },
      },
      yAxis: { type: "value", axisLabel: { color: t.axis, formatter: (v: number) => formatMoneyCompact(v, "") }, splitLine: { lineStyle: { color: t.grid } } },
      tooltip: { ...baseOption(t).tooltip, trigger: "axis", valueFormatter: (v) => formatMoneyCompact(v as number, currency) },
      series: [
        {
          type: "bar",
          barWidth: 36,
          data: scenarios.map((s) => s.enterprise_value),
          itemStyle: { color: t.categorical[0], borderRadius: [4, 4, 0, 0] },
          label: { show: true, position: "top", color: t.muted, formatter: (p: { value: unknown }) => formatMoneyCompact(p.value as number, "") },
          markLine: {
            symbol: "none",
            lineStyle: { color: t.text, type: "dashed" },
            label: { formatter: `Weighted ${formatMoneyCompact(weighted, currency)}`, color: t.text, position: "insideStartTop", backgroundColor: t.surface, padding: [1, 4] },
            data: [{ yAxis: weighted }],
          },
        },
      ],
    }),
    [scenarios, weighted, currency],
  )
  return (
    <EChart
      title="Scenarios: enterprise value"
      height={240}
      build={build}
      table={<SimpleTable head={["Scenario", "Probability", "EV"]} rows={scenarios.map((s) => [s.name, formatPct(s.probability, 0), formatMoneyCompact(s.enterprise_value, currency)])} />}
    />
  )
}

export function RevenueEbitdaChart({
  labels,
  revenue,
  ebitda,
  projected,
  currency,
}: {
  labels: string[]
  revenue: (number | null)[]
  ebitda: (number | null)[]
  projected: boolean[]
  currency: string
}) {
  const margin = revenue.map((r, i) => (r && ebitda[i] !== null ? (ebitda[i] as number) / r : null))
  const build = React.useCallback(
    (t: ChartTokens): echarts.EChartsOption => {
      const decal = { symbol: "rect", dashArrayX: [1, 0], dashArrayY: [3, 3], rotation: -Math.PI / 4, color: "rgba(255,255,255,0.45)" }
      const bar = (data: (number | null)[], color: string) =>
        data.map((v, i) => ({ value: v, itemStyle: { color, borderRadius: [4, 4, 0, 0], decal: projected[i] ? decal : undefined } }))
      return {
        ...baseOption(t),
        aria: { enabled: true, decal: { show: false } },
        color: [t.categorical[0], t.categorical[1], t.categorical[1]],
        legend: { top: 0, left: 0, textStyle: { color: t.text }, data: ["Revenue", "EBITDA"] },
        grid: [
          { left: 8, right: 16, top: 32, height: "52%", containLabel: true },
          { left: 8, right: 16, top: "72%", bottom: 8, containLabel: true },
        ],
        xAxis: [
          { type: "category", data: labels, gridIndex: 0, axisLabel: { show: false }, axisTick: { show: false }, axisLine: { lineStyle: { color: t.grid } } },
          { type: "category", data: labels, gridIndex: 1, axisLabel: { color: t.text }, axisTick: { show: false }, axisLine: { lineStyle: { color: t.grid } } },
        ],
        yAxis: [
          { type: "value", gridIndex: 0, axisLabel: { color: t.axis, formatter: (v: number) => formatMoneyCompact(v, "") }, splitLine: { lineStyle: { color: t.grid } } },
          { type: "value", gridIndex: 1, splitNumber: 2, axisLabel: { color: t.axis, formatter: (v: number) => formatPct(v, 0) }, splitLine: { lineStyle: { color: t.grid } }, name: "EBITDA margin", nameTextStyle: { color: t.axis, fontSize: 11, align: "left" } },
        ],
        tooltip: {
          ...baseOption(t).tooltip,
          trigger: "axis",
          valueFormatter: (v) => (typeof v === "number" && Math.abs(v) < 5 ? formatPct(v) : formatMoneyCompact(v as number, currency)),
        },
        axisPointer: { link: [{ xAxisIndex: "all" }] },
        series: [
          { name: "Revenue", type: "bar", xAxisIndex: 0, yAxisIndex: 0, barGap: "10%", barMaxWidth: 28, itemStyle: { color: t.categorical[0] }, data: bar(revenue, t.categorical[0]) },
          { name: "EBITDA", type: "bar", xAxisIndex: 0, yAxisIndex: 0, barMaxWidth: 28, itemStyle: { color: t.categorical[1] }, data: bar(ebitda, t.categorical[1]) },
          {
            name: "EBITDA margin",
            type: "line",
            xAxisIndex: 1,
            yAxisIndex: 1,
            data: margin,
            lineStyle: { width: 2, color: t.categorical[1] },
            itemStyle: { color: t.categorical[1] },
            symbolSize: 8,
            label: { show: true, position: "top", fontSize: 10, color: t.muted, formatter: (p: { value: unknown }) => formatPct(p.value as number) },
          },
        ],
      }
    },
    [labels, revenue, ebitda, projected, margin, currency],
  )
  return (
    <EChart
      title={`Revenue and EBITDA (${currency}); projected years hatched`}
      height={320}
      build={build}
      table={
        <SimpleTable
          head={["Year", "Revenue", "EBITDA", "Margin"]}
          rows={labels.map((l, i) => [l, formatMoneyCompact(revenue[i], currency), formatMoneyCompact(ebitda[i], currency), formatPct(margin[i])])}
        />
      }
    />
  )
}

export function MethodTable({ methods, currency }: { methods: MethodRange[]; currency: string }) {
  return (
    <SimpleTable
      head={["Method", "Weight", "Low", "Mid", "High"]}
      rows={methods.map((m) => [m.label, `${m.weight}`, formatMoneyCompact(m.equity_low, currency), formatMoneyCompact(m.equity_mid, currency), formatMoneyCompact(m.equity_high, currency)])}
    />
  )
}
