"use client"

import * as React from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { useVirtualizer } from "@tanstack/react-virtual"
import {
  CheckIcon,
  CircleAlertIcon,
  FileSpreadsheetIcon,
  FileTextIcon,
  PencilIcon,
  SparklesIcon,
  TableIcon,
  TagIcon,
  UserIcon,
  XIcon,
} from "lucide-react"

import { SearchSelect } from "@/components/common/search-select"
import { LinkButton } from "@/components/common/link-button"
import { HtmlViewer } from "@/components/documents/html-viewer"
import { ImageViewer } from "@/components/documents/image-viewer"
import { PdfViewer } from "@/components/documents/pdf-viewer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Empty, EmptyDescription, EmptyHeader, EmptyTitle } from "@/components/ui/empty"
import { Input } from "@/components/ui/input"
import { Kbd } from "@/components/ui/kbd"
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import { toast } from "@/components/ui/toast"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { useMediaQuery } from "@/hooks/use-mobile"
import { formatAccounting, formatScaled, parseCellInput, SCALE_LABEL, SCALE_NAME } from "@/lib/format"
import { useFinancials, useReview, useReviewMutations, useTaxonomy } from "@/lib/queries"
import type { Deal, DealDocument, ReviewItem, ReviewResponse, TaxonomyConcept, UnmappedRow } from "@/lib/types"
import { cn } from "@/lib/utils"

const STATEMENT_ORDER = ["income_statement", "balance_sheet", "cash_flow", "memo"]
const STATEMENT_LABEL: Record<string, string> = {
  income_statement: "Income statement",
  balance_sheet: "Balance sheet",
  cash_flow: "Cash flow statement",
  memo: "Other items",
}
const ACCEPT_THRESHOLD = 0.9
type Filter = "pending" | "accepted" | "rejected" | "all"

function confidenceOf(c: number): { label: string; variant: "positive" | "warning" | "negative" } {
  if (c >= 0.9) return { label: "High", variant: "positive" }
  if (c >= 0.75) return { label: "Medium", variant: "warning" }
  return { label: "Low", variant: "negative" }
}

function MethodIcon({ item }: { item: ReviewItem }) {
  const ai = item.method.startsWith("ai_")
  const tagged = item.method === "xbrl"
  const Icon = ai ? SparklesIcon : tagged ? TagIcon : item.method === "user_mapping" ? UserIcon : TableIcon
  const text = ai
    ? "Read by AI"
    : tagged
      ? "Tagged in the filing (XBRL)"
      : item.method === "user_mapping"
        ? "Mapped by you"
        : "Read from the table"
  return (
    <span title={text} className="text-muted-foreground">
      <Icon aria-hidden className="size-3.5" />
      <span className="sr-only">{text}</span>
    </span>
  )
}

function MethodLabel({ item }: { item: ReviewItem }) {
  const [Icon, text] =
    item.method === "ai_extraction"
      ? [SparklesIcon, "AI, from the notes"]
      : item.method === "ai_mapping"
        ? [SparklesIcon, "AI mapped the label"]
        : item.method === "user_mapping"
          ? [UserIcon, "You mapped the label"]
          : item.method === "xbrl"
            ? [TagIcon, item.mapping === "xbrl" ? "Tagged fact in the filing" : "Company-tagged fact, matched by its label"]
            : [TableIcon, item.mapping === "exact" ? "Table, dictionary match" : `Table, ${item.mapping} label match`]
  return (
    <span className="inline-flex items-center gap-1" title={item.provider ? `${item.provider} · ${item.model}` : undefined}>
      <Icon aria-hidden className="size-3" />
      {text}
    </span>
  )
}

function tableCell(ref: string | null): { table: number; row: number; col: number } | null {
  const m = ref?.match(/^t(\d+)r(\d+)c(\d+)$/)
  return m ? { table: Number(m[1]), row: Number(m[2]) + 1, col: Number(m[3]) + 1 } : null
}

function sourceOf(item: ReviewItem, docs: Map<string, DealDocument>): string {
  const doc = docs.get(item.document_id)
  const cell = tableCell(item.cell_ref)
  const where = item.sheet
    ? `${item.sheet}!${item.cell_ref ?? ""}`
    : item.method === "xbrl"
      ? "tagged fact"
      : cell
        ? `table ${cell.table}, row ${cell.row}`
        : item.page
          ? `p. ${item.page}`
          : ""
  return [doc?.filename, where].filter(Boolean).join(" · ")
}

function EditForm({
  item,
  scale,
  sign,
  decimalHint,
  onSave,
  onCancel,
}: {
  item: ReviewItem
  scale: number
  sign: TaxonomyConcept["sign"] | undefined
  decimalHint: "." | "," | null
  onSave: (value: number, reason: string) => void
  onCancel: () => void
}) {
  const factor = item.unit === "currency" ? scale : 1
  const [text, setText] = React.useState(String(+(item.value / factor).toFixed(6)))
  const [reason, setReason] = React.useState("")
  const [error, setError] = React.useState<string | null>(null)
  return (
    <form
      className="mt-2 flex flex-wrap items-end gap-2"
      onSubmit={(e) => {
        e.preventDefault()
        const parsed = parseCellInput(text, decimalHint)
        if (parsed === undefined || parsed === null) return setError("Enter a number.")
        if (!reason.trim()) return setError("Say why you changed it (kept in the history).")
        let value = parsed * factor
        if (sign === "negative") value = -Math.abs(value)
        onSave(value, reason.trim())
      }}
    >
      <label className="flex flex-col gap-1 text-xs">
        Value{item.unit === "currency" ? ` (${SCALE_NAME[scale]})` : ""}
        <Input
          autoFocus
          name="value"
          autoComplete="off"
          value={text}
          inputMode="decimal"
          className="h-7 w-32 text-right tabular-nums"
          onChange={(e) => setText(e.target.value)}
        />
      </label>
      <label className="flex min-w-48 flex-1 flex-col gap-1 text-xs">
        Reason
        <Input
          name="reason"
          autoComplete="off"
          value={reason}
          className="h-7"
          placeholder="e.g. Restated in note 3…"
          onChange={(e) => setReason(e.target.value)}
        />
      </label>
      <Button type="submit" size="sm">
        Save and accept
      </Button>
      <Button type="button" size="sm" variant="ghost" onClick={onCancel}>
        Cancel
      </Button>
      {error ? (
        <p role="alert" className="basis-full text-xs text-destructive">
          {error}
        </p>
      ) : null}
    </form>
  )
}

function SourcePanel({
  deal,
  item,
  doc,
  page,
  onPageChange,
}: {
  deal: Deal
  item: ReviewItem | null
  doc: DealDocument | undefined
  page: number
  onPageChange: (page: number) => void
}) {
  if (!item || !doc) {
    return (
      <div className="flex h-full items-center justify-center p-6 text-center text-sm text-muted-foreground">
        Select a value to see where it was read.
      </div>
    )
  }
  const details = (
    <dl className="grid grid-cols-[7rem_minmax(0,1fr)] gap-x-3 gap-y-1 border-t px-3 py-2 text-xs">
      <dt className="text-muted-foreground">Label as printed</dt>
      <dd className="break-words">{item.label}</dd>
      <dt className="text-muted-foreground">As written</dt>
      <dd className="tabular-nums">
        {item.value_as_written}
        {item.scale_label ? ` (${item.scale_label})` : ""}
      </dd>
      <dt className="text-muted-foreground">How it was read</dt>
      <dd>
        <MethodLabel item={item} />
        {item.provider ? <span className="text-muted-foreground"> · {item.provider} · {item.model}</span> : null}
      </dd>
      {item.rationale ? (
        <>
          <dt className="text-muted-foreground">Reasoning</dt>
          <dd className="break-words">{item.rationale}</dd>
        </>
      ) : null}
      {item.notes.length ? (
        <>
          <dt className="text-muted-foreground">Notes</dt>
          <dd>
            <ul className="flex flex-col gap-0.5">
              {item.notes.map((n) => (
                <li key={n} className="break-words">
                  {n}
                </li>
              ))}
            </ul>
          </dd>
        </>
      ) : null}
    </dl>
  )
  if (doc.kind === "xbrl" || doc.kind === "html") {
    return (
      <div className="flex h-full min-h-0 flex-col">
        <div className="min-h-0 flex-1">
          <HtmlViewer
            url={`/api/deals/${deal.id}/documents/${doc.id}/view`}
            target={item.cell_ref}
            label={`${doc.filename}, ${item.method === "xbrl" ? "tagged fact" : "table cell"} ${item.cell_ref ?? ""}`}
          />
        </div>
        {details}
      </div>
    )
  }
  if (doc.kind === "image") {
    return (
      <div className="flex h-full min-h-0 flex-col">
        <div className="min-h-0 flex-1">
          <ImageViewer
            url={`/api/deals/${deal.id}/documents/${doc.id}/file`}
            highlight={item.bbox}
            pageSize={doc.meta.page_size ?? null}
            label={doc.filename}
          />
        </div>
        {details}
      </div>
    )
  }
  if (doc.kind === "docx") {
    const cell = tableCell(item.cell_ref)
    return (
      <div className="flex h-full flex-col">
        <div className="flex flex-1 flex-col items-center justify-center gap-2 p-6 text-center">
          <FileTextIcon aria-hidden className="size-6 text-muted-foreground" />
          <p className="text-sm font-medium">{doc.filename}</p>
          <p className="text-sm">
            {cell ? `Word table ${cell.table}, row ${cell.row}, column ${cell.col}` : "Word document"}
          </p>
          <a
            href={`/api/deals/${deal.id}/documents/${doc.id}/file`}
            className="text-sm font-medium text-link underline-offset-2 hover:underline"
          >
            Download the original file
          </a>
        </div>
        {details}
      </div>
    )
  }
  if (doc.kind !== "pdf") {
    return (
      <div className="flex h-full flex-col">
        <div className="flex flex-1 flex-col items-center justify-center gap-2 p-6 text-center">
          <FileSpreadsheetIcon aria-hidden className="size-6 text-muted-foreground" />
          <p className="text-sm font-medium">{doc.filename}</p>
          <p className="text-sm">
            Sheet <span className="font-medium">{item.sheet ?? "—"}</span>, cell{" "}
            <span className="font-mono font-medium">{item.cell_ref ?? "—"}</span>
          </p>
          <a
            href={`/api/deals/${deal.id}/documents/${doc.id}/file`}
            className="text-sm font-medium text-link underline-offset-2 hover:underline"
          >
            Download the original file
          </a>
        </div>
        {details}
      </div>
    )
  }
  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="min-h-0 flex-1">
        <PdfViewer
          url={`/api/deals/${deal.id}/documents/${doc.id}/file`}
          page={page}
          highlight={page === item.page ? item.bbox : null}
          onPageChange={onPageChange}
          label={`${doc.filename}, page ${page}`}
        />
      </div>
      {details}
    </div>
  )
}

function ChecksSection({ checks }: { checks: ReviewResponse["checks"] }) {
  const errors = checks.filter((c) => c.severity === "error")
  const ordered = [...errors, ...checks.filter((c) => c.severity !== "error")]
  return (
    <details className="rounded-lg border" open={errors.length > 0}>
      <summary className="cursor-pointer px-4 py-2 text-sm font-medium">
        <CircleAlertIcon aria-hidden className={cn("mr-1.5 inline size-4", errors.length ? "text-negative" : "text-warning")} />
        Reconciliation: {checks.length} check{checks.length > 1 ? "s" : ""} fail
        {errors.length ? <span className="text-negative"> ({errors.length} errors)</span> : null}
        <span className="ml-2 text-xs font-normal text-muted-foreground">
          On accepted values plus the best value waiting in each empty cell. Warnings usually mean a component line
          is still unmapped.
        </span>
      </summary>
      <ul className="divide-y border-t text-sm">
        {ordered.map((c) => (
          <li key={`${c.check_id}-${c.period_id}`} className="flex gap-3 px-4 py-2">
            <Badge variant={c.severity === "error" ? "negative" : "warning"} className="shrink-0">
              {c.severity === "error" ? "Error" : "Warning"}
            </Badge>
            <span translate="no" className="shrink-0 tabular-nums text-muted-foreground">
              {c.period_id}
            </span>
            <span className="min-w-0 break-words">{c.message}</span>
          </li>
        ))}
      </ul>
    </details>
  )
}

function CrossDocumentSection({
  differences,
  names,
  scale,
}: {
  differences: ReviewResponse["cross_document"]
  names: Map<string, string>
  scale: number
}) {
  return (
    <details className="rounded-lg border" open>
      <summary className="cursor-pointer px-4 py-2 text-sm font-medium">
        <CircleAlertIcon aria-hidden className="mr-1.5 inline size-4 text-warning" />
        Across documents: {differences.length} figure{differences.length > 1 ? "s" : ""} differ
        <span className="ml-2 text-xs font-normal text-muted-foreground">
          The same period reported differently, usually a restatement. The newer document is preferred.
        </span>
      </summary>
      <ul className="divide-y border-t text-sm">
        {differences.map((d) => (
          <li key={`${d.concept_id}-${d.period_key}`} className="grid gap-1 px-4 py-2 md:grid-cols-[minmax(0,1fr)_minmax(0,2fr)]">
            <span className="font-medium">
              {names.get(d.concept_id) ?? d.concept_id} <span translate="no" className="text-muted-foreground">{d.period_key}</span>
            </span>
            <ul className="flex flex-col gap-0.5 text-xs">
              {d.values.map((v) => (
                <li key={v.item_id} className="flex flex-wrap gap-x-2">
                  <span className="tabular-nums">{formatScaled(v.value, scale)}</span>
                  <span className="min-w-0 truncate text-muted-foreground">{v.document}</span>
                  {v.item_id === d.preferred_item_id ? <Badge variant="positive">Preferred (newer)</Badge> : null}
                  {v.status !== "pending" ? <Badge variant="outline">{v.status}</Badge> : null}
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </details>
  )
}

function UnmappedSection({
  deal,
  docs,
  concepts,
}: {
  deal: Deal
  docs: DealDocument[]
  concepts: TaxonomyConcept[]
}) {
  const { mapRow } = useReviewMutations(deal.id)
  const rows = docs.flatMap((d) => (d.meta.unmapped ?? []).map((row) => ({ doc: d, row })))
  if (!rows.length) return null
  return (
    <details className="rounded-lg border" open={rows.length <= 12}>
      <summary className="cursor-pointer px-4 py-2 text-sm font-medium">
        Lines not recognised <span className="text-muted-foreground">({rows.length})</span>
        <span className="ml-2 text-xs font-normal text-muted-foreground">
          Map a line to a standard item to add its values for review. Nothing is discarded.
        </span>
      </summary>
      <ul className="divide-y border-t">
        {rows.map(({ doc, row }) => (
          <UnmappedLine
            key={`${doc.id}-${row.id}`}
            row={row}
            concepts={concepts}
            busy={mapRow.isPending}
            onMap={(conceptId) =>
              mapRow.mutate(
                { document_id: doc.id, row_id: row.id, concept_id: conceptId },
                {
                  onSuccess: () => toast.add({ title: "Line mapped", description: `${row.label} → review list` }),
                  onError: (e) => toast.add({ title: "Could not map", description: e.message, type: "error" }),
                },
              )
            }
          />
        ))}
      </ul>
    </details>
  )
}

function UnmappedLine({
  row,
  concepts,
  busy,
  onMap,
}: {
  row: UnmappedRow
  concepts: TaxonomyConcept[]
  busy: boolean
  onMap: (conceptId: string) => void
}) {
  const [choice, setChoice] = React.useState<string | null>(row.candidates[0] ?? null)
  const options = React.useMemo(
    () =>
      concepts
        .filter((c) => c.statement === row.statement || c.statement === "memo")
        .map((c) => ({ value: c.id, label: c.name })),
    [concepts, row.statement],
  )
  return (
    <li className="grid gap-2 px-4 py-2 text-sm md:grid-cols-[minmax(0,2fr)_minmax(0,1.5fr)_minmax(0,2fr)_auto] md:items-center">
      <span className="min-w-0 break-words">
        {row.label}
        <span className="block text-xs text-muted-foreground">
          p. {row.page} · {STATEMENT_LABEL[row.statement] ?? row.statement}
        </span>
      </span>
      <span className="truncate text-xs tabular-nums text-muted-foreground">
        {Object.entries(row.values)
          .map(([k, v]) => `${k}: ${v}`)
          .join(" · ")}
      </span>
      <SearchSelect
        options={options}
        value={choice}
        onChange={setChoice}
        placeholder="Map to a line item…"
        emptyText="No matching line item."
      />
      <Button size="sm" variant="outline" disabled={!choice || busy} onClick={() => choice && onMap(choice)}>
        Map
      </Button>
    </li>
  )
}

export function ReviewTab({ deal }: { deal: Deal }) {
  const params = useSearchParams()
  const router = useRouter()
  const isMobile = useMediaQuery("(max-width: 1099px)") // stack table and source below laptop width
  const { data, isPending, isError, error } = useReview(deal.id)
  const { data: grid } = useFinancials(deal.id)
  const { data: taxonomy } = useTaxonomy()
  const { decide } = useReviewMutations(deal.id)
  const requestedFilter = params.get("show")
  const filter: Filter = (["pending", "accepted", "rejected", "all"] as const).includes(requestedFilter as Filter)
    ? (requestedFilter as Filter)
    : "pending"
  const [checked, setChecked] = React.useState<Set<number>>(new Set())
  const [editing, setEditing] = React.useState<number | null>(null)
  const [viewerPage, setViewerPage] = React.useState<{ item: number | null; page: number }>({ item: null, page: 1 })
  const rowRefs = React.useRef(new Map<number, HTMLTableRowElement>())

  const docFilter = params.get("doc")
  const selectedId = Number(params.get("item")) || null
  const scale = grid?.entry.scale ?? 1_000_000
  const signs = React.useMemo(() => new Map(taxonomy?.concepts.map((c) => [c.id, c.sign])), [taxonomy])
  const docs = React.useMemo(() => new Map(data?.documents.map((d) => [d.id, d])), [data])

  const visible = React.useMemo(() => {
    if (!data) return []
    return data.items
      .filter((i) => (filter === "all" ? true : i.status === filter))
      .filter((i) => (docFilter ? i.document_id === docFilter : true))
      .sort(
        (a, b) =>
          STATEMENT_ORDER.indexOf(a.statement) - STATEMENT_ORDER.indexOf(b.statement) ||
          (a.page ?? 0) - (b.page ?? 0) ||
          a.id - b.id,
      )
  }, [data, filter, docFilter])
  const selected = visible.find((i) => i.id === selectedId) ?? data?.items.find((i) => i.id === selectedId) ?? null
  const page = viewerPage.item === selected?.id ? viewerPage.page : (selected?.page ?? 1)

  // Virtualised list: statement headers and value rows flattened, only the rows in view are rendered, so a filing
  // with thousands of values scrolls smoothly. Keyboard moves scroll the target row into view before focusing it.
  const flat = React.useMemo(() => {
    const out: ({ kind: "header"; statement: string } | { kind: "item"; item: ReviewItem; index: number })[] = []
    visible.forEach((item, index) => {
      if (index === 0 || item.statement !== visible[index - 1].statement) out.push({ kind: "header", statement: item.statement })
      out.push({ kind: "item", item, index })
    })
    return out
  }, [visible])
  const rowOf = React.useMemo(() => {
    const map = new Map<number, number>()
    flat.forEach((r, i) => r.kind === "item" && map.set(r.item.id, i))
    return map
  }, [flat])
  const scrollRef = React.useRef<HTMLDivElement>(null)
  // eslint-disable-next-line react-hooks/incompatible-library -- no React Compiler here; read fresh every render
  const virtualizer = useVirtualizer({
    count: flat.length,
    getScrollElement: () => scrollRef.current,
    estimateSize: (i) => (flat[i]?.kind === "header" ? 33 : 49),
    overscan: 10,
    getItemKey: (i) => {
      const r = flat[i]
      return r.kind === "header" ? `h:${r.statement}` : r.item.id
    },
  })
  const scrolledTo = React.useRef<number | null>(null)
  React.useEffect(() => {
    // a deep link (?item=…) or a filter change: bring the selected row into view once
    if (selectedId === null || scrolledTo.current === selectedId) return
    const row = rowOf.get(selectedId)
    if (row === undefined) return
    scrolledTo.current = selectedId
    virtualizer.scrollToIndex(row, { align: "auto" })
  }, [selectedId, rowOf, virtualizer])

  const setParam = React.useCallback(
    (key: string, value: string | null) => {
      const next = new URLSearchParams(params.toString())
      if (value) next.set(key, value)
      else next.delete(key)
      router.replace(`/deal?${next.toString()}`, { scroll: false })
    },
    [params, router],
  )
  const select = React.useCallback(
    (item: ReviewItem | undefined) => {
      if (!item) return
      setParam("item", String(item.id))
      const row = rowOf.get(item.id)
      scrolledTo.current = item.id
      if (row !== undefined) virtualizer.scrollToIndex(row, { align: "auto" })
      const focus = (attempt: number) => {
        const node = rowRefs.current.get(item.id)
        if (node) node.focus({ preventScroll: true })
        else if (attempt < 5) requestAnimationFrame(() => focus(attempt + 1))
      }
      focus(0)
    },
    [setParam, rowOf, virtualizer],
  )

  function act(actions: { item_id: number; action: "accept" | "reject" | "edit"; value?: number; reason?: string }[]) {
    const label = actions.length === 1 ? actions[0].action : `${actions.length} values`
    decide.mutate(
      { actions },
      {
        onSuccess: () => {
          setChecked(new Set())
          setEditing(null)
          toast.add({
            title: actions.every((a) => a.action === "reject") ? "Rejected" : "Accepted into the data grid",
            description: actions.length > 1 ? label : undefined,
            type: "success",
          })
        },
        onError: (e) => toast.add({ title: "Could not save", description: e.message, type: "error" }),
      },
    )
  }

  if (isPending) return <Skeleton className="h-96 w-full" />
  if (isError) return <p className="text-sm text-destructive">{error.message}</p>
  if (!data.documents.length) {
    return (
      <Empty className="border">
        <EmptyHeader>
          <EmptyTitle>Nothing to review yet</EmptyTitle>
          <EmptyDescription>Upload a report and DealScout will list every value it reads, with its source.</EmptyDescription>
        </EmptyHeader>
        <LinkButton href={`/deal?id=${deal.id}&tab=documents`} size="sm">
          Upload documents
        </LinkButton>
      </Empty>
    )
  }

  const pending = data.items.filter((i) => i.status === "pending")
  const highConfidence = new Set(
    pending.filter((i) => i.confidence >= ACCEPT_THRESHOLD && (!docFilter || i.document_id === docFilter)).map((i) => `${i.concept_id}|${i.period_key}`),
  )
  const counts = {
    pending: pending.length,
    accepted: data.items.filter((i) => i.status === "accepted").length,
    rejected: data.items.filter((i) => i.status === "rejected").length,
    all: data.items.length,
  }
  const notFound = data.documents.flatMap((d) => (d.meta.not_found ?? []).map((n) => ({ ...n, doc: d.filename })))
  const rejectedByCheck = data.documents.flatMap((d) => (d.meta.rejected ?? []).map((n) => ({ ...n, doc: d.filename })))
  const conceptName = new Map(taxonomy?.concepts.map((c) => [c.id, c.name]))
  const allChecked = visible.length > 0 && visible.every((i) => checked.has(i.id))
  const pendingChecked = [...checked].filter((id) => data.items.find((i) => i.id === id)?.status === "pending")

  function onRowKey(event: React.KeyboardEvent, item: ReviewItem, index: number) {
    if (event.target !== event.currentTarget) return
    const key = event.key.toLowerCase()
    if (key === "arrowdown" || key === "j") {
      event.preventDefault()
      select(visible[Math.min(index + 1, visible.length - 1)])
    } else if (key === "arrowup" || key === "k") {
      event.preventDefault()
      select(visible[Math.max(index - 1, 0)])
    } else if (key === "a" && item.status === "pending") {
      event.preventDefault()
      act([{ item_id: item.id, action: "accept" }])
    } else if (key === "r" && item.status === "pending") {
      event.preventDefault()
      act([{ item_id: item.id, action: "reject" }])
    } else if (key === "e" && item.status === "pending") {
      event.preventDefault()
      setEditing(item.id)
    } else if (key === " ") {
      event.preventDefault()
      setChecked((prev) => {
        const next = new Set(prev)
        if (next.has(item.id)) next.delete(item.id)
        else next.add(item.id)
        return next
      })
    }
  }

  const table = (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex flex-wrap items-center gap-2 border-b px-3 py-2">
        <ToggleGroup
          value={[filter]}
          onValueChange={(v) => v.length && setParam("show", v[0] === "pending" ? null : (v[0] as string))}
          size="sm"
          variant="outline"
          aria-label="Show values"
          className="max-w-full overflow-x-auto"
        >
          {(["pending", "accepted", "rejected", "all"] as const).map((f) => (
            <ToggleGroupItem key={f} value={f}>
              {f === "pending" ? "To review" : f[0].toUpperCase() + f.slice(1)}{" "}
              <span className="tabular-nums text-muted-foreground">{counts[f]}</span>
            </ToggleGroupItem>
          ))}
        </ToggleGroup>
        {data.documents.length > 1 ? (
          <Select
            items={[{ value: "", label: "All documents" }, ...data.documents.map((d) => ({ value: d.id, label: d.filename }))]}
            value={docFilter ?? ""}
            onValueChange={(v) => setParam("doc", (v as string) || null)}
          >
            <SelectTrigger size="sm" className="max-w-56" aria-label="Document">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectItem value="">All documents</SelectItem>
                {data.documents.map((d) => (
                  <SelectItem key={d.id} value={d.id}>
                    <span className="truncate">{d.filename}</span>
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>
        ) : null}
        <div className="ml-auto flex flex-wrap items-center gap-2">
          {pendingChecked.length ? (
            <>
              <Button
                size="sm"
                onClick={() => act(pendingChecked.map((id) => ({ item_id: id, action: "accept" as const })))}
                disabled={decide.isPending}
              >
                Accept {pendingChecked.length} selected
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => act(pendingChecked.map((id) => ({ item_id: id, action: "reject" as const })))}
                disabled={decide.isPending}
              >
                Reject selected
              </Button>
            </>
          ) : (
            <Button
              size="sm"
              disabled={!highConfidence.size || decide.isPending}
              onClick={() =>
                decide.mutate(
                  docFilter
                    ? {
                        actions: pending
                          .filter((i) => i.document_id === docFilter && i.confidence >= ACCEPT_THRESHOLD)
                          .map((i) => ({ item_id: i.id, action: "accept" as const })),
                      }
                    : { accept_all_above: ACCEPT_THRESHOLD },
                  {
                    onSuccess: (r) =>
                      toast.add({
                        title: `Accepted ${highConfidence.size} high-confidence values`,
                        description: r.counts ? `${r.counts.created ?? 0} added, ${r.counts.updated ?? 0} updated` : undefined,
                        type: "success",
                      }),
                  },
                )
              }
            >
              <CheckIcon aria-hidden />
              Accept all high-confidence ({highConfidence.size})
            </Button>
          )}
        </div>
      </div>
      <div ref={scrollRef} className="relative min-h-0 flex-1 overflow-auto">
        {visible.length === 0 ? (
          <p className="p-6 text-center text-sm text-muted-foreground">
            {filter === "pending" ? "Every value has been reviewed." : "No values in this view."}
          </p>
        ) : (
          <table
            className="w-full border-separate border-spacing-0 text-[13px]"
            aria-label="Values read from documents"
            aria-rowcount={flat.length + 1}
          >
            <thead className="sticky top-0 z-10 bg-muted text-xs text-muted-foreground">
              <tr>
                <th scope="col" className="w-8 border-b px-2 py-2">
                  <Checkbox
                    aria-label="Select all shown"
                    checked={allChecked}
                    onCheckedChange={(on) => setChecked(on ? new Set(visible.map((i) => i.id)) : new Set())}
                  />
                </th>
                <th scope="col" className="border-b px-2 py-2 text-left font-medium">
                  Line item
                </th>
                <th scope="col" className="border-b px-2 py-2 text-left font-medium">
                  Period
                </th>
                <th scope="col" className="border-b px-2 py-2 text-right font-medium">
                  Value, {grid?.currency ?? deal.reporting_currency} {SCALE_LABEL[scale] || "units"}
                </th>
                <th scope="col" className="border-b px-2 py-2 text-left font-medium">
                  Confidence
                </th>
                <th scope="col" className="border-b px-2 py-2 text-right font-medium">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {virtualizer.getVirtualItems()[0]?.start ? (
                <tr aria-hidden style={{ height: virtualizer.getVirtualItems()[0].start }} />
              ) : null}
              {virtualizer.getVirtualItems().map((v) => {
                const row = flat[v.index]
                if (row.kind === "header") {
                  return (
                    <tr key={v.key} data-index={v.index} ref={virtualizer.measureElement} aria-rowindex={v.index + 2}>
                      <th
                        colSpan={6}
                        scope="colgroup"
                        className="border-b bg-background px-2 pt-3 pb-1 text-left text-xs font-semibold text-muted-foreground"
                      >
                        {STATEMENT_LABEL[row.statement] ?? row.statement}
                      </th>
                    </tr>
                  )
                }
                const { item, index } = row
                const conf = confidenceOf(item.confidence)
                const isSelected = item.id === selected?.id
                const display =
                  item.unit === "currency" ? formatScaled(item.value, scale) : formatAccounting(item.value, item.unit === "ratio" ? 2 : 0)
                return (
                    <tr
                      key={v.key}
                      data-index={v.index}
                      aria-rowindex={v.index + 2}
                      ref={(node) => {
                        virtualizer.measureElement(node)
                        if (node) rowRefs.current.set(item.id, node)
                        else rowRefs.current.delete(item.id)
                      }}
                      tabIndex={isSelected || (!selected && index === 0) ? 0 : -1}
                      aria-current={isSelected || undefined}
                      onClick={() => select(item)}
                      onKeyDown={(e) => onRowKey(e, item, index)}
                      className={cn(
                        "cursor-default outline-none hover:bg-muted/60 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-inset",
                        isSelected && "bg-muted",
                      )}
                    >
                      <td className="border-b px-2 py-1.5 align-top" onClick={(e) => e.stopPropagation()}>
                        <Checkbox
                          aria-label={`Select ${item.concept_name} ${item.period_key}`}
                          checked={checked.has(item.id)}
                          onCheckedChange={(on) =>
                            setChecked((prev) => {
                              const next = new Set(prev)
                              if (on) next.add(item.id)
                              else next.delete(item.id)
                              return next
                            })
                          }
                        />
                      </td>
                      <td className="max-w-60 border-b px-2 py-1.5 align-top">
                        <span className="font-medium">{item.concept_name}</span>
                        <span className="block truncate text-xs text-muted-foreground" title={`${item.label}: ${sourceOf(item, docs)}`}>
                          “{item.label}” · {sourceOf(item, docs)}
                        </span>
                        {item.conflicts && item.status === "pending" ? (
                          <span className="mt-0.5 flex items-center gap-1 text-xs text-warning">
                            <CircleAlertIcon aria-hidden className="size-3" />
                            Grid already has{" "}
                            {item.unit === "currency" ? formatScaled(item.current_value, scale) : formatAccounting(item.current_value, 0)}{" "}
                            ({item.current_source}); accepting replaces it
                          </span>
                        ) : null}
                        {item.superseded_by && item.status === "pending" ? (
                          <span className="mt-0.5 flex items-center gap-1 text-xs text-warning">
                            <CircleAlertIcon aria-hidden className="size-3" />
                            {item.superseded_by} reports a different figure (restated?); the newer one is preferred
                          </span>
                        ) : null}
                        {editing === item.id ? (
                          <EditForm
                            item={item}
                            scale={scale}
                            sign={signs.get(item.concept_id)}
                            decimalHint={grid?.entry.decimal_hint ?? null}
                            onCancel={() => setEditing(null)}
                            onSave={(value, reason) => act([{ item_id: item.id, action: "edit", value, reason }])}
                          />
                        ) : null}
                      </td>
                      <td className="border-b px-2 py-1.5 align-top whitespace-nowrap" translate="no">
                        {item.period_key}
                      </td>
                      <td className="border-b px-2 py-1.5 text-right align-top tabular-nums whitespace-nowrap">{display}</td>
                      <td className="border-b px-2 py-1.5 align-top">
                        <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
                          <Badge variant={conf.variant}>
                            {conf.label} <span className="tabular-nums">{Math.round(item.confidence * 100)}%</span>
                          </Badge>
                          <MethodIcon item={item} />
                        </span>
                      </td>
                      <td className="border-b px-2 py-1.5 text-right align-top whitespace-nowrap">
                        {item.status === "pending" ? (
                          <span className="inline-flex gap-0.5" onClick={(e) => e.stopPropagation()}>
                            <Button
                              size="icon-sm"
                              variant="ghost"
                              aria-label={`Accept ${item.concept_name} ${item.period_key}`}
                              title="Accept (A)"
                              onClick={() => act([{ item_id: item.id, action: "accept" }])}
                            >
                              <CheckIcon />
                            </Button>
                            <Button
                              size="icon-sm"
                              variant="ghost"
                              aria-label={`Edit ${item.concept_name} ${item.period_key}`}
                              title="Edit (E)"
                              onClick={() => setEditing(item.id)}
                            >
                              <PencilIcon />
                            </Button>
                            <Button
                              size="icon-sm"
                              variant="ghost"
                              aria-label={`Reject ${item.concept_name} ${item.period_key}`}
                              title="Reject (R)"
                              onClick={() => act([{ item_id: item.id, action: "reject" }])}
                            >
                              <XIcon />
                            </Button>
                          </span>
                        ) : (
                          <Badge variant={item.status === "accepted" ? "positive" : "outline"}>
                            {item.status === "accepted" ? "Accepted" : "Rejected"}
                          </Badge>
                        )}
                      </td>
                    </tr>
                )
              })}
              {(() => {
                const items = virtualizer.getVirtualItems()
                const rest = items.length ? virtualizer.getTotalSize() - items[items.length - 1].end : 0
                return rest > 0 ? <tr aria-hidden style={{ height: rest }} /> : null
              })()}
            </tbody>
          </table>
        )}
      </div>
      <p className="hidden border-t px-3 py-1.5 text-xs text-muted-foreground md:block">
        <Kbd>↑</Kbd> <Kbd>↓</Kbd> move · <Kbd>A</Kbd> accept · <Kbd>E</Kbd> edit · <Kbd>R</Kbd> reject · <Kbd>Space</Kbd>{" "}
        select
      </p>
    </div>
  )

  const source = (
    <SourcePanel
      deal={deal}
      item={selected}
      doc={selected ? docs.get(selected.document_id) : undefined}
      page={page}
      onPageChange={(p) => setViewerPage({ item: selected?.id ?? null, page: p })}
    />
  )

  return (
    <div className="flex flex-col gap-4">
      <div className="overflow-hidden rounded-lg border" style={{ height: isMobile ? undefined : "calc(100dvh - 14rem)" }}>
        {isMobile ? (
          <div className="flex flex-col">
            <div className="h-[60vh] min-h-80">{table}</div>
            {selected ? <div className="h-[70vh] border-t">{source}</div> : null}
          </div>
        ) : (
          <ResizablePanelGroup orientation="horizontal">
            <ResizablePanel defaultSize="60" minSize="40">
              <div className="h-full min-w-0 overflow-hidden">{table}</div>
            </ResizablePanel>
            <ResizableHandle withHandle />
            <ResizablePanel defaultSize="40" minSize="25">
              <div className="h-full min-w-0 overflow-hidden">{source}</div>
            </ResizablePanel>
          </ResizablePanelGroup>
        )}
      </div>

      {data.checks.length ? <ChecksSection checks={data.checks} /> : null}

      {data.cross_document.length ? (
        <CrossDocumentSection
          differences={data.cross_document}
          names={new Map(taxonomy?.concepts.map((c) => [c.id, c.name]))}
          scale={scale}
        />
      ) : null}

      <UnmappedSection deal={deal} docs={docFilter ? data.documents.filter((d) => d.id === docFilter) : data.documents} concepts={taxonomy?.concepts ?? []} />

      {notFound.length ? (
        <details className="rounded-lg border">
          <summary className="cursor-pointer px-4 py-2 text-sm font-medium">
            Not found in the documents <span className="text-muted-foreground">({notFound.length})</span>
          </summary>
          <ul className="divide-y border-t text-sm">
            {notFound.map((n) => (
              <li key={`${n.doc}-${n.concept_id}`} className="flex flex-wrap items-center gap-x-3 gap-y-1 px-4 py-2">
                <span className="font-medium">{conceptName.get(n.concept_id) ?? n.concept_id}</span>
                <span className="min-w-0 flex-1 text-xs text-muted-foreground">{n.reason}</span>
                <Link
                  href={`/deal?id=${deal.id}&tab=data`}
                  className="text-xs font-medium text-link underline-offset-2 hover:underline"
                >
                  Enter manually
                </Link>
              </li>
            ))}
          </ul>
        </details>
      ) : null}

      {rejectedByCheck.length ? (
        <details className="rounded-lg border">
          <summary className="cursor-pointer px-4 py-2 text-sm font-medium">
            AI answers rejected by verification <span className="text-muted-foreground">({rejectedByCheck.length})</span>
            <span className="ml-2 text-xs font-normal text-muted-foreground">
              The figure was not printed on the pages sent, so it was never offered as a value.
            </span>
          </summary>
          <ul className="divide-y border-t text-sm">
            {rejectedByCheck.map((n, i) => (
              <li key={`${n.doc}-${n.concept_id}-${i}`} className="flex flex-wrap gap-x-3 px-4 py-2">
                <span className="font-medium">{conceptName.get(n.concept_id) ?? n.concept_id}</span>
                <span className="min-w-0 flex-1 text-xs text-muted-foreground">{n.reason}</span>
              </li>
            ))}
          </ul>
        </details>
      ) : null}
    </div>
  )
}
