import { ArrowRightLeftIcon, TriangleAlertIcon } from "lucide-react"

import type { FxStatus } from "@/lib/types"

/** Says which currency the figures are in and the rates used (brief §7: show the rate and date used). */
export function FxNote({ fx }: { fx?: FxStatus | null }) {
  if (!fx || !fx.needed) return null
  if (fx.message) {
    return (
      <p role="status" className="flex items-start gap-2 text-xs text-warning">
        <TriangleAlertIcon aria-hidden className="mt-0.5 size-3.5 shrink-0" />
        <span>{fx.message}</span>
      </p>
    )
  }
  return (
    <details className="text-xs text-muted-foreground">
      <summary className="flex cursor-pointer items-center gap-2">
        <ArrowRightLeftIcon aria-hidden className="size-3.5 shrink-0" />
        Figures in {fx.to}, converted from {fx.from}
        {fx.notes.length ? `: ${fx.notes[fx.notes.length - 1]}` : ""}
        {fx.notes.length > 1 ? ` (and ${fx.notes.length - 1} more rates)` : ""}
      </summary>
      <ul className="mt-1 ml-6 list-disc">
        {fx.notes.map((n) => (
          <li key={n}>{n}</li>
        ))}
      </ul>
    </details>
  )
}
