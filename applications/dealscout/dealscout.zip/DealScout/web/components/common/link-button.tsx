"use client"

import Link from "next/link"
import type * as React from "react"

import { Button } from "@/components/ui/button"

type ButtonProps = React.ComponentProps<typeof Button>

/** A Next.js link styled as a Button (Base UI `render` composition). */
export function LinkButton({ href, children, ...props }: Omit<ButtonProps, "render"> & { href: string }) {
  return (
    <Button nativeButton={false} render={<Link href={href} />} {...props}>
      {children}
    </Button>
  )
}
