"use client"

import * as React from "react"

import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox"

export interface Option {
  value: string
  label: string
  hint?: string
}

/** Searchable single-select over a long option list (countries, currencies). Controlled by `value` (option value). */
export function SearchSelect({
  id,
  options,
  value,
  onChange,
  onBlur,
  placeholder,
  invalid,
  emptyText = "No match.",
  disabled,
}: {
  id?: string
  options: Option[]
  value: string | null
  onChange: (value: string | null) => void
  onBlur?: () => void
  placeholder?: string
  invalid?: boolean
  emptyText?: string
  disabled?: boolean
}) {
  const selected = React.useMemo(() => options.find((o) => o.value === value) ?? null, [options, value])
  return (
    <Combobox<Option>
      items={options}
      value={selected}
      onValueChange={(option) => onChange(option ? option.value : null)}
      itemToStringLabel={(option) => option.label}
      itemToStringValue={(option) => option.value}
      isItemEqualToValue={(a, b) => a.value === b.value}
      disabled={disabled}
      autoHighlight
    >
      <ComboboxInput id={id} placeholder={placeholder} aria-invalid={invalid || undefined} onBlur={onBlur} />
      <ComboboxContent>
        <ComboboxEmpty>{emptyText}</ComboboxEmpty>
        <ComboboxList>
          {(option: Option) => (
            <ComboboxItem key={option.value} value={option}>
              <span className="truncate">{option.label}</span>
              {option.hint ? <span className="ml-auto pl-3 text-xs text-muted-foreground">{option.hint}</span> : null}
            </ComboboxItem>
          )}
        </ComboboxList>
      </ComboboxContent>
    </Combobox>
  )
}
