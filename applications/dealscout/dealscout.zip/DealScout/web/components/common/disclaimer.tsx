import { ShieldAlertIcon } from "lucide-react"

import disclaimers from "@/lib/disclaimers.generated.json"

/** The short disclaimer shown on every screen (brief §1). */
export function DisclaimerBar() {
  return (
    <footer
      role="note"
      aria-label="Disclaimer"
      className="flex items-start gap-2 border-t bg-muted px-4 py-2 text-xs text-muted-foreground md:px-6"
    >
      <ShieldAlertIcon aria-hidden className="mt-0.5 size-3.5 shrink-0" />
      <p>{disclaimers.short}</p>
    </footer>
  )
}
