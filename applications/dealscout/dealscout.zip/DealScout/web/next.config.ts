import type { NextConfig } from "next"
import { PHASE_DEVELOPMENT_SERVER } from "next/constants"

/**
 * Production builds are a static export (web/out) served by FastAPI on 127.0.0.1:8000.
 * In development (`./dev.sh`) the Next dev server proxies /api/* to FastAPI instead; rewrites and
 * `output: "export"` cannot be combined, so the config switches on the build phase.
 */
export default function config(phase: string): NextConfig {
  const base: NextConfig = {
    reactStrictMode: true,
    images: { unoptimized: true },
    poweredByHeader: false,
  }
  if (phase === PHASE_DEVELOPMENT_SERVER) {
    const api = process.env.DEALSCOUT_API_URL ?? `http://127.0.0.1:${process.env.DEALSCOUT_PORT ?? "8000"}`
    return {
      ...base,
      async rewrites() {
        return [{ source: "/api/:path*", destination: `${api}/api/:path*` }]
      },
    }
  }
  return { ...base, output: "export" }
}
