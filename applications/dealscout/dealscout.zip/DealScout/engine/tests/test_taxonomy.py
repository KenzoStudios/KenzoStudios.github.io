import pytest

from dealscout_engine.taxonomy import load_taxonomy, normalise_label

TAX = load_taxonomy()


def test_loads_and_has_core_concepts():
    for concept_id in [
        "revenue",
        "ebitda",
        "net_income",
        "total_assets",
        "cash",
        "st_debt",
        "lt_debt",
        "total_equity",
        "cfo",
        "capex",
        "shares_outstanding",
        "share_price",
    ]:
        assert TAX.has(concept_id), concept_id


def test_every_concept_has_all_required_fields():
    for concept in TAX.concepts:
        assert concept.definition.strip()
        assert concept.synonyms["en"], concept.id


@pytest.mark.parametrize(
    ("label", "expected"),
    [
        ("Revenue", "revenue"),
        ("Umsatzerlöse", "revenue"),
        ("Importe neto de la cifra de negocios", "revenue"),
        ("Chiffre d'affaires", "revenue"),
        ("Ricavi delle vendite e delle prestazioni", "revenue"),
        ("売上高", "revenue"),
        ("Revenue from operations", "revenue"),
        ("Turnover", "revenue"),
        ("Total assets (3)", "total_assets"),
        ("Cash and cash equivalents  Note 12", "cash"),
        ("Gewinn- und Verlust", None),
        ("PROPERTY, PLANT AND EQUIPMENT", "ppe"),
        ("ＥＢＩＴＤＡ", "ebitda"),  # full-width characters (NFKC)
        ("Trade and other receivables*", "receivables"),
        ("Cash flow from operating activities", "cfo"),
        ("営業活動によるキャッシュ・フロー", "cfo"),
    ],
)
def test_synonym_matching_across_languages(label, expected):
    matches = TAX.match_label(label)
    if expected is None:
        assert matches == []
    else:
        assert expected in matches


def test_normalise_label_strips_noise():
    assert normalise_label("  Revenue (1) ") == "revenue"
    assert normalise_label("Selling, general and administrative") == "selling general & administrative"
    assert normalise_label("Trade receivables – note 4.2") == "trade receivables"


def test_xbrl_index_maps_us_gaap_and_ifrs():
    index = TAX.xbrl_index()
    assert index["us-gaap:Revenues"] == "revenue"
    assert index["ifrs-full:Revenue"] == "revenue"
    assert index["ifrs-full:CashAndCashEquivalents"] == "cash"


def test_balance_sheet_subtotals_are_sums():
    assert TAX.concept("total_assets").components == ["total_current_assets", "total_non_current_assets"]
    assert TAX.concept("total_liabilities_and_equity").aggregation == "sum"


def test_sign_conventions():
    assert TAX.concept("cogs").sign == "negative"
    assert TAX.concept("capex").sign == "negative"
    assert TAX.concept("treasury_shares").sign == "negative"
    assert TAX.concept("revenue").sign == "positive"


def test_invalid_taxonomy_is_rejected(tmp_path):
    bad = tmp_path / "t.yaml"
    bad.write_text(
        """
version: "0"
as_of: "2026-01-01"
statements: {income_statement: IS}
standards: {ifrs: IFRS}
languages: [en]
concepts:
  - {id: a, name: A, statement: income_statement, definition: d, sign: either, period_type: duration,
     unit: currency, aggregation: sum, components: [b], synonyms: {en: [a]}}
  - {id: b, name: B, statement: income_statement, definition: d, sign: either, period_type: duration,
     unit: currency, aggregation: sum, components: [a], synonyms: {en: [b]}}
""",
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="cycle"):
        load_taxonomy(bad)


@pytest.mark.parametrize("fragment", ["Property", "Selling", "Plant and equipment", "Generales y de administración"])
def test_no_comma_split_fragments(fragment):
    """A comma inside a YAML flow list splits a synonym; quoted phrases must not leave fragments behind."""
    assert load_taxonomy().match_label(fragment) == []


def test_comma_phrases_match():
    tax = load_taxonomy()
    assert tax.match_label("Selling, general and administrative") == ["sga"]
    assert "ppe" in tax.match_label("Property, plant and equipment")
    assert tax.match_label("Purchases of property, plant and equipment") == ["capex_ppe"]
    assert tax.match_label("Net increase in cash and cash equivalents") == ["net_change_in_cash"]
