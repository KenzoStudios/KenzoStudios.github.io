from datetime import date

import pytest

from dealscout_engine.periods import Period, last_twelve_months


def test_ltm_formula_and_derivation():
    # H1 2026 revenue 560, FY2025 1000, H1 2025 500  ->  LTM to June 2026 = 1060
    result = last_twelve_months(560, 1000, 500)
    assert result.value == 1060
    assert [i.name for i in result.derivation.inputs] == ["latest_ytd", "prior_full_year", "prior_year_ytd"]


def test_period_validation_and_months():
    fy = Period(id="FY2025", kind="annual", start=date(2025, 1, 1), end=date(2025, 12, 31), fiscal_year=2025)
    assert fy.months == 12.0
    with pytest.raises(ValueError):
        Period(id="bad", kind="annual", start=date(2026, 1, 1), end=date(2025, 1, 1))
