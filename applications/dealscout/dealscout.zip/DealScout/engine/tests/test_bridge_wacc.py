import pytest
from hypothesis import given
from hypothesis import strategies as st

from dealscout_engine.valuation.bridge import (
    BridgeInputs,
    Convertible,
    DilutionInputs,
    OptionTranche,
    equity_to_ev,
    ev_to_equity,
    value_per_share,
)
from dealscout_engine.valuation.wacc import PeerBeta, WACCInputs, compute_wacc, relever_beta, unlever_beta


def test_bridge_with_toggles_and_excess_cash():
    b = BridgeInputs(
        gross_debt=300,
        lease_liabilities=50,
        pension_deficit=40,
        pension_tax_rate=0.25,
        minority_interest=20,
        cash=120,
        minimum_operating_cash=20,
        investments_in_associates=15,
        provisions=30,
        include_provisions=False,
    )
    r = ev_to_equity(1000, b)
    # 1000 − 300 − 50 − 30 (pension net of tax) − 20 + 100 (excess cash) + 15 = 715
    assert r.equity_value == pytest.approx(715)
    assert r.net_debt_and_adjustments == pytest.approx(285)
    no_leases = ev_to_equity(1000, b.model_copy(update={"include_leases": False}))
    assert no_leases.equity_value == pytest.approx(765)


money = st.floats(min_value=0, max_value=1e9, allow_nan=False, allow_infinity=False)


@given(
    ev=st.floats(min_value=-1e9, max_value=1e10, allow_nan=False),
    debt=money,
    cash=money,
    leases=money,
    minority=money,
    min_cash=money,
    include_leases=st.booleans(),
)
def test_bridge_is_reversible(ev, debt, cash, leases, minority, min_cash, include_leases):
    b = BridgeInputs(
        gross_debt=debt,
        cash=cash,
        lease_liabilities=leases,
        minority_interest=minority,
        minimum_operating_cash=min_cash,
        include_leases=include_leases,
    )
    assert equity_to_ev(ev_to_equity(ev, b).equity_value, b) == pytest.approx(ev, rel=1e-9, abs=1e-3)


def test_treasury_stock_method_closed_form():
    d = DilutionInputs(basic_shares=100, options=[OptionTranche(number=10, strike=5)])
    r = value_per_share(1000, d)
    assert r.value_per_share == pytest.approx(1050 / 110)  # (E + N·K) ÷ (basic + N) when in the money
    assert r.diluted_shares == pytest.approx(1000 / (1050 / 110))


def test_out_of_the_money_options_do_not_dilute_and_rsus_always_do():
    assert value_per_share(
        1000, DilutionInputs(basic_shares=100, options=[OptionTranche(number=10, strike=20)])
    ).value_per_share == pytest.approx(10)
    assert value_per_share(
        1000, DilutionInputs(basic_shares=100, options=[OptionTranche(kind="rsu", number=10)])
    ).value_per_share == pytest.approx(1000 / 110)


def test_if_converted_logic_both_ways():
    d = DilutionInputs(basic_shares=100, convertibles=[Convertible(principal=200, conversion_price=8)])
    itm = value_per_share(1000, d)  # (1000 + 200) ÷ 125 = 9.6 > 8 → converts
    assert itm.value_per_share == pytest.approx(9.6)
    assert itm.converted_principal_added_back == 200
    otm = value_per_share(500, d)  # (700 ÷ 125 = 5.6) < 8 → stays debt → 500 ÷ 100
    assert otm.value_per_share == pytest.approx(5.0)


def test_wacc_textbook():
    r = compute_wacc(
        WACCInputs(
            risk_free_rate=0.04,
            equity_risk_premium=0.05,
            beta_mode="levered_input",
            levered_beta=1.2,
            pre_tax_cost_of_debt=0.06,
            tax_rate=0.25,
            target_debt_to_capital=0.30,
        )
    )
    assert r.cost_of_equity == pytest.approx(0.10)
    assert r.after_tax_cost_of_debt == pytest.approx(0.045)
    assert r.wacc == pytest.approx(0.0835)


def test_hamada_relevering_and_peer_median():
    assert relever_beta(1.0, 0.5, 0.25) == pytest.approx(1.375)
    assert unlever_beta(1.375, 0.5, 0.25) == pytest.approx(1.0)
    r = compute_wacc(
        WACCInputs(
            risk_free_rate=0.03,
            equity_risk_premium=0.05,
            beta_mode="peers",
            pre_tax_cost_of_debt=0.05,
            tax_rate=0.25,
            target_debt_to_capital=1 / 3,
            peer_betas=[
                PeerBeta(name="A", levered_beta=1.375, debt_to_equity=0.5, tax_rate=0.25),
                PeerBeta(name="B", levered_beta=0.9, debt_to_equity=0.0, tax_rate=0.25),
                PeerBeta(name="C", levered_beta=1.6, debt_to_equity=0.0, tax_rate=0.25),
            ],
        )
    )
    assert r.unlevered_beta == pytest.approx(1.0)  # median of 1.0, 0.9, 1.6
    assert r.levered_beta == pytest.approx(1.375)  # D/E = 0.5 at 1/3 debt weight


def test_wacc_requires_beta_for_mode():
    with pytest.raises(ValueError):
        WACCInputs(
            risk_free_rate=0.04,
            equity_risk_premium=0.05,
            beta_mode="unlevered_input",
            pre_tax_cost_of_debt=0.05,
            tax_rate=0.25,
            target_debt_to_capital=0.2,
        )
