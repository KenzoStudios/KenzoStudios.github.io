import pytest

from dealscout_engine.ratios import cagr, compute_ratios
from dealscout_engine.reconciliation import run_checks, summarise
from dealscout_engine.statements import FinancialData
from dealscout_engine.taxonomy import load_taxonomy


@pytest.fixture
def data():
    d = FinancialData(load_taxonomy())
    rows = {
        "revenue": (1000, 1100),
        "cogs": (-600, -650),
        "ebit": (150, 170),
        "depreciation": (-40, -45),
        "interest_expense": (-20, -20),
        "pretax_income": (130, 150),
        "income_tax": (-32.5, -37.5),
        "net_income": (97.5, 112.5),
        "cash": (100, 120),
        "receivables": (150, 180),
        "inventory": (120, 130),
        "total_current_assets": (370, 430),
        "total_assets": (1000, 1080),
        "payables": (90, 100),
        "total_current_liabilities": (200, 210),
        "st_debt": (50, 40),
        "lt_debt": (250, 240),
        "total_equity": (400, 470),
        "total_liabilities_and_equity": (1000, 1080),
        "cfo": (160, 180),
        "capex": (-60, -70),
    }
    for concept, (a, b) in rows.items():
        d.set(concept, "FY2024", a)
        d.set(concept, "FY2025", b)
    return d


def by_id(results, period):
    return {r.ratio_id: r for r in results if r.period_id == period}


def test_core_ratios(data):
    r = by_id(compute_ratios(data, ["FY2024", "FY2025"], prior_period={"FY2025": "FY2024"}), "FY2025")
    assert r["revenue_growth"].value == pytest.approx(0.10)
    assert r["gross_margin"].value == pytest.approx(450 / 1100)
    assert r["ebitda_margin"].value == pytest.approx(215 / 1100)  # EBITDA = 170 + 45
    assert r["free_cash_flow"].value == pytest.approx(110)
    assert r["net_debt"].value == pytest.approx(160)  # 280 − 120
    assert r["net_debt_to_ebitda"].value == pytest.approx(160 / 215)
    assert r["interest_coverage"].value == pytest.approx(8.5)
    assert r["dso"].value == pytest.approx(180 / 1100 * 365)
    assert r["dio"].value == pytest.approx(130 / 650 * 365)
    assert r["roic"].value == pytest.approx(170 * 0.75 / ((630 + 600) / 2))  # IC = equity + debt − cash
    assert r["roe"].value == pytest.approx(112.5 / 435)
    assert r["capex_to_revenue"].value == pytest.approx(70 / 1100)


def test_missing_inputs_are_reported_not_guessed(data):
    r = by_id(compute_ratios(data, ["FY2024"]), "FY2024")
    assert r["revenue_growth"].value is None and "No prior period" in r["revenue_growth"].derivation.note
    assert r["eps_growth"].value is None


def test_cagr():
    assert cagr(100, 121, 2) == pytest.approx(0.10)
    assert cagr(-5, 10, 2) is None


def test_reconciliation_checks(data):
    results = run_checks(data, ["FY2025"], rounding_unit=1)
    bs = next(r for r in results if r.check_id == "balance_sheet_balances")
    assert bs.status == "pass"
    tca = next(r for r in results if r.check_id == "subtotal:total_current_assets")
    assert tca.status == "pass"  # 120 + 180 + 130 = 430
    data.set("total_liabilities_and_equity", "FY2025", 1075)
    data.set("capex", "FY2025", 70)  # wrong sign
    results = run_checks(data, ["FY2025"], rounding_unit=1)
    assert next(r for r in results if r.check_id == "balance_sheet_balances").status == "fail"
    assert any(r.check_id == "sign:capex" and r.status == "fail" for r in results)
    counts = summarise(results)
    assert counts["errors"] >= 1 and counts["warnings"] >= 1


def test_rounding_tolerance_and_cash_roll_forward(data):
    data.set("total_liabilities_and_equity", "FY2025", 1080.4)
    data.set("cash_beginning", "FY2025", 100)
    data.set("net_change_in_cash", "FY2025", 22)
    data.set("fx_effect", "FY2025", -2)
    data.set("cash_ending", "FY2025", 120)
    results = {r.check_id: r for r in run_checks(data, ["FY2025"], rounding_unit=1)}
    assert results["balance_sheet_balances"].status == "pass"  # within rounding
    assert results["cash_roll_forward"].status == "pass"
    assert results["cash_ties_to_balance_sheet"].status == "pass"
