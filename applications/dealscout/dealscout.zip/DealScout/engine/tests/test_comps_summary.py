import pytest

from dealscout_engine.valuation.bridge import BridgeInputs, DilutionInputs
from dealscout_engine.valuation.comps import Peer, implied_value, multiple_stats, peer_regression
from dealscout_engine.valuation.summary import MethodRange, football_field


def peers(multiples, ebitda=100.0):
    return [
        Peer(
            name=f"P{i}",
            enterprise_value=m * ebitda,
            ebitda=ebitda,
            market_cap=m * ebitda * 0.8,
            net_income=ebitda * 0.5,
            revenue_growth=0.02 * i,
            ebitda_margin=0.1,
        )
        for i, m in enumerate(multiples)
    ]


def test_stats_match_excel_percentile_inc():
    s = multiple_stats(peers([6, 8, 10, 12]), "ev_ebitda")
    assert (s.min, s.p25, s.median, s.mean, s.p75, s.max) == pytest.approx((6, 7.5, 9, 9, 10.5, 12))


def test_not_meaningful_and_user_excluded_peers():
    group = peers([6, 8, 10])
    group.append(Peer(name="Loss-maker", enterprise_value=500, ebitda=-20))
    group[0].include = False
    s = multiple_stats(group, "ev_ebitda")
    assert s.n == 2
    assert "Loss-maker" in s.excluded and "P0" in s.excluded


def test_outlier_exclusion_iqr():
    s = multiple_stats(peers([5, 6, 7, 8, 40]), "ev_ebitda", exclude_outliers=True)
    assert "P4" in s.excluded and s.max == 8


def test_implied_value_ev_and_equity_bases():
    bridge = BridgeInputs(gross_debt=250, cash=50)
    ev_based = implied_value(multiple_stats(peers([6, 8, 10, 12]), "ev_ebitda"), 100, bridge)
    assert (ev_based.ev_low, ev_based.ev_mid, ev_based.ev_high) == pytest.approx((750, 900, 1050))
    assert (ev_based.equity_low, ev_based.equity_mid, ev_based.equity_high) == pytest.approx((550, 700, 850))
    pe = implied_value(multiple_stats(peers([10, 10, 10]), "pe"), 50, bridge)
    assert pe.equity_mid == pytest.approx(16 * 50)  # P/E = 0.8 × 10 × 100 ÷ 50 = 16
    assert pe.ev_mid == pytest.approx(16 * 50 + 200)
    missing = implied_value(multiple_stats(peers([6, 8]), "ev_ebitda"), -5, bridge)
    assert missing.ev_mid is None and missing.note


def test_regression():
    r = peer_regression(peers([6, 8, 10, 12]), "ev_ebitda", "revenue_growth", 0.03)
    assert r.slope == pytest.approx(100)  # multiple rises 2x per 2pp of growth
    assert r.r_squared == pytest.approx(1)
    assert r.intercept == pytest.approx(6)
    assert r.target_implied_y == pytest.approx(9)


def test_football_field_blend_and_per_share():
    ff = football_field(
        [
            MethodRange(method_id="dcf", label="DCF", equity_low=800, equity_mid=1000, equity_high=1200, weight=2),
            MethodRange(method_id="comps", label="Comps", equity_low=600, equity_mid=700, equity_high=900, weight=1),
            MethodRange(method_id="excluded", label="X", equity_low=1, equity_mid=2, equity_high=3, included=False),
        ],
        dilution=DilutionInputs(basic_shares=100),
    )
    assert ff.weights_normalised == pytest.approx({"dcf": 2 / 3, "comps": 1 / 3})
    assert ff.blended_equity_mid == pytest.approx(900)
    assert ff.blended_equity_low == pytest.approx(733.333, abs=1e-3)
    assert ff.blended_per_share.mid == pytest.approx(9)
    assert ff.method_per_share["comps"].high == pytest.approx(9)
