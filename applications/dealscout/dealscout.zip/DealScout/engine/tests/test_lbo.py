"""LBO tests against hand-checked cases."""

from __future__ import annotations

import pytest

from dealscout_engine.valuation.lbo import (
    LBOInputs,
    OperatingYear,
    Tranche,
    max_entry_price,
    run_lbo,
    sensitivity_entry_exit,
    sensitivity_leverage_exit,
)
from dealscout_engine.valuation.returns import irr, moic, npv


def flat(years: int = 5, ebitda: float = 100.0) -> list[OperatingYear]:
    return [OperatingYear(label=f"Y{t + 1}", revenue=1000.0, ebitda=ebitda, da=0.0, capex=0.0) for t in range(years)]


def tlb(**kw) -> Tranche:
    base = {"name": "TLB", "kind": "term_loan_b", "size_x_ebitda": 5.0, "rate_type": "fixed", "fixed_rate": 0.10}
    return Tranche(**{**base, **kw})


def test_irr_and_moic():
    assert irr([-100, 0, 0, 0, 0, 161.051]) == pytest.approx(0.10, abs=1e-9)
    assert irr([-100, 110]) == pytest.approx(0.10, abs=1e-9)
    assert irr([100, 50]) is None  # no investment
    assert npv(0.1, [-100, 110]) == pytest.approx(0.0)
    assert moic(100, 250) == 2.5 and moic(0, 10) is None


def test_no_sweep_cash_builds_up():
    # 10x EBITDA 100 → EV 1,000; TLB 5x at 10%, not prepayable; no tax, capex or NWC: 50 a year piles up as cash
    case = LBOInputs(
        entry_ebitda=100,
        entry_multiple=10,
        tranches=[tlb(sweep=False)],
        operating=flat(),
        tax_rate=0,
        exit_year=5,
        interest_on_average=False,
    )
    result = run_lbo(case)
    assert result.sponsor.equity_invested == pytest.approx(500)
    assert result.schedule[-1].closing_cash == pytest.approx(250)
    assert result.exit_net_debt == pytest.approx(250)
    assert result.exit_equity == pytest.approx(750)
    assert result.sponsor.moic == pytest.approx(1.5)
    assert result.sponsor.irr == pytest.approx(1.5**0.2 - 1, abs=1e-9)
    assert result.leverage_at_close == pytest.approx(5.0)


def test_full_sweep_equity_compounds_at_the_debt_rate():
    # all cash repays 10% debt and exit = entry multiple: equity value grows exactly 10% a year
    case = LBOInputs(
        entry_ebitda=100,
        entry_multiple=10,
        tranches=[tlb()],
        operating=flat(),
        tax_rate=0,
        exit_year=5,
        interest_on_average=False,
    )
    result = run_lbo(case)
    balances = [row.tranches[0].closing for row in result.schedule]
    assert balances == pytest.approx([450, 395, 334.5, 267.95, 194.745])
    assert result.sponsor.irr == pytest.approx(0.10, abs=1e-9)
    assert result.sponsor.moic == pytest.approx(1.61051)


def test_average_balance_interest_converges():
    case = LBOInputs(entry_ebitda=100, entry_multiple=10, tranches=[tlb()], operating=flat(), tax_rate=0, exit_year=5)
    row = run_lbo(case).schedule[0]
    # interest = 10% × (500 + closing)/2 and closing = 500 − (100 − interest): solve → closing = 450/0.95 … check
    closing = row.tranches[0].closing
    assert row.cash_interest == pytest.approx(0.10 * (500 + closing) / 2, rel=1e-9)
    assert closing == pytest.approx(500 - (100 - row.cash_interest), rel=1e-9)


def test_goal_seek_max_entry_price():
    # with the case above, exit equity is 805.255 whatever the price; 20% IRR needs equity 805.255/1.2^5
    case = LBOInputs(
        entry_ebitda=100,
        entry_multiple=10,
        tranches=[tlb()],
        operating=flat(),
        tax_rate=0,
        exit_year=5,
        exit_multiple=10,
        interest_on_average=False,
    )
    best = max_entry_price(case, target_irr=0.20)
    equity = 805.255 / 1.2**5
    assert best.entry_multiple == pytest.approx((equity + 500) / 100, rel=1e-6)
    assert best.equity_purchase_price == pytest.approx(equity + 500, rel=1e-6)
    with_moic = max_entry_price(case, target_irr=0.0, target_moic=2.0)
    assert with_moic.entry_multiple == pytest.approx((805.255 / 2 + 500) / 100, rel=1e-6)


def test_taxes_fees_amortisation_and_sources_uses():
    ops = [
        OperatingYear(label=f"Y{t + 1}", revenue=1000, ebitda=200, da=50, capex=40, change_in_nwc=10) for t in range(5)
    ]
    tla = Tranche(
        name="TLA",
        kind="term_loan_a",
        size_x_ebitda=2,
        rate_type="floating",
        margin=0.03,
        amortization_pct=0.10,
        fee_pct=0.02,
    )
    notes = Tranche(name="Notes", kind="senior_notes", amount=300, rate_type="fixed", fixed_rate=0.08)
    case = LBOInputs(
        entry_ebitda=200,
        entry_multiple=8,
        existing_net_debt=100,
        transaction_fee_pct=0.02,
        minimum_cash=20,
        tranches=[tla, notes],
        operating=ops,
        tax_rate=0.25,
        base_rate=0.04,
        interest_on_average=False,
        rollover_equity=100,
    )
    r = run_lbo(case)
    uses = {u.label: u.amount for u in r.uses}
    assert uses["Purchase of equity"] == 1_500 and uses["Refinance existing net debt"] == 100
    assert uses["Transaction fees"] == pytest.approx(32) and uses["Financing fees"] == pytest.approx(8)
    sources = {s.label: s.amount for s in r.sources}
    assert sources["Sponsor equity"] == pytest.approx(1_660 - 400 - 300 - 100)
    y1 = r.schedule[0]
    interest = 400 * 0.07 + 300 * 0.08
    assert y1.cash_interest == pytest.approx(interest)
    assert y1.cash_taxes == pytest.approx((200 - 50 - interest) * 0.25)
    assert y1.mandatory_repayment == pytest.approx(40)
    assert y1.tranches[1].sweep == 0  # notes are not prepayable
    assert y1.sweep == pytest.approx(200 - 40 - 10 - y1.cash_taxes - interest - 40)
    assert r.rollover is not None and r.rollover.moic == pytest.approx(r.sponsor.moic)


def test_pik_revolver_covenants_and_recap():
    ops = flat(5, ebitda=100)
    ops[0] = OperatingYear(label="Y1", revenue=1000, ebitda=100, da=0, capex=180)  # a capex year: needs the revolver
    rcf = Tranche(name="RCF", kind="revolver", rate_type="fixed", fixed_rate=0.05, commitment=150, priority=0)
    pik = Tranche(name="Mezz", kind="mezzanine", amount=100, rate_type="fixed", fixed_rate=0.12, pik=True)
    case = LBOInputs(
        entry_ebitda=100,
        entry_multiple=10,
        tranches=[rcf, tlb(), pik],
        operating=ops,
        tax_rate=0,
        interest_on_average=False,
        max_leverage=5.5,
        min_interest_coverage=2.5,
        dividend_recap_year=3,
        dividend_recap_x_ebitda=1.0,
    )
    r = run_lbo(case)
    y1 = r.schedule[0]
    assert y1.revolver_draw == pytest.approx(130)  # 100 − 180 − 50 interest
    assert y1.tranches[2].closing == pytest.approx(112)  # PIK accrues
    assert any("leverage" in b for b in r.covenant_breaches)
    assert r.schedule[2].dividend == pytest.approx(100)
    assert r.sponsor.cash_flows[3] == pytest.approx(100)  # the recap dividend reaches the sponsor
    small = run_lbo(case.model_copy(update={"tranches": [rcf.model_copy(update={"commitment": 100}), tlb(), pik]}))
    assert small.schedule[0].revolver_draw == pytest.approx(100)
    assert any("cash shortfall of 30" in w for w in small.warnings)


def test_validation_and_sensitivities():
    with pytest.raises(ValueError):
        LBOInputs(entry_ebitda=100, tranches=[], operating=flat(), tax_rate=0)  # no price
    with pytest.raises(ValueError):
        run_lbo(LBOInputs(entry_ebitda=100, entry_multiple=4, tranches=[tlb()], operating=flat(), tax_rate=0))
    case = LBOInputs(entry_ebitda=100, entry_multiple=10, tranches=[tlb()], operating=flat(), tax_rate=0)
    grid = sensitivity_entry_exit(case, [-1, 0, 1], [-1, 0, 1])
    assert grid.values[1][1] == pytest.approx(run_lbo(case).sponsor.irr)
    assert grid.values[0][2] > grid.values[2][0]  # cheaper entry, richer exit → higher IRR
    lev = sensitivity_leverage_exit(case, [0.8, 1.0, 1.2], [0])
    assert lev.rows == pytest.approx([4.0, 5.0, 6.0])
    with pytest.raises(ValueError, match="margin"):
        run_lbo(
            LBOInputs(
                entry_ebitda=100,
                entry_multiple=10,
                operating=flat(),
                tax_rate=0,
                tranches=[Tranche(name="X", rate_type="floating", size_x_ebitda=3)],
            )
        )


def test_duplicate_tranche_names_are_rejected():
    """Two tranches with one name would merge their balances (sources would no longer equal uses)."""
    with pytest.raises(ValueError, match="its own name"):
        LBOInputs(
            entry_ebitda=100,
            entry_multiple=8,
            operating=flat(),
            tax_rate=0.25,
            tranches=[tlb(name="Term loan B", size_x_ebitda=2), tlb(name="term loan b ", size_x_ebitda=3)],
        )
