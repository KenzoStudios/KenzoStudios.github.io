import pytest

from dealscout_engine.formula import FormulaError, evaluate, formula_names


def test_evaluate_basic_arithmetic():
    assert evaluate("ebit - da_total", {"ebit": 80, "da_total": -20}) == 100
    assert evaluate("(a + b) * 2 / c", {"a": 1, "b": 2, "c": 3}) == 2
    assert evaluate("-a + 1.5", {"a": 1}) == 0.5


def test_formula_names_in_order():
    assert formula_names("share_price * shares_outstanding") == ["share_price", "shares_outstanding"]


@pytest.mark.parametrize("bad", ["__import__('os')", "a ** 2", "a if b else c", "f(a)", "a.b", "'x'"])
def test_rejects_unsafe_syntax(bad):
    with pytest.raises(FormulaError):
        evaluate(bad, {"a": 1, "b": 1, "c": 1})


def test_missing_input_raises_key_error():
    with pytest.raises(KeyError):
        evaluate("a + b", {"a": 1})
