"""Currency conversion and calendarisation, checked against hand-worked figures."""

from datetime import date

import pytest

from dealscout_engine.fx import (
    FxRate,
    PeriodRates,
    convert_adjustments,
    convert_amount,
    convert_bridge,
    convert_financial_data,
    convert_peer,
    convert_per_share,
    rate_kind,
)
from dealscout_engine.scores import Adjustment
from dealscout_engine.statements import FinancialData
from dealscout_engine.taxonomy import load_taxonomy
from dealscout_engine.valuation.bridge import BridgeInputs, ev_to_equity
from dealscout_engine.valuation.calendarise import calendarisation_weights, calendarise, calendarise_peer
from dealscout_engine.valuation.comps import Peer, multiple_stats

AVG = FxRate(rate=0.085, as_of=date(2025, 12, 31), source="Central bank annual average")
CLOSE = FxRate(rate=0.080, as_of=date(2025, 12, 31), source="Central bank 31 Dec fixing")


@pytest.fixture
def data():
    d = FinancialData(load_taxonomy())
    d.set("revenue", "FY2025", 1000)  # NOK
    d.set("cogs", "FY2025", -600)
    d.set("capex", "FY2025", -50)
    d.set("cash", "FY2025", 200)
    d.set("lt_debt", "FY2025", 300)
    d.set("shares_outstanding", "FY2025", 10)
    d.set("eps_basic", "FY2025", 4)
    return d


def test_rate_kind_follows_statement_type():
    t = load_taxonomy()
    assert rate_kind(t.concept("revenue")) == "average"
    assert rate_kind(t.concept("capex")) == "average"  # cash flow
    assert rate_kind(t.concept("cash")) == "closing"  # balance sheet
    assert rate_kind(t.concept("cash_ending")) == "closing"  # a balance shown on the cash-flow statement
    assert rate_kind(t.concept("share_price")) == "closing"
    assert rate_kind(t.concept("eps_basic")) == "average"  # per share, a flow
    assert rate_kind(t.concept("shares_outstanding")) is None


def test_income_and_cash_flow_use_average_balance_sheet_uses_closing(data):
    result = convert_financial_data(data, [PeriodRates(period_id="FY2025", average=AVG, closing=CLOSE)])
    assert result.complete
    out = result.data
    assert out.get("revenue", "FY2025") == pytest.approx(85.0)  # 1000 × 0.085
    assert out.get("cogs", "FY2025") == pytest.approx(-51.0)  # −600 × 0.085
    assert out.get("gross_profit", "FY2025") == pytest.approx(34.0)  # recomputed from converted lines
    assert out.get("capex", "FY2025") == pytest.approx(-4.25)  # −50 × 0.085
    assert out.get("cash", "FY2025") == pytest.approx(16.0)  # 200 × 0.080
    assert out.get("lt_debt", "FY2025") == pytest.approx(24.0)  # 300 × 0.080
    assert out.get("shares_outstanding", "FY2025") == 10  # a count, unchanged
    assert out.get("eps_basic", "FY2025") == pytest.approx(0.34)  # 4 × 0.085
    used = {(u.period_id, u.kind): u for u in result.used}
    assert used[("FY2025", "average")].values == 4
    assert used[("FY2025", "closing")].values == 2
    assert used[("FY2025", "closing")].note == "converted at 0.08 (2025-12-31, Central bank 31 Dec fixing)"


def test_missing_rate_is_listed_not_guessed(data):
    result = convert_financial_data(data, [PeriodRates(period_id="FY2025", average=AVG)])
    assert not result.complete
    assert [(m.period_id, m.kind) for m in result.missing] == [("FY2025", "closing")]
    assert sorted(result.missing[0].concepts) == ["cash", "lt_debt"]
    assert result.data.get("cash", "FY2025") is None  # left out, never converted at another rate
    assert result.data.get("revenue", "FY2025") == pytest.approx(85.0)


def test_amount_and_per_share_conversion():
    assert convert_amount(250, 1.1) == pytest.approx(275)
    assert convert_per_share(12.5, 0.08) == pytest.approx(1.0)
    assert convert_per_share(None, 0.08) is None
    with pytest.raises(ValueError):
        convert_amount(1, 0)
    with pytest.raises(ValueError):
        FxRate(rate=-1, as_of=date(2025, 1, 1), source="x")


def test_bridge_items_convert_and_equity_follows():
    b = BridgeInputs(gross_debt=300, cash=200, minimum_operating_cash=50, pension_deficit=40, pension_tax_rate=0.25)
    c = convert_bridge(b, 0.08)
    assert (c.gross_debt, c.cash, c.minimum_operating_cash, c.pension_deficit) == pytest.approx((24, 16, 4, 3.2))
    assert c.pension_tax_rate == 0.25 and c.include_leases is True  # toggles and rates untouched
    # EV 1,000 NOK: equity = 1000 − 300 − 40 × 0.75 + (200 − 50) = 820 NOK = 65.6 at 0.08
    assert ev_to_equity(1000, b).equity_value == pytest.approx(820)
    assert ev_to_equity(80, c).equity_value == pytest.approx(65.6)


def test_one_off_adjustments_convert_at_average_rate():
    items = [
        Adjustment(id="a", period_key="FY2025", label="Restructuring", amount=-100, confirmed=True),
        Adjustment(id="b", period_key="FY2024", label="Disposal gain", amount=20, confirmed=True),
    ]
    converted, missing = convert_adjustments(items, [PeriodRates(period_id="FY2025", average=AVG, closing=CLOSE)])
    assert [a.amount for a in converted] == pytest.approx([-8.5])  # −100 × 0.085
    assert [(m.period_id, m.kind, m.concepts) for m in missing] == [("FY2024", "average", ["one-off: Disposal gain"])]


def test_peer_conversion_keeps_multiples_and_flags_missing_rates():
    gbp = Peer(name="UK Co", currency="GBP", enterprise_value=1200, revenue=600, ebitda=150, revenue_growth=0.05)
    rate = FxRate(rate=1.17, as_of=date(2025, 12, 31), source="ECB reference rate")
    conv = convert_peer(gbp, "EUR", {"GBP": rate})
    assert conv.converted
    assert conv.peer.enterprise_value == pytest.approx(1404)  # 1200 × 1.17
    assert conv.peer.ebitda == pytest.approx(175.5)
    assert conv.peer.revenue_growth == 0.05  # a ratio, unchanged
    assert conv.peer.multiple("ev_ebitda") == pytest.approx(gbp.multiple("ev_ebitda"))  # 8.0x either way
    assert conv.note == "GBP converted at 1.17 (2025-12-31, ECB reference rate)"
    missing = convert_peer(gbp, "EUR", {})
    assert missing.missing_rate and not missing.converted
    same = convert_peer(Peer(name="DE Co", ebitda=1), "EUR", {})
    assert not same.converted and not same.missing_rate and same.from_currency == "EUR"


@pytest.mark.parametrize(
    ("peer_month", "target_month", "weights"),
    [
        (3, 12, (0.25, 0.75)),  # March peer, December target: 3/12 of FY Mar-25 + 9/12 of FY Mar-26
        (6, 12, (0.5, 0.5)),
        (12, 3, (0.75, 0.25)),  # December peer, March target: 9/12 of FY Dec-24 + 3/12 of FY Dec-25
        (9, 6, (0.25, 0.75)),  # September peer, June target: d = (6 − 9) mod 12 = 9
        (12, 12, (1.0, 0.0)),
    ],
)
def test_calendarisation_weights(peer_month, target_month, weights):
    assert calendarisation_weights(peer_month, target_month) == pytest.approx(weights)


def test_calendarise_worked_example():
    # FY Mar-2025 revenue 400, FY Mar-2026 revenue 480: calendar 2025 = 0.25 × 400 + 0.75 × 480 = 460
    assert calendarise(400, 480, 3, 12) == pytest.approx(460)
    assert calendarise(400, None, 3, 12) is None  # the following year is needed
    assert calendarise(400, None, 12, 12) == 400
    with pytest.raises(ValueError):
        calendarisation_weights(0, 12)


def test_calendarise_peer_and_multiples():
    peer = Peer(
        name="March Co",
        fiscal_year_end_month=3,
        enterprise_value=920,
        net_debt=100,
        market_cap=820,
        revenue=400,
        revenue_next=480,
        ebitda=80,
        ebitda_next=120,
        net_income=40,  # no following year entered
    )
    result = calendarise_peer(peer, 12)
    assert result.calendarised and result.weights == pytest.approx((0.25, 0.75))
    assert result.peer.revenue == pytest.approx(460)
    assert result.peer.ebitda == pytest.approx(110)  # 0.25 × 80 + 0.75 × 120
    assert result.peer.net_income is None and result.missing_next == ["net_income"]
    assert result.peer.enterprise_value == 920  # market values are not calendarised
    assert "0.25 × FY ending March + 0.75 × the following FY" in (result.note or "")
    stats = multiple_stats([result.peer], "ev_ebitda")
    assert stats.median == pytest.approx(920 / 110)
    pe = multiple_stats([result.peer], "pe")
    assert pe.n == 0 and "March Co" in pe.excluded
    # same year-end or unknown year-end: unchanged
    assert not calendarise_peer(peer.model_copy(update={"fiscal_year_end_month": 12}), 12).calendarised
    assert not calendarise_peer(peer, None).calendarised


def test_every_peer_amount_field_is_converted() -> None:
    """New money fields on Peer must be listed in PEER_AMOUNT_FIELDS or multiples would mix currencies."""
    from dealscout_engine.fx import PEER_AMOUNT_FIELDS
    from dealscout_engine.valuation.comps import Peer

    not_amounts = {"name", "ticker", "country", "include", "currency", "fiscal_year_end_month"}
    not_amounts |= {"revenue_growth", "ebitda_margin", "eps_growth", "as_of", "source", "notes", "exchange"}
    floats = {n for n, f in Peer.model_fields.items() if n not in not_amounts and "float" in str(f.annotation)}
    assert floats <= set(PEER_AMOUNT_FIELDS), floats - set(PEER_AMOUNT_FIELDS)
