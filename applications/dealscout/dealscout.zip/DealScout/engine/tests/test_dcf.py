from datetime import date

import pytest

from dealscout_engine.valuation.bridge import BridgeInputs, DilutionInputs
from dealscout_engine.valuation.dcf import (
    DCFInputs,
    ProjectionDrivers,
    Scenario,
    apply_scenario,
    default_scenarios,
    project,
    run_dcf,
    run_scenarios,
    sensitivity_growth_margin,
    sensitivity_wacc_exit,
    sensitivity_wacc_growth,
    stub_fraction,
)

FLAT = ProjectionDrivers(
    base_revenue=1000,
    revenue_growth=[0] * 5,
    ebitda_margin=[0.1] * 5,
    da_pct_revenue=[0] * 5,
    capex_pct_revenue=[0] * 5,
    nwc_pct_revenue=[0] * 5,
    tax_rate=0.0,
)


def inputs(**overrides):
    base = dict(
        drivers=FLAT,
        wacc=0.10,
        terminal_growth=0.0,
        exit_multiple=10.0,
        valuation_date=date(2025, 12, 31),
        first_year_end=date(2026, 12, 31),
        mid_year=False,
    )
    base.update(overrides)
    return DCFInputs(**base)


def test_flat_perpetuity_is_worth_fcf_over_wacc():
    r = run_dcf(inputs())
    # PV of 5 × 100 at 10% = 379.08; TV = 100 / 0.10 = 1000, PV = 620.92; EV = 1000 exactly
    assert r.sum_pv_fcf == pytest.approx(379.0787, abs=1e-3)
    assert r.gordon.value == pytest.approx(1000)
    assert r.enterprise_value == pytest.approx(1000)
    assert r.gordon.implied_cross_check == pytest.approx(10.0)  # 1000 ÷ EBITDA 100


def test_mid_year_convention_lifts_only_the_explicit_cash_flows():
    r = run_dcf(inputs(mid_year=True))
    assert r.sum_pv_fcf == pytest.approx(379.0787 * 1.1**0.5, abs=1e-3)
    assert r.terminal_value_pv == pytest.approx(620.9213, abs=1e-3)


def test_gordon_growth_and_cross_check_round_trip():
    r = run_dcf(inputs(terminal_growth=0.02))
    assert r.gordon.value == pytest.approx(100 * 1.02 / 0.08)
    implied = r.gordon.implied_cross_check
    r2 = run_dcf(inputs(terminal_growth=0.02, exit_multiple=implied, terminal_method="exit_multiple"))
    assert r2.exit.implied_cross_check == pytest.approx(0.02)  # implied growth from the exit TV recovers g
    assert r2.enterprise_value == pytest.approx(r.enterprise_value)


def test_taxes_with_nol_and_working_capital():
    d = ProjectionDrivers(
        base_revenue=1000,
        revenue_growth=[0.10, 0.0, 0.0],
        ebitda_margin=[0.2] * 3,
        da_pct_revenue=[0.05] * 3,
        capex_pct_revenue=[0.05] * 3,
        nwc_pct_revenue=[0.1] * 3,
        tax_rate=0.25,
        nol_opening=200,
    )
    rows = project(d)
    # year 1: revenue 1100, EBITDA 220, D&A 55, EBIT 165 fully sheltered by NOL → no tax
    assert rows[0]["ebit"] == pytest.approx(165)
    assert rows[0]["cash_taxes"] == 0
    assert rows[0]["change_in_nwc"] == pytest.approx(10)  # NWC 110 − opening 100
    assert rows[0]["unlevered_fcf"] == pytest.approx(165 + 55 - 55 - 10)
    # year 2: 35 of NOL left → taxable 130 → tax 32.5
    assert rows[1]["nol_used"] == pytest.approx(35)
    assert rows[1]["cash_taxes"] == pytest.approx(32.5)
    assert rows[2]["cash_taxes"] == pytest.approx(41.25)


def test_sbc_toggle():
    d = FLAT.model_copy(update={"sbc_pct_revenue": [0.01] * 5})
    expensed = project(d)[0]["unlevered_fcf"]
    added_back = project(d.model_copy(update={"sbc_treatment": "add_back"}))[0]["unlevered_fcf"]
    assert added_back - expensed == pytest.approx(10)


def test_stub_period():
    assert stub_fraction(date(2026, 6, 30), date(2026, 12, 31)) == pytest.approx(184 / 365)
    r = run_dcf(inputs(valuation_date=date(2026, 6, 30)))
    assert r.projection[0].period_fraction == pytest.approx(184 / 365)
    assert r.projection[0].pv_fcf == pytest.approx(100 * 184 / 365 / 1.1 ** (184 / 365))
    assert any("Stub period" in w for w in r.warnings)


def test_bridge_and_per_share():
    r = run_dcf(inputs(bridge=BridgeInputs(gross_debt=200, cash=50), dilution=DilutionInputs(basic_shares=85)))
    assert r.equity_value == pytest.approx(850)
    assert r.per_share.value_per_share == pytest.approx(10)


def test_warnings_terminal_share_and_growth_vs_rf():
    r = run_dcf(inputs(terminal_growth=0.05, risk_free_rate=0.04))  # TV share 77.5%
    assert any("Terminal value is" in w for w in r.warnings)
    assert any("risk-free" in w for w in r.warnings)


def test_wacc_must_exceed_growth():
    with pytest.raises(ValueError):
        run_dcf(inputs(wacc=0.02, terminal_growth=0.02))


def test_forecast_period_bounds():
    with pytest.raises(ValueError):
        ProjectionDrivers(
            base_revenue=1,
            revenue_growth=[0, 0],
            ebitda_margin=[0, 0],
            da_pct_revenue=[0, 0],
            capex_pct_revenue=[0, 0],
            nwc_pct_revenue=[0, 0],
            tax_rate=0,
        )


def test_sensitivities_centre_equals_base():
    i = inputs(terminal_growth=0.02)
    base = run_dcf(i).enterprise_value
    t1 = sensitivity_wacc_growth(i, [-0.01, 0, 0.01], [-0.005, 0, 0.005])
    assert t1.values[1][1] == pytest.approx(base)
    assert t1.values[0][1] > t1.values[2][1]  # lower WACC → higher EV
    t2 = sensitivity_wacc_exit(i, [-0.01, 0, 0.01], [-1, 0, 1])
    assert t2.values[1][1] == pytest.approx(
        run_dcf(i.model_copy(update={"terminal_method": "exit_multiple"})).enterprise_value
    )
    t3 = sensitivity_growth_margin(i, [-0.01, 0, 0.01], [-0.01, 0, 0.01])
    assert t3.values[1][1] == pytest.approx(base)
    assert t3.values[2][2] > t3.values[0][0]


def test_scenarios_probability_weighted():
    i = inputs(terminal_growth=0.02)
    s = run_scenarios(
        i,
        [
            Scenario(name="bear", probability=0.25, margin_shift=-0.02),
            Scenario(name="base", probability=0.5),
            Scenario(name="bull", probability=0.25, margin_shift=0.02),
        ],
    )
    evs = {r.name: r.enterprise_value for r in s.scenarios}
    assert evs["bear"] < evs["base"] < evs["bull"]
    assert s.probability_weighted_ev == pytest.approx(0.25 * evs["bear"] + 0.5 * evs["base"] + 0.25 * evs["bull"])
    with pytest.raises(ValueError):
        run_scenarios(i, [Scenario(name="base", probability=0.9)])


def test_custom_scenarios_apply_every_shift():
    i = inputs(terminal_growth=0.02, terminal_method="average")
    s = Scenario(
        name="Rate shock",
        probability=1.0,
        growth_shift=0.01,
        margin_shift=-0.01,
        wacc_shift=0.015,
        exit_multiple_shift=-1.5,
        terminal_growth_shift=-0.005,
    )
    v = apply_scenario(i, s)
    assert v.wacc == pytest.approx(0.115)
    assert v.exit_multiple == pytest.approx(8.5)
    assert v.terminal_growth == pytest.approx(0.015)
    assert v.drivers.revenue_growth == pytest.approx([0.01] * 5)
    assert v.drivers.ebitda_margin == pytest.approx([0.09] * 5)
    summary = run_scenarios(i, [s])
    assert summary.scenarios[0].enterprise_value == pytest.approx(run_dcf(v).enterprise_value)
    assert summary.scenarios[0].wacc == pytest.approx(0.115)
    # a lower terminal growth alone lowers the Gordon value
    lower = run_scenarios(
        inputs(terminal_growth=0.02, terminal_method="gordon"),
        [
            Scenario(name="a", probability=0.5),
            Scenario(name="b", probability=0.5, terminal_growth_shift=-0.01),
        ],
    )
    assert lower.scenarios[1].enterprise_value < lower.scenarios[0].enterprise_value


def test_up_to_six_named_scenarios_validated():
    i = inputs(terminal_growth=0.02)
    six = [Scenario(name=f"Case {n}", probability=1 / 6, growth_shift=(n - 3) / 100) for n in range(6)]
    assert len(run_scenarios(i, six).scenarios) == 6
    with pytest.raises(ValueError, match="between 1 and 6"):
        run_scenarios(i, [*six, Scenario(name="seventh", probability=0.0)])
    with pytest.raises(ValueError, match="own name"):
        run_scenarios(i, [Scenario(name="Base", probability=0.5), Scenario(name="base", probability=0.5)])
    with pytest.raises(ValueError, match="WACC must exceed"):
        run_scenarios(i, [Scenario(name="x", probability=1.0, terminal_growth_shift=0.09)])
    defaults = default_scenarios()
    assert [d.name for d in defaults] == ["bear", "base", "bull"]
    assert sum(d.probability for d in defaults) == pytest.approx(1.0)
