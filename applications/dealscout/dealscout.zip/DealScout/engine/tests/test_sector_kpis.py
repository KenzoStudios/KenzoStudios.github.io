import pytest

from dealscout_engine.sector_kpis import KPI_SETS, SECTOR_KPI_TEMPLATES, compute_sector_kpis
from dealscout_engine.statements import FinancialData
from dealscout_engine.taxonomy import load_taxonomy

PRIOR = {"FY2025": "FY2024"}


def make(rows: dict[str, tuple[float | None, float | None]]) -> FinancialData:
    d = FinancialData(load_taxonomy())
    for concept, (a, b) in rows.items():
        if a is not None:
            d.set(concept, "FY2024", a)
        if b is not None:
            d.set(concept, "FY2025", b)
    return d


def kpi(results, kpi_id, period="FY2025"):
    return next(r for r in results if r.ratio_id == kpi_id and r.period_id == period)


def test_every_template_kpi_reads_known_concepts():
    taxonomy = load_taxonomy()
    assert set(KPI_SETS) == set(SECTOR_KPI_TEMPLATES)
    for kpis in KPI_SETS.values():
        for k in kpis:
            if k.reported:
                assert taxonomy.concept(k.reported).statement in ("sector_kpi", "memo")


def test_general_template_has_no_kpis():
    assert compute_sector_kpis(make({"revenue": (1, 2)}), ["FY2025"], "general") == []


def test_bank_kpis_computed_from_inputs():
    d = make(
        {
            "net_interest_income": (None, 30),
            "interest_earning_assets": (900, 1100),
            "bank_operating_income": (None, 50),
            "bank_operating_expenses": (None, -27.5),
            "non_performing_loans": (None, 24),
            "gross_loans": (None, 800),
            "cet1_ratio": (None, 0.142),
        }
    )
    out = compute_sector_kpis(d, ["FY2024", "FY2025"], "bank", prior_period=PRIOR)
    assert kpi(out, "net_interest_margin").value == pytest.approx(30 / 1000)  # average of 900 and 1100
    assert kpi(out, "cost_income_ratio").value == pytest.approx(0.55)
    assert kpi(out, "npl_ratio").value == pytest.approx(0.03)
    cet1 = kpi(out, "cet1_ratio")
    assert cet1.value == pytest.approx(0.142) and cet1.derivation.kind == "reported"
    assert all(r.group == "sector" for r in out)
    assert kpi(out, "net_interest_margin", "FY2024").value is None


def test_reported_figure_used_when_inputs_missing_and_note_when_different():
    d = make({"net_interest_margin": (None, 0.021), "npl_ratio": (None, 0.05)})
    out = compute_sector_kpis(d, ["FY2025"], "bank")
    nim = kpi(out, "net_interest_margin")
    assert nim.value == pytest.approx(0.021) and nim.derivation.kind == "reported"
    # computed value wins over a different reported figure, with a note
    d.set("non_performing_loans", "FY2025", 30)
    d.set("gross_loans", "FY2025", 1000)
    npl = kpi(compute_sector_kpis(d, ["FY2025"], "bank"), "npl_ratio")
    assert npl.value == pytest.approx(0.03) and npl.derivation.kind == "computed"
    assert "different figure" in (npl.derivation.note or "")


def test_missing_kpi_says_what_to_enter():
    out = compute_sector_kpis(make({}), ["FY2025"], "bank")
    ci = kpi(out, "cost_income_ratio")
    assert ci.value is None and ci.derivation.kind == "missing"
    assert "operating_income" in (ci.derivation.note or "")
    assert "cet1_ratio" in (kpi(out, "cet1_ratio").derivation.note or "")


def test_cost_income_not_meaningful_on_negative_income():
    out = compute_sector_kpis(
        make({"bank_operating_income": (None, -5), "bank_operating_expenses": (None, -10)}), ["FY2025"], "bank"
    )
    assert kpi(out, "cost_income_ratio").value is None


def test_insurer_combined_and_solvency():
    d = make(
        {
            "net_earned_premiums": (None, 1000),
            "net_claims_incurred": (None, -650),
            "insurance_operating_expenses": (None, -300),
            "eligible_own_funds": (None, 2100),
            "solvency_capital_requirement": (None, 1000),
        }
    )
    out = compute_sector_kpis(d, ["FY2025"], "insurer")
    assert kpi(out, "combined_ratio").value == pytest.approx(0.95)
    assert kpi(out, "solvency_ratio").value == pytest.approx(2.1)
    assert kpi(out, "combined_ratio").higher_is_better is False


def test_insurer_reported_combined_ratio_fallback():
    out = compute_sector_kpis(make({"combined_ratio": (None, 0.97)}), ["FY2025"], "insurer")
    assert kpi(out, "combined_ratio").value == pytest.approx(0.97)


def test_saas_arr_growth_and_rule_of_40():
    d = make(
        {
            "arr": (100, 130),
            "net_revenue_retention": (None, 1.12),
            "revenue": (80, 100),
            "ebitda": (5, 15),
        }
    )
    out = compute_sector_kpis(d, ["FY2024", "FY2025"], "saas", prior_period=PRIOR)
    assert kpi(out, "arr").value == 130 and kpi(out, "arr").unit == "currency"
    assert kpi(out, "arr_growth").value == pytest.approx(0.30)
    assert kpi(out, "net_revenue_retention").value == pytest.approx(1.12)
    assert kpi(out, "rule_of_40").value == pytest.approx(0.25 + 0.15)
    assert kpi(out, "rule_of_40", "FY2024").value is None  # no prior year for growth
    assert kpi(out, "arr_growth", "FY2024").derivation.kind == "missing"


def test_rule_of_40_not_meaningful_without_positive_revenue():
    d = make({"revenue": (80, 0), "ebitda": (5, -3)})
    out = compute_sector_kpis(d, ["FY2025"], "saas", prior_period=PRIOR)
    assert kpi(out, "rule_of_40").value is None


def test_real_estate_ltv_and_yield():
    d = make(
        {
            "lt_debt": (None, 450),
            "st_debt": (None, 50),
            "cash": (None, 40),
            "non_current_lease_liabilities": (None, 999),  # leases are excluded from LTV
            "investment_property": (None, 1000),
            "noi": (None, 48),
            "occupancy_rate": (None, 0.955),
        }
    )
    out = compute_sector_kpis(d, ["FY2025"], "real_estate")
    assert kpi(out, "loan_to_value").value == pytest.approx(0.46)
    assert kpi(out, "property_yield").value == pytest.approx(0.048)
    assert kpi(out, "occupancy_rate").value == pytest.approx(0.955)
    assert kpi(out, "noi").value == 48


def test_real_estate_ltv_needs_positive_property_value():
    d = make({"lt_debt": (None, 450), "cash": (None, 40), "investment_property": (None, 0)})
    assert kpi(compute_sector_kpis(d, ["FY2025"], "real_estate"), "loan_to_value").value is None


def test_retail_lfl_and_revenue_per_store():
    d = make({"like_for_like_growth": (None, -0.012), "store_count": (None, 250), "revenue": (None, 500)})
    out = compute_sector_kpis(d, ["FY2025"], "retail")
    assert kpi(out, "like_for_like_growth").value == pytest.approx(-0.012)
    assert kpi(out, "revenue_per_store").value == pytest.approx(2.0)
    assert kpi(out, "store_count").unit == "number"
