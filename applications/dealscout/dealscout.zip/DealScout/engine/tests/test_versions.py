import pytest

from dealscout_engine.versions import diff_fields, diff_values, result_deltas


def test_diff_values_reports_changed_added_and_removed_cells():
    version = {("FY2024", "revenue"): 100.0, ("FY2024", "ebitda"): 20.0, ("FY2023", "revenue"): 90.0}
    current = {("FY2024", "revenue"): 110.0, ("FY2024", "ebitda"): 20.0 + 1e-12, ("FY2025", "revenue"): 120.0}
    diffs = diff_values(version, current)
    assert [(d.period_key, d.concept_id) for d in diffs] == [
        ("FY2023", "revenue"),
        ("FY2024", "revenue"),
        ("FY2025", "revenue"),
    ]
    removed, changed, added = diffs
    assert removed.current is None and removed.change is None
    assert changed.change == pytest.approx(10.0)
    assert added.version is None


def test_diff_fields_flat_documents():
    diffs = diff_fields("overrides", {"tax_rate": 0.25, "wacc": 0.1, "mid_year": True}, {"tax_rate": 0.3, "wacc": 0.1})
    assert [(d.key, d.version, d.current) for d in diffs] == [("mid_year", True, None), ("tax_rate", 0.25, 0.3)]
    assert diff_fields("x", {"a": [0.1, 0.2]}, {"a": [0.1, 0.2]}) == []


def test_result_deltas():
    out = {
        d.key: d
        for d in result_deltas(
            {"mid": 200.0, "low": 0.0, "methods": ["dcf"], "gone": 5.0},
            {"mid": 250.0, "low": 10.0, "methods": ["dcf", "lbo"], "new": 1.0},
        )
    }
    assert set(out) == {"mid", "low", "gone", "new"}
    assert out["mid"].change == pytest.approx(50.0) and out["mid"].change_pct == pytest.approx(0.25)
    assert out["low"].change == pytest.approx(10.0) and out["low"].change_pct is None
    assert out["gone"].current is None and out["gone"].change is None
