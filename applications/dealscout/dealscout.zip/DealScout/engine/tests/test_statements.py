import pytest

from dealscout_engine.statements import FinancialData
from dealscout_engine.taxonomy import load_taxonomy


@pytest.fixture
def data():
    return FinancialData(load_taxonomy())


def test_reported_value_wins_over_components(data):
    data.set("revenue", "FY2025", 1000)
    data.set("cogs", "FY2025", -600)
    data.set("gross_profit", "FY2025", 401)  # as reported (rounding difference)
    assert data.get("gross_profit", "FY2025") == 401
    assert data.resolve("gross_profit", "FY2025").derivation.kind == "reported"


def test_sum_concept_computed_from_components(data):
    data.set("revenue", "FY2025", 1000)
    data.set("cogs", "FY2025", -600)
    resolved = data.resolve("gross_profit", "FY2025")
    assert resolved.value == 400
    assert resolved.derivation.kind == "computed"
    assert resolved.derivation.formula == "revenue + cogs"


def test_sum_with_missing_components_is_flagged(data):
    data.set("cash", "FY2025", 50)
    data.set("receivables", "FY2025", 120)
    resolved = data.resolve("total_current_assets", "FY2025")
    assert resolved.value == 170
    assert "inventory" in (resolved.derivation.note or "")


def test_formula_concept_ebitda(data):
    data.set("ebit", "FY2025", 150)
    data.set("depreciation", "FY2025", -40)
    data.set("amortization", "FY2025", -10)
    resolved = data.resolve("ebitda", "FY2025")
    assert resolved.value == 200
    assert resolved.derivation.formula == "ebit - da_total"


def test_formula_with_missing_input_is_missing_not_guessed(data):
    data.set("ebit", "FY2025", 150)
    resolved = data.resolve("ebitda", "FY2025")
    assert resolved.value is None
    assert resolved.derivation.kind == "missing"
    assert "da_total" in (resolved.derivation.note or "")


def test_entered_ebitda_used_directly(data):
    data.set("ebitda", "FY2025", 220)
    assert data.get("ebitda", "FY2025") == 220


def test_unknown_concept_rejected(data):
    with pytest.raises(KeyError):
        data.set("not_a_concept", "FY2025", 1)
