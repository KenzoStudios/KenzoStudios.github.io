import pytest

from dealscout_engine.capital import capital_structure
from dealscout_engine.statements import FinancialData
from dealscout_engine.taxonomy import load_taxonomy


def test_capital_structure_and_maturity_profile():
    d = FinancialData(load_taxonomy())
    for concept, value in {
        "st_debt": 50,
        "lt_debt": 250,
        "current_lease_liabilities": 10,
        "non_current_lease_liabilities": 30,
        "total_equity": 700,
        "cash": 80,
        "st_investments": 20,
        "credit_facilities": 100,
        "debt_due_within_1y": 50,
        "debt_due_1_2y": 60,
        "debt_due_2_5y": 140,
        "debt_due_after_5y": 30,
    }.items():
        d.set(concept, "FY2025", value)
    cs = capital_structure(d, "FY2025")
    assert (cs.debt, cs.leases, cs.equity, cs.cash) == (300, 40, 700, 100)
    assert cs.total_capital == 1040
    assert [b.amount for b in cs.maturities] == [50, 60, 140, 30]
    assert cs.maturities_total == 280 and cs.unallocated_debt == 20
    assert cs.liquidity_cover == pytest.approx(200 / 50)


def test_capital_structure_without_a_maturity_note():
    d = FinancialData(load_taxonomy())
    d.set("lt_debt", "FY2025", 100)
    cs = capital_structure(d, "FY2025")
    assert cs.debt == 100 and cs.leases is None and cs.maturities_total is None
    assert cs.unallocated_debt is None and cs.liquidity_cover is None
