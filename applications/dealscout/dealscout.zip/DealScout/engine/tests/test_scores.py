"""Altman Z, Piotroski F, Beneish M, red flags and one-off adjustments."""

from __future__ import annotations

import pytest

from dealscout_engine.scores import (
    Adjustment,
    adjusted_metrics,
    altman_variant,
    altman_z,
    beneish_m,
    piotroski_f,
    red_flags,
)
from dealscout_engine.statements import FinancialData
from dealscout_engine.taxonomy import load_taxonomy

TAX = load_taxonomy()


def data(values: dict[str, dict[str, float]]) -> FinancialData:
    d = FinancialData(TAX)
    for concept, by_period in values.items():
        for period, value in by_period.items():
            d.values[(concept, period)] = value
    return d


BASE = {
    "total_assets": {"FY2024": 1000, "FY2025": 1100},
    "total_current_assets": {"FY2024": 400, "FY2025": 450},
    "total_current_liabilities": {"FY2024": 250, "FY2025": 250},
    "reserves": {"FY2024": 300, "FY2025": 330},
    "ebit": {"FY2024": 100, "FY2025": 120},
    "ebitda": {"FY2024": 150, "FY2025": 175},
    "total_liabilities": {"FY2024": 600, "FY2025": 640},
    "total_equity": {"FY2024": 400, "FY2025": 460},
    "revenue": {"FY2024": 1200, "FY2025": 1300},
    "gross_profit": {"FY2024": 400, "FY2025": 450},
    "net_income": {"FY2024": 60, "FY2025": 75},
    "cfo": {"FY2024": 90, "FY2025": 110},
    "lt_debt": {"FY2024": 300, "FY2025": 280},
    "shares_outstanding": {"FY2024": 100, "FY2025": 100},
    "receivables": {"FY2024": 200, "FY2025": 210},
    "ppe": {"FY2024": 500, "FY2025": 520},
    "depreciation": {"FY2024": -50, "FY2025": -55},
    "sga": {"FY2024": -250, "FY2025": -260},
}


def test_altman_variants():
    d = data(BASE)
    private = altman_z(d, "FY2025", "private")
    x = [200 / 1100, 330 / 1100, 120 / 1100, 460 / 640, 1300 / 1100]
    expected = 0.717 * x[0] + 0.847 * x[1] + 3.107 * x[2] + 0.420 * x[3] + 0.998 * x[4]
    assert private.value == pytest.approx(expected) and private.zone == "grey"
    public = altman_z(d, "FY2025", "public_manufacturing")
    assert public.value is None and any("market capitalisation" in m for m in public.missing)
    public = altman_z(d, "FY2025", "public_manufacturing", market_cap=1500)
    assert public.value == pytest.approx(1.2 * x[0] + 1.4 * x[1] + 3.3 * x[2] + 0.6 * 1500 / 640 + 1.0 * x[4])
    nonman = altman_z(d, "FY2025", "non_manufacturing")
    assert nonman.value == pytest.approx(6.56 * x[0] + 3.26 * x[1] + 6.72 * x[2] + 1.05 * x[3])
    assert altman_variant(listed=False, sector="industrials") == "private"
    assert altman_variant(listed=True, sector="software") == "non_manufacturing"


def test_piotroski():
    f = piotroski_f(data(BASE), "FY2025", "FY2024")
    # asset turnover falls (1,300/1,100 < 1,200/1,000): 8 of 9
    assert f.value == 8 and f.zone == "strong" and not f.missing
    assert f.components["Asset turnover improved"] == 0.0
    worse = {**BASE, "shares_outstanding": {"FY2024": 100, "FY2025": 120}, "cfo": {"FY2024": 90, "FY2025": 50}}
    assert piotroski_f(data(worse), "FY2025", "FY2024").value == 6  # new shares, and cash below profit


def test_beneish_and_missing_inputs():
    m = beneish_m(data(BASE), "FY2025", "FY2024")
    assert m.value is not None and m.zone == "no flag"
    sales_growth = 1300 / 1200
    assert m.components["SGI sales growth index"] == pytest.approx(sales_growth)
    assert m.components["TATA total accruals / total assets"] == pytest.approx((75 - 110) / 1100)
    partial = beneish_m(data({"revenue": BASE["revenue"]}), "FY2025", "FY2024")
    assert partial.value is None and partial.missing


def test_red_flags():
    risky = {
        **BASE,
        "receivables": {"FY2024": 200, "FY2025": 320},  # +60% vs revenue +8%
        "ebitda": {"FY2024": 150, "FY2025": 110},
        "net_income": {"FY2023": 50, "FY2024": 60, "FY2025": 75},
        "cfo": {"FY2023": 20, "FY2024": 30, "FY2025": 110},
        "goodwill": {"FY2025": 600},
        "interest_expense": {"FY2025": -50},
    }
    flags = {f.id: f for f in red_flags(data(risky), ["FY2023", "FY2024", "FY2025"])}
    assert flags["receivables_vs_revenue"].severity == "high"
    assert flags["margin_erosion"].period == "FY2025"
    assert flags["cash_conversion"].metric == 2
    assert flags["goodwill_vs_equity"].metric == pytest.approx(600 / 460)
    assert flags["weak_interest_cover"].metric == pytest.approx(110 / 50)
    assert "inventory_vs_revenue" not in flags
    assert red_flags(data(BASE), ["FY2024", "FY2025"]) == []


def test_adjusted_metrics():
    adjustments = [
        Adjustment(
            id="a1", period_key="FY2025", label="Restructuring", category="restructuring", amount=-20, confirmed=True
        ),
        Adjustment(
            id="a2", period_key="FY2025", label="Goodwill impairment", category="impairment", amount=-40, confirmed=True
        ),
        Adjustment(
            id="a3", period_key="FY2025", label="Gain on disposal", category="disposal_gain", amount=15, confirmed=True
        ),
        Adjustment(id="a4", period_key="FY2025", label="Suggested", amount=-99, confirmed=False, source="ai_suggested"),
    ]
    m = adjusted_metrics(data(BASE), "FY2025", adjustments)
    assert m.adjusted_ebitda == pytest.approx(175 + 20 - 15)
    assert m.adjusted_ebit == pytest.approx(120 + 20 + 40 - 15)
    assert len(m.items) == 3  # the unconfirmed suggestion is ignored


def test_adjusted_data_and_market_cap():
    from dealscout_engine.scores import Adjustment, adjusted_data, market_capitalisation

    d = data({"ebitda": {"FY2025": 100.0}, "ebit": {"FY2025": 60.0}, "share_price": {"FY2025": 4.0}})
    items = [
        Adjustment(
            id="a", period_key="FY2025", label="Restructuring", category="restructuring", amount=-10, confirmed=True
        ),
        Adjustment(id="b", period_key="FY2025", label="Impairment", category="impairment", amount=-5, confirmed=True),
        Adjustment(id="c", period_key="FY2025", label="Unconfirmed", amount=-50, source="ai_suggested"),
    ]
    adj = adjusted_data(d, items)
    assert adj.get("ebitda", "FY2025") == 110.0  # the impairment sits below EBITDA
    assert adj.get("ebit", "FY2025") == 75.0
    assert d.get("ebitda", "FY2025") == 100.0  # the reported data is untouched
    assert market_capitalisation(d, "FY2025", shares=25.0) == 100.0
    assert market_capitalisation(d, "FY2025") is None  # no share count
