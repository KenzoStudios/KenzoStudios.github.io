from __future__ import annotations

import pytest

from dealscout_engine.recommendation import PremiumRange, data_quality, recommend, suitability
from dealscout_engine.valuation.bridge import BridgeInputs
from dealscout_engine.valuation.summary import MethodRange, football_field


def by_id(items):
    return {s.method_id: s for s in items}


def test_suitability_by_profile():
    bank = by_id(suitability("financial", perspective="strategic", loss_making=False, listed=True))
    assert bank["ptbv"].relevance == "primary" and bank["dcf"].relevance == "not_suitable" and bank["dcf"].weight == 0
    assert bank["dcf"].reason
    mature = by_id(suitability("mature", perspective="financial_sponsor", loss_making=False, listed=False))
    assert mature["lbo"].relevance == "primary" and mature["comps_pe"].relevance == "secondary"
    loss = by_id(suitability("growth_tech", perspective="strategic", loss_making=True, listed=True))
    assert loss["comps_ev_ebitda"].relevance == "not_suitable" and loss["comps_ev_revenue"].weight == 1.0
    assert loss["strategic"].weight == 0


def test_recommendation_checks_and_implied_multiples():
    methods = [
        MethodRange(method_id="dcf", label="DCF", equity_low=800, equity_mid=1000, equity_high=1200, weight=1),
        MethodRange(method_id="lbo", label="LBO", equity_low=700, equity_mid=900, equity_high=1100, weight=1),
    ]
    ff = football_field(methods)
    bridge = BridgeInputs(gross_debt=300, cash=100)
    r = recommend(
        ff,
        bridge=bridge,
        revenue=2000,
        ebitda=150,
        net_income=60,
        market_cap=700,
        premium_range=PremiumRange(low=0.2, high=0.4),
        lbo_max_equity=900,
        lbo_target_irr=0.2,
        standalone_equity=700,
        synergy_value=400,
    )
    assert r is not None
    assert (r.equity_low, r.equity_mid, r.equity_high) == (750, 950, 1150)
    assert r.ev_mid == 1150 and r.implied["EV / EBITDA"][1] == pytest.approx(1150 / 150)
    assert r.premium_to_market[1] == pytest.approx(950 / 700 - 1)
    status = {c.label: c.status for c in r.checks}
    assert status["Control premium"] == "pass"  # +35.7% is inside 20–40%
    assert status["LBO affordability"] == "warn" and r.synergy_paid_away == pytest.approx(250 / 400)
    assert status["Synergies paid away"] == "warn"
    assert r.high_end_method == "DCF"


def test_data_quality():
    good = data_quality(
        value_confidences=[1, 1, 0.95], assumption_sources=["user", "historical", "default"], missing_inputs=0
    )
    assert good.grade == "A" and good.score >= 85
    weak = data_quality(
        value_confidences=[0.5], assumption_sources=["default", "default", "convention"], missing_inputs=2
    )
    assert weak.grade == "D" and weak.notes
