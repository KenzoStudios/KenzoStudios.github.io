"""EV/EBITDAR, PEG, EV/ARR, P/NAV and the current-year / next-year bases (hand-verified figures)."""

from datetime import date

import pytest

from dealscout_engine.defaults import MarketDefaults
from dealscout_engine.quickscan import DealContext, Overrides, comps_target_metrics, run_quick_scan
from dealscout_engine.recommendation import suitability
from dealscout_engine.statements import FinancialData
from dealscout_engine.taxonomy import load_taxonomy
from dealscout_engine.valuation.bridge import BridgeInputs
from dealscout_engine.valuation.comps import Peer, implied_value, metric_field, multiple_stats

PERIODS = ["FY2023", "FY2024", "FY2025"]


def _entry(value):
    return {"value": value, "as_of": "2026-10-01", "source": "Test", "status": "verified"}


DEFAULTS = MarketDefaults(
    raw={
        "version": "test",
        "stale_after_days": 90,
        "risk_free_rates": {"EUR": _entry(0.03)},
        "equity_risk_premium": {"mature_market": _entry(0.05)},
        "country_risk_premia": {"DE": _entry(0.0)},
        "sector_unlevered_betas": {"industrials": _entry(0.9)},
        "sector_multiples": {
            "industrials": {"ev_ebitda": None, "as_of": None, "source": None, "status": "placeholder"}
        },
        "tax_rates": {"DE": _entry(0.30)},
    }
)
CTX = DealContext(
    country="DE",
    sector="industrials",
    reporting_currency="EUR",
    valuation_date=date(2026, 1, 15),
    last_fiscal_year_end=date(2025, 12, 31),
)


def minimum_viable() -> FinancialData:
    d = FinancialData(load_taxonomy())
    for p, rev, ebitda in [("FY2023", 800, 120), ("FY2024", 900, 140), ("FY2025", 1000, 160)]:
        d.set("revenue", p, rev)
        d.set("ebitda", p, ebitda)
        d.set("da_total", p, -0.04 * rev)
        d.set("capex", p, -0.05 * rev)
    d.set("lt_debt", "FY2025", 300)
    d.set("cash", "FY2025", 100)
    d.set("total_equity", "FY2025", 700)
    d.set("interest_expense", "FY2025", -15)
    d.set("shares_outstanding", "FY2025", 50)
    return d


def test_ev_ebitdar_adds_rent_back():
    # EV 1,000 / (EBITDA 80 + rent 20) = 10.0x; rent entered with either sign
    assert Peer(name="A", enterprise_value=1000, ebitda=80, rent_expense=20).multiple("ev_ebitdar") == pytest.approx(10)
    assert Peer(name="A", enterprise_value=1000, ebitda=80, rent_expense=-20).multiple("ev_ebitdar") == pytest.approx(
        10
    )
    assert Peer(name="B", enterprise_value=1000, ebitda=80).multiple("ev_ebitdar") is None


def test_peg_is_pe_over_growth_in_percent():
    # P/E = 600 / 30 = 20x; EPS growth 10% → PEG 20 / 10 = 2.0
    peer = Peer(name="A", market_cap=600, net_income=30, eps_growth=0.10)
    assert peer.multiple("pe") == pytest.approx(20)
    assert peer.multiple("peg") == pytest.approx(2.0)
    assert Peer(name="B", market_cap=600, net_income=30, eps_growth=0).multiple("peg") is None
    assert Peer(name="C", market_cap=600, net_income=30, eps_growth=-0.05).multiple("peg") is None
    assert Peer(name="D", market_cap=600, net_income=30).multiple("peg") is None


def test_ev_arr_and_p_nav():
    assert Peer(name="S", enterprise_value=1200, arr=150).multiple("ev_arr") == pytest.approx(8.0)
    assert Peer(name="R", market_cap=900, nav=1000).multiple("p_nav") == pytest.approx(0.9)
    assert Peer(name="R", market_cap=900, nav=-10).multiple("p_nav") is None


def test_forward_bases_use_cy_and_ny_figures():
    peer = Peer(
        name="A",
        enterprise_value=1000,
        market_cap=800,
        revenue=400,
        revenue_cy=500,
        revenue_ny=625,
        ebitda=100,
        ebitda_cy=125,
        net_income=40,
        net_income_ny=50,
        eps_growth=0.2,
        book_equity=400,
        rent_expense=25,
    )
    assert peer.multiple("ev_revenue") == pytest.approx(2.5)
    assert peer.multiple("ev_revenue", "cy") == pytest.approx(2.0)
    assert peer.multiple("ev_revenue", "ny") == pytest.approx(1.6)
    assert peer.multiple("ev_ebitda", "cy") == pytest.approx(8.0)
    assert peer.multiple("ev_ebitda", "ny") is None  # no next-year EBITDA entered
    # forward P/E 800 / 50 = 16x; forward PEG 16 / 20 = 0.8
    assert peer.multiple("pe", "ny") == pytest.approx(16)
    assert peer.multiple("peg", "ny") == pytest.approx(0.8)
    # point-in-time multiples are the same on every basis; EBITDAR has no forward figure
    assert peer.multiple("pb", "ny") == peer.multiple("pb") == pytest.approx(2.0)
    assert peer.multiple("ev_ebitdar") == pytest.approx(8.0)
    assert peer.multiple("ev_ebitdar", "cy") is None
    assert metric_field("ev_ebitdar", "cy") is None and metric_field("ev_ebit", "ny") == "ebit_ny"


def test_stats_on_a_basis_and_reason_when_no_forward_figure():
    group = [
        Peer(name=f"P{i}", enterprise_value=m * 100, ebitda=90, ebitda_cy=100, rent_expense=10)
        for i, m in enumerate([6, 8, 10, 12])
    ]
    cy = multiple_stats(group, "ev_ebitda", basis="cy")
    assert cy.basis == "cy" and (cy.p25, cy.median, cy.p75) == pytest.approx((7.5, 9.0, 10.5))
    ebitdar = multiple_stats(group, "ev_ebitdar", basis="cy")
    assert ebitdar.n == 0 and ebitdar.excluded["P0"] == "No current year figure for this multiple"
    assert multiple_stats(group, "ev_ebitdar").median == pytest.approx(9.0)


def test_peg_implied_value():
    # peer PEGs 1.5 / 2.0 / 2.5 (P/E 15, 20, 25 at 10% growth); target net income 50 growing 8%
    group = [
        Peer(name=f"P{i}", market_cap=pe * 10, net_income=10, eps_growth=0.10) for i, pe in enumerate([15, 20, 25])
    ]
    stats = multiple_stats(group, "peg")
    assert stats.median == pytest.approx(2.0)
    # implied P/E = 2.0 × 8 = 16x → equity 16 × 50 = 800
    iv = implied_value(stats, 50 * 0.08 * 100, BridgeInputs())
    assert iv.equity_mid == pytest.approx(800)
    assert iv.equity_low == pytest.approx(1.75 * 8 * 50)


def target_data() -> FinancialData:
    d = minimum_viable()
    d.set("lease_expense", "FY2025", -40)
    d.set("arr", "FY2025", 600)
    d.set("reported_nav", "FY2025", 900)
    d.set("net_income", "FY2025", 80)
    return d


def test_target_metrics_ltm_and_forward_from_the_dcf_projection():
    o = Overrides(revenue_growth=0.05, ebitda_margin=0.15, tax_rate=0.25)
    r = run_quick_scan(target_data(), PERIODS, CTX, DEFAULTS, o)
    assert r.dcf is not None
    ltm, _ = comps_target_metrics(target_data(), "FY2025", 160, r.dcf, "ltm", 0.1)
    assert ltm["ev_ebitdar"] == pytest.approx(200)  # 160 + 40
    assert ltm["peg"] == pytest.approx(800)  # 80 × 10% × 100
    assert ltm["ev_arr"] == 600 and ltm["p_nav"] == 900
    # projection year 1 = 1,000 × 1.05 = 1,050 revenue, 15% margin → 157.5 EBITDA; year 2 = 1,102.5 / 165.375
    cy, notes = comps_target_metrics(target_data(), "FY2025", 160, r.dcf, "cy", 0.1)
    assert cy["ev_revenue"] == pytest.approx(1050) and cy["ev_ebitda"] == pytest.approx(157.5)
    assert cy["pe"] is None and "net income" in notes["pe"]
    assert cy["pb"] == ltm["pb"] == 700 and cy["ev_arr"] == 600
    ny, _ = comps_target_metrics(target_data(), "FY2025", 160, r.dcf, "ny", 0.1)
    assert ny["ev_revenue"] == pytest.approx(1102.5) and ny["ev_ebitda"] == pytest.approx(165.375)
    no_dcf, notes = comps_target_metrics(target_data(), "FY2025", 160, None, "cy", None)
    assert no_dcf["ev_ebitda"] is None and "DCF" in notes["ev_ebitda"]


def test_forward_basis_feeds_the_football_field_with_cy_label():
    peers = [
        Peer(name=f"Peer {i}", enterprise_value=m * 100, ebitda=100, ebitda_cy=125, market_cap=m * 80)
        for i, m in enumerate([7.0, 8.0, 9.0, 10.0])
    ]
    o = Overrides(
        revenue_growth=0.05,
        ebitda_margin=0.15,
        tax_rate=0.25,
        comps_basis="cy",
        method_weights={"dcf": 1, "comps_ev_ebitda": 1},
    )
    r = run_quick_scan(minimum_viable(), PERIODS, CTX, DEFAULTS, o, peers)
    c = next(c for c in r.comps if c.multiple_id == "ev_ebitda")
    # peer CY multiples 5.6 / 6.4 / 7.2 / 8.0 → median 6.8x × target CY EBITDA 157.5
    assert c.multiple_mid == pytest.approx(6.8) and c.ev_mid == pytest.approx(6.8 * 157.5)
    bar = next(m for m in r.football_field.methods if m.method_id == "comps_ev_ebitda")
    assert bar.label == "Trading comps: EV / EBITDA (CY)"
    # the exit multiple stays on the LTM basis (median 8.5x)
    assert next(a for a in r.assumptions if a.key == "exit_multiple").value == pytest.approx(8.5)


def test_sector_multiples_only_in_football_field_with_weight():
    peers = [
        Peer(name=f"P{i}", enterprise_value=m * 100, ebitda=100, rent_expense=25, market_cap=m * 80)
        for i, m in enumerate([7.0, 8.0, 9.0, 10.0])
    ]
    base = {"revenue_growth": 0.05, "ebitda_margin": 0.15, "tax_rate": 0.25}
    r = run_quick_scan(target_data(), PERIODS, CTX, DEFAULTS, Overrides(**base), peers)
    assert any(c.multiple_id == "ev_ebitdar" for c in r.comps)  # computed …
    assert "comps_ev_ebitdar" not in {m.method_id for m in r.football_field.methods}  # … but not shown at weight 0
    weighted = Overrides(**base, method_weights={"comps_ev_ebitdar": 0.5})
    r = run_quick_scan(target_data(), PERIODS, CTX, DEFAULTS, weighted, peers)
    bar = next(m for m in r.football_field.methods if m.method_id == "comps_ev_ebitdar")
    # peer EV/EBITDAR 5.6 / 6.4 / 7.2 / 8.0 → median 6.8x × target EBITDAR 200
    assert bar.ev_mid == pytest.approx(6.8 * 200)


def by_id(items):
    return {s.method_id: s for s in items}


def test_suitability_for_sector_multiples():
    software = by_id(
        suitability("growth_tech", perspective="strategic", loss_making=False, listed=True, sector="software")
    )
    assert software["comps_ev_arr"].relevance == "secondary" and software["comps_ev_arr"].weight == 0.5
    assert software["comps_peg"].relevance == "reference" and software["comps_p_nav"].weight == 0
    property_co = by_id(suitability("asset_based", perspective="strategic", loss_making=False, listed=True))
    assert property_co["comps_p_nav"].relevance == "secondary" and property_co["comps_p_nav"].reason
    airline = by_id(
        suitability("cyclical", perspective="strategic", loss_making=False, listed=True, sector="transport")
    )
    assert airline["comps_ev_ebitdar"].weight == 0.5
    industrial = by_id(suitability("cyclical", perspective="strategic", loss_making=False, listed=True))
    assert all(industrial[m].weight == 0 for m in ("comps_ev_ebitdar", "comps_peg", "comps_ev_arr", "comps_p_nav"))
    loss = by_id(suitability("growth_tech", perspective="strategic", loss_making=True, listed=True, sector="software"))
    assert loss["comps_peg"].relevance == "not_suitable"
