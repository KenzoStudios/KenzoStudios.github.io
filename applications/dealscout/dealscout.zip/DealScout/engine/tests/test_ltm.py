import pytest

from dealscout_engine.ltm import compute_ltm, plan_ltm
from dealscout_engine.statements import FinancialData
from dealscout_engine.taxonomy import load_taxonomy


def test_plan_requires_all_three_periods():
    assert [p.key for p in plan_ltm(["FY2024", "FY2025", "H1-2025", "H1-2026"])] == ["LTM-H1-2026"]
    assert plan_ltm(["FY2025", "H1-2026"]) == []  # no prior-year half
    assert [p.key for p in plan_ltm(["FY2025", "9M-2025", "9M-2026"])] == ["LTM-9M-2026"]


def test_flows_and_balances():
    d = FinancialData(load_taxonomy())
    for concept, fy, h1_prev, h1 in [("revenue", 1000, 480, 560), ("capex", -100, -40, -55)]:
        d.set(concept, "FY2025", fy)
        d.set(concept, "H1-2025", h1_prev)
        d.set(concept, "H1-2026", h1)
    d.set("cash", "H1-2026", 77)
    d.set("cash", "FY2025", 90)
    (plan,) = plan_ltm(["FY2025", "H1-2025", "H1-2026"])
    ltm = compute_ltm(d, plan)
    assert ltm["revenue"][0] == pytest.approx(1080)
    assert ltm["capex"][0] == pytest.approx(-115)
    assert ltm["cash"][0] == 77  # latest balance, not a sum
    assert ltm["revenue"][1].formula == "H1-2026 + FY2025 − H1-2025"
    assert "net_income" not in ltm  # inputs missing → not computed, never guessed
