from datetime import date

import pytest

from dealscout_engine.defaults import MarketDefaults, deep_merge, is_stale
from dealscout_engine.quickscan import DealContext, Overrides, per_year, run_quick_scan
from dealscout_engine.statements import FinancialData
from dealscout_engine.taxonomy import load_taxonomy
from dealscout_engine.valuation.comps import Peer

DEFAULTS = MarketDefaults(
    raw={
        "version": "test",
        "stale_after_days": 90,
        "risk_free_rates": {
            "EUR": {"value": 0.03, "as_of": "2026-10-31", "source": "Test source", "status": "verified"}
        },
        "equity_risk_premium": {
            "mature_market": {"value": 0.05, "as_of": "2026-10-01", "source": "Test", "status": "verified"}
        },
        "country_risk_premia": {"DE": {"value": 0.0, "as_of": "2026-07-01", "source": "Test", "status": "verified"}},
        "sector_unlevered_betas": {
            "industrials": {"value": 0.9, "as_of": "2026-01-05", "source": "Test", "status": "verified"}
        },
        "sector_multiples": {
            "industrials": {"ev_ebitda": None, "as_of": None, "source": None, "status": "placeholder"}
        },
        "tax_rates": {"DE": {"value": 0.30, "as_of": "2026-01-01", "source": "Test", "status": "verified"}},
    }
)

CTX = DealContext(
    country="DE",
    sector="industrials",
    reporting_currency="EUR",
    valuation_date=date(2026, 1, 15),
    last_fiscal_year_end=date(2025, 12, 31),
)


def minimum_viable() -> FinancialData:
    """Quick Scan minimum input: revenue, EBITDA, D&A, capex, net debt pieces, shares."""
    d = FinancialData(load_taxonomy())
    for p, rev, ebitda in [("FY2023", 800, 120), ("FY2024", 900, 140), ("FY2025", 1000, 160)]:
        d.set("revenue", p, rev)
        d.set("ebitda", p, ebitda)
        d.set("da_total", p, -0.04 * rev)
        d.set("capex", p, -0.05 * rev)
    d.set("lt_debt", "FY2025", 300)
    d.set("cash", "FY2025", 100)
    d.set("total_equity", "FY2025", 700)
    d.set("interest_expense", "FY2025", -15)
    d.set("shares_outstanding", "FY2025", 50)
    return d


def test_quick_scan_from_minimum_input():
    r = run_quick_scan(minimum_viable(), ["FY2023", "FY2024", "FY2025"], CTX, DEFAULTS)
    sources = {a.key: a.source for a in r.assumptions}
    assert sources["risk_free_rate"] == "default" and sources["tax_rate"] == "default"
    assert sources["revenue_growth"] == "historical" and sources["ebitda_margin"] == "historical"
    assert sources["exit_multiple"] == "derived"  # sector multiple is a placeholder → implied by Gordon
    assert sources["nwc_pct_revenue"] == "convention"
    assert r.missing == []
    assert r.dcf is not None and r.dcf.enterprise_value > 0
    growth = next(a for a in r.assumptions if a.key == "revenue_growth").value
    assert growth[0] == pytest.approx((1000 / 800) ** 0.5 - 1)  # 2-year CAGR 11.8%
    assert growth[-1] == pytest.approx(0.02)  # fades to terminal growth (2% < rf 3% − 0.5%)
    assert r.dcf_range["equity_low"] < r.dcf_range["equity_mid"] < r.dcf_range["equity_high"]
    assert r.football_field.blended_per_share is not None
    # cost of debt implied from interest ÷ debt = 5%
    assert next(a for a in r.assumptions if a.key == "pre_tax_cost_of_debt").value == pytest.approx(0.05)
    # net debt bridge: EV − 300 + 100
    assert r.dcf.equity_value == pytest.approx(r.dcf.enterprise_value - 200)


def test_missing_inputs_block_dcf_and_are_listed():
    d = FinancialData(load_taxonomy())
    d.set("revenue", "FY2025", 1000)
    r = run_quick_scan(d, ["FY2025"], CTX.model_copy(update={"reporting_currency": "BRL"}), DEFAULTS)
    assert {"risk_free_rate", "ebitda_margin", "da_pct_revenue", "capex_pct_revenue", "pre_tax_cost_of_debt"} <= set(
        r.missing
    )
    assert r.dcf is None
    assert any("DCF not run" in w for w in r.warnings)


def test_overrides_win_and_comps_feed_the_football_field():
    peers = [
        Peer(name=f"Peer {i}", enterprise_value=m * 100, ebitda=100, market_cap=m * 80, net_income=40, revenue=700)
        for i, m in enumerate([7.0, 8.0, 9.0, 10.0])
    ]
    o = Overrides(
        revenue_growth=0.05, ebitda_margin=0.15, tax_rate=0.25, method_weights={"dcf": 1, "comps_ev_ebitda": 1}
    )
    r = run_quick_scan(minimum_viable(), ["FY2023", "FY2024", "FY2025"], CTX, DEFAULTS, o, peers)
    sources = {a.key: a.source for a in r.assumptions}
    assert sources["revenue_growth"] == sources["ebitda_margin"] == sources["tax_rate"] == "user"
    assert sources["exit_multiple"] == "derived"  # peer median 8.5x
    assert next(a for a in r.assumptions if a.key == "exit_multiple").value == pytest.approx(8.5)
    ev_ebitda = next(c for c in r.comps if c.multiple_id == "ev_ebitda")
    assert ev_ebitda.ev_mid == pytest.approx(8.5 * 160)
    ids = {m.method_id for m in r.football_field.methods}
    assert {"dcf", "comps_ev_ebitda"} <= ids


def test_defaults_helpers():
    assert is_stale("2026-01-01", 90, today=date(2026, 11, 19))
    assert not is_stale("2026-11-01", 90, today=date(2026, 11, 19))
    merged = deep_merge({"a": {"x": 1, "y": 2}}, {"a": {"y": 3}})
    assert merged == {"a": {"x": 1, "y": 3}}
    placeholder = DEFAULTS.lookup("sector_multiples", "industrials", field="ev_ebitda")
    assert not placeholder.usable
    assert DEFAULTS.lookup("risk_free_rates", "EUR", today=date(2026, 11, 19)).stale is False


def test_country_risk_not_double_counted_with_local_sovereign_rate():
    defaults = MarketDefaults(
        raw={
            **DEFAULTS.raw,
            "risk_free_rates": {
                **DEFAULTS.raw["risk_free_rates"],
                "BRL": {"value": 0.15, "as_of": "2026-11-18", "status": "verified"},
                "USD": {"value": 0.05, "as_of": "2026-11-18", "status": "verified"},
            },
            "country_risk_premia": {"BR": {"value": 0.03, "as_of": "2026-01-05", "status": "verified"}},
        }
    )
    brl = CTX.model_copy(update={"country": "BR", "reporting_currency": "BRL", "country_currency": "BRL"})
    r = run_quick_scan(minimum_viable(), ["FY2023", "FY2024", "FY2025"], brl, defaults)
    crp = next(a for a in r.assumptions if a.key == "country_risk_premium")
    assert crp.value == 0.0 and crp.source == "convention" and "count it twice" in crp.detail
    usd = brl.model_copy(update={"reporting_currency": "USD"})
    r = run_quick_scan(minimum_viable(), ["FY2023", "FY2024", "FY2025"], usd, defaults)
    assert next(a for a in r.assumptions if a.key == "country_risk_premium").value == 0.03


def test_per_year_driver_overrides_reach_the_projection():
    o = Overrides(
        projection_years=5,
        revenue_growth=[0.10, 0.08, 0.06],  # padded with its last value
        ebitda_margin=0.2,
        da_pct_revenue=[0.03, 0.03, 0.04, 0.04, 0.05],
        capex_pct_revenue=[0.06, 0.05],
        nwc_pct_revenue=[0.1, 0.11, 0.12, 0.13, 0.14, 0.15, 0.16],  # cut to the forecast years
    )
    r = run_quick_scan(minimum_viable(), ["FY2023", "FY2024", "FY2025"], CTX, DEFAULTS, o)
    assert r.dcf is not None and r.dcf_inputs is not None
    d = r.dcf_inputs.drivers
    assert d.revenue_growth == pytest.approx([0.10, 0.08, 0.06, 0.06, 0.06])
    assert d.da_pct_revenue == pytest.approx([0.03, 0.03, 0.04, 0.04, 0.05])
    assert d.capex_pct_revenue == pytest.approx([0.06, 0.05, 0.05, 0.05, 0.05])
    assert d.nwc_pct_revenue == pytest.approx([0.1, 0.11, 0.12, 0.13, 0.14])
    proj = r.dcf.projection
    assert proj[4].da == pytest.approx(proj[4].revenue * 0.05)
    sources = {a.key: (a.source, a.value) for a in r.assumptions}
    assert sources["capex_pct_revenue"] == ("user", pytest.approx([0.06, 0.05, 0.05, 0.05, 0.05]))
    # a single value still applies to every year
    flat = run_quick_scan(
        minimum_viable(), ["FY2023", "FY2024", "FY2025"], CTX, DEFAULTS, Overrides(capex_pct_revenue=0.05)
    )
    assert flat.dcf_inputs is not None and flat.dcf_inputs.drivers.capex_pct_revenue == pytest.approx([0.05] * 5)


def test_per_year_helper():
    assert per_year(0.1, 3) == [0.1, 0.1, 0.1]
    assert per_year([0.1, 0.2], 3) == [0.1, 0.2, 0.2]
    with pytest.raises(ValueError):
        per_year([], 3)
