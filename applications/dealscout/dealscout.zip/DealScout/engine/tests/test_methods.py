"""Precedents, NAV/SOTP, financial-institution methods and strategic analysis: hand-checked cases."""

from __future__ import annotations

from datetime import date

import numpy as np
import pytest

from dealscout_engine.valuation.bridge import BridgeInputs
from dealscout_engine.valuation.fi import (
    APVInputs,
    DDMInputs,
    FCFEInputs,
    ResidualIncomeInputs,
    price_to_tangible_book,
    run_apv,
    run_ddm,
    run_fcfe,
    run_residual_income,
)
from dealscout_engine.valuation.nav import NAVInputs, NAVLine, Segment, SOTPInputs, run_nav, run_sotp
from dealscout_engine.valuation.precedents import (
    PrecedentFilters,
    Transaction,
    precedent_stats,
    precedent_value,
    weighted_percentile,
)
from dealscout_engine.valuation.strategic import (
    DLOM,
    AccretionInputs,
    LiquidationInputs,
    RecoveryLine,
    ReplacementLine,
    SynergyInputs,
    replacement_value,
    run_accretion,
    run_liquidation,
    run_synergies,
)

AS_OF = date(2026, 11, 20)


def deal(name: str, year: int, multiple: float, **kw) -> Transaction:
    return Transaction(announced=date(year, 6, 1), target=name, ev=multiple * 100, ebitda=100, **kw)


def test_weighted_percentile_matches_numpy_with_equal_weights():
    values = [8.0, 10.0, 12.0, 15.0, 9.5]
    for q in (0.25, 0.5, 0.75):
        assert weighted_percentile(values, [1] * 5, q) == pytest.approx(np.percentile(values, q * 100))


def test_precedents_filters_weights_and_value():
    deals = [
        deal("Alpha", 2026, 8, country="DE", premium_paid=0.30),
        deal("Beta", 2023, 10, country="FR", premium_paid=0.25),
        deal("Gamma", 2020, 12, country="DE"),
        deal("Old", 2012, 20, country="DE"),
        Transaction(announced=date(2025, 1, 1), target="Reported", ev_ebitda=11.0),
    ]
    equal = precedent_stats(deals[:3], "ev_ebitda", as_of=AS_OF)
    assert (equal.p25, equal.median, equal.p75) == pytest.approx((9, 10, 11))
    assert equal.median_premium == pytest.approx(0.275)
    filtered = precedent_stats(
        deals, "ev_ebitda", PrecedentFilters(since=date(2015, 1, 1), countries=["de"]), as_of=AS_OF
    )
    assert set(filtered.values) == {"Alpha (2026)", "Gamma (2020)"} and "Old (2012)" in filtered.excluded
    weighted = precedent_stats(deals[:3], "ev_ebitda", PrecedentFilters(half_life_years=3), as_of=AS_OF)
    assert weighted.weights["Alpha (2026)"] > weighted.weights["Beta (2023)"] > weighted.weights["Gamma (2020)"]
    assert weighted.median < equal.median  # recent cheaper deals pull the median down
    assert precedent_stats(deals, "ev_ebitda", as_of=AS_OF).values["Reported (2025)"] == 11.0
    value = precedent_value(equal, 100.0, BridgeInputs(gross_debt=250, cash=50))
    assert (value.ev_low, value.ev_mid, value.ev_high) == pytest.approx((900, 1000, 1100))
    assert (value.equity_low, value.equity_high) == pytest.approx((700, 900))
    assert "control premium" in value.note


def test_nav_with_revaluation_tax_and_discount():
    result = run_nav(
        NAVInputs(
            lines=[
                NAVLine(name="Logistics park", book_value=700, method="cap_rate", noi=50, cap_rate=0.05),
                NAVLine(name="Stake in JV", book_value=150, method="transaction", fair_value=200),
                NAVLine(name="Borrowings", side="liability", book_value=400),
            ],
            tax_rate=0.25,
            holding_discount=0.10,
            shares=10,
            share_price=50,
        )
    )
    assert result.book_nav == pytest.approx(450) and result.revaluation_gain == pytest.approx(350)
    assert result.deferred_tax == pytest.approx(87.5)
    assert result.nav == pytest.approx(712.5 * 0.9)
    assert result.nav_per_share == pytest.approx(64.125)
    assert result.premium_to_nav == pytest.approx(50 / 64.125 - 1)
    with pytest.raises(ValueError, match="cap rate"):
        run_nav(NAVInputs(lines=[NAVLine(name="X", method="cap_rate", noi=10)]))


def test_sotp():
    result = run_sotp(
        SOTPInputs(
            segments=[
                Segment(name="Industrial", metric=100, multiple_low=6, multiple_mid=7, multiple_high=8),
                Segment(name="Software", value=300),
            ],
            corporate_costs=10,
            corporate_cost_multiple=5,
            non_core_assets=40,
            conglomerate_discount=0.10,
            bridge=BridgeInputs(gross_debt=100),
        )
    )
    assert result.ev_before_discount == pytest.approx((890, 990, 1090))
    assert result.ev == pytest.approx((801, 891, 981))
    assert result.equity == pytest.approx((701, 791, 881))


def test_ddm_residual_income_fcfe_apv_ptbv():
    ddm = run_ddm(DDMInputs(current_dividend=10, high_growth=0.10, years=2, terminal_growth=0.03, cost_of_equity=0.09))
    expected = 11 / 1.09 + 12.1 / 1.09**2 + (12.1 * 1.03 / 0.06) / 1.09**2
    assert ddm.value == pytest.approx(expected)
    ri = run_residual_income(
        ResidualIncomeInputs(book_value=100, roe=[0.12, 0.12], payout_ratio=0.5, cost_of_equity=0.10)
    )
    assert ri.rows[1]["opening_book"] == pytest.approx(106)
    assert ri.value == pytest.approx(100 + 2 / 1.1 + 2.12 / 1.21 + (2.12 / 0.10) / 1.21)
    fcfe = run_fcfe(
        FCFEInputs(
            net_income=[10],
            da=[2],
            capex=[3],
            change_in_nwc=[1],
            net_borrowing=[2],
            cost_of_equity=0.10,
            terminal_growth=0.0,
        )
    )
    assert fcfe.value == pytest.approx(100.0)
    apv = run_apv(
        APVInputs(
            unlevered_fcf=[100, 100],
            unlevered_cost_of_equity=0.10,
            terminal_growth=0.0,
            debt_balances=[500, 500],
            cost_of_debt=0.05,
            tax_rate=0.25,
        )
    )
    assert apv.unlevered_value == pytest.approx(1000.0)
    assert apv.pv_tax_shields == pytest.approx(125.0)  # permanent debt: D × t (Modigliani–Miller)
    assert price_to_tangible_book(1000, 150, 50, 1.2) == pytest.approx(960)
    with pytest.raises(ValueError):
        run_ddm(DDMInputs(current_dividend=1, high_growth=0, years=1, terminal_growth=0.10, cost_of_equity=0.08))


def test_synergies_accretion_liquidation_replacement_dlom():
    syn = run_synergies(
        SynergyInputs(
            cost_synergies=100,
            phasing=[0.5, 1.0],
            integration_costs=[50],
            tax_rate=0.25,
            discount_rate=0.10,
            probability=0.8,
            share_paid_away=0.5,
        )
    )
    assert syn.rows[0]["after_tax"] == pytest.approx(0.0)
    assert syn.value_before_probability == pytest.approx(75 / 1.21 + 750 / 1.21)
    assert syn.value == pytest.approx(syn.value_before_probability * 0.8)
    assert syn.paid_away == pytest.approx(syn.value / 2)
    acc = run_accretion(
        AccretionInputs(
            acquirer_net_income=100,
            acquirer_shares=100,
            acquirer_share_price=20,
            target_net_income=20,
            purchase_equity_value=200,
            stock_share=0.5,
            debt_share=0.5,
            interest_on_new_debt=0.06,
            tax_rate=0.25,
        )
    )
    assert acc.new_shares == pytest.approx(5) and acc.pro_forma_eps == pytest.approx(1.1)
    assert acc.accretion == pytest.approx(0.10)
    assert acc.breakeven_synergies == pytest.approx(-14.0)
    with pytest.raises(ValueError, match="100%"):
        AccretionInputs(
            acquirer_net_income=1,
            acquirer_shares=1,
            acquirer_share_price=1,
            target_net_income=1,
            purchase_equity_value=1,
            cash_share=0.5,
            tax_rate=0.2,
        )
    liq = run_liquidation(
        LiquidationInputs(
            assets=[
                RecoveryLine(name="Receivables", book_value=100, recovery_low=0.5, recovery_high=0.8),
                RecoveryLine(name="Plant", book_value=200, recovery_low=0.2, recovery_high=0.3),
            ],
            liabilities=120,
            wind_down_costs=10,
        )
    )
    assert (liq.proceeds_low, liq.proceeds_high) == pytest.approx((90, 140))
    assert (liq.equity_low, liq.equity_high) == pytest.approx((0, 10))
    assert replacement_value(
        [ReplacementLine(name="Plant", replacement_cost=1000, physical_obsolescence=0.2, functional_obsolescence=0.1)]
    ) == pytest.approx(720)
    d = DLOM(low=0.2, mid=0.3, high=0.4)
    assert (d.apply(100, "low"), d.apply(100, "mid"), d.apply(100, "high")) == pytest.approx((60, 70, 80))


def test_m5_helpers():
    from dealscout_engine.valuation.bridge import BridgeInputs
    from dealscout_engine.valuation.fi import unlevered_cost_of_equity
    from dealscout_engine.valuation.lbo import entry_ev_from_price
    from dealscout_engine.valuation.strategic import (
        DLOM,
        apply_dlom,
        market_reference_points,
        run_rate_synergy_ebitda,
        strategic_value,
    )
    from dealscout_engine.valuation.summary import MethodRange

    assert run_rate_synergy_ebitda(10, 100, 0.2) == 30
    assert strategic_value((100, 120, 140), 25) == (125, 145, 165)
    assert unlevered_cost_of_equity(0.10, 0.05, 0.3) == pytest.approx(0.085)
    assert entry_ev_from_price(10, 5, BridgeInputs(gross_debt=20, cash=5)) == pytest.approx(65)

    comps = MethodRange(method_id="comps_ev_ebitda", label="Comps", equity_low=80, equity_mid=100, equity_high=120)
    dcf = MethodRange(method_id="dcf", label="DCF", equity_low=90, equity_mid=100, equity_high=110)
    out = apply_dlom([comps, dcf], DLOM(low=0.1, mid=0.2, high=0.3))
    assert (out[0].equity_low, out[0].equity_mid, out[0].equity_high) == pytest.approx((56, 80, 108))
    assert out[1] == dcf  # market methods only by default
    every = apply_dlom([dcf], DLOM(low=0.1, mid=0.2, high=0.3, applies_to="all_methods"))
    assert every[0].equity_mid == pytest.approx(80)

    points = market_reference_points(
        10, high_52w=12, low_52w=8, vwap={"VWAP 30 days": None}, analyst_targets=[9, 11, 15, 10]
    )
    assert [(p.label, p.equity) for p in points] == [
        ("52-week high", 120),
        ("52-week low", 80),
        ("Median analyst target", 105),
    ]
    assert market_reference_points(None, high_52w=12) == []


def test_precedents_with_same_target_and_year_are_all_kept():
    from datetime import date as _date

    from dealscout_engine.valuation.precedents import Transaction, precedent_stats

    deals = [
        Transaction(announced=_date(2024, 6, 1), target=t, ev=m * 100, ebitda=100)
        for t, m in (("", 6), ("", 9), ("", 12), ("Acme", 7), ("Acme", 8))
    ]
    stats = precedent_stats(deals, "ev_ebitda", as_of=_date(2026, 1, 1))
    assert stats.n == 5
    assert sorted(stats.values.values()) == [6, 7, 8, 9, 12]
    assert "Unnamed target (2024) #2" in stats.values and "Acme (2024) #2" in stats.values
