"""Safe evaluation of the small arithmetic formulas used in the taxonomy (e.g. ``ebit - da_total``).

Only names, numeric literals, + - * / and parentheses are allowed. Anything else raises ``FormulaError``.
"""

from __future__ import annotations

import ast
from collections.abc import Callable, Mapping

_ALLOWED_BINOPS: dict[type[ast.operator], Callable[[float, float], float]] = {
    ast.Add: lambda a, b: a + b,
    ast.Sub: lambda a, b: a - b,
    ast.Mult: lambda a, b: a * b,
    ast.Div: lambda a, b: a / b,
}


class FormulaError(ValueError):
    """Raised for a formula that cannot be parsed or uses disallowed syntax."""


def _parse(formula: str) -> ast.expr:
    try:
        tree = ast.parse(formula, mode="eval")
    except SyntaxError as exc:  # pragma: no cover - message passthrough
        raise FormulaError(f"Cannot parse formula {formula!r}: {exc.msg}") from exc
    _check(tree.body, formula)
    return tree.body


def _check(node: ast.AST, formula: str) -> None:
    if isinstance(node, ast.BinOp):
        if type(node.op) not in _ALLOWED_BINOPS:
            raise FormulaError(f"Operator not allowed in {formula!r}")
        _check(node.left, formula)
        _check(node.right, formula)
    elif isinstance(node, ast.UnaryOp):
        if not isinstance(node.op, ast.USub | ast.UAdd):
            raise FormulaError(f"Unary operator not allowed in {formula!r}")
        _check(node.operand, formula)
    elif isinstance(node, ast.Name):
        return
    elif isinstance(node, ast.Constant):
        if not isinstance(node.value, int | float) or isinstance(node.value, bool):
            raise FormulaError(f"Only numeric constants allowed in {formula!r}")
    else:
        raise FormulaError(f"Unsupported syntax {type(node).__name__} in {formula!r}")


def formula_names(formula: str) -> list[str]:
    """Return the variable names referenced by ``formula`` in order of first appearance."""
    seen: list[str] = []
    for node in ast.walk(_parse(formula)):
        if isinstance(node, ast.Name) and node.id not in seen:
            seen.append(node.id)
    return seen


def evaluate(formula: str, values: Mapping[str, float]) -> float:
    """Evaluate ``formula`` with ``values``; raises ``KeyError`` for a missing input."""

    def _eval(node: ast.expr) -> float:
        if isinstance(node, ast.BinOp):
            return _ALLOWED_BINOPS[type(node.op)](_eval(node.left), _eval(node.right))
        if isinstance(node, ast.UnaryOp):
            operand = _eval(node.operand)
            return -operand if isinstance(node.op, ast.USub) else operand
        if isinstance(node, ast.Name):
            return float(values[node.id])
        if isinstance(node, ast.Constant) and isinstance(node.value, int | float):
            return float(node.value)
        raise FormulaError("unreachable")  # pragma: no cover

    return _eval(_parse(formula))
