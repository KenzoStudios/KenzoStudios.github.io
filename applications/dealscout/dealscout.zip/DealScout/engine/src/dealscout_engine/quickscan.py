"""Quick Scan: from historical financials + overrides + sourced defaults to a valuation range (brief §4, §12).

Every assumption is resolved in this order and labelled with where it came from:
    user override  →  company history  →  sourced market default  →  stated convention
If an assumption has none of these, it is reported in ``missing`` and the valuation that needs it is not run.
Nothing is guessed silently.
"""

from __future__ import annotations

from datetime import date
from typing import Any, Literal

from pydantic import BaseModel, Field

from .defaults import MarketDefaults
from .ratios import cagr, effective_tax_rate, total_debt
from .statements import FinancialData
from .valuation.bridge import BridgeInputs, DilutionInputs, OptionTranche
from .valuation.comps import MULTIPLES, ImpliedValue, Peer, implied_value, multiple_stats
from .valuation.dcf import DCFInputs, DCFResult, ProjectionDrivers, run_dcf, sensitivity_wacc_growth
from .valuation.summary import FootballField, MethodRange, football_field
from .valuation.wacc import WACCInputs, WACCResult, compute_wacc

Source = Literal["user", "historical", "default", "convention", "derived", "missing"]

# Stated conventions (not market data): shown to the user as conventions and editable.
CONVENTION_TERMINAL_GROWTH = 0.02
CONVENTION_DCF_WACC_STEP = 0.01
CONVENTION_DCF_GROWTH_STEP = 0.005
CONVENTION_GROWTH_BOUNDS = (-0.10, 0.25)


class ResolvedAssumption(BaseModel):
    key: str
    label: str
    value: float | list[float] | None
    source: Source
    detail: str | None = None
    as_of: str | None = None
    stale: bool = False


class DealContext(BaseModel):
    country: str
    sector: str
    reporting_currency: str
    listed: bool = False
    valuation_date: date
    last_fiscal_year_end: date
    country_currency: str | None = None  # the country's own currency (to detect local-currency risk-free rates)


class Overrides(BaseModel):
    """User-set assumptions. Any field left as None is resolved from history, defaults or convention."""

    projection_years: int | None = Field(default=None, ge=3, le=15)
    revenue_growth: list[float] | float | None = None
    ebitda_margin: list[float] | float | None = None
    # a single value holds for every projection year; a list sets each year (Detailed mode), padded with its last
    da_pct_revenue: list[float] | float | None = None
    capex_pct_revenue: list[float] | float | None = None
    nwc_pct_revenue: list[float] | float | None = None
    tax_rate: float | None = None
    nol_opening: float | None = None
    risk_free_rate: float | None = None
    equity_risk_premium: float | None = None
    country_risk_premium: float | None = None
    unlevered_beta: float | None = None
    levered_beta: float | None = None
    size_premium: float | None = None
    company_specific_premium: float | None = None
    pre_tax_cost_of_debt: float | None = None
    target_debt_to_capital: float | None = Field(default=None, ge=0, lt=1)
    terminal_growth: float | None = None
    exit_multiple: float | None = None
    terminal_method: Literal["gordon", "exit_multiple", "average"] | None = None
    mid_year: bool | None = None
    include_leases: bool | None = None
    include_pensions: bool | None = None
    include_provisions: bool | None = None
    minimum_operating_cash: float | None = None
    basic_shares: float | None = None
    options: list[OptionTranche] = []
    share_price: float | None = None
    exclude_peer_outliers: bool = False
    method_weights: dict[str, float] = {}
    comps_basis: Literal["ltm", "cy", "ny"] = "ltm"  # trading comps: last reported, current year or next year
    target_eps_growth: float | None = Field(default=None, gt=-1, le=5)  # for PEG: expected EPS growth a year


class QuickScanResult(BaseModel):
    assumptions: list[ResolvedAssumption]
    missing: list[str]
    wacc: WACCResult | None
    dcf_inputs: DCFInputs | None = None
    dcf: DCFResult | None
    dcf_range: dict[str, float] | None
    comps: list[ImpliedValue]
    football_field: FootballField | None
    market_cap: float | None
    warnings: list[str]
    # context reused by the other valuation methods (LBO, precedents, NAV …)
    base_period: str | None = None
    base_revenue: float | None = None
    base_ebitda: float | None = None
    bridge: BridgeInputs | None = None
    dilution: DilutionInputs | None = None
    share_price: float | None = None
    tax_rate: float | None = None


def _avg(values: list[float | None]) -> float | None:
    clean = [v for v in values if v is not None]
    return sum(clean) / len(clean) if clean else None


def _ratio_series(
    data: FinancialData, periods: list[str], numerator: str, *, negate: bool = False
) -> list[float | None]:
    out: list[float | None] = []
    for p in periods:
        num, rev = data.get(numerator, p), data.get("revenue", p)
        if num is None or rev is None or rev == 0:
            out.append(None)
        else:
            out.append((-num if negate else num) / rev)
    return out


def _fade(start: float, end: float, years: int) -> list[float]:
    """Linear fade from the starting growth rate to the terminal rate in the final projection year."""
    if years == 1:
        return [end]
    return [start + (end - start) * t / (years - 1) for t in range(years)]


SECTOR_MULTIPLES = frozenset({"ev_ebitdar", "peg", "ev_arr", "p_nav"})


def comps_target_metrics(
    data: FinancialData,
    base: str | None,
    base_ebitda: float | None,
    dcf: DCFResult | None,
    basis: str,
    eps_growth: float | None,
) -> tuple[dict[str, float | None], dict[str, str]]:
    """The target's denominator for each applied multiple on a basis, with a note when one cannot be found.

    LTM uses the last reported period. Current year (CY) and next year (NY) use years 1 and 2 of the DCF projection
    for revenue, EBITDA and EBIT; the projection has no net income, so P / E and PEG are LTM only for the target.
    Point-in-time figures (book equity, ARR, NAV) are the same on every basis.
    """

    def get(concept: str) -> float | None:
        return data.get(concept, base) if base else None

    notes: dict[str, str] = {}
    net_income = get("net_income_to_shareholders") or get("net_income")
    lease = get("lease_expense")
    targets: dict[str, float | None] = {
        "ev_revenue": data.get("revenue", base) if base else None,
        "ev_ebitda": base_ebitda,
        "ev_ebit": get("ebit"),
        "pe": net_income,
        "pb": get("total_equity"),
        "ev_ebitdar": base_ebitda + abs(lease) if base_ebitda is not None and lease is not None else None,
        "peg": net_income * eps_growth * 100 if net_income is not None and eps_growth is not None else None,
        "ev_arr": get("arr"),
        "p_nav": get("reported_nav"),
    }
    notes["ev_ebitdar"] = "Enter the target's rent / lease expense to apply EV / EBITDAR."
    notes["peg"] = "Enter the target's expected EPS growth (trading comparables) to apply PEG."
    notes["ev_arr"] = "Enter the target's ARR (sector KPIs) to apply EV / ARR."
    notes["p_nav"] = "Enter the target's reported NAV to apply P / NAV."
    if basis in ("cy", "ny"):
        year = 0 if basis == "cy" else 1
        row = dcf.projection[year] if dcf is not None and len(dcf.projection) > year else None
        label = "current-year" if basis == "cy" else "next-year"
        for multiple_id, attr in (("ev_revenue", "revenue"), ("ev_ebitda", "ebitda"), ("ev_ebit", "ebit")):
            targets[multiple_id] = getattr(row, attr) if row is not None else None
            notes[multiple_id] = f"No {label} figure: complete the DCF projection or use the LTM basis."
        for multiple_id in ("pe", "peg"):
            targets[multiple_id] = None
            notes[multiple_id] = f"The DCF projection has no {label} net income; use the LTM basis for this multiple."
        targets["ev_ebitdar"] = None
    return targets, notes


def per_year(value: list[float] | float, years: int) -> list[float]:
    """One value per projection year: a single value repeats; a list is cut or padded with its last value."""
    if isinstance(value, list):
        if not value:
            raise ValueError("a per-year driver list needs at least one value")
        return ([float(v) for v in value] + [float(value[-1])] * years)[:years]
    return [float(value)] * years


def run_quick_scan(
    data: FinancialData,
    periods: list[str],
    ctx: DealContext,
    defaults: MarketDefaults,
    overrides: Overrides | None = None,
    peers: list[Peer] | None = None,
    *,
    today: date | None = None,
) -> QuickScanResult:
    """``periods`` are the historical annual period ids in chronological order (the last one is the base year)."""
    o = overrides or Overrides()
    peers = peers or []
    resolved: list[ResolvedAssumption] = []
    missing: list[str] = []
    warnings: list[str] = []
    base = periods[-1] if periods else None

    def record(
        key: str,
        label: str,
        value: Any,
        source: Source,
        detail: str | None = None,
        as_of: str | None = None,
        stale: bool = False,
    ) -> Any:
        resolved.append(
            ResolvedAssumption(
                key=key, label=label, value=value, source=source, detail=detail, as_of=as_of, stale=stale
            )
        )
        if source == "missing":
            missing.append(key)
        return value

    def from_default(key: str, label: str, *path: str, field: str = "value") -> float | None:
        d = defaults.lookup(*path, field=field, today=today)
        if d.usable:
            return record(key, label, d.value, "default", f"{d.source} ({d.path})", d.as_of, d.stale)
        return None

    # ── base year figures ───────────────────────────────────────────────
    base_revenue = data.get("revenue", base) if base else None
    if base_revenue is None or base_revenue <= 0:
        record("base_revenue", "Base-year revenue", None, "missing", "Enter revenue for the latest full year.")
    else:
        record("base_revenue", "Base-year revenue", base_revenue, "historical", f"Revenue {base}")
    base_ebitda = data.get("ebitda", base) if base else None

    years = o.projection_years or 5
    record(
        "projection_years",
        "Explicit forecast years",
        years,
        "user" if o.projection_years else "convention",
        None if o.projection_years else "5 years (standard; 3–15 allowed)",
    )

    # ── discount-rate inputs ────────────────────────────────────────────
    currency = ctx.reporting_currency
    rf = o.risk_free_rate if o.risk_free_rate is not None else None
    if rf is not None:
        record("risk_free_rate", "Risk-free rate", rf, "user")
    else:
        rf = from_default("risk_free_rate", "Risk-free rate", "risk_free_rates", currency)
        if rf is None:
            record(
                "risk_free_rate",
                "Risk-free rate",
                None,
                "missing",
                f"No sourced 10-year government yield for {currency}; enter one.",
            )

    erp = o.equity_risk_premium
    if erp is not None:
        record("equity_risk_premium", "Equity risk premium", erp, "user")
    else:
        erp = from_default("equity_risk_premium", "Equity risk premium", "equity_risk_premium", "mature_market")
        if erp is None:
            record("equity_risk_premium", "Equity risk premium", None, "missing", "Enter the equity risk premium.")

    crp = o.country_risk_premium
    local_sovereign_rf = (
        currency != "EUR" and ctx.country_currency == currency and o.risk_free_rate is None and rf is not None
    )
    if crp is not None:
        record("country_risk_premium", "Country risk premium", crp, "user")
    elif local_sovereign_rf and (defaults.lookup("country_risk_premia", ctx.country).value or 0.0) > 0:
        crp = record(
            "country_risk_premium",
            "Country risk premium",
            0.0,
            "convention",
            f"Not added: the {currency} risk-free rate is {ctx.country}'s own government yield, which already "
            "prices its default risk (adding a premium would count it twice). Enter one if you use a "
            "default-free rate instead.",
        )
    else:
        crp = from_default("country_risk_premium", "Country risk premium", "country_risk_premia", ctx.country)
        if crp is None:
            crp = record(
                "country_risk_premium",
                "Country risk premium",
                0.0,
                "convention",
                f"No sourced premium for {ctx.country}; 0% assumed; review it.",
            )

    beta_mode: Literal["levered_input", "unlevered_input"] = "unlevered_input"
    unlevered = o.unlevered_beta
    if o.levered_beta is not None:
        beta_mode = "levered_input"
        record("levered_beta", "Levered beta", o.levered_beta, "user")
    elif unlevered is not None:
        record("unlevered_beta", "Unlevered beta", unlevered, "user")
    else:
        unlevered = from_default("unlevered_beta", "Unlevered beta (sector)", "sector_unlevered_betas", ctx.sector)
        if unlevered is None:
            record("unlevered_beta", "Unlevered beta", None, "missing", f"No sourced beta for sector '{ctx.sector}'.")

    size_premium = record(
        "size_premium",
        "Size premium",
        o.size_premium or 0.0,
        "user" if o.size_premium is not None else "convention",
        None if o.size_premium is not None else "None applied unless you add one",
    )
    specific = record(
        "company_specific_premium",
        "Company-specific premium",
        o.company_specific_premium or 0.0,
        "user" if o.company_specific_premium is not None else "convention",
        None if o.company_specific_premium is not None else "None applied unless you add one",
    )

    tax = o.tax_rate
    if tax is not None:
        record("tax_rate", "Tax rate", tax, "user")
    else:
        tax = from_default("tax_rate", "Tax rate (statutory)", "tax_rates", ctx.country)
        if tax is None and base:
            etr = effective_tax_rate(data, base)
            if etr is not None:
                tax = record("tax_rate", "Tax rate", etr, "historical", f"Effective tax rate {base}")
        if tax is None:
            record("tax_rate", "Tax rate", None, "missing", "Enter the tax rate.")

    kd = o.pre_tax_cost_of_debt
    if kd is not None:
        record("pre_tax_cost_of_debt", "Pre-tax cost of debt", kd, "user")
    elif base:
        debt_now = total_debt(data, base, include_leases=False)
        debt_prev = total_debt(data, periods[-2], include_leases=False) if len(periods) > 1 else None
        interest = data.get("interest_expense", base)
        avg_debt = None if debt_now is None else (debt_now if debt_prev is None else (debt_now + debt_prev) / 2)
        if interest is not None and avg_debt and avg_debt > 0 and rf is not None:
            implied = min(max(-interest / avg_debt, rf), rf + 0.10)
            kd = record(
                "pre_tax_cost_of_debt",
                "Pre-tax cost of debt",
                implied,
                "historical",
                f"Interest expense ÷ average debt {base}, bounded to [rf, rf + 10%]",
            )
        else:
            record(
                "pre_tax_cost_of_debt",
                "Pre-tax cost of debt",
                None,
                "missing",
                "Enter the pre-tax cost of debt (no interest/debt history to imply it).",
            )

    dv = o.target_debt_to_capital
    if dv is not None:
        record("target_debt_to_capital", "Target debt ÷ capital", dv, "user")
    elif base:
        debt = total_debt(data, base) or 0.0
        equity_book = data.get("total_equity", base)
        if equity_book is not None and equity_book > 0 and debt + equity_book > 0:
            dv = record(
                "target_debt_to_capital",
                "Target debt ÷ capital",
                debt / (debt + equity_book),
                "historical",
                f"Book debt ÷ (debt + book equity) {base}; replace with a target structure if known",
            )
        else:
            dv = record(
                "target_debt_to_capital",
                "Target debt ÷ capital",
                0.0,
                "convention",
                "No balance sheet; all-equity assumed",
            )

    wacc_result: WACCResult | None = None
    if None not in (rf, erp, tax, kd, dv) and (unlevered is not None or beta_mode == "levered_input"):
        wacc_result = compute_wacc(
            WACCInputs(
                risk_free_rate=rf,
                equity_risk_premium=erp,
                country_risk_premium=crp or 0.0,
                size_premium=size_premium,
                company_specific_premium=specific,
                beta_mode=beta_mode,
                levered_beta=o.levered_beta,
                unlevered_beta=unlevered,
                pre_tax_cost_of_debt=kd,
                tax_rate=tax,
                target_debt_to_capital=dv or 0.0,
            )
        )
        record("wacc", "WACC", wacc_result.wacc, "derived", "Built from the inputs above")

    # ── projection drivers ──────────────────────────────────────────────
    hist = periods[-3:]
    g_terminal = o.terminal_growth
    if g_terminal is not None:
        record("terminal_growth", "Terminal growth", g_terminal, "user")
    else:
        g_terminal = CONVENTION_TERMINAL_GROWTH if rf is None else min(CONVENTION_TERMINAL_GROWTH, rf - 0.005)
        record(
            "terminal_growth",
            "Terminal growth",
            g_terminal,
            "convention",
            "2.0% long-run nominal growth, capped 0.5pp below the risk-free rate",
        )

    growth: list[float] | None = None
    if isinstance(o.revenue_growth, list) and o.revenue_growth:
        growth = record("revenue_growth", "Revenue growth by year", per_year(o.revenue_growth, years), "user")
    elif isinstance(o.revenue_growth, float | int):
        growth = record("revenue_growth", "Revenue growth by year", [float(o.revenue_growth)] * years, "user")
    else:
        revenues = [(p, data.get("revenue", p)) for p in hist]
        revenues = [(p, r) for p, r in revenues if r is not None]
        hist_cagr = cagr(revenues[0][1], revenues[-1][1], len(revenues) - 1) if len(revenues) >= 2 else None
        if hist_cagr is not None:
            start = min(max(hist_cagr, CONVENTION_GROWTH_BOUNDS[0]), CONVENTION_GROWTH_BOUNDS[1])
            growth = record(
                "revenue_growth",
                "Revenue growth by year",
                _fade(start, g_terminal, years),
                "historical",
                f"{revenues[0][0]}–{revenues[-1][0]} CAGR {hist_cagr:.1%} (bounded {CONVENTION_GROWTH_BOUNDS[0]:.0%}"
                f" to {CONVENTION_GROWTH_BOUNDS[1]:.0%}) fading linearly to terminal growth",
            )
        else:
            growth = record(
                "revenue_growth",
                "Revenue growth by year",
                [g_terminal] * years,
                "convention",
                "Only one year of revenue: flat at terminal growth; enter a growth view",
            )
    if growth is not None and len(growth) != years:
        growth = (growth + [growth[-1]] * years)[:years]

    margin: list[float] | None = None
    if isinstance(o.ebitda_margin, list) and o.ebitda_margin:
        margin = record("ebitda_margin", "EBITDA margin by year", per_year(o.ebitda_margin, years), "user")
    elif isinstance(o.ebitda_margin, float | int):
        margin = record("ebitda_margin", "EBITDA margin by year", [float(o.ebitda_margin)] * years, "user")
    elif base_ebitda is not None and base_revenue:
        margin = record(
            "ebitda_margin",
            "EBITDA margin by year",
            [base_ebitda / base_revenue] * years,
            "historical",
            f"Held at {base} margin {base_ebitda / base_revenue:.1%}",
        )
    else:
        record("ebitda_margin", "EBITDA margin", None, "missing", "Enter EBITDA (or EBIT and D&A) for the base year.")

    def pct_driver(
        key: str,
        label: str,
        override: list[float] | float | None,
        concept: str,
        *,
        negate: bool,
        fallback: float | None,
        fallback_note: str,
    ) -> list[float] | float | None:
        if isinstance(override, list) and override:
            return record(key, label, per_year(override, years), "user")
        if isinstance(override, int | float):
            return record(key, label, float(override), "user")
        hist_avg = _avg(_ratio_series(data, hist, concept, negate=negate))
        if hist_avg is not None:
            return record(key, label, hist_avg, "historical", f"Average of {', '.join(hist)}")
        if fallback is not None:
            return record(key, label, fallback, "convention", fallback_note)
        return record(key, label, None, "missing", fallback_note)

    da_pct = pct_driver(
        "da_pct_revenue",
        "D&A % of revenue",
        o.da_pct_revenue,
        "da_total",
        negate=True,
        fallback=None,
        fallback_note="Enter D&A for at least one year.",
    )
    capex_pct = pct_driver(
        "capex_pct_revenue",
        "Capex % of revenue",
        o.capex_pct_revenue,
        "capex",
        negate=True,
        fallback=None,
        fallback_note="Enter capex for at least one year.",
    )
    nwc_pct: list[float] | float
    if isinstance(o.nwc_pct_revenue, list) and o.nwc_pct_revenue:
        nwc_pct = record(
            "nwc_pct_revenue", "Net working capital % of revenue", per_year(o.nwc_pct_revenue, years), "user"
        )
    elif isinstance(o.nwc_pct_revenue, int | float):
        nwc_pct = record("nwc_pct_revenue", "Net working capital % of revenue", float(o.nwc_pct_revenue), "user")
    else:
        nwc_hist: list[float | None] = []
        for p in hist:
            rec, inv, pay, rev = (data.get(c, p) for c in ("receivables", "inventory", "payables", "revenue"))
            nwc_hist.append(None if rec is None or pay is None or not rev else (rec + (inv or 0.0) - pay) / rev)
        nwc_avg = _avg(nwc_hist)
        nwc_pct = record(
            "nwc_pct_revenue",
            "Net working capital % of revenue",
            nwc_avg if nwc_avg is not None else 0.0,
            "historical" if nwc_avg is not None else "convention",
            "Receivables + inventory − payables, average"
            if nwc_avg is not None
            else "No working-capital data: NWC held at 0% of revenue",
        )
    nol = o.nol_opening if o.nol_opening is not None else (data.get("nol", base) if base else None) or 0.0

    # ── bridge and shares from the latest balance sheet ─────────────────
    def bs(concept: str) -> float:
        return (data.get(concept, base) if base else None) or 0.0

    include_leases = True if o.include_leases is None else o.include_leases
    bridge = BridgeInputs(
        gross_debt=bs("st_debt") + bs("lt_debt"),
        lease_liabilities=bs("current_lease_liabilities") + bs("non_current_lease_liabilities"),
        include_leases=include_leases,
        pension_deficit=bs("pension_deficit"),
        include_pensions=True if o.include_pensions is None else o.include_pensions,
        preferred_equity=bs("preferred_equity"),
        minority_interest=bs("minority_interest_bs"),
        provisions=bs("provisions"),
        include_provisions=bool(o.include_provisions),
        cash=bs("cash"),
        minimum_operating_cash=o.minimum_operating_cash or 0.0,
        short_term_investments=bs("st_investments"),
        investments_in_associates=bs("investments_in_associates"),
    )
    shares = o.basic_shares or (data.get("shares_outstanding", base) if base else None)
    dilution = DilutionInputs(basic_shares=shares, options=o.options) if shares and shares > 0 else None
    if dilution is None:
        warnings.append("Share count unknown: values are shown for 100% of equity only, without per-share figures.")
    price = o.share_price if o.share_price is not None else (data.get("share_price", base) if base else None)
    market_cap = price * shares if price and shares else None

    # ── exit multiple ───────────────────────────────────────────────────
    peer_ev_ebitda = multiple_stats(peers, "ev_ebitda", exclude_outliers=o.exclude_peer_outliers) if peers else None
    exit_multiple = o.exit_multiple
    if exit_multiple is not None:
        record("exit_multiple", "Exit EV/EBITDA", exit_multiple, "user")
    elif peer_ev_ebitda and peer_ev_ebitda.median:
        exit_multiple = record(
            "exit_multiple", "Exit EV/EBITDA", peer_ev_ebitda.median, "derived", f"Median of {peer_ev_ebitda.n} peers"
        )
    else:
        exit_multiple = from_default(
            "exit_multiple", "Exit EV/EBITDA (sector)", "sector_multiples", ctx.sector, field="ev_ebitda"
        )
    terminal_method = o.terminal_method or "gordon"
    derive_exit_multiple = exit_multiple is None
    if derive_exit_multiple and terminal_method != "gordon":
        record(
            "exit_multiple",
            "Exit EV/EBITDA",
            None,
            "missing",
            "Add peers or enter an exit multiple to use the exit-multiple method.",
        )
    record(
        "terminal_method",
        "Terminal value method",
        None,
        "user" if o.terminal_method else "convention",
        {
            "gordon": "Gordon growth (exit multiple shown as cross-check)",
            "exit_multiple": "Exit multiple",
            "average": "Average of Gordon and exit multiple",
        }[terminal_method],
    )

    # ── DCF ─────────────────────────────────────────────────────────────
    dcf: DCFResult | None = None
    dcf_inputs: DCFInputs | None = None
    dcf_range: dict[str, float] | None = None
    ready = (
        wacc_result is not None
        and base_revenue
        and growth
        and margin
        and da_pct is not None
        and capex_pct is not None
        and tax is not None
        and not (derive_exit_multiple and terminal_method != "gordon")
    )
    if ready:
        assert wacc_result is not None and base_revenue and growth and margin and tax is not None
        drivers = ProjectionDrivers(
            base_year_label=base or "Base",
            base_revenue=base_revenue,
            revenue_growth=growth,
            ebitda_margin=margin,
            da_pct_revenue=per_year(da_pct if da_pct is not None else 0.0, years),
            capex_pct_revenue=per_year(capex_pct if capex_pct is not None else 0.0, years),
            nwc_pct_revenue=per_year(nwc_pct, years),
            tax_rate=tax,
            nol_opening=nol,
        )
        first_year_end = date(
            ctx.last_fiscal_year_end.year + 1,
            ctx.last_fiscal_year_end.month,
            min(ctx.last_fiscal_year_end.day, 28 if ctx.last_fiscal_year_end.month == 2 else 31),
        )
        valuation_date = max(ctx.valuation_date, ctx.last_fiscal_year_end)
        if first_year_end <= valuation_date:
            warnings.append("The valuation date is after the first projected year end; enter the latest full year.")
        if derive_exit_multiple and terminal_method == "gordon" and wacc_result.wacc > g_terminal:
            probe = run_dcf(
                DCFInputs(
                    drivers=drivers,
                    wacc=wacc_result.wacc,
                    terminal_growth=g_terminal,
                    exit_multiple=1.0,
                    valuation_date=valuation_date,
                    first_year_end=first_year_end,
                )
            )
            exit_multiple = record(
                "exit_multiple",
                "Exit EV/EBITDA",
                probe.gordon.implied_cross_check,
                "derived",
                "No peers or sourced sector multiple: implied by the Gordon terminal value",
            )
        dcf_inputs = DCFInputs(
            drivers=drivers,
            wacc=wacc_result.wacc,
            terminal_growth=g_terminal,
            exit_multiple=exit_multiple or 1.0,
            terminal_method=terminal_method,
            valuation_date=valuation_date,
            first_year_end=first_year_end,
            mid_year=True if o.mid_year is None else o.mid_year,
            risk_free_rate=rf,
            bridge=bridge,
            dilution=dilution,
            year_labels=[f"{first_year_end.year + t}E" for t in range(years)],
        )
        try:
            dcf = run_dcf(dcf_inputs)
            warnings.extend(dcf.warnings)
            grid = sensitivity_wacc_growth(
                dcf_inputs,
                [CONVENTION_DCF_WACC_STEP, 0, -CONVENTION_DCF_WACC_STEP],
                [-CONVENTION_DCF_GROWTH_STEP, 0, CONVENTION_DCF_GROWTH_STEP],
            )
            low_ev, high_ev = grid.values[0][0], grid.values[2][2]
            if low_ev is not None and high_ev is not None:
                from .valuation.bridge import ev_to_equity

                dcf_range = {
                    "ev_low": low_ev,
                    "ev_mid": dcf.enterprise_value,
                    "ev_high": high_ev,
                    "equity_low": ev_to_equity(low_ev, bridge).equity_value,
                    "equity_mid": dcf.equity_value,
                    "equity_high": ev_to_equity(high_ev, bridge).equity_value,
                }
        except ValueError as error:
            warnings.append(f"DCF not run: {error}")
    else:
        warnings.append("DCF not run until the missing inputs are entered.")

    # ── comps ───────────────────────────────────────────────────────────
    comps: list[ImpliedValue] = []
    comps_basis = o.comps_basis
    targets, target_notes = comps_target_metrics(data, base, base_ebitda, dcf, comps_basis, o.target_eps_growth)
    if peers:
        for multiple_id, metric in targets.items():
            stats = multiple_stats(peers, multiple_id, exclude_outliers=o.exclude_peer_outliers, basis=comps_basis)
            if stats.n:
                comps.append(implied_value(stats, metric, bridge, missing_note=target_notes.get(multiple_id)))

    # ── football field ──────────────────────────────────────────────────
    methods: list[MethodRange] = []
    weights = o.method_weights
    if dcf_range:
        methods.append(
            MethodRange(
                method_id="dcf",
                label="DCF (WACC ±1pp, g ±0.5pp)",
                equity_low=dcf_range["equity_low"],
                equity_mid=dcf_range["equity_mid"],
                equity_high=dcf_range["equity_high"],
                ev_low=dcf_range["ev_low"],
                ev_mid=dcf_range["ev_mid"],
                ev_high=dcf_range["ev_high"],
                weight=weights.get("dcf", 1.0),
            )
        )
    for c in comps:
        if c.equity_low is None or c.equity_mid is None or c.equity_high is None:
            continue
        default_weight = (
            1.0 if c.multiple_id in ("ev_ebitda",) else 0.5 if c.multiple_id in ("ev_revenue", "pe") else 0.0
        )
        # sector multiples (EV/EBITDAR, PEG, EV/ARR, P/NAV) appear only where the suitability guide or the analyst
        # gives them a weight, so a software deal is not shown a P/NAV bar and vice versa
        if c.multiple_id in SECTOR_MULTIPLES and weights.get(f"comps_{c.multiple_id}", 0.0) <= 0:
            continue
        suffix = "" if comps_basis == "ltm" else f" ({comps_basis.upper()})"
        methods.append(
            MethodRange(
                method_id=f"comps_{c.multiple_id}",
                label=f"Trading comps: {MULTIPLES[c.multiple_id]['label']}{suffix}",
                equity_low=c.equity_low,
                equity_mid=c.equity_mid,
                equity_high=c.equity_high,
                ev_low=c.ev_low,
                ev_mid=c.ev_mid,
                ev_high=c.ev_high,
                weight=weights.get(f"comps_{c.multiple_id}", default_weight),
            )
        )
    ff = football_field(methods, dilution=dilution, market_cap=market_cap, share_price=price) if methods else None
    if ff:
        warnings.extend(ff.warnings)

    return QuickScanResult(
        assumptions=resolved,
        missing=missing,
        wacc=wacc_result,
        dcf_inputs=dcf_inputs if dcf else None,
        dcf=dcf,
        dcf_range=dcf_range,
        comps=comps,
        football_field=ff,
        market_cap=market_cap,
        warnings=list(dict.fromkeys(warnings)),
        base_period=base,
        base_revenue=base_revenue,
        base_ebitda=base_ebitda,
        bridge=bridge,
        dilution=dilution,
        share_price=price,
        tax_rate=tax,
    )
