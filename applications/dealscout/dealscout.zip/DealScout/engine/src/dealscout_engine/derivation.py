"""Derivations: how a number was produced, so every figure in the UI and exports can be explained."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

DerivationKind = Literal["reported", "computed", "default", "assumption", "missing"]


class DerivationInput(BaseModel):
    """One input to a calculation."""

    name: str
    value: float | None
    label: str | None = None
    note: str | None = None


class Derivation(BaseModel):
    """A human-readable trace of a number: what kind it is, the formula and the inputs used."""

    kind: DerivationKind
    formula: str | None = None
    inputs: list[DerivationInput] = Field(default_factory=list)
    note: str | None = None
