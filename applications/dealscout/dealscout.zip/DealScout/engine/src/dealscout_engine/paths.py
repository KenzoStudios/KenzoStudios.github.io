"""Location of the versioned reference data (taxonomy, market defaults) shipped with the repository."""

from __future__ import annotations

import os
from pathlib import Path


def repo_data_dir() -> Path:
    """Return the repository ``data/`` directory.

    ``DEALSCOUT_REFERENCE_DATA`` overrides it (used by tests and packaged builds).
    """
    override = os.environ.get("DEALSCOUT_REFERENCE_DATA")
    if override:
        return Path(override)
    # engine/src/dealscout_engine/paths.py -> repo root is parents[3]
    return Path(__file__).resolve().parents[3] / "data"
