"""Comparing a saved version of a deal with its current state (brief §14, deal versioning).

Pure functions: the caller passes plain mappings read from the snapshot and from the live deal.

    value change   = current − version                       (per period and line item)
    result change  = current − version ;  % = change ÷ |version|   (undefined when the version value is 0 or missing)
"""

from __future__ import annotations

import math
from collections.abc import Mapping
from typing import Any

from pydantic import BaseModel

Cell = tuple[str, str]  # (period key, concept id)


class ValueDiff(BaseModel):
    period_key: str
    concept_id: str
    version: float | None  # None: not in the version (added since)
    current: float | None  # None: removed since the version
    change: float | None


class FieldDiff(BaseModel):
    section: str
    key: str
    version: Any = None
    current: Any = None


class ResultDelta(BaseModel):
    key: str
    version: float | None
    current: float | None
    change: float | None
    change_pct: float | None


def _same(a: float, b: float, tolerance: float) -> bool:
    return abs(a - b) <= tolerance * max(abs(a), abs(b), 1.0)


def _number(value: Any) -> bool:
    return isinstance(value, int | float) and not isinstance(value, bool)


def diff_values(
    version: Mapping[Cell, float], current: Mapping[Cell, float], *, tolerance: float = 1e-9
) -> list[ValueDiff]:
    """Cells that differ, were added or were removed, sorted by period then line item."""
    out: list[ValueDiff] = []
    for cell in sorted(set(version) | set(current)):
        old, new = version.get(cell), current.get(cell)
        if old is not None and new is not None and _same(old, new, tolerance):
            continue
        change = new - old if old is not None and new is not None else None
        out.append(ValueDiff(period_key=cell[0], concept_id=cell[1], version=old, current=new, change=change))
    return out


def diff_fields(section: str, version: Mapping[str, Any], current: Mapping[str, Any]) -> list[FieldDiff]:
    """Keys whose value differs between two flat documents (a missing key counts as None)."""
    out = []
    for key in sorted(set(version) | set(current)):
        old, new = version.get(key), current.get(key)
        if isinstance(old, int | float) and isinstance(new, int | float) and _number(old) and _number(new):
            if _same(float(old), float(new), 1e-12):
                continue
        elif old == new:
            continue
        out.append(FieldDiff(section=section, key=key, version=old, current=new))
    return out


def result_deltas(version: Mapping[str, Any], current: Mapping[str, Any]) -> list[ResultDelta]:
    """Numeric headline results side by side with their change (keys whose values are not numbers are skipped)."""
    out = []
    for key in sorted(set(version) | set(current)):
        old, new = version.get(key), current.get(key)
        present = [v for v in (old, new) if v is not None]
        if not present or not all(_number(v) for v in present):
            continue
        old_f = float(old) if old is not None else None
        new_f = float(new) if new is not None else None
        change = new_f - old_f if old_f is not None and new_f is not None else None
        pct = change / abs(old_f) if change is not None and old_f and math.isfinite(old_f) else None
        out.append(ResultDelta(key=key, version=old_f, current=new_f, change=change, change_pct=pct))
    return out
