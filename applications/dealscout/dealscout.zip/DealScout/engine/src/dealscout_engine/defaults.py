"""Market-assumption defaults (data/defaults/market_assumptions.yaml) — loading, lookup and staleness.

Every default carries a source and an as-of date. A ``null`` value is a placeholder the user must fill: lookups
return ``None`` for it so callers ask for the value instead of using it.
"""

from __future__ import annotations

from datetime import date
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel

from .paths import repo_data_dir


class DefaultValue(BaseModel):
    """One resolved default with its provenance."""

    path: str
    value: float | None
    as_of: str | None = None
    source: str | None = None
    source_url: str | None = None
    status: str | None = None
    stale: bool = False

    @property
    def usable(self) -> bool:
        return self.value is not None and self.status != "placeholder"


class MarketDefaults(BaseModel):
    raw: dict[str, Any]
    stale_after_days: int = 90

    @property
    def version(self) -> str:
        return str(self.raw.get("version", "unknown"))

    @property
    def as_of(self) -> str | None:
        value = self.raw.get("as_of")
        return str(value) if value else None

    def _entry(self, *keys: str) -> dict[str, Any] | None:
        node: Any = self.raw
        for key in keys:
            if not isinstance(node, dict) or key not in node:
                return None
            node = node[key]
        return node if isinstance(node, dict) else None

    def lookup(self, *keys: str, field: str = "value", today: date | None = None) -> DefaultValue:
        entry = self._entry(*keys)
        path = ".".join(keys) + ("" if field == "value" else f".{field}")
        if entry is None:
            return DefaultValue(path=path, value=None, status="missing")
        raw_value = entry.get(field)
        value = float(raw_value) if isinstance(raw_value, int | float) and not isinstance(raw_value, bool) else None
        as_of = str(entry["as_of"]) if entry.get("as_of") else None
        return DefaultValue(
            path=path,
            value=value,
            as_of=as_of,
            source=entry.get("source"),
            source_url=entry.get("source_url"),
            status=entry.get("status"),
            stale=is_stale(as_of, self.stale_after_days, today),
        )

    def entries(self) -> list[tuple[str, dict[str, Any]]]:
        """Flatten every leaf entry (a dict with a source/status) for the Defaults screen."""
        out: list[tuple[str, dict[str, Any]]] = []

        def walk(node: Any, prefix: list[str]) -> None:
            if isinstance(node, dict):
                if "status" in node or "source" in node:
                    out.append((".".join(prefix), node))
                    return
                for key, child in node.items():
                    walk(child, [*prefix, str(key)])

        for section in (
            "risk_free_rates",
            "equity_risk_premium",
            "country_risk_premia",
            "sector_unlevered_betas",
            "sector_multiples",
            "tax_rates",
            "control_premia",
            "lbo",
            "dlom",
        ):
            walk(self.raw.get(section, {}), [section])
        return out


def is_stale(as_of: str | None, stale_after_days: int, today: date | None = None) -> bool:
    if not as_of:
        return False
    try:
        dated = date.fromisoformat(as_of[:10])
    except ValueError:
        return False
    return ((today or date.today()) - dated).days > stale_after_days


def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Local edits (override) win over shipped defaults (base), key by key."""
    merged = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


@lru_cache(maxsize=2)
def _load(path: str) -> dict[str, Any]:
    with open(path, encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    return data if isinstance(data, dict) else {}


def load_defaults(path: Path | None = None, *, overrides: dict[str, Any] | None = None) -> MarketDefaults:
    target = path or repo_data_dir() / "defaults" / "market_assumptions.yaml"
    raw = _load(str(target)) if target.exists() else {}
    if overrides:
        raw = deep_merge(raw, overrides)
    return MarketDefaults(raw=raw, stale_after_days=int(raw.get("stale_after_days", 90) or 90))
