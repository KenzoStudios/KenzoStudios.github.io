"""DealScout calculation engine.

Pure, deterministic financial maths: no web, AI, database or document-format dependencies.
Every public calculation returns its result together with a ``Derivation`` (formula + inputs) so the
UI can show how any number was produced.
"""

__version__ = "0.1.0"
