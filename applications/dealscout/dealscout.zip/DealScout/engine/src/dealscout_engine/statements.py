"""Financial data container that resolves reported, summed and formula concepts with derivations.

Resolution rule for a (concept, period):
  1. a stored (reported / manual / extracted) value wins;
  2. otherwise a ``sum`` concept is the sum of its *available* components, provided at least one is
     available (missing components are listed in the derivation so the gap is visible, never hidden);
  3. otherwise a ``formula`` concept is evaluated when every input resolves;
  4. otherwise the value is missing (``None``) — callers must ask the user rather than guess.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .derivation import Derivation, DerivationInput
from .formula import evaluate
from .taxonomy import Taxonomy


@dataclass(frozen=True)
class Resolved:
    value: float | None
    derivation: Derivation


@dataclass
class FinancialData:
    """Values keyed by (concept_id, period_id). Values follow the taxonomy sign convention."""

    taxonomy: Taxonomy
    values: dict[tuple[str, str], float] = field(default_factory=dict)

    def set(self, concept_id: str, period_id: str, value: float) -> None:
        self.taxonomy.concept(concept_id)  # validates the id
        self.values[(concept_id, period_id)] = float(value)

    def get(self, concept_id: str, period_id: str) -> float | None:
        return self.resolve(concept_id, period_id).value

    def resolve(self, concept_id: str, period_id: str) -> Resolved:
        return self._resolve(concept_id, period_id, frozenset())

    def _resolve(self, concept_id: str, period_id: str, stack: frozenset[str]) -> Resolved:
        concept = self.taxonomy.concept(concept_id)
        stored = self.values.get((concept_id, period_id))
        if stored is not None:
            return Resolved(stored, Derivation(kind="reported", note=f"{concept.name} as entered/reported"))
        if concept_id in stack:  # defensive; the taxonomy validator already rejects cycles
            return Resolved(None, Derivation(kind="missing", note="circular definition"))
        nested = stack | {concept_id}

        if concept.aggregation == "sum":
            parts = [(c, self._resolve(c, period_id, nested)) for c in concept.components]
            available = [(c, r) for c, r in parts if r.value is not None]
            if not available:
                return Resolved(None, Derivation(kind="missing", note=f"{concept.name}: no value or components"))
            missing = [c for c, r in parts if r.value is None]
            total = sum(r.value for _, r in available if r.value is not None)
            note = f"components not available (treated as 0): {', '.join(missing)}" if missing else None
            return Resolved(
                total,
                Derivation(
                    kind="computed",
                    formula=" + ".join(concept.components),
                    inputs=[DerivationInput(name=c, value=r.value, label=self._name(c)) for c, r in parts],
                    note=note,
                ),
            )

        if concept.aggregation == "formula" and concept.formula:
            inputs = {name: self._resolve(name, period_id, nested) for name in concept.inputs}
            missing = [name for name, r in inputs.items() if r.value is None]
            derivation_inputs = [DerivationInput(name=n, value=r.value, label=self._name(n)) for n, r in inputs.items()]
            if missing:
                return Resolved(
                    None,
                    Derivation(
                        kind="missing",
                        formula=concept.formula,
                        inputs=derivation_inputs,
                        note=f"missing inputs: {', '.join(missing)}",
                    ),
                )
            value = evaluate(concept.formula, {n: r.value for n, r in inputs.items() if r.value is not None})
            return Resolved(value, Derivation(kind="computed", formula=concept.formula, inputs=derivation_inputs))

        return Resolved(None, Derivation(kind="missing", note=f"{concept.name} not provided"))

    def _name(self, concept_id: str) -> str:
        return self.taxonomy.concept(concept_id).name
