"""Calendarisation of peers with a different fiscal year-end (brief §7).

A peer's figures are moved onto the target's fiscal year by time-weighting the two peer fiscal years that overlap
the target's year. With ``d = (target year-end month − peer year-end month) mod 12``:

    calendarised = (12 − d) / 12 × FY_A + d / 12 × FY_B

where FY_A is the peer's last fiscal year ending on or before the target's year-end (the figures in the peer's
ordinary fields) and FY_B the following fiscal year (the ``*_next`` fields). Example: target December year-end,
peer March year-end, d = 9: calendar 2025 = 0.25 × FY Mar-2025 + 0.75 × FY Mar-2026.

Only flow figures are calendarised; balances (equity, net debt) and market values are taken as they stand. When
FY_B is needed but not entered the figure is not calendarised and is set to missing, so the multiple drops out
with a reason rather than mixing year-ends.
"""

from __future__ import annotations

from pydantic import BaseModel

from .comps import Peer

FLOW_FIELDS = ("revenue", "ebitda", "ebit", "net_income", "free_cash_flow")

MONTHS = (
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
)


def calendarisation_weights(peer_year_end_month: int, target_year_end_month: int) -> tuple[float, float]:
    """Weights of (FY_A, FY_B): the peer years ending on/before and after the target's year-end."""
    for m in (peer_year_end_month, target_year_end_month):
        if not 1 <= m <= 12:
            raise ValueError("a year-end month is between 1 and 12")
    d = (target_year_end_month - peer_year_end_month) % 12
    return (12 - d) / 12, d / 12


def calendarise(
    current: float | None, following: float | None, peer_year_end_month: int, target_year_end_month: int
) -> float | None:
    """Time-weighted figure for the target's fiscal year, or ``None`` when an input it needs is missing."""
    w_a, w_b = calendarisation_weights(peer_year_end_month, target_year_end_month)
    if current is None:
        return None
    if w_b == 0:
        return current
    if following is None:
        return None
    return w_a * current + w_b * following


class CalendarisedPeer(BaseModel):
    peer: Peer
    calendarised: bool
    weights: tuple[float, float] | None = None
    note: str | None = None
    missing_next: list[str] = []


def calendarise_peer(peer: Peer, target_year_end_month: int | None) -> CalendarisedPeer:
    """Put a peer's flow figures on the target's fiscal year; unchanged when the year-ends already match."""
    month = peer.fiscal_year_end_month
    if month is None or target_year_end_month is None or month == target_year_end_month:
        return CalendarisedPeer(peer=peer, calendarised=False)
    w_a, w_b = calendarisation_weights(month, target_year_end_month)
    update: dict[str, float | None] = {}
    missing: list[str] = []
    for f in FLOW_FIELDS:
        current, following = getattr(peer, f), getattr(peer, f"{f}_next")
        if current is not None and following is None:
            missing.append(f)
        update[f] = calendarise(current, following, month, target_year_end_month)
        update[f"{f}_next"] = None  # consumed; the result is one fiscal year on the target's basis
    note = (
        f"Calendarised to a {MONTHS[target_year_end_month - 1]} year-end: "
        f"{w_a:.2f} × FY ending {MONTHS[month - 1]} + {w_b:.2f} × the following FY"
    )
    if missing:
        note += f"; not calendarised (following year missing): {', '.join(missing)}"
    return CalendarisedPeer(
        peer=peer.model_copy(update=update),
        calendarised=True,
        weights=(w_a, w_b),
        note=note,
        missing_next=missing,
    )
