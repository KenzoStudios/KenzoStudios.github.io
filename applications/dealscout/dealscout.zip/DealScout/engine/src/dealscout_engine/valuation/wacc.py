"""Weighted average cost of capital with the full calculation shown (brief §9.2 WACC builder).

Cost of equity (CAPM + premia) = risk-free + β_levered × ERP + country risk premium + size premium + specific premium.
Beta can be entered directly, relevered from an unlevered (asset) beta with Hamada, or derived from peers.
Hamada: β_L = β_U × (1 + (1 − t) × D/E).
"""

from __future__ import annotations

from statistics import median
from typing import Literal

from pydantic import BaseModel, Field, model_validator

from ..derivation import Derivation, DerivationInput

BetaMode = Literal["levered_input", "unlevered_input", "peers"]


def unlever_beta(levered_beta: float, debt_to_equity: float, tax_rate: float) -> float:
    return levered_beta / (1 + (1 - tax_rate) * debt_to_equity)


def relever_beta(unlevered_beta: float, debt_to_equity: float, tax_rate: float) -> float:
    return unlevered_beta * (1 + (1 - tax_rate) * debt_to_equity)


class PeerBeta(BaseModel):
    name: str
    levered_beta: float
    debt_to_equity: float = Field(ge=0)
    tax_rate: float = Field(ge=0, le=1)


class WACCInputs(BaseModel):
    risk_free_rate: float
    equity_risk_premium: float
    country_risk_premium: float = 0.0
    size_premium: float = 0.0
    company_specific_premium: float = 0.0
    beta_mode: BetaMode = "unlevered_input"
    levered_beta: float | None = None
    unlevered_beta: float | None = None
    peer_betas: list[PeerBeta] = []
    pre_tax_cost_of_debt: float
    tax_rate: float = Field(ge=0, le=1)
    target_debt_to_capital: float = Field(ge=0, lt=1)  # D / (D + E)

    @model_validator(mode="after")
    def _beta_present(self) -> WACCInputs:
        if self.beta_mode == "levered_input" and self.levered_beta is None:
            raise ValueError("levered_beta is required when beta_mode is 'levered_input'")
        if self.beta_mode == "unlevered_input" and self.unlevered_beta is None:
            raise ValueError("unlevered_beta is required when beta_mode is 'unlevered_input'")
        if self.beta_mode == "peers" and not self.peer_betas:
            raise ValueError("peer_betas are required when beta_mode is 'peers'")
        return self


class WACCResult(BaseModel):
    debt_to_equity: float
    unlevered_beta: float | None
    levered_beta: float
    cost_of_equity: float
    after_tax_cost_of_debt: float
    equity_weight: float
    debt_weight: float
    wacc: float
    derivation: Derivation


def compute_wacc(i: WACCInputs) -> WACCResult:
    debt_weight = i.target_debt_to_capital
    equity_weight = 1 - debt_weight
    d_to_e = debt_weight / equity_weight
    unlevered: float | None
    if i.beta_mode == "levered_input":
        assert i.levered_beta is not None
        levered, unlevered = i.levered_beta, None
    else:
        if i.beta_mode == "peers":
            unlevered = median(unlever_beta(p.levered_beta, p.debt_to_equity, p.tax_rate) for p in i.peer_betas)
        else:
            unlevered = i.unlevered_beta
        assert unlevered is not None
        levered = relever_beta(unlevered, d_to_e, i.tax_rate)
    cost_of_equity = (
        i.risk_free_rate
        + levered * i.equity_risk_premium
        + i.country_risk_premium
        + i.size_premium
        + i.company_specific_premium
    )
    after_tax_kd = i.pre_tax_cost_of_debt * (1 - i.tax_rate)
    wacc = equity_weight * cost_of_equity + debt_weight * after_tax_kd
    inputs = [
        DerivationInput(name="risk_free_rate", value=i.risk_free_rate),
        DerivationInput(
            name="levered_beta", value=levered, note="relevered with Hamada" if unlevered is not None else None
        ),
        DerivationInput(name="equity_risk_premium", value=i.equity_risk_premium),
        DerivationInput(name="country_risk_premium", value=i.country_risk_premium),
        DerivationInput(name="size_premium", value=i.size_premium),
        DerivationInput(name="company_specific_premium", value=i.company_specific_premium),
        DerivationInput(name="cost_of_equity", value=cost_of_equity),
        DerivationInput(name="pre_tax_cost_of_debt", value=i.pre_tax_cost_of_debt),
        DerivationInput(name="tax_rate", value=i.tax_rate),
        DerivationInput(name="after_tax_cost_of_debt", value=after_tax_kd),
        DerivationInput(name="equity_weight", value=equity_weight),
        DerivationInput(name="debt_weight", value=debt_weight),
    ]
    return WACCResult(
        debt_to_equity=d_to_e,
        unlevered_beta=unlevered,
        levered_beta=levered,
        cost_of_equity=cost_of_equity,
        after_tax_cost_of_debt=after_tax_kd,
        equity_weight=equity_weight,
        debt_weight=debt_weight,
        wacc=wacc,
        derivation=Derivation(
            kind="computed",
            formula="WACC = E/V × (rf + β × ERP + CRP + size + specific) + D/V × Kd × (1 − t)",
            inputs=inputs,
        ),
    )
