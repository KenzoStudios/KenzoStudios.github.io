"""Precedent transactions (brief §9.4).

Each transaction records the price paid for control of a comparable business. Multiples are computed from the deal
EV and the target's metrics (or taken as entered). Filters narrow the set by date, geography and size; an optional
recency weighting gives recent deals more say (weight halves every ``half_life_years``). The implied range is the
weighted 25th / 50th / 75th percentile multiple applied to the target's metric. Precedent values include a control
premium, which is noted on the result.
"""

from __future__ import annotations

import itertools
from datetime import date
from typing import Literal

from pydantic import BaseModel, Field

from .bridge import BridgeInputs, ev_to_equity

PrecedentMultiple = Literal["ev_revenue", "ev_ebitda", "ev_ebit"]
LABELS = {"ev_revenue": "EV / Revenue", "ev_ebitda": "EV / EBITDA", "ev_ebit": "EV / EBIT"}
_METRIC = {"ev_revenue": "revenue", "ev_ebitda": "ebitda", "ev_ebit": "ebit"}


class Transaction(BaseModel):
    announced: date
    target: str = Field(max_length=120)
    acquirer: str = Field(default="", max_length=120)
    country: str | None = Field(default=None, max_length=2)
    sector: str | None = None
    ev: float | None = Field(default=None, gt=0)
    revenue: float | None = None
    ebitda: float | None = None
    ebit: float | None = None
    ev_revenue: float | None = Field(default=None, gt=0)  # as reported, when the metrics are not available
    ev_ebitda: float | None = Field(default=None, gt=0)
    ev_ebit: float | None = Field(default=None, gt=0)
    premium_paid: float | None = None  # vs undisturbed share price, for listed targets
    stake_acquired: float | None = Field(default=None, gt=0, le=1)
    consideration: Literal["cash", "stock", "mixed", "unknown"] = "unknown"
    include: bool = True
    source: str = Field(default="", max_length=300)

    def multiple(self, multiple_id: PrecedentMultiple) -> float | None:
        given = getattr(self, multiple_id)
        if given is not None:
            return float(given)
        metric = getattr(self, _METRIC[multiple_id])
        if self.ev is None or metric is None or metric <= 0:
            return None
        return self.ev / metric


class PrecedentFilters(BaseModel):
    since: date | None = None
    countries: list[str] = Field(default_factory=list)
    min_ev: float | None = None
    max_ev: float | None = None
    half_life_years: float | None = Field(default=None, gt=0)  # recency weighting; None = equal weights


class PrecedentRow(BaseModel):
    """An included transaction as used in the statistics (for live spreadsheet models)."""

    name: str
    announced: date
    ev: float | None
    metric: float | None  # the target's revenue / EBITDA / EBIT
    given_multiple: float | None  # the multiple as entered (wins over EV ÷ metric)
    multiple: float
    raw_weight: float  # before normalisation (1 without recency weighting)


class PrecedentStats(BaseModel):
    multiple_id: PrecedentMultiple
    label: str
    n: int
    values: dict[str, float]
    weights: dict[str, float]
    excluded: dict[str, str]
    p25: float | None
    median: float | None
    p75: float | None
    mean: float | None
    median_premium: float | None
    rows: list[PrecedentRow] = Field(default_factory=list)


class PrecedentValue(BaseModel):
    multiple_id: PrecedentMultiple
    label: str
    target_metric: float | None
    stats: PrecedentStats
    ev_low: float | None
    ev_mid: float | None
    ev_high: float | None
    equity_low: float | None
    equity_mid: float | None
    equity_high: float | None
    note: str


def weighted_percentile(values: list[float], weights: list[float], q: float) -> float:
    """Percentile of a weighted sample (q in 0..1).

    Item i sits at position (cumulative weight before it) / (total weight − last weight), so with equal weights this
    is exactly NumPy's default linear percentile — the convention used for trading comps.
    """
    pairs = sorted(zip(values, weights, strict=True))
    if any(w <= 0 for _, w in pairs):
        raise ValueError("weights must be positive")
    if len(pairs) == 1:
        return pairs[0][0]
    span = sum(w for _, w in pairs) - pairs[-1][1]
    positions = []
    cumulative = 0.0
    for value, weight in pairs:
        positions.append((cumulative / span, value))
        cumulative += weight
    for (p0, v0), (p1, v1) in itertools.pairwise(positions):
        if p0 <= q <= p1:
            return v0 if p1 == p0 else v0 + (v1 - v0) * (q - p0) / (p1 - p0)
    return positions[-1][1] if q > 1 else positions[0][1]


def precedent_stats(
    transactions: list[Transaction],
    multiple_id: PrecedentMultiple,
    filters: PrecedentFilters | None = None,
    *,
    as_of: date,
) -> PrecedentStats:
    f = filters or PrecedentFilters()
    values: dict[str, float] = {}
    weights: dict[str, float] = {}
    excluded: dict[str, str] = {}
    premia: list[float] = []
    rows: list[PrecedentRow] = []
    seen: dict[str, int] = {}
    for t in transactions:
        base = f"{t.target.strip() or 'Unnamed target'} ({t.announced.year})"
        seen[base] = seen.get(base, 0) + 1
        # same target and year twice (or blank targets): number them so neither overwrites the other
        name = base if seen[base] == 1 else f"{base} #{seen[base]}"
        if not t.include:
            excluded[name] = "Excluded by user"
            continue
        if f.since and t.announced < f.since:
            excluded[name] = f"Before {f.since.isoformat()}"
            continue
        if f.countries and (t.country or "").upper() not in {c.upper() for c in f.countries}:
            excluded[name] = "Outside the chosen geographies"
            continue
        if t.ev is not None and (
            (f.min_ev is not None and t.ev < f.min_ev) or (f.max_ev is not None and t.ev > f.max_ev)
        ):
            excluded[name] = "Outside the size range"
            continue
        m = t.multiple(multiple_id)
        if m is None:
            excluded[name] = "Multiple not available"
            continue
        values[name] = m
        age = max((as_of - t.announced).days / 365.25, 0.0)
        weights[name] = 0.5 ** (age / f.half_life_years) if f.half_life_years else 1.0
        rows.append(
            PrecedentRow(
                name=name,
                announced=t.announced,
                ev=t.ev,
                metric=getattr(t, _METRIC[multiple_id]),
                given_multiple=getattr(t, multiple_id),
                multiple=m,
                raw_weight=weights[name],
            )
        )
        if t.premium_paid is not None:
            premia.append(t.premium_paid)
    if not values:
        return PrecedentStats(
            multiple_id=multiple_id,
            label=LABELS[multiple_id],
            n=0,
            values={},
            weights={},
            excluded=excluded,
            p25=None,
            median=None,
            p75=None,
            mean=None,
            median_premium=None,
        )
    names = list(values)
    v = [values[n] for n in names]
    w = [weights[n] for n in names]
    total = sum(w)
    premia.sort()
    return PrecedentStats(
        multiple_id=multiple_id,
        label=LABELS[multiple_id],
        n=len(values),
        values=values,
        weights={n: weights[n] / total for n in names},
        excluded=excluded,
        p25=weighted_percentile(v, w, 0.25),
        median=weighted_percentile(v, w, 0.5),
        p75=weighted_percentile(v, w, 0.75),
        mean=sum(a * b for a, b in zip(v, w, strict=True)) / total,
        median_premium=premia[len(premia) // 2]
        if len(premia) % 2
        else ((premia[len(premia) // 2 - 1] + premia[len(premia) // 2]) / 2 if premia else None),
        rows=rows,
    )


def precedent_value(stats: PrecedentStats, target_metric: float | None, bridge: BridgeInputs) -> PrecedentValue:
    note = "Precedent multiples include a control premium paid by the acquirer."
    empty = {
        "ev_low": None,
        "ev_mid": None,
        "ev_high": None,
        "equity_low": None,
        "equity_mid": None,
        "equity_high": None,
    }
    base = {"multiple_id": stats.multiple_id, "label": stats.label, "target_metric": target_metric, "stats": stats}
    if stats.n == 0 or stats.p25 is None or stats.median is None or stats.p75 is None:
        return PrecedentValue(**base, **empty, note="No transactions with this multiple.")
    if target_metric is None or target_metric <= 0:
        return PrecedentValue(**base, **empty, note="The target's metric is missing or not positive.")
    evs = [stats.p25 * target_metric, stats.median * target_metric, stats.p75 * target_metric]
    equities = [ev_to_equity(e, bridge).equity_value for e in evs]
    return PrecedentValue(
        **base,
        ev_low=evs[0],
        ev_mid=evs[1],
        ev_high=evs[2],
        equity_low=equities[0],
        equity_mid=equities[1],
        equity_high=equities[2],
        note=note,
    )
