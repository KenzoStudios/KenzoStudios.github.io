"""Trading comparables (brief §9.3).

Peer multiples are computed from the peer financials entered (never typed in as multiples, so they can be audited).
Not-meaningful multiples (non-positive denominators, or EV/price missing) are excluded and listed. Optional outlier
exclusion uses the 1.5 × IQR rule. Statistics use linear interpolation percentiles (same as Excel PERCENTILE.INC).

Applying the 25th percentile / median / 75th percentile to the target metric gives the low / mid / high value. EV
multiples give enterprise value (then the equity bridge); equity multiples (P/E, P/B, P/TBV, P/FCF, PEG, P/NAV) give
equity value.

Bases: ``ltm`` (last reported or LTM figures), ``cy`` (current year) and ``ny`` (next year). Flow multiples with
forward figures (EV/Revenue, EV/EBITDA, EV/EBIT, P/E, PEG) switch to the peer's ``*_cy`` / ``*_ny`` fields; balance
sheet and run-rate multiples (P/B, P/TBV, P/NAV, EV/ARR) are point-in-time and identical on every basis; EV/EBITDAR and
P/FCF have no forward inputs and are not meaningful on a forward basis.

PEG = P/E ÷ (expected EPS growth × 100), e.g. 20x P/E with 10% growth is a PEG of 2.0. Applied to the target it gives
equity = PEG × (target EPS growth × 100) × target net income.
"""

from __future__ import annotations

from typing import Literal

import numpy as np
from pydantic import BaseModel, Field

from .bridge import BridgeInputs, equity_to_ev, ev_to_equity

MultipleId = Literal[
    "ev_revenue", "ev_ebitda", "ev_ebit", "pe", "pb", "ptbv", "p_fcf", "ev_ebitdar", "peg", "ev_arr", "p_nav"
]
Basis = Literal["ltm", "cy", "ny"]
BASES: dict[str, str] = {"ltm": "LTM / last reported", "cy": "Current year", "ny": "Next year"}

MULTIPLES: dict[str, dict[str, str]] = {
    "ev_revenue": {"label": "EV / Revenue", "numerator": "enterprise_value", "metric": "revenue", "basis": "ev"},
    "ev_ebitda": {"label": "EV / EBITDA", "numerator": "enterprise_value", "metric": "ebitda", "basis": "ev"},
    "ev_ebit": {"label": "EV / EBIT", "numerator": "enterprise_value", "metric": "ebit", "basis": "ev"},
    "pe": {"label": "P / E", "numerator": "market_cap", "metric": "net_income", "basis": "equity"},
    "pb": {"label": "P / B", "numerator": "market_cap", "metric": "book_equity", "basis": "equity"},
    "ptbv": {"label": "P / TBV", "numerator": "market_cap", "metric": "tangible_book_equity", "basis": "equity"},
    "p_fcf": {"label": "P / FCF", "numerator": "market_cap", "metric": "free_cash_flow", "basis": "equity"},
    # sector-specific and growth-adjusted multiples
    "ev_ebitdar": {"label": "EV / EBITDAR", "numerator": "enterprise_value", "metric": "ebitdar", "basis": "ev"},
    "peg": {"label": "PEG", "numerator": "market_cap", "metric": "net_income", "basis": "equity"},
    "ev_arr": {"label": "EV / ARR", "numerator": "enterprise_value", "metric": "arr", "basis": "ev"},
    "p_nav": {"label": "P / NAV", "numerator": "market_cap", "metric": "nav", "basis": "equity"},
}

# How a multiple behaves on the forward bases: "flow" has current-year / next-year figures; "point" is a balance sheet
# or run-rate figure, the same on every basis; "ltm_only" has no forward inputs.
TIMING: dict[str, Literal["flow", "point", "ltm_only"]] = {
    "ev_revenue": "flow",
    "ev_ebitda": "flow",
    "ev_ebit": "flow",
    "pe": "flow",
    "peg": "flow",
    "pb": "point",
    "ptbv": "point",
    "ev_arr": "point",
    "p_nav": "point",
    "p_fcf": "ltm_only",
    "ev_ebitdar": "ltm_only",
}


def metric_field(multiple_id: str, basis: str = "ltm") -> str | None:
    """The Peer attribute holding the denominator on a basis; None when the multiple has no figure on that basis."""
    metric = MULTIPLES[multiple_id]["metric"]
    timing = TIMING.get(multiple_id, "ltm_only")
    if basis == "ltm" or timing == "point":
        return metric
    if timing == "ltm_only":
        return None
    return f"{metric}_{basis}"


class Peer(BaseModel):
    """One comparable company. Amounts in one currency and scale (convert before entry)."""

    name: str
    ticker: str | None = None
    country: str | None = None
    include: bool = True
    market_cap: float | None = None
    net_debt: float | None = None  # EV = market cap + net debt (+ other adjustments) unless EV is given
    enterprise_value: float | None = None
    revenue: float | None = None
    ebitda: float | None = None
    ebit: float | None = None
    net_income: float | None = None
    book_equity: float | None = None
    tangible_book_equity: float | None = None
    free_cash_flow: float | None = None
    revenue_growth: float | None = None  # for the scatter / regression view
    ebitda_margin: float | None = None
    # currency conversion and calendarisation (brief §7; see dealscout_engine.fx and .valuation.calendarise)
    currency: str | None = Field(default=None, min_length=3, max_length=3)  # None = the analysis currency
    fiscal_year_end_month: int | None = Field(default=None, ge=1, le=12)  # None = same year-end as the target
    revenue_next: float | None = None  # the following fiscal year, used to calendarise
    ebitda_next: float | None = None
    ebit_next: float | None = None
    net_income_next: float | None = None
    free_cash_flow_next: float | None = None
    # EV/EBITDAR, PEG, EV/ARR, P/NAV and the forward bases (all optional)
    rent_expense: float | None = None  # rent / operating lease cost as a positive amount; EBITDAR = EBITDA + rent
    eps_growth: float | None = None  # expected EPS growth a year as a decimal (0.12 = 12%), for PEG
    arr: float | None = None  # annual recurring revenue (SaaS)
    nav: float | None = None  # reported net asset value (e.g. EPRA NTA) for property companies and holdings
    revenue_cy: float | None = None
    ebitda_cy: float | None = None
    ebit_cy: float | None = None
    net_income_cy: float | None = None
    revenue_ny: float | None = None
    ebitda_ny: float | None = None
    ebit_ny: float | None = None
    net_income_ny: float | None = None

    @property
    def ev(self) -> float | None:
        if self.enterprise_value is not None:
            return self.enterprise_value
        if self.market_cap is not None and self.net_debt is not None:
            return self.market_cap + self.net_debt
        return None

    @property
    def ebitdar(self) -> float | None:
        if self.ebitda is None or self.rent_expense is None:
            return None
        return self.ebitda + abs(self.rent_expense)

    def multiple(self, multiple_id: str, basis: str = "ltm") -> float | None:
        spec = MULTIPLES[multiple_id]
        field = metric_field(multiple_id, basis)
        if field is None:
            return None
        numerator = self.ev if spec["basis"] == "ev" else self.market_cap
        denominator = getattr(self, field)
        if numerator is None or denominator is None or denominator <= 0 or numerator <= 0:
            return None
        if multiple_id == "peg":
            if self.eps_growth is None or self.eps_growth <= 0:
                return None
            return numerator / denominator / (self.eps_growth * 100)
        return numerator / denominator


class MultipleStats(BaseModel):
    multiple_id: str
    label: str
    n: int
    values: dict[str, float]  # peer name -> multiple (used)
    excluded: dict[str, str]  # peer name -> reason
    min: float | None
    p25: float | None
    median: float | None
    mean: float | None
    p75: float | None
    max: float | None
    basis: str = "ltm"


def multiple_stats(
    peers: list[Peer], multiple_id: str, *, exclude_outliers: bool = False, basis: str = "ltm"
) -> MultipleStats:
    spec = MULTIPLES[multiple_id]
    values: dict[str, float] = {}
    excluded: dict[str, str] = {}
    no_figure = metric_field(multiple_id, basis) is None
    for p in peers:
        if not p.include:
            excluded[p.name] = "Excluded by user"
            continue
        m = p.multiple(multiple_id, basis)
        if m is None:
            excluded[p.name] = (
                f"No {BASES[basis].lower()} figure for this multiple"
                if no_figure
                else "Not meaningful (missing or non-positive figure)"
            )
        else:
            values[p.name] = m
    if exclude_outliers and len(values) >= 4:
        arr = np.array(list(values.values()))
        q1, q3 = np.percentile(arr, [25, 75])
        iqr = q3 - q1
        low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        for name, m in list(values.items()):
            if m < low or m > high:
                excluded[name] = f"Outlier (outside {low:.1f}x–{high:.1f}x)"
                del values[name]
    if not values:
        return MultipleStats(
            basis=basis,
            multiple_id=multiple_id,
            label=spec["label"],
            n=0,
            values={},
            excluded=excluded,
            min=None,
            p25=None,
            median=None,
            mean=None,
            p75=None,
            max=None,
        )
    arr = np.array(list(values.values()))
    p25, p50, p75 = (float(x) for x in np.percentile(arr, [25, 50, 75]))
    return MultipleStats(
        basis=basis,
        multiple_id=multiple_id,
        label=spec["label"],
        n=len(values),
        values=values,
        excluded=excluded,
        min=float(arr.min()),
        p25=p25,
        median=p50,
        mean=float(arr.mean()),
        p75=p75,
        max=float(arr.max()),
    )


class ImpliedValue(BaseModel):
    multiple_id: str
    label: str
    target_metric: float | None
    multiple_low: float | None
    multiple_mid: float | None
    multiple_high: float | None
    ev_low: float | None
    ev_mid: float | None
    ev_high: float | None
    equity_low: float | None
    equity_mid: float | None
    equity_high: float | None
    note: str | None = None


def implied_value(
    stats: MultipleStats, target_metric: float | None, bridge: BridgeInputs, *, missing_note: str | None = None
) -> ImpliedValue:
    """Peer quartiles × the target metric. For PEG pass the target's net income × EPS growth × 100."""
    spec = MULTIPLES[stats.multiple_id]
    base = {
        "multiple_id": stats.multiple_id,
        "label": stats.label,
        "target_metric": target_metric,
        "multiple_low": stats.p25,
        "multiple_mid": stats.median,
        "multiple_high": stats.p75,
    }
    empty = {
        "ev_low": None,
        "ev_mid": None,
        "ev_high": None,
        "equity_low": None,
        "equity_mid": None,
        "equity_high": None,
    }
    if stats.n == 0:
        return ImpliedValue(**base, **empty, note="No meaningful peer multiples.")
    if target_metric is None or target_metric <= 0:
        return ImpliedValue(
            **base, **empty, note=missing_note or "Target metric is missing or not positive; multiple not applicable."
        )
    assert stats.p25 is not None and stats.median is not None and stats.p75 is not None
    raw = [m * target_metric for m in (stats.p25, stats.median, stats.p75)]
    if spec["basis"] == "ev":
        evs = raw
        equities = [ev_to_equity(v, bridge).equity_value for v in raw]
    else:
        equities = raw
        evs = [equity_to_ev(v, bridge) for v in raw]
    return ImpliedValue(
        **base,
        ev_low=evs[0],
        ev_mid=evs[1],
        ev_high=evs[2],
        equity_low=equities[0],
        equity_mid=equities[1],
        equity_high=equities[2],
        note="Equity multiple: value derived on an equity basis." if spec["basis"] == "equity" else None,
    )


class Regression(BaseModel):
    x_label: str
    y_label: str
    slope: float
    intercept: float
    r_squared: float
    n: int
    target_x: float | None
    target_implied_y: float | None


def peer_regression(
    peers: list[Peer], multiple_id: str, x_attr: Literal["revenue_growth", "ebitda_margin"], target_x: float | None
) -> Regression | None:
    """Ordinary least squares of a multiple on growth or margin, with the target's implied multiple."""
    points = [(getattr(p, x_attr), p.multiple(multiple_id)) for p in peers if p.include]
    pts = [(x, y) for x, y in points if x is not None and y is not None]
    if len(pts) < 3:
        return None
    xs, ys = np.array([p[0] for p in pts]), np.array([p[1] for p in pts])
    slope, intercept = np.polyfit(xs, ys, 1)
    predicted = slope * xs + intercept
    ss_res = float(((ys - predicted) ** 2).sum())
    ss_tot = float(((ys - ys.mean()) ** 2).sum())
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
    return Regression(
        x_label=x_attr,
        y_label=MULTIPLES[multiple_id]["label"],
        slope=float(slope),
        intercept=float(intercept),
        r_squared=r2,
        n=len(pts),
        target_x=target_x,
        target_implied_y=None if target_x is None else float(slope * target_x + intercept),
    )
