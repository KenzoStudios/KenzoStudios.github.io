"""Discounted cash flow (FCFF) valuation (brief §9.2).

Projection (per year t):
    revenue_t        = revenue_{t-1} × (1 + growth_t)
    ebitda_t         = revenue_t × ebitda_margin_t
    d&a_t            = revenue_t × d&a %_t
    ebit_t           = ebitda_t − d&a_t
    cash taxes_t     = max(ebit_t − NOL used_t, 0) × tax rate     (NOLs offset positive EBIT until exhausted)
    nopat_t          = ebit_t − cash taxes_t
    capex_t          = revenue_t × capex %_t
    nwc_t            = revenue_t × nwc %_t ;  Δnwc_t = nwc_t − nwc_{t-1}
    unlevered_fcf_t  = nopat_t + d&a_t − capex_t − Δnwc_t (+ SBC when the SBC toggle treats it as non-cash)

Discounting: the first projection year is cut to the stub fraction (days from valuation date to the first projected
year end ÷ 365). With the mid-year convention each cash flow is discounted from the middle of its period. Terminal
value is discounted from the end of the final year.

Terminal value — both computed and cross-checked:
    Gordon:        TV = FCF_N × (1 + g) ÷ (WACC − g)
    Exit multiple: TV = EBITDA_N × exit EV/EBITDA
    implied multiple from Gordon = TV_gordon ÷ EBITDA_N
    implied growth from exit TV  = (TV × WACC − FCF_N) ÷ (TV + FCF_N)
"""

from __future__ import annotations

from datetime import date
from typing import Literal

from pydantic import BaseModel, Field, model_validator

from .bridge import BridgeInputs, BridgeResult, DilutionInputs, PerShareResult, ev_to_equity, value_per_share

TerminalMethod = Literal["gordon", "exit_multiple", "average"]


class ProjectionDrivers(BaseModel):
    """Per-year drivers; each list has one entry per projection year."""

    base_year_label: str = "Base"
    base_revenue: float = Field(gt=0)
    revenue_growth: list[float]
    ebitda_margin: list[float]
    da_pct_revenue: list[float]
    capex_pct_revenue: list[float]
    nwc_pct_revenue: list[float]
    base_nwc: float | None = None  # opening NWC; defaults to base revenue × first-year NWC %
    tax_rate: float = Field(ge=0, le=1)
    nol_opening: float = Field(default=0.0, ge=0)
    sbc_pct_revenue: list[float] | None = None
    sbc_treatment: Literal["expense", "add_back"] = "expense"

    @model_validator(mode="after")
    def _lengths(self) -> ProjectionDrivers:
        n = len(self.revenue_growth)
        if not 3 <= n <= 15:
            raise ValueError("the explicit forecast period must be between 3 and 15 years")
        lists = [self.ebitda_margin, self.da_pct_revenue, self.capex_pct_revenue, self.nwc_pct_revenue]
        if self.sbc_pct_revenue is not None:
            lists.append(self.sbc_pct_revenue)
        if any(len(values) != n for values in lists):
            raise ValueError("every driver list must have one value per projection year")
        return self

    @property
    def years(self) -> int:
        return len(self.revenue_growth)


class DCFInputs(BaseModel):
    drivers: ProjectionDrivers
    wacc: float = Field(gt=0)
    terminal_growth: float
    exit_multiple: float = Field(gt=0)
    terminal_method: TerminalMethod = "gordon"
    valuation_date: date
    first_year_end: date
    mid_year: bool = True
    risk_free_rate: float | None = None  # only used for the "growth ≥ risk-free" warning
    bridge: BridgeInputs = BridgeInputs()
    dilution: DilutionInputs | None = None
    year_labels: list[str] | None = None


class ProjectionYear(BaseModel):
    label: str
    revenue: float
    revenue_growth: float
    ebitda: float
    ebitda_margin: float
    da: float
    ebit: float
    nol_used: float
    cash_taxes: float
    nopat: float
    sbc: float
    capex: float
    nwc: float
    change_in_nwc: float
    unlevered_fcf: float
    period_fraction: float
    discount_time: float
    discount_factor: float
    pv_fcf: float


class TerminalValue(BaseModel):
    method: str
    value: float
    pv: float
    implied_cross_check: float | None  # implied multiple (Gordon) or implied growth (exit)


class DCFResult(BaseModel):
    projection: list[ProjectionYear]
    sum_pv_fcf: float
    gordon: TerminalValue
    exit: TerminalValue
    terminal_method: TerminalMethod
    terminal_value_pv: float
    enterprise_value: float
    terminal_share_of_ev: float
    bridge: BridgeResult
    equity_value: float
    per_share: PerShareResult | None
    warnings: list[str]


def stub_fraction(valuation_date: date, first_year_end: date) -> float:
    days = (first_year_end - valuation_date).days
    return min(max(days / 365.0, 0.0), 1.0)


def project(d: ProjectionDrivers, labels: list[str] | None = None) -> list[dict[str, float]]:
    rows: list[dict[str, float]] = []
    revenue = d.base_revenue
    nwc_prev = d.base_nwc if d.base_nwc is not None else d.base_revenue * d.nwc_pct_revenue[0]
    nol = d.nol_opening
    for t in range(d.years):
        revenue = revenue * (1 + d.revenue_growth[t])
        ebitda = revenue * d.ebitda_margin[t]
        da = revenue * d.da_pct_revenue[t]
        ebit = ebitda - da
        nol_used = min(nol, max(ebit, 0.0))
        nol -= nol_used
        cash_taxes = max(ebit - nol_used, 0.0) * d.tax_rate
        nopat = ebit - cash_taxes
        sbc = revenue * d.sbc_pct_revenue[t] if d.sbc_pct_revenue else 0.0
        capex = revenue * d.capex_pct_revenue[t]
        nwc = revenue * d.nwc_pct_revenue[t]
        change_in_nwc = nwc - nwc_prev
        nwc_prev = nwc
        ufcf = nopat + da - capex - change_in_nwc + (sbc if d.sbc_treatment == "add_back" else 0.0)
        rows.append(
            {
                "revenue": revenue,
                "revenue_growth": d.revenue_growth[t],
                "ebitda": ebitda,
                "ebitda_margin": d.ebitda_margin[t],
                "da": da,
                "ebit": ebit,
                "nol_used": nol_used,
                "cash_taxes": cash_taxes,
                "nopat": nopat,
                "sbc": sbc,
                "capex": capex,
                "nwc": nwc,
                "change_in_nwc": change_in_nwc,
                "unlevered_fcf": ufcf,
            }
        )
    return rows


def run_dcf(i: DCFInputs) -> DCFResult:
    warnings: list[str] = []
    if i.wacc <= i.terminal_growth:
        raise ValueError("WACC must exceed the terminal growth rate for the Gordon growth model")
    rows = project(i.drivers)
    n = len(rows)
    labels = i.year_labels or [f"Year {t + 1}" for t in range(n)]
    stub = stub_fraction(i.valuation_date, i.first_year_end)
    if stub < 1.0:
        warnings.append(
            f"Stub period: only {stub:.0%} of the first projection year is valued (valuation date mid-year)."
        )

    projection: list[ProjectionYear] = []
    elapsed = 0.0
    for t, row in enumerate(rows):
        fraction = stub if t == 0 else 1.0
        time_end = elapsed + fraction
        time = elapsed + fraction / 2 if i.mid_year else time_end
        factor = 1 / (1 + i.wacc) ** time
        fcf_in_period = row["unlevered_fcf"] * fraction
        projection.append(
            ProjectionYear(
                label=labels[t],
                **row,
                period_fraction=fraction,
                discount_time=time,
                discount_factor=factor,
                pv_fcf=fcf_in_period * factor,
            )
        )
        elapsed = time_end
    sum_pv = sum(p.pv_fcf for p in projection)
    final = projection[-1]
    tv_factor = 1 / (1 + i.wacc) ** elapsed

    tv_gordon = final.unlevered_fcf * (1 + i.terminal_growth) / (i.wacc - i.terminal_growth)
    tv_exit = final.ebitda * i.exit_multiple
    implied_multiple = tv_gordon / final.ebitda if final.ebitda > 0 else None
    implied_growth = (tv_exit * i.wacc - final.unlevered_fcf) / (tv_exit + final.unlevered_fcf)
    gordon = TerminalValue(
        method="Gordon growth", value=tv_gordon, pv=tv_gordon * tv_factor, implied_cross_check=implied_multiple
    )
    exit_tv = TerminalValue(
        method="Exit multiple", value=tv_exit, pv=tv_exit * tv_factor, implied_cross_check=implied_growth
    )
    tv_pv = {"gordon": gordon.pv, "exit_multiple": exit_tv.pv, "average": (gordon.pv + exit_tv.pv) / 2}[
        i.terminal_method
    ]

    ev = sum_pv + tv_pv
    tv_share = tv_pv / ev if ev > 0 else float("nan")
    if ev > 0 and tv_share > 0.75:
        warnings.append(
            f"Terminal value is {tv_share:.0%} of enterprise value (above 75%): the result rests on the "
            "long-term assumptions."
        )
    if i.risk_free_rate is not None and i.terminal_growth >= i.risk_free_rate:
        warnings.append(
            "Terminal growth is at or above the risk-free rate, which implies the company outgrows the economy forever."
        )
    if final.unlevered_fcf <= 0:
        warnings.append("Final-year free cash flow is not positive; the Gordon terminal value is not meaningful.")
    if implied_multiple is not None and abs(implied_multiple - i.exit_multiple) / i.exit_multiple > 0.3:
        warnings.append(
            f"Gordon terminal value implies {implied_multiple:.1f}x EBITDA versus the {i.exit_multiple:.1f}x exit "
            "multiple; the two terminal methods disagree by more than 30%."
        )

    bridge = ev_to_equity(ev, i.bridge)
    per_share = value_per_share(bridge.equity_value, i.dilution) if i.dilution else None
    return DCFResult(
        projection=projection,
        sum_pv_fcf=sum_pv,
        gordon=gordon,
        exit=exit_tv,
        terminal_method=i.terminal_method,
        terminal_value_pv=tv_pv,
        enterprise_value=ev,
        terminal_share_of_ev=tv_share,
        bridge=bridge,
        equity_value=bridge.equity_value,
        per_share=per_share,
        warnings=warnings,
    )


# ── sensitivities and scenarios ─────────────────────────────────────────────
class SensitivityTable(BaseModel):
    title: str
    row_label: str
    col_label: str
    rows: list[float]
    cols: list[float]
    values: list[list[float | None]]  # enterprise value (or None when not computable)
    output: Literal["enterprise_value", "equity_value"] = "enterprise_value"


def _safe_ev(i: DCFInputs) -> float | None:
    try:
        return run_dcf(i).enterprise_value
    except ValueError:
        return None


def sensitivity_wacc_growth(i: DCFInputs, wacc_steps: list[float], growth_steps: list[float]) -> SensitivityTable:
    rows = [i.wacc + s for s in wacc_steps]
    cols = [i.terminal_growth + s for s in growth_steps]
    values = [
        [_safe_ev(i.model_copy(update={"wacc": w, "terminal_growth": g, "terminal_method": "gordon"})) for g in cols]
        for w in rows
    ]
    return SensitivityTable(
        title="EV: WACC × terminal growth (Gordon)",
        row_label="WACC",
        col_label="Terminal growth",
        rows=rows,
        cols=cols,
        values=values,
    )


def sensitivity_wacc_exit(i: DCFInputs, wacc_steps: list[float], multiple_steps: list[float]) -> SensitivityTable:
    rows = [i.wacc + s for s in wacc_steps]
    cols = [i.exit_multiple + s for s in multiple_steps]
    values = [
        [
            _safe_ev(i.model_copy(update={"wacc": w, "exit_multiple": m, "terminal_method": "exit_multiple"}))
            for m in cols
        ]
        for w in rows
    ]
    return SensitivityTable(
        title="EV: WACC × exit multiple",
        row_label="WACC",
        col_label="Exit EV/EBITDA",
        rows=rows,
        cols=cols,
        values=values,
    )


def shift_drivers(d: ProjectionDrivers, growth_shift: float = 0.0, margin_shift: float = 0.0) -> ProjectionDrivers:
    return d.model_copy(
        update={
            "revenue_growth": [g + growth_shift for g in d.revenue_growth],
            "ebitda_margin": [m + margin_shift for m in d.ebitda_margin],
        }
    )


def sensitivity_growth_margin(i: DCFInputs, growth_shifts: list[float], margin_shifts: list[float]) -> SensitivityTable:
    values = [
        [_safe_ev(i.model_copy(update={"drivers": shift_drivers(i.drivers, g, m)})) for m in margin_shifts]
        for g in growth_shifts
    ]
    return SensitivityTable(
        title="EV: revenue growth × EBITDA margin (shift to every year)",
        row_label="Growth shift",
        col_label="Margin shift",
        rows=growth_shifts,
        cols=margin_shifts,
        values=values,
    )


MAX_SCENARIOS = 6


class Scenario(BaseModel):
    """A named case: shifts applied to every projection year (growth, margin) and to the valuation inputs.

    Rates and shifts are decimals (0.02 = +2pp); the exit multiple shift is in turns of EBITDA (1.0 = +1.0x).
    """

    name: str = Field(min_length=1, max_length=40)
    probability: float = Field(ge=0, le=1)
    growth_shift: float = Field(default=0.0, ge=-0.5, le=0.5)
    margin_shift: float = Field(default=0.0, ge=-0.5, le=0.5)
    wacc_shift: float = Field(default=0.0, ge=-0.2, le=0.2)
    exit_multiple_shift: float = Field(default=0.0, ge=-50, le=50)
    terminal_growth_shift: float = Field(default=0.0, ge=-0.1, le=0.1)


def default_scenarios() -> list[Scenario]:
    """Bear / base / bull: growth and margin ±2pp in every year, weighted 25 / 50 / 25 (a stated convention)."""
    return [
        Scenario(name="bear", probability=0.25, growth_shift=-0.02, margin_shift=-0.02),
        Scenario(name="base", probability=0.50),
        Scenario(name="bull", probability=0.25, growth_shift=0.02, margin_shift=0.02),
    ]


def validate_scenarios(scenarios: list[Scenario]) -> list[Scenario]:
    """1 to 6 scenarios with distinct names whose probabilities sum to 100% (within 0.01pp)."""
    if not 1 <= len(scenarios) <= MAX_SCENARIOS:
        raise ValueError(f"define between 1 and {MAX_SCENARIOS} scenarios")
    names = [s.name.strip().lower() for s in scenarios]
    repeated = sorted({s.name for s in scenarios if names.count(s.name.strip().lower()) > 1})
    if repeated:
        raise ValueError(f"give each scenario its own name (repeated: {', '.join(repeated)})")
    total_p = sum(s.probability for s in scenarios)
    if abs(total_p - 1.0) > 1e-4:
        raise ValueError(f"scenario probabilities must sum to 100% (they sum to {total_p:.2%})")
    return scenarios


def apply_scenario(i: DCFInputs, s: Scenario) -> DCFInputs:
    """The DCF inputs of one scenario (the base inputs with the scenario's shifts applied)."""
    return i.model_copy(
        update={
            "drivers": shift_drivers(i.drivers, s.growth_shift, s.margin_shift),
            "wacc": i.wacc + s.wacc_shift,
            "exit_multiple": i.exit_multiple + s.exit_multiple_shift,
            "terminal_growth": i.terminal_growth + s.terminal_growth_shift,
        }
    )


class ScenarioResult(BaseModel):
    name: str
    probability: float
    enterprise_value: float
    equity_value: float
    wacc: float | None = None
    terminal_growth: float | None = None
    exit_multiple: float | None = None


class ScenarioSummary(BaseModel):
    scenarios: list[ScenarioResult]
    probability_weighted_ev: float
    probability_weighted_equity: float


def run_scenarios(i: DCFInputs, scenarios: list[Scenario]) -> ScenarioSummary:
    validate_scenarios(scenarios)
    results = []
    for s in scenarios:
        variant = apply_scenario(i, s)
        if variant.wacc <= 0:
            raise ValueError(f"scenario {s.name!r}: WACC after the shift must stay above 0%")
        if variant.exit_multiple <= 0:
            raise ValueError(f"scenario {s.name!r}: the exit multiple after the shift must stay above 0x")
        try:
            r = run_dcf(variant)
        except ValueError as error:
            raise ValueError(f"scenario {s.name!r}: {error}") from error
        results.append(
            ScenarioResult(
                name=s.name,
                probability=s.probability,
                enterprise_value=r.enterprise_value,
                equity_value=r.equity_value,
                wacc=variant.wacc,
                terminal_growth=variant.terminal_growth,
                exit_multiple=variant.exit_multiple,
            )
        )
    return ScenarioSummary(
        scenarios=results,
        probability_weighted_ev=sum(r.probability * r.enterprise_value for r in results),
        probability_weighted_equity=sum(r.probability * r.equity_value for r in results),
    )
