"""Enterprise value ↔ equity value bridge and per-share value with dilution (brief §7, §9.2).

Conventions (toggles documented in docs/methodology.md):
- Debt-like items are deducted from EV; cash-like items are added.
- Only *excess* cash counts: cash − minimum operating cash (floored at zero).
- Lease liabilities, pension deficits and provisions are debt-like when their toggles are on.
- Pension deficits can be taken net of tax (deficit × (1 − tax rate)) because contributions are tax-deductible.
- Per-share value uses the treasury stock method for options/warrants/RSUs and if-converted logic for convertibles,
  iterated because dilution depends on the per-share value itself.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class BridgeInputs(BaseModel):
    gross_debt: float = 0.0
    lease_liabilities: float = 0.0
    include_leases: bool = True
    pension_deficit: float = 0.0
    include_pensions: bool = True
    pension_tax_rate: float | None = Field(default=None, ge=0, le=1)
    preferred_equity: float = 0.0
    minority_interest: float = 0.0
    provisions: float = 0.0
    include_provisions: bool = False
    earn_outs: float = 0.0
    other_debt_like: float = 0.0
    cash: float = 0.0
    minimum_operating_cash: float = Field(default=0.0, ge=0)
    short_term_investments: float = 0.0
    investments_in_associates: float = 0.0
    other_cash_like: float = 0.0


class BridgeItem(BaseModel):
    key: str
    label: str
    amount: float  # signed effect on equity value (debt-like negative, cash-like positive)
    included: bool = True
    note: str | None = None


class BridgeResult(BaseModel):
    enterprise_value: float
    items: list[BridgeItem]
    net_debt_and_adjustments: float  # EV − equity
    equity_value: float


def bridge_items(b: BridgeInputs) -> list[BridgeItem]:
    excess_cash = max(b.cash - b.minimum_operating_cash, 0.0)
    pension = b.pension_deficit * (1 - b.pension_tax_rate) if b.pension_tax_rate is not None else b.pension_deficit
    return [
        BridgeItem(key="gross_debt", label="Gross financial debt", amount=-b.gross_debt),
        BridgeItem(
            key="leases",
            label="Lease liabilities",
            amount=-b.lease_liabilities if b.include_leases else 0.0,
            included=b.include_leases,
            note=None if b.include_leases else "Excluded (pre-IFRS 16 basis)",
        ),
        BridgeItem(
            key="pensions",
            label="Pension deficit" + (" (net of tax)" if b.pension_tax_rate is not None else ""),
            amount=-pension if b.include_pensions else 0.0,
            included=b.include_pensions,
        ),
        BridgeItem(key="preferred_equity", label="Preferred equity", amount=-b.preferred_equity),
        BridgeItem(key="minority_interest", label="Non-controlling interests", amount=-b.minority_interest),
        BridgeItem(
            key="provisions",
            label="Provisions treated as debt",
            amount=-b.provisions if b.include_provisions else 0.0,
            included=b.include_provisions,
        ),
        BridgeItem(key="earn_outs", label="Earn-outs / deferred consideration", amount=-b.earn_outs),
        BridgeItem(key="other_debt_like", label="Other debt-like items", amount=-b.other_debt_like),
        BridgeItem(
            key="excess_cash",
            label="Excess cash",
            amount=excess_cash,
            note=f"Cash {b.cash:,.0f} less minimum operating cash {b.minimum_operating_cash:,.0f}"
            if b.minimum_operating_cash
            else None,
        ),
        BridgeItem(key="short_term_investments", label="Short-term investments", amount=b.short_term_investments),
        BridgeItem(key="associates", label="Investments in associates", amount=b.investments_in_associates),
        BridgeItem(key="other_cash_like", label="Other cash-like items", amount=b.other_cash_like),
    ]


def ev_to_equity(enterprise_value: float, b: BridgeInputs) -> BridgeResult:
    items = bridge_items(b)
    adjustment = sum(i.amount for i in items)
    return BridgeResult(
        enterprise_value=enterprise_value,
        items=items,
        net_debt_and_adjustments=-adjustment,
        equity_value=enterprise_value + adjustment,
    )


def equity_to_ev(equity_value: float, b: BridgeInputs) -> float:
    """Inverse of :func:`ev_to_equity` (used to turn P/E-based equity values into EV)."""
    return equity_value - sum(i.amount for i in bridge_items(b))


# ── dilution ──────────────────────────────────────────────────────────────
class OptionTranche(BaseModel):
    label: str = "Options"
    kind: Literal["option", "warrant", "rsu"] = "option"
    number: float = Field(ge=0)
    strike: float = Field(default=0.0, ge=0)  # 0 for RSUs / PSUs


class Convertible(BaseModel):
    label: str = "Convertible"
    principal: float = Field(ge=0)  # included in gross debt in the bridge
    conversion_price: float = Field(gt=0)

    @property
    def shares_on_conversion(self) -> float:
        return self.principal / self.conversion_price


class DilutionInputs(BaseModel):
    basic_shares: float = Field(gt=0)
    options: list[OptionTranche] = []
    convertibles: list[Convertible] = []


class DilutionLine(BaseModel):
    label: str
    method: Literal["treasury_stock", "if_converted"]
    in_the_money: bool
    gross_shares: float
    net_new_shares: float


class PerShareResult(BaseModel):
    equity_value: float
    value_per_share: float
    basic_shares: float
    diluted_shares: float
    converted_principal_added_back: float
    lines: list[DilutionLine]
    iterations: int


def diluted_shares_at_price(price: float, d: DilutionInputs) -> tuple[float, float, list[DilutionLine]]:
    """Diluted share count at a given share price, and principal of convertibles that convert."""
    shares = d.basic_shares
    lines: list[DilutionLine] = []
    for o in d.options:
        itm = price > o.strike
        new = o.number - (o.number * o.strike / price) if itm and price > 0 else 0.0
        shares += new
        lines.append(
            DilutionLine(
                label=o.label, method="treasury_stock", in_the_money=itm, gross_shares=o.number, net_new_shares=new
            )
        )
    principal_back = 0.0
    for c in d.convertibles:
        itm = price > c.conversion_price
        new = c.shares_on_conversion if itm else 0.0
        if itm:
            principal_back += c.principal
        shares += new
        lines.append(
            DilutionLine(
                label=c.label,
                method="if_converted",
                in_the_money=itm,
                gross_shares=c.shares_on_conversion,
                net_new_shares=new,
            )
        )
    return shares, principal_back, lines


def value_per_share(
    equity_value: float, d: DilutionInputs, *, max_iter: int = 100, tol: float = 1e-9
) -> PerShareResult:
    """Solve p = (equity + converted principal) ÷ diluted shares(p) by fixed-point iteration."""
    if equity_value <= 0:
        return PerShareResult(
            equity_value=equity_value,
            value_per_share=equity_value / d.basic_shares,
            basic_shares=d.basic_shares,
            diluted_shares=d.basic_shares,
            converted_principal_added_back=0.0,
            lines=[],
            iterations=0,
        )
    price = equity_value / d.basic_shares
    for iteration in range(1, max_iter + 1):  # noqa: B007 - reported after the loop
        shares, principal_back, lines = diluted_shares_at_price(price, d)
        new_price = (equity_value + principal_back) / shares
        if abs(new_price - price) <= tol * max(1.0, abs(price)):
            price = new_price
            break
        # damping avoids oscillation when a convertible flips in/out of the money
        price = 0.5 * price + 0.5 * new_price
    shares, principal_back, lines = diluted_shares_at_price(price, d)
    return PerShareResult(
        equity_value=equity_value,
        value_per_share=price,
        basic_shares=d.basic_shares,
        diluted_shares=shares,
        converted_principal_added_back=principal_back,
        lines=lines,
        iterations=iteration,
    )
