"""Strategic-buyer analysis and other reference values (brief §9.7).

* Synergies: run-rate cost and revenue synergies phased in, less one-off integration costs, taxed, haircut for the
  probability of delivery and discounted — the value a buyer could pay away.
* Accretion / dilution: the buyer's pro-forma EPS after an acquisition funded with cash, new debt and/or shares.
* Liquidation value: book values × recovery rates by asset class, less liabilities and wind-down costs.
* Replacement cost: cost to rebuild the asset base, less physical, functional and economic obsolescence.
* Discount for lack of marketability (DLOM): applied to private-company equity values (the user supplies the rate).
"""

from __future__ import annotations

from statistics import median
from typing import Literal

from pydantic import BaseModel, Field, model_validator

from .summary import MethodRange


def run_rate_synergy_ebitda(cost_synergies: float, revenue_synergies: float, revenue_synergy_margin: float) -> float:
    """Run-rate pre-tax synergies: cost synergies plus the EBITDA earned on synergy revenue."""
    return cost_synergies + revenue_synergies * revenue_synergy_margin


class SynergyInputs(BaseModel):
    cost_synergies: float = Field(default=0.0, ge=0)  # run-rate, pre-tax, per year
    revenue_synergies: float = Field(default=0.0, ge=0)  # run-rate revenue
    revenue_synergy_margin: float = Field(default=0.0, ge=0, le=1)  # EBITDA margin on synergy revenue
    phasing: list[float] = Field(default_factory=lambda: [0.33, 0.67, 1.0])  # share of run-rate achieved per year
    integration_costs: list[float] = Field(default_factory=list)  # one-off, per year (positive numbers)
    tax_rate: float = Field(ge=0, le=1)
    discount_rate: float = Field(gt=0)
    terminal_growth: float = 0.0
    probability: float = Field(default=1.0, ge=0, le=1)  # haircut for delivery risk
    share_paid_away: float = Field(default=0.0, ge=0, le=1)

    @model_validator(mode="after")
    def _phasing(self) -> SynergyInputs:
        if not self.phasing or any(not 0 <= p <= 1.5 for p in self.phasing):
            raise ValueError("phasing must list the share of run-rate synergies achieved in each year")
        return self


class SynergyResult(BaseModel):
    rows: list[dict[str, float]]
    pv_explicit: float
    pv_terminal: float
    value_before_probability: float
    value: float  # after the probability haircut
    paid_away: float  # premium the buyer would pay out of synergies
    retained: float


def run_synergies(i: SynergyInputs) -> SynergyResult:
    years = max(len(i.phasing), len(i.integration_costs))
    rows = []
    pv = 0.0
    after_tax = 0.0
    run_rate_ebitda = run_rate_synergy_ebitda(i.cost_synergies, i.revenue_synergies, i.revenue_synergy_margin)
    for t in range(years):
        phase = i.phasing[t] if t < len(i.phasing) else i.phasing[-1]
        ebitda = run_rate_ebitda * phase
        integration = i.integration_costs[t] if t < len(i.integration_costs) else 0.0
        after_tax = (ebitda - integration) * (1 - i.tax_rate)
        factor = (1 + i.discount_rate) ** -(t + 1)
        pv += after_tax * factor
        rows.append(
            {
                "year": t + 1,
                "synergy_ebitda": ebitda,
                "integration_costs": integration,
                "after_tax": after_tax,
                "pv": after_tax * factor,
            }
        )
    steady = run_rate_ebitda * (i.phasing[-1]) * (1 - i.tax_rate)
    if i.discount_rate <= i.terminal_growth:
        raise ValueError("the discount rate must exceed the terminal growth rate")
    terminal = steady * (1 + i.terminal_growth) / (i.discount_rate - i.terminal_growth)
    pv_terminal = terminal * (1 + i.discount_rate) ** -years
    gross = pv + pv_terminal
    value = gross * i.probability
    paid = value * i.share_paid_away
    return SynergyResult(
        rows=rows,
        pv_explicit=pv,
        pv_terminal=pv_terminal,
        value_before_probability=gross,
        value=value,
        paid_away=paid,
        retained=value - paid,
    )


def strategic_value(standalone: tuple[float, float, float], synergy_value: float) -> tuple[float, float, float]:
    """The most a strategic buyer could pay: each standalone value plus the risked value of synergies."""
    low, mid, high = standalone
    return low + synergy_value, mid + synergy_value, high + synergy_value


class AccretionInputs(BaseModel):
    acquirer_net_income: float
    acquirer_shares: float = Field(gt=0)
    acquirer_share_price: float = Field(gt=0)
    target_net_income: float
    purchase_equity_value: float = Field(gt=0)  # price paid for the target's equity
    cash_share: float = Field(default=0.0, ge=0, le=1)
    debt_share: float = Field(default=0.0, ge=0, le=1)
    stock_share: float = Field(default=0.0, ge=0, le=1)
    interest_on_new_debt: float = Field(default=0.0, ge=0)
    foregone_interest_on_cash: float = Field(default=0.0, ge=0)
    tax_rate: float = Field(ge=0, le=1)
    pre_tax_synergies: float = 0.0
    amortisation_of_intangibles: float = Field(default=0.0, ge=0)  # pre-tax, from the purchase price allocation
    transaction_costs: float = Field(default=0.0, ge=0)  # funded with the cash portion

    @model_validator(mode="after")
    def _mix(self) -> AccretionInputs:
        if abs(self.cash_share + self.debt_share + self.stock_share - 1) > 1e-6:
            raise ValueError("cash, debt and stock shares of the consideration must add up to 100%")
        return self


class AccretionResult(BaseModel):
    standalone_eps: float
    pro_forma_net_income: float
    new_shares: float
    pro_forma_shares: float
    pro_forma_eps: float
    accretion: float  # pro-forma EPS / standalone EPS − 1
    breakeven_synergies: float | None  # pre-tax synergies at which the deal is EPS-neutral


def run_accretion(i: AccretionInputs) -> AccretionResult:
    standalone = i.acquirer_net_income / i.acquirer_shares
    price = i.purchase_equity_value
    debt = price * i.debt_share
    cash = price * i.cash_share + i.transaction_costs
    new_shares = price * i.stock_share / i.acquirer_share_price

    def pro_forma_income(synergies: float) -> float:
        pre_tax = (
            synergies
            - debt * i.interest_on_new_debt
            - cash * i.foregone_interest_on_cash
            - i.amortisation_of_intangibles
        )
        return i.acquirer_net_income + i.target_net_income + pre_tax * (1 - i.tax_rate)

    shares = i.acquirer_shares + new_shares
    income = pro_forma_income(i.pre_tax_synergies)
    eps = income / shares
    # EPS-neutral synergies: solve standalone × shares = pro-forma income(s) for s (linear in s)
    gap = standalone * shares - pro_forma_income(0.0)
    breakeven = gap / (1 - i.tax_rate) if i.tax_rate < 1 else None
    return AccretionResult(
        standalone_eps=standalone,
        pro_forma_net_income=income,
        new_shares=new_shares,
        pro_forma_shares=shares,
        pro_forma_eps=eps,
        accretion=eps / standalone - 1,
        breakeven_synergies=breakeven,
    )


class RecoveryLine(BaseModel):
    name: str = Field(max_length=120)
    book_value: float = Field(ge=0)
    recovery_low: float = Field(ge=0, le=1.5)
    recovery_high: float = Field(ge=0, le=1.5)


class LiquidationInputs(BaseModel):
    assets: list[RecoveryLine]
    liabilities: float = Field(ge=0)  # claims ranking ahead of equity, at face value
    wind_down_costs: float = Field(default=0.0, ge=0)


class LiquidationResult(BaseModel):
    proceeds_low: float
    proceeds_high: float
    equity_low: float
    equity_high: float
    rows: list[dict[str, float | str]]


def run_liquidation(i: LiquidationInputs) -> LiquidationResult:
    rows: list[dict[str, float | str]] = []
    low = high = 0.0
    for a in i.assets:
        lo, hi = a.book_value * a.recovery_low, a.book_value * a.recovery_high
        low += lo
        high += hi
        rows.append({"name": a.name, "book_value": a.book_value, "low": lo, "high": hi})
    deduct = i.liabilities + i.wind_down_costs
    # equity cannot be negative: shareholders are not liable beyond their investment
    return LiquidationResult(
        proceeds_low=low,
        proceeds_high=high,
        equity_low=max(low - deduct, 0.0),
        equity_high=max(high - deduct, 0.0),
        rows=rows,
    )


class ReplacementLine(BaseModel):
    name: str = Field(max_length=120)
    replacement_cost: float = Field(ge=0)
    physical_obsolescence: float = Field(default=0.0, ge=0, le=1)
    functional_obsolescence: float = Field(default=0.0, ge=0, le=1)
    economic_obsolescence: float = Field(default=0.0, ge=0, le=1)

    def value(self) -> float:
        return (
            self.replacement_cost
            * (1 - self.physical_obsolescence)
            * (1 - self.functional_obsolescence)
            * (1 - self.economic_obsolescence)
        )


def replacement_value(lines: list[ReplacementLine]) -> float:
    """Depreciated replacement cost of the asset base (an enterprise-level value)."""
    return sum(line.value() for line in lines)


class DLOM(BaseModel):
    """A discount for lack of marketability; the rate comes from the user (no default is invented)."""

    low: float = Field(ge=0, lt=1)
    mid: float = Field(ge=0, lt=1)
    high: float = Field(ge=0, lt=1)
    applies_to: Literal["all_methods", "market_methods"] = "market_methods"

    def apply(self, equity: float, point: Literal["low", "mid", "high"]) -> float:
        # a higher discount lowers value: the high discount applies to the low end of the range
        rate = {"low": self.high, "mid": self.mid, "high": self.low}[point]
        return equity * (1 - rate)


MARKET_METHODS = frozenset(
    {"comps_ev_revenue", "comps_ev_ebitda", "comps_ev_ebit", "comps_pe", "comps_pb"}
    | {"comps_ev_ebitdar", "comps_peg", "comps_ev_arr", "comps_p_nav"}
)


def apply_dlom(ranges: list[MethodRange], dlom: DLOM) -> list[MethodRange]:
    """Apply a private-company marketability discount to market-based methods (or to every method)."""
    out = []
    for r in ranges:
        if dlom.applies_to == "all_methods" or r.method_id in MARKET_METHODS:
            note = f"After a {dlom.mid:.0%} discount for lack of marketability ({dlom.low:.0%}–{dlom.high:.0%})."
            out.append(
                r.model_copy(
                    update={
                        "equity_low": dlom.apply(r.equity_low, "low"),
                        "equity_mid": dlom.apply(r.equity_mid, "mid"),
                        "equity_high": dlom.apply(r.equity_high, "high"),
                        "note": f"{r.note} {note}" if r.note else note,
                    }
                )
            )
        else:
            out.append(r)
    return out


class MarketPoint(BaseModel):
    label: str
    price: float | None  # per share
    equity: float  # for all shares


def market_reference_points(
    shares: float | None,
    *,
    high_52w: float | None = None,
    low_52w: float | None = None,
    vwap: dict[str, float | None] | None = None,
    analyst_targets: list[float] | None = None,
) -> list[MarketPoint]:
    """Listed-target reference points (brief §9.7), as per-share prices and equity values for all shares."""
    if not shares:
        return []
    points = [("52-week high", high_52w), ("52-week low", low_52w), *((vwap or {}).items())]
    out = [MarketPoint(label=label, price=price, equity=price * shares) for label, price in points if price]
    if analyst_targets:
        target = median(analyst_targets)
        out.append(MarketPoint(label="Median analyst target", price=target, equity=target * shares))
    return out
