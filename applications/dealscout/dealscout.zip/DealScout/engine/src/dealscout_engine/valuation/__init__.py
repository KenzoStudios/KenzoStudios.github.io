"""Valuation methods. Each module exposes typed inputs, typed outputs and pure functions."""
