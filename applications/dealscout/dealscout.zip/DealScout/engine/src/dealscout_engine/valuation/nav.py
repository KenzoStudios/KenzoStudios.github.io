"""Net asset value and sum-of-the-parts (brief §9.6).

NAV starts from the book balance sheet and revalues each asset and liability with its own method: an appraisal, a
capitalisation rate on net operating income, a multiple of a metric, a recent transaction price, or book value.
Deferred tax on revaluation gains is deducted (optional), then an optional holding-company discount.

SOTP values each segment with its own multiple (or a value entered directly), adds non-core assets, deducts
capitalised corporate costs and the net debt bridge, then an optional conglomerate discount.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

from .bridge import BridgeInputs, ev_to_equity

ValuationMethod = Literal["book", "appraisal", "cap_rate", "multiple", "transaction"]


class NAVLine(BaseModel):
    name: str = Field(max_length=120)
    side: Literal["asset", "liability"] = "asset"
    book_value: float = 0.0
    method: ValuationMethod = "book"
    fair_value: float | None = None  # appraisal or transaction price
    noi: float | None = None  # cap-rate method: net operating income
    cap_rate: float | None = Field(default=None, gt=0, lt=1)
    metric: float | None = None  # multiple method
    multiple: float | None = Field(default=None, gt=0)
    taxable: bool = True  # revaluation gain attracts deferred tax

    def value(self) -> float:
        if self.method == "book":
            return self.book_value
        if self.method in ("appraisal", "transaction"):
            if self.fair_value is None:
                raise ValueError(
                    f"{self.name}: enter the {'appraised' if self.method == 'appraisal' else 'transaction'} value"
                )
            return self.fair_value
        if self.method == "cap_rate":
            if self.noi is None or self.cap_rate is None:
                raise ValueError(f"{self.name}: enter the net operating income and the cap rate")
            return self.noi / self.cap_rate
        if self.metric is None or self.multiple is None:
            raise ValueError(f"{self.name}: enter the metric and the multiple")
        return self.metric * self.multiple


class NAVInputs(BaseModel):
    lines: list[NAVLine]
    deferred_tax_on_gains: bool = True
    tax_rate: float = Field(default=0.0, ge=0, le=1)
    holding_discount: float = Field(default=0.0, ge=0, lt=1)
    shares: float | None = Field(default=None, gt=0)
    share_price: float | None = Field(default=None, gt=0)


class NAVLineResult(BaseModel):
    name: str
    side: str
    book_value: float
    fair_value: float
    revaluation: float
    method: str


class NAVResult(BaseModel):
    lines: list[NAVLineResult]
    book_nav: float
    revaluation_gain: float
    deferred_tax: float
    nav_before_discount: float
    holding_discount: float
    nav: float
    nav_per_share: float | None
    premium_to_nav: float | None  # share price vs NAV per share (negative = discount)


def run_nav(i: NAVInputs) -> NAVResult:
    rows: list[NAVLineResult] = []
    book = fair = taxable_gain = 0.0
    for line in i.lines:
        value = line.value()
        sign = 1.0 if line.side == "asset" else -1.0
        book += sign * line.book_value
        fair += sign * value
        gain = sign * (value - line.book_value)
        if line.taxable:
            taxable_gain += gain
        rows.append(
            NAVLineResult(
                name=line.name,
                side=line.side,
                book_value=line.book_value,
                fair_value=value,
                revaluation=value - line.book_value,
                method=line.method,
            )
        )
    deferred_tax = max(taxable_gain, 0.0) * i.tax_rate if i.deferred_tax_on_gains else 0.0
    before = fair - deferred_tax
    discount = before * i.holding_discount if before > 0 else 0.0
    nav = before - discount
    per_share = nav / i.shares if i.shares else None
    premium = (i.share_price / per_share - 1) if per_share and i.share_price else None
    return NAVResult(
        lines=rows,
        book_nav=book,
        revaluation_gain=fair - book,
        deferred_tax=deferred_tax,
        nav_before_discount=before,
        holding_discount=discount,
        nav=nav,
        nav_per_share=per_share,
        premium_to_nav=premium,
    )


class Segment(BaseModel):
    name: str = Field(max_length=120)
    metric_label: str = "EBITDA"
    metric: float | None = None
    multiple_low: float | None = Field(default=None, gt=0)
    multiple_mid: float | None = Field(default=None, gt=0)
    multiple_high: float | None = Field(default=None, gt=0)
    value: float | None = None  # a value from another method (e.g. a separate DCF) instead of a multiple

    def values(self) -> tuple[float, float, float]:
        if self.value is not None:
            return self.value, self.value, self.value
        if self.metric is None or self.multiple_mid is None:
            raise ValueError(f"{self.name}: enter the metric and at least the mid multiple, or a value")
        lo = self.multiple_low if self.multiple_low is not None else self.multiple_mid
        hi = self.multiple_high if self.multiple_high is not None else self.multiple_mid
        return self.metric * lo, self.metric * self.multiple_mid, self.metric * hi


class SOTPInputs(BaseModel):
    segments: list[Segment]
    non_core_assets: float = 0.0
    corporate_costs: float = Field(default=0.0, ge=0)  # annual unallocated head-office cost
    corporate_cost_multiple: float = Field(default=0.0, ge=0)  # capitalised at this multiple
    conglomerate_discount: float = Field(default=0.0, ge=0, lt=1)
    bridge: BridgeInputs = BridgeInputs()


class SOTPResult(BaseModel):
    segments: list[dict[str, float | str]]
    gross_ev: tuple[float, float, float]
    corporate_costs_capitalised: float
    non_core_assets: float
    ev_before_discount: tuple[float, float, float]
    conglomerate_discount: tuple[float, float, float]
    ev: tuple[float, float, float]
    equity: tuple[float, float, float]


def run_sotp(i: SOTPInputs) -> SOTPResult:
    rows: list[dict[str, float | str]] = []
    totals = [0.0, 0.0, 0.0]
    for s in i.segments:
        lo, mid, hi = s.values()
        rows.append({"name": s.name, "low": lo, "mid": mid, "high": hi})
        totals = [totals[0] + lo, totals[1] + mid, totals[2] + hi]
    corporate = i.corporate_costs * i.corporate_cost_multiple
    before = tuple(t - corporate + i.non_core_assets for t in totals)
    discount = tuple(max(b, 0.0) * i.conglomerate_discount for b in before)
    ev = tuple(b - d for b, d in zip(before, discount, strict=True))
    equity = tuple(ev_to_equity(e, i.bridge).equity_value for e in ev)
    return SOTPResult(
        segments=rows,
        gross_ev=(totals[0], totals[1], totals[2]),
        corporate_costs_capitalised=corporate,
        non_core_assets=i.non_core_assets,
        ev_before_discount=before,
        conglomerate_discount=discount,
        ev=ev,
        equity=equity,
    )
