"""Football field and blended valuation range (brief §10, basic version for Milestone 2).

Each method contributes a low / mid / high equity value. The blended range is the weight-averaged low, mid and high
of the included methods (weights are normalised to 100%). Per-share figures use the diluted share count at each value.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from .bridge import DilutionInputs, value_per_share


class MethodRange(BaseModel):
    method_id: str
    label: str
    equity_low: float
    equity_mid: float
    equity_high: float
    ev_low: float | None = None
    ev_mid: float | None = None
    ev_high: float | None = None
    weight: float = Field(default=1.0, ge=0)
    included: bool = True
    note: str | None = None


class PerShareRange(BaseModel):
    low: float
    mid: float
    high: float


class FootballField(BaseModel):
    methods: list[MethodRange]
    weights_normalised: dict[str, float]
    blended_equity_low: float | None
    blended_equity_mid: float | None
    blended_equity_high: float | None
    blended_per_share: PerShareRange | None
    method_per_share: dict[str, PerShareRange]
    market_cap: float | None
    share_price: float | None
    warnings: list[str]


def football_field(
    methods: list[MethodRange],
    *,
    dilution: DilutionInputs | None = None,
    market_cap: float | None = None,
    share_price: float | None = None,
) -> FootballField:
    warnings: list[str] = []
    active = [m for m in methods if m.included and m.weight > 0]
    total_weight = sum(m.weight for m in active)
    weights = {m.method_id: (m.weight / total_weight if total_weight else 0.0) for m in active}

    def per_share(value: float) -> float | None:
        return value_per_share(value, dilution).value_per_share if dilution else None

    method_ps: dict[str, PerShareRange] = {}
    if dilution:
        for m in methods:
            lo, mid, hi = per_share(m.equity_low), per_share(m.equity_mid), per_share(m.equity_high)
            if lo is not None and mid is not None and hi is not None:
                method_ps[m.method_id] = PerShareRange(low=lo, mid=mid, high=hi)

    for m in methods:
        if not m.equity_low <= m.equity_mid <= m.equity_high:
            warnings.append(f"{m.label}: low, mid and high are not in ascending order.")
    if not active:
        return FootballField(
            methods=methods,
            weights_normalised={},
            blended_equity_low=None,
            blended_equity_mid=None,
            blended_equity_high=None,
            blended_per_share=None,
            method_per_share=method_ps,
            market_cap=market_cap,
            share_price=share_price,
            warnings=[*warnings, "No method is included with a positive weight."],
        )
    low = sum(weights[m.method_id] * m.equity_low for m in active)
    mid = sum(weights[m.method_id] * m.equity_mid for m in active)
    high = sum(weights[m.method_id] * m.equity_high for m in active)
    blended_ps = None
    if dilution:
        lo_ps, mid_ps, hi_ps = per_share(low), per_share(mid), per_share(high)
        if lo_ps is not None and mid_ps is not None and hi_ps is not None:
            blended_ps = PerShareRange(low=lo_ps, mid=mid_ps, high=hi_ps)
    mids = [m.equity_mid for m in active]
    if len(mids) > 1 and max(mids) > 2 * min(mids) > 0:
        warnings.append(
            "Method mid-points differ by more than a factor of two; review the assumptions behind the outliers."
        )
    return FootballField(
        methods=methods,
        weights_normalised=weights,
        blended_equity_low=low,
        blended_equity_mid=mid,
        blended_equity_high=high,
        blended_per_share=blended_ps,
        method_per_share=method_ps,
        market_cap=market_cap,
        share_price=share_price,
        warnings=warnings,
    )
