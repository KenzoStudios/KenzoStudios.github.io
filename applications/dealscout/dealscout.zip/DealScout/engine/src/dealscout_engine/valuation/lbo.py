"""Leveraged buyout analysis (brief §9.5): sources & uses, debt schedule with cash sweep, covenants, exit and returns,
and the maximum entry price that still meets a target IRR / MOIC — a primary input to the acquisition price.

Conventions (docs/methodology.md):

* Annual periods; the deal closes at the start of projection year 1 and exits at the end of ``exit_year``.
* Purchase: enterprise value = entry multiple × entry EBITDA (or a given EV). Uses = equity purchase price
  (EV − existing net debt) + refinanced net debt + transaction fees + financing fees + cash left on the balance sheet.
  Sources = debt tranches + rollover equity + sponsor equity (the plug).
* Operating cash flow before financing = EBITDA − capex − change in NWC − cash taxes, taxes on EBIT after all
  interest (cash and PIK). Interest is charged on the average balance (an iterative solve of the circularity) or,
  with ``interest_on_average=False``, on the opening balance.
* Each year: cash interest and mandatory amortisation are paid first; excess cash above the minimum balance sweeps
  prepayable tranches in priority order; a shortfall is drawn on the revolver (if any) and otherwise flagged.
* Exit equity = exit multiple × exit-year EBITDA − debt outstanding (PIK included) + cash, less exit costs.
  Sponsor and rollover holders share equity pro rata to what they invested, after any management promote.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, model_validator

from .bridge import BridgeInputs, equity_to_ev
from .returns import irr, moic

TrancheKind = Literal[
    "revolver", "term_loan_a", "term_loan_b", "senior_notes", "high_yield", "mezzanine", "seller_note", "other"
]
_PREPAYABLE = {"revolver", "term_loan_a", "term_loan_b", "other"}


class Tranche(BaseModel):
    name: str = Field(max_length=60)
    kind: TrancheKind = "term_loan_b"
    size_x_ebitda: float | None = Field(default=None, ge=0)  # × entry EBITDA
    amount: float | None = Field(default=None, ge=0)  # or an absolute amount
    rate_type: Literal["fixed", "floating"] = "floating"
    fixed_rate: float | None = Field(default=None, ge=0, le=1)
    margin: float | None = Field(default=None, ge=0, le=1)  # over the base rate
    base_rate_floor: float = Field(default=0.0, ge=0, le=1)
    amortization_pct: float = Field(default=0.0, ge=0, le=1)  # of original principal per year
    pik: bool = False  # interest accrues to principal instead of being paid in cash
    sweep: bool | None = None  # prepayable from excess cash; default by kind
    priority: int = Field(default=1, ge=0)  # lower is repaid first in the sweep
    fee_pct: float = Field(default=0.0, ge=0, le=0.2)  # financing fee, % of principal, paid at close
    commitment: float | None = Field(default=None, ge=0)  # revolver facility size (drawn only when needed)

    @property
    def sweepable(self) -> bool:
        return self.sweep if self.sweep is not None else self.kind in _PREPAYABLE

    def principal(self, entry_ebitda: float) -> float:
        if self.kind == "revolver" and self.amount is None and self.size_x_ebitda is None:
            return 0.0
        if self.amount is not None:
            return self.amount
        return (self.size_x_ebitda or 0.0) * entry_ebitda

    def rate(self, base_rate: float) -> float:
        if self.rate_type == "fixed":
            if self.fixed_rate is None:
                raise ValueError(f"{self.name}: enter the fixed interest rate")
            return self.fixed_rate
        if self.margin is None:
            raise ValueError(f"{self.name}: enter the margin over the base rate")
        return max(base_rate, self.base_rate_floor) + self.margin


class OperatingYear(BaseModel):
    """One projection year of the operating case (normally the DCF projection)."""

    label: str
    revenue: float
    ebitda: float
    da: float
    capex: float = Field(ge=0)
    change_in_nwc: float = 0.0


class LBOInputs(BaseModel):
    entry_ebitda: float = Field(gt=0)
    entry_multiple: float | None = Field(default=None, gt=0)
    entry_ev: float | None = Field(default=None, gt=0)
    existing_net_debt: float = 0.0  # refinanced at close (debt repaid less cash acquired)
    transaction_fee_pct: float = Field(default=0.0, ge=0, le=0.2)  # of EV
    minimum_cash: float = Field(default=0.0, ge=0)
    tranches: list[Tranche] = Field(default_factory=list)
    rollover_equity: float = Field(default=0.0, ge=0)
    management_promote_pct: float = Field(default=0.0, ge=0, le=0.5)  # share of exit equity to management
    operating: list[OperatingYear]
    tax_rate: float = Field(ge=0, le=1)
    base_rate: float = Field(default=0.0, ge=0, le=1)
    base_rate_curve: list[float] | None = None  # per year, overrides base_rate
    interest_on_average: bool = True
    cash_sweep_pct: float = Field(default=1.0, ge=0, le=1)
    exit_year: int = Field(default=5, ge=1)
    exit_multiple: float | None = Field(default=None, gt=0)  # default: the entry multiple
    exit_cost_pct: float = Field(default=0.0, ge=0, le=0.1)  # of exit EV
    dividend_recap_year: int | None = Field(default=None, ge=1)
    dividend_recap_x_ebitda: float = Field(default=0.0, ge=0)  # extra debt raised for a dividend
    max_leverage: float | None = Field(default=None, gt=0)  # covenant: net debt / EBITDA
    min_interest_coverage: float | None = Field(default=None, gt=0)  # covenant: EBITDA / cash interest
    target_irr: float = Field(default=0.20, gt=-1)
    target_moic: float | None = Field(default=None, gt=0)

    @model_validator(mode="after")
    def _check(self) -> LBOInputs:
        names = [t.name.strip().lower() for t in self.tranches]
        duplicates = sorted({t.name for t in self.tranches if names.count(t.name.strip().lower()) > 1})
        if duplicates:
            # schedules are tracked per tranche name: two tranches with one name would merge their balances
            raise ValueError(f"give each tranche its own name (repeated: {', '.join(duplicates)})")
        if self.entry_multiple is None and self.entry_ev is None:
            raise ValueError("enter the entry multiple or the entry enterprise value")
        if self.exit_year > len(self.operating):
            raise ValueError("the exit year is beyond the projection")
        if self.dividend_recap_year is not None and self.dividend_recap_year >= self.exit_year:
            raise ValueError("a dividend recap must come before the exit year")
        return self

    @property
    def ev(self) -> float:
        return self.entry_ev if self.entry_ev is not None else (self.entry_multiple or 0.0) * self.entry_ebitda

    @property
    def multiple(self) -> float:
        return self.ev / self.entry_ebitda


class SourceUse(BaseModel):
    label: str
    amount: float


class TrancheYear(BaseModel):
    name: str
    opening: float
    drawn: float
    interest_cash: float
    interest_pik: float
    mandatory: float
    sweep: float
    closing: float
    rate: float


class ScheduleYear(BaseModel):
    label: str
    ebitda: float
    capex: float
    change_in_nwc: float
    cash_taxes: float
    operating_cash_flow: float  # before financing
    cash_interest: float
    pik_interest: float
    mandatory_repayment: float
    sweep: float
    revolver_draw: float
    dividend: float
    closing_cash: float
    total_debt: float
    net_debt: float
    leverage: float | None  # net debt / EBITDA
    interest_coverage: float | None  # EBITDA / cash interest
    tranches: list[TrancheYear]
    breaches: list[str]


class Returns(BaseModel):
    equity_invested: float
    proceeds: float
    irr: float | None
    moic: float | None
    cash_flows: list[float]


class LBOResult(BaseModel):
    entry_ev: float
    entry_multiple: float
    equity_purchase_price: float
    sources: list[SourceUse]
    uses: list[SourceUse]
    total_debt_at_close: float
    leverage_at_close: float
    schedule: list[ScheduleYear]
    exit_multiple: float
    exit_ev: float
    exit_net_debt: float
    exit_equity: float
    sponsor: Returns
    rollover: Returns | None
    covenant_breaches: list[str]
    warnings: list[str]


def _sources_uses(i: LBOInputs) -> tuple[list[SourceUse], list[SourceUse], dict[str, float], float]:
    ev = i.ev
    principals = {t.name: t.principal(i.entry_ebitda) for t in i.tranches}
    financing_fees = sum(principals[t.name] * t.fee_pct for t in i.tranches)
    transaction_fees = ev * i.transaction_fee_pct
    equity_price = ev - i.existing_net_debt
    uses = [
        SourceUse(label="Purchase of equity", amount=equity_price),
        SourceUse(label="Refinance existing net debt", amount=i.existing_net_debt),
        SourceUse(label="Transaction fees", amount=transaction_fees),
        SourceUse(label="Financing fees", amount=financing_fees),
        SourceUse(label="Cash to balance sheet", amount=i.minimum_cash),
    ]
    total_uses = sum(u.amount for u in uses)
    debt = sum(principals.values())
    sponsor = total_uses - debt - i.rollover_equity
    sources = [SourceUse(label=f"{t.name}", amount=principals[t.name]) for t in i.tranches if principals[t.name] > 0]
    if i.rollover_equity:
        sources.append(SourceUse(label="Rollover equity", amount=i.rollover_equity))
    sources.append(SourceUse(label="Sponsor equity", amount=sponsor))
    return sources, uses, principals, sponsor


def _year(
    i: LBOInputs, t: int, op: OperatingYear, opening: dict[str, float], cash: float, original: dict[str, float]
) -> tuple[ScheduleYear, dict[str, float], float]:
    base = i.base_rate_curve[t] if i.base_rate_curve and t < len(i.base_rate_curve) else i.base_rate
    rates = {tr.name: tr.rate(base) for tr in i.tranches}
    recap = (
        i.dividend_recap_x_ebitda * op.ebitda
        if i.dividend_recap_year is not None and t + 1 == i.dividend_recap_year
        else 0.0
    )
    recap_tranche = next((tr.name for tr in i.tranches if tr.kind in ("term_loan_b", "term_loan_a")), None)
    closing = dict(opening)
    result: ScheduleYear | None = None
    for _iteration in range(60):
        balances = {
            name: ((opening[name] + closing[name]) / 2 if i.interest_on_average else opening[name]) for name in opening
        }
        cash_interest = sum(balances[tr.name] * rates[tr.name] for tr in i.tranches if not tr.pik)
        pik_interest = sum(balances[tr.name] * rates[tr.name] for tr in i.tranches if tr.pik)
        taxable = op.ebitda - op.da - cash_interest - pik_interest
        cash_taxes = max(taxable, 0.0) * i.tax_rate
        operating = op.ebitda - op.capex - op.change_in_nwc - cash_taxes
        new_closing = dict(opening)
        tranche_rows: dict[str, dict[str, float]] = {
            tr.name: {"drawn": 0.0, "mandatory": 0.0, "sweep": 0.0, "pik": 0.0, "cash": 0.0} for tr in i.tranches
        }
        for tr in i.tranches:
            interest = balances[tr.name] * rates[tr.name]
            if tr.pik:
                new_closing[tr.name] += interest
                tranche_rows[tr.name]["pik"] = interest
            else:
                tranche_rows[tr.name]["cash"] = interest
        if recap and recap_tranche:
            new_closing[recap_tranche] += recap
            tranche_rows[recap_tranche]["drawn"] += recap
        mandatory = 0.0
        for tr in i.tranches:
            due = min(original[tr.name] * tr.amortization_pct, new_closing[tr.name])
            new_closing[tr.name] -= due
            tranche_rows[tr.name]["mandatory"] = due
            mandatory += due
        available = cash + operating - cash_interest - mandatory  # before sweep, revolver and recap dividend
        excess = available - i.minimum_cash
        revolver_draw = 0.0
        swept = 0.0
        if excess < 0:
            revolver = next((tr for tr in i.tranches if tr.kind == "revolver"), None)
            if revolver is not None:
                room = (revolver.commitment or 0.0) - new_closing[revolver.name]
                revolver_draw = min(-excess, max(room, 0.0))
                new_closing[revolver.name] += revolver_draw
                tranche_rows[revolver.name]["drawn"] += revolver_draw
            closing_cash = available + revolver_draw
        else:
            to_sweep = excess * i.cash_sweep_pct
            for tr in sorted(
                (tr for tr in i.tranches if tr.sweepable), key=lambda tr: (tr.priority, tr.kind != "revolver")
            ):
                pay = min(to_sweep, new_closing[tr.name])
                new_closing[tr.name] -= pay
                tranche_rows[tr.name]["sweep"] = pay
                to_sweep -= pay
                swept += pay
            closing_cash = available - swept
        total_debt = sum(new_closing.values())
        net_debt = total_debt - closing_cash
        leverage = net_debt / op.ebitda if op.ebitda > 0 else None
        coverage = op.ebitda / cash_interest if cash_interest > 0 else None
        breaches = []
        if i.max_leverage is not None and leverage is not None and leverage > i.max_leverage:
            breaches.append(f"{op.label}: leverage {leverage:.2f}x above the {i.max_leverage:.2f}x covenant")
        if i.min_interest_coverage is not None and coverage is not None and coverage < i.min_interest_coverage:
            breaches.append(
                f"{op.label}: interest cover {coverage:.2f}x below the {i.min_interest_coverage:.2f}x covenant"
            )
        result = ScheduleYear(
            label=op.label,
            ebitda=op.ebitda,
            capex=op.capex,
            change_in_nwc=op.change_in_nwc,
            cash_taxes=cash_taxes,
            operating_cash_flow=operating,
            cash_interest=cash_interest,
            pik_interest=pik_interest,
            mandatory_repayment=mandatory,
            sweep=swept,
            revolver_draw=revolver_draw,
            dividend=recap,
            closing_cash=closing_cash,
            total_debt=total_debt,
            net_debt=net_debt,
            leverage=leverage,
            interest_coverage=coverage,
            tranches=[
                TrancheYear(
                    name=tr.name,
                    opening=opening[tr.name],
                    drawn=tranche_rows[tr.name]["drawn"],
                    interest_cash=tranche_rows[tr.name]["cash"],
                    interest_pik=tranche_rows[tr.name]["pik"],
                    mandatory=tranche_rows[tr.name]["mandatory"],
                    sweep=tranche_rows[tr.name]["sweep"],
                    closing=new_closing[tr.name],
                    rate=rates[tr.name],
                )
                for tr in i.tranches
            ],
            breaches=breaches,
        )
        converged = all(abs(new_closing[k] - closing[k]) < 1e-6 for k in closing)
        closing = new_closing
        if not i.interest_on_average or converged:
            break
    assert result is not None
    # the recap dividend leaves the company: it is paid out of the new debt, not retained as cash
    return result, closing, result.closing_cash


def entry_ev_from_price(price_per_share: float, shares: float, bridge: BridgeInputs) -> float:
    """Entry enterprise value implied by an offer price per share: equity for all shares plus the net debt bridge."""
    return equity_to_ev(price_per_share * shares, bridge)


def run_lbo(i: LBOInputs) -> LBOResult:
    warnings: list[str] = []
    sources, uses, principals, sponsor_equity = _sources_uses(i)
    if sponsor_equity <= 0:
        raise ValueError("debt and rollover cover the whole purchase: there is no sponsor equity to earn a return")
    if not i.tranches:
        warnings.append("No debt tranches entered: the returns are unlevered.")
    balances = {t.name: principals[t.name] for t in i.tranches}
    original = dict(balances)
    cash = i.minimum_cash
    schedule: list[ScheduleYear] = []
    for t in range(i.exit_year):
        row, balances, cash = _year(i, t, i.operating[t], balances, cash, original)
        schedule.append(row)
        if row.closing_cash < -1e-6:
            warnings.append(f"{row.label}: cash shortfall of {-row.closing_cash:,.0f} with no revolver capacity left.")
    exit_ebitda = i.operating[i.exit_year - 1].ebitda
    exit_multiple = i.exit_multiple if i.exit_multiple is not None else i.multiple
    exit_ev = exit_multiple * exit_ebitda
    exit_debt = sum(balances.values())
    exit_net_debt = exit_debt - cash
    exit_equity = exit_ev * (1 - i.exit_cost_pct) - exit_net_debt
    if exit_equity < 0:
        warnings.append("Exit equity is negative: the debt is worth more than the business at exit.")
    distributable = max(exit_equity, 0.0) * (1 - i.management_promote_pct)
    invested = sponsor_equity + i.rollover_equity
    sponsor_share = sponsor_equity / invested

    def returns(share: float, equity: float) -> Returns:
        flows = [-equity] + [row.dividend * share for row in schedule]
        flows[-1] += distributable * share
        proceeds = sum(flows[1:])
        return Returns(
            equity_invested=equity, proceeds=proceeds, irr=irr(flows), moic=moic(equity, proceeds), cash_flows=flows
        )

    sponsor = returns(sponsor_share, sponsor_equity)
    rollover = returns(1 - sponsor_share, i.rollover_equity) if i.rollover_equity else None
    breaches = [b for row in schedule for b in row.breaches]
    total_debt = sum(principals.values())
    return LBOResult(
        entry_ev=i.ev,
        entry_multiple=i.multiple,
        equity_purchase_price=i.ev - i.existing_net_debt,
        sources=sources,
        uses=uses,
        total_debt_at_close=total_debt,
        leverage_at_close=total_debt / i.entry_ebitda,
        schedule=schedule,
        exit_multiple=exit_multiple,
        exit_ev=exit_ev,
        exit_net_debt=exit_net_debt,
        exit_equity=exit_equity,
        sponsor=sponsor,
        rollover=rollover,
        covenant_breaches=breaches,
        warnings=warnings,
    )


class MaxPrice(BaseModel):
    target_irr: float
    target_moic: float | None
    entry_multiple: float | None
    entry_ev: float | None
    equity_purchase_price: float | None
    note: str | None = None


def max_entry_price(i: LBOInputs, *, target_irr: float | None = None, target_moic: float | None = None) -> MaxPrice:
    """The highest entry multiple whose sponsor returns still meet the target IRR (and MOIC, if set).

    Debt stays sized as entered (× entry EBITDA), and the exit multiple is held at the case's exit multiple, so a
    higher price only means more equity. Solved by bisection between 0.5x and 50x EBITDA.
    """
    irr_target = i.target_irr if target_irr is None else target_irr
    moic_target = i.target_moic if target_moic is None else target_moic
    exit_multiple = i.exit_multiple if i.exit_multiple is not None else i.multiple

    def meets(multiple: float) -> bool:
        case = i.model_copy(update={"entry_multiple": multiple, "entry_ev": None, "exit_multiple": exit_multiple})
        try:
            r = run_lbo(case).sponsor
        except ValueError:
            return True  # debt alone covers this price: any return target is met trivially
        ok = r.irr is not None and r.irr >= irr_target
        if moic_target is not None:
            ok = ok and r.moic is not None and r.moic >= moic_target
        return ok

    low, high = 0.5, 50.0
    if not meets(low):
        return MaxPrice(
            target_irr=irr_target,
            target_moic=moic_target,
            entry_multiple=None,
            entry_ev=None,
            equity_purchase_price=None,
            note="No entry price meets the target with this financing.",
        )
    if meets(high):
        return MaxPrice(
            target_irr=irr_target,
            target_moic=moic_target,
            entry_multiple=None,
            entry_ev=None,
            equity_purchase_price=None,
            note="The target is met even at 50x EBITDA; check the inputs.",
        )
    for _ in range(80):
        mid = (low + high) / 2
        if meets(mid):
            low = mid
        else:
            high = mid
    ev = low * i.entry_ebitda
    return MaxPrice(
        target_irr=irr_target,
        target_moic=moic_target,
        entry_multiple=low,
        entry_ev=ev,
        equity_purchase_price=ev - i.existing_net_debt,
    )


class IRRGrid(BaseModel):
    title: str
    row_label: str
    col_label: str
    rows: list[float]
    cols: list[float]
    values: list[list[float | None]]  # sponsor IRR


def sensitivity_entry_exit(i: LBOInputs, entry_shifts: list[float], exit_shifts: list[float]) -> IRRGrid:
    base_exit = i.exit_multiple if i.exit_multiple is not None else i.multiple
    rows = [i.multiple + s for s in entry_shifts]
    cols = [base_exit + s for s in exit_shifts]
    values: list[list[float | None]] = []
    for entry in rows:
        line: list[float | None] = []
        for exit_multiple in cols:
            try:
                case = i.model_copy(update={"entry_multiple": entry, "entry_ev": None, "exit_multiple": exit_multiple})
                line.append(run_lbo(case).sponsor.irr if entry > 0 and exit_multiple > 0 else None)
            except ValueError:
                line.append(None)
        values.append(line)
    return IRRGrid(
        title="Sponsor IRR: entry × exit multiple",
        row_label="Entry EV/EBITDA",
        col_label="Exit EV/EBITDA",
        rows=rows,
        cols=cols,
        values=values,
    )


def sensitivity_leverage_exit(i: LBOInputs, leverage_factors: list[float], exit_shifts: list[float]) -> IRRGrid:
    """Scale every tranche by a factor (0.8 = 20% less debt) against the exit multiple."""
    base_exit = i.exit_multiple if i.exit_multiple is not None else i.multiple
    base_leverage = sum(t.principal(i.entry_ebitda) for t in i.tranches) / i.entry_ebitda
    rows = [base_leverage * f for f in leverage_factors]
    cols = [base_exit + s for s in exit_shifts]
    values: list[list[float | None]] = []
    for factor in leverage_factors:
        scaled = [
            t.model_copy(
                update={
                    "amount": t.amount * factor if t.amount is not None else None,
                    "size_x_ebitda": t.size_x_ebitda * factor if t.size_x_ebitda is not None else None,
                }
            )
            for t in i.tranches
        ]
        line: list[float | None] = []
        for exit_multiple in cols:
            try:
                case = i.model_copy(update={"tranches": scaled, "exit_multiple": exit_multiple})
                line.append(run_lbo(case).sponsor.irr)
            except ValueError:
                line.append(None)
        values.append(line)
    return IRRGrid(
        title="Sponsor IRR: leverage × exit multiple",
        row_label="Total debt / EBITDA",
        col_label="Exit EV/EBITDA",
        rows=rows,
        cols=cols,
        values=values,
    )
