"""Equity-based methods for financial institutions and leveraged situations (brief §9.1, §9.2).

Banks and insurers are valued on equity, not enterprise value: their debt is raw material, not financing. This module
provides the dividend discount model (two-stage), residual income (book value plus the present value of returns above
the cost of equity), free cash flow to equity, and adjusted present value (APV) for highly leveraged companies.
All values are equity values unless the result says otherwise.
"""

from __future__ import annotations

from pydantic import BaseModel, Field, model_validator


def _gordon(next_cash_flow: float, rate: float, growth: float) -> float:
    if rate <= growth:
        raise ValueError("the discount rate must exceed the terminal growth rate")
    return next_cash_flow / (rate - growth)


class DDMInputs(BaseModel):
    """Two-stage dividend discount: dividends grow at ``high_growth`` for ``years``, then at ``terminal_growth``."""

    current_dividend: float = Field(ge=0)  # total dividends paid in the last year (or per share)
    high_growth: float
    years: int = Field(ge=0, le=30)
    terminal_growth: float
    cost_of_equity: float = Field(gt=0)


class ValueResult(BaseModel):
    value: float
    pv_explicit: float
    pv_terminal: float
    terminal_share: float
    rows: list[dict[str, float]]


def run_ddm(i: DDMInputs) -> ValueResult:
    rows = []
    dividend = i.current_dividend
    pv = 0.0
    for t in range(1, i.years + 1):
        dividend *= 1 + i.high_growth
        factor = (1 + i.cost_of_equity) ** -t
        pv += dividend * factor
        rows.append({"year": t, "dividend": dividend, "discount_factor": factor, "pv": dividend * factor})
    terminal = _gordon(dividend * (1 + i.terminal_growth), i.cost_of_equity, i.terminal_growth)
    pv_terminal = terminal * (1 + i.cost_of_equity) ** -i.years
    value = pv + pv_terminal
    return ValueResult(
        value=value,
        pv_explicit=pv,
        pv_terminal=pv_terminal,
        terminal_share=pv_terminal / value if value else 0.0,
        rows=rows,
    )


class ResidualIncomeInputs(BaseModel):
    """Equity = book value + Σ PV(net income − cost of equity × opening book value) + terminal residual income.

    Each year's net income is ``roe`` × opening book value; book value grows by retained earnings
    (net income × (1 − payout)). The terminal residual income grows at ``terminal_growth`` (0 = held flat).
    """

    book_value: float = Field(gt=0)
    roe: list[float]
    payout_ratio: float = Field(ge=0, le=1)
    cost_of_equity: float = Field(gt=0)
    terminal_growth: float = 0.0

    @model_validator(mode="after")
    def _years(self) -> ResidualIncomeInputs:
        if not 1 <= len(self.roe) <= 30:
            raise ValueError("enter between 1 and 30 years of return on equity")
        return self


def run_residual_income(i: ResidualIncomeInputs) -> ValueResult:
    book = i.book_value
    pv = 0.0
    rows = []
    residual = 0.0
    for t, roe in enumerate(i.roe, start=1):
        income = roe * book
        residual = income - i.cost_of_equity * book
        factor = (1 + i.cost_of_equity) ** -t
        pv += residual * factor
        rows.append(
            {
                "year": t,
                "opening_book": book,
                "net_income": income,
                "residual_income": residual,
                "discount_factor": factor,
                "pv": residual * factor,
            }
        )
        book += income * (1 - i.payout_ratio)
    n = len(i.roe)
    terminal = _gordon(residual * (1 + i.terminal_growth), i.cost_of_equity, i.terminal_growth)
    pv_terminal = terminal * (1 + i.cost_of_equity) ** -n
    value = i.book_value + pv + pv_terminal
    return ValueResult(
        value=value,
        pv_explicit=pv,
        pv_terminal=pv_terminal,
        terminal_share=pv_terminal / value if value else 0.0,
        rows=rows,
    )


class FCFEInputs(BaseModel):
    """FCFE = net income + D&A − capex − change in NWC + net borrowing, discounted at the cost of equity."""

    net_income: list[float]
    da: list[float]
    capex: list[float]
    change_in_nwc: list[float]
    net_borrowing: list[float]
    cost_of_equity: float = Field(gt=0)
    terminal_growth: float

    @model_validator(mode="after")
    def _lengths(self) -> FCFEInputs:
        n = len(self.net_income)
        if n < 1 or any(len(x) != n for x in (self.da, self.capex, self.change_in_nwc, self.net_borrowing)):
            raise ValueError("every FCFE line needs one value per projection year")
        return self


def run_fcfe(i: FCFEInputs) -> ValueResult:
    pv = 0.0
    rows = []
    fcfe = 0.0
    for t in range(len(i.net_income)):
        fcfe = i.net_income[t] + i.da[t] - i.capex[t] - i.change_in_nwc[t] + i.net_borrowing[t]
        factor = (1 + i.cost_of_equity) ** -(t + 1)
        pv += fcfe * factor
        rows.append({"year": t + 1, "fcfe": fcfe, "discount_factor": factor, "pv": fcfe * factor})
    n = len(i.net_income)
    terminal = _gordon(fcfe * (1 + i.terminal_growth), i.cost_of_equity, i.terminal_growth)
    pv_terminal = terminal * (1 + i.cost_of_equity) ** -n
    value = pv + pv_terminal
    return ValueResult(
        value=value,
        pv_explicit=pv,
        pv_terminal=pv_terminal,
        terminal_share=pv_terminal / value if value else 0.0,
        rows=rows,
    )


class APVInputs(BaseModel):
    """APV = unlevered value (FCFF at the unlevered cost of equity) + PV of interest tax shields − distress costs.

    Tax shields are discounted at the cost of debt during the explicit period; after it, debt is assumed constant and
    the perpetual shield is (debt × tax rate) — the Modigliani–Miller value of permanent debt.
    """

    unlevered_fcf: list[float]
    unlevered_cost_of_equity: float = Field(gt=0)
    terminal_growth: float
    debt_balances: list[float]  # opening debt each year
    cost_of_debt: float = Field(gt=0)
    tax_rate: float = Field(ge=0, le=1)
    expected_distress_cost: float = Field(default=0.0, ge=0)

    @model_validator(mode="after")
    def _lengths(self) -> APVInputs:
        if not self.unlevered_fcf or len(self.debt_balances) != len(self.unlevered_fcf):
            raise ValueError("enter one debt balance per projection year")
        return self


class APVResult(BaseModel):
    unlevered_value: float
    pv_tax_shields: float
    distress_cost: float
    enterprise_value: float


def run_apv(i: APVInputs) -> APVResult:
    n = len(i.unlevered_fcf)
    pv = sum(fcf * (1 + i.unlevered_cost_of_equity) ** -(t + 1) for t, fcf in enumerate(i.unlevered_fcf))
    terminal = _gordon(i.unlevered_fcf[-1] * (1 + i.terminal_growth), i.unlevered_cost_of_equity, i.terminal_growth)
    unlevered = pv + terminal * (1 + i.unlevered_cost_of_equity) ** -n
    shields = sum(
        debt * i.cost_of_debt * i.tax_rate * (1 + i.cost_of_debt) ** -(t + 1) for t, debt in enumerate(i.debt_balances)
    )
    shields += i.debt_balances[-1] * i.tax_rate * (1 + i.cost_of_debt) ** -n  # permanent debt after the forecast
    return APVResult(
        unlevered_value=unlevered,
        pv_tax_shields=shields,
        distress_cost=i.expected_distress_cost,
        enterprise_value=unlevered + shields - i.expected_distress_cost,
    )


def unlevered_cost_of_equity(cost_of_equity: float, pre_tax_cost_of_debt: float, debt_weight: float) -> float:
    """Pre-tax WACC as the unlevered cost of equity (Modigliani–Miller with a debt beta consistent with kd)."""
    return (1 - debt_weight) * cost_of_equity + debt_weight * pre_tax_cost_of_debt


def price_to_tangible_book(equity: float, goodwill: float, intangibles: float, multiple: float) -> float:
    """Equity value from a P/TBV multiple: (book equity − goodwill − other intangibles) × multiple."""
    tangible = equity - goodwill - intangibles
    if tangible <= 0:
        raise ValueError("tangible book value is not positive")
    return tangible * multiple
