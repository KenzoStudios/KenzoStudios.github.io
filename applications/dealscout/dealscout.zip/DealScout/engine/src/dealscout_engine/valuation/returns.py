"""Return measures shared by the LBO and other methods: IRR (annual cash flows) and MOIC.

IRR is solved by bisection on the net present value, which is robust for the cash-flow shapes used here (one
investment followed by inflows); it returns None when no rate in the search range makes the NPV zero.
"""

from __future__ import annotations


def npv(rate: float, cash_flows: list[float]) -> float:
    """Net present value of annual cash flows, the first at time 0."""
    return sum(cf / (1 + rate) ** t for t, cf in enumerate(cash_flows))


def irr(cash_flows: list[float], *, low: float = -0.99, high: float = 10.0, tolerance: float = 1e-10) -> float | None:
    """Internal rate of return of annual cash flows (time 0 first). None when there is no sign change."""
    if not cash_flows or all(cf >= 0 for cf in cash_flows) or all(cf <= 0 for cf in cash_flows):
        return None
    f_low, f_high = npv(low, cash_flows), npv(high, cash_flows)
    if f_low * f_high > 0:
        return None
    for _ in range(300):
        mid = (low + high) / 2
        f_mid = npv(mid, cash_flows)
        if abs(f_mid) < tolerance or (high - low) < tolerance:
            return mid
        if f_low * f_mid < 0:
            high, f_high = mid, f_mid
        else:
            low, f_low = mid, f_mid
    return (low + high) / 2


def moic(invested: float, proceeds: float) -> float | None:
    """Multiple on invested capital: everything received ÷ everything invested."""
    return proceeds / invested if invested > 0 else None
