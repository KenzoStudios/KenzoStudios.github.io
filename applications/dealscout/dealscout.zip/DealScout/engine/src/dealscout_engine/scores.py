"""Credit and earnings-quality scores, red flags and one-off adjustments (brief §7, §8).

* Altman Z: the original model for listed manufacturers, Z′ for private companies (book equity instead of market
  value), Z″ for non-manufacturers and emerging-market firms (no sales/assets term).
* Piotroski F-score: nine binary signals of profitability, leverage/liquidity and efficiency (0–9).
* Beneish M-score: eight-variable earnings-manipulation model — indicative only.
* Red flags: rules-based quality-of-earnings checks, each with the metric, threshold, severity and an explanation.
  Flags found in document text (``source="document"``) carry the page and a quote as evidence.
* One-offs: user-confirmed adjustments that turn reported EBITDA/EBIT into adjusted figures.

Where an input is missing the score says so (``missing``) instead of guessing. Retained earnings use the taxonomy's
``reserves`` line, which may include other reserves; this is stated on the result.
"""

from __future__ import annotations

import itertools
from typing import Literal

from pydantic import BaseModel, Field

from .ratios import net_debt
from .statements import FinancialData

Zone = Literal["safe", "grey", "distress"]
Severity = Literal["high", "medium", "none"]


def _get(data: FinancialData, concept: str, period: str) -> float | None:
    return data.get(concept, period)


def _ratio(a: float | None, b: float | None) -> float | None:
    if a is None or b is None or b == 0:
        return None
    return a / b


# ── Altman Z ────────────────────────────────────────────────────────────────
AltmanVariant = Literal["public_manufacturing", "private", "non_manufacturing"]
_ALTMAN = {
    # weights for X1..X5 and the safe / distress thresholds
    "public_manufacturing": ((1.2, 1.4, 3.3, 0.6, 1.0), 2.99, 1.81),
    "private": ((0.717, 0.847, 3.107, 0.420, 0.998), 2.90, 1.23),
    "non_manufacturing": ((6.56, 3.26, 6.72, 1.05, 0.0), 2.60, 1.10),
}


class ScoreResult(BaseModel):
    name: str
    variant: str | None = None
    value: float | None
    zone: str | None = None
    components: dict[str, float | None]
    missing: list[str] = Field(default_factory=list)
    note: str | None = None


def altman_variant(*, listed: bool, sector: str) -> AltmanVariant:
    manufacturing = sector in {
        "industrials",
        "consumer_staples",
        "consumer_discretionary",
        "hardware",
        "chemicals",
        "materials",
        "pharma",
        "mining",
        "energy",
        "autos",
    }
    if not manufacturing:
        return "non_manufacturing"
    return "public_manufacturing" if listed else "private"


def market_capitalisation(
    data: FinancialData, period: str, *, share_price: float | None = None, shares: float | None = None
) -> float | None:
    """Share price × shares outstanding, from the overrides when given, else from the period's data."""
    price = share_price if share_price is not None else data.get("share_price", period)
    count = shares or data.get("shares_outstanding", period)
    return price * count if price and count else None


def altman_z(
    data: FinancialData, period: str, variant: AltmanVariant, *, market_cap: float | None = None
) -> ScoreResult:
    total_assets = _get(data, "total_assets", period)
    current_assets = _get(data, "total_current_assets", period)
    current_liabilities = _get(data, "total_current_liabilities", period)
    retained = _get(data, "reserves", period)
    ebit = _get(data, "ebit", period)
    liabilities = _get(data, "total_liabilities", period)
    equity = market_cap if variant == "public_manufacturing" else _get(data, "total_equity", period)
    revenue = _get(data, "revenue", period)
    working_capital = (
        current_assets - current_liabilities if current_assets is not None and current_liabilities is not None else None
    )
    x = {
        "X1 working capital / total assets": _ratio(working_capital, total_assets),
        "X2 retained earnings / total assets": _ratio(retained, total_assets),
        "X3 EBIT / total assets": _ratio(ebit, total_assets),
        (
            "X4 market value of equity / total liabilities"
            if variant == "public_manufacturing"
            else "X4 book equity / total liabilities"
        ): _ratio(equity, liabilities),
        "X5 revenue / total assets": _ratio(revenue, total_assets) if variant != "non_manufacturing" else 0.0,
    }
    weights, safe, distress = _ALTMAN[variant]
    missing = [k for k, v in x.items() if v is None]
    note = "Retained earnings are read from reserves, which may include other reserves."
    if variant == "public_manufacturing" and market_cap is None:
        missing.append("market capitalisation (share price × shares)")
    if missing:
        return ScoreResult(name="Altman Z", variant=variant, value=None, components=x, missing=missing, note=note)
    z = sum(w * (v or 0.0) for w, v in zip(weights, x.values(), strict=True))
    zone: Zone = "safe" if z > safe else "distress" if z < distress else "grey"
    return ScoreResult(name="Altman Z", variant=variant, value=z, zone=zone, components=x, note=note)


# ── Piotroski F ─────────────────────────────────────────────────────────────
def piotroski_f(data: FinancialData, period: str, prior: str) -> ScoreResult:
    def roa(p: str) -> float | None:
        return _ratio(_get(data, "net_income", p), _get(data, "total_assets", p))

    def leverage(p: str) -> float | None:
        return _ratio(_get(data, "lt_debt", p), _get(data, "total_assets", p))

    def current_ratio(p: str) -> float | None:
        return _ratio(_get(data, "total_current_assets", p), _get(data, "total_current_liabilities", p))

    def gross_margin(p: str) -> float | None:
        return _ratio(_get(data, "gross_profit", p), _get(data, "revenue", p))

    def turnover(p: str) -> float | None:
        return _ratio(_get(data, "revenue", p), _get(data, "total_assets", p))

    def better(a: float | None, b: float | None, *, lower: bool = False) -> float | None:
        if a is None or b is None:
            return None
        return 1.0 if (a < b if lower else a > b) else 0.0

    ni, cfo, assets = _get(data, "net_income", period), _get(data, "cfo", period), _get(data, "total_assets", period)
    shares, shares_prior = _get(data, "shares_outstanding", period), _get(data, "shares_outstanding", prior)
    signals: dict[str, float | None] = {
        "Positive return on assets": None if roa(period) is None else float((roa(period) or 0) > 0),
        "Positive operating cash flow": None if cfo is None else float(cfo > 0),
        "Return on assets improved": better(roa(period), roa(prior)),
        "Operating cash flow above net income (accruals)": None
        if cfo is None or ni is None or not assets
        else float(cfo > ni),
        "Long-term leverage fell": better(leverage(period), leverage(prior), lower=True),
        "Current ratio improved": better(current_ratio(period), current_ratio(prior)),
        "No new shares issued": None if shares is None or shares_prior is None else float(shares <= shares_prior),
        "Gross margin improved": better(gross_margin(period), gross_margin(prior)),
        "Asset turnover improved": better(turnover(period), turnover(prior)),
    }
    available = [v for v in signals.values() if v is not None]
    missing = [k for k, v in signals.items() if v is None]
    score = sum(available) if available else None
    note = f"{len(available)} of 9 signals could be computed." if missing else None
    zone = None if score is None or missing else ("strong" if score >= 7 else "weak" if score <= 3 else "average")
    return ScoreResult(name="Piotroski F", value=score, zone=zone, components=signals, missing=missing, note=note)


# ── Beneish M ───────────────────────────────────────────────────────────────
BENEISH_THRESHOLD = -1.78


def beneish_m(data: FinancialData, period: str, prior: str) -> ScoreResult:
    def g(concept: str, p: str) -> float | None:
        value = _get(data, concept, p)
        return abs(value) if value is not None and concept in {"cogs", "sga", "depreciation", "da_total"} else value

    def first(*concepts: str, p: str) -> float | None:
        return next((v for v in (g(c, p) for c in concepts) if v is not None), None)

    sales, sales0 = g("revenue", period), g("revenue", prior)
    rec, rec0 = g("receivables", period), g("receivables", prior)
    gp, gp0 = g("gross_profit", period), g("gross_profit", prior)
    ca, ca0 = g("total_current_assets", period), g("total_current_assets", prior)
    ppe, ppe0 = g("ppe", period), g("ppe", prior)
    ta, ta0 = g("total_assets", period), g("total_assets", prior)
    dep, dep0 = first("depreciation", "da_total", p=period), first("depreciation", "da_total", p=prior)
    sga, sga0 = g("sga", period), g("sga", prior)
    cl, cl0 = g("total_current_liabilities", period), g("total_current_liabilities", prior)
    ltd, ltd0 = g("lt_debt", period), g("lt_debt", prior)
    ni, cfo = g("net_income", period), g("cfo", period)

    def q(a: float | None, b: float | None) -> float | None:
        return _ratio(a, b)

    def aq(c: float | None, p: float | None, t: float | None) -> float | None:
        return None if c is None or p is None or not t else 1 - (c + p) / t

    def dr(d: float | None, p: float | None) -> float | None:
        return None if d is None or p is None or d + p == 0 else d / (d + p)

    def lev(c: float | None, debt: float | None, t: float | None) -> float | None:
        return None if c is None or debt is None or not t else (c + debt) / t

    v = {
        "DSRI days' sales in receivables index": q(q(rec, sales), q(rec0, sales0)),
        "GMI gross margin index": q(q(gp0, sales0), q(gp, sales)),
        "AQI asset quality index": q(aq(ca, ppe, ta), aq(ca0, ppe0, ta0)),
        "SGI sales growth index": q(sales, sales0),
        "DEPI depreciation index": q(dr(dep0, ppe0), dr(dep, ppe)),
        "SGAI SG&A index": q(q(sga, sales), q(sga0, sales0)),
        "LVGI leverage index": q(lev(cl, ltd, ta), lev(cl0, ltd0, ta0)),
        "TATA total accruals / total assets": None if ni is None or cfo is None or not ta else (ni - cfo) / ta,
    }
    weights = (0.92, 0.528, 0.404, 0.892, 0.115, -0.172, -0.327, 4.679)
    missing = [k for k, val in v.items() if val is None]
    note = "Indicative only: a statistical screen, not evidence of manipulation."
    if missing:
        return ScoreResult(name="Beneish M", value=None, components=v, missing=missing, note=note)
    m = -4.84 + sum(w * (val or 0.0) for w, val in zip(weights, v.values(), strict=True))
    zone = "flag" if m > BENEISH_THRESHOLD else "no flag"
    return ScoreResult(name="Beneish M", value=m, zone=zone, components=v, note=note)


# ── red flags ────────────────────────────────────────────────────────────────
class FlagEvidence(BaseModel):
    """Where a document-based warning sign was found: the page and a short quote."""

    document_id: str
    filename: str
    page: int
    snippet: str = Field(max_length=240)


class RedFlag(BaseModel):
    id: str
    signal: str
    period: str
    metric: float | None
    threshold: str
    severity: Severity
    explanation: str
    source: Literal["figures", "document"] = "figures"
    evidence: list[FlagEvidence] = Field(default_factory=list)


def _growth(data: FinancialData, concept: str, period: str, prior: str) -> float | None:
    now, before = data.get(concept, period), data.get(concept, prior)
    if now is None or before is None or before == 0:
        return None
    return now / before - 1


def red_flags(data: FinancialData, periods: list[str], *, adjustments: list[Adjustment] | None = None) -> list[RedFlag]:
    """Rules-based quality-of-earnings checks across consecutive annual periods (oldest first)."""
    flags: list[RedFlag] = []
    for prior, period in itertools.pairwise(periods):
        revenue_growth = _growth(data, "revenue", period, prior)
        for concept, name in (("receivables", "Receivables"), ("inventory", "Inventory")):
            g = _growth(data, concept, period, prior)
            if g is not None and revenue_growth is not None and g - revenue_growth > 0.10:
                gap = g - revenue_growth
                flags.append(
                    RedFlag(
                        id=f"{concept}_vs_revenue",
                        signal=f"{name} growing faster than revenue",
                        period=period,
                        metric=gap,
                        threshold="more than 10pp above revenue growth",
                        severity="high" if gap > 0.25 else "medium",
                        explanation=f"{name} grew {g:.0%} against revenue growth of {revenue_growth:.0%}: possible "
                        "aggressive revenue recognition, collection or stock problems.",
                    )
                )
        margin, margin0 = (_ratio(data.get("ebitda", p), data.get("revenue", p)) for p in (period, prior))
        if margin is not None and margin0 is not None and margin0 - margin > 0.03:
            flags.append(
                RedFlag(
                    id="margin_erosion",
                    signal="EBITDA margin erosion",
                    period=period,
                    metric=margin - margin0,
                    threshold="a fall of more than 3pp",
                    severity="high" if margin0 - margin > 0.06 else "medium",
                    explanation=f"EBITDA margin fell from {margin0:.1%} to {margin:.1%}.",
                )
            )
        lev, lev0 = (_ratio(net_debt(data, p), data.get("ebitda", p)) for p in (period, prior))
        if lev is not None and lev0 is not None and lev - lev0 > 1.0:
            flags.append(
                RedFlag(
                    id="rising_leverage",
                    signal="Rising leverage",
                    period=period,
                    metric=lev - lev0,
                    threshold="net debt / EBITDA up by more than 1.0x",
                    severity="high" if lev > 4 else "medium",
                    explanation=f"Net debt / EBITDA rose from {lev0:.1f}x to {lev:.1f}x.",
                )
            )
        intangible_capex = [abs(data.get("capex_intangibles", p) or 0.0) for p in (prior, period)]
        rev = [data.get("revenue", p) for p in (prior, period)]
        if all(rev) and intangible_capex[1] / rev[1] - intangible_capex[0] / rev[0] > 0.02:  # type: ignore[operator]
            flags.append(
                RedFlag(
                    id="capitalised_costs",
                    signal="Rising capitalised costs",
                    period=period,
                    metric=intangible_capex[1] / rev[1] - intangible_capex[0] / rev[0],  # type: ignore[operator]
                    threshold="intangible capex up by more than 2pp of revenue",
                    severity="medium",
                    explanation="More spending is being capitalised as intangible assets, which flatters EBITDA.",
                )
            )
    gaps = [
        p
        for p in periods
        if (ni := data.get("net_income", p)) is not None
        and (cfo := data.get("cfo", p)) is not None
        and ni > 0
        and cfo < 0.7 * ni
    ]
    if len(gaps) >= 2:
        flags.append(
            RedFlag(
                id="cash_conversion",
                signal="Net income persistently above operating cash flow",
                period=gaps[-1],
                metric=float(len(gaps)),
                threshold="operating cash flow below 70% of net income in 2+ years",
                severity="high",
                explanation=f"Weak cash conversion in {', '.join(gaps)}: earnings are not turning into cash.",
            )
        )
    if periods:
        last = periods[-1]
        goodwill, equity = data.get("goodwill", last), data.get("total_equity", last)
        ratio = _ratio(goodwill, equity)
        if ratio is not None and equity and equity > 0 and ratio > 1.0:
            flags.append(
                RedFlag(
                    id="goodwill_vs_equity",
                    signal="Goodwill larger than equity",
                    period=last,
                    metric=ratio,
                    threshold="goodwill above 100% of equity",
                    severity="medium",
                    explanation="An impairment would wipe out book equity; past acquisitions were expensive.",
                )
            )
        ebitda, interest = data.get("ebitda", last), data.get("interest_expense", last)
        cover = _ratio(ebitda, abs(interest) if interest else None)
        if cover is not None and cover < 3.0:
            flags.append(
                RedFlag(
                    id="weak_interest_cover",
                    signal="Weak interest coverage",
                    period=last,
                    metric=cover,
                    threshold="EBITDA / interest below 3.0x",
                    severity="high" if cover < 1.5 else "medium",
                    explanation=f"EBITDA covers interest only {cover:.1f} times.",
                )
            )
    one_off_years = sorted({a.period_key for a in adjustments or [] if a.confirmed})
    if len(one_off_years) >= 3:
        flags.append(
            RedFlag(
                id="frequent_one_offs",
                signal="Frequent one-off items",
                period=one_off_years[-1],
                metric=float(len(one_off_years)),
                threshold="adjustments in 3 or more years",
                severity="medium",
                explanation="Items called one-off recur; some may be part of the normal cost base.",
            )
        )
    return flags


# ── one-off adjustments ──────────────────────────────────────────────────────
AdjustmentCategory = Literal["restructuring", "impairment", "litigation", "disposal_gain", "transaction_costs", "other"]


class Adjustment(BaseModel):
    """A one-off item. ``amount`` is its effect on profit as reported: a cost is negative, a gain positive.

    Adjusting removes it: adjusted = reported − amount. Impairments sit below EBITDA, so by default they adjust
    EBIT only.
    """

    id: str = Field(max_length=40)
    period_key: str = Field(max_length=20)
    label: str = Field(max_length=200)
    category: AdjustmentCategory = "other"
    amount: float
    affects_ebitda: bool | None = None  # default: everything except impairments
    confirmed: bool = False
    source: Literal["user", "ai_suggested"] = "user"
    rationale: str | None = Field(default=None, max_length=1000)
    document_id: str | None = Field(default=None, max_length=40)  # evidence for an AI suggestion
    page: int | None = Field(default=None, ge=1)
    value_as_written: str | None = Field(default=None, max_length=60)

    @property
    def in_ebitda(self) -> bool:
        return self.affects_ebitda if self.affects_ebitda is not None else self.category != "impairment"


class AdjustedMetrics(BaseModel):
    period: str
    reported_ebitda: float | None
    adjusted_ebitda: float | None
    reported_ebit: float | None
    adjusted_ebit: float | None
    ebitda_adjustment: float
    ebit_adjustment: float
    items: list[Adjustment]


def adjusted_metrics(data: FinancialData, period: str, adjustments: list[Adjustment]) -> AdjustedMetrics:
    items = [a for a in adjustments if a.confirmed and a.period_key == period]
    ebitda_adj = -sum(a.amount for a in items if a.in_ebitda)
    ebit_adj = -sum(a.amount for a in items)
    ebitda, ebit = data.get("ebitda", period), data.get("ebit", period)
    return AdjustedMetrics(
        period=period,
        reported_ebitda=ebitda,
        adjusted_ebitda=None if ebitda is None else ebitda + ebitda_adj,
        reported_ebit=ebit,
        adjusted_ebit=None if ebit is None else ebit + ebit_adj,
        ebitda_adjustment=ebitda_adj,
        ebit_adjustment=ebit_adj,
        items=items,
    )


def adjusted_data(data: FinancialData, adjustments: list[Adjustment]) -> FinancialData:
    """A copy of the data with EBITDA and EBIT normalised for the confirmed one-offs of each period."""
    out = FinancialData(taxonomy=data.taxonomy, values=dict(data.values))
    for period in sorted({a.period_key for a in adjustments if a.confirmed}):
        m = adjusted_metrics(data, period, adjustments)
        if m.adjusted_ebitda is not None:
            out.set("ebitda", period, m.adjusted_ebitda)
        if m.adjusted_ebit is not None:
            out.set("ebit", period, m.adjusted_ebit)
    return out
