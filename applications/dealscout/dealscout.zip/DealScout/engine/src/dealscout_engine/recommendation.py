"""Acquisition price recommendation (brief §9.1, §10): method suitability, the suggested price range with its implied
multiples and premia, affordability and synergy checks, a data quality score, and the facts the rationale is written
from. Every number here is computed in code; the AI only phrases bullets around facts it is given.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

from .valuation.bridge import BridgeInputs, BridgeItem, equity_to_ev, ev_to_equity
from .valuation.summary import FootballField

Relevance = Literal["primary", "secondary", "reference", "not_suitable"]
Profile = Literal["growth_tech", "cyclical", "mature", "regulated", "asset_based", "financial", "asset_light_fin"]

METHOD_LABELS = {
    "dcf": "DCF",
    "comps_ev_revenue": "Trading comps: EV / Revenue",
    "comps_ev_ebitda": "Trading comps: EV / EBITDA",
    "comps_ev_ebit": "Trading comps: EV / EBIT",
    "comps_pe": "Trading comps: P / E",
    "comps_pb": "Trading comps: P / B",
    "comps_ev_ebitdar": "Trading comps: EV / EBITDAR",
    "comps_peg": "Trading comps: PEG",
    "comps_ev_arr": "Trading comps: EV / ARR",
    "comps_p_nav": "Trading comps: P / NAV",
    "lbo": "LBO",
    "precedents": "Precedent transactions",
    "nav": "Net asset value",
    "sotp": "Sum of the parts",
    "ddm": "Dividend discount",
    "residual_income": "Residual income",
    "ptbv": "Price / tangible book",
    "fcfe": "FCFE",
    "apv": "Adjusted present value",
    "strategic": "Strategic value (DCF + synergies)",
    "liquidation": "Liquidation value",
    "replacement": "Replacement cost",
}

_WEIGHT = {"primary": 1.0, "secondary": 0.5, "reference": 0.0, "not_suitable": 0.0}

# (relevance, reason) per method and sector profile; anything not listed is a reference point
_PROFILE_RULES: dict[str, dict[str, tuple[Relevance, str]]] = {
    "mature": {
        "dcf": ("primary", "Stable, cash-generative businesses are valued best on their own cash flows."),
        "comps_ev_ebitda": ("primary", "EV / EBITDA is the market's standard yardstick for mature companies."),
        "comps_pe": ("secondary", "P / E cross-checks the equity value where earnings are steady."),
        "comps_ev_revenue": ("reference", "Revenue multiples add little when margins are stable and known."),
        "precedents": ("secondary", "Deal multiples show what buyers have paid, including control."),
        "lbo": ("secondary", "Predictable cash flow supports debt, so sponsor affordability is a real price anchor."),
    },
    "cyclical": {
        "dcf": ("primary", "A DCF can use mid-cycle margins rather than the current point in the cycle."),
        "comps_ev_ebitda": ("primary", "Use EV / EBITDA on mid-cycle earnings; spot multiples swing with the cycle."),
        "comps_ev_revenue": ("secondary", "Revenue multiples are steadier than earnings multiples through the cycle."),
        "precedents": ("secondary", "Deal multiples show what buyers have paid, including control."),
        "replacement": ("secondary", "Asset-heavy cyclicals rarely trade far below the cost of rebuilding them."),
        "lbo": ("secondary", "Sponsor affordability caps the price, but leverage must survive a downturn."),
    },
    "growth_tech": {
        "dcf": ("primary", "Use a long explicit period so growth fades before the terminal value."),
        "comps_ev_revenue": ("primary", "Earnings are small or negative, so revenue multiples carry the market view."),
        "comps_ev_ebitda": ("secondary", "Meaningful only once EBITDA is clearly positive."),
        "precedents": ("secondary", "Deal multiples show what buyers have paid, including control."),
        "lbo": ("reference", "High growth with thin cash flow supports little debt."),
    },
    "regulated": {
        "dcf": ("primary", "Regulated returns make cash flows predictable."),
        "comps_ev_ebitda": ("primary", "EV / EBITDA is the usual market yardstick for utilities and infrastructure."),
        "ddm": ("secondary", "High, stable payouts make dividends a fair proxy for value."),
        "precedents": ("secondary", "Infrastructure deal multiples show what buyers have paid."),
        "lbo": ("secondary", "Stable cash flows support high leverage."),
        "replacement": ("reference", "The regulated asset base often anchors value."),
    },
    "asset_based": {
        "nav": ("primary", "Value sits in the assets, so revalued net assets come first."),
        "sotp": ("primary", "Separate businesses or holdings are valued best one by one."),
        "dcf": ("secondary", "Cash flows cross-check the asset values."),
        "comps_pb": ("secondary", "Price to book compares listed peers on their net assets."),
        "precedents": ("reference", "Deal multiples are less comparable across asset portfolios."),
        "comps_ev_ebitda": ("reference", "EBITDA understates value when gains come from assets."),
    },
    "financial": {
        "ptbv": ("primary", "Banks and insurers are priced on tangible book and its return."),
        "residual_income": ("primary", "Values the return on equity above the cost of equity."),
        "ddm": ("primary", "Capital rules make distributable dividends the cash the owner receives."),
        "comps_pe": ("secondary", "P / E cross-checks earnings power."),
        "comps_pb": ("secondary", "P / B compares listed peers on book value."),
        "dcf": (
            "not_suitable",
            "For financial firms debt is raw material, not financing, so FCFF and WACC break down.",
        ),
        "comps_ev_ebitda": ("not_suitable", "EV and EBITDA are not meaningful for banks and insurers."),
        "comps_ev_revenue": ("not_suitable", "EV is not meaningful for banks and insurers."),
        "lbo": ("not_suitable", "Regulated balance sheets cannot carry acquisition debt."),
    },
    "asset_light_fin": {
        "comps_pe": ("primary", "Asset managers are priced on earnings."),
        "dcf": ("primary", "Fee income is cash-generative and suits a DCF."),
        "comps_ev_ebitda": ("secondary", "EV / EBITDA cross-checks the earnings multiple."),
        "precedents": ("secondary", "Deal multiples show what buyers have paid."),
        "ddm": ("secondary", "High payouts make dividends a fair proxy."),
    },
}


# Sector multiples (brief §9.3): relevant to a few sectors only, so they are set per profile or sector and stay at
# weight 0 (reference) everywhere else. The football field shows them only when they carry a weight.
_PROFILE_RULES["asset_based"]["comps_p_nav"] = (
    "secondary",
    "Listed property companies and holdings trade at a premium or discount to NAV; P / NAV prices that gap.",
)
_PROFILE_RULES["growth_tech"]["comps_peg"] = (
    "reference",
    "PEG adjusts P / E for expected growth; a cross-check once earnings are positive.",
)
_SECTOR_RULES: dict[str, dict[str, tuple[Relevance, str]]] = {
    "software": {
        "comps_ev_arr": (
            "secondary",
            "Subscription software is priced on recurring revenue; EV / ARR applies when ARR is reported.",
        ),
    },
    **{
        sector: {
            "comps_ev_ebitdar": (
                "secondary",
                "Rent-heavy operators are compared before rent, so leasing versus owning sites or fleet does not "
                "distort the multiple.",
            )
        }
        for sector in ("transport", "consumer_discretionary", "healthcare")
    },
}


class Suggestion(BaseModel):
    method_id: str
    label: str
    relevance: Relevance
    weight: float
    reason: str


def suitability(
    profile: str,
    *,
    perspective: str,
    loss_making: bool,
    listed: bool,
    sector: str | None = None,
) -> list[Suggestion]:
    """Suggested relevance and default weight for every method, with the reason (brief §9.1)."""
    rules = dict(_PROFILE_RULES.get(profile, _PROFILE_RULES["mature"]))
    rules.update(_SECTOR_RULES.get(sector or "", {}))
    if loss_making:
        rules["comps_peg"] = ("not_suitable", "Earnings are negative, so PEG gives no value.")
    if loss_making and profile != "financial":
        rules["comps_ev_ebitda"] = ("not_suitable", "EBITDA is negative, so an EBITDA multiple gives no value.")
        rules["comps_pe"] = ("not_suitable", "Earnings are negative, so P / E gives no value.")
        rules["comps_ev_revenue"] = ("primary", "With losses, revenue multiples carry the market view.")
        rules["lbo"] = ("not_suitable", "A loss-making business cannot service acquisition debt.")
    lbo_relevance = rules.get("lbo", ("reference", ""))[0]
    sponsor_case = profile not in ("financial", "growth_tech") and not loss_making
    if perspective == "financial_sponsor" and lbo_relevance in ("secondary", "reference") and sponsor_case:
        rules["lbo"] = ("primary", "For a financial sponsor the price must clear the target return.")
    if perspective == "strategic":
        rules.setdefault(
            "strategic", ("reference", "Shows the most a strategic buyer could pay with all synergies (not weighted).")
        )
    rules.setdefault("liquidation", ("reference", "A floor: what shareholders would get in a wind-down."))
    out = []
    for method_id, label in METHOD_LABELS.items():
        relevance, reason = rules.get(method_id, ("reference", "Shown for reference; not weighted by default."))
        if method_id in ("comps_pe", "comps_pb") and not listed and relevance == "primary":
            relevance = "secondary"
        out.append(
            Suggestion(method_id=method_id, label=label, relevance=relevance, weight=_WEIGHT[relevance], reason=reason)
        )
    return out


# ── recommendation ──────────────────────────────────────────────────────────────
class PremiumRange(BaseModel):
    low: float = Field(ge=-0.5, le=3)
    high: float = Field(ge=-0.5, le=3)
    source: str = "Entered by the analyst"


class PriceCheck(BaseModel):
    label: str
    status: Literal["pass", "warn", "fail", "n/a"]
    detail: str


class Recommendation(BaseModel):
    equity_low: float
    equity_mid: float
    equity_high: float
    per_share: tuple[float, float, float] | None
    ev_low: float
    ev_mid: float
    ev_high: float
    implied: dict[str, tuple[float | None, float | None, float | None]]  # EV/Revenue, EV/EBITDA, P/E at low/mid/high
    premium_to_market: tuple[float, float, float] | None
    premium_to_vwap: tuple[float, float, float] | None
    checks: list[PriceCheck]
    bridge_at_mid: list[BridgeItem]
    high_end_method: str | None
    synergy_paid_away: float | None  # share of risked synergy value paid at the mid price


def _compact(v: float, currency: str) -> str:
    a = abs(v)
    div, suffix = (1e9, "bn") if a >= 1e9 else (1e6, "m") if a >= 1e6 else (1e3, "k") if a >= 1e3 else (1, "")
    text = f"{a / div:,.{0 if a / div >= 100 else 1}f}{suffix}"
    return f"{'−' if v < 0 else ''}{currency + ' ' if currency else ''}{text}"


def _ratio(a: float | None, b: float | None) -> float | None:
    return a / b if a is not None and b not in (None, 0) and b > 0 else None


def recommend(
    ff: FootballField,
    *,
    bridge: BridgeInputs,
    revenue: float | None,
    ebitda: float | None,
    net_income: float | None,
    market_cap: float | None,
    vwap_equity: float | None = None,
    premium_range: PremiumRange | None = None,
    lbo_max_equity: float | None = None,
    lbo_target_irr: float | None = None,
    standalone_equity: float | None = None,
    synergy_value: float | None = None,
    currency: str = "",
) -> Recommendation | None:
    """The suggested offer range is the blended value; checks compare it with the market, the LBO and synergies."""
    if ff.blended_equity_low is None or ff.blended_equity_mid is None or ff.blended_equity_high is None:
        return None
    eq = (ff.blended_equity_low, ff.blended_equity_mid, ff.blended_equity_high)
    ev = tuple(equity_to_ev(e, bridge) for e in eq)
    ps = ff.blended_per_share
    implied = {
        "EV / Revenue": tuple(_ratio(e, revenue) for e in ev),
        "EV / EBITDA": tuple(_ratio(e, ebitda) for e in ev),
        "P / E": tuple(_ratio(e, net_income) for e in eq),
    }
    prem_mkt = tuple(e / market_cap - 1 for e in eq) if market_cap else None
    prem_vwap = tuple(e / vwap_equity - 1 for e in eq) if vwap_equity else None
    checks: list[PriceCheck] = []
    if prem_mkt is not None:
        if premium_range is None:
            checks.append(
                PriceCheck(
                    label="Control premium",
                    status="n/a",
                    detail=f"Mid price is {prem_mkt[1]:+.0%} vs market value; enter a typical premium range.",
                )
            )
        else:
            mid = prem_mkt[1]
            ok = premium_range.low <= mid <= premium_range.high
            checks.append(
                PriceCheck(
                    label="Control premium",
                    status="pass" if ok else "warn",
                    detail=(
                        f"Mid price is {mid:+.0%} vs market value; typical range "
                        f"{premium_range.low:.0%}–{premium_range.high:.0%} ({premium_range.source})."
                    ),
                )
            )
    if lbo_max_equity is not None:
        clears = eq[1] <= lbo_max_equity
        checks.append(
            PriceCheck(
                label="LBO affordability",
                status="pass" if clears else "warn",
                detail=(
                    f"A sponsor can pay up to {_compact(lbo_max_equity, currency)} for "
                    f"{(lbo_target_irr or 0):.0%} IRR with the financing entered; the mid price is "
                    f"{'within' if clears else 'above'} that."
                ),
            )
        )
    paid_away = None
    if synergy_value and standalone_equity is not None:
        paid_away = (eq[1] - standalone_equity) / synergy_value
        status: Literal["pass", "warn", "fail"] = "pass" if paid_away <= 0.5 else "warn" if paid_away <= 1 else "fail"
        checks.append(
            PriceCheck(
                label="Synergies paid away",
                status=status,
                detail=f"The mid price pays away {paid_away:.0%} of the risked synergy value to the seller.",
            )
        )
    weighted = [m for m in ff.methods if m.included and ff.weights_normalised.get(m.method_id, 0) > 0]
    top = max(weighted, key=lambda m: m.equity_high, default=None)
    return Recommendation(
        equity_low=eq[0],
        equity_mid=eq[1],
        equity_high=eq[2],
        per_share=(ps.low, ps.mid, ps.high) if ps else None,
        ev_low=ev[0],
        ev_mid=ev[1],
        ev_high=ev[2],
        implied=implied,
        premium_to_market=prem_mkt,
        premium_to_vwap=prem_vwap,
        checks=checks,
        bridge_at_mid=ev_to_equity(ev[1], bridge).items,
        high_end_method=top.label if top else None,
        synergy_paid_away=paid_away,
    )


# ── data quality ────────────────────────────────────────────────────────────────
class DataQuality(BaseModel):
    score: int  # 0–100
    grade: Literal["A", "B", "C", "D"]
    components: dict[str, float]
    notes: list[str]


def data_quality(
    *,
    value_confidences: list[float],
    assumption_sources: list[str],
    missing_inputs: int,
) -> DataQuality:
    """Score = 50% financial-data confidence + 30% share of assumptions set by the analyst or history (not defaults)
    + 20% completeness. Manually entered values count as confidence 1 (the analyst vouches for them)."""
    conf = sum(value_confidences) / len(value_confidences) if value_confidences else 0.0
    n = len(assumption_sources)
    specific = sum(1 for s in assumption_sources if s in ("user", "historical", "derived")) / n if n else 0.0
    complete = max(0.0, 1 - missing_inputs / max(n, 1))
    score = round(100 * (0.5 * conf + 0.3 * specific + 0.2 * complete))
    grade: Literal["A", "B", "C", "D"] = "A" if score >= 85 else "B" if score >= 70 else "C" if score >= 50 else "D"
    notes = []
    if not value_confidences:
        notes.append("No financial figures entered.")
    elif conf < 0.8:
        notes.append("Some figures were extracted with low confidence; review them on the Review tab.")
    if n and specific < 0.5:
        notes.append("Most assumptions are market defaults or conventions rather than company-specific inputs.")
    if missing_inputs:
        notes.append(f"{missing_inputs} required input(s) are missing.")
    return DataQuality(
        score=score,
        grade=grade,
        components={"data_confidence": conf, "specific_assumptions": specific, "completeness": complete},
        notes=notes,
    )
