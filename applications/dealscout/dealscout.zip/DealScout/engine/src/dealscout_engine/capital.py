"""Capital structure and debt maturity profile (brief §11.10).

Per balance-sheet date:

* financial debt = short-term + long-term borrowings (leases kept apart), lease liabilities (current + non-current),
  book equity (total equity), cash and short-term investments, undrawn committed facilities;
* the maturity profile of borrowings in four buckets (within 1 year, 1 to 2, 2 to 5, after 5 years) as disclosed in
  the maturity note, with the part not covered by the note when the buckets do not add up to the debt.

Liquidity cover = (cash + short-term investments + undrawn facilities) ÷ debt due within one year.
"""

from __future__ import annotations

from pydantic import BaseModel

from .statements import FinancialData

BUCKETS: list[tuple[str, str]] = [
    ("debt_due_within_1y", "Within 1 year"),
    ("debt_due_1_2y", "1 to 2 years"),
    ("debt_due_2_5y", "2 to 5 years"),
    ("debt_due_after_5y", "After 5 years"),
]


class MaturityBucket(BaseModel):
    concept_id: str
    label: str
    amount: float | None


class CapitalStructure(BaseModel):
    period: str
    debt: float | None  # borrowings excluding leases
    leases: float | None
    equity: float | None  # book equity
    cash: float | None  # cash + short-term investments
    undrawn_facilities: float | None
    total_capital: float | None  # debt + leases + equity (positive parts only)
    maturities: list[MaturityBucket]
    maturities_total: float | None
    unallocated_debt: float | None  # debt not covered by the maturity buckets (None when no buckets)
    liquidity_cover: float | None  # (cash + undrawn) ÷ debt due within one year


def _sum(values: list[float | None]) -> float | None:
    present = [v for v in values if v is not None]
    return sum(present) if present else None


def capital_structure(data: FinancialData, period: str) -> CapitalStructure:
    debt = _sum([data.get("st_debt", period), data.get("lt_debt", period)])
    leases = _sum([data.get("current_lease_liabilities", period), data.get("non_current_lease_liabilities", period)])
    equity = data.get("total_equity", period)
    cash = _sum([data.get("cash", period), data.get("st_investments", period)])
    undrawn = data.get("credit_facilities", period)
    parts = [max(v, 0.0) for v in (debt, leases, equity) if v is not None]
    buckets = [MaturityBucket(concept_id=c, label=label, amount=data.get(c, period)) for c, label in BUCKETS]
    total_m = _sum([b.amount for b in buckets])
    unallocated = None if total_m is None or debt is None else debt - total_m
    within = buckets[0].amount
    liquid = _sum([cash, undrawn])
    cover = liquid / within if within and within > 0 and liquid is not None else None
    return CapitalStructure(
        period=period,
        debt=debt,
        leases=leases,
        equity=equity,
        cash=cash,
        undrawn_facilities=undrawn,
        total_capital=sum(parts) if parts else None,
        maturities=buckets,
        maturities_total=total_m,
        unallocated_debt=unallocated,
        liquidity_cover=cover,
    )
