"""Period model and LTM (last twelve months) construction."""

from __future__ import annotations

from datetime import date
from typing import Literal

from pydantic import BaseModel, model_validator

from .derivation import Derivation, DerivationInput

PeriodKind = Literal["annual", "half_year", "quarter", "ytd", "ltm", "projection", "instant"]


class Period(BaseModel):
    """A reporting period. ``id`` is stable and human-readable, e.g. ``FY2025``, ``H1-2026``, ``LTM-2026-06``."""

    id: str
    kind: PeriodKind
    start: date | None = None
    end: date
    fiscal_year: int | None = None
    label: str | None = None
    weeks: int | None = None  # 52/53-week fiscal years

    @model_validator(mode="after")
    def _dates(self) -> Period:
        if self.start and self.start > self.end:
            raise ValueError(f"period {self.id}: start after end")
        return self

    @property
    def months(self) -> float | None:
        if self.start is None:
            return None
        days = (self.end - self.start).days + 1
        return round(days / 30.4375, 1)


class LTMResult(BaseModel):
    value: float
    derivation: Derivation


def last_twelve_months(
    latest_ytd: float,
    prior_full_year: float,
    prior_year_ytd: float,
    *,
    latest_ytd_label: str = "latest YTD",
    prior_full_year_label: str = "prior full year",
    prior_year_ytd_label: str = "prior-year YTD",
) -> LTMResult:
    """LTM = latest YTD + prior full year − prior-year YTD (flow items only; use the latest balance for stocks)."""
    value = latest_ytd + prior_full_year - prior_year_ytd
    return LTMResult(
        value=value,
        derivation=Derivation(
            kind="computed",
            formula="LTM = latest YTD + prior full year − prior-year YTD",
            inputs=[
                DerivationInput(name="latest_ytd", value=latest_ytd, label=latest_ytd_label),
                DerivationInput(name="prior_full_year", value=prior_full_year, label=prior_full_year_label),
                DerivationInput(name="prior_year_ytd", value=prior_year_ytd, label=prior_year_ytd_label),
            ],
        ),
    )
