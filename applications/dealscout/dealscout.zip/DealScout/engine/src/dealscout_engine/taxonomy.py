"""Canonical financial taxonomy: models, loading, validation and synonym lookup.

The taxonomy lives in ``data/taxonomy/taxonomy.yaml`` (versioned). See that file's header for the sign
conventions. ``load_taxonomy()`` validates the file on load, so a broken edit fails fast.
"""

from __future__ import annotations

import re
import unicodedata
from functools import lru_cache
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field, model_validator

from .formula import formula_names
from .paths import repo_data_dir

Statement = Literal["income_statement", "balance_sheet", "cash_flow", "memo", "market", "sector_kpi"]
Sign = Literal["positive", "negative", "either"]
PeriodType = Literal["duration", "instant", "none"]
Unit = Literal["currency", "shares", "per_share", "ratio", "percent", "count", "schedule", "date"]
Aggregation = Literal["leaf", "sum", "formula"]


class Concept(BaseModel):
    id: str
    name: str
    statement: Statement
    definition: str
    sign: Sign
    period_type: PeriodType
    unit: Unit
    aggregation: Aggregation
    components: list[str] = Field(default_factory=list)
    formula: str | None = None
    xbrl: dict[str, list[str]] = Field(default_factory=dict)
    synonyms: dict[str, list[str]] = Field(default_factory=dict)
    standard_labels: dict[str, list[str]] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _aggregation_fields(self) -> Concept:
        if self.aggregation == "sum" and not self.components:
            raise ValueError(f"{self.id}: aggregation 'sum' needs components")
        if self.aggregation == "formula" and not self.formula:
            raise ValueError(f"{self.id}: aggregation 'formula' needs a formula")
        if self.aggregation == "leaf" and (self.components or self.formula):
            raise ValueError(f"{self.id}: a leaf concept cannot have components or a formula")
        return self

    @property
    def inputs(self) -> list[str]:
        """Concept IDs this concept is derived from (empty for leaves)."""
        if self.aggregation == "sum":
            return list(self.components)
        if self.aggregation == "formula" and self.formula:
            return formula_names(self.formula)
        return []


class Taxonomy(BaseModel):
    version: str
    as_of: str
    statements: dict[str, str]
    standards: dict[str, str]
    languages: list[str]
    concepts: list[Concept]

    @model_validator(mode="after")
    def _integrity(self) -> Taxonomy:
        ids = [c.id for c in self.concepts]
        duplicates = {i for i in ids if ids.count(i) > 1}
        if duplicates:
            raise ValueError(f"duplicate concept ids: {sorted(duplicates)}")
        known = set(ids)
        for concept in self.concepts:
            missing = [i for i in concept.inputs if i not in known]
            if missing:
                raise ValueError(f"{concept.id}: unknown inputs {missing}")
            unknown_standards = set(concept.standard_labels) - set(self.standards)
            if unknown_standards:
                raise ValueError(f"{concept.id}: unknown standards {sorted(unknown_standards)}")
            if "en" not in concept.synonyms:
                raise ValueError(f"{concept.id}: needs English synonyms")
        self._check_cycles()
        return self

    def _check_cycles(self) -> None:
        graph = {c.id: c.inputs for c in self.concepts}
        state: dict[str, int] = {}

        def visit(node: str, trail: list[str]) -> None:
            if state.get(node) == 2:
                return
            if state.get(node) == 1:
                raise ValueError(f"cycle in taxonomy: {' -> '.join([*trail, node])}")
            state[node] = 1
            for child in graph[node]:
                visit(child, [*trail, node])
            state[node] = 2

        for node in graph:
            visit(node, [])

    # ── lookups ─────────────────────────────────────────────────────────
    def concept(self, concept_id: str) -> Concept:
        try:
            return self._by_id[concept_id]
        except KeyError:
            raise KeyError(f"Unknown concept {concept_id!r}") from None

    def has(self, concept_id: str) -> bool:
        return concept_id in self._by_id

    @property
    def _by_id(self) -> dict[str, Concept]:
        cache = self.__dict__.get("_by_id_cache")
        if cache is None:
            cache = {c.id: c for c in self.concepts}
            self.__dict__["_by_id_cache"] = cache
        return cache

    def by_statement(self, statement: Statement) -> list[Concept]:
        return [c for c in self.concepts if c.statement == statement]

    def synonym_index(self) -> dict[str, list[str]]:
        """Map normalised label → concept IDs (several concepts may share a label, e.g. 'minority interests')."""
        cache = self.__dict__.get("_synonym_cache")
        if cache is None:
            cache = {}
            for concept in self.concepts:
                labels = [concept.name]
                for group in (concept.synonyms, concept.standard_labels):
                    for values in group.values():
                        labels.extend(values)
                for label in labels:
                    key = normalise_label(label)
                    bucket = cache.setdefault(key, [])
                    if concept.id not in bucket:
                        bucket.append(concept.id)
            self.__dict__["_synonym_cache"] = cache
        return cache

    def match_label(self, label: str) -> list[str]:
        """Exact (normalised) synonym match. Fuzzy and LLM-assisted mapping live in the extraction package."""
        return list(self.synonym_index().get(normalise_label(label), []))

    def xbrl_index(self) -> dict[str, str]:
        """Map ``prefix:Element`` (e.g. ``us-gaap:Revenues``) → concept ID. First concept listing an element wins."""
        prefixes = {"us_gaap": "us-gaap", "ifrs": "ifrs-full"}
        index: dict[str, str] = {}
        for concept in self.concepts:
            for key, elements in concept.xbrl.items():
                prefix = prefixes.get(key, key)
                for element in elements:
                    index.setdefault(f"{prefix}:{element}", concept.id)
        return index


_FOOTNOTE = re.compile(r"(\(\s*\d{1,2}\s*\)|\[\s*\d{1,2}\s*\]|\*+|†+|‡+)$")
_NOTE_REF = re.compile(r"\b(note|notes|anhang|nota|annexe|注記)\s*[\d.,\s]+$", re.IGNORECASE)
_SPACE = re.compile(r"\s+")
# leading line numbers and sign markers: "1." "a)" "III." "B." "+/−" "=" "−"
_LEADING = re.compile(r"^\s*(\(?\d{1,2}[.)]|\(?[a-z]\)|[ivx]{1,4}\.|[a-h]\.|\+/[−-]|[−-]/\+|[+−=±-])\s*")
# trailing note references: "8, 9, 10 y 11", "5 and 25", "b)", "(ii)", "(note 12)", "※1"
_TRAILING_REFS = re.compile(
    r"(\s+\d{1,2}(\.\d{1,2})?(\s*(,|y|and|&|et|und|e)\s*\d{1,2}(\.\d{1,2})?)*"
    r"|\s*\((notes?|nota|notas|anhang|anm\.?)?\s*[\d.,\s&y]+\)"
    r"|\s+\(?[a-z]\)|\s*\((i{1,3}|iv|vi{0,3})\)|\s*※\s*\d+|\s*\(△は(減少|増加)\))$"
)


def normalise_label(label: str) -> str:
    """Normalise a line-item label for dictionary matching.

    Lower-cases (Unicode-aware), NFKC-normalises (full-width → ASCII, e.g. Japanese reports), strips footnote
    markers and trailing note references, unifies quotes/dashes and collapses whitespace. Accents are kept:
    they carry meaning in several languages.
    """
    text = unicodedata.normalize("NFKC", label).casefold()
    text = text.replace("’", "'").replace("‘", "'").replace("–", "-").replace("—", "-")
    text = text.strip(" :.;-\t\n")
    for _ in range(3):
        text = _LEADING.sub("", text)
    for _ in range(2):
        text = _NOTE_REF.sub("", text).strip(" :.;-")
        text = _FOOTNOTE.sub("", text).strip(" :.;-")
        text = _TRAILING_REFS.sub("", text).strip(" :.;-")
    text = text.replace(" and ", " & ").replace(" und ", " & ")
    text = text.replace(",", "")
    return _SPACE.sub(" ", text).strip()


@lru_cache(maxsize=4)
def _load(path: str) -> Taxonomy:
    with open(path, encoding="utf-8") as handle:
        raw = yaml.safe_load(handle)
    return Taxonomy.model_validate(raw)


def load_taxonomy(path: Path | None = None) -> Taxonomy:
    """Load and validate the canonical taxonomy (cached per path)."""
    target = path or repo_data_dir() / "taxonomy" / "taxonomy.yaml"
    return _load(str(target))
