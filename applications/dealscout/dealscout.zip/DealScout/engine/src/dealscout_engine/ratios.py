"""Financial ratios for the company analysis dashboard (brief §8).

Every ratio is returned with its definition and a derivation (formula + inputs). A ratio whose inputs are missing
is returned with ``value=None`` and the reason, never estimated. Values follow the taxonomy sign convention, so
expenses and outflows are negative and are flipped where a ratio is conventionally positive (e.g. capex/revenue).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Literal

from pydantic import BaseModel

from .derivation import Derivation, DerivationInput
from .statements import FinancialData

RatioUnit = Literal["pct", "x", "days", "number", "currency"]
RatioGroup = Literal["growth", "profitability", "returns", "cash", "leverage", "liquidity", "efficiency", "sector"]


class RatioResult(BaseModel):
    ratio_id: str
    label: str
    group: RatioGroup
    period_id: str
    value: float | None
    unit: RatioUnit
    definition: str
    higher_is_better: bool | None
    derivation: Derivation


@dataclass
class _Ctx:
    data: FinancialData
    period: str
    prior: str | None
    days: float
    tax_rate_fallback: float | None
    include_leases_in_debt: bool

    def v(self, concept: str, period: str | None = None) -> float | None:
        return self.data.get(concept, period or self.period)

    def avg(self, concept: str) -> float | None:
        """Average of opening and closing balance; closing only when no prior period exists."""
        closing = self.v(concept)
        if closing is None:
            return None
        opening = self.v(concept, self.prior) if self.prior else None
        return closing if opening is None else (opening + closing) / 2


def _div(numerator: float | None, denominator: float | None) -> float | None:
    if numerator is None or denominator is None or denominator == 0:
        return None
    return numerator / denominator


def total_debt(data: FinancialData, period: str, *, include_leases: bool = True) -> float | None:
    """Gross financial debt: short- plus long-term borrowings (+ lease liabilities when included)."""
    parts = ["st_debt", "lt_debt"] + (
        ["current_lease_liabilities", "non_current_lease_liabilities"] if include_leases else []
    )
    values = [data.get(p, period) for p in parts]
    if all(v is None for v in values[:2]):
        return None
    return sum(v or 0.0 for v in values)


def net_debt(data: FinancialData, period: str, *, include_leases: bool = True) -> float | None:
    """Simple net debt for ratios: gross debt − cash − short-term investments. (The valuation bridge is richer.)"""
    debt = total_debt(data, period, include_leases=include_leases)
    cash = data.get("cash", period)
    if debt is None or cash is None:
        return None
    return debt - cash - (data.get("st_investments", period) or 0.0)


def free_cash_flow(data: FinancialData, period: str) -> float | None:
    """Free cash flow = cash from operations + capex (capex stored negative)."""
    cfo, capex = data.get("cfo", period), data.get("capex", period)
    return None if cfo is None or capex is None else cfo + capex


def effective_tax_rate(data: FinancialData, period: str) -> float | None:
    pretax, tax = data.get("pretax_income", period), data.get("income_tax", period)
    if pretax is None or tax is None or pretax <= 0:
        return None
    rate = -tax / pretax
    return rate if 0 <= rate <= 0.6 else None


def invested_capital(data: FinancialData, period: str, *, include_leases: bool = True) -> float | None:
    """Invested capital (financing view) = total equity + gross debt (+ leases) − cash − short-term investments."""
    equity = data.get("total_equity", period)
    nd = net_debt(data, period, include_leases=include_leases)
    return None if equity is None or nd is None else equity + nd


def _growth(ctx: _Ctx, getter: Callable[[str], float | None]) -> tuple[float | None, list[DerivationInput], str | None]:
    if ctx.prior is None:
        return None, [], "No prior period."
    current, previous = getter(ctx.period), getter(ctx.prior)
    inputs = [DerivationInput(name="current", value=current), DerivationInput(name="prior", value=previous)]
    if current is None or previous is None:
        return None, inputs, "Value missing for this or the prior period."
    if previous <= 0:
        return None, inputs, "Not meaningful: prior-period value is zero or negative."
    return current / previous - 1, inputs, None


def compute_ratios(
    data: FinancialData,
    period_ids: list[str],
    *,
    prior_period: dict[str, str] | None = None,
    days_in_period: dict[str, float] | None = None,
    tax_rate_fallback: float | None = None,
    include_leases_in_debt: bool = True,
) -> list[RatioResult]:
    """Compute the ratio set for each period. ``prior_period`` links each period to the previous comparable one."""
    prior_period = prior_period or {}
    days_in_period = days_in_period or {}
    out: list[RatioResult] = []

    for period in period_ids:
        ctx = _Ctx(
            data,
            period,
            prior_period.get(period),
            days_in_period.get(period, 365.0),
            tax_rate_fallback,
            include_leases_in_debt,
        )

        def add(
            ratio_id: str,
            label: str,
            group: RatioGroup,
            unit: RatioUnit,
            definition: str,
            value: float | None,
            formula: str,
            inputs: dict[str, float | None],
            better: bool | None,
            note: str | None = None,
            _period: str = period,
        ) -> None:
            missing = [k for k, v in inputs.items() if v is None]
            if value is None and note is None:
                note = f"Missing: {', '.join(missing)}." if missing else "Not meaningful (division by zero)."
            out.append(
                RatioResult(
                    ratio_id=ratio_id,
                    label=label,
                    group=group,
                    period_id=_period,
                    value=value,
                    unit=unit,
                    definition=definition,
                    higher_is_better=better,
                    derivation=Derivation(
                        kind="computed" if value is not None else "missing",
                        formula=formula,
                        inputs=[DerivationInput(name=k, value=v) for k, v in inputs.items()],
                        note=note,
                    ),
                )
            )

        revenue, cogs = ctx.v("revenue"), ctx.v("cogs")
        gross_profit, ebitda, ebit = ctx.v("gross_profit"), ctx.v("ebitda"), ctx.v("ebit")
        net_income, ni_parent = ctx.v("net_income"), ctx.v("net_income_to_shareholders")
        fcf = free_cash_flow(data, period)

        # ── growth ────────────────────────────────────────────────
        for rid, label, concept in [
            ("revenue_growth", "Revenue growth", "revenue"),
            ("ebitda_growth", "EBITDA growth", "ebitda"),
            ("ebit_growth", "EBIT growth", "ebit"),
            ("eps_growth", "EPS growth (diluted)", "eps_diluted"),
        ]:

            def getter(p: str, c: str = concept) -> float | None:
                return data.get(c, p)

            value, inputs, note = _growth(ctx, getter)
            out.append(
                RatioResult(
                    ratio_id=rid,
                    label=label,
                    group="growth",
                    period_id=period,
                    value=value,
                    unit="pct",
                    definition=f"{label.split(' growth')[0]} this period ÷ prior period − 1.",
                    higher_is_better=True,
                    derivation=Derivation(
                        kind="computed" if value is not None else "missing",
                        formula="current ÷ prior − 1",
                        inputs=inputs,
                        note=note,
                    ),
                )
            )
        value, inputs, note = _growth(ctx, lambda p: free_cash_flow(data, p))
        out.append(
            RatioResult(
                ratio_id="fcf_growth",
                label="Free cash flow growth",
                group="growth",
                period_id=period,
                value=value,
                unit="pct",
                definition="FCF this period ÷ prior period − 1.",
                higher_is_better=True,
                derivation=Derivation(
                    kind="computed" if value is not None else "missing",
                    formula="current ÷ prior − 1",
                    inputs=inputs,
                    note=note,
                ),
            )
        )

        # ── profitability ─────────────────────────────────────────
        add(
            "gross_margin",
            "Gross margin",
            "profitability",
            "pct",
            "Gross profit ÷ revenue.",
            _div(gross_profit, revenue),
            "gross_profit ÷ revenue",
            {"gross_profit": gross_profit, "revenue": revenue},
            True,
        )
        add(
            "ebitda_margin",
            "EBITDA margin",
            "profitability",
            "pct",
            "EBITDA ÷ revenue.",
            _div(ebitda, revenue),
            "ebitda ÷ revenue",
            {"ebitda": ebitda, "revenue": revenue},
            True,
        )
        add(
            "ebit_margin",
            "EBIT margin",
            "profitability",
            "pct",
            "EBIT (operating profit) ÷ revenue.",
            _div(ebit, revenue),
            "ebit ÷ revenue",
            {"ebit": ebit, "revenue": revenue},
            True,
        )
        add(
            "net_margin",
            "Net margin",
            "profitability",
            "pct",
            "Net income ÷ revenue.",
            _div(net_income, revenue),
            "net_income ÷ revenue",
            {"net_income": net_income, "revenue": revenue},
            True,
        )

        # ── returns ───────────────────────────────────────────────
        etr = effective_tax_rate(data, period)
        tax_rate = etr if etr is not None else tax_rate_fallback
        tax_note = (
            None
            if etr is not None
            else ("Effective tax rate unavailable; default tax rate used." if tax_rate_fallback is not None else None)
        )
        nopat = None if ebit is None or tax_rate is None else ebit * (1 - tax_rate)
        prior_ic = invested_capital(data, ctx.prior, include_leases=include_leases_in_debt) if ctx.prior else None
        closing_ic = invested_capital(data, period, include_leases=include_leases_in_debt)
        avg_ic = None if closing_ic is None else (closing_ic if prior_ic is None else (closing_ic + prior_ic) / 2)
        add(
            "roic",
            "ROIC",
            "returns",
            "pct",
            "NOPAT ÷ average invested capital. NOPAT = EBIT × (1 − tax rate); invested capital = total equity + gross "
            "debt (incl. leases when the lease toggle is on) − cash − short-term investments.",
            _div(nopat, avg_ic),
            "ebit × (1 − tax_rate) ÷ avg invested capital",
            {"ebit": ebit, "tax_rate": tax_rate, "avg_invested_capital": avg_ic},
            True,
            note=tax_note,
        )
        equity_parent = ctx.avg("equity_to_shareholders") or ctx.avg("total_equity")
        add(
            "roe",
            "ROE",
            "returns",
            "pct",
            "Net income to shareholders ÷ average shareholders' equity.",
            _div(ni_parent if ni_parent is not None else net_income, equity_parent),
            "net income ÷ avg equity",
            {"net_income": ni_parent if ni_parent is not None else net_income, "avg_equity": equity_parent},
            True,
        )
        avg_assets = ctx.avg("total_assets")
        add(
            "roa",
            "ROA",
            "returns",
            "pct",
            "Net income ÷ average total assets.",
            _div(net_income, avg_assets),
            "net_income ÷ avg total assets",
            {"net_income": net_income, "avg_total_assets": avg_assets},
            True,
        )
        add(
            "asset_turnover",
            "Asset turnover",
            "efficiency",
            "x",
            "Revenue ÷ average total assets (DuPont).",
            _div(revenue, avg_assets),
            "revenue ÷ avg total assets",
            {"revenue": revenue, "avg_total_assets": avg_assets},
            True,
        )
        avg_equity = ctx.avg("total_equity")
        add(
            "equity_multiplier",
            "Equity multiplier",
            "leverage",
            "x",
            "Average total assets ÷ average total equity (DuPont).",
            _div(avg_assets, avg_equity),
            "avg total assets ÷ avg equity",
            {"avg_total_assets": avg_assets, "avg_equity": avg_equity},
            None,
        )

        # ── cash generation ───────────────────────────────────────
        capex, da = ctx.v("capex"), ctx.v("da_total")
        add(
            "free_cash_flow",
            "Free cash flow",
            "cash",
            "currency",
            "Cash from operations + capex (capex is an outflow).",
            fcf,
            "cfo + capex",
            {"cfo": ctx.v("cfo"), "capex": capex},
            True,
        )
        add(
            "fcf_conversion_ebitda",
            "FCF conversion (÷ EBITDA)",
            "cash",
            "pct",
            "Free cash flow ÷ EBITDA.",
            _div(fcf, ebitda),
            "fcf ÷ ebitda",
            {"fcf": fcf, "ebitda": ebitda},
            True,
        )
        add(
            "fcf_conversion_net_income",
            "FCF conversion (÷ net income)",
            "cash",
            "pct",
            "Free cash flow ÷ net income.",
            _div(fcf, net_income),
            "fcf ÷ net_income",
            {"fcf": fcf, "net_income": net_income},
            True,
        )
        add(
            "capex_to_revenue",
            "Capex ÷ revenue",
            "cash",
            "pct",
            "Capital expenditure ÷ revenue.",
            _div(-capex if capex is not None else None, revenue),
            "−capex ÷ revenue",
            {"capex": capex, "revenue": revenue},
            None,
        )
        add(
            "capex_to_da",
            "Capex ÷ D&A",
            "cash",
            "x",
            "Capital expenditure ÷ depreciation and amortisation (>1 = growing asset base).",
            _div(capex, da),
            "capex ÷ d&a (both outflows)",
            {"capex": capex, "da_total": da},
            None,
        )

        # ── leverage & liquidity ──────────────────────────────────
        nd = net_debt(data, period, include_leases=include_leases_in_debt)
        add(
            "net_debt",
            "Net debt",
            "leverage",
            "currency",
            "Gross debt (incl. leases when the lease toggle is on) − cash − short-term investments.",
            nd,
            "debt − cash − st investments",
            {"net_debt": nd},
            False,
        )
        add(
            "net_debt_to_ebitda",
            "Net debt ÷ EBITDA",
            "leverage",
            "x",
            "Net debt ÷ EBITDA.",
            _div(nd, ebitda) if ebitda is not None and ebitda > 0 else None,
            "net_debt ÷ ebitda",
            {"net_debt": nd, "ebitda": ebitda},
            False,
            note=None if ebitda is None or ebitda > 0 else "Not meaningful: EBITDA is zero or negative.",
        )
        interest = ctx.v("interest_expense")
        add(
            "interest_coverage",
            "Interest coverage",
            "leverage",
            "x",
            "EBIT ÷ interest expense.",
            _div(ebit, -interest if interest is not None else None),
            "ebit ÷ −interest_expense",
            {"ebit": ebit, "interest_expense": interest},
            True,
        )
        debt = total_debt(data, period, include_leases=include_leases_in_debt)
        equity = ctx.v("total_equity")
        add(
            "debt_to_equity",
            "Debt ÷ equity",
            "leverage",
            "x",
            "Gross debt ÷ total equity.",
            _div(debt, equity) if equity is not None and equity > 0 else None,
            "debt ÷ total_equity",
            {"debt": debt, "total_equity": equity},
            False,
        )
        current_assets, current_liabilities = ctx.v("total_current_assets"), ctx.v("total_current_liabilities")
        add(
            "current_ratio",
            "Current ratio",
            "liquidity",
            "x",
            "Current assets ÷ current liabilities.",
            _div(current_assets, current_liabilities),
            "current assets ÷ current liabilities",
            {"current_assets": current_assets, "current_liabilities": current_liabilities},
            True,
        )
        cash = ctx.v("cash")
        quick_assets = None if cash is None else cash + (ctx.v("st_investments") or 0) + (ctx.v("receivables") or 0)
        add(
            "quick_ratio",
            "Quick ratio",
            "liquidity",
            "x",
            "(Cash + short-term investments + receivables) ÷ current liabilities.",
            _div(quick_assets, current_liabilities),
            "quick assets ÷ current liabilities",
            {"quick_assets": quick_assets, "current_liabilities": current_liabilities},
            True,
        )

        # ── working-capital efficiency (period-end balances) ──────
        days = ctx.days
        receivables, inventory, payables = ctx.v("receivables"), ctx.v("inventory"), ctx.v("payables")
        cost_base = -cogs if cogs is not None else None
        dso = _div(receivables, revenue)
        dio = _div(inventory, cost_base)
        dpo = _div(payables, cost_base)
        add(
            "dso",
            "Days sales outstanding",
            "efficiency",
            "days",
            f"Receivables ÷ revenue × {days:g}.",
            None if dso is None else dso * days,
            "receivables ÷ revenue × days",
            {"receivables": receivables, "revenue": revenue},
            False,
        )
        add(
            "dio",
            "Days inventory outstanding",
            "efficiency",
            "days",
            f"Inventory ÷ cost of sales × {days:g}.",
            None if dio is None else dio * days,
            "inventory ÷ cost of sales × days",
            {"inventory": inventory, "cost_of_sales": cost_base},
            False,
        )
        add(
            "dpo",
            "Days payables outstanding",
            "efficiency",
            "days",
            f"Payables ÷ cost of sales × {days:g}.",
            None if dpo is None else dpo * days,
            "payables ÷ cost of sales × days",
            {"payables": payables, "cost_of_sales": cost_base},
            None,
        )
        ccc = None if dso is None or dio is None or dpo is None else (dso + dio - dpo) * days
        add(
            "cash_conversion_cycle",
            "Cash conversion cycle",
            "efficiency",
            "days",
            "DSO + DIO − DPO.",
            ccc,
            "dso + dio − dpo",
            {
                "dso": None if dso is None else dso * days,
                "dio": None if dio is None else dio * days,
                "dpo": None if dpo is None else dpo * days,
            },
            False,
        )
    return out


def cagr(first: float | None, last: float | None, years: float) -> float | None:
    """Compound annual growth rate; None when not meaningful (non-positive endpoints or no time elapsed)."""
    if first is None or last is None or first <= 0 or last <= 0 or years <= 0:
        return None
    return (last / first) ** (1 / years) - 1
