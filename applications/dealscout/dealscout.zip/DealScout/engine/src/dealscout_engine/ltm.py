"""Last-twelve-months figures from interim data (brief §5.2 step 8).

Flow items (income statement, cash flow): LTM = latest YTD + prior full year − prior-year YTD.
Balance items: the latest interim balance. Only built when all three periods exist; every value carries its
derivation so the grid can show the calculation.
"""

from __future__ import annotations

import re

from pydantic import BaseModel

from .derivation import Derivation, DerivationInput
from .statements import FinancialData

_YTD = re.compile(r"^(H1|H2|9M|6M|3M|Q1)-(\d{4})$")


class LTMPlan(BaseModel):
    key: str
    label: str
    latest_ytd: str
    prior_full_year: str
    prior_year_ytd: str


def plan_ltm(period_keys: list[str]) -> list[LTMPlan]:
    """LTM columns that can be built from the periods present (H1-2026 + FY2025 + H1-2025 → LTM-H1-2026)."""
    keys = set(period_keys)
    plans = []
    for key in period_keys:
        m = _YTD.match(key)
        if not m or m.group(1) == "H2":
            continue
        part, year = m.group(1), int(m.group(2))
        prior_fy, prior_ytd = f"FY{year - 1}", f"{part}-{year - 1}"
        if prior_fy in keys and prior_ytd in keys:
            plans.append(
                LTMPlan(
                    key=f"LTM-{key}",
                    label=f"LTM {part} {year}",
                    latest_ytd=key,
                    prior_full_year=prior_fy,
                    prior_year_ytd=prior_ytd,
                )
            )
    return plans


def compute_ltm(data: FinancialData, plan: LTMPlan) -> dict[str, tuple[float, Derivation]]:
    out: dict[str, tuple[float, Derivation]] = {}
    for concept in data.taxonomy.concepts:
        if concept.unit in ("schedule", "ratio", "percent", "date"):
            continue
        latest = data.get(concept.id, plan.latest_ytd)
        if concept.period_type == "instant":
            if latest is not None:
                out[concept.id] = (
                    latest,
                    Derivation(
                        kind="computed",
                        formula=f"Balance at {plan.latest_ytd}",
                        inputs=[DerivationInput(name=plan.latest_ytd, value=latest)],
                    ),
                )
            continue
        fy = data.get(concept.id, plan.prior_full_year)
        prior = data.get(concept.id, plan.prior_year_ytd)
        if latest is None or fy is None or prior is None:
            continue
        out[concept.id] = (
            latest + fy - prior,
            Derivation(
                kind="computed",
                formula=f"{plan.latest_ytd} + {plan.prior_full_year} − {plan.prior_year_ytd}",
                inputs=[
                    DerivationInput(name=plan.latest_ytd, value=latest),
                    DerivationInput(name=plan.prior_full_year, value=fy),
                    DerivationInput(name=plan.prior_year_ytd, value=prior),
                ],
            ),
        )
    return out
