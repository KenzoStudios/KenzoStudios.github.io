"""Currency conversion (brief §7): reporting currency → analysis currency with rates the analyst enters.

Conventions (docs/methodology.md, "Currency conversion"):
- A rate is quoted as units of the analysis currency per 1 unit of the source currency (EUR→USD 1.08 means
  1 EUR = 1.08 USD), with the date it applies to and the source it came from. The engine never invents a rate.
- Flow items (income statement, cash flow, and any other duration amount) use the period's **average** rate.
- Balance-sheet items (and any other point-in-time amount, such as a share price or cash at year-end) use the
  period's **closing** rate.
- Per-share amounts are converted like other amounts; share counts, ratios, percentages and counts are not.
- Only stored values are converted. Subtotals and formulas are recomputed from the converted components, so a
  cash-flow statement translated at average rates no longer ties to balance sheets translated at closing rates;
  that difference is the currency translation effect, which is real and is not hidden.
- When a needed rate is missing the value is not converted and the rate is listed as missing: callers must ask
  for it instead of computing.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Literal

from pydantic import BaseModel, Field

from .scores import Adjustment
from .statements import FinancialData
from .taxonomy import Concept
from .valuation.bridge import BridgeInputs
from .valuation.comps import Peer

RateKind = Literal["average", "closing"]

CONVERTED_UNITS = ("currency", "per_share")

# Bridge fields that are amounts (the rest are toggles or a tax rate).
BRIDGE_AMOUNT_FIELDS = (
    "gross_debt",
    "lease_liabilities",
    "pension_deficit",
    "preferred_equity",
    "minority_interest",
    "provisions",
    "earn_outs",
    "other_debt_like",
    "cash",
    "minimum_operating_cash",
    "short_term_investments",
    "investments_in_associates",
    "other_cash_like",
)

# Peer fields that are money amounts. Growth and margin are ratios and stay as they are.
PEER_AMOUNT_FIELDS = (
    "market_cap",
    "net_debt",
    "enterprise_value",
    "revenue",
    "ebitda",
    "ebit",
    "net_income",
    "book_equity",
    "tangible_book_equity",
    "free_cash_flow",
    "revenue_next",
    "ebitda_next",
    "ebit_next",
    "net_income_next",
    "free_cash_flow_next",
    # comps depth: EBITDAR rent, SaaS ARR, NAV and the current-year / next-year estimates
    "rent_expense",
    "arr",
    "nav",
    "revenue_cy",
    "ebitda_cy",
    "ebit_cy",
    "net_income_cy",
    "revenue_ny",
    "ebitda_ny",
    "ebit_ny",
    "net_income_ny",
)


class FxRate(BaseModel):
    """One rate: units of the target currency per 1 unit of the source currency, with its date and source."""

    rate: float = Field(gt=0)
    as_of: date
    source: str = Field(min_length=1, max_length=300)

    def describe(self) -> str:
        return f"{self.rate:,.6g} ({self.as_of.isoformat()}, {self.source})"


class PeriodRates(BaseModel):
    """The average rate (flows) and closing rate (balances) for one reporting period."""

    period_id: str
    average: FxRate | None = None
    closing: FxRate | None = None

    def get(self, kind: RateKind) -> FxRate | None:
        return self.average if kind == "average" else self.closing


class UsedRate(BaseModel):
    period_id: str
    kind: RateKind
    rate: float
    as_of: date
    source: str
    values: int  # how many stored values were converted at this rate

    @property
    def note(self) -> str:
        return f"converted at {self.rate:,.6g} ({self.as_of.isoformat()}, {self.source})"


class MissingRate(BaseModel):
    period_id: str
    kind: RateKind
    concepts: list[str]


@dataclass
class ConversionResult:
    data: FinancialData
    used: list[UsedRate] = field(default_factory=list)
    missing: list[MissingRate] = field(default_factory=list)

    @property
    def complete(self) -> bool:
        return not self.missing


def rate_kind(concept: Concept) -> RateKind | None:
    """Which rate converts a concept, or ``None`` when it is not a money amount (shares, ratios, counts …)."""
    if concept.unit not in CONVERTED_UNITS:
        return None
    if concept.statement == "balance_sheet":
        return "closing"
    if concept.statement in ("income_statement", "cash_flow") and concept.period_type == "duration":
        return "average"
    return "closing" if concept.period_type == "instant" else "average"


def convert_amount(value: float, rate: float) -> float:
    """An amount in the source currency → the target currency (``rate`` target units per source unit)."""
    if rate <= 0:
        raise ValueError("an FX rate must be positive")
    return value * rate


def convert_financial_data(data: FinancialData, rates: list[PeriodRates]) -> ConversionResult:
    """Convert every stored money value; values whose rate is missing are left out and the rate is listed."""
    by_period = {r.period_id: r for r in rates}
    out = FinancialData(data.taxonomy)
    used: dict[tuple[str, RateKind], UsedRate] = {}
    missing: dict[tuple[str, RateKind], list[str]] = {}
    for (concept_id, period_id), value in sorted(data.values.items(), key=lambda kv: (kv[0][1], kv[0][0])):
        kind = rate_kind(data.taxonomy.concept(concept_id))
        if kind is None:
            out.values[(concept_id, period_id)] = value
            continue
        period_rates = by_period.get(period_id)
        fx = period_rates.get(kind) if period_rates else None
        if fx is None:
            missing.setdefault((period_id, kind), []).append(concept_id)
            continue
        out.values[(concept_id, period_id)] = convert_amount(value, fx.rate)
        key = (period_id, kind)
        if key in used:
            used[key].values += 1
        else:
            used[key] = UsedRate(
                period_id=period_id, kind=kind, rate=fx.rate, as_of=fx.as_of, source=fx.source, values=1
            )
    return ConversionResult(
        data=out,
        used=list(used.values()),
        missing=[MissingRate(period_id=p, kind=k, concepts=c) for (p, k), c in missing.items()],
    )


def convert_bridge(bridge: BridgeInputs, rate: float) -> BridgeInputs:
    """Bridge items are balances: convert them at the closing rate of the balance-sheet date."""
    return bridge.model_copy(update={f: convert_amount(getattr(bridge, f), rate) for f in BRIDGE_AMOUNT_FIELDS})


def convert_per_share(value: float | None, rate: float) -> float | None:
    """A per-share value (price, value per share, strike) converts like any amount; the share count does not."""
    return None if value is None else convert_amount(value, rate)


class PeerConversion(BaseModel):
    peer: Peer
    converted: bool
    from_currency: str | None
    rate: FxRate | None = None
    note: str | None = None
    missing_rate: bool = False


def convert_peer(peer: Peer, analysis_currency: str, rates: dict[str, FxRate]) -> PeerConversion:
    """Convert a peer's amounts to the analysis currency with the rate entered for the peer's currency.

    A peer without a currency is taken to be in the analysis currency. One rate converts every amount of the peer,
    so its multiples are unchanged by the conversion; converted amounts make sizes comparable. A missing rate is
    reported (``missing_rate``) and the peer is returned unconverted for the caller to exclude.
    """
    source = (peer.currency or analysis_currency).upper()
    if source == analysis_currency.upper():
        return PeerConversion(peer=peer, converted=False, from_currency=source)
    fx = rates.get(source)
    if fx is None:
        return PeerConversion(
            peer=peer,
            converted=False,
            from_currency=source,
            missing_rate=True,
            note=f"No {source} to {analysis_currency.upper()} rate entered",
        )
    update = {f: convert_amount(v, fx.rate) for f in PEER_AMOUNT_FIELDS if (v := getattr(peer, f)) is not None}
    return PeerConversion(
        peer=peer.model_copy(update=update),
        converted=True,
        from_currency=source,
        rate=fx,
        note=f"{source} converted at {fx.describe()}",
    )


def convert_adjustments(
    adjustments: list[Adjustment], rates: list[PeriodRates]
) -> tuple[list[Adjustment], list[MissingRate]]:
    """One-off items are profit-and-loss amounts: convert each at its period's average rate."""
    by_period = {r.period_id: r for r in rates}
    out: list[Adjustment] = []
    missing: dict[str, list[str]] = {}
    for a in adjustments:
        fx = by_period[a.period_key].average if a.period_key in by_period else None
        if fx is None:
            missing.setdefault(a.period_key, []).append(f"one-off: {a.label}")
            continue
        out.append(a.model_copy(update={"amount": convert_amount(a.amount, fx.rate)}))
    return out, [MissingRate(period_id=p, kind="average", concepts=c) for p, c in missing.items()]
