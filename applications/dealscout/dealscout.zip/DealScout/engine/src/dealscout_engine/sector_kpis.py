"""Sector KPIs (brief §8): banks, insurers, SaaS, real estate and retail.

Each KPI is returned as a :class:`~dealscout_engine.ratios.RatioResult` (group ``sector``) so it uses the same display
conventions as the ratio table: value, unit, definition and a derivation.

A KPI with a formula is **computed from its inputs when they are all available**; otherwise the figure the company
reports (typed or extracted into the ``sector_kpi`` statement) is used and marked ``reported``. When neither exists
the KPI is ``missing``. Nothing is estimated. Percentages are stored as fractions (0.145 = 14.5%).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from .derivation import Derivation, DerivationInput
from .ratios import RatioResult, RatioUnit, net_debt
from .statements import FinancialData

# template id (data/taxonomy/templates.yaml) → label shown above the KPI block
SECTOR_KPI_TEMPLATES: dict[str, str] = {
    "bank": "Bank KPIs",
    "insurer": "Insurance KPIs",
    "saas": "SaaS KPIs",
    "real_estate": "Real estate KPIs",
    "retail": "Retail KPIs",
}


@dataclass
class _P:
    data: FinancialData
    period: str
    prior: str | None

    def v(self, concept: str, period: str | None = None) -> float | None:
        return self.data.get(concept, period or self.period)

    def avg(self, concept: str) -> float | None:
        closing = self.v(concept)
        if closing is None:
            return None
        opening = self.v(concept, self.prior) if self.prior else None
        return closing if opening is None else (opening + closing) / 2


def _div(a: float | None, b: float | None) -> float | None:
    if a is None or b is None or b == 0:
        return None
    return a / b


@dataclass(frozen=True)
class _Kpi:
    kpi_id: str
    label: str
    unit: RatioUnit
    definition: str
    better: bool | None
    reported: str | None  # concept holding the company's own figure (used when the formula cannot run)
    formula: str | None = None
    compute: Callable[[_P], tuple[float | None, dict[str, float | None]]] | None = None


# ── formulas ──────────────────────────────────────────────────────────────────
def _nim(p: _P) -> tuple[float | None, dict[str, float | None]]:
    nii, assets = p.v("net_interest_income"), p.avg("interest_earning_assets")
    return _div(nii, assets), {"net_interest_income": nii, "avg_interest_earning_assets": assets}


def _cost_income(p: _P) -> tuple[float | None, dict[str, float | None]]:
    costs, income = p.v("bank_operating_expenses"), p.v("bank_operating_income")
    value = _div(-costs if costs is not None else None, income) if income is not None and income > 0 else None
    return value, {"operating_expenses": costs, "operating_income": income}


def _npl(p: _P) -> tuple[float | None, dict[str, float | None]]:
    npl, loans = p.v("non_performing_loans"), p.v("gross_loans")
    return _div(npl, loans), {"non_performing_loans": npl, "gross_loans": loans}


def _combined(p: _P) -> tuple[float | None, dict[str, float | None]]:
    claims, expenses = p.v("net_claims_incurred"), p.v("insurance_operating_expenses")
    premiums = p.v("net_earned_premiums")
    costs = None if claims is None or expenses is None else -(claims + expenses)
    value = _div(costs, premiums) if premiums is not None and premiums > 0 else None
    return value, {"net_claims_incurred": claims, "operating_expenses": expenses, "net_earned_premiums": premiums}


def _solvency(p: _P) -> tuple[float | None, dict[str, float | None]]:
    own_funds, scr = p.v("eligible_own_funds"), p.v("solvency_capital_requirement")
    return _div(own_funds, scr), {"eligible_own_funds": own_funds, "solvency_capital_requirement": scr}


def _growth_of(concept: str) -> Callable[[_P], tuple[float | None, dict[str, float | None]]]:
    def compute(p: _P) -> tuple[float | None, dict[str, float | None]]:
        now = p.v(concept)
        before = p.v(concept, p.prior) if p.prior else None
        value = None if now is None or before is None or before <= 0 else now / before - 1
        return value, {"current": now, "prior": before}

    return compute


def _rule_of_40(p: _P) -> tuple[float | None, dict[str, float | None]]:
    growth, _ = _growth_of("revenue")(p)
    revenue, ebitda = p.v("revenue"), p.v("ebitda")
    margin = _div(ebitda, revenue) if revenue is not None and revenue > 0 else None
    value = None if growth is None or margin is None else growth + margin
    return value, {"revenue_growth": growth, "ebitda_margin": margin}


def _ltv(p: _P) -> tuple[float | None, dict[str, float | None]]:
    debt = net_debt(p.data, p.period, include_leases=False)
    value_of_property = p.v("investment_property")
    ratio = _div(debt, value_of_property) if value_of_property is not None and value_of_property > 0 else None
    return ratio, {"net_debt": debt, "investment_property": value_of_property}


def _yield(p: _P) -> tuple[float | None, dict[str, float | None]]:
    noi, value_of_property = p.v("noi"), p.v("investment_property")
    ratio = _div(noi, value_of_property) if value_of_property is not None and value_of_property > 0 else None
    return ratio, {"noi": noi, "investment_property": value_of_property}


def _revenue_per_store(p: _P) -> tuple[float | None, dict[str, float | None]]:
    revenue, stores = p.v("revenue"), p.v("store_count")
    value = _div(revenue, stores) if stores is not None and stores > 0 else None
    return value, {"revenue": revenue, "store_count": stores}


KPI_SETS: dict[str, list[_Kpi]] = {
    "bank": [
        _Kpi(
            "cet1_ratio",
            "CET1 ratio",
            "pct",
            "Common Equity Tier 1 capital ÷ risk-weighted assets.",
            True,
            "cet1_ratio",
        ),
        _Kpi(
            "net_interest_margin",
            "Net interest margin",
            "pct",
            "Net interest income ÷ average interest-earning assets.",
            True,
            "net_interest_margin",
            "net_interest_income ÷ avg interest_earning_assets",
            _nim,
        ),
        _Kpi(
            "cost_income_ratio",
            "Cost ÷ income ratio",
            "pct",
            "Operating expenses ÷ total operating income.",
            False,
            "cost_income_ratio",
            "−operating_expenses ÷ operating_income",
            _cost_income,
        ),
        _Kpi(
            "npl_ratio",
            "Non-performing loan ratio",
            "pct",
            "Non-performing loans ÷ gross loans.",
            False,
            "npl_ratio",
            "non_performing_loans ÷ gross_loans",
            _npl,
        ),
    ],
    "insurer": [
        _Kpi(
            "combined_ratio",
            "Combined ratio",
            "pct",
            "(Net claims incurred + operating expenses) ÷ net earned premiums. Below 100% = underwriting profit.",
            False,
            "combined_ratio",
            "−(claims + expenses) ÷ net_earned_premiums",
            _combined,
        ),
        _Kpi(
            "solvency_ratio",
            "Solvency ratio",
            "pct",
            "Eligible own funds ÷ solvency capital requirement.",
            True,
            "solvency_ratio",
            "eligible_own_funds ÷ scr",
            _solvency,
        ),
    ],
    "saas": [
        _Kpi("arr", "ARR", "currency", "Annual recurring revenue at period end.", True, "arr"),
        _Kpi(
            "arr_growth",
            "ARR growth",
            "pct",
            "ARR this period ÷ prior period − 1.",
            True,
            None,
            "current ÷ prior − 1",
            _growth_of("arr"),
        ),
        _Kpi(
            "net_revenue_retention",
            "Net revenue retention",
            "pct",
            "Recurring revenue from last year's customers, including expansion and churn, ÷ their revenue a year "
            "earlier.",
            True,
            "net_revenue_retention",
        ),
        _Kpi(
            "rule_of_40",
            "Rule of 40",
            "pct",
            "Revenue growth + EBITDA margin. 40% or more is the usual benchmark for software companies.",
            True,
            None,
            "revenue_growth + ebitda_margin",
            _rule_of_40,
        ),
    ],
    "real_estate": [
        _Kpi("occupancy_rate", "Occupancy", "pct", "Occupied area or rent ÷ total lettable.", True, "occupancy_rate"),
        _Kpi(
            "loan_to_value",
            "Loan to value (LTV)",
            "pct",
            "Net debt (borrowings − cash − short-term investments, leases excluded) ÷ investment property value.",
            False,
            "loan_to_value",
            "net_debt ÷ investment_property",
            _ltv,
        ),
        _Kpi("noi", "Net operating income", "currency", "Rental income less property operating expenses.", True, "noi"),
        _Kpi(
            "property_yield",
            "NOI yield",
            "pct",
            "Net operating income ÷ investment property value.",
            None,
            "property_yield",
            "noi ÷ investment_property",
            _yield,
        ),
    ],
    "retail": [
        _Kpi(
            "like_for_like_growth",
            "Like-for-like sales growth",
            "pct",
            "Sales growth from stores open in both periods (as reported).",
            True,
            "like_for_like_growth",
        ),
        _Kpi("store_count", "Stores", "number", "Number of stores at period end.", None, "store_count"),
        _Kpi(
            "revenue_per_store",
            "Revenue per store",
            "currency",
            "Revenue ÷ stores at period end.",
            True,
            None,
            "revenue ÷ store_count",
            _revenue_per_store,
        ),
    ],
}


def compute_sector_kpis(
    data: FinancialData,
    period_ids: list[str],
    template: str,
    *,
    prior_period: dict[str, str] | None = None,
) -> list[RatioResult]:
    """Sector KPIs for each period; an empty list when the template has no KPI set (general corporates)."""
    kpis = KPI_SETS.get(template, [])
    prior_period = prior_period or {}
    out: list[RatioResult] = []
    for period in period_ids:
        p = _P(data, period, prior_period.get(period))
        for k in kpis:
            value, inputs = k.compute(p) if k.compute else (None, {})
            reported = p.v(k.reported) if k.reported else None
            if value is not None:
                derivation = Derivation(
                    kind="computed",
                    formula=k.formula,
                    inputs=[DerivationInput(name=n, value=v) for n, v in inputs.items()],
                    note=None
                    if reported is None or abs(reported - value) <= 0.0005 * max(1.0, abs(value))
                    else "The company reports a different figure; the computed value is shown.",
                )
            elif reported is not None:
                value = reported
                derivation = Derivation(
                    kind="reported",
                    formula=None,
                    inputs=[DerivationInput(name=k.reported or k.kpi_id, value=reported)],
                    note="As reported by the company." if k.compute else None,
                )
            else:
                missing = [n for n, v in inputs.items() if v is None]
                needs = [k.reported] if k.reported else []
                if k.compute:
                    note = (
                        f"Missing: {', '.join(missing)}." if missing else "Not meaningful (zero or negative base)."
                    ) + (f" Or enter the reported {k.label}." if k.reported else "")
                else:
                    note = f"Enter {', '.join(needs)} on the Data tab."
                derivation = Derivation(
                    kind="missing",
                    formula=k.formula,
                    inputs=[DerivationInput(name=n, value=v) for n, v in inputs.items()],
                    note=note,
                )
            out.append(
                RatioResult(
                    ratio_id=k.kpi_id,
                    label=k.label,
                    group="sector",
                    period_id=period,
                    value=value,
                    unit=k.unit,
                    definition=k.definition,
                    higher_is_better=k.better,
                    derivation=derivation,
                )
            )
    return out
