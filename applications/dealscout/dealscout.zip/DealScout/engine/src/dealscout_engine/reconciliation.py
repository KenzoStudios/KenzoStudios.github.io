"""Reconciliation checks run automatically on every set of statements (brief §5.2 step 9).

Each check returns pass / fail / not_applicable with the expected and actual figures, so the UI can show *why* a
check failed. Tolerances allow for rounding in published statements.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

from .statements import FinancialData

Status = Literal["pass", "fail", "not_applicable"]
Severity = Literal["error", "warning", "info"]


class CheckResult(BaseModel):
    check_id: str
    label: str
    period_id: str
    status: Status
    severity: Severity
    expected: float | None = None
    actual: float | None = None
    difference: float | None = None
    tolerance: float | None = None
    message: str


def _tolerance(expected: float, rounding_unit: float, n_terms: int) -> float:
    """Half a rounding unit per summed term, or 0.1% of the figure, whichever is larger."""
    return max(0.5 * rounding_unit * max(1, n_terms), 0.001 * abs(expected))


def _compare(
    check_id: str,
    label: str,
    period_id: str,
    expected: float | None,
    actual: float | None,
    *,
    rounding_unit: float,
    n_terms: int = 2,
    severity: Severity = "error",
    fail_message: str,
    pass_message: str,
    missing_message: str,
) -> CheckResult:
    if expected is None or actual is None:
        return CheckResult(
            check_id=check_id,
            label=label,
            period_id=period_id,
            status="not_applicable",
            severity="info",
            expected=expected,
            actual=actual,
            message=missing_message,
        )
    difference = actual - expected
    tolerance = _tolerance(expected, rounding_unit, n_terms)
    ok = abs(difference) <= tolerance
    return CheckResult(
        check_id=check_id,
        label=label,
        period_id=period_id,
        status="pass" if ok else "fail",
        severity="info" if ok else severity,
        expected=expected,
        actual=actual,
        difference=difference,
        tolerance=tolerance,
        message=pass_message if ok else fail_message,
    )


def run_checks(
    data: FinancialData,
    period_ids: list[str],
    *,
    prior_period: dict[str, str] | None = None,
    rounding_unit: float = 1.0,
) -> list[CheckResult]:
    """Run every applicable check for each period.

    ``rounding_unit`` is the smallest unit the figures were entered in (e.g. 1e6 for "EUR m"), used for tolerance.
    ``prior_period`` maps a period to the one before it (for opening-cash continuity).
    """
    stored = data.values
    tax = data.taxonomy
    results: list[CheckResult] = []

    for period in period_ids:

        def get(concept: str, _period: str = period) -> float | None:
            return data.get(concept, _period)

        def has(concept: str, _period: str = period) -> bool:
            return (concept, _period) in stored

        # 1. Assets = liabilities + equity
        assets = get("total_assets")
        l_and_e = get("total_liabilities_and_equity")
        if l_and_e is None and get("total_liabilities") is not None and get("total_equity") is not None:
            l_and_e = (get("total_liabilities") or 0) + (get("total_equity") or 0)
        results.append(
            _compare(
                "balance_sheet_balances",
                "Assets = liabilities + equity",
                period,
                assets,
                l_and_e,
                rounding_unit=rounding_unit,
                fail_message="Total assets do not equal total liabilities plus equity.",
                pass_message="The balance sheet balances.",
                missing_message="Enter total assets and total liabilities and equity to check the balance sheet.",
            )
        )

        # 2. Reported subtotals equal the sum of their components
        for concept in tax.concepts:
            if concept.aggregation != "sum" or not has(concept.id):
                continue
            present = [c for c in concept.components if has(c) or data.get(c, period) is not None]
            if not present:
                continue
            missing = [c for c in concept.components if c not in present]
            components_total = sum(data.get(c, period) or 0.0 for c in present)
            reported = stored[(concept.id, period)]
            check = _compare(
                f"subtotal:{concept.id}",
                f"{concept.name} = sum of components",
                period,
                components_total,
                reported,
                rounding_unit=rounding_unit,
                n_terms=len(present),
                severity="warning" if missing else "error",
                fail_message=(
                    f"Reported {concept.name.lower()} differs from the sum of its components"
                    + (f" (not entered: {', '.join(tax.concept(m).name for m in missing)})." if missing else ".")
                ),
                pass_message=f"{concept.name} agrees with its components.",
                missing_message="",
            )
            if len(present) == 1 and missing:
                continue  # one component alone says nothing about the subtotal
            results.append(check)

        # 3. Cash flow roll-forward: opening + net change (+ FX) = closing
        opening, closing, change = get("cash_beginning"), get("cash_ending"), get("net_change_in_cash")
        expected_closing = None if opening is None or change is None else opening + change + (get("fx_effect") or 0.0)
        results.append(
            _compare(
                "cash_roll_forward",
                "Opening cash + net change (+ FX) = closing cash",
                period,
                expected_closing,
                closing,
                rounding_unit=rounding_unit,
                n_terms=3,
                fail_message="The cash flow statement does not roll forward from opening to closing cash.",
                pass_message="Cash rolls forward from opening to closing balance.",
                missing_message="Enter opening cash, net change and closing cash to check the roll-forward.",
            )
        )

        # 4. Closing cash in the cash flow statement ties to the balance sheet
        results.append(
            _compare(
                "cash_ties_to_balance_sheet",
                "Closing cash (cash flow) = cash (balance sheet)",
                period,
                get("cash"),
                closing,
                rounding_unit=rounding_unit,
                severity="warning",
                fail_message=(
                    "Closing cash in the cash flow statement differs from balance-sheet cash. Check for overdrafts, "
                    "restricted cash or held-for-sale cash in the cash-flow definition."
                ),
                pass_message="Closing cash agrees with the balance sheet.",
                missing_message="Enter closing cash in both statements to tie them out.",
            )
        )

        # 5. Opening cash equals prior-period closing cash
        if prior_period and period in prior_period:
            previous = prior_period[period]
            results.append(
                _compare(
                    "opening_cash_continuity",
                    "Opening cash = prior-period closing cash",
                    period,
                    data.get("cash_ending", previous),
                    opening,
                    rounding_unit=rounding_unit,
                    severity="warning",
                    fail_message="Opening cash differs from the previous period's closing cash (restatement?).",
                    pass_message="Opening cash continues from the prior period.",
                    missing_message="Opening or prior-period closing cash not entered.",
                )
            )

        # 6. Net income agrees between income statement and cash flow statement
        if has("cf_net_income"):
            results.append(
                _compare(
                    "net_income_ties",
                    "Net income (income statement) = profit in cash flow",
                    period,
                    get("net_income"),
                    get("cf_net_income"),
                    rounding_unit=rounding_unit,
                    severity="warning",
                    fail_message=(
                        "The cash flow statement starts from a different profit figure than the income statement."
                    ),
                    pass_message="Net income agrees between statements.",
                    missing_message="Enter net income on the income statement to tie it to the cash flow statement.",
                )
            )

        # 7. Sign sanity
        for (concept_id, value_period), value in stored.items():
            if value_period != period or value == 0:
                continue
            concept = tax.concept(concept_id)
            wrong = (concept.sign == "positive" and value < 0) or (concept.sign == "negative" and value > 0)
            if wrong:
                expected_sign = "positive" if concept.sign == "positive" else "negative (an outflow or expense)"
                results.append(
                    CheckResult(
                        check_id=f"sign:{concept_id}",
                        label=f"Sign of {concept.name}",
                        period_id=period,
                        status="fail",
                        severity="warning",
                        actual=value,
                        message=f"{concept.name} is normally {expected_sign}; check the sign convention.",
                    )
                )
    return results


def summarise(results: list[CheckResult]) -> dict[str, int]:
    counts = {"pass": 0, "fail": 0, "not_applicable": 0, "errors": 0, "warnings": 0}
    for r in results:
        counts[r.status] += 1
        if r.status == "fail":
            counts["errors" if r.severity == "error" else "warnings"] += 1
    return counts
