# DealScout UI system

The brief (§14A, §17) is the brand: restrained navy + one teal accent, soft greys, semantic red/amber/green for
warnings only, dense "terminal-grade" finance UI, light and dark modes. This file records how that is implemented so
every screen, chart and export stays consistent. Built with shadcn/ui (Base UI primitives, `base-nova` style) on
Tailwind v4.

## Colour

Single source of truth: [`data/design/palette.json`](data/design/palette.json). `web/scripts/gen-theme.mjs`
generates `--ds-*` CSS variables from it before every dev/build; `web/app/globals.css` maps them onto shadcn's
semantic tokens. Excel, PDF, PPTX and chart code read the same JSON. Never hard-code a hex value in a component.

| Role | Light | Dark | Notes |
|---|---|---|---|
| `primary` (buttons, selected toggles) | navy `#0B1F3A` | navy-100 `#DCE4EF` on navy text | 16.5:1 / 12.9:1 |
| `ring` (focus) | teal `#0FA3A3` | `#2EC4C4` | teal is never small text on white (3.1:1) |
| `link` (inline text links) | teal-700 `#0B7A7A` | `#2EC4C4` | 5.2:1 / 8.6:1 |
| `muted-foreground` | grey-600 `#4E5866` | `#93A0B1` | grey-500 failed on grey-50 bands (4.34:1) |
| `positive / warning / negative` | `#1E7B4A / #B54708 / #B42318` on their `*-bg` | `#47CD89 / #FDB022 / #F97066` | ≥4.7:1 on their tint; always with icon + text |
| `sidebar` | navy | near-black navy | teal logo mark |

Semantic colours appear only in `Badge` variants `positive | warning | negative` and `Alert`; they are never the only
signal (an icon and a word always accompany them).

## Type

- One family: Inter Variable, bundled via `@fontsource-variable/inter` (works offline; `next/font/google` would need
  network at build time). System sans fallback. Monospace only for codes (tickers, currency codes, keys).
- Body 14 px; dense tables 13 px; secondary text 12 px; page title 20 px semibold; section headings 14 px semibold.
- `font-variant-numeric: tabular-nums` on every `td`, `th`, `.num` and numeric input.
- Copy uses sentence case (app-design rule; deliberately not the Title Case the Vercel guidelines suggest).

## Density and measurements

| Element | Desktop | Touch (`pointer: coarse`) |
|---|---|---|
| Button / input / select / toggle | 32 px high (`h-8`), sm 28 px | min 44 px |
| Icon button | 28–32 px square | min 44 px |
| Table row | ~36 px, 13 px text, sticky muted header | horizontal scroll inside the bordered container; low-value columns hidden below `sm`/`md`/`lg` |
| Header bar | 48 px sticky; `scroll-padding-top: 3.5rem` keeps focus visible | same |
| Radius | 6 px (`--radius: 0.375rem`) | same |
| Forms | max-width 672 px (`max-w-2xl`), labels above fields, two-column pairs from `sm` | single column |
| Page gutter | 24 px (`p-6`) desktop, 16 px mobile | |

Depth strategy: **borders only** (1 px `--border`), no shadows on work surfaces; popovers/sheets keep the library's
shadow. No cards inside cards.

## Components and patterns

- Layout: collapsible icon sidebar (Workspace / Recent deals / Setup), sticky header with ⌘K command menu, AI status
  chip and theme toggle; the short disclaimer bar sits at the bottom of every screen.
- Lists: `Table` in a bordered container; whole row clickable but the company name is the real `<a>`; row actions
  in a `DropdownMenu`; filters and sort live in the URL query string.
- States: skeletons shaped like content while loading, `Empty` with a first action, `Alert` with "Try again" on
  errors, disabled controls say why (e.g. "Arrives in Milestone 3").
- Forms: react-hook-form + zod; `Field`/`FieldError` (role="alert"); validation on blur for text inputs, on change for
  selects/comboboxes; server errors keep input and receive focus; unsaved changes warn on unload.
- Option sets of 2–7 use `ToggleGroup` (selected = primary fill, not colour-only: it also carries `aria-pressed`).
- Long option lists use `SearchSelect` (Base UI Combobox with `autoHighlight`, Enter picks the first match).
- Destructive: archive is undoable (toast with Undo); hard delete is a confirm dialog that names the deal and says it
  cannot be undone, with the verb on the button ("Delete deal").
- Motion: library defaults only (≤200 ms, transform/opacity); `prefers-reduced-motion` disables it. No
  `transition: all` anywhere (patched in the generated shadcn components).

## Charts (dataviz skill)

- ECharts, SVG renderer, themed from `palette.json → chart` for light and dark separately.
- Categorical palette validated with the dataviz skill's `validate_palette.js` (lightness band, chroma floor, CVD and
  normal-vision separation, contrast) — light `#2F6DB5 #0FA3A3 #C98A1A #7158D1 #D5588F #4E9A2A`, dark
  `#3D6BD6 #0E9E97 #B37C16 #9070E4 #D45C8E #4F9A2C`. Brand navy is text/emphasis (the blended range bar), never a
  series colour. Gold WARNs on light contrast, so every chart has value labels or a table view.
- Sequential (teal, validated ordinal) for magnitude; diverging (rose ↔ grey ↔ teal) for sensitivity heatmaps, centred
  on the base case, base cell outlined.
- No dual-axis charts: "revenue/EBITDA + margin" is two aligned panels (amounts above, margin below).
- Projected periods carry a hatch texture as well as an "E" suffix (never colour alone).
- Every chart: hover tooltip, PNG/SVG download, Table toggle (accessible data view).

## Statement grid

- Sticky header and label column; 32 px rows; tabular figures; costs in parentheses.
- Keyboard: arrows move, Enter/F2/typing edits, Enter/Tab commit and move, Esc cancels, Delete clears, ⌘/Ctrl+Z undo,
  ⌘/Ctrl+Shift+Z redo, multi-cell paste from Excel at the selected cell.
- Computed subtotals are italic, muted and marked ƒ; failing checks tint the cell (amber/red) **and** show an icon and a
  message (title + accessible label).
- The cell inspector shows the source, the formula or entered text, and the change history.

## Documents and review (Milestone 3)

- **Documents tab**: drop zone with a "Choose files" button (drag is never the only way), per-step job progress
  (Read · Find statements · Map · AI · Prepare), paused/failed states with Resume, "Read again", delete with
  confirmation. A "No AI connected" notice offers Connect AI or continuing with tables and the dictionary.
- **Review tab**: resizable split (60/40). Left: values grouped by statement, 13 px rows, confidence badge with a text
  label and percentage, method icon (table / AI / you) with a text alternative, conflict note when the grid already
  holds a different value; filters (To review / Accepted / Rejected / All) and document in the URL (`show`, `doc`,
  `item`). Right: pdf.js page with the value boxed and its row banded; zoom 75–200 %; Excel/CSV sources show sheet and
  cell. Keyboard: ↑/↓ or J/K move, A accept, E edit (value + reason), R reject, Space select.
- Below the split: reconciliation (errors first), lines not recognised (map to a line item), items not found, AI
  answers rejected by verification. All collapsible.
- Phones: the split stacks; the table scrolls inside its own container; tabs and filters scroll horizontally.
- pdf.js assets (worker, CJK character maps, standard fonts) are copied into `public/` at build time; no CDN at runtime.

## Tagged filings, images and several documents (Milestone 4)

- HTML and tagged filings open in a fully sandboxed frame (`sandbox=""`, CSP `sandbox; default-src 'none'`) built
  from a sanitised copy: scripts, forms and external resources are removed, every tagged fact and table cell has an
  id, and selecting a value only changes the URL fragment (CSS `:target` boxes it, its row is banded). An "Open in a
  new tab" link is the fallback where a browser blocks embedded frames.
- Images of statements show the OCR'd value boxed; Word sources name the table, row and column.
- "Across documents" lists figures that differ between documents with the newer one marked preferred; the older value's
  row says so. Tagged values use a tag icon and read "Tagged fact in the filing".

## Valuation methods (Milestone 5)

- Valuation tab has line-style sub-tabs, one per method family, each with a Ready / Needs input / Error badge (icon +
  word). Results come first (range banner, stat tiles, charts, tables), inputs below in one form per section with
  "Save and run" / "Discard changes", an unsaved-changes note and a browser warning on leave.
- Money is typed in the deal's entry scale; percentages as percent; numbers validate on blur.
- LBO charts: debt by tranche as stacked bars (fixed tranche order, 2px surface gap, totals on top); leverage as one
  line with the covenant as a dashed reference; IRR heatmaps diverging around the target IRR, base case outlined.
- Analysis: scores as tiles with band badges; early-warning table with severity icon + word; one-off items table.

## Acquisition price (Milestone 6)

- First Valuation sub-tab. Order: headline range with the data quality score beside it (score, grade badge, the
  three components), implied multiples and premia as stat tiles, football field with the offer as a shaded band,
  market cap dashed and market reference points dotted (names on hover, values in the table view), checks (badge
  with icon + word), rationale, EV-to-equity waterfall (totals navy; debt-like and cash-like steps on the two
  diverging poles with a signed label), then the weighting table and the premium range.

## Exports (Milestone 7)

- One style module (`api/src/dealscout_api/exports/style.py`) for every export: palette from `palette.json`, Calibri
  in Excel and PowerPoint (Helvetica in the PDF, a standard PDF font), navy section bands, grey header rows, zebra
  rows, number formats with negatives in parentheses and zeros as a dash, `0.0x` multiples, units in every header.
- Excel: banking colours (inputs blue, links to other tabs green, formulas black); gridlines off; column A as a
  margin; frozen panes; "← Back to Report" on every tab; tab colours by type (navy report/summary, teal model, grey
  method results, light grey sources/disclaimer); A4 fit-to-width with the AI disclaimer and page numbers in the
  footer; native charts only, with no dual axes (revenue/EBITDA and margin are separate charts).
- Status in exports is never colour alone: "● Pass", "▲ Check", "■ Fail" / "■ High", "▲ Medium", "● No concern".
- PowerPoint: one 16:9 slide, navy title panel, three stat callouts, a native football-field chart, rationale and
  checks; no decorative stripes; the AI notice in the speaker notes and the disclaimer along the bottom.
- Live method tabs (`exports/live_methods.py`): LBO, Precedents and NAV & SOTP use the model-tab colour (teal tab)
  and the same layout as the DCF chain: an inputs block (blue), a formula-driven body, an engine check cell (✓ / ✗)
  and, below a navy band, the engine-only outputs (LBO goal seek, sensitivity tables). The LBO's interest solver
  passes sit in a collapsed row group under the visible debt schedule; years after the exit year are greyed by
  conditional formatting. LBO charts: debt by tranche (stacked columns, series named by tranche) and leverage as a
  separate line chart.
- Report breakdowns (`exports/report_breakdowns.py`), between the rationale and the early warning signs, in pairs
  of compact tables followed by two half-width native charts (11.3 cm × 6.6 cm, anchored at B and E): segment and
  geography mix (stacked columns), cost structure (% of revenue, lines), EBITDA margin bridge and EBITDA to free cash
  flow (waterfalls), working capital days (lines), capital structure (stacked columns) and debt maturities vs
  liquidity (columns, liquidity bar in the second categorical colour and named on the axis). Waterfalls: invisible
  base series (hidden from the legend), increases and decreases on the diverging palette's teal and rose poles,
  totals navy, with short category labels and the signed values in the table. Helper data lives in hidden columns
  J to P. A breakdown without data shows a one-line italic note instead.
- Web Analysis tab: capital structure (stacked bars: borrowings, leases, book equity, debt share labelled on top) and
  the debt maturity profile (bars by bucket, liquidity as a dashed reference line; a within-one-year bar above
  liquidity turns rose and says "above liquidity").
- `scripts/export_examples.py --snapshots` regenerates `docs/examples/` and PNG snapshots of the Report and
  Financials pages for visual comparison.

## Hardening (Milestone 8)

- Chart tooltips that build HTML escape every interpolated name with `esc()` (`components/charts/echart.tsx`).
- Missing assumptions are announced as "not set" (not a dash) to screen readers.
- End-to-end test `web/e2e/main-flow.spec.ts` covers create deal → upload → review → assumptions → acquisition price →
  analysis → Create Excel, and produces the README screenshots.

## Deal cockpit (UX upgrade, option B)

- A deal opens on **Summary**: the suggested price range with per-share and implied EV/EBITDA, the data quality score,
  five headline numbers (revenue, EBITDA margin, net debt/EBITDA, LBO sponsor IRR, warning signs), the football field
  with the offer band, and a **to-do list** ranked by importance (high ▲ icon in red, medium in amber, info neutral;
  icon plus wording, never colour alone). Each to-do links to the exact tab and valuation sub-tab that resolves it.
- The valuation sub-tab is in the URL (`&method=lbo`), so links and the back button work.
- Add-data shortcuts and deal details stay below the cockpit.

## Polish pass (design-taste-frontend, audited with ui-ux-pro-max)

- Scope: the skill targets marketing pages, so only its product-UI rules were applied. Palette and Inter unchanged.
- No em or en dashes as separators in visible copy (labels, messages, exports): colons, "to" for ranges, brackets
  or full stops instead. A lone "–"/"—" standing for zero or no value is kept (accounting convention, above).
- Loading states are shaped like the screen they replace (`CockpitSkeleton`) and announce `aria-busy`.
- Buttons animate colour, shadow, opacity and transform only (no width/height transitions).
- Audit fix: the cockpit's to-do links show a visible inset focus ring on keyboard focus.

## Theme default

- The app opens in the light theme (owner's choice); the header button switches to dark, and the choice is remembered
  per browser. Both themes stay fully supported.

## Versions, scenarios, modes and long lists

- **Saved versions** live on the deal's "Versions and activity" tab (also reached from the header's Versions button):
  a table of saved versions (date and author, name with note, equity price range) with "Compare with current" (a
  sheet: results side by side with signed changes, then changed assumptions and settings, then changed values) and
  "Restore" (confirm dialog that says the current state is saved first as an "Automatic" version, so a restore is
  undoable). Versions are immutable.
- **Scenario editor** sits under the WACC table and scenario chart on Summary & DCF: one row per scenario (name,
  probability %, growth / margin / WACC / terminal growth shifts in pp, exit multiple shift in x), up to 6, with
  "Add scenario", "Use bear, base, bull", "Discard changes" and "Save and run". The running total of probabilities
  shows an icon and words (never colour alone).
- **Mode**: a Quick Scan / Detailed toggle in Deal details. Detailed shows per-year inputs for the five operating
  drivers ("Set years"), every assumption and every method tab. Quick Scan keeps single values, tucks rarely used
  assumptions and the conventions behind "Show every assumption", and shows only Acquisition price, Summary & DCF
  and methods that already have a result, with "Show all methods (n more)".
- **Long lists**: the deals list and the review table are virtualised with `@tanstack/react-virtual` (spacer rows in
  a real `<table>`, so columns, sticky headers and row semantics stay). Each scrolls inside its own bordered area;
  ↑/↓ (and J/K in review) scroll the next row into view before focusing it; deep links (`?item=`) scroll to the row.

## Known gaps (tracked)

- Excel/CSV sources show sheet and cell, not a rendered sheet preview.

- No bulk actions on the deal list yet (ui-ux-pro-max "data table" guideline, severity low).
- M5 audits done (break-ui with 300 transactions, 10^15 values, negatives, long multilingual names; rules pass;
  ui-ux-pro-max checklist at 375 px, light and dark). Rules adopted: every horizontal scroll container is `relative`
  (keeps `sr-only` text inside); fieldsets have `min-inline-size: 0`; table row labels clamp to two lines with the
  full text on hover; ranges read "X to Y"; number fields select on focus and show errors visibly below the field;
  native selects and checkboxes get 44 px touch targets.

## Text warning signs and sector KPIs

- Early-warning table: signs found in document text sit with the figure-based ones; under the signal a link reads
  "p. N, filename" (opens the PDF at that page, or the sanitised HTML view) and shows the quote in a tooltip on hover
  or focus (also in screen-reader text). Their metric column reads "Text", or the printed share for customer
  concentration. Excel Report and PDF append "Source: p. N, filename: "quote"" to the explanation.
- Sector KPIs: a block below the ratio table, only for bank, insurer, SaaS, real estate and retail templates, with the
  ratio table's conventions (sparkline, n/m, popover with formula, inputs and "reported" or "computed"). Excel shows
  them under the ratios on the Financials tab; percent rows use the `0.0%` format.
