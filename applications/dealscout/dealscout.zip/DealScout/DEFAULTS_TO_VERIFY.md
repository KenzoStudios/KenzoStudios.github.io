# Defaults to verify

`data/defaults/market_assumptions.yaml` (version 2026.11.0, compiled 2026-11-19) follows one rule from the
product brief: **no invented figures**. Every number in it was read at the `source_url` on that entry, and
the entry records the date of that number in `as_of`. Where no citable public source could be found, the value
is `null` with `status: placeholder`. The engine never uses a placeholder silently: it asks you for the value.
`status: convention` marks a stated market convention, such as the 20% target IRR.

Fill a placeholder by editing the YAML (or the Defaults screen). Give it a value, `as_of`, `source`,
`source_url`, and set `status: verified`.

## Placeholders (value is null)

| Path in the YAML | What it means | Suggested source |
|---|---|---|
| `risk_free_rates.ARS` | 10Y local-currency government yield, Argentina | BCRA / Ministry of Economy (Secretaría de Finanzas). There may be no liquid 10Y fixed-rate peso bond; consider a USD-based cost of capital instead |
| `risk_free_rates.AED` | 10Y local-currency government yield, UAE | UAE Ministry of Finance dirham T-bond auction results / CBUAE |
| `risk_free_rates.SAR` | 10Y local-currency government yield, Saudi Arabia | Saudi National Debt Management Center, riyal sukuk yields |
| `risk_free_rates.QAR` | 10Y local-currency government yield, Qatar | Qatar Central Bank government bond yields (the Trading Economics quote was stale, February 2023) |
| `risk_free_rates.EGP` | 10Y local-currency government yield, Egypt | Central Bank of Egypt, treasury bond auction results |
| `control_premia.default` (`low`, `median`, `high`) | One-day / announcement premium paid in public takeovers | FactSet Review (formerly Mergerstat Review) or the FactSet BVR Control Premium Study (both paid), Kroll. Free law-firm public M&A reviews (Skadden, Davis Polk, Slaughter and May) report averages with conflicting samples and methods, and none gives a low / median / high distribution |
| `lbo.total_leverage_x_ebitda` (`low`, `typical`, `high`) | Total debt / EBITDA at LBO close | PitchBook LCD quarterly LBO statistics (US and Europe). For a supervisory upper reference, see the ECB *Guidance on leveraged transactions* (2017) |
| `lbo.senior_leverage_x_ebitda` (`low`, `typical`, `high`) | Senior / first-lien debt / EBITDA at close | PitchBook LCD first-lien leverage statistics |
| `lbo.senior_margin_bps` (`low`, `typical`, `high`) | Senior term-loan margin over the base rate | PitchBook LCD new-issue spreads (B / B+ term loan B, over SOFR / EURIBOR), Morningstar LSTA index |
| `dlom.default` (`low`, `typical`, `high`) | Discount for lack of marketability, private companies | Stout Restricted Stock Study, Valuation Advisors pre-IPO study, IRS *DLOM Job Aid* (2009, irs.gov/pub/irs-lbi/dlom.pdf) |

**Null by design, not a placeholder:** `sector_multiples.banks.ev_ebitda`. Damodaran reports EV/EBITDA as NA
for banks, because EV-based multiples are not meaningful for them. Use P/E or P/B for banks.

## Verified values whose source is older than 90 days

These values were checked against their source on 2026-11-19, but the source's own date is more than 90 days
before that date (before 2026-08-21). Refresh them when the source updates. Damodaran's next full update is
January 2027.

- **`country_risk_premia.*`**: 52 countries (all except US). Source: Damodaran `ctryprem.html`, dated
  2026-01-05; the `TR` row is marked "updated February 2026". A newer **July 1, 2026** update exists, but only
  as an Excel file (`pc/datasets/ctrypremJuly26.xlsx`). It was not downloaded, so refreshing from it is the
  first thing to do.
- **`sector_unlevered_betas.*`**: all 20 sectors. Source: Damodaran `Betas.html` (US), January 2026.
- **`sector_multiples.*`**: all 20 sectors. Source: Damodaran `vebitda.html`, `psdata.html` and `pedata.html`
  (US), January 2026.
- **`tax_rates.*`**: all 53 countries. Source: Damodaran `countrytaxrates.html`, January 2026 update (source
  PwC). The `ZA` value comes from the `ctryprem.html` tax column (2026-01-05), because South Africa is missing
  from `countrytaxrates.html`.

The risk-free rates, the ERP (2026-11-01) and the base rates (October to November 2026) are all within 90 days.

## Verified, but worth upgrading or double-checking

- **Rates from Trading Economics** (a market-data aggregator, not an official source). Replace these with
  central-bank or debt-office data when you can: `risk_free_rates` CNY, BRL, SGD, HKD, COP, PEN, ISK, RON, TRY,
  NGN, KES, TWD, MYR, THB, IDR, PHP and VND. The MAS SGS page was in maintenance on 2026-11-19. HKMA's API has
  no constant-maturity 10Y HKGB yield.
- **Monthly averages, not daily closes.** These rates are October 2026 OECD averages via FRED: CHF, AUD, DKK,
  INR, MXN, ZAR, KRW, PLN, CLP, CZK, HUF, ILS and NZD. `lbo.base_rates.EURIBOR_3M` is an October 2026 ECB
  monthly average.
- **`country_risk_premia.US` = 0.0** (`status: convention`). Damodaran's November 2026 ERP is stated against the
  raw Treasury yield. His January 2026 table shows a 0.23% US premium, but that applies only when the default
  spread is netted out of the Treasury rate.
- **Sector data is US-region.** The free HTML pages cover US industries only. Global and Europe versions exist
  only as Excel files. The industry chosen for each sector is in its `mapped_from` field. Judgement calls:
  hardware → Semiconductor; healthcare → Healthcare Support Services; consumer_discretionary → Retail
  (Special Lines); energy → Oil/Gas (Production and Exploration); real_estate → R.E.I.T.; holding → Diversified.
- **Which source columns were used:**
  - Betas: Damodaran's "Unlevered beta corrected for cash".
  - EV/EBITDA: the "only positive EBITDA firms" column.
  - P/E: "Aggregate Mkt Cap / Trailing Net Income (only money making firms)". Damodaran's simple-average
    "Trailing PE" column is distorted by outliers; for example it shows 314x for Retail (Special Lines).
