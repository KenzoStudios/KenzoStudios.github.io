"""Per-provider extraction accuracy on the public filings (brief §3, §16). A manual command: it uses YOUR keys.

    uv run python scripts/provider_accuracy.py                    # plan only: providers with a key, documents, cost
    uv run python scripts/provider_accuracy.py --yes              # run every provider that has a key
    uv run python scripts/provider_accuracy.py --providers anthropic,gemini --yes --write
    uv run python scripts/provider_accuracy.py --model openai=gpt-6.2-astra --providers openai --yes

Each provider is asked for the manifest's core items on the relevant pages (the same request the app makes for items
the statements don't show), so the score measures the AI itself, not the rules-based reading underneath. Figures are
verified against the pages exactly as in the app; unverifiable answers count as not found.

``--write`` stores the result in ``data/ai/provider_accuracy.json`` (the Connect AI screen shows the tier from it) and
refreshes the table in ``docs/providers.md``. Keys come from the OS keychain or ``.env`` as in the app; they are never
printed or written anywhere.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "tests" / "fixtures" / "manifest.yaml"
RESULTS = ROOT / "data" / "ai" / "provider_accuracy.json"
PROVIDERS_DOC = ROOT / "docs" / "providers.md"
START, END = "<!-- accuracy:start -->", "<!-- accuracy:end -->"
# capex in the manifest is the cash-flow line as printed: ask for both lines
ASK_FOR = {"capex": ["capex", "capex_ppe"]}
TOKENS_PER_PAGE = 2_000  # rough planning figure for a statement page sent as text or PDF


def _accuracy_module() -> Any:
    spec = importlib.util.spec_from_file_location("accuracy_report", ROOT / "scripts" / "accuracy_report.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


@dataclass
class ProviderResult:
    provider: str
    model: str
    correct: int = 0
    wrong: int = 0
    missed: int = 0
    cost_usd: float = 0.0
    cost_known: bool = True
    seconds: float = 0.0
    documents: int = 0
    errors: list[str] = field(default_factory=list)
    details: list[str] = field(default_factory=list)

    @property
    def scored(self) -> int:
        return self.correct + self.wrong + self.missed

    @property
    def accuracy(self) -> float:
        return self.correct / self.scored if self.scored else 0.0

    @property
    def tier(self) -> str:
        if self.scored < 20 or self.errors:
            return "untested"
        return "high" if self.accuracy >= 0.95 else "medium" if self.accuracy >= 0.85 else "limited"


def evaluate_provider(provider: Any, specs: list[dict], download_dir: Path) -> ProviderResult:
    """Run one provider over the manifest documents and score its answers."""
    from dealscout_engine.taxonomy import load_taxonomy
    from dealscout_extraction.ai_extract import ai_extract_missing
    from dealscout_extraction.pipeline import extract_rules

    accuracy = _accuracy_module()
    taxonomy = load_taxonomy()
    result = ProviderResult(provider=provider.provider_id, model=provider.model)
    for spec in specs:
        path = download_dir / spec["filename"]
        if not path.exists():
            continue
        content = path.read_bytes()
        rules = extract_rules(content, path.name, taxonomy)
        located = {t.page for tables in rules.located.values() for t in tables}
        concepts = sorted({c for e in spec["expected"] for c in ASK_FOR.get(e["concept"], [e["concept"]])})
        started = time.time()
        try:
            outcome = ai_extract_missing(
                provider, content, rules.doc, concepts, taxonomy, located_pages=located, page_limit=8
            )
        except Exception as error:  # an AIError (key, credit, rate limit) ends this provider's run
            result.errors.append(f"{spec['id']}: {getattr(error, 'message', error)}")
            break
        result.seconds += time.time() - started
        result.documents += 1
        for usage in outcome.usage:
            if usage.estimated_cost_usd is None:
                result.cost_known = False
            else:
                result.cost_usd += usage.estimated_cost_usd
        doc = accuracy.score(
            accuracy.DocResult(id=spec["id"], country=spec["country"], status="read"), outcome.candidates, spec
        )
        result.correct += doc.correct
        result.wrong += len(doc.wrong)
        result.missed += len(doc.missed)
        result.details += [f"{spec['id']}: {w}" for w in doc.wrong]
    return result


def _plan(specs: list[dict], download_dir: Path, providers: list[tuple[str, str]]) -> str:
    from dealscout_ai.pricing import price_for

    present = [s for s in specs if (download_dir / s["filename"]).exists()]
    tokens = len(present) * 8 * TOKENS_PER_PAGE
    lines = [f"{len(present)} documents downloaded; about {tokens:,} input tokens per provider (8 pages each)."]
    for provider_id, model in providers:
        price = price_for(provider_id, model)
        cost = (
            f"≈ ${tokens * price.input_per_mtok / 1e6 + len(present) * 2000 * price.output_per_mtok / 1e6:.2f}"
            if price
            else "cost unknown"
        )
        lines.append(f"  {provider_id:<13} {model:<32} {cost}")
    return "\n".join(lines)


def _write(results: list[ProviderResult], specs: list[dict]) -> None:
    previous = json.loads(RESULTS.read_text(encoding="utf-8")) if RESULTS.exists() else {"providers": {}}
    for r in results:
        previous["providers"][r.provider] = {
            "model": r.model,
            "tier": r.tier,
            "correct": r.correct,
            "scored": r.scored,
            "accuracy": round(r.accuracy, 4),
            "cost_usd": round(r.cost_usd, 4) if r.cost_known else None,
            "seconds": round(r.seconds, 1),
            "documents": r.documents,
            "date": date.today().isoformat(),
        }
    previous["documents"] = [s["id"] for s in specs]
    RESULTS.parent.mkdir(parents=True, exist_ok=True)
    RESULTS.write_text(json.dumps(previous, indent=2) + "\n", encoding="utf-8")
    table = [
        START,
        "",
        "| Provider | Model | Correct | Accuracy | Tier | Cost for the run | Date |",
        "|---|---|---|---|---|---|---|",
    ]
    for provider_id, r in sorted(previous["providers"].items()):
        cost = f"${r['cost_usd']:.2f}" if r.get("cost_usd") is not None else "unknown"
        table.append(
            f"| {provider_id} | `{r['model']}` | {r['correct']}/{r['scored']} | {100 * r['accuracy']:.0f}% | "
            f"{r['tier']} | {cost} | {r['date']} |"
        )
    table += ["", END]
    text = PROVIDERS_DOC.read_text(encoding="utf-8")
    if START in text and END in text:
        text = text[: text.index(START)] + "\n".join(table) + text[text.index(END) + len(END) :]
    else:
        text += "\n## Measured extraction accuracy\n\n" + "\n".join(table) + "\n"
    PROVIDERS_DOC.write_text(text, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--providers", help="comma-separated provider ids (default: every provider with a key)")
    parser.add_argument("--model", action="append", default=[], help="provider=model override (repeatable)")
    parser.add_argument("--documents", help="comma-separated manifest document ids (default: all downloaded)")
    parser.add_argument("--yes", action="store_true", help="make the live, billed calls")
    parser.add_argument("--write", action="store_true", help="store results and refresh docs/providers.md")
    args = parser.parse_args()

    from sqlmodel import Session

    from dealscout_ai.keystore import KeyStore
    from dealscout_ai.registry import PROVIDERS
    from dealscout_api.config import get_settings
    from dealscout_api.db import init_engine
    from dealscout_api.services.ai_service import AIService

    manifest = yaml.safe_load(MANIFEST.read_text(encoding="utf-8"))
    download_dir = ROOT / manifest["download_dir"]
    wanted_docs = set(args.documents.split(",")) if args.documents else None
    specs = [s for s in manifest["documents"] if wanted_docs is None or s["id"] in wanted_docs]
    settings = get_settings()
    service = AIService(settings, KeyStore(settings.secrets_dir))
    overrides = dict(m.split("=", 1) for m in args.model)
    chosen = args.providers.split(",") if args.providers else list(PROVIDERS)
    engine = init_engine(settings.db_path)
    runnable: list[tuple[str, Any]] = []
    with Session(engine) as session:
        for provider_id in chosen:
            spec = PROVIDERS.get(provider_id)
            if spec is None:
                print(f"Unknown provider {provider_id!r}.", file=sys.stderr)
                return 2
            key, _ = service.resolve_key(provider_id)
            if spec.key_required and not key:
                if args.providers:
                    print(f"{spec.label}: no key in the keychain or .env — skipped.")
                continue
            try:
                runnable.append(
                    (provider_id, service.adapter_for(session, provider_id, model=overrides.get(provider_id)))
                )
            except Exception as error:  # incomplete connection (Azure endpoint, custom URL …)
                print(f"{spec.label}: not set up ({getattr(error, 'message', error)}) — skipped.")
    if not runnable:
        print("No provider has a key. Connect one in the app (Settings → Connect AI) or set it in .env.")
        return 1
    print(_plan(specs, download_dir, [(p, a.model) for p, a in runnable]))
    if not args.yes:
        print("\nPlan only. Add --yes to make these live, billed calls with your keys.")
        return 0
    results = []
    for provider_id, adapter in runnable:
        print(f"\n{provider_id} · {adapter.model} …", flush=True)
        result = evaluate_provider(adapter, specs, download_dir)
        results.append(result)
        cost = f"${result.cost_usd:.2f}" if result.cost_known else "cost unknown"
        print(
            f"  {result.correct}/{result.scored} correct ({100 * result.accuracy:.0f}%), tier {result.tier}, {cost}, "
            f"{result.seconds:.0f}s"
        )
        for line in result.errors + result.details[:10]:
            print(f"  - {line}")
    if args.write:
        _write(results, specs)
        print(f"\nWrote {RESULTS.relative_to(ROOT)} and refreshed docs/providers.md.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
