# Windows equivalent of the Makefile:  .\scripts\tasks.ps1 test|lint|format|seed|web-build
param([Parameter(Mandatory = $true)][ValidateSet("test", "lint", "format", "seed", "web-build")][string]$Task)
$ErrorActionPreference = "Stop"
Set-Location -Path (Join-Path $PSScriptRoot "..")
switch ($Task) {
    "test"      { uv run pytest }
    "lint"      { uv run ruff check .; uv run ruff format --check .; uv run mypy engine/src ai/src extraction/src api/src; Push-Location web; npm run lint; Pop-Location }
    "format"    { uv run ruff format .; uv run ruff check --fix .; Push-Location web; npm run format; Pop-Location }
    "seed"      { uv run python -m dealscout_api.seed }
    "web-build" { uv run python scripts/web_build.py --force }
}
