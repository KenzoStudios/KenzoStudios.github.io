"""Write sample exports for a synthetic fixture company to docs/examples/ (brief §14A).

    uv run python scripts/export_examples.py            # workbook, tear sheet, slide
    uv run python scripts/export_examples.py --snapshots  # also render Report and Financials pages to PNG

The fixture is made up (no real company data). Snapshots need LibreOffice; compare them before and after a change
to catch visual regressions in the workbook layout.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs" / "examples"
M = 1e6


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--snapshots", action="store_true")
    args = parser.parse_args()
    os.environ["DEALSCOUT_DATA_DIR"] = tempfile.mkdtemp(prefix="dealscout-examples-")
    os.environ["DEALSCOUT_TEST_NO_KEYRING"] = "1"
    from fastapi.testclient import TestClient
    from sqlmodel import Session

    from dealscout_api.app import create_app
    from dealscout_api.config import get_settings
    from dealscout_api.exports.context import build_context
    from dealscout_api.exports.pdf import build_pdf
    from dealscout_api.exports.pptx import build_pptx
    from dealscout_api.exports.quality import check_workbook, soffice_path
    from dealscout_api.exports.workbook import build_workbook
    from dealscout_api.models import Deal

    app = create_app(get_settings())
    with TestClient(app, base_url="http://127.0.0.1:8000") as c:
        deal = c.post(
            "/api/deals",
            json={
                "name": "Fixture Industrial AG (synthetic)",
                "country": "de",
                "sector": "industrials",
                "industry": "Machinery",
                "listed": True,
                "ticker": "FIXT",
                "reporting_currency": "eur",
                "perspective": "financial_sponsor",
                "valuation_date": "2026-03-31",
            },
        ).json()
        rows = {
            "revenue": {"FY2023": 800 * M, "FY2024": 900 * M, "FY2025": 1000 * M},
            "ebitda": {"FY2023": 120 * M, "FY2024": 140 * M, "FY2025": 160 * M},
            "da_total": {"FY2023": -32 * M, "FY2024": -36 * M, "FY2025": -40 * M},
            "capex": {"FY2023": -40 * M, "FY2024": -45 * M, "FY2025": -50 * M},
            "net_income": {"FY2023": 50 * M, "FY2024": 60 * M, "FY2025": 70 * M},
            "cogs": {"FY2023": -480 * M, "FY2024": -531 * M, "FY2025": -580 * M},
            "sga": {"FY2023": -150 * M, "FY2024": -170 * M, "FY2025": -186 * M},
            "rnd": {"FY2023": -50 * M, "FY2024": -59 * M, "FY2025": -74 * M},
            "change_in_working_capital": {"FY2023": -8 * M, "FY2024": -10 * M, "FY2025": -12 * M},
            "taxes_paid": {"FY2023": -20 * M, "FY2024": -24 * M, "FY2025": -28 * M},
            "cfo": {"FY2023": 88 * M, "FY2024": 102 * M, "FY2025": 116 * M},
            "receivables": {"FY2023": 130 * M, "FY2024": 150 * M, "FY2025": 172 * M},
            "inventory": {"FY2023": 90 * M, "FY2024": 98 * M, "FY2025": 110 * M},
            "payables": {"FY2023": 70 * M, "FY2024": 76 * M, "FY2025": 82 * M},
            "st_debt": {"FY2023": 40 * M, "FY2024": 45 * M, "FY2025": 50 * M},
            "lt_debt": {"FY2023": 320 * M, "FY2024": 300 * M, "FY2025": 250 * M},
            "non_current_lease_liabilities": {"FY2023": 40 * M, "FY2024": 38 * M, "FY2025": 36 * M},
            "cash": {"FY2023": 70 * M, "FY2024": 85 * M, "FY2025": 100 * M},
            "total_equity": {"FY2023": 560 * M, "FY2024": 625 * M, "FY2025": 700 * M},
            "shares_outstanding": {"FY2025": 50 * M},
            "credit_facilities": {"FY2025": 80 * M},
            "debt_due_within_1y": {"FY2025": 50 * M},
            "debt_due_1_2y": {"FY2025": 60 * M},
            "debt_due_2_5y": {"FY2025": 150 * M},
            "debt_due_after_5y": {"FY2025": 40 * M},
        }
        changes = [{"concept_id": k, "period_key": p, "value": v} for k, ps in rows.items() for p, v in ps.items()]
        c.put(f"/api/deals/{deal['id']}/financials/cells", json={"changes": changes, "source": "manual"})
        c.put(
            f"/api/deals/{deal['id']}/assumptions",
            json={
                "overrides": {
                    "risk_free_rate": 0.03,
                    "equity_risk_premium": 0.05,
                    "unlevered_beta": 0.9,
                    "tax_rate": 0.3,
                    "pre_tax_cost_of_debt": 0.05,
                    "country_risk_premium": 0.0,
                    "share_price": 22.0,
                }
            },
        )
        c.put(
            f"/api/deals/{deal['id']}/methods/lbo",
            json={
                "entry_multiple": 9.0,
                "max_leverage": 5.0,
                "tranches": [
                    {
                        "name": "Term loan B",
                        "kind": "term_loan_b",
                        "size_x_ebitda": 3.0,
                        "rate_type": "floating",
                        "margin": 0.0375,
                    },
                    {
                        "name": "Senior notes",
                        "kind": "senior_notes",
                        "size_x_ebitda": 1.0,
                        "rate_type": "fixed",
                        "fixed_rate": 0.07,
                    },
                ],
            },
        )
        c.put(
            f"/api/deals/{deal['id']}/methods/precedents",
            json={
                "transactions": [
                    {
                        "announced": f"202{i}-06-30",
                        "target": f"Synthetic target {i}",
                        "ev": (8 + i) * 100 * M,
                        "ebitda": 100 * M,
                    }
                    for i in range(1, 5)
                ]
            },
        )
        c.put(
            f"/api/deals/{deal['id']}/methods/breakdowns",
            json={
                "segments": [
                    {"name": "Machines", "revenue": {"FY2023": 520 * M, "FY2024": 570 * M, "FY2025": 620 * M}},
                    {"name": "Services", "revenue": {"FY2023": 200 * M, "FY2024": 240 * M, "FY2025": 280 * M}},
                    {"name": "Spare parts", "revenue": {"FY2023": 80 * M, "FY2024": 90 * M, "FY2025": 100 * M}},
                ],
                "geographies": [
                    {"name": "Germany", "revenue": {"FY2023": 360 * M, "FY2024": 390 * M, "FY2025": 420 * M}},
                    {"name": "Rest of Europe", "revenue": {"FY2023": 280 * M, "FY2024": 320 * M, "FY2025": 350 * M}},
                    {"name": "Americas", "revenue": {"FY2023": 160 * M, "FY2024": 190 * M, "FY2025": 230 * M}},
                ],
            },
        )
        c.put(
            f"/api/deals/{deal['id']}/methods/premium", json={"low": 0.2, "high": 0.4, "source": "Illustrative range"}
        )
        with Session(app.state.engine) as session:
            ctx = build_context(session, session.get(Deal, deal["id"]))
            workbook = build_workbook(ctx)
            quality = check_workbook(
                workbook, footer=ctx.disclaimers["print_footer"], notice=ctx.disclaimers["ai_report_notice"]
            )
            if not quality.ok:
                sys.exit(f"workbook failed its checks: {quality.errors + quality.problems}")
            OUT.mkdir(parents=True, exist_ok=True)
            (OUT / "fixture-analysis.xlsx").write_bytes(workbook)
            (OUT / "fixture-tear-sheet.pdf").write_bytes(build_pdf(ctx))
            (OUT / "fixture-one-pager.pptx").write_bytes(build_pptx(ctx))
    print(f"wrote {OUT} (workbook recalculated: {quality.recalculated})")
    if args.snapshots:
        soffice = soffice_path()
        if soffice is None:
            sys.exit("LibreOffice is needed for snapshots")
        import pymupdf

        with tempfile.TemporaryDirectory() as tmp:
            subprocess.run(
                [
                    soffice,
                    f"-env:UserInstallation={Path(tmp, 'p').as_uri()}",
                    "--headless",
                    "--convert-to",
                    "pdf",
                    "--outdir",
                    tmp,
                    str(OUT / "fixture-analysis.xlsx"),
                ],
                capture_output=True,
                check=False,
            )
            pdf = pymupdf.open(Path(tmp) / "fixture-analysis.pdf")
            snaps = OUT / "snapshots"
            snaps.mkdir(exist_ok=True)
            names = {0: "report-page-1", 1: "report-page-2"}
            for i in range(pdf.page_count):
                if "Financial analysis" in pdf[i].get_text() and "financials-page-1" not in names.values():
                    names[i] = "financials-page-1"
            for i, name in names.items():
                if i < pdf.page_count:
                    pdf[i].get_pixmap(dpi=80).save(snaps / f"{name}.png")
        print(f"snapshots in {snaps}")


if __name__ == "__main__":
    main()
