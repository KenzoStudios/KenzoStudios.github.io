"""Extraction accuracy against the hand-read public filings in tests/fixtures/manifest.yaml.

    uv run python scripts/accuracy_report.py            # rules only (no AI), prints a table
    uv run python scripts/accuracy_report.py --write    # also writes docs/accuracy.md

A value counts as correct when the extracted figure, as written in the document, equals the hand-read figure
(sign ignored: the manifest records the print, the app stores the taxonomy sign) and the page matches. Items the
manifest records as null (not a single line on the statements) are scored separately: the right answer is "not
found", and any value we return for them is listed for review rather than counted as an error.

Documents in a format the current release does not read are listed as skipped.
"""

from __future__ import annotations

import argparse
import sys
import time
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

import yaml

from dealscout_engine.taxonomy import load_taxonomy
from dealscout_extraction.mapping import Candidate
from dealscout_extraction.numbers import parse_number
from dealscout_extraction.pipeline import extract

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "tests" / "fixtures" / "manifest.yaml"
READ_NOW = {"pdf", "xlsx", "xls", "csv", "htm", "html", "xhtml", "xbrl", "zip", "docx"}
# the manifest's "capex" is the cash flow line as printed: total capex where shown, else PP&E capex
ALTERNATIVES = {"capex": ["capex", "capex_ppe"]}


@dataclass
class DocResult:
    id: str
    country: str
    status: str  # read | skipped | missing
    seconds: float = 0.0
    correct: int = 0
    wrong: list[str] = field(default_factory=list)
    missed: list[str] = field(default_factory=list)
    null_ok: int = 0
    null_found: list[str] = field(default_factory=list)

    @property
    def scored(self) -> int:
        return self.correct + len(self.wrong) + len(self.missed)


def _number(text: str | None, decimal_hint: str | None) -> float | None:
    if text is None:
        return None
    value = parse_number(str(text), decimal_hint=decimal_hint).value  # type: ignore[arg-type]
    return None if value is None else abs(value)


def _decimal_hint(number_format: str) -> str | None:
    fmt = number_format.lower()
    if "thousands '.'" in fmt or 'thousands "."' in fmt:
        return ","
    if "thousands ','" in fmt:
        return "."
    return None


def evaluate(doc_spec: dict, download_dir: Path) -> DocResult:
    result = DocResult(id=doc_spec["id"], country=doc_spec["country"], status="read")
    path = download_dir / doc_spec["filename"]
    if not path.exists():
        result.status = "missing"
        return result
    kind = path.suffix.lower().lstrip(".")
    if kind not in READ_NOW:
        result.status = "skipped"
        return result
    started = time.time()
    out = extract(path.read_bytes(), path.name, load_taxonomy())
    result.seconds = time.time() - started
    return score(result, out.candidates, doc_spec)


def score(result: DocResult, candidates: list[Candidate], doc_spec: dict) -> DocResult:
    """Compare candidates with the hand-read values of one manifest document (shared with provider_accuracy.py)."""
    hint = _decimal_hint(doc_spec.get("number_format", ""))
    found: dict[tuple[str, str], Candidate] = {(c.concept_id, c.period_key): c for c in candidates}
    for expected in doc_spec["expected"]:
        concept, period = expected["concept"], expected["period"]
        candidate = next(
            (found[(c, period)] for c in ALTERNATIVES.get(concept, [concept]) if (c, period) in found), None
        )
        tag = f"{concept} {period}"
        if expected.get("value_as_written") is None:
            if candidate is None:
                result.null_ok += 1
            else:
                result.null_found.append(f"{tag}: returned {candidate.value_as_written} (p. {candidate.page})")
            continue
        if candidate is None:
            result.missed.append(f"{tag}: expected {expected['value_as_written']} (p. {expected.get('page')})")
            continue
        want = _number(expected["value_as_written"], hint)
        got = _number(candidate.value_as_written, hint)
        page_ok = not isinstance(expected.get("page"), int) or expected["page"] == candidate.page
        if want is not None and got is not None and abs(want - got) <= 1e-9 * max(1.0, want) and page_ok:
            result.correct += 1
        else:
            result.wrong.append(
                f"{tag}: got {candidate.value_as_written} p. {candidate.page}, "
                f"expected {expected['value_as_written']} p. {expected.get('page')}"
            )
    return result


def render(results: list[DocResult]) -> str:
    scored = [r for r in results if r.status == "read"]
    correct = sum(r.correct for r in scored)
    total = sum(r.scored for r in scored)
    lines = [
        "# Extraction accuracy",
        "",
        f"Run {date.today().isoformat()} with tables and the dictionary only (no AI). Documents and hand-read "
        "values: `tests/fixtures/manifest.yaml`; regenerate with `uv run python scripts/accuracy_report.py --write`.",
        "",
        f"**{correct} of {total} values correct ({(100 * correct / total) if total else 0:.0f}%)** across "
        f"{len(scored)} documents read. A value is correct when the figure as printed and its page match.",
        "",
        "| Document | Country | Status | Correct | Wrong | Not found | Null items left empty | Time |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for r in results:
        if r.status != "read":
            reason = "skipped (format not read yet)" if r.status == "skipped" else "file not downloaded"
            lines.append(f"| {r.id} | {r.country} | {reason} | – | – | – | – | – |")
            continue
        nulls = r.null_ok + len(r.null_found)
        lines.append(
            f"| {r.id} | {r.country} | read | {r.correct}/{r.scored} | {len(r.wrong)} | {len(r.missed)} | "
            f"{r.null_ok}/{nulls} | {r.seconds:.1f}s |"
        )
    details = [r for r in scored if r.wrong or r.missed or r.null_found]
    if details:
        lines += ["", "## Differences", ""]
        for r in details:
            lines.append(f"**{r.id}**")
            lines.append("")
            lines += [f"- Wrong: {w}" for w in r.wrong]
            lines += [f"- Not found: {m}" for m in r.missed]
            lines += [f"- Returned for an item the manifest leaves empty: {n}" for n in r.null_found]
            lines.append("")
    lines += [
        "",
        "Not found is the expected outcome for items the statements do not show on one line (the AI step searches "
        "the notes for those once a provider is connected). Every value still goes through the review screen.",
        "",
    ]
    return "\n".join(lines)


def run() -> list[DocResult]:
    manifest = yaml.safe_load(MANIFEST.read_text(encoding="utf-8"))
    download_dir = ROOT / manifest["download_dir"]
    return [evaluate(spec, download_dir) for spec in manifest["documents"]]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--write", action="store_true", help="write docs/accuracy.md")
    args = parser.parse_args()
    results = run()
    report = render(results)
    print(report)
    if args.write:
        (ROOT / "docs" / "accuracy.md").write_text(report, encoding="utf-8")
    if all(r.status == "missing" for r in results):
        print("No fixtures downloaded: run `uv run python scripts/fetch_fixtures.py` first.", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
