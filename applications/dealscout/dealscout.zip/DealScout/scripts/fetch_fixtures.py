"""Download the extraction test fixtures listed in tests/fixtures/manifest.yaml and verify their sha256.

Usage::

    uv run python scripts/fetch_fixtures.py            # download missing files, verify all
    uv run python scripts/fetch_fixtures.py --check    # verify only, no network
    uv run python scripts/fetch_fixtures.py --only uk_rightmove_ara_2025 --force

Files go to the manifest's ``download_dir`` (``tests/fixtures/downloaded/``, gitignored). A download is written to
``<name>.part`` and only renamed into place when its size and sha256 match the manifest. A file that is already
present is never replaced unless ``--force`` is given.

SEC EDGAR rejects requests whose User-Agent does not identify the requester. Set ``SEC_USER_AGENT`` to a name and
contact address (for example ``"Jane Doe jane@example.com"``); without it a placeholder is sent. Other hosts get a
generic User-Agent.

Standard library only. The manifest is read with a small parser for the block style the manifest uses: each
document starts with ``"  - "`` and its scalar keys sit at exactly four spaces. Nested keys (``expected``) and
folded text are ignored here.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MANIFEST = ROOT / "tests" / "fixtures" / "manifest.yaml"
DEFAULT_DOWNLOAD_DIR = "tests/fixtures/downloaded"
DEFAULT_SEC_USER_AGENT = "DealScout fixture fetcher admin@example.org"
GENERIC_USER_AGENT = "Mozilla/5.0 (compatible; DealScout fixture fetcher)"
REQUIRED_KEYS = ("id", "url", "filename", "sha256", "size_bytes")
CHUNK_SIZE = 1 << 16
TIMEOUT_SECONDS = 120
RETRIES = 3

_DOC_START = re.compile(r"^  - ([A-Za-z_][\w-]*):(.*)$")
_DOC_KEY = re.compile(r"^    ([A-Za-z_][\w-]*):(.*)$")
_TOP_KEY = re.compile(r"^([A-Za-z_][\w-]*):(.*)$")
_SAFE_FILENAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")


class ManifestError(ValueError):
    pass


@dataclass(frozen=True)
class Fixture:
    id: str
    url: str
    filename: str
    sha256: str
    size_bytes: int


@dataclass(frozen=True)
class Result:
    fixture: Fixture
    status: str
    ok: bool
    detail: str = ""


# --- manifest -------------------------------------------------------------------------------------------------


def _scalar(raw: str, where: str) -> str | None:
    """Parse a YAML scalar on one line: double-quoted, single-quoted or plain (with an optional ``# comment``)."""
    raw = raw.strip()
    if raw.startswith('"'):
        end = 1
        while end < len(raw):
            if raw[end] == "\\":
                end += 2
                continue
            if raw[end] == '"':
                break
            end += 1
        else:
            raise ManifestError(f"{where}: unterminated double-quoted string")
        try:
            value: str = json.loads(raw[: end + 1])
        except json.JSONDecodeError as exc:
            raise ManifestError(f"{where}: unsupported escape in {raw[: end + 1]}") from exc
        return value
    if raw.startswith("'"):
        match = re.match(r"'((?:[^']|'')*)'", raw)
        if not match:
            raise ManifestError(f"{where}: unterminated single-quoted string")
        return match.group(1).replace("''", "'")
    raw = re.split(r"\s#", raw, maxsplit=1)[0].strip()
    if raw in ("", "~", "null", "Null", "NULL"):
        return None
    return raw


def load_manifest(path: Path) -> tuple[Path, list[Fixture]]:
    """Return the download directory and the fixtures listed in the manifest."""
    download_dir = DEFAULT_DOWNLOAD_DIR
    docs: list[dict[str, str | None]] = []
    current: dict[str, str | None] | None = None
    in_documents = False

    for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        where = f"{path.name}:{lineno}"
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        top = _TOP_KEY.match(line)
        if top:
            key = top.group(1)
            in_documents = key == "documents"
            current = None
            if key == "download_dir":
                download_dir = _scalar(top.group(2), where) or DEFAULT_DOWNLOAD_DIR
            continue
        if not in_documents:
            continue
        start = _DOC_START.match(line)
        if start:
            current = {start.group(1): _scalar(start.group(2), where)}
            docs.append(current)
            continue
        field = _DOC_KEY.match(line)
        if field and current is not None:
            current[field.group(1)] = _scalar(field.group(2), where)

    fixtures: list[Fixture] = []
    seen: set[str] = set()
    for doc in docs:
        label = doc.get("id") or "<document without id>"
        missing = [key for key in REQUIRED_KEYS if not doc.get(key)]
        if missing:
            raise ManifestError(f"{label}: missing {', '.join(missing)}")
        fixture = Fixture(
            id=str(doc["id"]),
            url=str(doc["url"]),
            filename=str(doc["filename"]),
            sha256=str(doc["sha256"]).lower(),
            size_bytes=int(str(doc["size_bytes"])),
        )
        if fixture.id in seen:
            raise ManifestError(f"{fixture.id}: duplicate id")
        seen.add(fixture.id)
        if not _SAFE_FILENAME.match(fixture.filename):
            raise ManifestError(f"{fixture.id}: filename must be a plain file name, got {fixture.filename!r}")
        if not re.fullmatch(r"[0-9a-f]{64}", fixture.sha256):
            raise ManifestError(f"{fixture.id}: sha256 must be 64 hex characters")
        if urllib.parse.urlsplit(fixture.url).scheme != "https":
            raise ManifestError(f"{fixture.id}: url must use https")
        fixtures.append(fixture)

    if not fixtures:
        raise ManifestError(f"{path}: no documents found")
    target = Path(download_dir)
    return (target if target.is_absolute() else ROOT / target), fixtures


# --- download -------------------------------------------------------------------------------------------------


def is_sec(url: str) -> bool:
    host = (urllib.parse.urlsplit(url).hostname or "").lower()
    return host == "sec.gov" or host.endswith(".sec.gov")


def user_agent_for(url: str) -> str:
    if is_sec(url):
        return os.environ.get("SEC_USER_AGENT", "").strip() or DEFAULT_SEC_USER_AGENT
    return GENERIC_USER_AGENT


def file_digest(path: Path) -> tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as handle:
        while chunk := handle.read(CHUNK_SIZE):
            digest.update(chunk)
            size += len(chunk)
    return digest.hexdigest(), size


def download(url: str, target: Path) -> tuple[str, int]:
    """Stream ``url`` into ``target`` and return its sha256 and size. Retries transient failures."""
    request = urllib.request.Request(url, headers={"User-Agent": user_agent_for(url), "Accept": "*/*"})
    last_error: Exception | None = None
    for attempt in range(1, RETRIES + 1):
        try:
            digest = hashlib.sha256()
            size = 0
            with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response, target.open("wb") as out:
                while chunk := response.read(CHUNK_SIZE):
                    digest.update(chunk)
                    out.write(chunk)
                    size += len(chunk)
            return digest.hexdigest(), size
        except urllib.error.HTTPError as exc:
            last_error = exc
            if exc.code not in (408, 429) and exc.code < 500:
                break
        except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
            last_error = exc
        if attempt < RETRIES:
            time.sleep(2**attempt)
    target.unlink(missing_ok=True)
    assert last_error is not None
    raise last_error


def describe_error(exc: Exception, url: str) -> str:
    if isinstance(exc, urllib.error.HTTPError):
        text = f"HTTP {exc.code} {exc.reason}"
        if is_sec(url) and exc.code in (403, 429):
            text += " (SEC needs a User-Agent with your contact details: set SEC_USER_AGENT)"
        return text
    if isinstance(exc, urllib.error.URLError):
        return f"network error: {exc.reason}"
    return f"{type(exc).__name__}: {exc}"


def fetch_one(fixture: Fixture, download_dir: Path, *, force: bool, check_only: bool) -> Result:
    dest = download_dir / fixture.filename
    if dest.exists() and not force:
        sha, size = file_digest(dest)
        if sha == fixture.sha256 and size == fixture.size_bytes:
            return Result(fixture, "present", True)
        return Result(fixture, "MISMATCH", False, f"local file sha256 {sha[:12]}..., {size} bytes; rerun with --force")
    if check_only:
        return Result(fixture, "MISSING", False, "not downloaded (--check)")

    partial = dest.with_name(dest.name + ".part")
    try:
        sha, size = download(fixture.url, partial)
    except Exception as exc:  # report every failure in the summary instead of stopping
        return Result(fixture, "FAILED", False, describe_error(exc, fixture.url))
    if sha != fixture.sha256 or size != fixture.size_bytes:
        partial.unlink(missing_ok=True)
        return Result(
            fixture,
            "BAD HASH",
            False,
            f"server sent sha256 {sha}, {size} bytes; the upstream file changed, so re-check the expected values",
        )
    partial.replace(dest)
    return Result(fixture, "downloaded", True)


# --- cli ------------------------------------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=(__doc__ or "").split("\n\n")[0])
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST, help="path to manifest.yaml")
    parser.add_argument("--only", nargs="+", metavar="ID", help="limit to these fixture ids")
    parser.add_argument("--force", action="store_true", help="download again even if the file is present")
    parser.add_argument("--check", action="store_true", help="verify files already present; no network access")
    args = parser.parse_args(argv)

    try:
        download_dir, fixtures = load_manifest(args.manifest)
    except (OSError, ManifestError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if args.only:
        unknown = sorted(set(args.only) - {f.id for f in fixtures})
        if unknown:
            print(f"error: unknown fixture id(s): {', '.join(unknown)}", file=sys.stderr)
            return 2
        fixtures = [f for f in fixtures if f.id in args.only]

    download_dir.mkdir(parents=True, exist_ok=True)
    needs_sec = any(is_sec(f.url) and (args.force or not (download_dir / f.filename).exists()) for f in fixtures)
    if needs_sec and not args.check and not os.environ.get("SEC_USER_AGENT", "").strip():
        print(f"note: SEC_USER_AGENT is not set; sending {DEFAULT_SEC_USER_AGENT!r} to SEC EDGAR", file=sys.stderr)

    results: list[Result] = []
    for fixture in fixtures:
        result = fetch_one(fixture, download_dir, force=args.force, check_only=args.check)
        results.append(result)
        print(f"{result.status:<10} {fixture.id}" + (f"  {result.detail}" if result.detail else ""), flush=True)

    width = max(len(r.fixture.id) for r in results)
    print()
    print(f"{'id':<{width}}  {'status':<10}  {'size':>12}  file")
    for r in results:
        print(f"{r.fixture.id:<{width}}  {r.status:<10}  {r.fixture.size_bytes:>12,}  {r.fixture.filename}")
    failed = [r for r in results if not r.ok]
    try:
        shown_dir = download_dir.relative_to(ROOT)
    except ValueError:
        shown_dir = download_dir
    print(f"\n{len(results) - len(failed)}/{len(results)} fixtures verified in {shown_dir}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
