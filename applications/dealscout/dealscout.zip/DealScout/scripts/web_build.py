"""Build the static web export only when its sources changed (used by start.sh / start.ps1).

Hashes the web sources plus the shared palette, compares with ``web/out/.build-hash`` and runs
``npm ci`` (first run) and ``npm run build`` when they differ. ``--force`` always rebuilds.
"""

from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"
OUT = WEB / "out"
HASH_FILE = OUT / ".build-hash"
SOURCE_GLOBS = [
    "app/**/*",
    "components/**/*",
    "lib/**/*",
    "hooks/**/*",
    "scripts/**/*",
    "public/**/*",
    "*.json",
    "*.mjs",
    "*.ts",
]
EXTRA_FILES = [ROOT / "data" / "design" / "palette.json", ROOT / "data" / "legal" / "disclaimers.json"]
SKIP_DIRS = {"node_modules", ".next", "out"}


def source_hash() -> str:
    digest = hashlib.sha256()
    files: set[Path] = set()
    for pattern in SOURCE_GLOBS:
        for path in WEB.glob(pattern):
            if path.is_file() and not SKIP_DIRS.intersection(path.relative_to(WEB).parts):
                files.add(path)
    files.update(p for p in EXTRA_FILES if p.exists())
    for path in sorted(files):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def run(cmd: list[str]) -> None:
    exe = shutil.which(cmd[0])
    if exe is None:
        sys.exit(f"✗ '{cmd[0]}' not found on PATH — install Node.js 20+ (see README).")
    env = {**os.environ, "NEXT_TELEMETRY_DISABLED": "1"}
    subprocess.run([exe, *cmd[1:]], cwd=WEB, check=True, env=env)


def main() -> None:
    force = "--force" in sys.argv
    current = source_hash()
    if not force and HASH_FILE.exists() and HASH_FILE.read_text().strip() == current:
        print("  web interface is up to date")
        return
    if not (WEB / "node_modules").exists():
        print("  installing web dependencies (first run, takes a minute)…")
        run(["npm", "ci", "--no-audit", "--no-fund"])
    print("  building web interface…")
    run(["npm", "run", "build"])
    HASH_FILE.write_text(current)


if __name__ == "__main__":
    main()
