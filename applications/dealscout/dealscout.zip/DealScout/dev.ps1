# DealScout — development mode (Windows PowerShell).
# FastAPI with auto-reload on :8000 and the Next.js dev server with hot reload on :3000.
# Open http://127.0.0.1:3000 — the dev server proxies /api/* to FastAPI. Ctrl+C stops both.
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

uv sync --all-packages --quiet
if (-not (Test-Path "web/node_modules")) { Push-Location web; npm install; Pop-Location }

$port = if ($env:DEALSCOUT_PORT) { $env:DEALSCOUT_PORT } else { "8000" }
$env:DEALSCOUT_DEV = "1"
$env:NEXT_TELEMETRY_DISABLED = "1"
$api = Start-Process -PassThru -NoNewWindow uv -ArgumentList @(
    "run", "uvicorn", "dealscout_api.app:create_app", "--factory", "--reload",
    "--host", "127.0.0.1", "--port", $port,
    "--reload-dir", "api/src", "--reload-dir", "engine/src", "--reload-dir", "ai/src", "--reload-dir", "extraction/src")
$web = Start-Process -PassThru -NoNewWindow -WorkingDirectory web npm.cmd -ArgumentList @("run", "dev", "--", "--hostname", "127.0.0.1", "--port", "3000")
Write-Host "-> Dev servers starting: open http://127.0.0.1:3000  (Ctrl+C to stop)"
try { Wait-Process -Id $api.Id, $web.Id }
finally {
    foreach ($p in @($api, $web)) { if ($p -and -not $p.HasExited) { taskkill /PID $p.Id /T /F | Out-Null } }
}
