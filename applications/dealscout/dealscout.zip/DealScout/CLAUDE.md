# DealScout — notes for Claude Code sessions

DealScout is a local, single-user web app (FastAPI + static Next.js export at http://127.0.0.1:8000) that gives
investment professionals a first-pass analysis and indicative acquisition price range for a company.

- Full brief: `docs/BRIEF.md` (read it before starting a milestone). Build plan and assumptions: `docs/PLAN.md`.
- UI system (tokens, density, measurements): `DESIGN.md`. Palette source of truth: `data/design/palette.json`.
- Financial conventions and toggles: `docs/methodology.md`.

## Hard rules

- `engine/` (`dealscout_engine`) is pure: no web, AI, DB or file-format imports. All arithmetic lives there and is unit-tested.
- The AI finds and explains; code calculates. AI output never becomes a final number without passing through the engine.
- All AI calls go through the provider-neutral interface in `ai/` (`dealscout_ai`); never import a vendor SDK outside `ai/src/dealscout_ai/providers/`.
- No API keys, deal data or non-redistributable documents in the repo, logs, exports or JSON deal files. Keys live in the OS keychain.
- Server binds to 127.0.0.1 only; keep the Host/Origin guard middleware.
- Every default market assumption carries a source and as-of date; unverifiable values are `null` placeholders listed in `DEFAULTS_TO_VERIFY.md`.

## Commands

- `make test` · `make lint` · `make seed` · `./dev.sh` (hot reload) · `./start.sh` (production-style local run)
- Python: `uv run pytest`, `uv run ruff check .`, `uv run mypy engine/src ai/src extraction/src api/src`
- Extraction accuracy: `uv run python scripts/fetch_fixtures.py` (downloads public filings, git-ignored), then `uv run python scripts/accuracy_report.py --write`; per-provider (live keys, billed): `uv run python scripts/provider_accuracy.py`
- Web: `cd web && npm run lint && npm run build`
- End-to-end (Playwright): `cd web && npm run e2e`; `SCREENSHOTS=1 npm run e2e` refreshes `docs/screenshots`
- Sample exports and Excel layout snapshots: `uv run python scripts/export_examples.py --snapshots` (needs LibreOffice)

## 0. Skills to use

Claude Code skills are installed for this build. Use the ones below at the points named, and copy this section into the repo's `CLAUDE.md` during Milestone 1 so every later session follows it too. Many other design skills are installed; ignore the ones listed under "Do not use".

| Skill | Use it for | When |
|---|---|---|
| `claude-api` | The Anthropic (Claude) adapter of the AI layer: current model strings, native PDF/document input, structured outputs / tool use with JSON schemas, prompt caching, token and cost accounting. For the other providers, read their official API docs instead | Before writing the Anthropic adapter (Milestone 3) and whenever it changes |
| `xlsx` | The "Create Excel" workbook (§14A) and the blank manual-entry template (§12): live formulas only, colour conventions, zero formula errors, LibreOffice recalculation check | Milestone 7, and Milestone 2 for the entry template |
| `dataviz` | Every chart in §11, in the web UI and in the Excel/PDF/PPTX exports: chart form, one shared palette, light/dark, semantic red/amber/green that never relies on colour alone | Milestone 2 onwards, whenever a chart is built |
| `app-design` | All web UI work: the deal flow, extraction review screen, grids, dashboards, assumptions and valuation tabs, states, keyboard, browser verification, accessibility audit | Every milestone that touches `web/` |
| `shadcn` | Adding, composing, theming and debugging shadcn/ui components through the shadcn CLI, reading `components.json` | Every milestone that touches `web/` |
| `break-ui` | Stress-testing statement grids, financial tables and the review screen with worst-case data (huge and negative numbers, long labels, missing periods, 0 and 300+ rows, non-Latin labels) | End of each UI milestone |
| `web-design-guidelines` | Pre-ship rules audit of the UI code | End of each UI milestone |
| `playwright-cli` | Looking at screens while building, and alongside the Playwright end-to-end tests in §16 | Every UI milestone |
| `pdf` | The PDF tear sheet (§14) and handling PDF inputs in tests | Milestones 3 and 7 |
| `pptx` | The python-pptx one-page slide summary (§14) | Milestone 7 |
| `ui-ux-pro-max` | Lookups and checklists only: stack guidelines (`--stack nextjs`, `--stack shadcn`), UX guidelines (`--domain ux`, e.g. "data table", "form validation", "loading states", "keyboard navigation"), and its "Before Delivering App UI" checklist | Start of each UI milestone (look up the screens you're about to build) and end of each UI milestone (run the checklist next to web-design-guidelines) |

Rules for applying them:

- **The brief is the brand override for `app-design`.** The visual specs in §14A and §17 win. Skip `app-design`'s direction-setting step and do not generate a new palette or "signature" style; use its build, states, verification and audit phases. Record the UI system once in `DESIGN.md` (tokens, density, component measurements) and reuse it.
- **One palette everywhere.** Define the palette once (navy primary, one accent, soft greys, semantic red/amber/green) and share it between the web UI, charts, Excel, PDF and PPTX.
- **Excel formulas must recalculate in LibreOffice**, because §14A's CI check recalculates with it. Use `INDEX`/`MATCH`; never `XLOOKUP`, `XMATCH`, `FILTER`, `SORT`, `UNIQUE` or `SEQUENCE`. Do sorting, filtering and de-duplication in Python before writing cells.
- **Check current model names and capabilities before hard-coding any.** For Claude, use the `claude-api` skill. For OpenAI, Azure OpenAI, Google Gemini, xAI and Perplexity, check each provider's official API documentation at build time (model names, structured-output support, PDF/file input, pricing). Never rely on remembered model names.
- **`ui-ux-pro-max` is for lookups and checklists only.** Never run its `--design-system` generator or adopt any palette, font or style it suggests; the visual specs in §14A and §17 are fixed. `dataviz` stays the main chart skill; `--domain chart` is a second opinion only. Run searches with: `python3 "$HOME/.claude/skills/ui-ux-pro-max/scripts/search.py" "<query>" --domain <domain>` (or `--stack <stack>`).
- **`design-taste-frontend` is allowed (owner's decision, after Milestone 8)** for polishing hierarchy, spacing, type rhythm and empty states only. The palette and Inter font stay fixed; audit its changes with the ui-ux-pro-max checklist.
- **Do not use** `website-design`, `website-presentation-hero`, `frontend-design`, `image-to-code`, `design-md-library`, `frontend-slides`, `mckinsey` or `mckinsey-plus` on this project. They target marketing sites, bold visual styles or hand-made decks, and conflict with the restrained, dense UI this brief asks for. The ui-ux-pro-max design-system generator is also out (the palette is fixed); see the `ui-ux-pro-max` rule above for its permitted lookups. Keep motion minimal; Emil Kowalski's animation skills are not needed beyond the basic rules inside `app-design`.
