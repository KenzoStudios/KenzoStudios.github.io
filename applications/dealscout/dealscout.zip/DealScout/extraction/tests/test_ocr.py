"""Scanned documents: OCR through Tesseract when installed (faked here), a clear message when not, and the AI
reading page images as a flagged, low-confidence fallback."""

from __future__ import annotations

import json

import pymupdf
import pytest

from dealscout_ai.testing import ScriptedProvider
from dealscout_engine.taxonomy import load_taxonomy
from dealscout_extraction import ocr, synthetic
from dealscout_extraction.ingest import read_document
from dealscout_extraction.pipeline import extract, extract_rules

TAX = load_taxonomy()
TEXT_PAGES = pymupdf.open(stream=synthetic.english_annual_report(), filetype="pdf")


@pytest.fixture
def fake_tesseract(monkeypatch):
    """A perfect OCR engine: the words of the original text page at the same positions."""

    def words(page, languages):
        source = TEXT_PAGES[page.number] if page.parent.page_count == TEXT_PAGES.page_count else TEXT_PAGES[1]
        return [(w[0], w[1], w[2], w[3], w[4]) for w in source.get_text("words")]

    monkeypatch.setattr(ocr, "ocr_available", lambda: True)
    monkeypatch.setattr(ocr, "_engine_words", words)


@pytest.fixture
def no_tesseract(monkeypatch):
    monkeypatch.setattr(ocr, "ocr_available", lambda: False)


def test_scanned_report_is_read_with_ocr(fake_tesseract):
    out = extract_rules(synthetic.scanned_annual_report(), "scan.pdf", TAX)
    v = {(c.concept_id, c.period_key): c for c in out.candidates}
    assert out.doc.scanned_pages == 5 and all(p.ocr for p in out.doc.pages)
    assert v[("revenue", "FY2025")].value == pytest.approx(1_250.4e6)
    assert v[("revenue", "FY2025")].confidence < 0.75  # OCR tables rank below clean tables (brief §5.2 step 10)
    assert v[("revenue", "FY2025")].bbox is not None  # highlightable on the page image
    assert any("read with OCR" in w for w in out.warnings)


def test_scanned_report_without_tesseract_says_what_to_install(no_tesseract):
    out = extract_rules(synthetic.scanned_annual_report(), "scan.pdf", TAX)
    assert out.candidates == []
    assert any("Install Tesseract" in w and "brew install tesseract" in w for w in out.warnings)


def test_image_of_a_statement(fake_tesseract):
    page = TEXT_PAGES[1]
    png = page.get_pixmap(dpi=100).tobytes("png")
    doc = read_document(png, "income-statement.png")
    assert doc.kind == "image" and doc.pages[0].ocr
    assert doc.tables and doc.tables[0].source == "ocr"


def test_ai_reads_scanned_pages_only_as_flagged_low_confidence_values(no_tesseract):
    answer = {
        "values": [
            {
                "concept_id": "total_assets",
                "period": "2025",
                "value_as_written": "1,376.0",
                "page": 3,
                "label": "Total assets",
                "unit_scale": "€ million",
                "confidence": 0.95,
                "reason_if_null": None,
            },
            {
                "concept_id": "cash",
                "period": "2025",
                "value_as_written": "145.5",
                "page": 99,
                "label": "Cash",
                "unit_scale": "€ million",
                "confidence": 0.9,
                "reason_if_null": None,
            },
        ]
    }
    fake = ScriptedProvider(
        {"AIMappingResult": [json.dumps({"items": []})], "AIExtractionResult": [json.dumps(answer)]},
        image_input=True,
    )
    out = extract(synthetic.scanned_annual_report(), "scan.pdf", TAX, provider=fake.provider)
    v = {(c.concept_id, c.period_key): c for c in out.candidates}
    assets = v[("total_assets", "FY2025")]
    assert assets.value == pytest.approx(1_376.0e6) and assets.page == 3
    assert assets.confidence <= 0.5 and any("scanned page image" in n for n in assets.notes)
    assert ("cash", "FY2025") not in v  # cited a page it was never shown
    sent = next(r for r in fake.requests if r["schema"] == "AIExtractionResult")
    assert any(getattr(part, "kind", "") == "page_image" for part in sent["content"])
