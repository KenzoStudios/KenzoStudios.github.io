"""Tagged filings (SEC iXBRL, ESEF packages, XBRL instances), HTML and Word tables."""

from __future__ import annotations

import pytest

from dealscout_engine.taxonomy import load_taxonomy
from dealscout_extraction import synthetic
from dealscout_extraction.ingest import read_document, sniff_kind
from dealscout_extraction.ixbrl import Context, InlineReport, _transform, period_key, read_inline_xbrl
from dealscout_extraction.numbers import parse_period_header
from dealscout_extraction.pipeline import extract_rules

TAX = load_taxonomy()


def by_key(out):
    return {(c.concept_id, c.period_key): c for c in out.candidates}


def test_sec_10k_tagged_facts_first():
    out = extract_rules(synthetic.sec_retailer_10k(), "brightmart-10k.htm", TAX)
    v = by_key(out)
    assert out.doc.kind == "xbrl" and out.doc_type == "annual_report"
    assert out.doc.entity_name == "Brightmart Stores, Inc." and out.doc.currency == "USD"
    # fiscal 2025 ends on 31 January 2026: named as the filing names it
    assert v[("revenue", "FY2025")].value == pytest.approx(12_480.5e6)
    assert v[("revenue", "FY2024")].value == pytest.approx(11_902.0e6)
    assert v[("revenue", "FY2025")].method == "xbrl" and v[("revenue", "FY2025")].cell_ref == "f1"
    assert v[("revenue", "FY2025")].confidence >= 0.97
    # the dimensional (segment) fact is not the consolidated total
    assert all(c.cell_ref != "f9" for c in out.candidates)
    # sign="-" is a loss; costs and outflows follow the taxonomy sign
    assert v[("net_income", "FY2025")].value == pytest.approx(-35.0e6)
    assert v[("cf_net_income", "FY2025")].value == pytest.approx(-35.0e6)
    assert v[("cogs", "FY2025")].value == pytest.approx(-8_105.2e6)
    assert v[("capex_ppe", "FY2025")].value == pytest.approx(-455.0e6)
    # an increase in receivables is a cash outflow; a decrease an inflow
    assert v[("change_receivables", "FY2025")].value == pytest.approx(-42.0e6)
    assert v[("change_receivables", "FY2024")].value == pytest.approx(12.5e6)
    # ixt:fixed-zero, balance-sheet instants, cover-page shares
    assert v[("lt_debt", "FY2024")].value == 0.0
    assert v[("total_assets", "FY2025")].value == pytest.approx(9_210.0e6)
    assert v[("shares_outstanding", "FY2025")].value == 412_005_331
    assert any("2026-03-10" in n for n in v[("shares_outstanding", "FY2025")].notes)
    # company-specific element offered for mapping, never dropped
    assert [u.label for u in out.unmapped] == ["Store preopening costs (acme:StorePreopeningCosts)"]
    assert sorted({c.period_key for c in out.candidates}) == ["FY2024", "FY2025"]


def test_esef_package_with_labels_and_comma_decimals():
    content = synthetic.esef_package()
    assert sniff_kind(content, "ortel.zip") == "zip"
    out = extract_rules(content, "ortel-2025.zip", TAX)
    v = by_key(out)
    assert out.doc.report_member == "ortel-2025-12-31/reports/ortel-2025-12-31-fr.xhtml"
    assert out.doc.currency == "EUR" and out.doc_type == "annual_report"
    assert v[("revenue", "FY2025")].value == pytest.approx(1_204_310_000)
    assert v[("net_income", "FY2025")].value == pytest.approx(88_412_500)  # "88 412,5" in thousands
    # a company element whose own label is a dictionary label is mapped, with a lower confidence and a note
    assert v[("ebitda", "FY2025")].value == pytest.approx(212_050_000) and v[("ebitda", "FY2025")].cell_ref == "x25"
    assert v[("ebitda", "FY2025")].confidence < v[("revenue", "FY2025")].confidence
    assert out.unmapped[0].label.startswith("Charges de restructuration non récurrentes")


def test_classic_xbrl_instance():
    out = extract_rules(synthetic.xbrl_instance(), "report.xbrl", TAX)
    v = by_key(out)
    assert v[("revenue", "FY2025")].value == 5_400_000 and v[("net_income", "FY2025")].value == -120_000


def test_word_tables():
    out = extract_rules(synthetic.word_statements_docx(), "mgmt.docx", TAX)
    v = by_key(out)
    assert out.doc.kind == "docx"
    # "(£000)" in the heading above the table sets the scale
    assert v[("revenue", "FY2025")].value == 4_210e3 and v[("cogs", "FY2024")].value == -1_990e3
    assert v[("revenue", "FY2025")].cell_ref.startswith("t1r")


def test_html_tables_join_split_figures():
    html = b"""<html><body><p>Consolidated Statements of Income (in millions)</p><table>
<tr><td></td><td colspan="2">2025</td><td colspan="2">2024</td></tr>
<tr><td>Net sales</td><td>$</td><td>1,234</td><td>$</td><td>1,100</td></tr>
<tr><td>Cost of sales</td><td></td><td>(800</td><td>)</td><td>(700)</td></tr>
<tr><td>Operating income</td><td></td><td>434</td><td></td><td>400</td></tr>
<tr><td>Net income</td><td></td><td>300</td><td></td><td>280</td></tr>
</table><script>document.write('x')</script></body></html>"""
    out = extract_rules(html, "statement.html", TAX)
    v = by_key(out)
    assert out.doc.kind == "html"
    assert v[("revenue", "FY2025")].value == pytest.approx(1_234e6)
    assert v[("cogs", "FY2025")].value == pytest.approx(-800e6)
    assert v[("revenue", "FY2024")].value == pytest.approx(1_100e6)


@pytest.mark.parametrize(
    ("text", "fmt", "expected"),
    [
        ("1,234.5", "ixt:num-dot-decimal", 1234.5),
        ("1 234,5", "ixt:num-comma-decimal", 1234.5),
        ("1.234,5", "ixt:num-comma-decimal", 1234.5),
        ("—", "ixt:fixed-zero", 0.0),
        ("-", "ixt:zerodash", 0.0),
        ("none", "ixt-sec:numwordsen", 0.0),
        ("12", None, 12.0),
    ],
)
def test_ixbrl_number_formats(text, fmt, expected):
    assert _transform(text, fmt) == expected


def test_period_keys_follow_the_filing():
    from datetime import date

    report = InlineReport(fiscal_year_focus=2025, period_end=date(2026, 1, 31), fiscal_year_end=(1, 31))
    assert period_key(report, Context("a", date(2025, 2, 2), date(2026, 1, 31), False, False)) == "FY2025"
    assert period_key(report, Context("b", None, date(2026, 1, 31), True, False)) == "FY2025"
    calendar = InlineReport(fiscal_year_end=(12, 31))
    assert period_key(calendar, Context("c", date(2026, 1, 1), date(2026, 6, 30), False, False)) == "H1-2026"
    assert period_key(calendar, Context("d", date(2026, 4, 1), date(2026, 6, 30), False, False)) == "Q2-2026"
    assert period_key(calendar, Context("e", date(2026, 1, 1), date(2026, 9, 30), False, False)) == "9M-2026"
    assert period_key(calendar, Context("f", None, date(2026, 6, 30), True, False)) == "H1-2026"


def test_us_date_headers():
    assert parse_period_header("January 31, 2026").key == "FY2026"
    assert parse_period_header("Dec. 31, 2025").end.isoformat() == "2025-12-31"
    assert parse_period_header("Fiscal 2025").key == "FY2025"


def test_hostile_xml_is_not_expanded():
    bomb = b"""<?xml version="1.0"?><!DOCTYPE lolz [<!ENTITY lol "lol"><!ENTITY lol2 "&lol;&lol;&lol;&lol;">]>
<html xmlns:ix="http://www.xbrl.org/2013/inlineXBRL"><body>&lol2;</body></html>"""
    report = read_inline_xbrl(bomb)
    assert report.facts == []
    doc = read_document(bomb, "bomb.xhtml")
    assert doc.kind == "xbrl"
