"""Large documents (brief §16, Milestone 8): a 345-page report is read and mapped well within a minute."""

from __future__ import annotations

import time

import pymupdf

from dealscout_engine.taxonomy import load_taxonomy
from dealscout_extraction.pipeline import extract_rules
from dealscout_extraction.synthetic import english_annual_report


def big_report(narrative: int = 170, notes: int = 170) -> bytes:
    base = pymupdf.open(stream=english_annual_report(), filetype="pdf")
    doc = pymupdf.open()
    filler = "The Group continued to invest in its operations across all regions. " * 40
    for i in range(narrative):
        doc.new_page().insert_textbox(pymupdf.Rect(50, 50, 545, 800), f"Section {i}\n{filler}", fontsize=9)
    doc.insert_pdf(base)
    for i in range(notes):
        page = doc.new_page()
        for r in range(40):
            y = 60 + r * 18
            page.insert_text((50, y), f"Line item {r} of note {i}", fontsize=8)
            page.insert_text((400, y), f"{(r + 1) * 1234:,}", fontsize=8)
            page.insert_text((480, y), f"{(r + 1) * 1111:,}", fontsize=8)
    return doc.tobytes()


def test_345_page_report_is_fast_and_still_finds_the_statements():
    content = big_report()
    start = time.perf_counter()
    out = extract_rules(content, "annual-report.pdf", load_taxonomy())
    elapsed = time.perf_counter() - start
    assert out.doc.page_count == 345
    assert elapsed < 30, f"took {elapsed:.1f}s"  # about 3s on a 2024 laptop; generous for CI runners
    found = {(c.concept_id, c.period_key) for c in out.candidates}
    assert ("revenue", "FY2025") in found and ("total_assets", "FY2025") in found


def test_rotated_pages_read_the_same_values_and_positions():
    """Pages stored with /Rotate: values and their boxes stay in unrotated page space, which the viewer expects
    (it converts through the page's unrotated view box and pdf.js applies the rotation)."""
    tax = load_taxonomy()
    plain = english_annual_report()
    doc = pymupdf.open(stream=plain, filetype="pdf")
    for page in doc:
        page.set_rotation(90)
    rotated = doc.tobytes()
    a = {(c.concept_id, c.period_key): (c.value, c.page, c.bbox) for c in extract_rules(plain, "a.pdf", tax).candidates}
    b = {
        (c.concept_id, c.period_key): (c.value, c.page, c.bbox) for c in extract_rules(rotated, "b.pdf", tax).candidates
    }
    assert a and a == b
