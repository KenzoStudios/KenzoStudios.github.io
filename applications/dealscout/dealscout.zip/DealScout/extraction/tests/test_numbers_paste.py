from datetime import date

import pytest

from dealscout_engine.taxonomy import load_taxonomy
from dealscout_extraction.numbers import detect_scale, parse_number, parse_period_header
from dealscout_extraction.paste import parse_pasted_table


@pytest.mark.parametrize(
    ("text", "expected", "hint"),
    [
        ("1,234.56", 1234.56, None),
        ("1.234,56", 1234.56, None),
        ("1 234,56", 1234.56, None),
        ("(1,234)", -1234, None),
        ("1,234-", -1234, None),
        ("−1,234", -1234, None),
        ("▲1,234", -1234, None),
        ("△ 500", -500, None),
        ("–", 0.0, None),
        ("-", 0.0, None),
        ("nil", 0.0, None),
        ("n/a", None, None),
        ("1,234(a)", 1234, None),
        ("1,234*", 1234, None),
        ("€1,234m", 1234, None),
        ("12.5%", 0.125, None),
        ("1.234", 1234, ","),
        ("1,5", 1.5, None),
        ("1'234'567", 1234567, None),
        ("１，２３４", 1234, None),
        ("1.234.567", 1234567, None),
        ("text", None, None),
    ],
)
def test_parse_number(text, expected, hint):
    parsed = parse_number(text, decimal_hint=hint)
    assert parsed.value == (pytest.approx(expected) if expected is not None else None)


def test_ambiguous_thousands_is_flagged():
    assert parse_number("1.234").ambiguous


@pytest.mark.parametrize(
    ("text", "factor"),
    [
        ("in thousands", 1e3),
        ("EUR m", 1e6),
        ("€m", 1e6),
        ("in Mio. EUR", 1e6),
        ("en miles de euros", 1e3),
        ("(単位：百万円)", 1e6),
        ("₹ crore", 1e7),
        ("Rs. in lakhs", 1e5),
        ("in Tsd. €", 1e3),
        ("USD bn", 1e9),
        ("in millions of U.S. dollars", 1e6),
        ("Revenue", None),
    ],
)
def test_detect_scale(text, factor):
    scale = detect_scale(text)
    assert (scale.factor if scale else None) == factor


@pytest.mark.parametrize(
    ("text", "key", "kind"),
    [
        ("2025", "FY2025", "annual"),
        ("FY24", "FY2024", "annual"),
        ("FY 2023/24", "FY2024", "annual"),
        ("H1 2026", "H1-2026", "half_year"),
        ("Q3 2025", "Q3-2025", "quarter"),
        ("9M 2026", "9M-2026", "ytd"),
        ("31.12.2025", "FY2025", "annual"),
        ("令和6年度", "FY2024", "annual"),
        ("Dec-25", "FY2025", "annual"),
        ("2027E", "FY2027", "projection"),
        ("Notes", None, None),
    ],
)
def test_period_headers(text, key, kind):
    guess = parse_period_header(text)
    if key is None:
        assert guess is None
    else:
        assert (guess.key, guess.kind) == (key, kind)


def test_period_end_dates():
    assert parse_period_header("31.03.2025").end == date(2025, 3, 31)
    assert parse_period_header("12/31/2024").end == date(2024, 12, 31)
    assert parse_period_header("Mar-25").end == date(2025, 3, 31)


def test_paste_german_statement():
    text = (
        "Gewinn- und Verlustrechnung\tin Mio. EUR\t\nPosition\t2025\t2024\nUmsatzerlöse\t1.234,5\t1.100,0\n"
        "Umsatzkosten\t(800,1)\t(700,0)\nSonstiges\t12\t10\n"
    )
    preview = parse_pasted_table(text, load_taxonomy())
    assert [p.key for p in preview.periods] == ["FY2025", "FY2024"]
    assert preview.scale.factor == 1e6
    revenue = next(r for r in preview.rows if r.label == "Umsatzerlöse")
    assert revenue.concept_id == "revenue" and revenue.values == {"FY2025": 1234.5, "FY2024": 1100.0}
    cogs = next(r for r in preview.rows if r.label == "Umsatzkosten")
    assert cogs.values["FY2025"] == pytest.approx(-800.1)
    assert preview.unmatched == 1


def test_paste_without_headers_warns():
    preview = parse_pasted_table("Revenue\t100\nCosts\t50", load_taxonomy())
    assert preview.rows == [] and preview.warnings
