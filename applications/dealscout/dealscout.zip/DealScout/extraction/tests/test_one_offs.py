"""AI-suggested one-offs: amounts must be printed on the cited page; nothing invented is kept."""

from __future__ import annotations

import json

from dealscout_ai.testing import AnthropicHarness, Scenario
from dealscout_extraction.model import DocumentContent, PageContent
from dealscout_extraction.one_offs import select_one_off_pages, suggest_one_offs

DOC = DocumentContent(
    kind="html",
    language="en",
    pages=[
        PageContent(page=1, text="Chair's letter. A good year for the group."),
        PageContent(
            page=2,
            text=(
                "Note 7 Exceptional items (EUR million)\n"
                "Restructuring costs of the plant closure 2025 (12.5) 2024 —\n"
                "Gain on disposal of the logistics business 2025 4.0\n"
                "Impairment of goodwill 2025 (30.0)"
            ),
        ),
    ],
)


def item(label, category, effect, value, page=2, below=False, period="2025"):
    return {
        "label": label,
        "category": category,
        "effect": effect,
        "period": period,
        "value_as_written": value,
        "page": page,
        "unit_scale": "EUR million",
        "below_ebitda": below,
        "rationale": "Presented by the company as an exceptional item.",
        "confidence": 0.95,
    }


def test_select_pages_finds_one_off_terms():
    assert select_one_off_pages(DOC) == [2]


def test_suggestions_are_verified_scaled_and_signed():
    answer = {
        "items": [
            item("Restructuring costs", "restructuring", "cost", "(12.5)"),
            item("Gain on disposal", "disposal_gain", "gain", "4.0", page=1),  # wrong page: found on page 2
            item("Goodwill impairment", "impairment", "cost", "(30.0)", below=True),
            item("Litigation settlement", "litigation", "cost", "(7.7)"),  # not printed anywhere: rejected
            item("Restructuring costs", "restructuring", "cost", "(12.5)"),  # duplicate
        ]
    }
    provider, rec = AnthropicHarness().build([Scenario(text=json.dumps(answer))])
    out = suggest_one_offs(provider, None, DOC)
    assert len(rec.requests) == 1 and out.pages == [2]
    got = {s.label: s for s in out.suggestions}
    assert set(got) == {"Restructuring costs", "Gain on disposal", "Goodwill impairment"}
    assert got["Restructuring costs"].amount == -12.5e6 and got["Restructuring costs"].affects_ebitda
    assert got["Gain on disposal"].amount == 4.0e6 and got["Gain on disposal"].page == 2
    assert got["Goodwill impairment"].affects_ebitda is False
    assert got["Restructuring costs"].period_key == "FY2025"
    assert [r["label"] for r in out.rejected] == ["Litigation settlement"]
    assert out.usage and out.usage[0].input_tokens == 1000


def test_no_pages_means_no_call():
    provider, rec = AnthropicHarness().build([])
    out = suggest_one_offs(provider, None, DocumentContent(kind="html", pages=[PageContent(page=1, text="Nothing")]))
    assert out.suggestions == [] and rec.requests == []
