"""Layouts found in real filings: spreads, two-column statements, HGB two-level items, Japanese 有価証券報告書."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from dealscout_engine.taxonomy import load_taxonomy, normalise_label
from dealscout_extraction import synthetic
from dealscout_extraction.ingest import read_document
from dealscout_extraction.mapping import _cash_balance, _fuzzy, _tokens_correspond
from dealscout_extraction.numbers import detect_scale, parse_number, parse_period_header
from dealscout_extraction.pipeline import classify, extract

TAX = load_taxonomy()


def values(out):
    return {(c.concept_id, c.period_key): c for c in out.candidates}


def test_hgb_spread_reads_both_printed_pages_and_two_level_items():
    out = extract(synthetic.hgb_spread_report(), "gb.pdf", TAX)
    v = values(out)
    # the spread is split: income statement on the left half, cash flow on the right, same physical page
    assert {t.page for t in out.located["income_statement"]} == {2} and {t.page for t in out.located["cash_flow"]} == {
        2
    }
    assert v[("revenue", "FY2025")].value == pytest.approx(512_300e3)  # "(in TEUR)" → thousands
    assert v[("revenue", "FY2024")].value == pytest.approx(488_120e3)
    # "3. Materialaufwand" total sits on the line of its last sub-item, in the main column
    assert v[("materials_expense", "FY2025")].value == pytest.approx(-265_600e3)
    assert v[("personnel_expense", "FY2024")].value == pytest.approx(-152_500e3)
    # sub-items keep their own amounts (from the detail column) and are offered for mapping
    sub = next(u for u in out.unmapped if u.label.startswith("a) Löhne"))
    assert sub.values == {"FY2025": "130.150", "FY2024": "126.400"}
    # cash flow lines keep their sign markers in the label, not as a figure
    assert v[("capex_ppe", "FY2025")].value == pytest.approx(-11_870e3)
    assert v[("cfo", "FY2024")].value == pytest.approx(25_835e3)
    # the running header "Geschäftsbericht 2025" is not mistaken for a column header
    assert ("revenue", "FY2024") in v and not out.warnings


def test_japanese_securities_report():
    out = extract(synthetic.japanese_securities_report(), "yuho.pdf", TAX)
    v = values(out)
    assert v[("revenue", "FY2025")].value == pytest.approx(91_605e6)  # ※１ marker stripped, 百万円 scale
    assert v[("revenue", "FY2024")].value == pytest.approx(84_210e6)  # prior year printed first
    assert v[("revenue", "FY2025")].value_as_written == "※１91,605"
    assert v[("net_income", "FY2024")].value == pytest.approx(2_620e6)
    assert v[("cogs", "FY2025")].value == pytest.approx(-55_870e6)
    assert out.doc.language == "ja"


def test_landscape_pages_split_only_when_both_sides_are_tables():
    out = extract(synthetic.landscape_report(), "ara.pdf", TAX)
    v = values(out)
    # income statement: labels far from the figures on a landscape page; must not be split apart
    assert v[("revenue", "FY2025")].value == pytest.approx(88_412e3)
    assert v[("net_income", "FY2024")].mapping == "prefix"  # "… being total comprehensive income"
    # cash flow in two columns with a repeated 2025/2024 header: both halves, both years
    assert v[("cfo", "FY2024")].value == pytest.approx(47_330e3)
    assert v[("cff", "FY2025")].value == pytest.approx(-43_410e3)
    assert v[("cash_ending", "FY2025")].value == pytest.approx(9_214e3)
    # intangible capex is never taken for PP&E capex
    assert v[("capex_ppe", "FY2025")].value == pytest.approx(-612e3)
    assert v[("capex_intangibles", "FY2025")].value == pytest.approx(-2_105e3)
    assert out.doc_type == "annual_report"


@pytest.mark.parametrize(
    ("label", "expected"),
    [
        ("Dotaciones para amortizaciones 8, 9, 10 y 11", "dotaciones para amortizaciones"),
        ("Adquisiciones de activos fijos b)", "adquisiciones de activos fijos"),
        ("1. Umsatzerlöse", "umsatzerlöse"),
        ("III. Kassenbestand, Guthaben bei Kreditinstituten", "kassenbestand guthaben bei kreditinstituten"),
        (
            "− Auszahlungen für Investitionen in das Sachanlagevermögen",
            "auszahlungen für investitionen in das sachanlagevermögen",
        ),
        ("+/−Zinsaufwendungen/Zinserträge", "zinsaufwendungen/zinserträge"),
        ("Cash and cash equivalents (note 12)", "cash & cash equivalents"),
        ("現金及び現金同等物の増減額（△は減少）", "現金及び現金同等物の増減額"),
        ("Property, plant and equipment", "property plant & equipment"),
        ("IFRS 16 lease liabilities", "ifrs 16 lease liabilities"),
    ],
)
def test_label_normalisation(label, expected):
    assert normalise_label(label) == expected


def test_fuzzy_matching_never_changes_a_word():
    assert not _tokens_correspond("acquisition of intangible assets", "acquisition of tangible fixed assets")
    assert _tokens_correspond("depreciation & amortization", "depreciation & amortisation")
    assert _tokens_correspond("trade receivables", "trade receivable")
    assert _fuzzy("営業利益", ["経常利益"]) is None  # CJK: exact matches only


def test_cash_balance_lines():
    assert _cash_balance("cash & cash equivalents at 31 december") == "cash_ending"
    assert _cash_balance("cash & cash equivalents at 1 january") == "cash_beginning"
    assert _cash_balance("cash & cash equivalents at the end of the year") == "cash_ending"
    assert _cash_balance("cash & cash equivalents") is None


def test_parsers_for_real_world_notation():
    assert parse_number("※１331,129").value == 331_129
    assert parse_number("△10,126").value == -10_126
    assert parse_number("−16.858", decimal_hint=",").value == -16_858
    assert parse_period_header("(自　2024年１月１日") is None  # a start date: the end follows on the next line
    assert parse_period_header("　至　2024年12月31日)").key == "FY2024"
    assert parse_period_header("31. 12. 2025").key == "FY2025"  # thin spaces
    assert parse_period_header("1. 1.−31. 12. 2024").key == "FY2024"
    for text in ("(in T€)", "in TEUR", "kEUR"):
        assert detect_scale(text).factor == 1000


def test_annual_report_mentioning_half_year_is_still_annual():
    doc = read_document(synthetic.english_annual_report(), "ar.pdf")
    doc.pages[2].text += " Half-year results were published in July. Interim dividend."
    assert classify(doc) == "annual_report"


def test_no_label_maps_to_two_concepts_on_one_statement():
    seen: dict[tuple[str, str], set[str]] = {}
    for concept in TAX.concepts:
        for items in (concept.synonyms or {}).values():
            for synonym in items:
                seen.setdefault((concept.statement, normalise_label(synonym)), set()).add(concept.id)
    clashes = {k: v for k, v in seen.items() if len(v) > 1}
    assert not clashes


MANIFEST = Path(__file__).resolve().parents[2] / "tests" / "fixtures" / "manifest.yaml"


@pytest.mark.skipif(
    not (MANIFEST.parent / "downloaded").exists(), reason="public filings not downloaded (scripts/fetch_fixtures.py)"
)
def test_accuracy_on_public_filings_does_not_regress():
    import importlib.util

    spec = importlib.util.spec_from_file_location("accuracy", MANIFEST.parents[2] / "scripts" / "accuracy_report.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module  # dataclasses look their module up
    spec.loader.exec_module(module)
    results = [r for r in module.run() if r.status == "read"]
    correct = sum(r.correct for r in results)
    total = sum(r.scored for r in results)
    assert total and correct / total >= 0.95, module.render(results)
