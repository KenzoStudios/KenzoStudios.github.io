"""Text-based warning signs: every rule fires on its phrase and stays quiet on reassuring or conditional wording."""

from __future__ import annotations

import pytest

from dealscout_extraction.ingest import read_document
from dealscout_extraction.model import DocumentContent, PageContent
from dealscout_extraction.synthetic import clean_report, warning_signs_report
from dealscout_extraction.text_signals import (
    SNIPPET_MAX,
    document_year,
    scan_document,
    scan_text,
    snippet,
    to_red_flags,
)


def ids(text: str) -> set[str]:
    return {s.signal_id for s in scan_text(text)}


POSITIVE = [
    # going concern
    ("going_concern", "Material uncertainty related to going concern. We draw attention to note 2."),
    (
        "going_concern",
        "These conditions indicate that a material uncertainty exists that may cast significant doubt on the "
        "Company's ability to continue as a going concern.",
    ),
    (
        "going_concern",
        "These conditions raise substantial doubt about the Company's ability to continue as a going concern.",
    ),
    (
        "going_concern",
        "Es besteht eine wesentliche Unsicherheit im Zusammenhang mit der Fortführung der Unternehmenstätigkeit.",
    ),
    ("going_concern", "Existe una incertidumbre material relacionada con la empresa en funcionamiento."),
    ("going_concern", "Il existe une incertitude significative sur la continuité d'exploitation."),
    ("going_concern", "Sussiste un'incertezza significativa sulla continuità aziendale della società."),
    ("going_concern", "Er is sprake van een onzekerheid van materieel belang omtrent de continuïteit."),
    ("going_concern", "Existe uma incerteza material relacionada com a continuidade das operações."),
    ("going_concern", "継続企業の前提に関する重要な不確実性が存在する。"),
    # audit opinion
    ("qualified_opinion", "Basis for qualified opinion: we could not observe the inventory count."),
    (
        "qualified_opinion",
        "In our opinion, because of the matter described, the accounts do not give a true view. Adverse opinion.",
    ),
    ("qualified_opinion", "Disclaimer of opinion. We do not express an opinion on the financial statements."),
    ("qualified_opinion", "Wir erteilen einen eingeschränkten Bestätigungsvermerk."),
    ("qualified_opinion", "Fundamento de la opinión con salvedades."),
    ("qualified_opinion", "Nous certifions avec réserve : opinion avec réserve sur les stocks."),
    ("qualified_opinion", "Giudizio con rilievi sul bilancio d'esercizio."),
    ("qualified_opinion", "Wij hebben een verklaring met beperking verstrekt."),
    ("qualified_opinion", "Base para opinião com ressalva."),
    ("qualified_opinion", "限定付適正意見を表明する。"),
    # emphasis of matter
    (
        "emphasis_of_matter",
        "Emphasis of matter. We draw attention to note 30. Our opinion is not modified in respect of this matter.",
    ),
    ("emphasis_of_matter", "Hervorhebung eines Sachverhalts: Wir verweisen auf Anhang 4."),
    ("emphasis_of_matter", "Párrafo de énfasis sobre la nota 2."),
    ("emphasis_of_matter", "Richiamo d'informativa sulla nota 5."),
    # auditor change
    ("auditor_change", "Following a tender, the board approved a change of auditor; KPMG LLP replaces Smith & Co."),
    (
        "auditor_change",
        "Grant Thornton resigned as auditors on 3 March 2025. The auditors resigned after a disagreement.",
    ),
    ("auditor_change", "Die Hauptversammlung beschloss einen Wechsel des Abschlussprüfers."),
    ("auditor_change", "Se ha producido un cambio de auditor en el ejercicio."),
    ("auditor_change", "Nomination d'un nouveau commissaire aux comptes."),
    ("auditor_change", "Durante l'esercizio è stata nominata una nuova società di revisione."),
    # restatement
    ("restatement", "The comparative figures for 2024 have been restated to reflect the new segment structure."),
    ("restatement", "Correction of a prior period error in revenue recognition."),
    ("restatement", "Die Vorjahreszahlen wurden aufgrund einer Fehlerkorrektur angepasst."),
    ("restatement", "Las cifras comparativas han sido reexpresadas."),
    ("restatement", "Correction d'une erreur sur l'exercice précédent."),
    ("restatement", "過年度決算の訂正を行った。"),
    # related party
    ("related_party", "During the year the group granted a loan to a director of EUR 1.2 million."),
    ("related_party", "The group leases its head office from a company controlled by the chief executive."),
    ("related_party", "Transactions with related parties include a loan from the majority shareholder."),
    ("related_party", "Mit nahestehenden Personen bestehen Darlehen in Höhe von 2 Mio. EUR."),
    ("related_party", "Operaciones con partes vinculadas: préstamo concedido al accionista mayoritario."),
    ("related_party", "Transactions avec les parties liées : prêt accordé au dirigeant."),
    # customer concentration
    ("customer_concentration", "Our largest customer accounted for 34% of revenue."),
    ("customer_concentration", "The top five customers represented 62 per cent of group sales."),
    ("customer_concentration", "Der größte Kunde stand für 18 % des Umsatzes."),
    ("customer_concentration", "El mayor cliente representa el 27% de las ventas."),
    ("customer_concentration", "Le premier client représente 15 % du chiffre d'affaires."),
    ("customer_concentration", "Il primo cliente rappresenta il 21% dei ricavi."),
    ("customer_concentration", "De grootste klant was goed voor 12% van de omzet."),
    ("customer_concentration", "O maior cliente representou 40% da receita."),
    ("customer_concentration", "最大顧客への売上高は全体の３５％を占める。"),
]

NEGATIVE = [
    # going concern: reassurance and auditor boilerplate
    ("going_concern", "There is no material uncertainty related to going concern."),
    (
        "going_concern",
        "The directors are not aware of any material uncertainties that may cast doubt on the going concern basis.",
    ),
    (
        "going_concern",
        "We conclude whether a material uncertainty exists related to events or conditions that may cast significant "
        "doubt on the Company's ability to continue as a going concern.",
    ),
    (
        "going_concern",
        "Conclude whether, in our judgment, there are conditions or events, considered in the aggregate, that raise "
        "substantial doubt about the Company's ability to continue as a going concern for a reasonable period of time.",
    ),
    ("going_concern", "The financial statements have been prepared on a going concern basis."),
    (
        "going_concern",
        "Es bestehen keine wesentlichen Unsicherheiten in Bezug auf die Fortführung der Unternehmenstätigkeit.",
    ),
    ("going_concern", "Bestandsgefährdende Risiken sind derzeit nicht erkennbar."),
    ("going_concern", "No existe una incertidumbre material sobre la empresa en funcionamiento."),
    ("going_concern", "Il n'existe pas d'incertitude significative sur la continuité d'exploitation."),
    ("going_concern", "Non sussistono incertezze significative sulla continuità aziendale."),
    ("going_concern", "継続企業の前提に関する重要な不確実性は認められない。"),
    # audit opinion
    ("qualified_opinion", "We have issued an unqualified opinion on the consolidated financial statements."),
    ("qualified_opinion", "Our opinion is not qualified in respect of this matter."),
    ("qualified_opinion", "Wir erteilen einen uneingeschränkten Bestätigungsvermerk."),
    ("qualified_opinion", "Opinión sin salvedades."),
    ("qualified_opinion", "If we conclude that the disclosures are inadequate we would issue a qualified opinion."),
    # emphasis of matter
    ("emphasis_of_matter", "The report contains no emphasis of matter."),
    # auditor change
    ("auditor_change", "There was no change of auditor during the year."),
    (
        "auditor_change",
        "A resolution to re-appoint Deloitte as auditor will be proposed. No new auditor was appointed.",
    ),
    ("auditor_change", "Es gab keinen Wechsel des Abschlussprüfers."),
    # restatement
    ("restatement", "The comparative figures have not been restated."),
    ("restatement", "The Group has not restated comparative information for 2024."),
    ("restatement", "Die Vorjahreszahlen wurden nicht angepasst."),
    # related party
    ("related_party", "There were no loans to directors during the year."),
    ("related_party", "Note 24 Related party transactions: remuneration of key management personnel."),
    ("related_party", "No guarantees were provided to related parties."),
    # customer concentration
    ("customer_concentration", "No single customer accounted for more than 10% of revenue."),
    ("customer_concentration", "Our largest customer accounted for less than 5% of revenue."),
    ("customer_concentration", "Our largest customer accounted for 4% of revenue."),
    ("customer_concentration", "The top ten customers represented 22% of sales."),
    ("customer_concentration", "Our largest customer has been with us for 15 years and margins improved by 12%."),
    ("customer_concentration", "Kein einzelner Kunde stand für mehr als 10 % des Umsatzes."),
    ("customer_concentration", "Ningún cliente representa más del 10% de las ventas."),
    ("customer_concentration", "Aucun client ne représente plus de 10 % du chiffre d'affaires."),
]


@pytest.mark.parametrize(("signal_id", "text"), POSITIVE)
def test_rule_fires(signal_id: str, text: str) -> None:
    assert signal_id in ids(text), text


@pytest.mark.parametrize(("signal_id", "text"), NEGATIVE)
def test_rule_stays_quiet(signal_id: str, text: str) -> None:
    assert signal_id not in ids(text), text


def test_severity_rules() -> None:
    def sev(text: str, signal_id: str) -> str:
        return next(s.severity for s in scan_text(text) if s.signal_id == signal_id)

    assert sev("Our largest customer accounted for 34% of revenue.", "customer_concentration") == "high"
    assert sev("Our largest customer accounted for 12% of revenue.", "customer_concentration") == "medium"
    assert sev("The top five customers represented 35% of revenue.", "customer_concentration") == "medium"
    assert sev("The top five customers represented 55% of revenue.", "customer_concentration") == "high"
    assert sev("The comparative figures have been restated for the new segments.", "restatement") == "medium"
    assert sev("Comparative figures have been restated to correct an error.", "restatement") == "high"
    assert sev("Basis for qualified opinion.", "qualified_opinion") == "high"
    metric = next(s.metric for s in scan_text("Our largest customer accounted for 34.5% of revenue."))
    assert metric == pytest.approx(0.345)


def test_snippet_is_short_and_centred() -> None:
    long = ("Filler words about the market and the strategy of the group. " * 10).replace(". ", ", ")
    sentence = long + "Our largest customer accounted for 34% of revenue, " + long
    found = scan_text(sentence)
    assert found and len(found[0].snippet) <= SNIPPET_MAX + 2
    assert "34%" in found[0].snippet and found[0].snippet.startswith("…")
    assert snippet("short sentence", 0, 5) == "short sentence"


def test_line_breaks_inside_a_phrase_are_joined() -> None:
    assert "going_concern" in ids("Material uncertainty related\nto going concern\n")


def test_synthetic_pdf_end_to_end() -> None:
    doc = read_document(warning_signs_report(), "report.pdf")
    found = scan_document(doc, document_id="d1", filename="report.pdf")
    by_id = {s.signal_id: s for s in found}
    assert set(by_id) == {
        "customer_concentration",
        "qualified_opinion",
        "going_concern",
        "restatement",
        "related_party",
    }
    assert by_id["customer_concentration"].page == 1
    assert by_id["going_concern"].page == 2 and by_id["restatement"].page == 3
    assert by_id["restatement"].severity == "high"  # an error correction
    assert all(s.document_id == "d1" and s.filename == "report.pdf" for s in found)
    # the auditor's "whether a material uncertainty exists" boilerplate is not a second finding
    assert sum(1 for s in found if s.signal_id == "going_concern") == 1
    assert document_year(doc) == 2025

    flags = to_red_flags(found, period="FY2025")
    assert {f.id for f in flags} == {f"text_{i}" for i in by_id}
    concentration = next(f for f in flags if f.id == "text_customer_concentration")
    assert concentration.source == "document" and concentration.metric == pytest.approx(0.34)
    assert concentration.evidence[0].page == 1 and "34%" in concentration.evidence[0].snippet
    assert all(f.period == "FY2025" for f in flags)


def test_clean_pdf_has_no_signals() -> None:
    doc = read_document(clean_report(), "clean.pdf")
    assert scan_document(doc) == []


def test_spreadsheets_are_not_scanned() -> None:
    doc = DocumentContent(
        kind="xlsx", pages=[PageContent(page=1, text="Our largest customer accounted for 50% of sales")]
    )
    assert scan_document(doc) == []


def test_evidence_grouped_per_document_and_capped() -> None:
    pages = [PageContent(page=n, text="The group granted a loan to a director.") for n in range(1, 7)]
    doc = DocumentContent(kind="pdf", pages=pages)
    flags = to_red_flags(scan_document(doc, document_id="a", filename="a.pdf"), period="FY2025")
    assert len(flags) == 1 and [e.page for e in flags[0].evidence] == [1, 2, 3]
