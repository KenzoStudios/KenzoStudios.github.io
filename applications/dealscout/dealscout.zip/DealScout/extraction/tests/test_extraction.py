import io
import json
import zipfile

import pytest

from dealscout_ai.testing import ScriptedProvider
from dealscout_engine.taxonomy import load_taxonomy
from dealscout_extraction import synthetic
from dealscout_extraction.ingest import check_zip_safety, read_document, sniff_kind
from dealscout_extraction.locate import locate_statements
from dealscout_extraction.mapping import map_located
from dealscout_extraction.pipeline import extract

TAX = load_taxonomy()


def values(candidates):
    return {(c.concept_id, c.period_key): c.value for c in candidates}


def test_sniffing_uses_magic_bytes_not_extensions():
    assert sniff_kind(synthetic.english_annual_report(), "report.xlsx") == "pdf"
    assert sniff_kind(synthetic.management_accounts_xlsx(), "file.pdf") == "xlsx"
    assert sniff_kind(b"Line;2025;2024\nRevenue;1;2\n", "x.csv") == "csv"
    assert sniff_kind(b"<html><body>hi</body></html>", "a.htm") == "html"
    inline = b'<html xmlns:ix="http://www.xbrl.org/2013/inlineXBRL"><ix:header></ix:header></html>'
    assert sniff_kind(inline, "a.htm") == "xbrl"
    assert sniff_kind(b"<html><body>mentions ix:header in text</body></html>", "a.htm") == "html"
    assert sniff_kind(b"\x89PNG\r\n\x1a\n...", "scan.png") == "image"
    assert sniff_kind(b"random bytes", "x.bin") == "unknown"


def test_zip_safety_flags_path_traversal():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("../evil.txt", "x")
    assert any("Unsafe path" in p for p in check_zip_safety(buf.getvalue()))


def test_pdf_layout_tables_scale_language_and_note_column():
    doc = read_document(synthetic.english_annual_report(), "ar.pdf")
    assert doc.kind == "pdf" and doc.page_count == 5 and doc.language == "en"
    income = next(t for t in doc.tables if t.page == 2)
    assert [c.key for c in income.columns] == ["FY2025", "FY2024"]  # the "Note" column is dropped
    assert income.scale.factor == 1e6
    revenue = next(r for r in income.rows if r.label == "Revenue")
    assert revenue.cells["FY2025"].raw == "1,250.4" and revenue.cells["FY2025"].bbox is not None


def test_consolidated_preferred_over_parent_company():
    doc = read_document(synthetic.english_annual_report(), "ar.pdf")
    located = locate_statements(doc, TAX)
    assert located["balance_sheet"][0].page == 3 and located["balance_sheet"][0].consolidated is True
    assert all(t.page != 5 for t in located["balance_sheet"])
    assert located["income_statement"][0].page == 2 and located["cash_flow"][0].page == 4


def test_mapping_signs_scale_and_unmapped_bucket():
    doc = read_document(synthetic.english_annual_report(), "ar.pdf")
    candidates, unmapped, _warnings = map_located(doc, locate_statements(doc, TAX), TAX)
    v = values(candidates)
    assert v[("revenue", "FY2025")] == pytest.approx(1_250.4e6)
    assert v[("cogs", "FY2025")] == pytest.approx(-812.3e6)  # cost stored negative
    assert v[("lt_debt", "FY2025")] == pytest.approx(300e6)  # liability shown in brackets, stored positive
    assert v[("capex_ppe", "FY2024")] == pytest.approx(-80.1e6)
    assert v[("cash", "FY2025")] == pytest.approx(145.5e6)  # consolidated, not the parent company's 1.2
    assert v[("sga", "FY2025")] == pytest.approx(-201.5e6)
    lt_debt = next(c for c in candidates if c.concept_id == "lt_debt")
    assert lt_debt.notes and lt_debt.page == 3 and lt_debt.confidence > 0.8
    assert unmapped == []


def test_german_decimal_convention():
    doc = read_document(synthetic.german_annual_report(), "gb.pdf")
    assert doc.language == "de"
    candidates, _, _ = map_located(doc, locate_statements(doc, TAX), TAX)
    v = values(candidates)
    assert v[("revenue", "FY2025")] == pytest.approx(84_512_000)  # 84.512 Tsd. EUR
    assert v[("net_income", "FY2024")] == pytest.approx(3_744_000)
    assert v[("materials_expense", "FY2025")] == pytest.approx(-40_110_000)


def test_excel_and_csv():
    doc = read_document(synthetic.management_accounts_xlsx(), "m.xlsx")
    candidates, _, _ = map_located(doc, locate_statements(doc, TAX), TAX)
    v = values(candidates)
    assert v[("revenue", "FY2025")] == pytest.approx(55_870_000)
    assert v[("ebitda", "FY2024")] == pytest.approx(9_850_000)
    revenue = next(c for c in candidates if c.concept_id == "revenue" and c.period_key == "FY2025")
    assert revenue.cell_ref == "C4" and revenue.sheet == "P&L"
    csv = "Fictional Ltd;;\nEUR m;;\nLine item;2025;2024\nRevenue;1.234,5;1.100,0\nCost of sales;-700,0;-650,0\nOperating profit;150,0;120,0\n"
    doc = read_document(csv.encode(), "pnl.csv")
    candidates, _, _ = map_located(doc, locate_statements(doc, TAX), TAX)
    assert values(candidates)[("revenue", "FY2025")] == pytest.approx(1_234.5e6)


def test_pipeline_without_ai_reports_missing_core_items():
    out = extract(synthetic.german_annual_report(), "gb.pdf", TAX)
    assert out.ai_used is False and out.doc_type in {"other", "annual_report"}
    missing = {m["concept_id"] for m in out.not_found}
    assert {"total_assets", "cfo", "shares_outstanding"} <= missing
    assert "revenue" not in missing


def test_ai_values_are_verified_against_the_page():
    content = synthetic.english_annual_report()
    fake = ScriptedProvider(
        {
            "AIMappingResult": [json.dumps({"items": []})],
            "AIExtractionResult": [
                json.dumps(
                    {
                        "values": [
                            # printed on page 4 → accepted (it was cited on the wrong page; we find it)
                            {
                                "concept_id": "da_total",
                                "period": "2025",
                                "value_as_written": "55.0",
                                "page": 2,
                                "label": "Depreciation and amortisation",
                                "unit_scale": "€ million",
                                "confidence": 0.9,
                                "reason_if_null": None,
                            },
                            # not printed anywhere → rejected, never stored
                            {
                                "concept_id": "shares_outstanding",
                                "period": "2025",
                                "value_as_written": "88,123,456",
                                "page": 3,
                                "label": "Shares",
                                "unit_scale": None,
                                "confidence": 0.8,
                                "reason_if_null": None,
                            },
                            {
                                "concept_id": "st_debt",
                                "period": "2025",
                                "value_as_written": None,
                                "page": None,
                                "label": None,
                                "unit_scale": None,
                                "confidence": 0.0,
                                "reason_if_null": "No short-term borrowings line is shown.",
                            },
                        ]
                    }
                )
            ],
        }
    )
    out = extract(content, "ar.pdf", TAX, provider=fake.provider)
    v = values(out.candidates)
    assert v[("da_total", "FY2025")] == pytest.approx(-55.0e6)
    da = next(c for c in out.candidates if c.concept_id == "da_total")
    assert da.page == 4 and da.method == "ai_extraction" and any("cited page 2" in n for n in da.notes)
    assert ("shares_outstanding", "FY2025") not in v
    assert any(r["concept_id"] == "shares_outstanding" for r in out.rejected)
    assert any(n["concept_id"] == "st_debt" and "short-term" in n["reason"] for n in out.not_found)
    assert out.usage and out.usage[0].provider == "fake"
    # no native PDF support on this provider → page text with page markers was sent instead
    request = next(r for r in fake.requests if r["schema"] == "AIExtractionResult")
    assert any(getattr(part, "kind", "") == "page_text" and part.page == 4 for part in request["content"])


def test_ai_maps_unrecognised_rows_and_reads_numbers_from_the_table():
    pdf = synthetic.english_annual_report(sga_label="Overheads and selling costs")
    rules = extract(pdf, "ar.pdf", TAX)
    assert [u.label for u in rules.unmapped] == ["Overheads and selling costs"]
    fake = ScriptedProvider(
        {
            "AIMappingResult": [
                json.dumps(
                    {
                        "items": [
                            {
                                "row": 0,
                                "concept_id": "sga",
                                "confidence": 0.9,
                                "rationale": "Overheads and selling costs are SG&A.",
                            }
                        ]
                    }
                )
            ],
            "AIExtractionResult": [json.dumps({"values": []})],
        }
    )
    out = extract(pdf, "ar.pdf", TAX, provider=fake.provider)
    sga = [c for c in out.candidates if c.concept_id == "sga"]
    assert len(sga) == 2 and all(c.method == "ai_mapping" for c in sga)
    assert {c.period_key: c.value for c in sga}["FY2025"] == pytest.approx(-201.5e6)  # number read from the table
    assert out.unmapped == []


def test_ai_mapping_to_unknown_concept_is_ignored():
    pdf = synthetic.english_annual_report(sga_label="Overheads and selling costs")
    fake = ScriptedProvider(
        {
            "AIMappingResult": [
                json.dumps(
                    {"items": [{"row": 0, "concept_id": "made_up_concept", "confidence": 0.99, "rationale": "x"}]}
                )
            ],
            "AIExtractionResult": [json.dumps({"values": []})],
        }
    )
    out = extract(pdf, "ar.pdf", TAX, provider=fake.provider)
    assert [u.label for u in out.unmapped] == ["Overheads and selling costs"]
