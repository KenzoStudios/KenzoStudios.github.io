"""Excel (.xlsx/.xls) and CSV readers: find period headers, the label column and figures per row.

Cached values are read (openpyxl ``data_only=True``); formulas are never evaluated and macros never run.
"""

from __future__ import annotations

import csv
import io
from typing import Any

from openpyxl.utils import get_column_letter

from .model import DocumentContent, PageContent, Table, TableCell, TableColumn, TableRow
from .numbers import detect_scale, parse_number, parse_period_header

MAX_ROWS = 3000
MAX_COLS = 80


def _grids(content: bytes, kind: str) -> list[tuple[str, list[list[Any]]]]:
    if kind == "xlsx":
        from openpyxl import load_workbook

        wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
        out = []
        for ws in wb.worksheets:
            rows = []
            for r, row in enumerate(ws.iter_rows(values_only=True)):
                if r >= MAX_ROWS:
                    break
                rows.append(list(row[:MAX_COLS]))
            out.append((ws.title, rows))
        wb.close()
        return out
    if kind == "xls":
        import xlrd

        book = xlrd.open_workbook(file_contents=content, on_demand=True)
        out = []
        for sheet in book.sheets():
            rows = [sheet.row_values(r)[:MAX_COLS] for r in range(min(sheet.nrows, MAX_ROWS))]
            out.append((sheet.name, rows))
        return out
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = content.decode("latin-1")
    try:
        dialect = csv.Sniffer().sniff(text[:5000], delimiters=",;\t|")
        delimiter = dialect.delimiter
    except csv.Error:
        delimiter = "\t" if "\t" in text[:2000] else ","
    rows = [row[:MAX_COLS] for row in csv.reader(io.StringIO(text), delimiter=delimiter)][:MAX_ROWS]
    return [("CSV", rows)]


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _number(value: Any, decimal_hint: str | None) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int | float):
        return float(value)
    return parse_number(str(value), decimal_hint=decimal_hint).value  # type: ignore[arg-type]


def _table(
    sheet_index: int, name: str, grid: list[list[Any]], source: str, decimal_hint: str | None = None
) -> Table | None:
    header_row, periods = None, {}
    for r, row in enumerate(grid[:40]):
        found = {}
        for c, value in enumerate(row):
            text = _as_text(value)
            if not text:
                continue
            guess = parse_period_header(text)
            if guess:
                found[c] = (text, guess)
        if len(found) >= 1 and (len(found) >= 2 or header_row is None):
            header_row, periods = r, found
            if len(found) >= 2:
                break
    if header_row is None:
        return None
    first_period_col = min(periods)
    label_col = None
    for c in range(first_period_col - 1, -1, -1):
        texts = sum(
            1 for row in grid[header_row + 1 :] if c < len(row) and _as_text(row[c]) and _number(row[c], None) is None
        )
        if texts >= 2:
            label_col = c
            break
    if label_col is None:
        return None
    columns, used = [], set()
    for c in sorted(periods):
        raw, guess = periods[c]
        key = guess.key if guess.key not in used else f"{guess.key}#{c}"
        used.add(key)
        columns.append(TableColumn(key=key, raw=raw, period=guess))
    col_keys = {c: col.key for c, col in zip(sorted(periods), columns, strict=True)}
    rows: list[TableRow] = []
    for r in range(header_row + 1, len(grid)):
        row = grid[r]
        label = _as_text(row[label_col]) if label_col < len(row) else ""
        if not label:
            continue
        cells = {}
        for c, key in col_keys.items():
            value = row[c] if c < len(row) else None
            number = _number(value, decimal_hint)
            if number is None and _as_text(value) == "":
                continue
            cells[key] = TableCell(raw=_as_text(value), value=number, ref=f"{get_column_letter(c + 1)}{r + 1}")
        if any(cell.value is not None for cell in cells.values()):
            rows.append(TableRow(label=label, cells=cells, ref=f"{get_column_letter(label_col + 1)}{r + 1}"))
    if len(rows) < 2:
        return None
    top_text = " ".join(_as_text(v) for row in grid[: header_row + 1] for v in row if v is not None)
    return Table(
        page=sheet_index,
        sheet=name,
        columns=columns,
        rows=rows,
        scale=detect_scale(f"{name} {top_text}"),
        heading=f"{name} {top_text}"[:300],
        source="csv" if source == "csv" else "excel",
    )


def read_sheets(content: bytes, kind: str) -> DocumentContent:
    doc = DocumentContent(kind=kind)
    try:
        grids = _grids(content, kind)
    except Exception as error:
        doc.warnings.append(f"The spreadsheet could not be read ({type(error).__name__}).")
        return doc
    for index, (name, grid) in enumerate(grids, start=1):
        text = "\n".join("\t".join(_as_text(v) for v in row) for row in grid)
        doc.pages.append(PageContent(page=index, name=name, text=text))
        table = _table(index, name, grid, kind)
        if table:
            doc.tables.append(table)
    doc.page_count = len(grids)
    if kind == "xlsx" and not doc.tables and any("=" in p.text for p in doc.pages):
        doc.warnings.append(
            "Some cells are formulas without saved values; open and save the file in Excel, then upload again."
        )
    return doc
