"""PDF text and table reconstruction from word positions (PyMuPDF).

Financial statements are usually *unruled* tables: a label on the left and right-aligned figures per period. We
rebuild them from word coordinates instead of relying on drawn lines:

1. group words into visual lines by vertical centre;
2. split each line into segments where the horizontal gap is wide;
3. a row is a text label followed by numeric segments;
4. numeric columns are found by clustering the right edges of the figures on the page;
5. period headers (2025, FY24, 31.12.2025, 令和6年度 …) above the rows name the columns;
6. small-integer columns headed "Note"/"Anhang"/"Nota" are note references and are dropped.

Every cell keeps its bounding box so the review screen can highlight it on the page.
"""

from __future__ import annotations

import re
import statistics
from dataclasses import dataclass

import pymupdf

from .model import BBox, DocumentContent, PageContent, Table, TableCell, TableColumn, TableRow, Word
from .numbers import PeriodGuess, detect_scale, parse_number, parse_period_header

NOTE_HEADERS = re.compile(r"^(notes?|anhang|anm\.?|nota|notas|note n°|ref\.?|注記|注|tz\.?|textziffer)$", re.IGNORECASE)
SCANNED_TEXT_THRESHOLD = 25
DECIMAL_COMMA_LANGUAGES = {"de", "es", "fr", "it", "pt", "nl"}


@dataclass
class _Segment:
    text: str
    x0: float
    y0: float
    x1: float
    y1: float

    @property
    def bbox(self) -> BBox:
        return (self.x0, self.y0, self.x1, self.y1)


@dataclass
class _Line:
    y: float
    segments: list[_Segment]

    @property
    def text(self) -> str:
        return " ".join(s.text for s in self.segments)


def _lines(words: list[tuple[float, float, float, float, str]]) -> list[_Line]:
    if not words:
        return []
    heights = [w[3] - w[1] for w in words if w[3] > w[1]]
    h = statistics.median(heights) if heights else 8.0
    ordered = sorted(words, key=lambda w: ((w[1] + w[3]) / 2, w[0]))
    groups: list[list[tuple[float, float, float, float, str]]] = []
    for w in ordered:
        yc = (w[1] + w[3]) / 2
        if groups and abs(yc - (groups[-1][0][1] + groups[-1][0][3]) / 2) <= max(2.0, 0.45 * h):
            groups[-1].append(w)
        else:
            groups.append([w])
    lines: list[_Line] = []
    gap_limit = max(5.0, 0.9 * h)
    for group in groups:
        group.sort(key=lambda w: w[0])
        segs: list[_Segment] = []
        for x0, y0, x1, y1, text in group:
            if segs and x0 - segs[-1].x1 <= gap_limit:
                s = segs[-1]
                s.text, s.x1, s.y0, s.y1 = f"{s.text} {text}", x1, min(s.y0, y0), max(s.y1, y1)
            else:
                segs.append(_Segment(text, x0, y0, x1, y1))
        lines.append(_Line(y=(group[0][1] + group[0][3]) / 2, segments=segs))
    return lines


def _is_numeric(text: str) -> bool:
    t = text.strip()
    if not t:
        return False
    if t in {"-", "–", "—", "−", "－", "‐", "‒"}:
        return True
    if not re.search(r"\d", t):
        return False
    return parse_number(t).value is not None


def _looks_like_header(line: _Line) -> bool:
    """A period header line: every figure on it is a period, and either two or more periods or no wordy label."""
    periods = [s for s in line.segments if parse_period_header(s.text)]
    if not periods:
        return False
    numeric = [s for s in line.segments if _is_numeric(s.text)]
    if not all(parse_period_header(s.text) for s in numeric):
        return False
    wordy = [s for s in line.segments if s not in periods and re.search(r"[^\W\d_]{4,}", s.text)]
    return len(periods) >= 2 or not wordy


_W = tuple[float, float, float, float, str]


def _crossings(words: list[_W], x: float) -> int:
    return sum(1 for w in words if w[0] < x < w[2])


def _best_gutter(words: list[_W], lo: float, hi: float) -> tuple[float, int]:
    """The x in [lo, hi] crossed by the fewest words (centre of the widest such run)."""
    best_x, best_n, run_start, best_len = lo, 10**9, None, -1.0
    x = lo
    while x <= hi:
        n = _crossings(words, x)
        if n < best_n:
            best_n, best_x, run_start, best_len = n, x, x, 0.0
        elif n == best_n and run_start is not None:
            if x - run_start > best_len:
                best_len, best_x = x - run_start, (run_start + x) / 2
        else:
            run_start = None if n > best_n else run_start
        if n > best_n:
            run_start = None
        elif run_start is None:
            run_start = x
        x += 1.0
    return best_x, best_n


def _centre_gutter(words: list[_W], width: float, allowance: int) -> tuple[float, int]:
    """For a two-page spread: the x nearest the middle that at most ``allowance`` words cross (a title may)."""
    centre = width / 2
    scanned = [(float(x), _crossings(words, float(x))) for x in range(int(width * 0.4), int(width * 0.6) + 1)]
    open_x = [(abs(x - centre), x, n) for x, n in scanned if n <= allowance]
    if open_x:
        _, x, n = min(open_x)
        return x, n
    x, n = min(scanned, key=lambda xn: (xn[1], abs(xn[0] - centre)))
    return x, n


def _row_like_lines(words: list[_W]) -> int:
    """Lines that read as a table row on their own: a worded label left of a figure with three or more digits."""
    count = 0
    for line in _lines(words):
        figures = [s for s in line.segments if _is_numeric(s.text) and len(re.findall(r"\d", s.text)) >= 3]
        if figures and any(s.x1 <= figures[0].x0 and re.search(r"[^\W\d_]{3,}", s.text) for s in line.segments):
            count += 1
    return count


def _halves(words: list[_W], x: float) -> tuple[list[_W], list[_W]] | None:
    left = [w for w in words if (w[0] + w[2]) / 2 < x]
    right = [w for w in words if (w[0] + w[2]) / 2 >= x]
    # each side must stand alone as a table; a label column split from its figures does not
    if _row_like_lines(left) >= 3 and _row_like_lines(right) >= 3:
        return left, right
    return None


def split_regions(words: list[_W], width: float, height: float) -> list[list[_W]]:
    """Split a page into side-by-side regions before reading tables.

    Two cases: a landscape spread of two printed pages, and a statement set in two columns whose period header
    repeats (2025 2024 … 2025 2024). Each region is then read as its own table on the same page.
    """
    if len(words) < 20:
        return [words]
    allowance = max(2, int(0.02 * len(words)))
    if width > height * 1.15:
        x, n = _centre_gutter(words, width, allowance)
        halves = _halves(words, x) if n <= allowance else None
        if halves:
            return [r for part in halves for r in split_regions(part, width / 2, height * 2)]
    for line in _lines(words):
        periods = [s for s in line.segments if parse_period_header(s.text)]
        keys = [getattr(parse_period_header(s.text), "key", None) for s in periods]
        half = len(keys) // 2
        if len(keys) >= 4 and len(keys) % 2 == 0 and keys[:half] == keys[half:]:
            left_edge = max(s.x1 for s in periods[:half])
            right_start = min(s.x0 for s in periods[half:])
            x, n = _best_gutter(words, left_edge, max(left_edge, right_start - 40))
            halves = _halves(words, x) if n <= allowance else None
            if halves:
                return list(halves)
    return [words]


def _cluster(values: list[float], tolerance: float) -> list[list[float]]:
    clusters: list[list[float]] = []
    for v in sorted(values):
        if clusters and v - clusters[-1][-1] <= tolerance:
            clusters[-1].append(v)
        else:
            clusters.append([v])
    return clusters


_ENUMERATOR = re.compile(r"^(\(?\d{1,2}[.)]|[a-z]\)|[ivx]{1,4}\.|[A-H]\.)$", re.IGNORECASE)  # 1.  a)  IV.  B.
_SIGN_MARK = re.compile(r"^(\+|−|-|–|=|\+/−|−/\+|\+/-|-/\+)$")  # "− Auszahlungen für …" in a cash flow statement
_SUB_ITEM = re.compile(r"^[a-z]{1,2}\)\s")  # "a) Löhne und Gehälter"
_PARENT_ITEM = re.compile(r"^(\d{1,2}\.|[IVX]{1,4}\.|[A-H]\.)\s")


def _page_table(page_number: int, lines: list[_Line], page_text: str, decimal_hint: str | None = None) -> Table | None:
    rows_raw: list[tuple[_Line, list[_Segment], list[_Segment]]] = []
    for line in lines:
        # a leading line number ("1.", "a)") is part of the label, not a figure
        segments = list(line.segments)
        lead = [
            s
            for s in segments[:1]
            if _ENUMERATOR.match(s.text.strip())
            or (_SIGN_MARK.match(s.text.strip()) and len(segments) > 1 and not _is_numeric(segments[1].text))
        ]
        nums = [s for s in segments if s not in lead and _is_numeric(s.text)]
        if not nums or _looks_like_header(line):
            continue
        label_parts = [s for s in segments if s not in nums and s.x1 <= min(n.x0 for n in nums) + 1]
        rows_raw.append((line, label_parts, nums))
    if len(rows_raw) < 3:
        return None

    right_edges = [n.x1 for _, _, nums in rows_raw for n in nums]
    clusters = [c for c in _cluster(right_edges, 14.0) if len(c) >= 2]
    if not clusters:
        return None
    centers = [statistics.median(c) for c in clusters]

    def column_of(x1: float) -> int | None:
        best = min(range(len(centers)), key=lambda i: abs(centers[i] - x1))
        return best if abs(centers[best] - x1) <= 20 else None

    spans: dict[int, tuple[float, float]] = {}
    for _, _, nums in rows_raw:
        for n in nums:
            col = column_of(n.x1)
            if col is not None:
                lo, hi = spans.get(col, (n.x0, n.x1))
                spans[col] = (min(lo, n.x0), max(hi, n.x1))

    def header_columns(seg: _Segment) -> list[int]:
        """Figure columns under a header, left to right: every column it overlaps, else the nearest right edge."""
        width = max(1.0, seg.x1 - seg.x0)
        under = [
            i
            for i, (lo, hi) in sorted(spans.items())
            if min(seg.x1, hi) - max(seg.x0, lo) > 0.25 * min(width, max(1.0, hi - lo))
        ]
        if under:
            return under
        col = column_of(seg.x1)
        if col is None:
            col = column_of((seg.x0 + seg.x1) / 2 + 15)
        return [] if col is None else [col]

    # Period headers: the header line nearest above the figures wins (running page headers like "Annual Report
    # 2025" sit further up), then repeated headers inside the table.
    first_row_y = rows_raw[0][0].y
    header_lines = [ln for ln in lines if _looks_like_header(ln)]
    header_lines.sort(key=lambda ln: (ln.y > first_row_y, abs(first_row_y - ln.y)))
    header_for: dict[int, tuple[str, PeriodGuess | None]] = {}
    detail_cols: set[int] = set()
    for line in header_lines:
        for seg in line.segments:
            guess = parse_period_header(seg.text)
            if guess is None:
                continue
            under = [c for c in header_columns(seg) if c not in header_for and c not in detail_cols]
            if not under:
                continue
            # a header spanning two columns: the right one holds the totals, the left one sub-item detail
            header_for[under[-1]] = (seg.text, guess)
            detail_cols.update(under[:-1])
    note_cols: set[int] = set()
    for line in lines:
        if line.y > first_row_y:
            break
        for seg in line.segments:
            if NOTE_HEADERS.match(seg.text.strip()):
                col = column_of(seg.x1) if column_of(seg.x1) is not None else column_of(seg.x0 + 10)
                if col is not None:
                    note_cols.add(col)
    for idx, _members in enumerate(clusters):  # unlabelled note columns: small integers only, left of the figures
        if idx in header_for or idx in note_cols:
            continue
        values = [n.text for _, _, nums in rows_raw for n in nums if column_of(n.x1) == idx]
        if (
            values
            and all(re.fullmatch(r"\d{1,2}(\.\d{1,2})?\.?[a-z]?", v.strip()) for v in values)
            and idx == 0
            and len(centers) > 1
        ):
            note_cols.add(idx)
    if header_for:
        # an unheaded column just left of a headed one is sub-item detail (HGB/IFRS two-level layouts)
        for idx in range(len(centers)):
            if idx not in header_for and idx not in note_cols and idx + 1 in header_for:
                detail_cols.add(idx)
    main_of = {d: min((h for h in header_for if h > d), default=d) for d in detail_cols}

    columns: list[TableColumn] = []
    key_of: dict[int, str] = {}
    used_keys: set[str] = set()
    for idx, center in enumerate(centers):
        if idx in note_cols or idx in detail_cols:
            continue
        raw, guess = header_for.get(idx, (f"Column {idx + 1}", None))
        key = getattr(guess, "key", None) or f"col{idx + 1}"
        if key in used_keys:
            key = f"{key}#{idx + 1}"
        used_keys.add(key)
        key_of[idx] = key
        columns.append(TableColumn(key=key, raw=str(raw), period=guess, x_right=center))
    if not columns:
        return None

    def cell(n: _Segment) -> TableCell:
        return TableCell(raw=n.text, value=parse_number(n.text, decimal_hint=decimal_hint).value, bbox=n.bbox)  # type: ignore[arg-type]

    rows: list[TableRow] = []
    parent: TableRow | None = None  # the latest numbered item ("5. Materialaufwand") for HGB-style totals
    pending_label: tuple[str, BBox] | None = None
    min_x = min((s.x0 for line, _, _ in rows_raw for s in line.segments), default=0.0)
    numeric_ys = {id(line) for line, _, _ in rows_raw}
    for line in lines:
        if line.y < first_row_y - 1:
            continue
        if id(line) not in numeric_ys:
            text = line.text.strip()
            if text and len(text) < 160 and not parse_period_header(text):
                if pending_label and _PARENT_ITEM.match(pending_label[0]):
                    parent = TableRow(label=pending_label[0], label_bbox=pending_label[1], cells={})
                    rows.append(parent)
                pending_label = (text, line.segments[0].bbox)
            continue
        match = next(r for r in rows_raw if r[0] is line)
        _, label_parts, nums = match
        label = " ".join(s.text for s in label_parts).strip()
        bbox = label_parts[0].bbox if label_parts else None
        if pending_label and _SUB_ITEM.match(label) and _PARENT_ITEM.match(pending_label[0]):
            parent = TableRow(label=pending_label[0], label_bbox=pending_label[1], cells={})
            rows.append(parent)
        elif pending_label and (not label or label[:1].islower()):
            label = f"{pending_label[0]} {label}".strip()
            bbox = bbox or pending_label[1]
        pending_label = None
        if not label:
            continue
        own: dict[str, TableCell] = {}
        detail: dict[str, TableCell] = {}
        for n in nums:
            col = column_of(n.x1)
            if col is None:
                continue
            if col in detail_cols and main_of[col] in key_of:
                detail[key_of[main_of[col]]] = cell(n)
            elif col in key_of:
                own[key_of[col]] = cell(n)
        cells = dict(own)
        if detail:
            if _SUB_ITEM.match(label) and parent is not None:
                # sub-item amount in the detail column; a figure in the main column on this line is the parent total
                for key, value in own.items():
                    parent.cells.setdefault(key, value)
                cells = detail
            else:
                cells = {**detail, **own}
        if _PARENT_ITEM.match(label):
            parent = None
        if cells:
            row = TableRow(
                label=label,
                label_bbox=bbox,
                cells=cells,
                indent=(label_parts[0].x0 - min_x) if label_parts else 0.0,
            )
            rows.append(row)
            if _PARENT_ITEM.match(label):
                parent = row
    rows = [r for r in rows if r.cells]
    if len(rows) < 3:
        return None
    heading = " ".join(line.text for line in lines[:6])[:300]
    scale = detect_scale(" ".join(line.text for line in lines if line.y < first_row_y + 1)) or detect_scale(
        page_text[:1500]
    )
    return Table(page=page_number, columns=columns, rows=rows, scale=scale, heading=heading, source="pdf_layout")


_STOPWORDS = {
    "en": {"the", "and", "of", "to", "for", "in", "on", "with"},
    "de": {"und", "der", "die", "das", "für", "mit", "des", "im"},
    "es": {"de", "la", "y", "los", "las", "del", "en", "por"},
    "fr": {"et", "les", "des", "le", "la", "du", "pour", "dans"},
    "it": {"e", "di", "il", "della", "del", "per", "che", "nel"},
    "pt": {"e", "de", "do", "da", "os", "das", "para", "com"},
    "nl": {"en", "van", "de", "het", "voor", "met", "op", "een"},
}


def guess_language(text: str) -> str | None:
    if not text.strip():
        return None
    cjk = len(re.findall(r"[぀-ヿ一-鿿]", text))
    if cjk > 50:
        # kana, yen units, 株式会社 or the △ minus are Japanese; Chinese reports use 元 and 公司
        return "ja" if re.search(r"[぀-ヿ]|円|株式会社|△", text) else "zh"
    tokens = re.findall(r"[a-zà-ÿ]+", text.lower())[:5000]
    scores = {lang: sum(1 for t in tokens if t in words) for lang, words in _STOPWORDS.items()}
    lang, score = max(scores.items(), key=lambda kv: kv[1])
    return lang if score >= 5 else None


def read_pdf(content: bytes, *, max_pages: int = 1500, force_scanned: bool = False) -> DocumentContent:
    from . import ocr

    doc = DocumentContent(kind="pdf")
    try:
        pdf = pymupdf.open(stream=content, filetype="pdf")
    except Exception as error:  # corrupt or encrypted
        doc.warnings.append(f"The PDF could not be opened ({type(error).__name__}).")
        return doc
    if pdf.needs_pass:
        doc.warnings.append("The PDF is password-protected; remove the password and upload it again.")
        return doc
    doc.page_count = pdf.page_count
    sample: list[str] = []
    pending: list[tuple[int, list[tuple[float, float, float, float, str]], str, bool]] = []
    scanned_indexes: list[int] = []
    for index in range(min(pdf.page_count, max_pages)):
        page = pdf[index]
        raw_words = page.get_text("words")
        text = page.get_text("text")
        scanned = force_scanned or (len(text.strip()) < SCANNED_TEXT_THRESHOLD and bool(page.get_images(full=False)))
        words = [(w[0], w[1], w[2], w[3], w[4]) for w in raw_words]
        content_page = PageContent(
            page=index + 1,
            width=page.rect.width,
            height=page.rect.height,
            text=text,
            words=[Word(text=w[4], bbox=(w[0], w[1], w[2], w[3])) for w in words],
            is_scanned=scanned,
        )
        doc.pages.append(content_page)
        if scanned:
            doc.scanned_pages += 1
            scanned_indexes.append(index)
            continue
        if len(sample) < 20:
            sample.append(text)
        pending.append((index + 1, words, text, False))
    # Decimal convention follows the document language: 1.234,5 in German/Spanish/French/Italian, 1,234.5 in English.
    doc.language = guess_language("\n".join(sample))
    if scanned_indexes:
        if ocr.ocr_available():
            languages = ocr.ocr_languages(doc.language)
            for index in scanned_indexes[: ocr.MAX_OCR_PAGES]:
                words, text = ocr.ocr_page(pdf[index], languages)
                page_content = doc.pages[index]
                page_content.words = [Word(text=w[4], bbox=(w[0], w[1], w[2], w[3])) for w in words]
                page_content.text = text
                page_content.ocr = True
                if len(sample) < 20:
                    sample.append(text)
                pending.append((index + 1, words, text, True))
            doc.language = doc.language or guess_language("\n".join(sample))
            if len(scanned_indexes) > ocr.MAX_OCR_PAGES:
                doc.warnings.append(f"Only the first {ocr.MAX_OCR_PAGES} scanned pages were read with OCR.")
            doc.warnings.append(
                f"{len(scanned_indexes)} scanned page(s) were read with OCR; check those figures against the image."
            )
        else:
            doc.warnings.append(ocr.not_available_warning(len(scanned_indexes)))
    decimal_hint = "," if doc.language in DECIMAL_COMMA_LANGUAGES else "." if doc.language else None
    for number, words, text, from_ocr in sorted(pending, key=lambda item: item[0]):
        target = doc.page(number)
        assert target is not None
        for region in split_regions(words, target.width, target.height):
            table = _page_table(number, _lines(region), text, decimal_hint)
            if table:
                if from_ocr:
                    table.source = "ocr"
                doc.tables.append(table)
    if pdf.page_count > max_pages:
        doc.warnings.append(f"Only the first {max_pages} pages were read.")
    return doc
