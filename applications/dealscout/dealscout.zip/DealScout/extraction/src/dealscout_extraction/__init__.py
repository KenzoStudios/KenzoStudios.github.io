"""dealscout_extraction package."""

__version__ = "0.1.0"
