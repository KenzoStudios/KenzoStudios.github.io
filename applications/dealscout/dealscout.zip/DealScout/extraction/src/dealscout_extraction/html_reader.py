"""HTML and Word (.docx) tables, and the inline-XBRL container (brief §3: BeautifulSoup/lxml, python-docx).

Each ``<table>`` (or Word table) becomes a grid of cell texts that goes through the same header/label/figure logic as
spreadsheets. SEC-style HTML splits a figure over several cells (``$`` | ``1,234`` | ``)``); those pieces are joined
back into one cell before reading. Every cell keeps a reference ``t{table}r{row}c{col}`` so the review screen can
highlight it in the original document.
"""

from __future__ import annotations

import io
import re
from typing import Any

from lxml import etree
from lxml import html as lxml_html

from .model import DocumentContent, PageContent
from .numbers import detect_scale, parse_number, parse_period_header
from .sheet_reader import _table

MAX_TABLES = 2000
_CURRENCY_ONLY = re.compile(r"^[$€£¥₹]|^(USD|EUR|GBP|CHF|JPY)$")
_SKIP_TAGS = {"script", "style", "noscript", "template"}


def _html_root(content: bytes) -> Any:
    parser = lxml_html.HTMLParser(remove_comments=True, no_network=True, huge_tree=True)
    return lxml_html.parse(io.BytesIO(content), parser).getroot()


def html_tables(root: Any) -> list[Any]:
    """Every table element in document order (the same order the viewer uses to find a cell)."""
    if root is None:
        return []
    return [el for el in root.iter() if isinstance(el.tag, str) and el.tag.split("}")[-1].lower() == "table"]


def _cell_text(cell: Any) -> str:
    parts = []
    for text in cell.itertext():
        parts.append(text)
    return re.sub(r"\s+", " ", "".join(parts).replace(" ", " ")).strip()


def _grid(table: Any) -> list[list[str]]:
    """Rows of cell texts; colspans repeated so headers line up with the figures beneath them."""
    grid: list[list[str]] = []
    for tr in table.iter():
        if not isinstance(tr.tag, str) or tr.tag.split("}")[-1].lower() != "tr":
            continue
        row: list[str] = []
        for cell in tr:
            if not isinstance(cell.tag, str) or cell.tag.split("}")[-1].lower() not in ("td", "th"):
                continue
            text = _cell_text(cell)
            try:
                span = max(1, min(int(cell.get("colspan", "1") or 1), 20))
            except ValueError:
                span = 1
            row.append(text)
            # a period header spans the columns of its figures ($ | 1,234); repeat it so each column has a period
            row.extend([text if parse_period_header(text) else ""] * (span - 1))
        grid.append(_join_split_figures(row))
    return grid


def _join_split_figures(row: list[str]) -> list[str]:
    """``$ | 1,234 | )`` → ``1,234`` and ``( | 56 | )`` → ``(56)``, keeping cell positions."""
    out = list(row)
    for i, text in enumerate(out):
        if _CURRENCY_ONLY.match(text) and len(text) <= 3:
            out[i] = ""
        elif text in (")", "%)", ")%"):
            j = i - 1
            while j >= 0 and not out[j]:
                j -= 1
            if j >= 0 and not out[j].endswith(")") and parse_number(f"({out[j].lstrip('(')})").value is not None:
                out[j] = f"({out[j].lstrip('(')})"
            out[i] = ""
        elif text == "(":
            out[i] = ""
            k = i + 1
            while k < len(out) and not out[k]:
                k += 1
            if k < len(out) and parse_number(out[k]).value is not None:
                out[k] = f"({out[k]}" if not out[k].startswith("(") else out[k]
    return out


def _heading_before(table: Any, limit: int = 400) -> str:
    """Text just before the table (its title, unit line), walking back through preceding elements."""
    texts: list[str] = []
    node = table
    size = 0
    while node is not None and size < limit:
        prev = node.getprevious()
        while prev is None:
            node = node.getparent()
            if node is None:
                break
            prev = node.getprevious()
        if node is None or prev is None:
            break
        node = prev
        if isinstance(node.tag, str) and node.tag.split("}")[-1].lower() in _SKIP_TAGS | {"table"}:
            if node.tag.split("}")[-1].lower() == "table":
                break
            continue
        text = re.sub(r"\s+", " ", " ".join(node.itertext()) if isinstance(node.tag, str) else "").strip()
        if text:
            texts.insert(0, text[-limit:])
            size += len(text)
    return " ".join(texts)[-limit:]


def _tagged_names(table: Any) -> list[str]:
    return [
        el.get("name", "")
        for el in table.iter()
        if isinstance(el.tag, str) and el.tag.lower().endswith("nonfraction") and el.get("name")
    ]


def _tables_from_grids(
    doc: DocumentContent,
    grids: list[tuple[str, list[list[str]]]],
    source: str,
    tags: list[list[str]] | None = None,
) -> None:
    from .pdf_reader import DECIMAL_COMMA_LANGUAGES, guess_language

    sample = " ".join(heading + " " + " ".join(" ".join(r) for r in grid[:30]) for heading, grid in grids[:60])
    doc.language = doc.language or guess_language(sample)
    decimal_hint = "," if doc.language in DECIMAL_COMMA_LANGUAGES else "." if doc.language else None
    for index, (heading, grid) in enumerate(grids, start=1):
        doc.pages.append(
            PageContent(
                page=index,
                name=f"Table {index}",
                text=f"{heading}\n" + "\n".join(" | ".join(c for c in row if c) for row in grid[:200]),
            )
        )
        table = _table(index, f"Table {index}", grid, "csv", decimal_hint)
        if table is None:
            continue
        refs = {}
        for r, row in enumerate(grid):
            for c, _ in enumerate(row):
                refs[(r, c)] = f"t{index}r{r}c{c}"
        # replace spreadsheet-style refs (A1) with table/row/column refs the viewer can find
        for table_row in table.rows:
            for cell in table_row.cells.values():
                if cell.ref:
                    m = re.match(r"([A-Z]+)(\d+)", cell.ref)
                    if m:
                        col = _col_index(m.group(1))
                        cell.ref = refs.get((int(m.group(2)) - 1, col), cell.ref)
        table.source = source  # type: ignore[assignment]
        table.tags = tags[index - 1] if tags else []
        table.heading = f"{heading} {table.heading}"[:300]
        if table.scale is None:
            table.scale = detect_scale(heading)
        table.sheet = None
        doc.tables.append(table)


def _col_index(letters: str) -> int:
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def read_html(content: bytes, *, kind: str = "html") -> DocumentContent:
    doc = DocumentContent(kind=kind)
    try:
        root = _html_root(content)
    except (etree.ParserError, ValueError) as error:
        doc.warnings.append(f"The HTML could not be read ({type(error).__name__}).")
        return doc
    tables = html_tables(root)[:MAX_TABLES]
    grids = [(_heading_before(t), _grid(t)) for t in tables]
    _tables_from_grids(doc, grids, "html", [_tagged_names(t) for t in tables] if kind == "xbrl" else None)
    doc.page_count = len(grids)
    return doc


def read_docx(content: bytes) -> DocumentContent:
    from docx import Document as WordDocument

    doc = DocumentContent(kind="docx")
    try:
        word = WordDocument(io.BytesIO(content))
    except Exception as error:  # corrupt or not a Word file
        doc.warnings.append(f"The Word document could not be opened ({type(error).__name__}).")
        return doc
    grids: list[tuple[str, list[list[str]]]] = []
    body = word.element.body
    last_text = ""
    for child in body.iterchildren():
        tag = child.tag.split("}")[-1]
        if tag == "p":
            text = "".join(t.text or "" for t in child.iter() if t.tag.endswith("}t")).strip()
            if text:
                last_text = (last_text + " " + text)[-400:]
        elif tag == "tbl":
            rows = []
            for tr in child.iter():
                if not tr.tag.endswith("}tr"):
                    continue
                row = []
                for tc in tr:
                    if not tc.tag.endswith("}tc"):
                        continue
                    text = " ".join(
                        "".join(t.text or "" for t in p.iter() if t.tag.endswith("}t"))
                        for p in tc.iter()
                        if p.tag.endswith("}p")
                    ).strip()
                    row.append(re.sub(r"\s+", " ", text))
                rows.append(_join_split_figures(row))
            grids.append((last_text, rows))
            last_text = ""
    _tables_from_grids(doc, grids, "docx")
    doc.page_count = len(grids)
    if not grids:
        doc.warnings.append("No tables were found in this Word document.")
    return doc


# ── a safe, highlightable copy for the review screen ───────────────────────────
_DROP_ELEMENTS = {
    "script",
    "iframe",
    "frame",
    "frameset",
    "object",
    "embed",
    "applet",
    "base",
    "form",
    "link",
    "noscript",
}
VIEW_STYLE = """
:target { outline: 3px solid #2F6DB5 !important; outline-offset: 2px; background: rgba(47,109,181,.18) !important;
  scroll-margin: 35vh; }
tr:has(> :target) { background: rgba(47,109,181,.07) !important; }
html { scroll-behavior: auto; background: #fff; color-scheme: light; }
"""


def viewable_html(content: bytes) -> bytes:
    """Strip active content and give every table cell an id ``t{table}r{row}c{col}`` (matching cell refs).

    The result is served with a CSP sandbox; ids let the review screen jump to and highlight a value with a URL
    fragment (``:target``), so the document never has to be reloaded or scripted.
    """
    root = _html_root(content)
    if root is None:
        return b"<!doctype html><p>This document could not be displayed.</p>"
    for el in list(root.iter()):
        if not isinstance(el.tag, str):
            continue
        tag = el.tag.split("}")[-1].lower()
        if tag in _DROP_ELEMENTS or (tag == "meta" and (el.get("http-equiv") or "").lower() == "refresh"):
            el.drop_tree()
            continue
        unsafe = [
            attr
            for attr, value in el.attrib.items()
            if attr.lower().startswith("on")
            or (
                attr.lower() in ("href", "src", "action", "formaction", "xlink:href")
                and value.strip().lower().startswith(("javascript:", "vbscript:", "data:text/html"))
            )
        ]
        for attr in unsafe:
            try:
                del el.attrib[attr]
            except (KeyError, ValueError):
                el.set(attr, "")
    for k, table in enumerate(html_tables(root), start=1):
        r = 0
        for tr in table.iter():
            if not isinstance(tr.tag, str) or tr.tag.split("}")[-1].lower() != "tr":
                continue
            c = 0
            for cell in tr:
                if not isinstance(cell.tag, str) or cell.tag.split("}")[-1].lower() not in ("td", "th"):
                    continue
                if not cell.get("id"):
                    cell.set("id", f"t{k}r{r}c{c}")
                try:
                    c += max(1, min(int(cell.get("colspan", "1") or 1), 20))
                except ValueError:
                    c += 1
            r += 1
    head = root.find("head") if root.find("head") is not None else root.find("{http://www.w3.org/1999/xhtml}head")
    style = etree.Element("style")
    style.text = VIEW_STYLE
    if head is not None:
        head.insert(0, style)
    else:
        root.insert(0, style)
    return lxml_html.tostring(root, encoding="utf-8", doctype="<!DOCTYPE html>")
