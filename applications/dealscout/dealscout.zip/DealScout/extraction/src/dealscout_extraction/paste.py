"""Parse a statement pasted from Excel (tab-separated) into labelled rows by period (brief §12).

Returns a preview: detected periods, scale, and each row's label, numbers and the taxonomy concepts it may map to.
Nothing is written until the user confirms the mapping.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dealscout_engine.taxonomy import Taxonomy

from .numbers import DecimalHint, PeriodGuess, Scale, detect_scale, parse_number, parse_period_header


@dataclass
class PastedRow:
    label: str
    values: dict[str, float | None]  # period key -> value as written (before scale)
    candidates: list[str]
    concept_id: str | None
    raw_cells: list[str] = field(default_factory=list)
    ambiguous_numbers: bool = False


@dataclass
class PastePreview:
    periods: list[PeriodGuess]
    scale: Scale | None
    rows: list[PastedRow]
    unmatched: int
    warnings: list[str]


def parse_pasted_table(text: str, taxonomy: Taxonomy, *, decimal_hint: DecimalHint = None) -> PastePreview:
    lines = [line for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n") if line.strip()]
    grid = [line.split("\t") for line in lines]
    warnings: list[str] = []
    scale = None
    for line in lines[:6]:
        scale = scale or detect_scale(line)

    header_index, period_cols = None, {}
    for i, cells in enumerate(grid[:10]):
        found = {j: g for j, cell in enumerate(cells) if (g := parse_period_header(cell))}
        if found:
            header_index, period_cols = i, found
            break
    if header_index is None:
        return PastePreview(
            periods=[],
            scale=scale,
            rows=[],
            unmatched=0,
            warnings=["No period headers found (e.g. 2025, FY24, H1 2026). Include the header row when copying."],
        )
    label_col = min(period_cols) - 1 if min(period_cols) > 0 else None
    if label_col is None:
        warnings.append("Period headers start in the first column; labels are expected to their left.")
    periods = [period_cols[j] for j in sorted(period_cols)]
    seen_keys = [p.key for p in periods]
    if len(set(seen_keys)) != len(seen_keys):
        warnings.append("Two columns resolve to the same period; check the header row.")

    rows: list[PastedRow] = []
    unmatched = 0
    for cells in grid[header_index + 1 :]:
        label = cells[label_col].strip() if label_col is not None and label_col < len(cells) else ""
        if not label:
            label = next((c.strip() for c in cells if c.strip() and parse_number(c).value is None), "")
        values: dict[str, float | None] = {}
        ambiguous = False
        for j, period in period_cols.items():
            cell = cells[j] if j < len(cells) else ""
            parsed = parse_number(cell, decimal_hint=decimal_hint)
            values[period.key] = parsed.value
            ambiguous = ambiguous or parsed.ambiguous
        if not label and all(v is None for v in values.values()):
            continue
        if all(v is None for v in values.values()):
            scale = scale or detect_scale(label)
            continue  # section heading such as "Assets" or "in EUR m"
        candidates = taxonomy.match_label(label) if label else []
        if not candidates:
            unmatched += 1
        rows.append(
            PastedRow(
                label=label,
                values=values,
                candidates=candidates,
                concept_id=candidates[0] if len(candidates) == 1 else None,
                raw_cells=cells,
                ambiguous_numbers=ambiguous,
            )
        )
    if scale is None:
        warnings.append("No unit statement found (e.g. 'in thousands', 'EUR m'); choose the unit before importing.")
    if any(r.ambiguous_numbers for r in rows):
        warnings.append("Some numbers such as '1.234' could use either decimal convention; choose the separator.")
    return PastePreview(periods=periods, scale=scale, rows=rows, unmatched=unmatched, warnings=warnings)
