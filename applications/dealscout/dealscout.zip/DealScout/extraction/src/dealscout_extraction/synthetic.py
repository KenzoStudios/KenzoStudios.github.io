"""Synthetic test documents (fictional companies) built in code, so CI never needs copyrighted files.

They mimic real layouts: unruled statement tables with note columns, multi-line labels, parentheses, scale lines,
German number formats, and a parent-company statement that must be ignored in favour of the consolidated one.
"""

from __future__ import annotations

import io

import pymupdf


def _statement_page(
    page: pymupdf.Page,
    title: str,
    subtitle: str,
    header: list[str],
    rows: list[tuple[str, str, list[str]]],
    *,
    note_col: bool = True,
    x_cols: tuple[float, ...] = (430, 520),
) -> None:
    y = 60
    page.insert_text((50, y), title, fontsize=13)
    y += 18
    page.insert_text((50, y), subtitle, fontsize=9)
    y += 30
    if note_col:
        page.insert_text((330, y), "Note", fontsize=9)
    for x, text in zip(x_cols, header, strict=True):
        page.insert_text((x - pymupdf.get_text_length(text, fontsize=9), y), text, fontsize=9)
    y += 20
    for label, note, values in rows:
        page.insert_text((50, y), label, fontsize=9)
        if note_col and note:
            page.insert_text((335, y), note, fontsize=9)
        for x, text in zip(x_cols, values, strict=True):
            if text:
                page.insert_text((x - pymupdf.get_text_length(text, fontsize=9), y), text, fontsize=9)
        y += 15


def english_annual_report(sga_label: str = "Selling, general and administrative") -> bytes:
    """A small fictional IFRS annual report in EUR millions with consolidated and parent-company statements."""
    doc = pymupdf.open()
    cover = doc.new_page()
    cover.insert_text((50, 100), "Fjordline Industrial Group plc — Annual Report 2025", fontsize=16)
    cover.insert_text((50, 130), "A fictional company used for DealScout tests.", fontsize=10)
    _statement_page(
        doc.new_page(),
        "Consolidated income statement",
        "for the year ended 31 December 2025 · € million",
        ["2025", "2024"],
        [
            ("Revenue", "4", ["1,250.4", "1,102.7"]),
            ("Cost of sales", "", ["(812.3)", "(720.1)"]),
            ("Gross profit", "", ["438.1", "382.6"]),
            (sga_label, "", ["(201.5)", "(188.0)"]),
            ("expenses", "", ["", ""]),
            ("Operating profit", "", ["236.6", "194.6"]),
            ("Finance costs", "8", ["(22.4)", "(25.0)"]),
            ("Profit before tax", "", ["214.2", "169.6"]),
            ("Income tax expense", "9", ["(53.6)", "(42.4)"]),
            ("Profit for the year", "", ["160.6", "127.2"]),
        ],
    )
    _statement_page(
        doc.new_page(),
        "Consolidated statement of financial position",
        "at 31 December 2025 · € million",
        ["2025", "2024"],
        [
            ("Property, plant and equipment", "12", ["640.0", "602.5"]),
            ("Goodwill", "13", ["120.0", "120.0"]),
            ("Inventories", "", ["210.4", "198.0"]),
            ("Trade and other receivables", "", ["260.1", "241.7"]),
            ("Cash and cash equivalents", "", ["145.5", "98.8"]),
            ("Total assets", "", ["1,376.0", "1,261.0"]),
            ("Trade and other payables", "", ["(190.0)", "(176.3)"]),
            ("Borrowings", "", ["(300.0)", "(320.0)"]),
            ("Provisions", "", ["(130.0)", "(113.7)"]),
            ("Total liabilities", "", ["(620.0)", "(610.0)"]),
            ("Total equity", "", ["756.0", "651.0"]),
            ("Total liabilities and equity", "", ["1,376.0", "1,261.0"]),
        ],
    )
    _statement_page(
        doc.new_page(),
        "Consolidated statement of cash flows",
        "for the year ended 31 December 2025 · € million",
        ["2025", "2024"],
        [
            ("Profit for the year", "", ["160.6", "127.2"]),
            ("Depreciation and amortisation", "", ["55.0", "51.2"]),
            ("Net cash from operating activities", "", ["228.3", "190.4"]),
            ("Purchase of property, plant and equipment", "", ["(93.0)", "(80.1)"]),
            ("Net cash used in investing activities", "", ["(95.1)", "(82.0)"]),
            ("Net cash used in financing activities", "", ["(86.5)", "(70.2)"]),
            ("Net increase in cash and cash equivalents", "", ["46.7", "38.2"]),
        ],
    )
    _statement_page(
        doc.new_page(),
        "Company balance sheet (parent company)",
        "at 31 December 2025 · € million",
        ["2025", "2024"],
        [
            ("Investments in subsidiaries", "", ["900.0", "900.0"]),
            ("Cash and cash equivalents", "", ["1.2", "0.9"]),
            ("Total assets", "", ["901.2", "900.9"]),
            ("Total equity", "", ["850.0", "849.0"]),
        ],
    )
    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def german_annual_report() -> bytes:
    """A fictional German Konzernabschluss in Tsd. EUR with German number formats."""
    doc = pymupdf.open()
    _statement_page(
        doc.new_page(),
        "Konzern-Gewinn- und Verlustrechnung",
        "für das Geschäftsjahr 2025 · in Tsd. EUR",
        ["2025", "2024"],
        [
            ("Umsatzerlöse", "1", ["84.512", "79.004"]),
            ("Materialaufwand", "", ["-40.110", "-38.020"]),
            ("Personalaufwand", "", ["-25.300", "-24.100"]),
            ("Abschreibungen", "", ["-4.250", "-4.010"]),
            ("Sonstige betriebliche Aufwendungen", "", ["-6.900", "-6.500"]),
            ("Betriebsergebnis", "", ["7.952", "6.374"]),
            ("Zinsen und ähnliche Aufwendungen", "", ["-1.020", "-1.100"]),
            ("Ergebnis vor Steuern", "", ["6.932", "5.274"]),
            ("Steuern vom Einkommen und vom Ertrag", "", ["-2.010", "-1.530"]),
            ("Jahresüberschuss", "", ["4.922", "3.744"]),
        ],
        note_col=True,
    )
    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def management_accounts_xlsx() -> bytes:
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    assert ws is not None
    ws.title = "P&L"
    ws.append(["Fictional Co — management accounts", None, None])
    ws.append(["USD thousands", None, None])
    ws.append(["Line", "FY24", "FY25"])
    for row in [
        ("Net sales", 50_210, 55_870),
        ("Cost of goods sold", -30_100, -33_250),
        ("EBITDA", 9_850, 11_020),
        ("Depreciation and amortization", -2_000, -2_150),
        ("Operating income", 7_850, 8_870),
    ]:
        ws.append(list(row))
    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()


# ── layouts found in real filings (fictional figures) ──────────────────────────
def _rendered_width(text: str, font: str) -> float:
    """Width as drawn (built-in CJK fonts report metrics that differ from what they render)."""
    scratch = pymupdf.open()
    page = scratch.new_page()
    page.insert_text((0, 50), text, fontsize=9, fontname=font)
    words = page.get_text("words")
    return max(w[2] for w in words) - min(w[0] for w in words) if words else 0.0


def _text(page: pymupdf.Page, x: float, y: float, text: str, *, right: bool = False, font: str = "helv") -> None:
    width = 0.0
    if right:
        width = (
            pymupdf.get_text_length(text, fontsize=9, fontname=font) if font == "helv" else _rendered_width(text, font)
        )
    page.insert_text((x - width if right else x, y), text, fontsize=9, fontname=font)


def hgb_spread_report() -> bytes:
    """A German HGB report printed as two-page spreads (A3 landscape): the income statement in the two-level
    layout (sub-items in a detail column, the parent total on the last sub-item's line) on the left page and a
    DRS 21 cash flow statement with sign markers on the right page. Figures in TEUR."""
    doc = pymupdf.open()
    cover = doc.new_page()
    cover.insert_text((50, 100), "Wendeltal Antriebe GmbH - Geschäftsbericht 2025", fontsize=16)
    page = doc.new_page(width=1191, height=842)
    _text(page, 40, 24, "Geschäftsbericht 2025")
    _text(page, 1150, 24, "Geschäftsbericht 2025", right=True)
    _text(page, 40, 70, "KONZERN-GEWINN- UND VERLUSTRECHNUNG")
    _text(page, 40, 86, "(in TEUR)")
    _text(page, 420, 110, "1. 1.-31. 12. 2025", right=True)
    _text(page, 560, 110, "1. 1.-31. 12. 2024", right=True)
    gv = [
        ("1.", "Umsatzerlöse", "", "512.300", "", "488.120"),
        ("2.", "Sonstige betriebliche Erträge", "", "9.410", "", "8.775"),
        ("3.", "Materialaufwand", None, None, None, None),
        ("", "a) Aufwendungen für Roh-, Hilfs- und Betriebsstoffe", "201.330", "", "190.880", ""),
        ("", "b) Aufwendungen für bezogene Leistungen", "64.270", "265.600", "61.020", "251.900"),
        ("4.", "Personalaufwand", None, None, None, None),
        ("", "a) Löhne und Gehälter", "130.150", "", "126.400", ""),
        ("", "b) Soziale Abgaben", "27.350", "157.500", "26.100", "152.500"),
        ("5.", "Abschreibungen", "", "14.210", "", "13.880"),
        ("6.", "Sonstige betriebliche Aufwendungen", "", "61.400", "", "58.310"),
        ("7.", "Steuern vom Einkommen und vom Ertrag", "", "6.900", "", "6.050"),
        ("8.", "Konzernjahresüberschuss", "", "15.300", "", "14.255"),
    ]
    y = 135.0
    for enum, label, d25, t25, d24, t24 in gv:
        if enum:
            _text(page, 40, y, enum)
        _text(page, 58, y, label)
        for x, value in ((360, d25), (420, t25), (500, d24), (560, t24)):
            if value:
                _text(page, x, y, value, right=True)
        y += 15
    _text(page, 640, 70, "KONZERN-KAPITALFLUSSRECHNUNG")
    _text(page, 640, 86, "(in TEUR)")
    _text(page, 1060, 110, "1. 1.-31. 12. 2025", right=True)
    _text(page, 1150, 110, "1. 1.-31. 12. 2024", right=True)
    cf = [
        ("", "Konzernjahresüberschuss", "15.300", "14.255"),
        ("+", "Abschreibungen auf Gegenstände des Anlagevermögens", "14.210", "13.880"),
        ("-", "Zunahme der Vorräte", "-4.120", "-2.300"),
        ("=", "Cashflow aus der laufenden Geschäftstätigkeit", "25.390", "25.835"),
        ("-", "Auszahlungen für Investitionen in das Sachanlagevermögen", "-11.870", "-10.420"),
        ("=", "Cashflow aus der Investitionstätigkeit", "-11.870", "-10.420"),
        ("", "Finanzmittelfonds am Ende der Periode", "48.210", "34.690"),
    ]
    y = 135.0
    for sign, label, v25, v24 in cf:
        if sign:
            _text(page, 640, y, sign)
        _text(page, 655, y, label)
        _text(page, 1060, y, v25, right=True)
        _text(page, 1150, y, v24, right=True)
        y += 15
    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()


def japanese_securities_report() -> bytes:
    """A J-GAAP 有価証券報告書 income statement page: prior year on the left, 前/当連結会計年度 headers with
    自…至 dates on two lines, ※ footnote markers fused to figures and △ for negatives. ¥ millions."""
    doc = pymupdf.open()
    cover = doc.new_page()
    cover.insert_text((50, 100), "有価証券報告書", fontsize=16, fontname="japan")
    page = doc.new_page()
    _text(page, 70, 60, "②【連結損益計算書】", font="japan")
    _text(page, 450, 80, "(単位：百万円)", font="japan")
    for right_edge, year, label in ((386, 2024, "前連結会計年度"), (530, 2025, "当連結会計年度")):
        _text(page, right_edge - 10, 100, label, right=True, font="japan")
        _text(page, right_edge, 114, f"(自 {year}年１月１日", right=True, font="japan")
        _text(page, right_edge, 128, f"至 {year}年12月31日)", right=True, font="japan")
    rows = [
        ("売上高", "※１84,210", "※１91,605"),
        ("売上原価", "※２51,330", "※２55,870"),
        ("売上総利益", "32,880", "35,735"),
        ("営業利益", "4,120", "4,980"),
        ("営業外費用", "△310", "△245"),
        ("税金等調整前当期純利益", "3,810", "4,735"),
        ("法人税等合計", "1,190", "1,470"),
        ("当期純利益", "2,620", "3,265"),
    ]
    y = 150.0
    for label, prior, current in rows:
        _text(page, 51, y, label, font="japan")
        _text(page, 386, y, prior, right=True, font="japan")
        _text(page, 530, y, current, right=True, font="japan")
        y += 14
    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()


def landscape_report() -> bytes:
    """Landscape single pages (not spreads): an income statement whose labels sit far from the figures, and a
    cash flow statement set in two columns with a repeated 2025/2024 header. £000."""
    doc = pymupdf.open()
    cover = doc.new_page(width=842, height=595)
    cover.insert_text((50, 100), "Harrowgate Listings plc - Annual report and accounts 2025", fontsize=16)
    page = doc.new_page(width=842, height=595)
    _text(page, 50, 60, "Consolidated statement of comprehensive income")
    _text(page, 50, 76, "for the year ended 31 December 2025")
    for x, text in ((741, "2025"), (786, "2024")):
        _text(page, x, 100, text, right=True)
        _text(page, x, 112, "£000", right=True)
    income = [
        ("Revenue", "88,412", "80,170"),
        ("Administrative expenses", "(31,240)", "(29,905)"),
        ("Operating profit", "57,172", "50,265"),
        ("Income tax expense", "(14,290)", "(12,560)"),
        ("Profit for the year being total comprehensive income", "42,882", "37,705"),
    ]
    y = 130.0
    for label, v25, v24 in income:
        _text(page, 50, y, label)
        _text(page, 741, y, v25, right=True)
        _text(page, 786, y, v24, right=True)
        y += 15
    page = doc.new_page(width=842, height=595)
    _text(page, 50, 60, "Consolidated statement of cash flows")
    _text(page, 50, 76, "for the year ended 31 December 2025")
    for x, text in ((366, "2025"), (412, "2024"), (743, "2025"), (789, "2024")):
        _text(page, x, 100, text, right=True)
        _text(page, x, 112, "£000", right=True)
    left = [
        ("Profit for the year", "42,882", "37,705"),
        ("Depreciation", "1,210", "1,105"),
        ("Income tax expense", "14,290", "12,560"),
        ("Net cash from operating activities", "51,906", "47,330"),
        ("Acquisition of property, plant and equipment", "(612)", "(540)"),
        ("Acquisition of intangible assets", "(2,105)", "(1,880)"),
    ]
    right = [
        ("Dividends paid", "(18,400)", "(16,200)"),
        ("Purchase of own shares", "(25,010)", "(22,300)"),
        ("Net cash used in financing activities", "(43,410)", "(38,500)"),
        ("Cash and cash equivalents at 31 December", "9,214", "3,435"),
    ]
    for rows, x_label, xs in ((left, 50, (366, 412)), (right, 430, (743, 789))):
        y = 130.0
        for label, v25, v24 in rows:
            _text(page, x_label, y, label)
            _text(page, xs[0], y, v25, right=True)
            _text(page, xs[1], y, v24, right=True)
            y += 15
    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()


# ── tagged filings (fictional) ───────────────────────────────────────────────────
def _ixbrl_body(facts: str, contexts: str, *, extra_ns: str = "") -> bytes:
    return f"""<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:ix="http://www.xbrl.org/2013/inlineXBRL"
 xmlns:ixt="http://www.xbrl.org/inlineXBRL/transformation/2020-02-12" xmlns:xbrli="http://www.xbrl.org/2003/instance"
 xmlns:xbrldi="http://xbrl.org/2006/xbrldi" xmlns:iso4217="http://www.xbrl.org/2003/iso4217"
 xmlns:us-gaap="http://fasb.org/us-gaap/2025" xmlns:dei="http://xbrl.sec.gov/dei/2025"
 xmlns:ifrs-full="https://xbrl.ifrs.org/taxonomy/2025-03-27/ifrs-full" xmlns:acme="http://acme.example/2025" {extra_ns}>
<head><title>Tagged report</title><script>alert('x')</script></head><body>
<div style="display:none"><ix:header><ix:hidden>{facts.split("<!--visible-->")[0]}</ix:hidden><ix:resources>
<xbrli:unit id="usd"><xbrli:measure>iso4217:USD</xbrli:measure></xbrli:unit>
<xbrli:unit id="eur"><xbrli:measure>iso4217:EUR</xbrli:measure></xbrli:unit>
<xbrli:unit id="shares"><xbrli:measure>xbrli:shares</xbrli:measure></xbrli:unit>
{contexts}</ix:resources></ix:header></div>
{facts.split("<!--visible-->")[1] if "<!--visible-->" in facts else ""}
</body></html>""".encode()


def _ctx(
    cid: str, *, start: str | None = None, end: str | None = None, instant: str | None = None, dim: bool = False
) -> str:
    period = (
        f"<xbrli:instant>{instant}</xbrli:instant>"
        if instant
        else f"<xbrli:startDate>{start}</xbrli:startDate><xbrli:endDate>{end}</xbrli:endDate>"
    )
    segment = (
        '<xbrli:segment><xbrldi:explicitMember dimension="us-gaap:StatementBusinessSegmentsAxis">'
        "acme:WestMember</xbrldi:explicitMember></xbrli:segment>"
        if dim
        else ""
    )
    return (
        f'<xbrli:context id="{cid}"><xbrli:entity><xbrli:identifier scheme="http://www.sec.gov/CIK">0000000001'
        f"</xbrli:identifier>{segment}</xbrli:entity><xbrli:period>{period}</xbrli:period></xbrli:context>"
    )


def sec_retailer_10k() -> bytes:
    """A fictional retailer's 10-K: fiscal 2025 ends 31 January 2026 (the filing calls it fiscal 2025)."""
    contexts = "".join(
        [
            _ctx("d25", start="2025-02-02", end="2026-01-31"),
            _ctx("d24", start="2024-02-04", end="2025-02-01"),
            _ctx("i25", instant="2026-01-31"),
            _ctx("i24", instant="2025-02-01"),
            _ctx("cover", instant="2026-03-10"),
            _ctx("d25west", start="2025-02-02", end="2026-01-31", dim=True),
        ]
    )
    nf = 'ix:nonFraction unitRef="usd" decimals="-6" scale="6" format="ixt:num-dot-decimal"'
    facts = f"""
<ix:nonNumeric name="dei:DocumentType" contextRef="d25">10-K</ix:nonNumeric>
<ix:nonNumeric name="dei:DocumentFiscalYearFocus" contextRef="d25">2025</ix:nonNumeric>
<ix:nonNumeric name="dei:DocumentPeriodEndDate" contextRef="d25">January 31, 2026</ix:nonNumeric>
<ix:nonNumeric name="dei:CurrentFiscalYearEndDate" contextRef="d25">--01-31</ix:nonNumeric>
<ix:nonNumeric name="dei:EntityRegistrantName" contextRef="d25">Brightmart Stores, Inc.</ix:nonNumeric>
<ix:nonFraction name="dei:EntityCommonStockSharesOutstanding" contextRef="cover" unitRef="shares" decimals="INF" format="ixt:num-dot-decimal">412,005,331</ix:nonFraction>
<!--visible-->
<table id="is">
<tr><td></td><td>Fiscal 2025</td><td></td><td>Fiscal 2024</td></tr>
<tr><td>Net sales</td><td>$</td><td><{nf} name="us-gaap:Revenues" contextRef="d25" id="f1">12,480.5</ix:nonFraction></td><td>$</td><td><{nf} name="us-gaap:Revenues" contextRef="d24" id="f2">11,902.0</ix:nonFraction></td></tr>
<tr><td>Cost of sales</td><td></td><td><{nf} name="us-gaap:CostOfRevenue" contextRef="d25" id="f3">8,105.2</ix:nonFraction></td><td></td><td><{nf} name="us-gaap:CostOfRevenue" contextRef="d24" id="f4">7,750.9</ix:nonFraction></td></tr>
<tr><td>Operating income</td><td></td><td><{nf} name="us-gaap:OperatingIncomeLoss" contextRef="d25" id="f5">912.4</ix:nonFraction></td><td></td><td><{nf} name="us-gaap:OperatingIncomeLoss" contextRef="d24" id="f6">850.0</ix:nonFraction></td></tr>
<tr><td>Net income (loss)</td><td></td><td>(<{nf} name="us-gaap:ProfitLoss" contextRef="d25" id="f7" sign="-">35.0</ix:nonFraction>)</td><td></td><td><{nf} name="us-gaap:ProfitLoss" contextRef="d24" id="f8">410.3</ix:nonFraction></td></tr>
<tr><td>Restructuring (West segment)</td><td></td><td><{nf} name="us-gaap:Revenues" contextRef="d25west" id="f9">5,000.0</ix:nonFraction></td></tr>
<tr><td>Store pre-opening costs</td><td></td><td><{nf} name="acme:StorePreopeningCosts" contextRef="d25" id="f10">22.1</ix:nonFraction></td><td></td><td><{nf} name="acme:StorePreopeningCosts" contextRef="d24" id="f11">18.4</ix:nonFraction></td></tr>
</table>
<table id="bs">
<tr><td></td><td>January 31, 2026</td><td>February 1, 2025</td></tr>
<tr><td>Cash and cash equivalents</td><td><{nf} name="us-gaap:CashAndCashEquivalentsAtCarryingValue" contextRef="i25" id="f12">640.0</ix:nonFraction></td><td><{nf} name="us-gaap:CashAndCashEquivalentsAtCarryingValue" contextRef="i24" id="f13">588.1</ix:nonFraction></td></tr>
<tr><td>Total assets</td><td><{nf} name="us-gaap:Assets" contextRef="i25" id="f14">9,210.0</ix:nonFraction></td><td><{nf} name="us-gaap:Assets" contextRef="i24" id="f15">8,870.4</ix:nonFraction></td></tr>
<tr><td>Long-term debt</td><td><{nf} name="us-gaap:LongTermDebtNoncurrent" contextRef="i25" id="f16">1,500.0</ix:nonFraction></td><td><ix:nonFraction name="us-gaap:LongTermDebtNoncurrent" contextRef="i24" unitRef="usd" decimals="-6" scale="6" format="ixt:fixed-zero" id="f17">—</ix:nonFraction></td></tr>
</table>
<table id="cf">
<tr><td></td><td>Fiscal 2025</td><td>Fiscal 2024</td></tr>
<tr><td>Accounts receivable</td><td><{nf} name="us-gaap:IncreaseDecreaseInAccountsReceivable" contextRef="d25" id="f18">42.0</ix:nonFraction></td><td>(<{nf} name="us-gaap:IncreaseDecreaseInAccountsReceivable" contextRef="d24" id="f19" sign="-">12.5</ix:nonFraction>)</td></tr>
<tr><td>Net cash provided by operating activities</td><td><{nf} name="us-gaap:NetCashProvidedByUsedInOperatingActivities" contextRef="d25" id="f20">1,105.0</ix:nonFraction></td><td><{nf} name="us-gaap:NetCashProvidedByUsedInOperatingActivities" contextRef="d24" id="f21">980.2</ix:nonFraction></td></tr>
<tr><td>Capital expenditures</td><td>(<{nf} name="us-gaap:PaymentsToAcquirePropertyPlantAndEquipment" contextRef="d25" id="f22">455.0</ix:nonFraction>)</td><td>(<{nf} name="us-gaap:PaymentsToAcquirePropertyPlantAndEquipment" contextRef="d24" id="f23">401.6</ix:nonFraction>)</td></tr>
</table>"""
    return _ixbrl_body(facts, contexts)


def esef_package() -> bytes:
    """A fictional French ESEF report package (ZIP) with comma decimals and a company element with a French label."""
    contexts = _ctx("y25", start="2025-01-01", end="2025-12-31") + _ctx("y24", start="2024-01-01", end="2024-12-31")
    contexts += _ctx("e25", instant="2025-12-31") + _ctx("e24", instant="2024-12-31")
    nf = 'ix:nonFraction unitRef="eur" decimals="-3" scale="3" format="ixt:num-comma-decimal"'
    facts = f"""<!--visible-->
<div><p>Compte de résultat consolidé (en milliers d’euros)</p>
<p>Chiffre d’affaires <{nf} name="ifrs-full:RevenueFromContractsWithCustomers" contextRef="y25" id="r25">1 204 310</ix:nonFraction>
 <{nf} name="ifrs-full:RevenueFromContractsWithCustomers" contextRef="y24" id="r24">1 150 002</ix:nonFraction></p>
<p>Résultat net <{nf} name="ifrs-full:ProfitLoss" contextRef="y25" id="p25">88 412,5</ix:nonFraction></p>
<p>Total de l’actif <{nf} name="ifrs-full:Assets" contextRef="e25" id="a25">2 010 400</ix:nonFraction></p>
<p>EBITDA <{nf} name="ortel:EBITDA" contextRef="y25" id="x25">212 050</ix:nonFraction></p>
<p>Charges de restructuration <{nf} name="ortel:ChargesRestructuration" contextRef="y25" id="x26">4 100</ix:nonFraction></p>
</div>"""
    report = _ixbrl_body(facts, contexts, extra_ns='xmlns:ortel="http://ortel.example/2025"')
    labels = """<?xml version="1.0" encoding="utf-8"?>
<link:linkbase xmlns:link="http://www.xbrl.org/2003/linkbase" xmlns:xlink="http://www.w3.org/1999/xlink">
<link:labelLink xlink:type="extended" xlink:role="http://www.xbrl.org/2003/role/link">
<link:loc xlink:type="locator" xlink:href="ortel.xsd#ortel_EBITDA" xlink:label="ortel_EBITDA"/>
<link:label xlink:type="resource" xlink:label="lab_EBITDA" xlink:role="http://www.xbrl.org/2003/role/label" xml:lang="fr">EBITDA</link:label>
<link:labelArc xlink:type="arc" xlink:arcrole="http://www.xbrl.org/2003/arcrole/concept-label" xlink:from="ortel_EBITDA" xlink:to="lab_EBITDA"/>
<link:loc xlink:type="locator" xlink:href="ortel.xsd#ortel_ChargesRestructuration" xlink:label="ortel_ChargesRestructuration"/>
<link:label xlink:type="resource" xlink:label="lab_CR" xlink:role="http://www.xbrl.org/2003/role/label" xml:lang="fr">Charges de restructuration non récurrentes</link:label>
<link:labelArc xlink:type="arc" xlink:arcrole="http://www.xbrl.org/2003/arcrole/concept-label" xlink:from="ortel_ChargesRestructuration" xlink:to="lab_CR"/>
</link:labelLink></link:linkbase>"""
    out = io.BytesIO()
    import zipfile

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("ortel-2025-12-31/META-INF/taxonomyPackage.xml", "<taxonomyPackage/>")
        zf.writestr("ortel-2025-12-31/reports/ortel-2025-12-31-fr.xhtml", report)
        zf.writestr("ortel-2025-12-31/www.ortel.example/ortel_lab-fr.xml", labels)
    return out.getvalue()


def xbrl_instance() -> bytes:
    """A classic (non-inline) XBRL instance with two facts."""
    return b"""<?xml version="1.0" encoding="utf-8"?>
<xbrli:xbrl xmlns:xbrli="http://www.xbrl.org/2003/instance" xmlns:iso4217="http://www.xbrl.org/2003/iso4217"
 xmlns:ifrs-full="https://xbrl.ifrs.org/taxonomy/2025-03-27/ifrs-full">
<xbrli:context id="y25"><xbrli:entity><xbrli:identifier scheme="x">1</xbrli:identifier></xbrli:entity>
<xbrli:period><xbrli:startDate>2025-01-01</xbrli:startDate><xbrli:endDate>2025-12-31</xbrli:endDate></xbrli:period></xbrli:context>
<xbrli:unit id="eur"><xbrli:measure>iso4217:EUR</xbrli:measure></xbrli:unit>
<ifrs-full:Revenue contextRef="y25" unitRef="eur" decimals="0">5400000</ifrs-full:Revenue>
<ifrs-full:ProfitLoss contextRef="y25" unitRef="eur" decimals="0">-120000</ifrs-full:ProfitLoss>
</xbrli:xbrl>"""


def word_statements_docx() -> bytes:
    """Management accounts in Word: an income statement table with a split-cell figure."""
    from docx import Document as WordDocument

    word = WordDocument()
    word.add_paragraph("Fictional Holdings Ltd — management accounts, income statement (£000)")
    table = word.add_table(rows=5, cols=4)
    rows = [
        ["", "FY2025", "", "FY2024"],
        ["Revenue", "4,210", "", "3,980"],
        ["Cost of sales", "(2,105)", "", "(1,990)"],
        ["Gross profit", "2,105", "", "1,990"],
        ["Operating profit", "612", "", "540"],
    ]
    for r, values in enumerate(rows):
        for c, value in enumerate(values):
            table.cell(r, c).text = value
    out = io.BytesIO()
    word.save(out)
    return out.getvalue()


def scanned_annual_report() -> bytes:
    """The English annual report as a scan: every page an image, no text layer."""
    text_pdf = pymupdf.open(stream=english_annual_report(), filetype="pdf")
    scan = pymupdf.open()
    for index in range(text_pdf.page_count):
        page = text_pdf[index]
        pix = page.get_pixmap(dpi=100)
        new_page = scan.new_page(width=page.rect.width, height=page.rect.height)
        new_page.insert_image(new_page.rect, stream=pix.tobytes("png"))
    out = io.BytesIO()
    scan.save(out)
    return out.getvalue()


def _prose_page(doc: pymupdf.Document, title: str, paragraphs: list[str]) -> None:
    page = doc.new_page()
    page.insert_text((50, 70), title, fontsize=13)
    y = 95.0
    for text in paragraphs:
        rect = pymupdf.Rect(50, y, 545, y + 140)
        page.insert_textbox(rect, text, fontsize=10)
        y += 150


def warning_signs_report() -> bytes:
    """A fictional English annual report whose narrative carries text-based warning signs (and clean boilerplate)."""
    doc = pymupdf.open()
    _prose_page(
        doc,
        "Halvard Components Ltd: Annual Report 2025",
        [
            "Report for the year ended 31 December 2025. A fictional company used for DealScout tests.",
            "Our largest customer accounted for 34% of revenue in 2025 (2024: 29%). No other customer accounted for "
            "more than 10% of revenue.",
        ],
    )
    _prose_page(
        doc,
        "Independent auditor's report",
        [
            "Basis for qualified opinion. We were unable to obtain sufficient appropriate audit evidence about the "
            "carrying amount of inventories held at the Brno warehouse.",
            "Material uncertainty related to going concern. We draw attention to note 2, which indicates that the "
            "group's revolving facility matures in May 2026 and has not yet been refinanced.",
            "As part of our audit we conclude whether a material uncertainty exists related to events or conditions "
            "that may cast significant doubt on the group's ability to continue as a going concern.",
        ],
    )
    _prose_page(
        doc,
        "Notes to the financial statements",
        [
            "Note 3 Prior period restatement. The comparative figures for 2024 have been restated to correct an "
            "error in the recognition of tooling revenue.",
            "Note 24 Related party transactions. During the year the group granted a loan to a director of EUR 1.2 "
            "million. The group leases its head office from a company controlled by the chief executive.",
        ],
    )
    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def clean_report() -> bytes:
    """A fictional annual report with only reassuring wording: no text-based warning sign may fire."""
    doc = pymupdf.open()
    _prose_page(
        doc,
        "Brightwater Foods plc: Annual Report 2025",
        [
            "The directors have a reasonable expectation that the group has adequate resources and there is no "
            "material uncertainty related to going concern.",
            "In our opinion the financial statements give a true and fair view. We have issued an unqualified opinion.",
            "No single customer accounted for more than 10% of revenue. There were no related party transactions "
            "other than remuneration of key management.",
            "The comparative figures have not been restated. There was no change of auditor during the year.",
        ],
    )
    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()
