"""File sniffing, fingerprinting, safety checks and dispatch to format readers (brief §5.1, §15)."""

from __future__ import annotations

import hashlib
import io
import re
import zipfile

from .model import DocKind, DocumentContent

MAX_ZIP_MEMBERS = 500
MAX_ZIP_UNCOMPRESSED = 1024 * 1024 * 1024  # 1 GB guard against zip bombs
MAX_ZIP_RATIO = 200


def sha256(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def sniff_kind(content: bytes, filename: str) -> DocKind:
    """Decide the type from magic bytes first, then the extension. Never trusts the extension alone."""
    name = filename.lower()
    head = content[:8]
    if head.startswith(b"%PDF"):
        return "pdf"
    if head.startswith(b"\x89PNG") or head[:3] == b"\xff\xd8\xff":
        return "image"
    if head.startswith(b"\xd0\xcf\x11\xe0"):  # OLE2 (legacy .xls / .doc)
        return "xls" if name.endswith(".xls") else "unknown"
    if head.startswith(b"PK"):
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as zf:
                names = zf.namelist()
        except zipfile.BadZipFile:
            return "unknown"
        if "[Content_Types].xml" in names:
            if any(n.startswith("xl/") for n in names):
                return "xlsx"
            if any(n.startswith("word/") for n in names):
                return "docx"
        return "zip"
    sample = content[:4096].decode("utf-8", errors="ignore").lower()
    if "<html" in sample or "<!doctype html" in sample or name.endswith((".htm", ".html", ".xhtml")):
        inline = b"xbrl.org/2013/inlineXBRL" in content[:100_000] or b"xbrl.org/2008/inlineXBRL" in content[:100_000]
        return "xbrl" if inline else "html"
    if sample.lstrip().startswith("<?xml") and ("xbrl" in sample or name.endswith(".xbrl")):
        return "xbrl"
    if name.endswith((".csv", ".tsv", ".txt")) or re.search(r"[,;\t].*\n.*[,;\t]", sample):
        return "csv"
    return "unknown"


def check_zip_safety(content: bytes) -> list[str]:
    """Reject archives that could exhaust disk or memory (zip bombs) or that escape their folder."""
    problems: list[str] = []
    with zipfile.ZipFile(io.BytesIO(content)) as zf:
        infos = zf.infolist()
        if len(infos) > MAX_ZIP_MEMBERS:
            problems.append(f"The archive has {len(infos)} files (limit {MAX_ZIP_MEMBERS}).")
        total = sum(i.file_size for i in infos)
        if total > MAX_ZIP_UNCOMPRESSED:
            problems.append("The archive expands to more than 1 GB.")
        for i in infos:
            if i.compress_size and i.file_size / max(i.compress_size, 1) > MAX_ZIP_RATIO and i.file_size > 10_000_000:
                problems.append(f"Suspicious compression ratio in {i.filename}.")
            if i.filename.startswith("/") or ".." in i.filename.split("/"):
                problems.append(f"Unsafe path in archive: {i.filename}")
    return problems


def read_document(content: bytes, filename: str) -> DocumentContent:
    kind = sniff_kind(content, filename)
    if kind == "pdf":
        from .pdf_reader import read_pdf

        return read_pdf(content)
    if kind in ("xlsx", "xls", "csv"):
        from .sheet_reader import read_sheets

        return read_sheets(content, kind)
    if kind == "docx":
        from .html_reader import read_docx

        return read_docx(content)
    if kind == "html":
        from .html_reader import read_html

        return read_html(content)
    if kind == "xbrl":
        return _read_tagged(content, member=None)
    if kind == "zip":
        from .ixbrl import find_report_in_package

        found = find_report_in_package(content)
        if found:
            from .ixbrl import read_package_labels

            doc = _read_tagged(found[1], member=found[0])
            doc.inline.labels = read_package_labels(content)
            return doc
        doc = DocumentContent(kind="zip")
        doc.warnings.append("This archive is not an ESEF report package; its files are added as separate documents.")
        return doc
    if kind == "image":
        from .ocr import read_image

        return read_image(content)
    doc = DocumentContent(kind=kind)
    doc.warnings.append("This file type is not supported. Upload PDF, Excel, CSV, Word, HTML, XBRL or ZIP.")
    return doc


def _read_tagged(content: bytes, *, member: str | None) -> DocumentContent:
    """Inline XBRL (SEC, ESEF): the tagged facts plus the HTML tables; a classic XBRL instance: facts only."""
    from .ixbrl import is_inline_xbrl, read_inline_xbrl, read_xbrl_instance

    if is_inline_xbrl(content):
        from .html_reader import read_html

        doc = read_html(content, kind="xbrl")
        report = read_inline_xbrl(content)
    else:
        doc = DocumentContent(kind="xbrl")
        report = read_xbrl_instance(content)
    report.language = doc.language
    doc.inline = report
    doc.report_member = member
    doc.entity_name = report.entity_name
    doc.currency = report.currency
    doc.warnings += report.warnings
    return doc
