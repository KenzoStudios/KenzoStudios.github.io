"""AI-assisted mapping and targeted extraction, provider-neutral (brief §5.2 steps 5–6, §5.3).

Safeguards that apply to every provider:
- Prompts ask for figures *as printed* with page and label; the model never converts or calculates.
- Every returned figure is **verified**: its printed form must appear on the cited page (or another page that was
  sent). Unverifiable figures are rejected and reported, never stored.
- Numbers are parsed by our own parser with the document's decimal convention and the page's unit statement.
- ``null`` with a reason is a valid answer and is surfaced to the analyst as "not found".
"""

from __future__ import annotations

import io
import re
from dataclasses import dataclass, field

from pydantic import BaseModel, Field

from dealscout_ai import AIProvider, Capabilities, ContentPart, PageImage, PageText, PdfDocument, Usage
from dealscout_engine.taxonomy import Taxonomy, normalise_label

from .mapping import Candidate, UnmappedRow
from .model import DocumentContent
from .numbers import detect_scale, parse_number, parse_period_header

PROMPT_VERSION = "dealscout-extract-2026-11-v1"
TIER_FACTOR = {"high": 1.0, "medium": 0.9, "limited": 0.75, "untested": 0.85}

SYSTEM_EXTRACT = (
    "You help an investment analyst read company financial reports. Rules you must follow:\n"
    "1. Report only figures that are printed on the pages provided. Copy each figure exactly as printed "
    "(value_as_written), with the page number, the line label as printed, and the unit statement that applies "
    "(e.g. 'EUR million', 'in Tsd. EUR', '百万円').\n"
    "2. Never calculate, convert, add up, estimate or infer a number. If a figure is not printed, return "
    "value_as_written null and say why in reason_if_null.\n"
    "3. Prefer consolidated (group) statements over parent-company statements.\n"
    "4. Use the period column header as printed (e.g. '2025', 'FY24', '31.12.2025').\n"
    "5. Confidence is your certainty (0–1) that the figure is the requested item for that period."
)
SYSTEM_MAP = (
    "You map line items from company financial statements to a fixed list of canonical concepts. For each row, "
    "choose the single best concept id from the allowed list, or null when none fits (do not force a match). "
    "Consider the language, the statement and typical accounting labels in that country. Give a short rationale."
)


class AIMappingItem(BaseModel):
    row: int
    concept_id: str | None
    confidence: float = Field(ge=0, le=1)
    rationale: str


class AIMappingResult(BaseModel):
    items: list[AIMappingItem]


class AIValue(BaseModel):
    concept_id: str
    period: str | None
    value_as_written: str | None
    page: int | None
    label: str | None
    unit_scale: str | None
    confidence: float = Field(ge=0, le=1)
    reason_if_null: str | None


class AIExtractionResult(BaseModel):
    values: list[AIValue]


@dataclass
class AIOutcome:
    candidates: list[Candidate] = field(default_factory=list)
    not_found: list[dict[str, str]] = field(default_factory=list)
    rejected: list[dict[str, str]] = field(default_factory=list)
    usage: list[Usage] = field(default_factory=list)
    mapped_rows: list[tuple[UnmappedRow, str, float, str]] = field(default_factory=list)


def _core(value: str) -> str:
    return re.sub(r"[^\d.,]", "", value).strip(".,")


def _page_contains(text: str, value: str) -> bool:
    core = _core(value)
    if not core:
        return False
    squashed = re.sub(r"[\s  ']", "", text)
    return core in squashed


def select_pages(
    doc: DocumentContent,
    taxonomy: Taxonomy,
    concepts: list[str],
    located_pages: set[int],
    *,
    limit: int = 8,
    include_scanned: bool = False,
) -> list[int]:
    """Pages most likely to hold the requested concepts: synonym hits in the page text, plus the statements."""
    scores: dict[int, float] = {}
    # scanned pages without OCR text can only be read from their image; keep a few, after the cover pages
    unread = [p.page for p in doc.pages if p.is_scanned and not p.ocr]
    if unread and include_scanned:
        body = unread[2:] if len(unread) > limit else unread
        for page_number in body[:limit]:
            scores[page_number] = 0.5
    for page in doc.pages:
        if page.is_scanned and not page.ocr:
            continue
        low = page.text.lower()
        score = 0.0
        for concept_id in concepts:
            concept = taxonomy.concept(concept_id)
            for values in concept.synonyms.values():
                if any(len(s) > 4 and s.lower() in low for s in values):
                    score += 1
                    break
        if page.page in located_pages:
            score += 2
        if score:
            scores[page.page] = score
    return sorted(sorted(scores, key=lambda p: scores[p], reverse=True)[:limit])


def build_content(
    original: bytes | None, doc: DocumentContent, pages: list[int], caps: Capabilities
) -> list[ContentPart]:
    """Native PDF slices when supported; else page text with page markers (+ page images when vision is supported)."""
    parts: list[ContentPart] = []
    if caps.native_pdf and doc.kind == "pdf" and original:
        import pymupdf

        source = pymupdf.open(stream=original, filetype="pdf")
        runs: list[list[int]] = []
        for p in pages:
            if runs and p == runs[-1][-1] + 1:
                runs[-1].append(p)
            else:
                runs.append([p])
        for run in runs:
            out = pymupdf.open()
            out.insert_pdf(source, from_page=run[0] - 1, to_page=run[-1] - 1)
            buffer = io.BytesIO()
            out.save(buffer)
            parts.append(
                PdfDocument(data=buffer.getvalue(), first_page=run[0], source_name=f"pages {run[0]}–{run[-1]}")
            )
        return parts
    for p in pages:
        page = doc.page(p)
        if page is None:
            continue
        if page.text.strip():
            parts.append(PageText(page=p, text=page.text, source_name=page.name))
        if caps.image_input and original and doc.kind == "image":
            media = "image/png" if original[:4] == b"\x89PNG" else "image/jpeg"
            parts.append(PageImage(page=p, data=original, media_type=media))
        elif caps.image_input and doc.kind == "pdf" and original:
            import pymupdf

            dpi = 150 if page.is_scanned else 110  # scans need more detail to read
            pix = pymupdf.open(stream=original, filetype="pdf")[p - 1].get_pixmap(dpi=dpi)
            parts.append(PageImage(page=p, data=pix.tobytes("png")))
    return parts


def ai_map_rows(
    provider: AIProvider, unmapped: list[UnmappedRow], taxonomy: Taxonomy, *, tier: str = "untested"
) -> AIOutcome:
    outcome = AIOutcome()
    if not unmapped:
        return outcome
    by_statement: dict[str | None, list[tuple[int, UnmappedRow]]] = {}
    for i, row in enumerate(unmapped[:120]):
        by_statement.setdefault(row.statement, []).append((i, row))
    for statement, rows in by_statement.items():
        allowed = [c for c in taxonomy.concepts if c.statement in (statement, "memo") and c.unit != "schedule"]
        concept_lines = "\n".join(f"- {c.id}: {c.name} — {c.definition[:140]}" for c in allowed)
        row_lines = "\n".join(
            f"{i}. “{row.label}” (page {row.page}; values "
            + ", ".join(f"{k}: {v}" for k, v in list(row.values.items())[:3])
            + ")"
            for i, row in rows
        )
        prompt = (
            f"Statement: {statement}\nAllowed concepts:\n{concept_lines}\n\nRows to map (use the row number):\n"
            f"{row_lines}\n\nReturn one item per row."
        )
        result = provider.extract_structured(
            [PageText(page=0, text=prompt, source_name="rows")],
            AIMappingResult,
            instructions=SYSTEM_MAP,
            max_tokens=8000,
        )
        outcome.usage.append(result.usage)
        allowed_ids = {c.id for c in allowed}
        for item in result.value.items:
            if item.concept_id and item.concept_id in allowed_ids and 0 <= item.row < len(unmapped):
                outcome.mapped_rows.append(
                    (unmapped[item.row], item.concept_id, item.confidence * TIER_FACTOR.get(tier, 0.85), item.rationale)
                )
    return outcome


def ai_extract_missing(
    provider: AIProvider,
    original: bytes | None,
    doc: DocumentContent,
    concepts: list[str],
    taxonomy: Taxonomy,
    *,
    located_pages: set[int],
    page_limit: int = 8,
    tier: str = "untested",
) -> AIOutcome:
    outcome = AIOutcome()
    if not concepts:
        return outcome
    caps = provider.capabilities()
    pages = select_pages(
        doc, taxonomy, concepts, located_pages, limit=page_limit, include_scanned=caps.image_input or caps.native_pdf
    )
    if not pages:
        outcome.not_found = [{"concept_id": c, "reason": "No page mentions this item."} for c in concepts]
        return outcome
    content = build_content(original, doc, pages, provider.capabilities())
    request = "\n".join(f"- {c}: {taxonomy.concept(c).name} — {taxonomy.concept(c).definition[:160]}" for c in concepts)
    content.append(
        PageText(
            page=0,
            source_name="request",
            text=(
                "Find these items for every period column shown (latest and prior year at least):\n"
                + request
                + "\nReturn one entry per item and period; use null with a reason when an item is not printed."
            ),
        )
    )
    result = provider.extract_structured(content, AIExtractionResult, instructions=SYSTEM_EXTRACT, max_tokens=12000)
    outcome.usage.append(result.usage)
    decimal_hint = "," if doc.language in {"de", "es", "fr", "it", "pt", "nl"} else "." if doc.language else None
    seen: set[tuple[str, str]] = set()
    for v in result.value.values:
        if v.concept_id not in concepts:
            continue
        if not v.value_as_written:
            outcome.not_found.append({"concept_id": v.concept_id, "reason": v.reason_if_null or "Not found by the AI."})
            continue
        period = parse_period_header(v.period or "")
        if period is None:
            outcome.rejected.append(
                {
                    "concept_id": v.concept_id,
                    "value": v.value_as_written,
                    "reason": f"Period “{v.period}” not recognised.",
                }
            )
            continue
        cited = v.page if v.page in pages else None
        verified_page = cited if cited and _page_contains(doc.page(cited).text, v.value_as_written) else None  # type: ignore[union-attr]
        if verified_page is None:
            verified_page = next((p for p in pages if _page_contains(doc.page(p).text, v.value_as_written)), None)  # type: ignore[union-attr]
        image_only = False
        if verified_page is None and cited is not None:
            cited_page = doc.page(cited)
            # a scanned page without OCR has no text to check against: accept only the page the AI was shown and
            # cited, at low confidence, flagged for checking against the image
            if cited_page is not None and cited_page.is_scanned and not cited_page.ocr:
                verified_page, image_only = cited, True
        if verified_page is None:
            outcome.rejected.append(
                {
                    "concept_id": v.concept_id,
                    "value": v.value_as_written,
                    "reason": "The figure does not appear on the pages sent; rejected (never invented).",
                }
            )
            continue
        parsed = parse_number(v.value_as_written, decimal_hint=decimal_hint)  # type: ignore[arg-type]
        if parsed.value is None:
            outcome.rejected.append(
                {"concept_id": v.concept_id, "value": v.value_as_written, "reason": "Not a number."}
            )
            continue
        concept = taxonomy.concept(v.concept_id)
        page_text = doc.page(verified_page).text  # type: ignore[union-attr]
        scale = detect_scale(v.unit_scale or "") or detect_scale(page_text[:2000])
        factor = scale.factor if scale and concept.unit == "currency" else 1.0
        value = parsed.value * factor
        if concept.sign == "negative":
            value = -abs(value)
        elif concept.sign == "positive" and value < 0:
            value = abs(value)
        if (v.concept_id, period.key) in seen:
            continue
        seen.add((v.concept_id, period.key))
        notes = [] if scale or concept.unit != "currency" else ["No unit statement found; read as units."]
        if verified_page != v.page:
            notes.append(f"The AI cited page {v.page}; the figure was found on page {verified_page}.")
        if image_only:
            notes.append("Read by the AI from a scanned page image: no text to verify against. Check it on the image.")
        outcome.candidates.append(
            Candidate(
                concept_id=v.concept_id,
                period_key=period.key,
                value=value,
                value_as_written=v.value_as_written,
                label=v.label or concept.name,
                page=verified_page,
                statement=concept.statement,
                method="ai_extraction",
                mapping="ai",
                confidence=round(
                    min(
                        min(v.confidence, 0.9) * TIER_FACTOR.get(tier, 0.85) * (0.8 if notes else 1),
                        0.5 if image_only else 1.0,
                    ),
                    3,
                ),
                scale_factor=factor,
                scale_label=scale.label if scale else None,
                rationale=(
                    f"AI read “{v.label or concept.name}” = {v.value_as_written} ({v.unit_scale or 'unit not stated'})."
                ),
                notes=notes,
            )
        )
    return outcome


def candidate_from_ai_mapping(
    doc: DocumentContent, row: UnmappedRow, concept_id: str, confidence: float, rationale: str, taxonomy: Taxonomy
) -> list[Candidate]:
    """Turn an AI-mapped table row back into values, reading the numbers from the table (not from the AI)."""
    if row.table_index < 0:  # a company-specific tagged element: numbers come from its facts
        return _candidates_from_tagged_row(doc, row, concept_id, confidence, rationale, taxonomy)
    table = doc.tables[row.table_index]
    source_row = table.rows[row.row_index]
    concept = taxonomy.concept(concept_id)
    out: list[Candidate] = []
    for column in table.columns:
        cell = source_row.cells.get(column.key)
        if column.period is None or column.period.kind == "projection" or cell is None or cell.value is None:
            continue
        factor = table.scale.factor if table.scale and concept.unit == "currency" else 1.0
        value = cell.value * factor
        if concept.sign == "negative":
            value = -abs(value)
        elif concept.sign == "positive" and value < 0:
            value = abs(value)
        out.append(
            Candidate(
                concept_id=concept_id,
                period_key=column.period.key,
                value=value,
                value_as_written=cell.raw,
                label=source_row.label,
                page=table.page,
                statement=row.statement,
                method="ai_mapping",
                mapping="ai",
                confidence=round(0.85 * confidence, 3),
                bbox=cell.bbox,
                cell_ref=cell.ref,
                sheet=table.sheet,
                scale_factor=factor,
                scale_label=table.scale.label if table.scale else None,
                rationale=f"AI mapped “{source_row.label}” to {concept.name}: {rationale}",
            )
        )
    return out


def normalised(label: str) -> str:
    return normalise_label(label)


def _candidates_from_tagged_row(
    doc: DocumentContent, row: UnmappedRow, concept_id: str, confidence: float, rationale: str, taxonomy: Taxonomy
) -> list[Candidate]:
    from .numbers import parse_number
    from .pdf_reader import DECIMAL_COMMA_LANGUAGES

    concept = taxonomy.concept(concept_id)
    hint = "," if doc.language in DECIMAL_COMMA_LANGUAGES else "."
    out: list[Candidate] = []
    for period_key, raw in row.values.items():
        number = parse_number(raw, decimal_hint=hint).value  # type: ignore[arg-type]
        if number is None:
            continue
        value = number * (row.scale_factor or 1.0)
        if concept.sign == "negative":
            value = -abs(value)
        out.append(
            Candidate(
                concept_id=concept_id,
                period_key=period_key,
                value=value,
                value_as_written=raw,
                label=row.label,
                page=0,
                statement=row.statement or concept.statement,
                method="ai_mapping",
                mapping="ai",
                confidence=round(0.9 * confidence, 3),
                scale_factor=row.scale_factor or 1.0,
                rationale=rationale,
                notes=["Company-specific tagged element; the figure is the tagged value, the mapping is the AI's."],
            )
        )
    return out
