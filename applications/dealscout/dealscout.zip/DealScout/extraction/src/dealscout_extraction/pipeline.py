"""End-to-end extraction of one document: read → locate → map → AI (optional) → candidates for review.

Nothing here writes to a database: the API job stores the output and the analyst reviews every value.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field

from dealscout_ai import AIProvider, Usage
from dealscout_engine.taxonomy import Taxonomy

from .ai_extract import ai_extract_missing, ai_map_rows, candidate_from_ai_mapping
from .ingest import read_document
from .locate import LocatedTable, locate_statements
from .mapping import Candidate, UnmappedRow, adjust_for_reconciliation, map_located
from .model import DocumentContent

CORE_CONCEPTS = [
    "revenue",
    "ebit",
    "da_total",
    "net_income",
    "total_assets",
    "cash",
    "st_debt",
    "lt_debt",
    "total_equity",
    "cfo",
    "capex",
    "shares_outstanding",
    "interest_expense",
    "income_tax",
]
DOC_TYPES = [
    (
        "interim_report",
        r"interim|half[- ]year|quarterly|halbjahres|quartals|semestral|trimestral|semestriel|四半期|半期",
    ),
    (
        "annual_report",
        r"annual report|geschäftsbericht|informe anual|rapport annuel|relazione finanziaria annuale|"
        r"有価証券報告書|integrated report|10-k|annual financial report",
    ),
    (
        "audited_accounts",
        r"cuentas anuales|jahresabschluss|consolidated financial statements|comptes consolidés|"
        r"bilancio consolidato|independent auditor",
    ),
    ("management_accounts", r"management accounts|management report|monthly report|budget|forecast"),
    ("investor_presentation", r"investor presentation|capital markets day|earnings presentation"),
    ("prospectus", r"prospectus|offering memorandum"),
]

Progress = Callable[[str, str], None]


@dataclass
class ExtractionOutput:
    doc: DocumentContent
    located: dict[str, list[LocatedTable]]
    candidates: list[Candidate]
    unmapped: list[UnmappedRow]
    not_found: list[dict[str, str]] = field(default_factory=list)
    rejected: list[dict[str, str]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    usage: list[Usage] = field(default_factory=list)
    doc_type: str = "other"
    periods: list[str] = field(default_factory=list)
    ai_used: bool = False


_FILING_TYPES = {
    "10-K": "annual_report",
    "20-F": "annual_report",
    "40-F": "annual_report",
    "10-Q": "interim_report",
    "6-K": "interim_report",
    "10-KT": "annual_report",
}


def classify(doc: DocumentContent) -> str:
    """The document type with the strongest evidence in the opening pages; the cover page counts three times.

    An annual report that mentions its half-year results must still be an annual report.
    """
    if doc.inline is not None:
        filing = (doc.inline.document_type or "").upper()
        if filing in _FILING_TYPES:
            return _FILING_TYPES[filing]
        if doc.report_member:  # ESEF report packages are annual financial reports
            return "annual_report"
    cover = " ".join(p.text[:3000] for p in doc.pages[:1]).lower()
    sample = " ".join(p.text[:3000] for p in doc.pages[:5]).lower()
    scores = {
        doc_type: 3 * len(re.findall(pattern, cover)) + len(re.findall(pattern, sample))
        for doc_type, pattern in DOC_TYPES
    }
    best = max(scores, key=lambda k: scores[k])
    return best if scores[best] else "other"


def extract_rules(
    content: bytes, filename: str, taxonomy: Taxonomy, *, progress: Progress | None = None
) -> ExtractionOutput:
    """Read, locate and map with the dictionary only (no AI). Always runs; results are stored before any AI call."""

    def step(name: str, detail: str) -> None:
        if progress:
            progress(name, detail)

    doc = read_document(content, filename)
    step(
        "read",
        f"{doc.kind.upper()}, {doc.page_count} page(s), {len(doc.tables)} table(s) found"
        + (f", language {doc.language}" if doc.language else ""),
    )
    if doc.inline is not None:
        from .ixbrl import align_tables

        align_tables(doc, doc.inline)
    located = locate_by_tags(doc, taxonomy) if doc.inline is not None else locate_statements(doc, taxonomy)
    step(
        "locate",
        "; ".join(f"{k.replace('_', ' ')}: p. {', '.join(str(t.page) for t in v)}" for k, v in located.items())
        or "No primary statements recognised",
    )
    candidates, unmapped, warnings = map_located(doc, located, taxonomy)
    if doc.inline is not None:
        # structured data first (brief §5.2 step 2): tagged facts win; tables only fill cells nothing tagged
        from .ixbrl import facts_to_candidates

        tagged, tagged_unmapped, tagged_warnings = facts_to_candidates(doc.inline, taxonomy)
        covered = {(c.concept_id, c.period_key) for c in tagged}
        candidates = tagged + [c for c in candidates if (c.concept_id, c.period_key) not in covered]
        unmapped = tagged_unmapped  # table rows of a tagged filing repeat its facts; extensions are listed instead
        warnings = [w for w in warnings if "no unit statement" not in w] + tagged_warnings
    adjust_for_reconciliation(candidates, taxonomy)
    step("map", f"{len(candidates)} values mapped, {len(unmapped)} rows not recognised")
    out = ExtractionOutput(
        doc=doc,
        located=located,
        candidates=candidates,
        unmapped=unmapped,
        warnings=doc.warnings + warnings,
        doc_type=classify(doc),
    )
    out.periods = sorted({c.period_key for c in out.candidates})
    return out


def locate_by_tags(doc: DocumentContent, taxonomy: Taxonomy) -> dict[str, list[LocatedTable]]:
    """In a tagged filing the statement tables are the ones holding the statement's tagged facts.

    Each table votes for the statement most of its mapped tags belong to; a statement keeps its tables with at
    least three such tags, best first (balance sheets often span an assets table and a liabilities table).
    """
    index = taxonomy.xbrl_index()
    prefixes = {"us-gaap": "us-gaap", "ifrs-full": "ifrs-full"}
    votes: dict[str, list[LocatedTable]] = {}
    for t_index, table in enumerate(doc.tables):
        counts: dict[str, int] = {}
        for name in set(table.tags):
            prefix, _, local = name.partition(":")
            concept_id = index.get(f"{prefixes.get(prefix, prefix)}:{local}")
            if concept_id is None:
                continue
            statement = taxonomy.concept(concept_id).statement
            if statement in ("income_statement", "balance_sheet", "cash_flow"):
                counts[statement] = counts.get(statement, 0) + 1
        if not counts:
            continue
        winner, count = max(counts.items(), key=lambda kv: kv[1])
        if count >= 3:
            votes.setdefault(winner, []).append(
                LocatedTable(
                    statement=winner,
                    table_index=t_index,
                    page=table.page,
                    score=float(count),
                    consolidated=True,
                    reasons=[f"{count} tagged {winner.replace('_', ' ')} facts"],
                )
            )
    return {s: sorted(items, key=lambda x: x.score, reverse=True)[:3] for s, items in votes.items()}


def missing_core(out: ExtractionOutput) -> list[str]:
    have = {c.concept_id for c in out.candidates}
    return [c for c in CORE_CONCEPTS if c not in have]


def extract_ai(
    out: ExtractionOutput,
    content: bytes,
    taxonomy: Taxonomy,
    provider: AIProvider,
    *,
    tier: str = "untested",
    page_limit: int = 8,
    progress: Progress | None = None,
) -> ExtractionOutput:
    """AI mapping of unrecognised rows and a verified search for missing core items. Raises AIError to pause the job."""
    out.ai_used = True
    mapping = ai_map_rows(provider, out.unmapped, taxonomy, tier=tier)
    out.usage += mapping.usage
    taken = {(c.concept_id, c.period_key) for c in out.candidates}
    mapped_ids = {id(row) for row, *_ in mapping.mapped_rows}
    for row, concept_id, confidence, rationale in mapping.mapped_rows:
        for cand in candidate_from_ai_mapping(out.doc, row, concept_id, confidence, rationale, taxonomy):
            if (cand.concept_id, cand.period_key) not in taken:
                out.candidates.append(cand)
                taken.add((cand.concept_id, cand.period_key))
    out.unmapped = [r for r in out.unmapped if id(r) not in mapped_ids]
    located_pages = {t.page for tables in out.located.values() for t in tables}
    search = ai_extract_missing(
        provider,
        content,
        out.doc,
        missing_core(out),
        taxonomy,
        located_pages=located_pages,
        page_limit=page_limit,
        tier=tier,
    )
    out.usage += search.usage
    out.candidates += [c for c in search.candidates if (c.concept_id, c.period_key) not in taken]
    adjust_for_reconciliation([c for c in out.candidates if c.method.startswith("ai_")], taxonomy)
    out.not_found = search.not_found
    out.rejected = search.rejected
    out.periods = sorted({c.period_key for c in out.candidates})
    if progress:
        progress(
            "ai",
            f"AI mapped {len(mapping.mapped_rows)} rows and found {len(search.candidates)} more values"
            + (f"; {len(search.rejected)} rejected as unverifiable" if search.rejected else ""),
        )
    return out


def extract(
    content: bytes,
    filename: str,
    taxonomy: Taxonomy,
    *,
    provider: AIProvider | None = None,
    tier: str = "untested",
    page_limit: int = 8,
    progress: Progress | None = None,
) -> ExtractionOutput:
    out = extract_rules(content, filename, taxonomy, progress=progress)
    if provider is not None and out.doc.pages:
        return extract_ai(out, content, taxonomy, provider, tier=tier, page_limit=page_limit, progress=progress)
    out.not_found = [
        {"concept_id": c, "reason": "Not found in the statements (no AI connected to search the notes)."}
        for c in missing_core(out)
    ]
    if progress:
        progress("ai", "Skipped: no AI connected (tables and dictionary only)")
    return out
