"""Inline XBRL (iXBRL) reader: SEC 10-K/10-Q filings and EU ESEF annual reports (brief §5.2 step 2).

Tagged facts come first because they are the most reliable source: the company assigned each figure to a taxonomy
element, a reporting period and a unit. We read numeric facts (``ix:nonFraction``) together with their contexts and
units, keep only facts without dimensions (segment and scenario breakdowns are not the consolidated total), apply
the iXBRL ``scale``, ``sign`` and ``format`` rules, and map US GAAP / IFRS elements to the canonical taxonomy.

Parsing is hardened: no DTDs, no entity expansion and no network access (the filing is untrusted input).
"""

from __future__ import annotations

import dataclasses
import io
import re
import zipfile
from collections import Counter
from dataclasses import dataclass, field
from datetime import date, timedelta

from lxml import etree

IX_NAMESPACES = {"http://www.xbrl.org/2013/inlineXBRL", "http://www.xbrl.org/2008/inlineXBRL"}
XBRLI = "http://www.xbrl.org/2003/instance"
XBRLDI = "http://xbrl.org/2006/xbrldi"

# taxonomy family by namespace (the version year in the URI changes every year)
_FAMILIES = [
    (re.compile(r"fasb\.org/us-gaap/"), "us_gaap"),
    (re.compile(r"xbrl\.ifrs\.org/taxonomy/.*/ifrs-full|ifrs-full"), "ifrs"),
    (re.compile(r"xbrl\.sec\.gov/dei/"), "dei"),
]

# Elements whose sign is the change in a balance, not its cash effect: an increase in an asset is a cash outflow.
# Stored values follow the taxonomy's cash-effect convention (docs/methodology.md), so these are negated.
NEGATE_FOR_CASH_EFFECT = {
    "us-gaap:IncreaseDecreaseInAccountsReceivable",
    "us-gaap:IncreaseDecreaseInInventories",
    "us-gaap:IncreaseDecreaseInOtherOperatingAssets",
    "us-gaap:IncreaseDecreaseInOperatingCapital",
    "us-gaap:IncreaseDecreaseInOtherOperatingCapitalNet",
    "us-gaap:IncomeTaxesPaidNet",
    "us-gaap:IncomeTaxesPaid",
    "ifrs-full:IncomeTaxesPaidRefundClassifiedAsOperatingActivities",
    "ifrs-full:IncreaseDecreaseInWorkingCapital",
}
# DEI cover facts that map to canonical concepts (shares outstanding on the cover page)
DEI_CONCEPTS = {"dei:EntityCommonStockSharesOutstanding": "shares_outstanding"}

SCALE_NAMES = {0: "units", 3: "thousands", 6: "millions", 9: "billions", -2: "per cent"}


@dataclass
class Context:
    id: str
    start: date | None
    end: date | None  # instant contexts have end == instant
    instant: bool
    dimensional: bool


@dataclass
class Fact:
    id: str | None
    name: str  # prefix:Local as written in the filing
    family: str | None  # us_gaap | ifrs | dei | None (company extension)
    canonical_name: str  # us-gaap:Local / ifrs-full:Local / dei:Local / <prefix>:Local
    context: Context
    unit: str | None
    displayed: str
    value: float | None
    scale: int
    decimals: str | None
    negated: bool  # sign="-" in the filing


@dataclass
class InlineReport:
    facts: list[Fact] = field(default_factory=list)
    entity_name: str | None = None
    currency: str | None = None
    fiscal_year_focus: int | None = None
    period_end: date | None = None
    fiscal_year_end: tuple[int, int] | None = None  # (month, day)
    document_type: str | None = None  # dei:DocumentType (10-K, 10-Q, 20-F …)
    labels: dict[str, dict[str, str]] = field(default_factory=dict)  # extension element → {lang: label}
    language: str | None = None
    warnings: list[str] = field(default_factory=list)


def is_inline_xbrl(content: bytes) -> bool:
    """The inline XBRL namespace is declared on the root element (the ix:header itself may sit anywhere)."""
    head = content[:100_000]
    return b"xbrl.org/2013/inlineXBRL" in head or b"xbrl.org/2008/inlineXBRL" in head


def find_report_in_package(content: bytes) -> tuple[str, bytes] | None:
    """An ESEF report package (ZIP): return the inline XBRL report under ``reports/``, if there is one."""
    try:
        with zipfile.ZipFile(io.BytesIO(content)) as zf:
            candidates = [
                n
                for n in zf.namelist()
                if n.lower().endswith((".xhtml", ".html", ".htm")) and "/reports/" in f"/{n}".lower()
            ]
            for name in sorted(candidates, key=lambda n: zf.getinfo(n).file_size, reverse=True):
                data = zf.read(name)
                if is_inline_xbrl(data):
                    return name, data
    except zipfile.BadZipFile:
        return None
    return None


def _parser() -> etree.XMLParser:
    return etree.XMLParser(
        resolve_entities=False, no_network=True, load_dtd=False, huge_tree=True, recover=True, remove_comments=True
    )


def _date(text: str | None) -> date | None:
    if not text:
        return None
    try:
        return date.fromisoformat(text.strip()[:10])
    except ValueError:
        return None


def _family(namespace: str | None) -> str | None:
    if not namespace:
        return None
    for pattern, family in _FAMILIES:
        if pattern.search(namespace):
            return family
    return None


_CANONICAL_PREFIX = {"us_gaap": "us-gaap", "ifrs": "ifrs-full", "dei": "dei"}


def _transform(displayed: str, fmt: str | None) -> float | None:
    """iXBRL transformation registry formats used for numbers (ixt 1–5 and ixt-sec)."""
    text = displayed.replace(" ", " ").replace(" ", " ").strip()
    local = (fmt or "").split(":")[-1].lower().replace("-", "")
    if local in {"fixedzero", "zerodash", "fixedempty"} or text in {"-", "–", "—", "−", ""}:
        return 0.0
    if local in {"numwordsen", "numwordsen0"}:
        words = {"no": 0, "none": 0, "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6}
        return float(words[text.lower()]) if text.lower() in words else None
    if local in {"numcommadecimal", "numcommadot", "numspacecomma", "numdotcomma"} and local != "numdotcomma":
        cleaned = re.sub(r"[ .'’]", "", text).replace(",", ".")
    else:  # num-dot-decimal and plain numbers: thousands separators are commas, spaces or apostrophes
        cleaned = re.sub(r"[ ,'’]", "", text)
    cleaned = re.sub(r"[^\d.]", "", cleaned)
    if not cleaned or cleaned.count(".") > 1:
        return None
    try:
        return float(cleaned)
    except ValueError:
        return None


def read_inline_xbrl(content: bytes) -> InlineReport:
    report = InlineReport()
    try:
        root = etree.parse(io.BytesIO(content), _parser()).getroot()
    except etree.XMLSyntaxError as error:
        report.warnings.append(f"The tagged filing could not be parsed ({error.msg}).")
        return report
    if root is None:
        report.warnings.append("The tagged filing is empty.")
        return report

    contexts: dict[str, Context] = {}
    for ctx in root.iter(f"{{{XBRLI}}}context"):
        cid = ctx.get("id")
        if not cid:
            continue
        period = ctx.find(f"{{{XBRLI}}}period")
        instant = period.findtext(f"{{{XBRLI}}}instant") if period is not None else None
        start = period.findtext(f"{{{XBRLI}}}startDate") if period is not None else None
        end = period.findtext(f"{{{XBRLI}}}endDate") if period is not None else None
        dimensional = any(len(el) > 0 for el in ctx.iter(f"{{{XBRLI}}}segment", f"{{{XBRLI}}}scenario"))
        if instant:
            d = _date(instant)
            contexts[cid] = Context(cid, None, d, True, dimensional)
        else:
            contexts[cid] = Context(cid, _date(start), _date(end), False, dimensional)

    units: dict[str, str] = {}
    for unit in root.iter(f"{{{XBRLI}}}unit"):
        uid = unit.get("id")
        measures = [m.text.strip() for m in unit.iter(f"{{{XBRLI}}}measure") if m.text]
        if uid:
            units[uid] = "/".join(measures)

    currencies: Counter[str] = Counter()
    for element in root.iter():
        if not isinstance(element.tag, str):
            continue
        namespace, _, local = element.tag[1:].partition("}") if element.tag.startswith("{") else ("", "", element.tag)
        if namespace not in IX_NAMESPACES:
            continue
        if local == "nonNumeric":
            name = element.get("name", "")
            text = "".join(element.itertext()).strip()
            if name.endswith(":EntityRegistrantName") or name.endswith(
                ":NameOfReportingEntityOrOtherMeansOfIdentification"
            ):
                report.entity_name = report.entity_name or text[:200]
            elif name.endswith(":DocumentType"):
                report.document_type = text[:20]
            elif name.endswith(":DocumentFiscalYearFocus") and text[:4].isdigit():
                report.fiscal_year_focus = int(text[:4])
            elif name.endswith(":DocumentPeriodEndDate"):
                ctx = contexts.get(element.get("contextRef", ""))
                report.period_end = ctx.end if ctx else None
            elif name.endswith(":CurrentFiscalYearEndDate"):
                m = re.search(r"--(\d{2})-(\d{2})", text)
                if m:
                    report.fiscal_year_end = (int(m.group(1)), int(m.group(2)))
            continue
        if local != "nonFraction":
            continue
        if element.get("{http://www.w3.org/2001/XMLSchema-instance}nil") == "true":
            continue
        name = element.get("name", "")
        prefix, _, element_local = name.partition(":")
        namespace_uri = element.nsmap.get(prefix) if prefix else None
        family = _family(namespace_uri)
        context = contexts.get(element.get("contextRef", ""))
        if context is None:
            continue
        displayed = "".join(element.itertext()).strip()
        try:
            scale = int(element.get("scale", "0") or 0)
        except ValueError:
            scale = 0
        number = _transform(displayed, element.get("format"))
        negated = element.get("sign") == "-"
        value = None if number is None else number * (10**scale) * (-1 if negated else 1)
        unit = units.get(element.get("unitRef", ""))
        if unit and unit.lower().startswith("iso4217:") and "/" not in unit:
            currencies[unit.split(":", 1)[1].upper()] += 1
        report.facts.append(
            Fact(
                id=element.get("id"),
                name=name,
                family=family,
                canonical_name=f"{_CANONICAL_PREFIX.get(family or '', prefix)}:{element_local}",
                context=context,
                unit=unit,
                displayed=displayed,
                value=value,
                scale=scale,
                decimals=element.get("decimals"),
                negated=negated,
            )
        )
    report.currency = currencies.most_common(1)[0][0] if currencies else None
    if report.fiscal_year_end is None:
        report.fiscal_year_end = _infer_fiscal_year_end(report)
    if not report.facts:
        report.warnings.append("No numeric tagged facts were found in this filing.")
    return report


def _infer_fiscal_year_end(report: InlineReport) -> tuple[int, int] | None:
    ends: Counter[tuple[int, int]] = Counter()
    for fact in report.facts:
        ctx = fact.context
        if not ctx.instant and ctx.start and ctx.end and 330 <= (ctx.end - ctx.start).days <= 400:
            ends[(ctx.end.month, ctx.end.day)] += 1
    return ends.most_common(1)[0][0] if ends else None


def _months(a: date, b: date) -> int:
    return round((b - a).days / 30.44)


def period_key(report: InlineReport, ctx: Context) -> str | None:
    """FY2025 / H1-2026 / Q3-2026 / 9M-2026 for a context, aligned with the filing's own fiscal-year naming."""
    if ctx.end is None or report.fiscal_year_end is None:
        return None
    fye_month, fye_day = report.fiscal_year_end
    offset = 0
    if report.fiscal_year_focus and report.period_end:
        offset = report.fiscal_year_focus - _fiscal_year_of(report.period_end, fye_month, fye_day)
    fiscal_year = _fiscal_year_of(ctx.end, fye_month, fye_day) + offset
    fy_end = _fye(fiscal_year - offset, fye_month, fye_day)
    fy_start = _fye(fiscal_year - offset - 1, fye_month, fye_day) + timedelta(days=1)
    near_fye = abs((ctx.end - fy_end).days) <= 7  # 52/53-week years end within a week of the nominal date
    if ctx.instant:
        if near_fye:
            return f"FY{fiscal_year}"
        elapsed = _months(fy_start, ctx.end + timedelta(days=1))
        return {3: f"Q1-{fiscal_year}", 6: f"H1-{fiscal_year}", 9: f"9M-{fiscal_year}"}.get(elapsed)
    if ctx.start is None:
        return None
    length = _months(ctx.start, ctx.end + timedelta(days=1))
    if 11 <= length <= 13 and near_fye:
        return f"FY{fiscal_year}"
    elapsed = _months(fy_start, ctx.end + timedelta(days=1))
    if length == 3 and elapsed in (3, 6, 9, 12):
        return f"Q{elapsed // 3}-{fiscal_year}"
    if length == 6:
        return f"H1-{fiscal_year}" if elapsed == 6 else f"H2-{fiscal_year}" if elapsed == 12 else None
    if length == 9 and elapsed == 9:
        return f"9M-{fiscal_year}"
    return None


def _fye(year: int, month: int, day: int) -> date:
    while True:
        try:
            return date(year, month, day)
        except ValueError:
            day -= 1


def _fiscal_year_of(d: date, fye_month: int, fye_day: int) -> int:
    """The calendar year of the fiscal year end on or after ``d`` (allowing a week for 52/53-week years)."""
    this_year_end = _fye(d.year, fye_month, fye_day)
    return d.year if d <= this_year_end + timedelta(days=7) else d.year + 1


def scale_label(scale: int) -> str:
    return SCALE_NAMES.get(scale, f"×10^{scale}")


# ── facts → review candidates ─────────────────────────────────────────────────
XBRL_CONFIDENCE = 0.97  # brief §5.2 step 10: XBRL > clean table > OCR > narrative > LLM inference
_UNIT_KIND = {"currency": "money", "per_share": "per_share", "shares": "shares", "count": "pure", "percent": "pure"}
_SPLIT_CAMEL = re.compile(r"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")


def _unit_kind(unit: str | None) -> str | None:
    if not unit:
        return None
    lowered = unit.lower()
    if lowered.startswith("iso4217:") and "/" in lowered and "shares" in lowered:
        return "per_share"
    if lowered.startswith("iso4217:"):
        return "money"
    if lowered.endswith("shares"):
        return "shares"
    if lowered.endswith("pure"):
        return "pure"
    return None


def readable(name: str) -> str:
    """us-gaap:RevenueFromContractWithCustomer… → "Revenue from contract with customer…" (for labels)."""
    local = name.split(":", 1)[-1]
    words = _SPLIT_CAMEL.sub(" ", local).split()
    return " ".join([words[0], *(w.lower() if not w.isupper() else w for w in words[1:])]) if words else name


def facts_to_candidates(report: InlineReport, taxonomy):
    """Map tagged facts to canonical concepts. Returns (candidates, unmapped rows, warnings)."""
    from dealscout_engine.taxonomy import normalise_label

    from .mapping import Candidate, UnmappedRow

    families = {"us_gaap": "us-gaap", "ifrs": "ifrs-full"}
    # element → [(concept, priority)], so one fact can feed several concepts (net income on the P&L and the CF)
    by_element: dict[str, list[tuple[str, int]]] = {}
    for concept in taxonomy.concepts:
        for family, elements in concept.xbrl.items():
            prefix = families.get(family, family)
            for rank, element in enumerate(elements):
                by_element.setdefault(f"{prefix}:{element}", []).append((concept.id, rank))
    for element, concept_id in DEI_CONCEPTS.items():
        by_element.setdefault(element, []).append((concept_id, 0))

    best: dict[tuple[str, str], tuple[int, Fact]] = {}
    extension_rows: dict[str, dict[str, str]] = {}
    extension_scale: dict[str, int] = {}
    extension_ids: dict[str, dict[str, str | None]] = {}
    latest_fy = f"FY{report.fiscal_year_focus}" if report.fiscal_year_focus else None
    for fact in report.facts:
        if fact.context.dimensional or fact.value is None:
            continue
        key = period_key(report, fact.context)
        if fact.canonical_name in DEI_CONCEPTS:
            key = latest_fy or key  # cover-page share count is dated after the year end
        if key is None:
            continue
        targets = by_element.get(fact.canonical_name)
        if not targets:
            if fact.family is None and _unit_kind(fact.unit) == "money":
                display = f"-{fact.displayed}" if fact.negated else fact.displayed
                extension_rows.setdefault(fact.canonical_name, {}).setdefault(key, display)
                extension_ids.setdefault(fact.canonical_name, {}).setdefault(key, fact.id)
                extension_scale[fact.canonical_name] = fact.scale
            continue
        for concept_id, rank in targets:
            concept = taxonomy.concept(concept_id)
            wanted = _UNIT_KIND.get(concept.unit)
            if wanted and _unit_kind(fact.unit) not in (wanted, None):
                continue
            slot = (concept_id, key)
            if slot not in best or rank < best[slot][0]:
                best[slot] = (rank, fact)

    candidates: list[Candidate] = []
    for (concept_id, key), (_, fact) in best.items():
        concept = taxonomy.concept(concept_id)
        value = fact.value or 0.0
        if concept.sign == "negative" or fact.canonical_name in NEGATE_FOR_CASH_EFFECT:
            value = -value
        notes = [f"Tagged {fact.canonical_name} in the filing ({_describe(fact.context)})."]
        if fact.canonical_name in DEI_CONCEPTS and fact.context.end:
            notes.append(f"Cover-page figure as at {fact.context.end.isoformat()}.")
        currency = (
            fact.unit.split(":", 1)[1].upper() if fact.unit and fact.unit.lower().startswith("iso4217:") else None
        )
        if currency and "/" not in (fact.unit or ""):
            notes.append(f"Currency {currency}.")
        candidates.append(
            Candidate(
                concept_id=concept_id,
                period_key=key,
                value=value,
                value_as_written=(f"-{fact.displayed}" if fact.negated else fact.displayed).replace(" ", " ")[:80],
                label=fact.canonical_name,
                page=0,
                statement=concept.statement,
                method="xbrl",
                mapping="xbrl",
                confidence=XBRL_CONFIDENCE,
                cell_ref=fact.id,
                scale_factor=float(10**fact.scale),
                scale_label=scale_label(fact.scale),
                rationale=f"Tagged fact {fact.canonical_name}.",
                notes=notes,
            )
        )
    # company elements whose own label is a dictionary label map like a table row would (exact matches only)
    synonyms = taxonomy.synonym_index()
    for name in list(extension_rows):
        label = _label_for(report, name)
        matches = synonyms.get(normalise_label(label), []) if label else []
        if len(set(matches)) != 1:
            continue
        concept = taxonomy.concept(matches[0])
        if any((concept.id, key) in best for key in extension_rows[name]):
            continue
        for key, display in extension_rows.pop(name).items():
            number = _transform(
                display.lstrip("-"), "num-comma-decimal" if "," in display and "." not in display else None
            )
            if number is None:
                continue
            value = number * 10 ** extension_scale.get(name, 0) * (-1 if display.startswith("-") else 1)
            candidates.append(
                Candidate(
                    concept_id=concept.id,
                    period_key=key,
                    value=-abs(value) if concept.sign == "negative" else value,
                    value_as_written=display.replace("\u00a0", " ")[:80],
                    label=f"{label} ({name})"[:300],
                    page=0,
                    statement=concept.statement,
                    method="xbrl",
                    mapping="exact",
                    cell_ref=extension_ids.get(name, {}).get(key),
                    confidence=round(XBRL_CONFIDENCE * 0.95, 3),
                    scale_factor=float(10 ** extension_scale.get(name, 0)),
                    scale_label=scale_label(extension_scale.get(name, 0)),
                    rationale=f"Company element {name}, labelled “{label}”, matched the dictionary.",
                    notes=[f"Company-specific element {name}; mapped by its label."],
                )
            )
    unmapped = [
        UnmappedRow(
            label=f"{_label_for(report, name) or readable(name)} ({name})"[:300],
            page=0,
            statement=None,
            values={k: v.replace(" ", " ") for k, v in values.items()},
            candidates=[],
            table_index=-1,
            row_index=-1,
            reason="Company-specific tagged element (not in the US GAAP or IFRS taxonomy).",
            scale_factor=float(10 ** extension_scale.get(name, 0)),
        )
        for name, values in extension_rows.items()
    ]
    warnings = list(report.warnings)
    return candidates, unmapped, warnings


def _label_for(report: InlineReport, name: str) -> str | None:
    labels = report.labels.get(name, {})
    return labels.get(report.language or "") or labels.get("en") or next(iter(labels.values()), None)


def _describe(ctx: Context) -> str:
    if ctx.instant and ctx.end:
        return f"as at {ctx.end.isoformat()}"
    if ctx.start and ctx.end:
        return f"{ctx.start.isoformat()} to {ctx.end.isoformat()}"
    return "no period"


def read_xbrl_instance(content: bytes) -> InlineReport:
    """A classic XBRL instance document (.xbrl/.xml): facts are elements carrying ``contextRef``."""
    report = InlineReport()
    try:
        root = etree.parse(io.BytesIO(content), _parser()).getroot()
    except etree.XMLSyntaxError as error:
        report.warnings.append(f"The XBRL instance could not be parsed ({error.msg}).")
        return report
    if root is None:
        return report
    wrapper = etree.Element("{http://www.w3.org/1999/xhtml}html", nsmap={"ix": "http://www.xbrl.org/2013/inlineXBRL"})
    contexts_and_units = [el for el in root if isinstance(el.tag, str) and el.tag.startswith(f"{{{XBRLI}}}")]
    header = etree.SubElement(wrapper, "{http://www.xbrl.org/2013/inlineXBRL}header")
    resources = etree.SubElement(header, "{http://www.xbrl.org/2013/inlineXBRL}resources")
    for el in contexts_and_units:
        resources.append(el)
    for el in list(root):
        if not isinstance(el.tag, str) or el.get("contextRef") is None:
            continue
        namespace, _, local = el.tag[1:].partition("}")
        prefix = next((p for p, uri in el.nsmap.items() if uri == namespace and p), "ext")
        tag = "nonFraction" if el.get("unitRef") else "nonNumeric"
        fact = etree.SubElement(
            wrapper,
            f"{{http://www.xbrl.org/2013/inlineXBRL}}{tag}",
            nsmap={prefix: namespace},
            attrib={k: v for k, v in el.attrib.items() if k in ("contextRef", "unitRef", "decimals", "id")},
        )
        fact.set("name", f"{prefix}:{local}")
        text = (el.text or "").strip()
        if text.startswith("-"):
            fact.set("sign", "-")
            text = text[1:]
        fact.text = text
    return read_inline_xbrl(etree.tostring(wrapper))


XLINK = "http://www.w3.org/1999/xlink"
_STANDARD_LABEL = "http://www.xbrl.org/2003/role/label"


def read_package_labels(package: bytes) -> dict[str, dict[str, str]]:
    """Standard labels of a report package's own (extension) elements: ``prefix:Local`` → {lang: label}."""
    labels: dict[str, dict[str, str]] = {}
    try:
        with zipfile.ZipFile(io.BytesIO(package)) as zf:
            names = [n for n in zf.namelist() if re.search(r"_lab(-[a-z]{2})?\.xml$", n.lower())]
            for name in names[:10]:
                root = etree.parse(io.BytesIO(zf.read(name)), _parser()).getroot()
                if root is None:
                    continue
                locs: dict[str, str] = {}
                texts: dict[str, list[tuple[str, str, str]]] = {}
                arcs: list[tuple[str, str]] = []
                for el in root.iter():
                    if not isinstance(el.tag, str):
                        continue
                    local = el.tag.split("}")[-1]
                    if local == "loc":
                        href = el.get(f"{{{XLINK}}}href", "")
                        locs[el.get(f"{{{XLINK}}}label", "")] = href.split("#")[-1]
                    elif local == "label":
                        texts.setdefault(el.get(f"{{{XLINK}}}label", ""), []).append(
                            (
                                el.get(f"{{{XLINK}}}role", ""),
                                el.get("{http://www.w3.org/XML/1998/namespace}lang", ""),
                                (el.text or "").strip(),
                            )
                        )
                    elif local == "labelArc":
                        arcs.append((el.get(f"{{{XLINK}}}from", ""), el.get(f"{{{XLINK}}}to", "")))
                for source, target in arcs:
                    element_id = locs.get(source)
                    if not element_id or "_" not in element_id:
                        continue
                    qname = element_id.replace("_", ":", 1)
                    for role, lang, text in texts.get(target, []):
                        if role == _STANDARD_LABEL and text:
                            labels.setdefault(qname, {})[lang[:2].lower()] = text[:300]
    except (zipfile.BadZipFile, etree.XMLSyntaxError, KeyError):
        return labels
    return labels


def align_tables(doc, report: InlineReport) -> None:
    """Give tables of a tagged filing the filing's own period names and the scale of the facts tagged in them."""
    scales: dict[str, Counter[int]] = {}
    for fact in report.facts:
        scales.setdefault(fact.name, Counter())[fact.scale] += 1
    from .numbers import Scale

    for table in doc.tables:
        found: Counter[int] = Counter()
        for name in table.tags:
            found.update(scales.get(name, Counter()))
        if found and table.scale is None:
            power = found.most_common(1)[0][0]
            if power > 0:
                table.scale = Scale(factor=float(10**power), label=scale_label(power), matched="tagged facts")
        for column in table.columns:
            guess = column.period
            if guess is None or guess.end is None:
                continue
            key = period_key(report, Context("table", None, guess.end, True, False))
            if key and key != guess.key:
                if column.key == guess.key:
                    column.key = key
                column.period = dataclasses.replace(guess, key=key, fiscal_year=int(re.findall(r"\d{4}", key)[0]))
