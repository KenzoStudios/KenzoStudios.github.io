"""OCR for scanned PDF pages and images of statements (brief §5.1, §5.2 step 3).

Uses Tesseract through PyMuPDF when it is installed (an optional prerequisite: ``brew install tesseract
tesseract-lang`` on macOS, ``winget install UB-Mannheim.TesseractOCR`` on Windows). Recognised words keep their
positions, so OCR'd tables go through the same reconstruction as text PDFs and can be highlighted on the page. Without
Tesseract, scanned pages are reported clearly and never guessed.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

import pymupdf

from .model import DocumentContent

# document language (ISO 639-1) → Tesseract language pack
TESSERACT_LANGUAGES = {
    "en": "eng",
    "de": "deu",
    "es": "spa",
    "fr": "fra",
    "it": "ita",
    "pt": "por",
    "nl": "nld",
    "ja": "jpn",
    "zh": "chi_sim",
}
DEFAULT_LANGUAGES = "eng+deu+fra+spa+ita"
OCR_DPI = 300
MAX_OCR_PAGES = 80  # scanned annual reports are long; statements sit in a few pages

Word = tuple[float, float, float, float, str]


@lru_cache(maxsize=1)
def tessdata_dir() -> str | None:
    """Where Tesseract's language packs are, or None when Tesseract is not installed."""
    configured = os.environ.get("TESSDATA_PREFIX")
    if configured and Path(configured).is_dir():
        return configured
    try:
        found = pymupdf.get_tessdata()
    except (RuntimeError, OSError, ValueError):
        return None
    return found if found and Path(found).is_dir() else None


def ocr_available() -> bool:
    return tessdata_dir() is not None


def installed_languages() -> set[str]:
    folder = tessdata_dir()
    if not folder:
        return set()
    return {p.stem for p in Path(folder).glob("*.traineddata")}


def ocr_languages(document_language: str | None = None) -> str:
    """The language packs to use: the document's own language first, then the configured set, if installed."""
    configured = os.environ.get("DEALSCOUT_OCR_LANGUAGES", DEFAULT_LANGUAGES).split("+")
    wanted = [TESSERACT_LANGUAGES.get(document_language or "", ""), *configured]
    installed = installed_languages()
    chosen: list[str] = []
    for code in wanted:
        if code and (not installed or code in installed) and code not in chosen:
            chosen.append(code)
    return "+".join(chosen[:4]) or "eng"


def _engine_words(page: pymupdf.Page, languages: str) -> list[Word]:
    textpage = page.get_textpage_ocr(language=languages, dpi=OCR_DPI, full=True, tessdata=tessdata_dir())
    return [(w[0], w[1], w[2], w[3], w[4]) for w in page.get_text("words", textpage=textpage)]


def ocr_page(page: pymupdf.Page, languages: str) -> tuple[list[Word], str]:
    """Words with positions (PDF points, top-left origin) and the page text, from OCR."""
    words = _engine_words(page, languages)
    lines: dict[int, list[Word]] = {}
    for w in words:
        lines.setdefault(round((w[1] + w[3]) / 2 / 4), []).append(w)
    text = "\n".join(" ".join(w[4] for w in sorted(ws, key=lambda w: w[0])) for _, ws in sorted(lines.items()))
    return words, text


def not_available_warning(scanned: int) -> str:
    return (
        f"{scanned} page(s) are scanned images. Install Tesseract to read them (macOS: brew install tesseract "
        "tesseract-lang; Windows: winget install UB-Mannheim.TesseractOCR), connect an AI provider that reads "
        "images, or enter those figures manually."
    )


def read_image(content: bytes) -> DocumentContent:
    """A photo or screenshot of a statement: read as a one-page scanned document."""
    try:
        image = pymupdf.open(stream=content, filetype="png" if content[:4] == b"\x89PNG" else "jpeg")
        pdf_bytes = image.convert_to_pdf()
    except (RuntimeError, ValueError) as error:
        doc = DocumentContent(kind="image")
        doc.warnings.append(f"The image could not be opened ({type(error).__name__}).")
        return doc
    from .pdf_reader import read_pdf

    doc = read_pdf(pdf_bytes, force_scanned=True)
    doc.kind = "image"
    return doc
