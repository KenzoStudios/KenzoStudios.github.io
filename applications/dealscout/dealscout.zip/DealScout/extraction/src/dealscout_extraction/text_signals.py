"""Text-based warning signs in a deal's documents (brief §8, quality-of-earnings red flags).

A rules-based, multilingual phrase scanner over the page text of processed documents. It finds:

* going-concern doubt (material uncertainty / substantial doubt),
* a qualified or adverse audit opinion or a disclaimer of opinion,
* an emphasis-of-matter paragraph,
* a change of auditor,
* a restatement of prior periods (an error correction is high severity),
* significant related-party transactions (loans, guarantees, purchases or sales with related parties),
* customer concentration with a printed share (e.g. "our largest customer accounted for 23% of revenue").

No AI is needed. Each finding carries the page, a short quote and a one-sentence explanation. False positives are
the main risk, so every rule has negation cues (``no material uncertainty``, ``unqualified opinion``) and the
auditor's conditional boilerplate (``whether a material uncertainty exists``, ``if we conclude``) is ignored.
Negations are tested only on the text just before and inside the match, so a later "our opinion is not modified"
does not cancel an emphasis-of-matter paragraph.
"""

from __future__ import annotations

import re
import unicodedata
from collections import Counter
from dataclasses import dataclass, field
from typing import Literal

from pydantic import BaseModel, Field

from dealscout_engine.scores import FlagEvidence, RedFlag

from .model import DocumentContent

RULES_VERSION = "text-signals-2026-11-v1"
Severity = Literal["high", "medium"]
SNIPPET_MAX = 200
NEGATION_WINDOW = 70  # characters before the match that are checked for a negation
MAX_EVIDENCE = 3  # pages quoted per signal and document


class TextSignal(BaseModel):
    """One phrase found on one page."""

    signal_id: str
    signal: str
    severity: Severity
    page: int
    snippet: str = Field(max_length=SNIPPET_MAX + 2)
    explanation: str
    metric: float | None = None  # customer concentration: the share printed (0.23 = 23%)
    document_id: str | None = None
    filename: str | None = None


@dataclass
class _Rule:
    id: str
    signal: str
    severity: Severity
    explanation: str
    patterns: list[str]
    negations: list[str] = field(default_factory=list)
    conditional: bool = True  # ignore matches in conditional / hypothetical sentences (auditor boilerplate)
    escalate: str | None = None  # a sentence matching this turns a medium finding into a high one
    threshold: str = "phrase found in the document"

    def __post_init__(self) -> None:
        self.rx = re.compile("|".join(f"(?:{p})" for p in self.patterns), re.IGNORECASE)
        self.neg = re.compile("|".join(f"(?:{p})" for p in self.negations), re.IGNORECASE) if self.negations else None
        self.esc = re.compile(self.escalate, re.IGNORECASE) if self.escalate else None
        self.cond = _CONDITIONAL_RX if self.conditional else None


# conditional / hypothetical wording used in auditors' standard responsibilities paragraphs and in policies
_CONDITIONAL = [
    r"\bwhether\b",
    r"\bif (?:we|the|it|there|such|management|they)\b",
    r"\bin the event\b",
    r"\bob\b",
    r"\bfalls (?:wir|eine|die|der)\b",
    r"\bsofern\b",
    r"\bsi (?:nous|concluimos|existe|una|une|il)\b",
    r"\bqualora\b",
    r"\bse (?:concludiamo|esiste)\b",
    r"\bof er\b",
    r"\bcaso\b",
    r"場合には",
]

_NEGATIONS = [
    r"\bno\b",
    r"\bnot\b",
    r"\bnone\b",
    r"\bnor\b",
    r"\bwithout\b",
    r"\babsence of\b",
    r"n't\b",
    r"\bkein(?:e|en|er|es)?\b",
    r"\bnicht\b",
    r"\bohne\b",
    r"\bningun[ao]?\b",
    r"\bsin\b",
    r"\bno (?:existe|hay|se)\b",
    r"\baucun(?:e)?\b",
    r"\bpas\b",
    r"\bsans\b",
    r"\bnessun[ao]?\b",
    r"\bnon\b(?!-)",
    r"\bsenza\b",
    r"\bgeen\b",
    r"\bniet\b",
    r"\bzonder\b",
    r"\bnão\b",
    r"\bnenhum[a]?\b",
    r"\bsem\b",
    r"ない",
    r"ません",
    r"認められない",
    r"該当事項はありません",
]

_CONDITIONAL_RX = re.compile("|".join(_CONDITIONAL), re.IGNORECASE)
# negation that follows the phrase (German "... sind nicht erkennbar", Japanese "...は認められない")
_POST_NEGATION = re.compile(
    r"\b(?:nicht|keine?|not (?:been )?(?:identified|exist)|does not exist|n'existe pas|ne sont pas"
    r"|non (?:sussist|esist)|niet|não (?:existe|há))\b|認められ(?:ない|ません)|ありません|存在しない|はない|該当事項",
    re.IGNORECASE,
)
POST_WINDOW = 40

RULES: list[_Rule] = [
    _Rule(
        id="going_concern",
        signal="Going-concern doubt",
        severity="high",
        explanation="The accounts flag doubt about the company's ability to continue in business; financing, "
        "covenants and liquidity need checking before any price is agreed.",
        patterns=[
            # English (IFRS / ISA 570 and US GAAP wording)
            r"material uncertaint(?:y|ies)\b.{0,140}\bgoing concern",
            r"going concern\b.{0,140}\bmaterial uncertaint(?:y|ies)",
            r"(?:substantial|significant) doubt\b.{0,120}\b(?:going concern|ability to continue)",
            # German
            r"wesentlichen? unsicherheit\w*.{0,160}(?:fortführung|going concern|bestandsgefährd)",
            r"(?:fortführung der unternehmenstätigkeit|unternehmensfortführung).{0,160}wesentlichen? unsicherheit",
            r"bestandsgefährdende[nr]? (?:tatsachen|risik)",
            # Spanish
            r"incertidumbre (?:material|significativa).{0,160}(?:empresa en funcionamiento|principio de"
            r" funcionamiento)",
            r"(?:empresa en funcionamiento).{0,160}incertidumbre (?:material|significativa)",
            # French
            r"incertitude significative.{0,160}continuité d'exploitation",
            r"continuité d'exploitation.{0,160}incertitude significative",
            # Italian
            r"incertezz[ae] significativ[ae].{0,160}continuità aziendale",
            r"continuità aziendale.{0,160}incertezz[ae] significativ[ae]",
            # Dutch
            r"onzekerheid van materieel belang.{0,160}continuïteit",
            r"continuïteit.{0,160}onzekerheid van materieel belang",
            # Portuguese
            r"incerteza (?:material|significativa).{0,160}continuidade",
            r"continuidade.{0,160}incerteza (?:material|significativa)",
            # Japanese
            r"継続企業の前提に(?:関する)?重要な(?:不確実性|疑義)",
        ],
        negations=[*_NEGATIONS, r"\balleviat", r"\bmitigat"],
    ),
    _Rule(
        id="qualified_opinion",
        signal="Qualified or adverse audit opinion",
        severity="high",
        explanation="The auditor did not give a clean opinion; the figures may be unreliable in the area the "
        "auditor names.",
        patterns=[
            r"\b(?:qualified|adverse) (?:audit )?opinion\b",
            r"\bdisclaimer of (?:an )?opinion\b",
            r"\bwe do not express an opinion\b",
            r"(?<!un)eingeschränkte[nrs]? (?:bestätigungsvermerk|prüfungsurteil)",
            r"\bversagungsvermerk\b",
            r"\bversagte[sn]? prüfungsurteil",
            r"\bopinión (?:con salvedades|desfavorable|adversa)\b",
            r"\bdenegación de opinión\b",
            r"\bopinion (?:avec réserves?|défavorable)\b",
            r"\bcertification avec réserves?\b",
            r"\bimpossibilité d'exprimer une opinion\b",
            r"\brefus de certifier\b",
            r"\bgiudizio (?:con rilievi|negativo)\b",
            r"\bimpossibilità di esprimere un giudizio\b",
            r"\b(?:verklaring met beperking|afkeurende verklaring|oordeelonthouding)\b",
            r"\bopinião (?:com ressalvas?|adversa)\b",
            r"\babstenção de opinião\b",
            r"限定付適正意見",
            r"不適正意見",
            r"意見不表明",
        ],
        negations=[*_NEGATIONS, r"\bun(?:qualified|modified)\b", r"\bclean\b", r"\bmay\b"],
    ),
    _Rule(
        id="emphasis_of_matter",
        signal="Emphasis of matter in the audit report",
        severity="medium",
        explanation="The auditor draws attention to a matter disclosed in the accounts (often uncertainty or a "
        "significant event); read the note it refers to.",
        patterns=[
            r"\bemphasis of matters?\b",
            r"\bhervorhebung (?:eines|von) sachverhalt",
            r"\bpárrafo de énfasis\b",
            r"\bparagraphe d'observations?\b",
            r"\brichiam[oi] d'informativa\b",
            r"\bbenadrukking van (?:een )?aangelegenhe(?:id|den)\b",
            r"\bênfases?\b",
            r"強調事項",
        ],
        negations=[
            r"\bno emphasis\b",
            r"\bwithout (?:an )?emphasis\b",
            r"\bkeine hervorhebung\b",
            r"\bsin (?:párrafo de )?énfasis\b",
            r"\bsans observation\b",
            r"\bsenza richiam",
            r"\bsem ênfase\b",
            r"強調事項はない",
        ],
    ),
    _Rule(
        id="auditor_change",
        signal="Change of auditor",
        severity="medium",
        explanation="A new auditor can follow a disagreement over accounting; ask why the auditor changed and read "
        "the predecessor's last report.",
        patterns=[
            r"\bchange (?:of|in) (?:the )?(?:company's |group's |statutory |external |independent )*auditors?\b",
            r"\b(?:new|successor) (?:statutory |external |independent )?auditors?\b",
            r"\bauditors? (?:resigned|was dismissed|were dismissed|was replaced|were replaced)\b",
            r"\b(?:dismiss(?:ed|al of)|replac(?:ed|ement of)|resignation of) (?:the |our |its )?"
            r"(?:statutory |external |independent )?(?:auditors?|accountants?|registered public accounting firm)\b",
            r"\bwechsel (?:des|im) abschlussprüfer",
            r"\bprüferwechsel\b",
            r"\bneue[nr]? abschlussprüfer",
            r"\bcambio (?:de|del) auditor",
            r"\bnuevo auditor\b",
            r"\bchangement (?:de|du) commissaires? aux comptes\b",
            r"\bnouveaux? commissaires? aux comptes\b",
            r"\bcambio (?:del|di) revisore\b",
            r"\bnuov[oa] (?:società di )?revisione\b",
            r"\bwisseling van (?:de )?accountant\b",
            r"\bmudança (?:de|do) auditor",
            r"\bnovo auditor\b",
            r"(?:会計)?監査人の異動",
        ],
        negations=[*_NEGATIONS, r"re-?appoint", r"\bwiederbestell", r"\breconduc"],
    ),
    _Rule(
        id="restatement",
        signal="Restatement of prior periods",
        severity="medium",
        explanation="Previously published figures were changed; compare the restated and original numbers and ask "
        "what caused the change.",
        patterns=[
            r"\brestat(?:ement|ed)\b.{0,80}\b(?:prior|previous|previously|comparative)",
            r"\b(?:prior|previous|comparative)\b.{0,50}\b(?:have been|has been|were|was) restated\b",
            r"\bas restated\b",
            r"\bcorrection of (?:an |a |prior[- ]period )?(?:material )?errors?\b",
            r"\bprior[- ]period (?:adjustments?|errors?)\b",
            r"\b(?:fehlerkorrektur|korrektur von fehlern|korrektur eines fehlers)\b",
            r"\bvorjahres(?:zahlen|werte|angaben)\b.{0,60}\b(?:angepasst|korrigiert)\b",
            r"\breexpres(?:ión|ad[oa]s?)\b",
            r"\bcorrección de errores?\b",
            r"\bretrait(?:ement|é(?:e|s|es)?)\b.{0,60}\b(?:exercice|période)s? (?:antérieur|précédent)",
            r"\bcorrection d'(?:une )?erreurs?\b",
            r"\brideterminat[oiae]\b.{0,60}\b(?:esercizi?o? precedent|comparativ|period[oi] precedent)",
            r"\bcorrezione di errori\b",
            r"\b(?:herrekend|herziene vergelijkende cijfers|foutherstel)\b",
            r"\breapresenta(?:ção|d[oa]s?)\b",
            r"\bcorreção de erros?\b",
            r"遡及修正",
            r"修正再表示",
            r"過年度(?:決算)?の訂正",
        ],
        negations=_NEGATIONS,
        escalate=r"\berror|\bfehler|\berrores?\b|\berreur|\berrori\b|\bfout|\berros?\b|訂正|誤謬",
    ),
    _Rule(
        id="related_party",
        signal="Significant related-party transactions",
        severity="medium",
        explanation="Loans, guarantees or trading with shareholders, directors or their companies may not be at "
        "arm's length and may end after a sale; quantify them and check the terms.",
        patterns=[
            r"\b(?:loans?|advances?|guarantees?|borrowings?) (?:to|from|granted to|provided to|with) "
            r"(?:a |the |our |its )?(?:related part(?:y|ies)|directors?"
            r"|(?:controlling |majority |principal )?shareholders?|key management|chief executive)",
            r"\brelated part(?:y|ies)\b.{0,80}\b(?:loan|guarantee|purchased|acquired|sold|lease[sd]?|rent|consult"
            r"(?:ancy|ing) fees?|management fees?)\b",
            r"\b(?:purchased|acquired|bought|sold|leases?|rents?) .{0,40}\bfrom (?:a |an )?(?:company|entity|entities)"
            r" (?:controlled|owned) by (?:a |the |our )?(?:director|shareholder|chief executive|founder)",
            r"\b(?:nahestehende[nr]? (?:personen|unternehmen)).{0,80}\b(?:darlehen|bürgschaft|garantie|miete)",
            r"\b(?:darlehen|bürgschaft)\w* (?:an|von) (?:nahestehende|gesellschafter|vorstand|geschäftsführer)",
            r"\bpartes vinculadas\b.{0,80}\b(?:préstamo|garantía|arrendamiento|compra)",
            r"\bparties liées\b.{0,80}\b(?:prêt|garantie|bail|achat|caution)",
            r"\bparti correlate\b.{0,80}\b(?:finanziament|garanzi|locazion|acquist)",
            r"\bverbonden partijen\b.{0,80}\b(?:lening|garantie|huur)",
            r"\bpartes relacionadas\b.{0,80}\b(?:empréstimo|garantia|arrendamento|compra)",
            r"関連当事者.{0,40}(?:貸付|債務保証|借入|資金の貸付)",
        ],
        negations=[*_NEGATIONS, r"\barm's[- ]length\b.{0,20}\bterms\b"],
    ),
]

# customer concentration: the printed share decides the severity
_CONCENTRATION = re.compile(
    r"(?P<subject>(?:our |the |its |the group's )?(?:(?:single largest|largest|biggest|major|principal|main|key) "
    r"|top (?:(?:one|two|three|five|ten|\d{1,2}) )?|(?:one|two|three|five|ten) )customers?\b"
    r"|größte[nr]? kunde[n]?|wichtigste[nr]? kunde[n]?|(?:fünf|zehn) größten kunden"
    r"|(?:mayor|principal) cliente|(?:cinco|diez) (?:mayores|principales) clientes"
    r"|(?:premier|principal|plus important) client|(?:cinq|dix) (?:premiers|principaux) clients"
    r"|(?:primo|principale|maggiore) cliente|(?:primi|principali) (?:cinque|dieci) clienti"
    r"|grootste klant(?:en)?|maior cliente|(?:cinco|dez) maiores clientes"
    r"|(?:最大|主要|上位\d+社の?)(?:顧客|取引先|販売先))"
    r"(?P<gap>.{0,90}?)"
    r"(?P<pct>\d{1,2}(?:[.,]\d{1,2})?|100)\s?(?:%|per ?cent\b|percent\b|prozent\b|por ciento\b|pour cent\b|per cento\b"
    r"|procent\b|por cento\b)",
    re.IGNORECASE,
)
_CONCENTRATION_NEG = re.compile(
    "|".join(
        [
            r"\bno (?:single |individual |one )?customers?\b",
            r"\bnone of\b",
            r"\bless than\b",
            r"\bbelow\b",
            r"\bunder\b",
            r"\bnot more than\b",
            r"\bdid not\b",
            r"\bdoes not\b",
            r"\bkein(?:e|en|er)? (?:einzelne[nr]? )?kunde",
            r"\bweniger als\b",
            r"\bningún cliente\b",
            r"\bmenos del?\b",
            r"\baucun client\b",
            r"\bmoins de\b",
            r"\bnessun cliente\b",
            r"\bmeno del\b",
            r"\bgeen (?:enkele )?klant\b",
            r"\bminder dan\b",
            r"\bnenhum cliente\b",
            r"\bmenos de\b",
            r"未満",
        ]
    ),
    re.IGNORECASE,
)
_TOP_N = re.compile(
    r"\btop\b|\b(?:two|three|five|ten|\d{1,2})\b|fünf|zehn|cinco|diez|cinq|dix|cinque|dieci|dez|上位", re.IGNORECASE
)
_REVENUE_WORDS = re.compile(
    r"revenue|sales|turnover|umsatz|erlöse|ventas|ingresos|cifra de negocios|chiffre d'affaires|ventes|ricavi|fatturato"
    r"|omzet|receita|vendas|売上|収益",
    re.IGNORECASE,
)
CONCENTRATION_SIGNAL = "Customer concentration"
CONCENTRATION_EXPLANATION = (
    "A large share of revenue depends on few customers; losing one would hit earnings, so check contract terms and "
    "change-of-control clauses."
)


def _concentration_severity(share: float, top_n: bool) -> Severity | None:
    """Single customer: 10% or more is medium, 25% or more high. Top-N group: 30% medium, 50% high."""
    low, high = (0.30, 0.50) if top_n else (0.10, 0.25)
    if share >= high:
        return "high"
    if share >= low:
        return "medium"
    return None


# ── text helpers ─────────────────────────────────────────────────────────────
_SENTENCE = re.compile(r"(?<=[.!?;。])\s+|(?<=。)|\s{3,}")


def normalise_text(text: str) -> str:
    """NFKC (full-width digits and % in Japanese reports), typographic quotes, joined line breaks."""
    t = unicodedata.normalize("NFKC", text)
    t = t.replace("’", "'").replace("‘", "'").replace("­", "")
    t = re.sub(r"-\n(?=[a-zäöüéèàç])", "", t)  # hyphenated line break inside a word
    t = re.sub(r"[ \t]*\n[ \t]*", " ", t)
    return re.sub(r"[ \t]{2,}", "  ", t)


def sentences(text: str) -> list[str]:
    return [s.strip() for s in _SENTENCE.split(normalise_text(text)) if s and s.strip()]


def snippet(sentence: str, start: int, end: int, limit: int = SNIPPET_MAX) -> str:
    """The sentence when short enough, else a window of ``limit`` characters around the match."""
    text = re.sub(r"\s+", " ", sentence).strip()
    if len(text) <= limit:
        return text
    centre = (start + end) // 2
    lo = max(0, min(centre - limit // 2, len(text) - limit))
    hi = min(len(text), lo + limit)
    cut = text[lo:hi]
    if lo > 0:
        cut = "…" + cut[cut.find(" ") + 1 :] if " " in cut[:30] else "…" + cut
    if hi < len(text):
        cut = (cut[: cut.rfind(" ")] if " " in cut[-30:] else cut) + "…"
    return cut


def _negated(rule: _Rule, sentence: str, start: int, end: int) -> bool:
    """A negation just before or inside the match, a negation right after it, or a conditional sentence."""
    if rule.neg is not None and rule.neg.search(sentence[max(0, start - NEGATION_WINDOW) : end]):
        return True
    if rule.cond is not None and rule.cond.search(sentence[:end]):
        return True
    return rule.id != "emphasis_of_matter" and bool(_POST_NEGATION.search(sentence[end : end + POST_WINDOW]))


# ── scanning ─────────────────────────────────────────────────────────────────
def scan_text(text: str, page: int = 1) -> list[TextSignal]:
    """All signals in one page of text (every rule, every language)."""
    found: list[TextSignal] = []
    for sentence in sentences(text):
        for rule in RULES:
            for m in rule.rx.finditer(sentence):
                if _negated(rule, sentence, m.start(), m.end()):
                    continue
                severity: Severity = "high" if rule.esc and rule.esc.search(sentence) else rule.severity
                found.append(
                    TextSignal(
                        signal_id=rule.id,
                        signal=rule.signal,
                        severity=severity,
                        page=page,
                        snippet=snippet(sentence, m.start(), m.end()),
                        explanation=rule.explanation,
                    )
                )
                break
        for m in _CONCENTRATION.finditer(sentence):
            if _CONCENTRATION_NEG.search(sentence[max(0, m.start() - NEGATION_WINDOW) : m.end()]):
                continue
            if not _REVENUE_WORDS.search(sentence):
                continue
            share = float(m.group("pct").replace(",", ".")) / 100
            subject = m.group("subject").strip().lower()
            top_n = bool(_TOP_N.search(subject)) or subject.endswith(
                ("customers", "kunden", "clientes", "clients", "clienti", "klanten")
            )
            sev = _concentration_severity(share, top_n)
            if sev is None:
                continue
            found.append(
                TextSignal(
                    signal_id="customer_concentration",
                    signal=CONCENTRATION_SIGNAL,
                    severity=sev,
                    page=page,
                    snippet=snippet(sentence, m.start(), m.end()),
                    explanation=CONCENTRATION_EXPLANATION,
                    metric=share,
                )
            )
            break
    return found


NARRATIVE_KINDS = {"pdf", "html", "xbrl", "zip", "docx", "image"}


def scan_document(
    doc: DocumentContent, *, document_id: str | None = None, filename: str | None = None
) -> list[TextSignal]:
    """Signals across a document's pages, in page order; spreadsheets have no narrative and return nothing."""
    if doc.kind not in NARRATIVE_KINDS:
        return []
    out: list[TextSignal] = []
    for page in doc.pages:
        if not page.text:
            continue
        for s in scan_text(page.text, page.page):
            out.append(s.model_copy(update={"document_id": document_id, "filename": filename}))
    return out


_YEAR_CONTEXT = re.compile(
    r"(?:year|period) ended\b[^.]{0,30}?\b((?:19|20)\d\d)\b|annual report\s((?:19|20)\d\d)\b"
    r"|(?:geschäftsbericht|jahresabschluss|konzernabschluss)\s(?:\w+\s){0,2}((?:19|20)\d\d)\b"
    r"|(?:informe anual|cuentas anuales|rapport annuel|relazione finanziaria annuale|jaarverslag|relatório anual)"
    r"\s(?:\w+\s){0,2}((?:19|20)\d\d)\b|(?:fiscal|financial) year\s((?:19|20)\d\d)\b",
    re.IGNORECASE,
)


def document_year(doc: DocumentContent, *, pages: int = 3) -> int | None:
    """The reporting year a document is about, from wording on its first pages ("year ended 31 December 2025")."""
    years: Counter[int] = Counter()
    for page in doc.pages[:pages]:
        for m in _YEAR_CONTEXT.finditer(normalise_text(page.text)):
            year = next(g for g in m.groups() if g)
            years[int(year)] += 1
    return max(years) if years else None


def to_red_flags(signals: list[TextSignal], *, period: str) -> list[RedFlag]:
    """One early-warning sign per signal and document, with up to three quoted pages as evidence."""
    grouped: dict[tuple[str, str | None], list[TextSignal]] = {}
    for s in signals:
        grouped.setdefault((s.signal_id, s.document_id), []).append(s)
    flags: list[RedFlag] = []
    for (signal_id, _doc), items in grouped.items():
        pages: list[TextSignal] = []
        for s in sorted(items, key=lambda x: (x.severity != "high", x.page)):
            if all(p.page != s.page for p in pages):
                pages.append(s)
        pages = sorted(pages[:MAX_EVIDENCE], key=lambda x: x.page)
        severity: Severity = "high" if any(s.severity == "high" for s in items) else "medium"
        metrics = [s.metric for s in items if s.metric is not None]
        first = pages[0]
        rule = next((r for r in RULES if r.id == signal_id), None)
        flags.append(
            RedFlag(
                id=f"text_{signal_id}",
                signal=first.signal,
                period=period,
                metric=max(metrics) if metrics else None,
                threshold=(
                    "one customer 10% (high 25%) or top customers 30% (high 50%) of revenue"
                    if signal_id == "customer_concentration"
                    else rule.threshold
                    if rule
                    else "phrase found in the document"
                ),
                severity=severity,
                explanation=first.explanation,
                source="document",
                evidence=[
                    FlagEvidence(
                        document_id=s.document_id or "",
                        filename=s.filename or "",
                        page=s.page,
                        snippet=s.snippet,
                    )
                    for s in pages
                ],
            )
        )
    return flags
