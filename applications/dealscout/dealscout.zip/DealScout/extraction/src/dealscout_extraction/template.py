"""Read a filled-in DealScout entry template (.xlsx) back into cell values (brief §12).

Only literal values are imported; formula cells are skipped (the engine recomputes subtotals). Values typed as
positive amounts on cost/outflow lines are recorded as negatives, matching the grid's entry rule. Macros are never
executed: only .xlsx is accepted and openpyxl does not evaluate formulas or run code.
"""

from __future__ import annotations

import io
from dataclasses import dataclass, field

from openpyxl import load_workbook

from dealscout_engine.taxonomy import Taxonomy

from .numbers import parse_number, parse_period_header

SCALES = {"units": 1.0, "thousands": 1e3, "millions": 1e6, "billions": 1e9}
HEADER_ROW = 4
FIRST_ROW = 5


@dataclass
class TemplateCell:
    concept_id: str
    period_key: str
    value: float
    entered_text: str
    sheet: str
    cell: str


@dataclass
class TemplateImport:
    deal_id: str | None
    scale: float
    scale_label: str
    cells: list[TemplateCell] = field(default_factory=list)
    periods: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def read_entry_template(content: bytes, taxonomy: Taxonomy) -> TemplateImport:
    try:
        wb = load_workbook(io.BytesIO(content), data_only=False, read_only=False)
    except Exception as error:  # zip/format errors
        raise ValueError(f"This file could not be read as an Excel workbook ({type(error).__name__}).") from error
    if "Instructions" not in wb.sheetnames:
        raise ValueError(
            "This is not a DealScout entry template (no 'Instructions' sheet). Download the template first."
        )
    deal_id = None
    if "_dealscout" in wb.sheetnames:
        deal_id = str(wb["_dealscout"]["B1"].value or "") or None
    units = str(wb["Instructions"]["C6"].value or "millions").strip().lower()
    warnings: list[str] = []
    if units not in SCALES:
        warnings.append(f"Unknown units '{units}' on the Instructions sheet; millions assumed.")
        units = "millions"
    result = TemplateImport(deal_id=deal_id, scale=SCALES[units], scale_label=units, warnings=warnings)
    periods_seen: set[str] = set()
    for ws in wb.worksheets:
        if ws.title in ("Instructions", "_dealscout"):
            continue
        header: dict[int, str] = {}
        for col in range(3, ws.max_column + 1):
            raw = ws.cell(row=HEADER_ROW, column=col).value
            if raw is None or str(raw).strip() == "":
                continue
            guess = parse_period_header(str(raw))
            if guess is None:
                result.warnings.append(
                    f"{ws.title}: column header '{raw}' is not a period (e.g. FY2025); column skipped."
                )
                continue
            header[col] = guess.key
        for row in range(FIRST_ROW, ws.max_row + 1):
            concept_id = ws.cell(row=row, column=1).value
            if not concept_id:
                continue
            concept_id = str(concept_id).strip()
            if not taxonomy.has(concept_id):
                result.warnings.append(f"{ws.title} row {row}: unknown line-item code '{concept_id}'; row skipped.")
                continue
            concept = taxonomy.concept(concept_id)
            for col, period_key in header.items():
                cell = ws.cell(row=row, column=col)
                value = cell.value
                if value is None or (isinstance(value, str) and (value.strip() == "" or value.startswith("="))):
                    continue
                if isinstance(value, bool):
                    continue
                if isinstance(value, int | float):
                    number: float | None = float(value)
                else:
                    number = parse_number(str(value)).value
                    if number is None:
                        result.warnings.append(f"{ws.title}!{cell.coordinate}: '{value}' is not a number; skipped.")
                        continue
                assert number is not None
                if concept.unit == "currency":
                    number *= result.scale
                if concept.sign == "negative":
                    number = -abs(number)
                periods_seen.add(period_key)
                result.cells.append(
                    TemplateCell(
                        concept_id=concept_id,
                        period_key=period_key,
                        value=number,
                        entered_text=str(value)[:120],
                        sheet=ws.title,
                        cell=cell.coordinate,
                    )
                )
    result.periods = sorted(periods_seen)
    if not result.cells:
        result.warnings.append("No figures were found in the template.")
    return result
