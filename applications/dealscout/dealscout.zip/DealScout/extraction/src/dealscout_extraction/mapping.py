"""Map statement rows to canonical concepts with the synonym dictionary and structural cues (brief §5.2 step 5).

Rows that do not map, or map ambiguously, are kept in an ``unmapped`` bucket for the AI step or the analyst —
never discarded. Numbers are normalised here: scale (thousands/millions/…), and the taxonomy sign convention
(costs and outflows stored negative).
"""

from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field

from dealscout_engine.taxonomy import Taxonomy, normalise_label

from .locate import LocatedTable
from .model import BBox, DocumentContent, Table

SOURCE_CONFIDENCE = {
    "xbrl": 0.97,
    "html": 0.88,
    "excel": 0.92,
    "csv": 0.92,
    "pdf_layout": 0.85,
    "docx": 0.85,
    "ocr": 0.6,
    "ai_text": 0.6,
}
MAPPING_FACTOR = {"xbrl": 1.0, "exact": 1.0, "prefix": 0.95, "fuzzy": 0.85, "ai": 0.8, "user": 1.0}


@dataclass
class Candidate:
    concept_id: str
    period_key: str
    value: float  # absolute units, taxonomy sign
    value_as_written: str
    label: str
    page: int
    statement: str | None
    method: str  # table_rules | ai_mapping | ai_extraction
    mapping: str  # exact | prefix | fuzzy | ai | user
    confidence: float
    bbox: BBox | None = None
    cell_ref: str | None = None
    sheet: str | None = None
    scale_factor: float = 1.0
    scale_label: str | None = None
    rationale: str | None = None
    notes: list[str] = field(default_factory=list)


@dataclass
class UnmappedRow:
    label: str
    page: int
    statement: str | None
    values: dict[str, str]
    candidates: list[str]
    table_index: int
    row_index: int
    reason: str
    scale_factor: float | None = None  # tagged facts: 10^scale (no table to read it from)


_FUZZY_STOP = {
    "and", "&", "of", "the", "for", "in", "on", "to", "from", "de", "la", "y", "des", "du", "der", "die", "das",
    "für", "von", "del", "los", "las", "el", "en", "et", "und", "e", "di", "da", "do", "a",
}  # fmt: skip
_CJK = re.compile(r"[぀-ヿ一-鿿가-힯]")
_CUTS = re.compile(
    r",\s|\s\(|\sbeing\s|\sattributable\s|\s[-–]\s|\s/\s|\sdavon\s|\sthereof\s|\sof which\s|\sdont\s"
    r"|\sde los cuales\s|（"
)


def _significant(label: str) -> list[str]:
    words = [w.strip(".:;()") for w in label.split()]
    return [w[:-1] if len(w) > 4 and w.endswith("s") else w for w in words if w and w not in _FUZZY_STOP]


def _tokens_correspond(a: str, b: str) -> bool:
    """A fuzzy match may only differ in spelling (amortisation/amortization, plural), never in a word.

    "acquisition of intangible assets" must not match "acquisition of tangible fixed assets".
    """
    left, right = _significant(a), _significant(b)
    if len(left) != len(right):
        return False
    remaining = list(right)
    for word in left:
        partner = next(
            (w for w in remaining if w[:3] == word[:3] and difflib.SequenceMatcher(None, w, word).ratio() >= 0.8),
            None,
        )
        if partner is None:
            return False
        remaining.remove(partner)
    return True


def _fuzzy(label: str, keys: list[str]) -> str | None:
    if _CJK.search(label):
        return None  # one character changes the meaning (営業利益 / 経常利益): exact matches only
    for match in difflib.get_close_matches(label, keys, n=3, cutoff=0.88):
        if _tokens_correspond(label, match):
            return match
    return None


_CASH_AT = re.compile(
    r"^(?:net )?cash & cash equivalents(?: \(?net of (?:bank )?overdrafts\)?)? (?:at|as at|as of) (?:the )?(.+)$"
)
_MONTH = r"(?:january|february|march|april|may|june|july|august|september|october|november|december)"


def _cash_balance(label_key: str) -> str | None:
    """'Cash and cash equivalents at 31 December' closes the period; 'at 1 January' opens it."""
    m = _CASH_AT.match(label_key)
    if not m:
        return None
    when = m.group(1)
    if re.match(rf"(end|close)\b|(2[89]|3[01]) {_MONTH}|{_MONTH} (2[89]|3[01])\b", when):
        return "cash_ending"
    if re.match(rf"(beginning|start)\b|1 {_MONTH}|{_MONTH} 1\b", when):
        return "cash_beginning"
    return None


def _prefix_match(raw_label: str, index: dict[str, list[str]], allowed: set[str]) -> list[str]:
    """'Profit for the year being total comprehensive income' → 'profit for the year'. Longest prefix first."""
    cuts = [m.start() for m in _CUTS.finditer(raw_label)]
    for position in reversed(cuts):
        key = normalise_label(raw_label[:position])
        if len(key) < 4:
            continue
        matches = [i for i in index.get(key, []) if i in allowed]
        if matches:
            return matches
    return []


def map_located(
    doc: DocumentContent,
    located: dict[str, list[LocatedTable]],
    taxonomy: Taxonomy,
) -> tuple[list[Candidate], list[UnmappedRow], list[str]]:
    index = taxonomy.synonym_index()
    warnings: list[str] = []
    candidates: list[Candidate] = []
    unmapped: list[UnmappedRow] = []
    for statement, tables in located.items():
        allowed = {c.id for c in taxonomy.concepts if c.statement in (statement, "memo")}
        keys = [k for k, ids in index.items() if any(i in allowed for i in ids)]
        seen: set[tuple[str, str]] = set()
        for loc in tables:
            table: Table = doc.tables[loc.table_index]
            if table.scale is None:
                warnings.append(
                    f"Page {table.page}: no unit statement found (e.g. 'in millions'); figures were read as "
                    "units. Check the scale before accepting."
                )
            period_columns = [c for c in table.columns if c.period is not None and c.period.kind != "projection"]
            if not period_columns:
                warnings.append(f"Page {table.page}: no period headers recognised; this table was skipped.")
                continue
            for r_index, row in enumerate(table.rows):
                label_key = normalise_label(row.label)
                matches = [i for i in index.get(label_key, []) if i in allowed]
                mapping = "exact"
                if not matches and statement == "cash_flow" and _cash_balance(label_key):
                    matches = [_cash_balance(label_key) or ""]
                if not matches:
                    matches = _prefix_match(row.label, index, allowed)
                    mapping = "prefix"
                if not matches:
                    fuzzy = _fuzzy(label_key, keys)
                    if fuzzy:
                        matches = [i for i in index[fuzzy] if i in allowed]
                        mapping = "fuzzy"
                values = {c.key: row.cells[c.key].raw for c in period_columns if c.key in row.cells}
                if len(matches) != 1:
                    unmapped.append(
                        UnmappedRow(
                            label=row.label,
                            page=table.page,
                            statement=statement,
                            values=values,
                            candidates=matches,
                            table_index=loc.table_index,
                            row_index=r_index,
                            reason="Several line items match this label."
                            if matches
                            else "No line item matches this label.",
                        )
                    )
                    continue
                concept = taxonomy.concept(matches[0])
                for column in period_columns:
                    cell = row.cells.get(column.key)
                    if cell is None or cell.value is None:
                        continue
                    period_key = column.period.key if column.period else column.key
                    if (concept.id, period_key) in seen:
                        continue  # first occurrence on the statement face wins (later ones are sub-totals or notes)
                    seen.add((concept.id, period_key))
                    notes: list[str] = []
                    factor = table.scale.factor if table.scale and concept.unit == "currency" else 1.0
                    value = cell.value * factor
                    if concept.sign == "negative":
                        value = -abs(value)
                    elif concept.sign == "positive" and value < 0:
                        value = abs(value)
                        notes.append("Shown with a minus sign in the source (presentation); recorded as positive.")
                    confidence = SOURCE_CONFIDENCE.get(table.source, 0.7) * MAPPING_FACTOR[mapping]
                    if table.scale is None and concept.unit == "currency":
                        confidence *= 0.7
                        notes.append("No unit statement found; read as units.")
                    if loc.consolidated is False:
                        notes.append("Parent-company (not consolidated) statement.")
                    if table.source == "ocr":
                        notes.append("Read with OCR from a scanned page; check it against the image.")
                    candidates.append(
                        Candidate(
                            concept_id=concept.id,
                            period_key=period_key,
                            value=value,
                            value_as_written=cell.raw,
                            label=row.label,
                            page=table.page,
                            statement=statement,
                            method="table_rules",
                            mapping=mapping,
                            confidence=round(confidence, 3),
                            bbox=cell.bbox,
                            cell_ref=cell.ref,
                            sheet=table.sheet,
                            scale_factor=factor,
                            scale_label=table.scale.label if table.scale else None,
                            rationale=f"Row “{row.label}” matched {concept.name} ({mapping} synonym match).",
                            notes=notes,
                        )
                    )
    return candidates, unmapped, warnings


# ── confidence from reconciliation (brief §5.2 step 10) ──────────────────────────
CHECK_CONCEPTS = {
    "balance_sheet_balances": ["total_assets", "total_liabilities_and_equity", "total_liabilities", "total_equity"],
    "cash_roll_forward": ["cash_beginning", "cash_ending", "net_change_in_cash", "fx_effect"],
    "cash_ties_to_balance_sheet": ["cash_ending", "cash"],
    "net_income_ties": ["net_income", "cf_net_income"],
}
RECONCILED_BONUS = 0.1
FAILED_FACTOR = 0.8


def adjust_for_reconciliation(candidates: list[Candidate], taxonomy: Taxonomy) -> None:
    """Values that tie out in a passing check gain confidence; values in a failing check lose some and say why.

    Only the engine does the arithmetic; this decides which candidates each check speaks for.
    """
    from dealscout_engine.reconciliation import run_checks
    from dealscout_engine.statements import FinancialData

    best: dict[tuple[str, str], Candidate] = {}
    for c in candidates:
        key = (c.concept_id, c.period_key)
        if key not in best or c.confidence > best[key].confidence:
            best[key] = c
    data = FinancialData(taxonomy)
    for (concept_id, period_key), c in best.items():
        data.values[(concept_id, period_key)] = c.value
    periods = sorted({p for _, p in best})
    rounding = max((c.scale_factor for c in best.values()), default=1.0)
    passed: dict[tuple[str, str], str] = {}
    failed: dict[tuple[str, str], str] = {}
    for check in run_checks(data, periods, rounding_unit=rounding):
        if check.status not in ("pass", "fail"):
            continue
        if check.check_id.startswith("subtotal:"):
            parent = check.check_id.split(":", 1)[1]
            involved = [parent, *taxonomy.concept(parent).components]
        elif check.check_id.startswith("sign:"):
            involved = [check.check_id.split(":", 1)[1]]
        else:
            involved = CHECK_CONCEPTS.get(check.check_id, [])
        for concept_id in involved:
            key = (concept_id, check.period_id)
            if key not in best:
                continue
            if check.status == "pass":
                passed.setdefault(key, check.label)
            else:
                failed.setdefault(key, check.message)
    for key, c in best.items():
        if key in failed:
            c.confidence = round(c.confidence * FAILED_FACTOR, 3)
            c.notes.append(f"Reconciliation: {failed[key]}")
        elif key in passed:
            c.confidence = round(min(0.99, c.confidence + RECONCILED_BONUS), 3)
            c.notes.append(f"Reconciles: {passed[key]}")
