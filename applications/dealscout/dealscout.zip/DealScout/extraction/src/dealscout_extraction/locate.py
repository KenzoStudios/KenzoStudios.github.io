"""Find the primary statements by search, not by position (brief §5.2 step 4).

Each table is scored against statement signatures — headings in many languages plus the number of its row labels
that match that statement's concepts. Consolidated statements are preferred over parent-only ones; which was used is
recorded.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from dealscout_engine.taxonomy import Taxonomy, normalise_label

from .model import DocumentContent, Table

HEADINGS: dict[str, list[str]] = {
    "income_statement": [
        "income statement",
        "statement of income",
        "statement of profit or loss",
        "statement of profit and loss",
        "profit and loss account",
        "statement of comprehensive income",
        "statements of operations",
        "statement of operations",
        "gewinn- und verlustrechnung",
        "gewinn und verlustrechnung",
        "guv",
        "cuenta de pérdidas y ganancias",
        "cuenta de resultados",
        "estado de resultados",
        "compte de résultat",
        "conto economico",
        "損益計算書",
        "損益及び包括利益計算書",
        "statement of profit or loss and other comprehensive income",
        "demonstração do resultado",
        "winst-en-verliesrekening",
    ],
    "balance_sheet": [
        "balance sheet",
        "statement of financial position",
        "statements of financial position",
        "bilanz",
        "konzernbilanz",
        "balance de situación",
        "estado de situación financiera",
        "bilan",
        "stato patrimoniale",
        "situazione patrimoniale-finanziaria",
        "貸借対照表",
        "財政状態計算書",
        "balanço patrimonial",
        "balans",
    ],
    "cash_flow": [
        "cash flow statement",
        "statement of cash flows",
        "statements of cash flows",
        "cash flows statement",
        "kapitalflussrechnung",
        "cashflow-rechnung",
        "cash-flow-rechnung",
        "estado de flujos de efectivo",
        "tableau des flux de trésorerie",
        "rendiconto finanziario",
        "キャッシュ・フロー計算書",
        "demonstração dos fluxos de caixa",
        "kasstroomoverzicht",
    ],
    "equity": [
        "statement of changes in equity",
        "eigenkapitalveränderungsrechnung",
        "estado de cambios en el patrimonio neto",
        "tableau de variation des capitaux propres",
        "prospetto delle variazioni del patrimonio netto",
        "株主資本等変動計算書",
    ],
}
CONSOLIDATED = [
    "consolidated",
    "group",
    "konzern",
    "consolidado",
    "consolidada",
    "consolidados",
    "consolidé",
    "consolidés",
    "consolidato",
    "連結",
    "consolidada",
]
STANDALONE = [
    "parent company",
    "company balance sheet",
    "company statement",
    "einzelabschluss",
    "jahresabschluss der",
    "individual",
    "separate financial",
    "société mère",
    "単体",
    "standalone",
    "company only",
    "sociedad dominante",
]


@dataclass
class LocatedTable:
    statement: str
    table_index: int
    page: int
    score: float
    consolidated: bool | None
    reasons: list[str] = field(default_factory=list)


def _statement_of(concept_statement: str) -> str:
    return concept_statement


def locate_statements(
    doc: DocumentContent, taxonomy: Taxonomy, *, prefer_consolidated: bool = True
) -> dict[str, list[LocatedTable]]:
    index = taxonomy.synonym_index()
    scored: dict[str, list[LocatedTable]] = {s: [] for s in ("income_statement", "balance_sheet", "cash_flow")}
    for t_index, table in enumerate(doc.tables):
        page = doc.page(table.page)
        top = (table.heading + " " + (page.text[:800] if page else "")).lower()
        consolidated = (
            True if any(k in top for k in CONSOLIDATED) else (False if any(k in top for k in STANDALONE) else None)
        )
        row_hits: dict[str, int] = {s: 0 for s in scored}
        for row in table.rows:
            for concept_id in index.get(normalise_label(row.label), []):
                concept_statement = taxonomy.concept(concept_id).statement
                if concept_statement in row_hits:
                    row_hits[concept_statement] += 1
                    break
        for statement in scored:
            reasons: list[str] = []
            score = float(row_hits[statement])
            heading_hit = next((h for h in HEADINGS[statement] if h in top), None)
            if heading_hit:
                score += 6
                reasons.append(f"heading “{heading_hit}”")
            if row_hits[statement]:
                reasons.append(f"{row_hits[statement]} matching line items")
            if score < 3 or row_hits[statement] < 2:
                continue
            if consolidated is True and prefer_consolidated:
                score += 3
                reasons.append("consolidated")
            elif consolidated is False:
                score -= 5
                reasons.append("parent-company only")
            # a page about another statement is unlikely to be this one
            other_hits = max((row_hits[s] for s in scored if s != statement), default=0)
            score -= 0.5 * other_hits
            scored[statement].append(
                LocatedTable(
                    statement=statement,
                    table_index=t_index,
                    page=table.page,
                    score=score,
                    consolidated=consolidated,
                    reasons=reasons,
                )
            )
    result: dict[str, list[LocatedTable]] = {}
    for statement, items in scored.items():
        items.sort(key=lambda x: x.score, reverse=True)
        if not items:
            continue
        best = items[0]
        chosen = [best]
        # statements often continue over two pages (assets, then equity and liabilities; or the last lines of
        # an income statement). A continuation page carries the same statement's line items and no heading of
        # its own for another statement.
        # A spread or two-column page can hold the continuation on the same page.
        for other in items[1:]:
            offset = other.page - best.page
            if offset not in (-1, 0, 1) or other.consolidated not in (best.consolidated, None):
                continue
            own_heading_elsewhere = _other_heading(doc, other, statement)
            if (other.score >= 0.6 * best.score and (offset != 0 or not own_heading_elsewhere)) or (
                offset in (0, 1) and not own_heading_elsewhere
            ):
                chosen.append(other)
                break
        result[statement] = chosen
    return result


def _other_heading(doc: DocumentContent, located: LocatedTable, statement: str) -> bool:
    table = doc.tables[located.table_index]
    top = table.heading.lower()
    return any(h in top for s, headings in HEADINGS.items() if s != statement for h in headings)


def table_by_index(doc: DocumentContent, located: LocatedTable) -> Table:
    return doc.tables[located.table_index]
