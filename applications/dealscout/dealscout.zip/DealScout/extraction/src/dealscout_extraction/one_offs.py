"""AI-suggested one-off items for adjusted EBITDA / EBIT (brief §7).

The AI only *finds* candidate one-offs (restructuring, impairments, litigation, disposal gains, deal costs) and
copies each amount as printed, with its page. Code then verifies that the printed amount is on that page, parses it
with the document's conventions and unit statement, and returns suggestions that the analyst must confirm before
they change any figure. Nothing the AI returns becomes a number without passing these checks.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from pydantic import BaseModel, Field

from dealscout_ai import AIProvider, PageText, Usage

from .ai_extract import _page_contains, build_content
from .model import DocumentContent
from .numbers import detect_scale, parse_number, parse_period_header

PROMPT_VERSION = "dealscout-oneoffs-2026-11-v1"

# words that announce non-recurring items, by language (lower case; matched as substrings of the page text)
ONE_OFF_TERMS = (
    # English
    "restructuring",
    "impairment",
    "write-down",
    "write-off",
    "litigation",
    "settlement",
    "exceptional",
    "non-recurring",
    "one-off",
    "one-time",
    "gain on disposal",
    "loss on disposal",
    "gain on sale",
    "transaction costs",
    "acquisition-related",
    "integration costs",
    "special items",
    "adjusting items",
    # German
    "restrukturierung",
    "wertminderung",
    "sondereffekt",
    "einmaleffekt",
    "rechtsstreit",
    "veräußerungsgewinn",
    # Spanish
    "reestructuración",
    "deterioro",
    "litigio",
    "no recurrente",
    "extraordinari",
    "enajenación",
    # French
    "restructuration",
    "dépréciation",
    "litige",
    "non courant",
    "non récurrent",
    "cession",
    # Italian / Portuguese / Dutch
    "ristrutturazione",
    "svalutazion",
    "reestruturação",
    "imparidade",
    "reorganisatie",
    "bijzondere waardevermindering",
    # Japanese
    "特別損失",
    "特別利益",
    "減損",
    "構造改革",
    "事業再編",
)

SYSTEM_ONE_OFFS = (
    "You help an investment analyst normalise a company's earnings. From the pages provided, list items the company "
    "itself presents or describes as one-off, exceptional, non-recurring or special: restructuring costs, asset "
    "impairments, litigation charges or settlements, gains or losses on disposals, and acquisition or transaction "
    "costs. Rules you must follow:\n"
    "1. Report only amounts that are printed on the pages provided. Copy each amount exactly as printed "
    "(value_as_written) with the page number, the label as printed and the unit statement that applies "
    "(e.g. 'EUR million', 'in Tsd. EUR', '百万円').\n"
    "2. Never calculate, add up, convert or estimate. If an item is mentioned without an amount, leave it out.\n"
    "3. effect is 'cost' when the item reduced reported profit and 'gain' when it increased it.\n"
    "4. below_ebitda is true when the item sits below EBITDA (impairments and amortisation of assets usually do).\n"
    "5. Use the period column header or year as printed (e.g. '2025', 'FY24').\n"
    "6. Give a one-sentence rationale citing why the company treats it as non-recurring. Do not include recurring "
    "items such as ordinary depreciation, regular share-based pay or routine fees."
)

Category = Literal["restructuring", "impairment", "litigation", "disposal_gain", "transaction_costs", "other"]


class AIOneOff(BaseModel):
    label: str
    category: Category
    effect: Literal["cost", "gain"]
    period: str | None
    value_as_written: str | None
    page: int | None
    unit_scale: str | None
    below_ebitda: bool
    rationale: str
    confidence: float = Field(ge=0, le=1)


class AIOneOffResult(BaseModel):
    items: list[AIOneOff]


@dataclass
class OneOffSuggestion:
    label: str
    category: Category
    period_key: str
    amount: float  # effect on reported profit, absolute units: a cost is negative, a gain positive
    affects_ebitda: bool
    page: int
    value_as_written: str
    scale_label: str | None
    rationale: str
    confidence: float


@dataclass
class OneOffOutcome:
    suggestions: list[OneOffSuggestion] = field(default_factory=list)
    rejected: list[dict[str, str]] = field(default_factory=list)
    usage: list[Usage] = field(default_factory=list)
    pages: list[int] = field(default_factory=list)


def select_one_off_pages(doc: DocumentContent, *, limit: int = 8) -> list[int]:
    """Pages that mention the most one-off terms (pages without text are skipped)."""
    scores: dict[int, int] = {}
    for page in doc.pages:
        low = page.text.lower()
        hits = sum(1 for term in ONE_OFF_TERMS if term in low)
        if hits:
            scores[page.page] = hits
    return sorted(sorted(scores, key=lambda p: (-scores[p], p))[:limit])


def suggest_one_offs(
    provider: AIProvider,
    original: bytes | None,
    doc: DocumentContent,
    *,
    page_limit: int = 8,
) -> OneOffOutcome:
    outcome = OneOffOutcome()
    pages = select_one_off_pages(doc, limit=page_limit)
    outcome.pages = pages
    if not pages:
        return outcome
    content = build_content(original, doc, pages, provider.capabilities())
    content.append(
        PageText(
            page=0,
            source_name="request",
            text="List the one-off items with printed amounts for every period shown. Return an empty list if none.",
        )
    )
    result = provider.extract_structured(content, AIOneOffResult, instructions=SYSTEM_ONE_OFFS, max_tokens=8000)
    outcome.usage.append(result.usage)
    decimal_hint = "," if doc.language in {"de", "es", "fr", "it", "pt", "nl"} else "." if doc.language else None
    seen: set[tuple[str, str, float]] = set()
    for item in result.value.items:
        if not item.value_as_written:
            continue

        def reject(reason: str, item: AIOneOff = item) -> None:
            outcome.rejected.append({"label": item.label, "value": item.value_as_written or "", "reason": reason})

        period = parse_period_header(item.period or "")
        if period is None:
            reject(f"Period “{item.period}” not recognised.")
            continue
        cited = item.page if item.page in pages else None
        page_number = cited if cited and _page_contains(doc.page(cited).text, item.value_as_written) else None  # type: ignore[union-attr]
        if page_number is None:
            page_number = next((p for p in pages if _page_contains(doc.page(p).text, item.value_as_written)), None)  # type: ignore[union-attr]
        if page_number is None:
            reject("The amount does not appear on the pages sent; rejected (never invented).")
            continue
        parsed = parse_number(item.value_as_written, decimal_hint=decimal_hint)  # type: ignore[arg-type]
        if parsed.value is None:
            reject("Not a number.")
            continue
        page_text = doc.page(page_number).text  # type: ignore[union-attr]
        scale = detect_scale(item.unit_scale or "") or detect_scale(page_text[:2000])
        magnitude = abs(parsed.value) * (scale.factor if scale else 1.0)
        amount = -magnitude if item.effect == "cost" else magnitude
        key = (period.key, item.label.strip().lower(), round(amount, 2))
        if key in seen:
            continue
        seen.add(key)
        outcome.suggestions.append(
            OneOffSuggestion(
                label=item.label[:200],
                category=item.category,
                period_key=period.key,
                amount=amount,
                affects_ebitda=not item.below_ebitda,
                page=page_number,
                value_as_written=item.value_as_written,
                scale_label=scale.label if scale else None,
                rationale=item.rationale[:1000],
                confidence=round(min(item.confidence, 0.9), 3),
            )
        )
    return outcome
