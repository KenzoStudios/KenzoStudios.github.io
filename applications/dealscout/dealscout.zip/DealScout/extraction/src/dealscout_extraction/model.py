"""Format-neutral representation of a document's content, positions included (for source highlighting)."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from .numbers import PeriodGuess, Scale

BBox = tuple[float, float, float, float]  # x0, y0, x1, y1 in PDF points (top-left origin)
DocKind = Literal["pdf", "xlsx", "xls", "csv", "docx", "html", "xbrl", "zip", "image", "unknown"]


class Word(BaseModel):
    text: str
    bbox: BBox


class PageContent(BaseModel):
    page: int  # 1-based physical page number (or sheet index for spreadsheets)
    name: str | None = None  # sheet name for spreadsheets
    width: float = 0
    height: float = 0
    text: str = ""
    words: list[Word] = Field(default_factory=list)
    is_scanned: bool = False
    ocr: bool = False  # words and text come from OCR


class TableCell(BaseModel):
    raw: str
    value: float | None
    bbox: BBox | None = None
    ref: str | None = None  # spreadsheet cell reference, e.g. "C12"


class TableColumn(BaseModel):
    key: str  # period key (FY2025 …) or a positional key (col3) when no period was recognised
    raw: str
    period: PeriodGuess | None = None
    x_right: float | None = None


class TableRow(BaseModel):
    label: str
    label_bbox: BBox | None = None
    cells: dict[str, TableCell] = Field(default_factory=dict)  # column key -> cell
    indent: float = 0.0
    ref: str | None = None


class Table(BaseModel):
    page: int
    sheet: str | None = None
    columns: list[TableColumn]
    rows: list[TableRow]
    scale: Scale | None = None
    heading: str = ""
    source: Literal["pdf_layout", "excel", "csv", "docx", "html", "ocr"] = "pdf_layout"
    tags: list[str] = Field(default_factory=list)  # inline XBRL element names tagged inside this table


class DocumentContent(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    kind: DocKind
    pages: list[PageContent] = Field(default_factory=list)
    tables: list[Table] = Field(default_factory=list)
    page_count: int = 0
    scanned_pages: int = 0
    language: str | None = None
    warnings: list[str] = Field(default_factory=list)
    report_member: str | None = None  # ESEF package: the inline XBRL report inside the ZIP
    entity_name: str | None = None
    currency: str | None = None
    inline: Any = Field(default=None, exclude=True)  # ixbrl.InlineReport for tagged filings

    def page(self, number: int) -> PageContent | None:
        return next((p for p in self.pages if p.page == number), None)
