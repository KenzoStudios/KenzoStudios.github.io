"""Locale- and format-agnostic number, scale and period parsing (brief §5.2 step 7).

These functions never guess silently: ambiguous inputs return ``None`` (or are flagged) so the caller can ask.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from datetime import date
from typing import Literal

DecimalHint = Literal[".", ","] | None

_FOOTNOTE = re.compile(r"(\(\s*[a-z\d]{1,2}\s*\)|\[\s*\d{1,2}\s*\]|[*†‡§¹²³⁴⁵⁶⁷⁸⁹⁰]+)$", re.IGNORECASE)
_CURRENCY = re.compile(r"(?i)(eur|usd|gbp|chf|jpy|inr|cny|rmb|aud|cad|sek|nok|dkk|brl|mxn|zar|[€$£¥₹₩]|kr|rs\.?)")
_LEADING_MARK = re.compile(r"^\s*(?:※\s*[０-９]+(?:[、,]\s*[０-９]+)*\s*|※\s*\d{1,2}\s+|\*\d\s+)")  # ※１331,129
_JP_DATE = re.compile(r"(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日")
_DASHES = {"-", "–", "—", "−", "‒", "―", "－"}
_NULLS = {"n/a", "na", "n.a.", "nm", "n.m.", "", "…", "...", "—/—"}
_ZEROS = {"nil", "none", "0"}


@dataclass(frozen=True)
class ParsedNumber:
    value: float | None
    raw: str
    is_percent: bool = False
    ambiguous: bool = False
    note: str | None = None


def _normalise(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    text = text.replace(" ", " ").replace(" ", " ").replace(" ", " ").replace("’", "'")
    return text.strip()


def parse_number(text: str, *, decimal_hint: DecimalHint = None) -> ParsedNumber:
    """Parse one cell. ``decimal_hint`` resolves cases like ``1.234`` (thousands in DE, decimals in US)."""
    raw = text
    s = _normalise(_LEADING_MARK.sub("", str(text)))  # footnote markers go before NFKC joins "１" to the digits
    if s.lower() in _NULLS:
        return ParsedNumber(None, raw, note="empty or not available")
    if s in _DASHES or s.lower() in _ZEROS:
        return ParsedNumber(0.0, raw, note="dash or nil means zero" if s not in {"0"} else None)

    negative = False
    if s.startswith("(") and s.endswith(")"):
        negative, s = True, s[1:-1].strip()
    s = _FOOTNOTE.sub("", s).strip()
    if s.startswith("(") and s.endswith(")"):
        negative, s = True, s[1:-1].strip()
    if s[:1] in {"▲", "△", "-", "−", "–"}:
        negative, s = True, s[1:].strip()
    if s.endswith("-") or s.endswith("−"):
        negative, s = True, s[:-1].strip()
    is_percent = s.endswith("%")
    s = s.rstrip("%").strip()
    s = _CURRENCY.sub("", s).strip()
    s = re.sub(r"(?i)(?<=\d)\s?(mn|mio|bn|m|k)\.?$", "", s)  # scale suffix glued to the number (scale set separately)
    s = s.replace("'", "").replace(" ", "")
    if not s or not re.fullmatch(r"[\d.,]+", s):
        return ParsedNumber(None, raw, note="not a number")

    ambiguous = False
    if "," in s and "." in s:
        decimal = "," if s.rfind(",") > s.rfind(".") else "."
        thousands = "." if decimal == "," else ","
        s = s.replace(thousands, "").replace(decimal, ".")
    elif "," in s or "." in s:
        sep = "," if "," in s else "."
        groups = s.split(sep)
        looks_grouped = len(groups) > 1 and all(len(g) == 3 for g in groups[1:]) and 1 <= len(groups[0]) <= 3
        if len(groups) > 2:  # repeated separator can only be thousands
            s = s.replace(sep, "")
        elif looks_grouped:
            if decimal_hint == sep:
                s = s.replace(sep, ".")
            elif decimal_hint is None and sep == ".":
                ambiguous = True  # "1.234": thousands (DE) or 1.234 (US)? default to thousands only with a hint
                s = s.replace(sep, ".")
            else:
                s = s.replace(sep, "")
        else:
            s = s.replace(sep, ".")
    try:
        value = float(s)
    except ValueError:
        return ParsedNumber(None, raw, note="not a number")
    if negative:
        value = -value
    if is_percent:
        value = value / 100
    return ParsedNumber(
        value,
        raw,
        is_percent=is_percent,
        ambiguous=ambiguous,
        note="'1.234'-style value: set the decimal separator to confirm" if ambiguous else None,
    )


# ── scale ────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Scale:
    factor: float
    label: str
    matched: str


_SCALE_PATTERNS: list[tuple[str, float, str]] = [
    (
        r"\bin\s+billions?\b|\bbn\b|\bmrd\.?\b|\bmilliarden\b|\bmil\s+millones\b|\bmilliards?\b|\bbilhões\b",
        1e9,
        "billions",
    ),
    (r"亿元|亿", 1e8, "hundred millions (亿)"),
    (
        r"\bin\s+millions?\b|(?:\b(?:eur|usd|gbp|chf)|[€$£])\s?m(?:n|io)?\b|\bm(?:n|io)\.?\s?(?:eur|usd|gbp|chf|€|\$|£)?(?:\s|$)"
        r"|\bmillones\b|\bmillions\b|\bmilioni\b|\bmillion\b|\bmilhões\b|\bmiljoen\b|\bmln\b",
        1e6,
        "millions",
    ),
    (r"百万円|百万", 1e6, "millions (百万)"),
    (r"\bcrores?\b|\bcr\.?\b", 1e7, "crore"),
    (r"\blakhs?\b|\blacs?\b", 1e5, "lakh"),
    (
        r"\bin\s+thousands?\b|(?:\b(?:eur|usd|gbp|chf)|[€$£])\s?(?:k|000s?|'000)\b|\btsd\.?|\btausend\b|\bmiles\b"
        r"|\bmilliers\b|\bmigliaia\b|\bthousands\b|\b000s\b|'000|\bt\s?€|\bteur\b|\bk€|\bkeur\b|\btchf\b"
        r"|\bmilhares\b|\bduizenden\b|\bx\s?(?:€|eur)?\s?1[.,\s]?000\b",
        1e3,
        "thousands",
    ),
    (r"千円|千元", 1e3, "thousands (千)"),
    (r"万元", 1e4, "ten thousands (万)"),
    (r"单位\s*[:：]\s*(?:人民币)?元", 1.0, "units (元)"),
]


def detect_scale(text: str) -> Scale | None:
    """Detect a scale statement such as 'in millions', '€m', 'in Mio. EUR', 'en miles de euros', '百万円', '₹ crore'."""
    s = _normalise(text).lower()
    for pattern, factor, label in _SCALE_PATTERNS:
        m = re.search(pattern, s)
        if m:
            return Scale(factor=factor, label=label, matched=m.group(0))
    return None


# ── periods ──────────────────────────────────────────────────────────────────
PeriodKind = Literal["annual", "half_year", "quarter", "ytd", "projection"]


@dataclass(frozen=True)
class PeriodGuess:
    key: str
    kind: PeriodKind
    fiscal_year: int
    end: date | None
    raw: str


_MONTHS = {
    m: i + 1 for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])
}
_ERAS = {"令和": 2018, "平成": 1988}


def _year(token: str) -> int | None:
    value = int(token)
    if value < 100:
        value += 2000
    return value if 1950 <= value <= 2100 else None


def _month_end(year: int, month: int) -> date:
    if month == 12:
        return date(year, 12, 31)
    return date(year, month + 1, 1).fromordinal(date(year, month + 1, 1).toordinal() - 1)


def parse_period_header(text: str) -> PeriodGuess | None:
    raw = text
    s = _normalise(text)
    low = s.lower().replace("’", "'")
    projection = bool(re.search(r"\d\s*[ef]\b|\bbudget\b|\bforecast\b|\bplan\b", low))
    if re.match(r"^[(（]?\s*自", s) and "至" not in s:
        return None  # "(自 2025年1月1日" is the start of a period; its end date follows on the next line
    jp_dates = _JP_DATE.findall(s)
    if jp_dates:
        jy, jm, jd = (int(x) for x in jp_dates[-1])  # "自 … 至 2025年12月31日" → the end date
        try:
            jp_end: date | None = date(jy, jm, jd)
        except ValueError:
            jp_end = None
        return PeriodGuess(key=f"FY{jy}", kind="annual", fiscal_year=jy, end=jp_end, raw=raw)
    era = re.search(r"(令和|平成)\s*(\d{1,2}|元)\s*年度?", s)
    if era:
        n = 1 if era.group(2) == "元" else int(era.group(2))
        fy = _ERAS[era.group(1)] + n
        return PeriodGuess(key=f"FY{fy}", kind="annual", fiscal_year=fy, end=None, raw=raw)
    m = re.search(r"\b(\d{1,2})\s?[./-]\s?(\d{1,2})\s?[./-]\s?(\d{2,4})\b", low)  # 31.12.2025, 31. 12. 2025
    if m:
        a, b, y = int(m.group(1)), int(m.group(2)), _year(m.group(3))
        day, month = (a, b) if a > 12 or (b <= 12 and a > b) else (b, a) if b > 12 else (a, b)
        if y and 1 <= month <= 12:
            try:
                end = date(y, month, day)
            except ValueError:
                end = None
            return PeriodGuess(key=f"FY{y}", kind="annual", fiscal_year=y, end=end, raw=raw)
    m = re.search(r"\b(h[12]|[1-4]q|q[1-4]|9m|6m|3m)\s*'?(\d{2,4})\b", low) or re.search(
        r"\b(\d{2,4})\s*(h[12]|q[1-4])\b", low
    )
    if m:
        part, yr = (m.group(1), m.group(2)) if not m.group(1).isdigit() else (m.group(2), m.group(1))
        y = _year(yr)
        if y:
            part = part.upper().replace("1Q", "Q1").replace("2Q", "Q2").replace("3Q", "Q3").replace("4Q", "Q4")
            kind: PeriodKind = "half_year" if part.startswith("H") else "quarter" if part.startswith("Q") else "ytd"
            return PeriodGuess(key=f"{part}-{y}", kind=kind, fiscal_year=y, end=None, raw=raw)
    m = re.search(
        r"\b(?:fy|ej|gj|ex|exercice|ejercicio|geschäftsjahr|esercizio|fiscal(?: year)?)\s*'?(\d{2,4})(?:/(\d{2,4}))?\b",
        low,
    )
    if m:
        y = _year(m.group(2) or m.group(1))
        if y:
            return PeriodGuess(
                key=f"FY{y}", kind="projection" if projection else "annual", fiscal_year=y, end=None, raw=raw
            )
    # "January 31, 2026" (US) and "31 January 2026" (UK/EU): a full date, before the "Dec-25" pattern below
    m = re.search(
        r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2}),?\s+(\d{4})\b", low
    ) or re.search(r"\b(\d{1,2})\.?\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?,?\s+(\d{4})\b", low)
    if m:
        groups = m.groups()
        month_text, day_text = (groups[0], groups[1]) if not groups[0].isdigit() else (groups[1], groups[0])
        y = _year(groups[2])
        if y:
            try:
                full_end: date | None = date(y, _MONTHS[month_text], int(day_text))
            except ValueError:
                full_end = None
            return PeriodGuess(key=f"FY{y}", kind="annual", fiscal_year=y, end=full_end, raw=raw)
    m = re.search(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[-\s']+(\d{2,4})\b", low)
    if m:
        y = _year(m.group(2))
        if y:
            return PeriodGuess(
                key=f"FY{y}", kind="annual", fiscal_year=y, end=_month_end(y, _MONTHS[m.group(1)]), raw=raw
            )
    m = re.fullmatch(r"\s*(\d{4})\s*([ae])?\s*", low)
    if m:
        y = _year(m.group(1))
        if y:
            return PeriodGuess(
                key=f"FY{y}", kind="projection" if m.group(2) == "e" else "annual", fiscal_year=y, end=None, raw=raw
            )
    return None
