#!/usr/bin/env bash
# DealScout — one start command (macOS / Linux).
# Checks prerequisites, installs dependencies on first run, rebuilds the web app if it changed,
# then serves everything at http://127.0.0.1:8000 and opens your browser. Ctrl+C stops it.
set -euo pipefail
cd "$(dirname "$0")"

os="$(uname -s)"
hint() { # $1 = mac command, $2 = linux command
  if [ "$os" = "Darwin" ]; then echo "    $1"; else echo "    $2"; fi
}

missing=0
if ! command -v uv >/dev/null 2>&1; then
  echo "✗ uv is not installed (it manages Python and DealScout's Python packages). Install it with:"
  hint "brew install uv" "curl -LsSf https://astral.sh/uv/install.sh | sh"
  missing=1
fi
if ! command -v node >/dev/null 2>&1; then
  echo "✗ Node.js 20+ is not installed (needed to build the web interface). Install it with:"
  hint "brew install node" "sudo apt install nodejs npm   # or use https://nodejs.org"
  missing=1
else
  node_major="$(node -p 'process.versions.node.split(".")[0]')"
  if [ "$node_major" -lt 20 ]; then
    echo "✗ Node.js $node_major found; DealScout needs Node.js 20 or newer. Upgrade with:"
    hint "brew upgrade node" "see https://nodejs.org"
    missing=1
  fi
fi
if [ "$missing" -ne 0 ]; then
  echo "Install the missing prerequisites above, then run ./start.sh again."
  exit 1
fi
if ! command -v tesseract >/dev/null 2>&1; then
  echo "ℹ Optional: Tesseract is not installed, so scanned (image-only) pages can't be read."
  hint "brew install tesseract tesseract-lang" "sudo apt install tesseract-ocr tesseract-ocr-all"
fi

echo "→ Installing / checking Python dependencies (uv installs Python 3.12 automatically if needed)…"
uv sync --all-packages --frozen --quiet

echo "→ Checking the web interface build…"
uv run --frozen python scripts/web_build.py

echo "→ Starting DealScout at http://127.0.0.1:${DEALSCOUT_PORT:-8000}  (Ctrl+C to stop)"
exec uv run --frozen dealscout
