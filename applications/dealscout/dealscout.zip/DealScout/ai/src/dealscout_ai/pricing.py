"""Per-token prices used for *estimated* cost. Prices change: each entry carries its source and as-of date.

Unknown models return ``None`` (shown as "cost unknown"), never a guess.
"""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Price:
    input_per_mtok: float
    output_per_mtok: float
    cache_read_per_mtok: float | None
    source: str
    as_of: str


_ANTHROPIC_SOURCE = "Anthropic API pricing (claude-api skill model table)"
_ANTHROPIC_AS_OF = "2026-11-03"

PRICES: dict[tuple[str, str], Price] = {
    ("anthropic", "claude-opus-5-5"): Price(4.00, 20.00, 0.20, _ANTHROPIC_SOURCE, _ANTHROPIC_AS_OF),
    ("anthropic", "claude-sonnet-5-5"): Price(2.00, 10.00, 0.10, _ANTHROPIC_SOURCE, _ANTHROPIC_AS_OF),
    ("anthropic", "claude-haiku-5-5"): Price(0.10, 0.50, None, _ANTHROPIC_SOURCE, _ANTHROPIC_AS_OF),
    ("anthropic", "claude-fable-5-2"): Price(8.00, 40.00, 0.20, _ANTHROPIC_SOURCE, _ANTHROPIC_AS_OF),
    ("anthropic", "claude-opus-5"): Price(5.00, 25.00, None, _ANTHROPIC_SOURCE, _ANTHROPIC_AS_OF),
    ("anthropic", "claude-sonnet-5"): Price(2.00, 10.00, None, _ANTHROPIC_SOURCE, _ANTHROPIC_AS_OF),
    ("anthropic", "claude-opus-4-8"): Price(5.00, 25.00, None, _ANTHROPIC_SOURCE, _ANTHROPIC_AS_OF),
    ("anthropic", "claude-sonnet-4-6"): Price(3.00, 15.00, None, _ANTHROPIC_SOURCE, _ANTHROPIC_AS_OF),
    ("anthropic", "claude-haiku-4-5"): Price(1.00, 5.00, None, _ANTHROPIC_SOURCE, _ANTHROPIC_AS_OF),
}

_OPENAI_SOURCE = "developers.openai.com/api/docs/pricing (Standard tier)"
_AZURE_SOURCE = "azure.microsoft.com/pricing/details/azure-openai (Global deployment)"
_GEMINI_SOURCE = "aistudio.google.com/docs/pricing (paid tier)"
_FETCHED = "2026-11-20"

PRICES.update(
    {
        ("openai", "gpt-6.2-astra"): Price(8.00, 40.00, 0.40, _OPENAI_SOURCE, _FETCHED),
        ("openai", "gpt-6.2-sol"): Price(2.00, 10.00, 0.10, _OPENAI_SOURCE, _FETCHED),
        ("openai", "gpt-6.1-terra"): Price(1.00, 5.00, 0.05, _OPENAI_SOURCE, _FETCHED),
        ("openai", "gpt-6-luna"): Price(0.10, 0.50, 0.01, _OPENAI_SOURCE, _FETCHED),
        # Azure prices are per model; the deployment's served model name is looked up.
        ("azure_openai", "gpt-6-astra"): Price(10.00, 50.00, 1.00, _AZURE_SOURCE, _FETCHED),
        ("azure_openai", "gpt-6.1-sol"): Price(2.00, 10.00, 0.10, _AZURE_SOURCE, _FETCHED),
        ("azure_openai", "gpt-6.1-terra"): Price(1.00, 5.00, 0.05, _AZURE_SOURCE, _FETCHED),
        ("azure_openai", "gpt-6-luna"): Price(0.10, 0.50, 0.01, _AZURE_SOURCE, _FETCHED),
        # gemini-4-carbon: introductory 2.00/10.00 runs to 2026-11-30; the standard price from 2026-12-01 is used.
        ("gemini", "gemini-4-carbon"): Price(
            4.00, 20.00, 0.20, _GEMINI_SOURCE + "; standard from 2026-12-01", _FETCHED
        ),
        ("gemini", "gemini-4-neon"): Price(3.00, 15.00, 0.15, _GEMINI_SOURCE, _FETCHED),
        ("gemini", "gemini-4-hydrogen"): Price(1.50, 7.50, 0.075, _GEMINI_SOURCE, _FETCHED),
        ("gemini", "gemini-3.5-flash-lite"): Price(0.30, 2.50, 0.03, _GEMINI_SOURCE, _FETCHED),
    }
)

_XAI_SOURCE = "docs.x.ai/developers/pricing (prompts under 200k tokens; longer prompts cost double)"
_PERPLEXITY_SOURCE = "docs.perplexity.ai/docs/getting-started/pricing (Agent API, no tools)"
PRICES.update(
    {
        ("xai", "grok-4.7"): Price(2.00, 6.00, 0.50, _XAI_SOURCE, _FETCHED),
        ("xai", "grok-4.6"): Price(2.00, 6.00, 0.50, _XAI_SOURCE, _FETCHED),
        ("xai", "grok-4.5"): Price(2.00, 6.00, 0.30, _XAI_SOURCE, _FETCHED),
        ("xai", "grok-4.3"): Price(1.25, 2.50, 0.20, _XAI_SOURCE, _FETCHED),
        ("xai", "grok-4.20-0309-non-reasoning"): Price(1.25, 2.50, 0.20, _XAI_SOURCE, _FETCHED),
        ("perplexity", "perplexity/sonar"): Price(0.25, 2.50, 0.0625, _PERPLEXITY_SOURCE, _FETCHED),
        ("perplexity", "anthropic/claude-sonnet-5-5"): Price(2.00, 10.00, 0.10, _PERPLEXITY_SOURCE, _FETCHED),
        ("perplexity", "anthropic/claude-haiku-5-5"): Price(0.10, 0.50, 0.01, _PERPLEXITY_SOURCE, _FETCHED),
        ("perplexity", "openai/gpt-5.6-sol"): Price(4.00, 20.00, 0.40, _PERPLEXITY_SOURCE, _FETCHED),
        ("perplexity", "openai/gpt-5.6-luna"): Price(0.20, 1.20, 0.02, _PERPLEXITY_SOURCE, _FETCHED),
    }
)

# Cache writes: Anthropic ~1.25x input (5-minute TTL); OpenAI/Azure GPT-5.6+ 1.25x (30-minute TTL); Gemini's
# implicit caching has no write charge.
CACHE_WRITE_MULTIPLIER = {
    "anthropic": 1.25,
    "openai": 1.25,
    "azure_openai": 1.25,
    "gemini": 1.0,
    "xai": 1.0,
    "perplexity": 1.25,
}
# When a cache-read price is not listed, reads are billed at ~0.1x input.
CACHE_READ_FALLBACK_MULTIPLIER = {
    "anthropic": 0.10,
    "openai": 0.10,
    "azure_openai": 0.10,
    "gemini": 0.10,
    "xai": 0.25,
    "perplexity": 0.10,
}
_DATED = re.compile(r"-(\d{4}-\d{2}-\d{2}|\d{8}|\d{3})$")


def price_for(provider: str, model: str) -> Price | None:
    """Exact model first, then without a version suffix ("gpt-6.1-sol-2026-03-11", "gemini-4-hydrogen-001")."""
    name = model.removeprefix("models/")
    return PRICES.get((provider, name)) or PRICES.get((provider, _DATED.sub("", name)))


def estimate_cost(
    provider: str,
    model: str,
    *,
    input_tokens: int,
    output_tokens: int,
    cache_read_tokens: int = 0,
    cache_write_tokens: int = 0,
) -> float | None:
    price = price_for(provider, model)
    if price is None:
        return None
    read_price = price.cache_read_per_mtok
    if read_price is None:
        read_price = price.input_per_mtok * CACHE_READ_FALLBACK_MULTIPLIER.get(provider, 1.0)
    write_price = price.input_per_mtok * CACHE_WRITE_MULTIPLIER.get(provider, 1.0)
    cost = (
        input_tokens * price.input_per_mtok
        + output_tokens * price.output_per_mtok
        + cache_read_tokens * read_price
        + cache_write_tokens * write_price
    ) / 1_000_000
    return round(cost, 6)
