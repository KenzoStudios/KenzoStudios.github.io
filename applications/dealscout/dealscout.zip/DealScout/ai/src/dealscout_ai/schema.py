"""JSON-schema helpers: turn a Pydantic model into a schema every structured-output API accepts.

Strict structured-output modes (Anthropic, OpenAI) require ``additionalProperties: false`` on every object
and every property listed in ``required``; several reject numeric/string constraints. We generate the
schema from the Pydantic model, inline ``$ref``s, and strip unsupported keywords. The Pydantic model
itself is still used to validate the answer client-side, so no constraint is lost.
"""

from __future__ import annotations

import copy
from typing import Any

from pydantic import BaseModel

_UNSUPPORTED = {
    "minimum",
    "maximum",
    "exclusiveMinimum",
    "exclusiveMaximum",
    "multipleOf",
    "minLength",
    "maxLength",
    "pattern",
    "minItems",
    "maxItems",
    "uniqueItems",
    "default",
    "title",
    "examples",
    "format",
}
_KEEP_FORMATS = {"date-time", "time", "date", "duration", "email", "hostname", "uri", "ipv4", "ipv6", "uuid"}


def strict_json_schema(model: type[BaseModel]) -> dict[str, Any]:
    raw = model.model_json_schema()
    defs = raw.pop("$defs", {})
    return _clean(_inline(raw, defs))


def _inline(node: Any, defs: dict[str, Any]) -> Any:
    if isinstance(node, dict):
        if "$ref" in node:
            name = node["$ref"].split("/")[-1]
            target = copy.deepcopy(defs[name])
            extra = {k: v for k, v in node.items() if k != "$ref"}
            target.update(extra)
            return _inline(target, defs)
        return {k: _inline(v, defs) for k, v in node.items()}
    if isinstance(node, list):
        return [_inline(v, defs) for v in node]
    return node


def _clean(node: Any) -> Any:
    if isinstance(node, list):
        return [_clean(v) for v in node]
    if not isinstance(node, dict):
        return node
    out: dict[str, Any] = {}
    for key, value in node.items():
        if key == "format" and value in _KEEP_FORMATS:
            out[key] = value
            continue
        if key in _UNSUPPORTED:
            continue
        if key == "properties":
            out[key] = {name: _clean(prop) for name, prop in value.items()}
        else:
            out[key] = _clean(value)
    if out.get("type") == "object" or "properties" in out:
        out["type"] = "object"
        out["additionalProperties"] = False
        out["required"] = list(out.get("properties", {}).keys())
    return out
