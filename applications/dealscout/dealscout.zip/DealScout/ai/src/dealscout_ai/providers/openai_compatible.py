"""xAI (Grok) and Perplexity adapters: Responses-style APIs reached with the official ``openai`` SDK.

Facts checked against the official documentation on 2026-11-20 (see docs/providers.md):

* **xAI** — ``https://api.x.ai/v1``; the Responses API is preferred (Chat Completions is marked legacy). Structured
  output through ``text.format`` (strict JSON schema). Images as ``input_image`` data URLs (PNG/JPEG). PDFs only as
  uploaded files or URLs, not inline, so documents go as page text plus page images. API data is kept 30 days for
  abuse auditing and is not used for training without permission.
* **Perplexity** — the Sonar Chat Completions API reached end of life on 2026-09-27; the Agent API is reached with
  ``responses.create`` at ``https://api.perplexity.ai/v1``. Models are named ``provider/model``. A request with no
  ``tools`` and no ``effort`` answers from the model alone, **without web search**, which is what document
  extraction needs. Structured output is ``response_format`` (``json_schema``), passed through ``extra_body``; the
  first request with a new schema can take 10–30 s. Usage reports cache tokens under its own names and an actual
  ``cost``. Out of credit is HTTP 402.
"""

from __future__ import annotations

import re
from typing import Any

import openai

from ..base import ProviderConfig
from ..pricing import estimate_cost, price_for
from ..types import Capabilities, ModelInfo, Usage
from .openai import OpenAIProvider, _map_error

XAI_BASE_URL = "https://api.x.ai/v1"
XAI_DEFAULT_MODEL = "grok-4.7"
PERPLEXITY_BASE_URL = "https://api.perplexity.ai/v1"
PERPLEXITY_DEFAULT_MODEL = "anthropic/claude-sonnet-5-5"
_GROK = re.compile(r"^grok-")


class XAIProvider(OpenAIProvider):
    provider_id = "xai"

    def _base_url(self) -> str | None:
        return self.config.base_url or XAI_BASE_URL

    def _extra_request(self) -> dict[str, Any]:
        return {"store": False}

    def capabilities(self) -> Capabilities:
        return Capabilities(
            native_pdf=False,  # inline PDFs are not accepted; page text + page images instead
            image_input=True,
            structured_output="strict",
            prompt_caching=True,
            max_context_tokens=500_000 if self.model.startswith("grok-4.7") else None,
        )

    def list_models(self) -> list[ModelInfo]:
        try:
            models = list(self._client.models.list())
        except openai.APIError as error:
            raise _map_error(error, self.provider_id) from error
        result = []
        for model_id in sorted({m.id for m in models if _GROK.match(m.id) and "image" not in m.id}):
            price = price_for(self.provider_id, model_id)
            result.append(
                ModelInfo(
                    id=model_id,
                    display_name=model_id,
                    capabilities=Capabilities(image_input=True, structured_output="strict", prompt_caching=True),
                    input_price_per_mtok=price.input_per_mtok if price else None,
                    output_price_per_mtok=price.output_per_mtok if price else None,
                    recommended=model_id == XAI_DEFAULT_MODEL,
                )
            )
        return result


class PerplexityProvider(OpenAIProvider):
    provider_id = "perplexity"

    def __init__(self, config: ProviderConfig, *, http_client: Any | None = None):
        # a new schema can take 10–30 s to prepare on the first request
        super().__init__(
            config.model_copy(update={"timeout_seconds": max(config.timeout_seconds, 120.0)}), http_client=http_client
        )

    def _base_url(self) -> str | None:
        return self.config.base_url or PERPLEXITY_BASE_URL

    def _extra_request(self) -> dict[str, Any]:
        # no tools and no effort preset: the model answers from the pages sent, never from a web search
        return {}

    def _json_format(self, schema_name: str, schema: dict[str, Any]) -> dict[str, Any]:
        name = re.sub(r"[^A-Za-z0-9]", "", schema_name)[:64] or "Result"
        return {
            "extra_body": {"response_format": {"type": "json_schema", "json_schema": {"name": name, "schema": schema}}}
        }

    def capabilities(self) -> Capabilities:
        return Capabilities(native_pdf=False, image_input=True, structured_output="best_effort", prompt_caching=True)

    def list_models(self) -> list[ModelInfo]:
        try:
            models = list(self._client.models.list())  # this endpoint needs no key: it cannot test one
        except openai.APIError as error:
            raise _map_error(error, self.provider_id) from error
        result = []
        for model_id in sorted({m.id for m in models}):
            price = price_for(self.provider_id, model_id)
            result.append(
                ModelInfo(
                    id=model_id,
                    display_name=model_id,
                    capabilities=Capabilities(image_input=True, structured_output="best_effort"),
                    input_price_per_mtok=price.input_per_mtok if price else None,
                    output_price_per_mtok=price.output_per_mtok if price else None,
                    recommended=model_id == PERPLEXITY_DEFAULT_MODEL,
                )
            )
        return result

    def _usage_of(self, response: Any) -> Usage:
        usage = getattr(response, "usage", None)
        served_model = getattr(response, "model", None) or self.model
        extra = getattr(usage, "model_extra", None) or {}
        details = getattr(usage, "input_tokens_details", None)
        detail_extra = getattr(details, "model_extra", None) or {}
        total_in = int(getattr(usage, "input_tokens", 0) or 0)
        cache_read = int(detail_extra.get("cache_read_input_tokens") or 0)
        cache_write = int(detail_extra.get("cache_creation_input_tokens") or 0)
        output_tokens = int(getattr(usage, "output_tokens", 0) or 0)
        uncached = max(0, total_in - cache_read - cache_write)
        reported = (extra.get("cost") or {}).get("total_cost") if isinstance(extra.get("cost"), dict) else None
        cost = (
            float(reported)
            if reported is not None
            else estimate_cost(
                self.provider_id,
                served_model,
                input_tokens=uncached,
                output_tokens=output_tokens,
                cache_read_tokens=cache_read,
                cache_write_tokens=cache_write,
            )
        )
        return Usage(
            provider=self.provider_id,
            model=served_model,
            input_tokens=uncached,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read,
            cache_write_tokens=cache_write,
            estimated_cost_usd=cost,
        )
