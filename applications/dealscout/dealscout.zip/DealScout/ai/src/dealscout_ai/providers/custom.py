"""Custom OpenAI-compatible endpoints: company AI gateways and local models (Ollama, LM Studio, llama.cpp, vLLM).

Chat Completions is the API every compatible server implements, so this adapter uses it. Structured output support
varies: Ollama honours ``response_format`` ``json_schema`` (and silently ignores types it doesn't know), LM Studio
and llama.cpp support it, other servers answer 400/422. The adapter therefore steps down — JSON schema, then JSON
mode, then a prompt-only request — and remembers the step that worked. Every answer is validated against the same
Pydantic schema by the base class, so a weaker server can never slip an unvalidated value through.

Facts checked against the official documentation on 2026-11-20 (see docs/providers.md).
"""

from __future__ import annotations

import base64
import json
import re
from collections.abc import Sequence
from typing import Any, Literal
from urllib.parse import urlparse

import openai

from ..base import AIProvider, ProviderConfig, render_page_text
from ..types import (
    AIError,
    Capabilities,
    ConnectionResult,
    ContentPart,
    ContentRefusedError,
    ModelInfo,
    OutputTruncatedError,
    PageImage,
    PageText,
    PdfDocument,
    Usage,
)
from .openai import _map_error, _result_code

JsonMode = Literal["json_schema", "json_object", "prompt"]
_VISION = re.compile(r"vision|llava|[-_.]vl\b|[-_.]vl[-_:.]|gemma3|minicpm-v|qwen2\.5vl|pixtral|llama3\.2-vision", re.I)
_LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1", "[::1]", "0.0.0.0"}


class CustomOpenAIProvider(AIProvider):
    provider_id = "custom"

    def __init__(self, config: ProviderConfig, *, http_client: Any | None = None):
        super().__init__(config)
        if not config.base_url:
            raise ValueError("A custom endpoint needs its base URL, e.g. http://localhost:11434/v1 for Ollama.")
        kwargs: dict[str, Any] = {
            # many local servers need no key, but the SDK requires a value
            "api_key": config.api_key.get_secret_value() if config.api_key else "not-needed",
            "base_url": config.base_url,
            "max_retries": config.max_retries,
            "timeout": config.timeout_seconds,
        }
        if http_client is not None:
            kwargs["http_client"] = http_client
        self._client = openai.OpenAI(**kwargs)
        self._json_mode: JsonMode = "json_schema"
        host = (urlparse(config.base_url).hostname or "").lower()
        self._local = host in _LOCAL_HOSTS or host.endswith(".local")

    # ── capabilities ──────────────────────────────────────────────────
    def capabilities(self) -> Capabilities:
        return Capabilities(
            native_pdf=False,
            image_input=bool(_VISION.search(self.model)),  # only models known for vision get page images
            structured_output="best_effort",
        )

    # ── primitives ────────────────────────────────────────────────────
    def _complete_json(
        self,
        *,
        system: str,
        content: Sequence[ContentPart],
        schema: dict[str, Any],
        schema_name: str,
        max_tokens: int,
    ) -> tuple[str, Usage]:
        parts = self._parts(content)
        modes: list[JsonMode] = ["json_schema", "json_object", "prompt"]
        for mode in modes[modes.index(self._json_mode) :]:
            instruction = f"Return a single JSON object matching the {schema_name} schema."
            if mode != "json_schema":
                instruction += f" The schema is:\n{json.dumps(schema)}\nReply with JSON only, no prose."
            kwargs: dict[str, Any] = {
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": [*parts, {"type": "text", "text": instruction}]},
                ],
                "max_tokens": max_tokens,
            }
            if mode == "json_schema":
                kwargs["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {"name": schema_name, "schema": schema, "strict": True},
                }
            elif mode == "json_object":
                kwargs["response_format"] = {"type": "json_object"}
            try:
                response = self._create(**kwargs)
            except (openai.BadRequestError, openai.UnprocessableEntityError):
                if mode == "prompt":
                    raise
                continue  # this server does not support the mode: step down
            self._json_mode = mode
            return self._text_of(response), self._usage_of(response)
        raise AIError("The endpoint rejected every structured-output mode.", provider=self.provider_id)

    def _complete_text(self, *, system: str, prompt: str, max_tokens: int) -> tuple[str, Usage]:
        response = self._create(
            messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}],
            max_tokens=max_tokens,
        )
        return self._text_of(response), self._usage_of(response)

    # ── connection ────────────────────────────────────────────────────
    def test_connection(self) -> ConnectionResult:
        try:
            response = self._create(
                messages=[{"role": "user", "content": "Reply with the single word OK."}],
                max_tokens=256,
                allow_truncation=True,
                translate=True,
            )
        except AIError as error:
            return ConnectionResult(
                ok=False, provider=self.provider_id, model=self.model, code=_result_code(error), message=error.message
            )
        return ConnectionResult(
            ok=True,
            provider=self.provider_id,
            model=self.model,
            code="ok",
            message=f"Connected to {self.config.base_url} — {self.model} answered.",
            usage=self._usage_of(response),
        )

    def list_models(self) -> list[ModelInfo]:
        try:
            models = list(self._client.models.list())
        except openai.APIError as error:
            raise self._translate(error) from error
        ids = sorted({m.id for m in models})
        return [
            ModelInfo(
                id=model_id,
                display_name=model_id,
                capabilities=Capabilities(image_input=bool(_VISION.search(model_id)), structured_output="best_effort"),
                recommended=model_id == self.model or (not self.model and i == 0),
            )
            for i, model_id in enumerate(ids)
        ]

    # ── helpers ───────────────────────────────────────────────────────
    def _create(self, *, allow_truncation: bool = False, translate: bool = False, **kwargs: Any) -> Any:
        try:
            response = self._client.chat.completions.create(model=self.model, **kwargs)
        except (openai.BadRequestError, openai.UnprocessableEntityError) as error:
            mapped = self._translate(error)
            if translate or "response_format" not in kwargs or mapped.code != "error":
                raise mapped from error  # billing, refusal… are real errors, not an unsupported format
            raise  # let _complete_json step down to a simpler structured-output mode
        except openai.APIError as error:
            raise self._translate(error) from error
        choice = response.choices[0] if response.choices else None
        message = getattr(choice, "message", None)
        if message is not None and getattr(message, "refusal", None):
            raise ContentRefusedError(
                "The model declined this request. Try another model or enter these values manually.",
                provider=self.provider_id,
            )
        if getattr(choice, "finish_reason", None) == "length" and not allow_truncation:
            raise OutputTruncatedError(
                "The answer was cut off at the output token limit; the request needs a smaller page set.",
                provider=self.provider_id,
            )
        return response

    def _translate(self, error: openai.APIError) -> AIError:
        if isinstance(error, openai.APIConnectionError):
            from ..types import ProviderUnavailableError

            hint = " Is Ollama or LM Studio running?" if self._local else ""
            return ProviderUnavailableError(f"Could not reach {self.config.base_url}.{hint}", provider=self.provider_id)
        if isinstance(error, openai.NotFoundError):
            from ..types import ModelUnavailableError

            pull = f" For Ollama, run: ollama pull {self.model}" if self._local else ""
            return ModelUnavailableError(
                f"The endpoint does not have the model “{self.model}”.{pull}", provider=self.provider_id
            )
        return _map_error(error, self.provider_id)

    def _parts(self, content: Sequence[ContentPart]) -> list[dict[str, Any]]:
        parts: list[dict[str, Any]] = []
        vision = self.capabilities().image_input
        for part in content:
            if isinstance(part, PageText):
                parts.append({"type": "text", "text": render_page_text(part)})
            elif isinstance(part, PageImage) and vision:
                data = base64.standard_b64encode(part.data).decode("ascii")
                parts.append({"type": "text", "text": f"Image of source page {part.page}:"})
                parts.append({"type": "image_url", "image_url": {"url": f"data:{part.media_type};base64,{data}"}})
            elif isinstance(part, PdfDocument):
                continue  # never sent: capabilities declare no native PDF, so the pipeline sends page text
        return parts

    @staticmethod
    def _text_of(response: Any) -> str:
        choice = response.choices[0] if response.choices else None
        message = getattr(choice, "message", None)
        return (getattr(message, "content", None) or "") if message is not None else ""

    def _usage_of(self, response: Any) -> Usage:
        usage = getattr(response, "usage", None)
        prompt = int(getattr(usage, "prompt_tokens", 0) or 0)
        details = getattr(usage, "prompt_tokens_details", None)
        cached = int(getattr(details, "cached_tokens", 0) or 0)
        return Usage(
            provider=self.provider_id,
            model=getattr(response, "model", None) or self.model,
            input_tokens=max(0, prompt - cached),
            output_tokens=int(getattr(usage, "completion_tokens", 0) or 0),
            cache_read_tokens=cached,
            # a model on this computer costs nothing per call; a company gateway's price is unknown
            estimated_cost_usd=0.0 if self._local else None,
        )
