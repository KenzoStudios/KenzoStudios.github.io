"""Per-provider adapters. Vendor SDKs may only be imported inside this package."""
