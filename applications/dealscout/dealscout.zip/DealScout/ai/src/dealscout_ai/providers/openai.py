"""OpenAI and Azure OpenAI adapters (Responses API).

Facts checked against the official documentation on 2026-11-20 (see docs/providers.md):

* Responses is the recommended API for new projects; structured output uses ``text.format`` with
  ``{"type": "json_schema", "strict": true}``. Our schemas already meet the strict rules (every property
  required, ``additionalProperties: false``, no numeric/length keywords — which Azure rejects).
* PDFs go in as ``input_file`` with a base64 data URL and a filename; images as ``input_image``.
* Refusals arrive as a ``refusal`` content part; a cut-off answer has ``status == "incomplete"``.
* Billing failures are 429s too (``insufficient_quota``, ``credit_balance_exhausted``, spend limits): they must
  not be retried like rate limits.
* Azure OpenAI's v1 API takes the plain OpenAI client with ``base_url=<endpoint>/openai/v1/``; ``model`` is
  the deployment name; a retired model answers ``410 Gone``; filtered prompts are ``400 content_filter``.
* ``store=False``: responses are not kept on the provider's side for later retrieval.
"""

from __future__ import annotations

import base64
import re
from collections.abc import Sequence
from typing import Any

import openai

from ..base import AIProvider, ProviderConfig, render_page_text
from ..pricing import estimate_cost, price_for
from ..types import (
    AIError,
    Capabilities,
    ConnectionResult,
    ContentPart,
    ContentRefusedError,
    InvalidKeyError,
    ModelInfo,
    ModelUnavailableError,
    OutOfCreditError,
    OutputTruncatedError,
    PageImage,
    PageText,
    PdfDocument,
    ProviderUnavailableError,
    RateLimitedError,
    Usage,
)

DEFAULT_MODEL = "gpt-6.2-sol"
# Families documented with a 1,050,000-token context and 128,000 output tokens, PDF/image input and
# structured outputs (developers.openai.com/api/docs/models, 2026-11-20).
_GPT6 = re.compile(r"^gpt-6(\.\d+)?-(astra|sol|terra|luna)")
_BILLING_CODES = {
    "insufficient_quota",
    "credit_balance_exhausted",
    "organization_spend_limit_exceeded",
    "project_spend_limit_exceeded",
    "organization_usage_limit_exceeded",
    "billing_hard_limit_reached",
}
_LABEL = {
    "openai": "OpenAI",
    "azure_openai": "Azure OpenAI",
    "xai": "xAI",
    "perplexity": "Perplexity",
    "custom": "your endpoint",
}


class OpenAIProvider(AIProvider):
    provider_id = "openai"

    def __init__(self, config: ProviderConfig, *, http_client: Any | None = None):
        super().__init__(config)
        kwargs: dict[str, Any] = {
            "api_key": config.api_key.get_secret_value() if config.api_key else None,
            "max_retries": config.max_retries,
            "timeout": config.timeout_seconds,
            "base_url": self._base_url(),
        }
        if http_client is not None:
            kwargs["http_client"] = http_client
        self._client = openai.OpenAI(**kwargs)

    def _base_url(self) -> str | None:
        return self.config.base_url or None

    # ── capabilities ──────────────────────────────────────────────────
    def capabilities(self) -> Capabilities:
        known = bool(_GPT6.match(self.model))
        return Capabilities(
            native_pdf=True,
            image_input=True,
            structured_output="strict",
            prompt_caching=True,  # automatic above 1,024 prompt tokens
            max_context_tokens=1_050_000 if known else None,
            max_output_tokens=128_000 if known else None,
        )

    # ── primitives ────────────────────────────────────────────────────
    def _complete_json(
        self,
        *,
        system: str,
        content: Sequence[ContentPart],
        schema: dict[str, Any],
        schema_name: str,
        max_tokens: int,
    ) -> tuple[str, Usage]:
        parts = self._input_parts(content)
        parts.append({"type": "input_text", "text": f"Return a single JSON object matching the {schema_name} schema."})
        response = self._create(
            instructions=system,
            input=[{"role": "user", "content": parts}],
            max_output_tokens=max_tokens,
            **self._json_format(schema_name, schema),
        )
        return response.output_text or "", self._usage_of(response)

    def _json_format(self, schema_name: str, schema: dict[str, Any]) -> dict[str, Any]:
        """How this API asks for schema-constrained JSON (Responses ``text.format``)."""
        return {"text": {"format": {"type": "json_schema", "name": schema_name, "schema": schema, "strict": True}}}

    def _complete_text(self, *, system: str, prompt: str, max_tokens: int) -> tuple[str, Usage]:
        response = self._create(
            instructions=system,
            input=[{"role": "user", "content": [{"type": "input_text", "text": prompt}]}],
            max_output_tokens=max_tokens,
        )
        return response.output_text or "", self._usage_of(response)

    # ── connection ────────────────────────────────────────────────────
    def test_connection(self) -> ConnectionResult:
        label = _LABEL.get(self.provider_id, self.provider_id)
        try:
            response = self._create(
                instructions="Connection test.",
                input=[{"role": "user", "content": [{"type": "input_text", "text": "Reply with the single word OK."}]}],
                max_output_tokens=256,
                allow_truncation=True,
            )
        except AIError as error:
            return ConnectionResult(
                ok=False, provider=self.provider_id, model=self.model, code=_result_code(error), message=error.message
            )
        return ConnectionResult(
            ok=True,
            provider=self.provider_id,
            model=self.model,
            code="ok",
            message=f"Connected to {label} — {self.model} answered.",
            usage=self._usage_of(response),
        )

    def list_models(self) -> list[ModelInfo]:
        try:
            models = list(self._client.models.list())
        except openai.APIError as error:
            raise _map_error(error, self.provider_id) from error
        ids = sorted({m.id for m in models if _GPT6.match(m.id) or m.id.startswith(("gpt-5", "gpt-4.1", "o"))})
        result = []
        for model_id in ids:
            price = price_for(self.provider_id, model_id)
            known = bool(_GPT6.match(model_id))
            result.append(
                ModelInfo(
                    id=model_id,
                    display_name=model_id,
                    capabilities=Capabilities(
                        native_pdf=known,
                        image_input=known,
                        structured_output="strict" if known else "none",
                        prompt_caching=True,
                        max_context_tokens=1_050_000 if known else None,
                        max_output_tokens=128_000 if known else None,
                    ),
                    input_price_per_mtok=price.input_per_mtok if price else None,
                    output_price_per_mtok=price.output_per_mtok if price else None,
                    recommended=model_id == DEFAULT_MODEL,
                )
            )
        return result

    # ── helpers ───────────────────────────────────────────────────────
    def _create(self, *, allow_truncation: bool = False, **kwargs: Any) -> Any:
        if self.config.effort:
            kwargs["reasoning"] = {"effort": self.config.effort}
        try:
            response = self._client.responses.create(model=self.model, **self._extra_request(), **kwargs)
        except openai.APIError as error:
            raise _map_error(error, self.provider_id) from error
        for item in getattr(response, "output", None) or []:
            for part in getattr(item, "content", None) or []:
                if getattr(part, "type", None) == "refusal":
                    raise ContentRefusedError(
                        "The model declined this request. Try another model or enter these values manually.",
                        provider=self.provider_id,
                    )
        if getattr(response, "status", None) == "incomplete":
            reason = getattr(getattr(response, "incomplete_details", None), "reason", None)
            if reason == "content_filter":
                raise ContentRefusedError(
                    "The provider's content filter stopped the answer. Enter these values manually.",
                    provider=self.provider_id,
                )
            if not allow_truncation:
                raise OutputTruncatedError(
                    f"The answer was cut off ({reason or 'incomplete'}); the request needs a smaller page set.",
                    provider=self.provider_id,
                )
        return response

    def _extra_request(self) -> dict[str, Any]:
        """Per-provider request options; OpenAI: don't keep the response on the provider's side."""
        return {"store": False}

    def _input_parts(self, content: Sequence[ContentPart]) -> list[dict[str, Any]]:
        parts: list[dict[str, Any]] = []
        for part in content:
            if isinstance(part, PdfDocument):
                data = base64.standard_b64encode(part.data).decode("ascii")
                parts.append(
                    {
                        "type": "input_file",
                        "filename": part.source_name or "document.pdf",
                        "file_data": f"data:application/pdf;base64,{data}",
                    }
                )
                if part.first_page != 1:
                    parts.append(
                        {
                            "type": "input_text",
                            "text": f"Page 1 of the PDF above is page {part.first_page} of the source document; "
                            "cite source page numbers.",
                        }
                    )
            elif isinstance(part, PageImage):
                data = base64.standard_b64encode(part.data).decode("ascii")
                parts.append({"type": "input_text", "text": f"Image of source page {part.page}:"})
                parts.append(
                    {"type": "input_image", "image_url": f"data:{part.media_type};base64,{data}", "detail": "high"}
                )
            elif isinstance(part, PageText):
                parts.append({"type": "input_text", "text": render_page_text(part)})
        return parts

    def _usage_of(self, response: Any) -> Usage:
        usage = getattr(response, "usage", None)
        served_model = getattr(response, "model", None) or self.model
        total_in = int(getattr(usage, "input_tokens", 0) or 0)
        details = getattr(usage, "input_tokens_details", None)
        cached = int(getattr(details, "cached_tokens", 0) or 0)
        written = int(getattr(details, "cache_write_tokens", 0) or 0)
        output_tokens = int(getattr(usage, "output_tokens", 0) or 0)  # includes reasoning tokens
        # input_tokens counts cached and cache-write tokens too; bill each part at its own rate
        uncached = max(0, total_in - cached - written)
        return Usage(
            provider=self.provider_id,
            model=served_model,
            input_tokens=uncached,
            output_tokens=output_tokens,
            cache_read_tokens=cached,
            cache_write_tokens=written,
            estimated_cost_usd=estimate_cost(
                self.provider_id,
                served_model,
                input_tokens=uncached,
                output_tokens=output_tokens,
                cache_read_tokens=cached,
                cache_write_tokens=written,
            ),
        )


class AzureOpenAIProvider(OpenAIProvider):
    """Azure OpenAI through the v1 API: the company's own resource, region and deployment."""

    provider_id = "azure_openai"

    def __init__(self, config: ProviderConfig, *, http_client: Any | None = None):
        if not (config.endpoint or config.base_url):
            raise ValueError("Azure OpenAI needs the resource endpoint, e.g. https://<resource>.openai.azure.com")
        if config.deployment and not config.model:
            config = config.model_copy(update={"model": config.deployment})
        super().__init__(config, http_client=http_client)

    def _base_url(self) -> str | None:
        root = (self.config.base_url or self.config.endpoint or "").rstrip("/")
        return root if root.endswith("/openai/v1") else f"{root}/openai/v1"

    def capabilities(self) -> Capabilities:
        # The model behind a deployment name is unknown, and only image-capable deployments accept PDF files:
        # send page text plus page images, which every current vision deployment reads.
        return Capabilities(native_pdf=False, image_input=True, structured_output="strict", prompt_caching=True)

    def list_models(self) -> list[ModelInfo]:
        # /openai/v1/models lists models Azure offers, not this resource's deployments: show the deployment.
        return [
            ModelInfo(
                id=self.model,
                display_name=f"{self.model} (your deployment)",
                capabilities=self.capabilities(),
                recommended=True,
            )
        ]


def _retry_after(error: openai.APIStatusError) -> float | None:
    try:
        return float(error.response.headers.get("retry-after", "") or 0) or None
    except (AttributeError, ValueError):
        return None


def _map_error(error: openai.APIError, provider: str) -> AIError:
    """Map SDK exceptions (most specific first) to the provider-neutral error taxonomy."""
    label = _LABEL.get(provider, provider)
    message = getattr(error, "message", str(error))
    code = str(getattr(error, "code", "") or "")
    kind = str(getattr(error, "type", "") or "")
    lowered = message.lower()
    billing = (
        code in _BILLING_CODES
        or kind in _BILLING_CODES
        or any(
            word in lowered
            for word in ("credit balance", "insufficient_quota", "exceeded your current quota", "billing")
        )
    )
    if isinstance(error, openai.AuthenticationError):
        return InvalidKeyError(f"{label} rejected the API key (invalid or revoked).", provider=provider)
    if isinstance(error, openai.PermissionDeniedError):
        return InvalidKeyError(f"This {label} key is not allowed to do this: {message}", provider=provider)
    if isinstance(error, openai.NotFoundError):
        what = "deployment" if provider == "azure_openai" else "model"
        return ModelUnavailableError(
            f"The selected {what} is not available to this key (retired, misspelt or not enabled). Pick another.",
            provider=provider,
        )
    if isinstance(error, openai.RateLimitError):
        if billing:
            return OutOfCreditError(
                f"Your {label} account is out of credit or over its spend limit. Add credit or raise the limit, "
                "then resume.",
                provider=provider,
            )
        return RateLimitedError(
            f"{label} rate limit reached; the job will retry automatically.",
            provider=provider,
            retry_after=_retry_after(error),
        )
    if isinstance(error, openai.BadRequestError):
        if code == "content_filter":
            return ContentRefusedError(
                f"{label}'s content filter blocked this request. Enter these values manually.", provider=provider
            )
        if billing:
            return OutOfCreditError(
                f"Your {label} credit balance is too low. Add credit, then resume.", provider=provider
            )
        return AIError(f"{label} rejected the request: {message}", provider=provider)
    if isinstance(error, openai.APIStatusError):
        if error.status_code == 402:
            return OutOfCreditError(
                f"Your {label} account is out of credit. Add credit, then resume.", provider=provider
            )
        if error.status_code == 410:
            return ModelUnavailableError(
                f"The model behind this {label} deployment has been retired. Redeploy a current model.",
                provider=provider,
            )
        if error.status_code >= 500:
            return ProviderUnavailableError(
                f"{label} is temporarily unavailable or overloaded; the job will retry.", provider=provider
            )
        return AIError(f"{label} error {error.status_code}: {message}", provider=provider)
    if isinstance(error, openai.APIConnectionError):
        return ProviderUnavailableError(
            f"Could not reach {label}. Check your internet connection, proxy or endpoint address.", provider=provider
        )
    return AIError(message, provider=provider)


def _result_code(error: AIError) -> Any:
    known = {"invalid_key", "out_of_credit", "model_unavailable", "rate_limited", "unreachable"}
    return error.code if error.code in known else "error"
