"""Google Gemini adapter (``google-genai`` SDK, ``generateContent``).

Facts checked against the official documentation on 2026-11-20 (see docs/providers.md):

* Structured output: ``response_mime_type="application/json"`` with ``response_json_schema``; keywords outside
  Gemini's subset are stripped silently, so the answer is always validated against the Pydantic model.
* PDFs and images go in inline as ``Part.from_bytes``; PDF text is extracted at no extra token charge.
* ``generateContent`` is still supported; Google recommends the newer Interactions API for new projects. We
  use ``generateContent`` because its request and response are fully typed in the SDK; moving is a follow-up.
* Errors: ``errors.ClientError`` (4xx) / ``errors.ServerError`` (5xx) with ``.code`` and ``.status``. An
  invalid key is a 400 ``INVALID_ARGUMENT`` (API_KEY_INVALID) or 401/403. Connection failures and timeouts are
  raw ``httpx2`` exceptions. The SDK makes a single attempt unless ``retry_options`` is set.
* Usage: ``prompt_token_count`` includes cached tokens; output is billed including thinking tokens.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import httpx2
from google import genai
from google.genai import errors as genai_errors
from google.genai import types as genai_types

from ..base import AIProvider, ProviderConfig, render_page_text
from ..pricing import estimate_cost, price_for
from ..types import (
    AIError,
    Capabilities,
    ConnectionResult,
    ContentPart,
    ContentRefusedError,
    InvalidKeyError,
    ModelInfo,
    ModelUnavailableError,
    OutOfCreditError,
    OutputTruncatedError,
    PageImage,
    PageText,
    PdfDocument,
    ProviderUnavailableError,
    RateLimitedError,
    Usage,
)

DEFAULT_MODEL = "gemini-4-hydrogen"
_REFUSAL_REASONS = {"SAFETY", "PROHIBITED_CONTENT", "BLOCKLIST", "SPII", "RECITATION", "IMAGE_SAFETY"}


class GeminiProvider(AIProvider):
    provider_id = "gemini"

    def __init__(self, config: ProviderConfig, *, http_client: Any | None = None):
        super().__init__(config)
        options: dict[str, Any] = {
            "timeout": int(config.timeout_seconds * 1000),  # milliseconds
            "retry_options": genai_types.HttpRetryOptions(attempts=max(1, config.max_retries + 1)),
        }
        if config.base_url:
            options["base_url"] = config.base_url
        if http_client is not None:
            options["httpx_client"] = http_client
        self._client = genai.Client(
            api_key=config.api_key.get_secret_value() if config.api_key else None,
            http_options=genai_types.HttpOptions(**options),
        )

    # ── capabilities ──────────────────────────────────────────────────
    def capabilities(self) -> Capabilities:
        lite = "flash-lite" in self.model
        return Capabilities(
            native_pdf=True,
            image_input=True,
            structured_output="strict",
            prompt_caching=True,  # implicit caching above 4,096 prompt tokens
            max_context_tokens=1_048_576,
            max_output_tokens=65_536 if lite else None,
        )

    # ── primitives ────────────────────────────────────────────────────
    def _complete_json(
        self,
        *,
        system: str,
        content: Sequence[ContentPart],
        schema: dict[str, Any],
        schema_name: str,
        max_tokens: int,
    ) -> tuple[str, Usage]:
        parts = self._parts(content)
        parts.append(genai_types.Part.from_text(text=f"Return a single JSON object matching the {schema_name} schema."))
        config = genai_types.GenerateContentConfig(
            system_instruction=system,
            max_output_tokens=max_tokens,
            response_mime_type="application/json",
            response_json_schema=schema,
        )
        response = self._generate(parts, config)
        return _text_of(response), self._usage_of(response)

    def _complete_text(self, *, system: str, prompt: str, max_tokens: int) -> tuple[str, Usage]:
        config = genai_types.GenerateContentConfig(system_instruction=system, max_output_tokens=max_tokens)
        response = self._generate([genai_types.Part.from_text(text=prompt)], config)
        return _text_of(response), self._usage_of(response)

    # ── connection ────────────────────────────────────────────────────
    def test_connection(self) -> ConnectionResult:
        try:
            config = genai_types.GenerateContentConfig(system_instruction="Connection test.", max_output_tokens=1024)
            response = self._generate(
                [genai_types.Part.from_text(text="Reply with the single word OK.")], config, allow_truncation=True
            )
        except AIError as error:
            known = {"invalid_key", "out_of_credit", "model_unavailable", "rate_limited", "unreachable"}
            return ConnectionResult(
                ok=False,
                provider=self.provider_id,
                model=self.model,
                code=error.code if error.code in known else "error",
                message=error.message,
            )
        return ConnectionResult(
            ok=True,
            provider=self.provider_id,
            model=self.model,
            code="ok",
            message=f"Connected to Google Gemini — {self.model} answered.",
            usage=self._usage_of(response),
        )

    def list_models(self) -> list[ModelInfo]:
        try:
            models = list(self._client.models.list())
        except (genai_errors.APIError, httpx2.HTTPError) as error:
            raise _map_error(error) from error
        result = []
        for m in models:
            model_id = (m.name or "").removeprefix("models/")
            actions = m.supported_actions or []
            if not model_id.startswith("gemini") or "generateContent" not in actions:
                continue
            price = price_for(self.provider_id, model_id)
            result.append(
                ModelInfo(
                    id=model_id,
                    display_name=m.display_name or model_id,
                    capabilities=Capabilities(
                        native_pdf=True,
                        image_input=True,
                        structured_output="strict",
                        prompt_caching=True,
                        max_context_tokens=m.input_token_limit,
                        max_output_tokens=m.output_token_limit,
                    ),
                    input_price_per_mtok=price.input_per_mtok if price else None,
                    output_price_per_mtok=price.output_per_mtok if price else None,
                    recommended=model_id == DEFAULT_MODEL,
                )
            )
        return result

    # ── helpers ───────────────────────────────────────────────────────
    def _generate(
        self,
        parts: list[genai_types.Part],
        config: genai_types.GenerateContentConfig,
        *,
        allow_truncation: bool = False,
    ) -> genai_types.GenerateContentResponse:
        try:
            response = self._client.models.generate_content(
                model=self.model, contents=[genai_types.Content(role="user", parts=parts)], config=config
            )
        except (genai_errors.APIError, httpx2.HTTPError) as error:
            raise _map_error(error) from error
        feedback = response.prompt_feedback
        if feedback is not None and feedback.block_reason:
            raise ContentRefusedError(
                f"Gemini blocked this request ({feedback.block_reason}). Enter these values manually.",
                provider=self.provider_id,
            )
        candidate = response.candidates[0] if response.candidates else None
        reason = str(getattr(candidate, "finish_reason", "") or "").split(".")[-1]
        if reason in _REFUSAL_REASONS:
            raise ContentRefusedError(
                f"Gemini stopped the answer ({reason.lower()}). Try another model or enter these values manually.",
                provider=self.provider_id,
            )
        if reason == "MAX_TOKENS" and not allow_truncation:
            raise OutputTruncatedError(
                "The answer was cut off at the output token limit; the request needs a smaller page set.",
                provider=self.provider_id,
            )
        return response

    @staticmethod
    def _parts(content: Sequence[ContentPart]) -> list[genai_types.Part]:
        parts: list[genai_types.Part] = []
        for part in content:
            if isinstance(part, PdfDocument):
                parts.append(genai_types.Part.from_bytes(data=part.data, mime_type="application/pdf"))
                if part.first_page != 1:
                    parts.append(
                        genai_types.Part.from_text(
                            text=f"Page 1 of the PDF above is page {part.first_page} of the source document; "
                            "cite source page numbers."
                        )
                    )
            elif isinstance(part, PageImage):
                parts.append(genai_types.Part.from_text(text=f"Image of source page {part.page}:"))
                parts.append(genai_types.Part.from_bytes(data=part.data, mime_type=part.media_type))
            elif isinstance(part, PageText):
                parts.append(genai_types.Part.from_text(text=render_page_text(part)))
        return parts

    def _usage_of(self, response: genai_types.GenerateContentResponse) -> Usage:
        meta = response.usage_metadata
        served_model = response.model_version or self.model
        prompt = int(getattr(meta, "prompt_token_count", 0) or 0)
        cached = int(getattr(meta, "cached_content_token_count", 0) or 0)
        output = int(getattr(meta, "candidates_token_count", 0) or 0) + int(
            getattr(meta, "thoughts_token_count", 0) or 0
        )
        uncached = max(0, prompt - cached)
        return Usage(
            provider=self.provider_id,
            model=served_model,
            input_tokens=uncached,
            output_tokens=output,
            cache_read_tokens=cached,
            estimated_cost_usd=estimate_cost(
                self.provider_id, served_model, input_tokens=uncached, output_tokens=output, cache_read_tokens=cached
            ),
        )


def _text_of(response: genai_types.GenerateContentResponse) -> str:
    candidate = response.candidates[0] if response.candidates else None
    content = getattr(candidate, "content", None)
    texts = [p.text for p in (getattr(content, "parts", None) or []) if getattr(p, "text", None) and not p.thought]
    return "".join(texts)


def _map_error(error: Exception) -> AIError:
    provider = "gemini"
    if isinstance(error, httpx2.HTTPError):
        return ProviderUnavailableError(
            "Could not reach Google Gemini. Check your internet connection or proxy.", provider=provider
        )
    assert isinstance(error, genai_errors.APIError)
    code = int(error.code or 0)
    status = str(error.status or "")
    message = str(error.message or error)
    lowered = message.lower()
    if code in (401, 403) or (code == 400 and ("api key" in lowered or "api_key_invalid" in lowered)):
        return InvalidKeyError("Google rejected the API key (invalid, restricted or revoked).", provider=provider)
    if code == 402 or (code == 400 and any(word in lowered for word in ("billing", "credit"))):
        return OutOfCreditError(
            "Your Google AI account has no credit or billing is not enabled. Fix it in Google AI Studio, then resume.",
            provider=provider,
        )
    if code == 404:
        return ModelUnavailableError(
            "The selected Gemini model is not available to this key (retired or misspelt). Pick another model.",
            provider=provider,
        )
    if code == 429:
        if any(word in lowered for word in ("prepay", "credit", "billing", "spend")):
            return OutOfCreditError(
                "Your Google AI spend limit or prepaid credit is used up. Raise it in Google AI Studio, then resume.",
                provider=provider,
            )
        return RateLimitedError("Gemini rate limit reached; the job will retry automatically.", provider=provider)
    if code >= 500:
        return ProviderUnavailableError(
            "Google Gemini is temporarily unavailable; the job will retry.", provider=provider
        )
    return AIError(f"Gemini rejected the request ({status or code}): {message}", provider=provider)
