"""Anthropic Claude adapter (reference provider).

Follows the claude-api skill: model IDs as published, structured output through ``output_config.format``
(forced tool choice is rejected on current models), native PDF document blocks with prompt caching, typed
SDK exceptions mapped most-specific-first, and server-side refusal fallbacks on the models that support them.
"""

from __future__ import annotations

import base64
from collections.abc import Sequence
from typing import Any

import anthropic

from ..base import AIProvider, ProviderConfig, render_page_text
from ..pricing import estimate_cost, price_for
from ..types import (
    AIError,
    Capabilities,
    ConnectionResult,
    ContentPart,
    ContentRefusedError,
    InvalidKeyError,
    ModelInfo,
    ModelUnavailableError,
    OutOfCreditError,
    OutputTruncatedError,
    PageImage,
    PageText,
    PdfDocument,
    ProviderUnavailableError,
    RateLimitedError,
    Usage,
)

DEFAULT_MODEL = "claude-opus-5-5"

# Models that accept the server-side ``fallbacks`` parameter (claude-api skill, refusal handling).
_FALLBACK_MODELS = {"claude-fable-5-2", "claude-fable-5-1", "claude-opus-5-5", "claude-opus-5", "claude-sonnet-5-5"}
_FALLBACK_BETA = "server-side-fallback-2026-07-01"
# Older models reject the effort parameter; current families accept it.
_NO_EFFORT_PREFIXES = ("claude-haiku-4", "claude-sonnet-4-5", "claude-opus-4-1", "claude-3")


class AnthropicProvider(AIProvider):
    provider_id = "anthropic"

    def __init__(self, config: ProviderConfig, *, http_client: Any | None = None):
        super().__init__(config)
        kwargs: dict[str, Any] = {
            "api_key": config.api_key.get_secret_value() if config.api_key else None,
            "max_retries": config.max_retries,
            "timeout": config.timeout_seconds,
        }
        if config.base_url:
            kwargs["base_url"] = config.base_url
        if http_client is not None:
            kwargs["http_client"] = http_client
        self._client = anthropic.Anthropic(**kwargs)

    # ── capabilities ──────────────────────────────────────────────────
    def capabilities(self) -> Capabilities:
        return Capabilities(
            native_pdf=True,
            image_input=True,
            structured_output="strict",
            prompt_caching=True,
            max_context_tokens=1_000_000 if not self.model.startswith("claude-haiku-4") else 200_000,
            max_output_tokens=128_000 if not self.model.startswith("claude-haiku-4") else 64_000,
        )

    # ── primitives ────────────────────────────────────────────────────
    def _complete_json(
        self,
        *,
        system: str,
        content: Sequence[ContentPart],
        schema: dict[str, Any],
        schema_name: str,
        max_tokens: int,
    ) -> tuple[str, Usage]:
        output_config: dict[str, Any] = {"format": {"type": "json_schema", "schema": schema}}
        effort = self.config.effort or "high"  # extraction is accuracy-sensitive
        if self._supports_effort():
            output_config["effort"] = effort
        blocks = self._content_blocks(content)
        blocks.append({"type": "text", "text": f"Return a single JSON object matching the {schema_name} schema."})
        response = self._create(
            system=system,
            messages=[{"role": "user", "content": blocks}],
            max_tokens=max_tokens,
            output_config=output_config,
        )
        return self._text_of(response), self._usage_of(response)

    def _complete_text(self, *, system: str, prompt: str, max_tokens: int) -> tuple[str, Usage]:
        output_config: dict[str, Any] = {}
        if self._supports_effort():
            output_config["effort"] = self.config.effort or "medium"
        response = self._create(
            system=system,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=max_tokens,
            output_config=output_config or None,
        )
        return self._text_of(response), self._usage_of(response)

    # ── connection ────────────────────────────────────────────────────
    def test_connection(self) -> ConnectionResult:
        try:
            self._client.models.retrieve(self.model)
            output_config = {"effort": "low"} if self._supports_effort() else None
            response = self._create(
                system="Connection test.",
                messages=[{"role": "user", "content": "Reply with the single word OK."}],
                max_tokens=256,
                output_config=output_config,
                allow_truncation=True,
            )
        except AIError as error:
            return ConnectionResult(
                ok=False, provider=self.provider_id, model=self.model, code=_result_code(error), message=error.message
            )
        except anthropic.APIError as error:  # mapped below for completeness
            mapped = _map_error(error)
            return ConnectionResult(
                ok=False, provider=self.provider_id, model=self.model, code=_result_code(mapped), message=mapped.message
            )
        return ConnectionResult(
            ok=True,
            provider=self.provider_id,
            model=self.model,
            code="ok",
            message=f"Connected to Anthropic — {self.model} answered.",
            usage=self._usage_of(response),
        )

    def list_models(self) -> list[ModelInfo]:
        try:
            models = list(self._client.models.list())
        except anthropic.APIError as error:
            raise _map_error(error) from error
        result: list[ModelInfo] = []
        for m in models:
            caps = getattr(m, "capabilities", None) or {}
            price = price_for(self.provider_id, m.id)
            result.append(
                ModelInfo(
                    id=m.id,
                    display_name=getattr(m, "display_name", m.id) or m.id,
                    capabilities=Capabilities(
                        native_pdf=bool(_leaf(caps, "pdf_input", default=True)),
                        image_input=bool(_leaf(caps, "image_input", default=True)),
                        structured_output="strict" if _leaf(caps, "structured_outputs", default=False) else "none",
                        prompt_caching=True,
                        max_context_tokens=getattr(m, "max_input_tokens", None),
                        max_output_tokens=getattr(m, "max_tokens", None),
                    ),
                    input_price_per_mtok=price.input_per_mtok if price else None,
                    output_price_per_mtok=price.output_per_mtok if price else None,
                    recommended=m.id == DEFAULT_MODEL,
                )
            )
        return result

    # ── helpers ───────────────────────────────────────────────────────
    def _supports_effort(self) -> bool:
        return not self.model.startswith(_NO_EFFORT_PREFIXES)

    def _create(
        self,
        *,
        system: str,
        messages: list[dict[str, Any]],
        max_tokens: int,
        output_config: dict[str, Any] | None,
        allow_truncation: bool = False,
    ) -> Any:
        kwargs: dict[str, Any] = {
            "model": self.model,
            "max_tokens": max_tokens,
            "system": system,
            "messages": messages,
        }
        if output_config:
            kwargs["output_config"] = output_config
        try:
            if self.model in _FALLBACK_MODELS:
                response = self._client.beta.messages.create(betas=[_FALLBACK_BETA], fallbacks="default", **kwargs)
            else:
                response = self._client.messages.create(**kwargs)
        except anthropic.APIError as error:
            raise _map_error(error) from error

        if response.stop_reason == "refusal":
            details = getattr(response, "stop_details", None)
            category = getattr(details, "category", None) if details else None
            raise ContentRefusedError(
                "The model declined this request"
                + (f" (category: {category})" if category else "")
                + ". Try another model or enter these values manually.",
                provider=self.provider_id,
            )
        if response.stop_reason == "max_tokens" and not allow_truncation:
            raise OutputTruncatedError(
                f"The answer was cut off at {max_tokens} output tokens; the request needs a smaller page set.",
                provider=self.provider_id,
            )
        return response

    def _content_blocks(self, content: Sequence[ContentPart]) -> list[dict[str, Any]]:
        blocks: list[dict[str, Any]] = []
        last_document_index: int | None = None
        for part in content:
            if isinstance(part, PdfDocument):
                blocks.append(
                    {
                        "type": "document",
                        "source": {
                            "type": "base64",
                            "media_type": "application/pdf",
                            "data": base64.standard_b64encode(part.data).decode("ascii"),
                        },
                        **({"title": part.source_name} if part.source_name else {}),
                    }
                )
                last_document_index = len(blocks) - 1
                if part.first_page != 1:
                    blocks.append(
                        {
                            "type": "text",
                            "text": f"Page 1 of the PDF above is page {part.first_page} of the source document; "
                            "cite source page numbers.",
                        }
                    )
            elif isinstance(part, PageImage):
                blocks.append({"type": "text", "text": f"Image of source page {part.page}:"})
                blocks.append(
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": part.media_type,
                            "data": base64.standard_b64encode(part.data).decode("ascii"),
                        },
                    }
                )
            elif isinstance(part, PageText):
                blocks.append({"type": "text", "text": render_page_text(part)})
        # Cache the (large, stable) document prefix so follow-up questions on the same pages are cheap.
        if last_document_index is not None:
            blocks[last_document_index]["cache_control"] = {"type": "ephemeral"}
        return blocks

    @staticmethod
    def _text_of(response: Any) -> str:
        return "".join(block.text for block in response.content if getattr(block, "type", None) == "text")

    def _usage_of(self, response: Any) -> Usage:
        usage = response.usage
        served_model = getattr(response, "model", None) or self.model
        input_tokens = int(getattr(usage, "input_tokens", 0) or 0)
        output_tokens = int(getattr(usage, "output_tokens", 0) or 0)
        cache_read = int(getattr(usage, "cache_read_input_tokens", 0) or 0)
        cache_write = int(getattr(usage, "cache_creation_input_tokens", 0) or 0)
        return Usage(
            provider=self.provider_id,
            model=served_model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read,
            cache_write_tokens=cache_write,
            estimated_cost_usd=estimate_cost(
                self.provider_id,
                served_model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cache_read_tokens=cache_read,
                cache_write_tokens=cache_write,
            ),
        )


def _leaf(caps: Any, key: str, *, default: bool) -> bool:
    node = caps.get(key) if isinstance(caps, dict) else None
    if isinstance(node, dict) and "supported" in node:
        return bool(node["supported"])
    return default


def _map_error(error: anthropic.APIError) -> AIError:
    """Map SDK exceptions (most specific first) to the provider-neutral error taxonomy."""
    provider = "anthropic"
    message = getattr(error, "message", str(error))
    if isinstance(error, anthropic.AuthenticationError):
        return InvalidKeyError("Anthropic rejected the API key (invalid or revoked).", provider=provider)
    if isinstance(error, anthropic.PermissionDeniedError):
        return InvalidKeyError(f"This API key is not allowed to do this: {message}", provider=provider)
    if isinstance(error, anthropic.PaymentRequiredError):
        return OutOfCreditError(
            "Your Anthropic account is out of credit. Add credit in the Claude Console, then resume.",
            provider=provider,
        )
    if isinstance(error, anthropic.NotFoundError):
        return ModelUnavailableError(
            "The selected model is not available to this API key (retired or not enabled). Pick another model.",
            provider=provider,
        )
    if isinstance(error, anthropic.RateLimitError):
        retry_after = None
        try:
            retry_after = float(error.response.headers.get("retry-after", "") or 0) or None
        except (AttributeError, ValueError):
            retry_after = None
        return RateLimitedError(
            "Anthropic rate limit reached; the job will retry automatically.",
            provider=provider,
            retry_after=retry_after,
        )
    if isinstance(error, anthropic.BadRequestError):
        if "credit balance" in message.lower():
            return OutOfCreditError(
                "Your Anthropic credit balance is too low. Add credit in the Claude Console, then resume.",
                provider=provider,
            )
        return AIError(f"Anthropic rejected the request: {message}", provider=provider)
    if isinstance(error, anthropic.APIStatusError):
        if error.status_code >= 500:
            return ProviderUnavailableError(
                "Anthropic is temporarily unavailable or overloaded; the job will retry.", provider=provider
            )
        return AIError(f"Anthropic error {error.status_code}: {message}", provider=provider)
    if isinstance(error, anthropic.APIConnectionError):
        return ProviderUnavailableError(
            "Could not reach Anthropic. Check your internet connection or proxy.", provider=provider
        )
    return AIError(message, provider=provider)


def _result_code(error: AIError) -> Any:
    known = {"invalid_key", "out_of_credit", "model_unavailable", "rate_limited", "unreachable"}
    return error.code if error.code in known else "error"
