"""DealScout provider-neutral AI layer.

Use :func:`create_provider` with a :class:`ProviderConfig`; call ``extract_structured``, ``generate_text``,
``test_connection`` and ``list_models``. Never import a vendor SDK outside ``dealscout_ai.providers``.
"""

from .base import AIProvider, ProviderConfig, parse_json_text
from .keystore import KeyStore, last4
from .registry import PROVIDERS, ProviderSpec, create_provider, get_spec
from .types import (
    AIDisabledError,
    AIError,
    Capabilities,
    ConnectionResult,
    ContentPart,
    ContentRefusedError,
    InvalidKeyError,
    ModelInfo,
    ModelUnavailableError,
    NotConnectedError,
    OutOfCreditError,
    OutputTruncatedError,
    PageImage,
    PageText,
    PdfDocument,
    ProviderUnavailableError,
    RateLimitedError,
    SchemaValidationError,
    SpendCapReachedError,
    StructuredResult,
    TextResult,
    Usage,
)

__all__ = [
    "PROVIDERS",
    "AIDisabledError",
    "AIError",
    "AIProvider",
    "Capabilities",
    "ConnectionResult",
    "ContentPart",
    "ContentRefusedError",
    "InvalidKeyError",
    "KeyStore",
    "ModelInfo",
    "ModelUnavailableError",
    "NotConnectedError",
    "OutOfCreditError",
    "OutputTruncatedError",
    "PageImage",
    "PageText",
    "PdfDocument",
    "ProviderConfig",
    "ProviderSpec",
    "ProviderUnavailableError",
    "RateLimitedError",
    "SchemaValidationError",
    "SpendCapReachedError",
    "StructuredResult",
    "TextResult",
    "Usage",
    "create_provider",
    "get_spec",
    "last4",
    "parse_json_text",
]
__version__ = "0.1.0"
