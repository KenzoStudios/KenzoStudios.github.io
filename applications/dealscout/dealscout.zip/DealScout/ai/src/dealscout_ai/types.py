"""Provider-neutral types shared by every AI adapter."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Generic, Literal, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T", bound=BaseModel)

StructuredMode = Literal["strict", "best_effort", "none"]


# ── content ────────────────────────────────────────────────────────────────
class PageText(BaseModel):
    """Extracted text of one page (1-based ``page``), sent with a page marker so answers can cite it."""

    kind: Literal["page_text"] = "page_text"
    page: int
    text: str
    source_name: str | None = None


class PageImage(BaseModel):
    """A rendered page image (for tables), used when the provider supports vision."""

    kind: Literal["page_image"] = "page_image"
    page: int
    media_type: Literal["image/png", "image/jpeg"] = "image/png"
    data: bytes
    source_name: str | None = None


class PdfDocument(BaseModel):
    """A native PDF (usually a slice of the located pages). ``first_page`` maps PDF page 1 to the source page."""

    kind: Literal["pdf"] = "pdf"
    data: bytes
    first_page: int = 1
    source_name: str | None = None


ContentPart = PageText | PageImage | PdfDocument


# ── capabilities, models, usage ───────────────────────────────────────────
class Capabilities(BaseModel):
    """What a provider/model can do; the extraction pipeline adapts its content strategy to these flags."""

    native_pdf: bool = False
    image_input: bool = False
    structured_output: StructuredMode = "none"
    prompt_caching: bool = False
    max_context_tokens: int | None = None
    max_output_tokens: int | None = None


class ModelInfo(BaseModel):
    id: str
    display_name: str
    capabilities: Capabilities
    input_price_per_mtok: float | None = None
    output_price_per_mtok: float | None = None
    recommended: bool = False


class Usage(BaseModel):
    """Usage of one call. ``estimated_cost_usd`` is None when the model's price is unknown."""

    provider: str
    model: str
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    estimated_cost_usd: float | None = None
    at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    def __add__(self, other: Usage) -> Usage:
        cost = (
            None
            if self.estimated_cost_usd is None or other.estimated_cost_usd is None
            else self.estimated_cost_usd + other.estimated_cost_usd
        )
        return Usage(
            provider=self.provider,
            model=other.model or self.model,
            input_tokens=self.input_tokens + other.input_tokens,
            output_tokens=self.output_tokens + other.output_tokens,
            cache_read_tokens=self.cache_read_tokens + other.cache_read_tokens,
            cache_write_tokens=self.cache_write_tokens + other.cache_write_tokens,
            estimated_cost_usd=cost,
            at=other.at,
        )


class StructuredResult(BaseModel, Generic[T]):
    value: T
    usage: Usage
    attempts: int
    provider: str
    model: str
    raw_text: str


class TextResult(BaseModel):
    text: str
    usage: Usage
    provider: str
    model: str


class ConnectionResult(BaseModel):
    ok: bool
    provider: str
    model: str | None = None
    code: Literal["ok", "invalid_key", "out_of_credit", "model_unavailable", "rate_limited", "unreachable", "error"]
    message: str
    usage: Usage | None = None


# ── errors (identical across providers) ───────────────────────────────────
class AIError(Exception):
    """Base class. ``code`` is stable and shown to the user; ``retryable`` tells the job runner what to do."""

    code = "error"
    retryable = False

    def __init__(self, message: str, *, provider: str = "", retry_after: float | None = None):
        super().__init__(message)
        self.message = message
        self.provider = provider
        self.retry_after = retry_after


class InvalidKeyError(AIError):
    code = "invalid_key"


class OutOfCreditError(AIError):
    code = "out_of_credit"


class ModelUnavailableError(AIError):
    code = "model_unavailable"


class RateLimitedError(AIError):
    code = "rate_limited"
    retryable = True


class ProviderUnavailableError(AIError):
    code = "unreachable"
    retryable = True


class ContentRefusedError(AIError):
    code = "refused"


class OutputTruncatedError(AIError):
    code = "truncated"


class SchemaValidationError(AIError):
    """The model's answer did not match the schema even after one retry with the validation errors."""

    code = "schema_invalid"


class AIDisabledError(AIError):
    code = "ai_disabled"


class SpendCapReachedError(AIError):
    code = "spend_cap_reached"


class NotConnectedError(AIError):
    code = "not_connected"
