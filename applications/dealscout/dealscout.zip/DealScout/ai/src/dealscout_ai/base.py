"""The provider-neutral AI interface.

Extraction, mapping and writing code depend only on :class:`AIProvider`. Each adapter implements two raw
primitives (``_complete_json`` / ``_complete_text``) plus ``test_connection`` and ``list_models``; the
validate-and-retry-once logic, JSON parsing and result packaging live here so every provider is held to
the same schema, validation and "never invent a number" rules.
"""

from __future__ import annotations

import json
import re
from abc import ABC, abstractmethod
from collections.abc import Sequence
from typing import Any, TypeVar

from pydantic import BaseModel, SecretStr, ValidationError

from .schema import strict_json_schema
from .types import (
    Capabilities,
    ConnectionResult,
    ContentPart,
    ModelInfo,
    PageText,
    SchemaValidationError,
    StructuredResult,
    TextResult,
    Usage,
)

T = TypeVar("T", bound=BaseModel)


class ProviderConfig(BaseModel):
    """Connection settings for one provider. Only ``api_key`` is secret; it never leaves the server."""

    provider: str
    model: str
    api_key: SecretStr | None = None
    base_url: str | None = None  # custom / OpenAI-compatible endpoints, xAI, Perplexity
    endpoint: str | None = None  # Azure OpenAI resource endpoint
    deployment: str | None = None  # Azure OpenAI deployment name
    api_version: str | None = None  # Azure OpenAI API version
    effort: str | None = None  # provider-specific reasoning effort hint, when supported
    max_retries: int = 3
    timeout_seconds: float = 600.0


class AIProvider(ABC):
    """Abstract base for every adapter. Subclasses must not do business logic — only transport."""

    provider_id: str = ""

    def __init__(self, config: ProviderConfig):
        self.config = config

    # ── provider primitives ────────────────────────────────────────────
    @abstractmethod
    def capabilities(self) -> Capabilities: ...

    @abstractmethod
    def _complete_json(
        self,
        *,
        system: str,
        content: Sequence[ContentPart],
        schema: dict[str, Any],
        schema_name: str,
        max_tokens: int,
    ) -> tuple[str, Usage]:
        """Return the model's raw JSON text for ``schema`` and the usage of the call."""

    @abstractmethod
    def _complete_text(self, *, system: str, prompt: str, max_tokens: int) -> tuple[str, Usage]: ...

    @abstractmethod
    def test_connection(self) -> ConnectionResult: ...

    @abstractmethod
    def list_models(self) -> list[ModelInfo]: ...

    # ── shared behaviour ───────────────────────────────────────────────
    @property
    def model(self) -> str:
        return self.config.model

    def extract_structured(
        self,
        content: Sequence[ContentPart],
        output_type: type[T],
        *,
        instructions: str,
        max_tokens: int = 16_000,
    ) -> StructuredResult[T]:
        """Ask for ``output_type`` as JSON; validate; on failure retry once with the validation errors."""
        schema = strict_json_schema(output_type)
        name = output_type.__name__
        raw, usage = self._complete_json(
            system=instructions, content=content, schema=schema, schema_name=name, max_tokens=max_tokens
        )
        try:
            value = output_type.model_validate(parse_json_text(raw))
            return StructuredResult[T](
                value=value, usage=usage, attempts=1, provider=self.provider_id, model=usage.model, raw_text=raw
            )
        except (ValueError, ValidationError) as first_error:
            feedback = PageText(
                page=0,
                source_name="validation feedback",
                text=(
                    "Your previous answer did not match the required JSON schema.\n"
                    f"Validation errors:\n{_error_summary(first_error)}\n"
                    f"Previous answer:\n{raw[:4000]}\n"
                    "Return corrected JSON only. Do not invent values: use null with a reason when unknown."
                ),
            )
            raw2, usage2 = self._complete_json(
                system=instructions,
                content=[*content, feedback],
                schema=schema,
                schema_name=name,
                max_tokens=max_tokens,
            )
            total = usage + usage2
            try:
                value = output_type.model_validate(parse_json_text(raw2))
            except (ValueError, ValidationError) as second_error:
                raise SchemaValidationError(
                    f"{self.provider_id}/{self.model} returned output that does not match {name} after one "
                    f"retry: {_error_summary(second_error)}",
                    provider=self.provider_id,
                ) from second_error
            return StructuredResult[T](
                value=value, usage=total, attempts=2, provider=self.provider_id, model=usage2.model, raw_text=raw2
            )

    def generate_text(
        self, prompt: str, context: str = "", *, system: str | None = None, max_tokens: int = 8_000
    ) -> TextResult:
        full_prompt = f"{context}\n\n{prompt}" if context else prompt
        text, usage = self._complete_text(
            system=system or "You are a careful financial analyst's assistant.",
            prompt=full_prompt,
            max_tokens=max_tokens,
        )
        return TextResult(text=text, usage=usage, provider=self.provider_id, model=usage.model)


_FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL)


def parse_json_text(text: str) -> Any:
    """Parse JSON from a model answer, tolerating code fences and leading prose (best-effort providers)."""
    stripped = text.strip()
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        pass
    fenced = _FENCE.search(stripped)
    if fenced:
        try:
            return json.loads(fenced.group(1).strip())
        except json.JSONDecodeError:
            pass
    start = min((i for i in (stripped.find("{"), stripped.find("[")) if i >= 0), default=-1)
    if start >= 0:
        decoder = json.JSONDecoder()
        try:
            value, _ = decoder.raw_decode(stripped[start:])
            return value
        except json.JSONDecodeError:
            pass
    raise ValueError("answer is not valid JSON")


def _error_summary(error: Exception) -> str:
    if isinstance(error, ValidationError):
        lines = [f"- {'.'.join(str(p) for p in e['loc']) or '(root)'}: {e['msg']}" for e in error.errors()[:20]]
        return "\n".join(lines)
    return f"- {error}"


def render_page_text(part: PageText) -> str:
    source = f' source="{part.source_name}"' if part.source_name else ""
    return f'<page number="{part.page}"{source}>\n{part.text}\n</page>'
