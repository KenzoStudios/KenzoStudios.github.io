"""Catalogue of supported AI providers: what each needs to connect, where to get a key, data-use policy.

The UI renders the Connect AI screen from this catalogue. ``implemented`` marks adapters available in this
release; others are listed (disabled) so users can see what is coming.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

from pydantic import BaseModel

from .base import AIProvider, ProviderConfig

Field = Literal["api_key", "model", "base_url", "endpoint", "deployment", "api_version"]
AccuracyTier = Literal["high", "medium", "limited", "untested"]


class ProviderSpec(BaseModel):
    id: str
    label: str
    tagline: str
    fields: list[Field]
    key_required: bool = True
    key_page_url: str | None = None
    data_policy_url: str | None = None
    data_location_note: str
    env_vars: dict[str, str]
    default_model: str | None = None
    notes: list[str] = []
    implemented: bool = False
    available_in: str | None = None
    accuracy_tier: AccuracyTier = "untested"


PROVIDERS: dict[str, ProviderSpec] = {
    spec.id: spec
    for spec in [
        ProviderSpec(
            id="anthropic",
            label="Anthropic Claude",
            tagline="Default and recommended. Reads PDFs natively and returns schema-checked JSON.",
            fields=["api_key", "model"],
            key_page_url="https://console.anthropic.com/settings/keys",
            data_policy_url="https://www.anthropic.com/legal/commercial-terms",
            data_location_note=(
                "Selected pages are sent to Anthropic's API. Under Anthropic's commercial terms, API inputs and "
                "outputs are not used to train models by default."
            ),
            env_vars={"api_key": "ANTHROPIC_API_KEY", "model": "ANTHROPIC_MODEL"},
            default_model="claude-opus-5-5",
            implemented=True,
        ),
        ProviderSpec(
            id="openai",
            label="OpenAI",
            tagline="The models behind ChatGPT, through the OpenAI Platform API.",
            fields=["api_key", "model"],
            key_page_url="https://platform.openai.com/api-keys",
            data_policy_url="https://openai.com/enterprise-privacy/",
            data_location_note="Selected pages are sent to OpenAI's API.",
            env_vars={"api_key": "OPENAI_API_KEY", "model": "OPENAI_MODEL"},
            default_model="gpt-6.2-sol",
            notes=["For the hardest documents, gpt-6.2-astra is more accurate and about four times the price."],
            implemented=True,
        ),
        ProviderSpec(
            id="azure_openai",
            label="Microsoft Copilot / Azure OpenAI",
            tagline="For companies on Microsoft: the same OpenAI models under your Azure agreement.",
            fields=["api_key", "endpoint", "deployment"],
            key_page_url="https://portal.azure.com/",
            data_policy_url="https://learn.microsoft.com/legal/cognitive-services/openai/data-privacy",
            data_location_note="Selected pages are sent to your company's Azure OpenAI resource, in its region.",
            env_vars={
                "api_key": "AZURE_OPENAI_API_KEY",
                "endpoint": "AZURE_OPENAI_ENDPOINT",
                "deployment": "AZURE_OPENAI_DEPLOYMENT",
            },
            notes=[
                "Consumer Copilot and Microsoft 365 Copilot have no general-purpose API for this. Companies "
                "that standardise on Copilot normally have Azure OpenAI (or Azure AI Foundry), which serves the "
                "same OpenAI models — ask your IT team for the endpoint, deployment name and key.",
                "Uses Azure's v1 API, so no API version is needed. Pages are sent as text plus page images, "
                "which any vision-capable deployment reads.",
            ],
            implemented=True,
        ),
        ProviderSpec(
            id="gemini",
            label="Google Gemini",
            tagline="Gemini models through Google AI Studio (or Vertex AI for Google Cloud companies).",
            fields=["api_key", "model"],
            key_page_url="https://aistudio.google.com/apikey",
            data_policy_url="https://ai.google.dev/gemini-api/terms",
            data_location_note="Selected pages are sent to Google's Gemini API.",
            env_vars={"api_key": "GEMINI_API_KEY", "model": "GEMINI_MODEL"},
            default_model="gemini-4-hydrogen",
            implemented=True,
        ),
        ProviderSpec(
            id="xai",
            label="xAI Grok",
            tagline="Grok models through xAI's API (reached with the official OpenAI SDK).",
            fields=["api_key", "model"],
            key_page_url="https://console.x.ai/",
            data_policy_url="https://x.ai/legal/privacy-policy",
            data_location_note="Selected pages are sent to xAI's API.",
            env_vars={"api_key": "XAI_API_KEY", "model": "XAI_MODEL"},
            default_model="grok-4.7",
            notes=[
                "Documents are sent as page text plus page images (xAI does not take PDFs inline). xAI keeps API data "
                "for 30 days for abuse checks and does not train on it without your permission."
            ],
            implemented=True,
        ),
        ProviderSpec(
            id="perplexity",
            label="Perplexity",
            tagline="Claude, GPT and Sonar models through Perplexity's Agent API; web search off for documents.",
            fields=["api_key", "model"],
            key_page_url="https://www.perplexity.ai/settings/api",
            data_policy_url="https://www.perplexity.ai/hub/legal/privacy-policy",
            data_location_note="Selected pages are sent to Perplexity's API.",
            env_vars={"api_key": "PERPLEXITY_API_KEY", "model": "PERPLEXITY_MODEL"},
            default_model="anthropic/claude-sonnet-5-5",
            notes=[
                "Uses Perplexity's Agent API with web search turned off for document reading (no search tools are "
                "sent), so answers come from your pages. Models are named provider/model, e.g. "
                "anthropic/claude-sonnet-5-5 or openai/gpt-5.6-sol.",
                "The first request with a new extraction schema can take 10–30 seconds to prepare.",
            ],
            implemented=True,
        ),
        ProviderSpec(
            id="custom",
            label="Custom OpenAI-compatible endpoint",
            tagline="A company AI gateway or a local model (Ollama, LM Studio).",
            fields=["base_url", "model", "api_key"],
            key_required=False,
            data_location_note="Pages are sent only to the endpoint you enter (which may stay inside your network).",
            env_vars={"base_url": "CUSTOM_AI_BASE_URL", "api_key": "CUSTOM_AI_API_KEY", "model": "CUSTOM_AI_MODEL"},
            notes=[
                "Small local models may extract poorly; check every value on the review screen.",
                "Ollama: http://localhost:11434/v1 · LM Studio: http://localhost:1234/v1. Models with vision in "
                "their name (e.g. llava, qwen2.5vl, gemma3) also get page images.",
            ],
            implemented=True,
        ),
    ]
}


MEASURED_ACCURACY = Path(__file__).resolve().parents[3] / "data" / "ai" / "provider_accuracy.json"
TIERS: tuple[AccuracyTier, ...] = ("high", "medium", "limited", "untested")


def _apply_measured_tiers(path: Path = MEASURED_ACCURACY) -> None:
    """Tiers come from the last accuracy evaluation (scripts/provider_accuracy.py); untested until one runs."""
    if not path.exists():
        return
    try:
        measured = json.loads(path.read_text(encoding="utf-8")).get("providers", {})
    except (OSError, ValueError):
        return
    for provider_id, result in measured.items():
        tier = result.get("tier") if isinstance(result, dict) else None
        if provider_id in PROVIDERS and tier in TIERS:
            PROVIDERS[provider_id].accuracy_tier = tier


_apply_measured_tiers()


def get_spec(provider_id: str) -> ProviderSpec:
    try:
        return PROVIDERS[provider_id]
    except KeyError:
        raise KeyError(f"Unknown AI provider {provider_id!r}") from None


def create_provider(config: ProviderConfig) -> AIProvider:
    """Instantiate the adapter for ``config.provider``. Vendor SDKs are imported lazily here only."""
    spec = get_spec(config.provider)
    if not spec.implemented:
        raise NotImplementedError(f"{spec.label} support arrives in {spec.available_in}.")
    if config.provider == "anthropic":
        from .providers.anthropic import AnthropicProvider

        return AnthropicProvider(config)
    if config.provider == "openai":
        from .providers.openai import OpenAIProvider

        return OpenAIProvider(config)
    if config.provider == "azure_openai":
        from .providers.openai import AzureOpenAIProvider

        return AzureOpenAIProvider(config)
    if config.provider == "gemini":
        from .providers.gemini import GeminiProvider

        return GeminiProvider(config)
    if config.provider == "xai":
        from .providers.openai_compatible import XAIProvider

        return XAIProvider(config)
    if config.provider == "perplexity":
        from .providers.openai_compatible import PerplexityProvider

        return PerplexityProvider(config)
    if config.provider == "custom":
        from .providers.custom import CustomOpenAIProvider

        return CustomOpenAIProvider(config)
    raise NotImplementedError(config.provider)  # pragma: no cover
