"""Storage for AI provider keys: the OS keychain via ``keyring``, with a user-only file as fallback.

Keys are never logged, never returned to the browser (only the last four characters) and never written
into the database, exports or JSON deal files.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import stat
from pathlib import Path
from typing import Literal

log = logging.getLogger(__name__)

SERVICE = "DealScout"
Backend = Literal["keychain", "file"]


def last4(secret: str | None) -> str | None:
    if not secret:
        return None
    return secret[-4:] if len(secret) >= 8 else "…"


class KeyStore:
    def __init__(self, fallback_dir: Path, *, force_file: bool = False):
        self._fallback_path = fallback_dir / "secrets.json"
        self.backend: Backend = "file" if force_file or not _keychain_available() else "keychain"

    # ── public API ─────────────────────────────────────────────────────
    def get(self, provider_id: str) -> str | None:
        if self.backend == "keychain":
            import keyring

            try:
                return keyring.get_password(SERVICE, provider_id)
            except Exception:  # keychain locked / denied: surface as "no key" rather than crash
                log.warning("Could not read the %s key from the OS keychain", provider_id)
                return None
        return self._read_file().get(provider_id)

    def set(self, provider_id: str, secret: str) -> None:
        secret = secret.strip()
        if not secret:
            raise ValueError("empty key")
        if self.backend == "keychain":
            import keyring

            keyring.set_password(SERVICE, provider_id, secret)
            return
        data = self._read_file()
        data[provider_id] = secret
        self._write_file(data)

    def delete(self, provider_id: str) -> None:
        if self.backend == "keychain":
            import keyring
            from keyring.errors import PasswordDeleteError

            with contextlib.suppress(PasswordDeleteError):
                keyring.delete_password(SERVICE, provider_id)
            return
        data = self._read_file()
        if data.pop(provider_id, None) is not None:
            self._write_file(data)

    def describe(self) -> dict[str, str]:
        if self.backend == "keychain":
            import keyring

            return {"backend": "keychain", "detail": f"OS keychain ({type(keyring.get_keyring()).__name__})"}
        return {
            "backend": "file",
            "detail": (
                f"No OS keychain available — keys are stored in {self._fallback_path}, readable only by your "
                "user account."
            ),
        }

    # ── file fallback ──────────────────────────────────────────────────
    def _read_file(self) -> dict[str, str]:
        if not self._fallback_path.exists():
            return {}
        try:
            data = json.loads(self._fallback_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return {str(k): str(v) for k, v in data.items()} if isinstance(data, dict) else {}

    def _write_file(self, data: dict[str, str]) -> None:
        self._fallback_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._fallback_path.with_suffix(".tmp")
        # create with owner-only permissions before writing any secret
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, stat.S_IRUSR | stat.S_IWUSR)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle)
        os.replace(tmp, self._fallback_path)
        # On Windows chmod is best-effort; the file lives in the user's own profile folder.
        with contextlib.suppress(OSError):
            os.chmod(self._fallback_path, stat.S_IRUSR | stat.S_IWUSR)


def _keychain_available() -> bool:
    if os.environ.get("DEALSCOUT_TEST_NO_KEYRING") == "1":
        return False
    try:
        import keyring
        from keyring.backends import fail

        backend = keyring.get_keyring()
        if isinstance(backend, fail.Keyring):
            return False
        chainer = getattr(backend, "backends", None)
        return not (chainer is not None and len(chainer) == 0)
    except Exception:  # pragma: no cover
        return False
