"""Recorded-response harnesses for adapter contract tests (no network, no keys). Test-only helpers.

Each harness turns provider-neutral *scenarios* into the HTTP responses that provider's API would send,
and builds an adapter wired to a mock transport. Adding a provider = adding a harness; the contract tests
in ``test_contract.py`` then run unchanged against it.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import httpx2
from pydantic import SecretStr

from dealscout_ai.base import AIProvider, ProviderConfig


@dataclass
class Scenario:
    """One scripted reply: either a successful answer (``text``) or an error (``status``)."""

    text: str | None = None
    status: int = 200
    error_type: str | None = None
    error_message: str = "error"
    stop_reason: str = "end_turn"
    input_tokens: int = 1000
    output_tokens: int = 200
    model: str | None = None


@dataclass
class Recorder:
    requests: list[dict[str, Any]] = field(default_factory=list)
    headers: list[dict[str, str]] = field(default_factory=list)
    paths: list[str] = field(default_factory=list)


class AnthropicHarness:
    name = "anthropic"
    model = "claude-opus-5-5"

    def build(self, scenarios: list[Scenario], *, model: str | None = None) -> tuple[AIProvider, Recorder]:
        from anthropic import DefaultHttpxClient

        from dealscout_ai.providers.anthropic import AnthropicProvider

        recorder = Recorder()
        queue = list(scenarios)
        model_id = model or self.model

        def handler(request: httpx2.Request) -> httpx2.Response:
            recorder.paths.append(request.url.path)
            recorder.headers.append(dict(request.headers))
            body = json.loads(request.content or b"{}") if request.content else {}
            recorder.requests.append(body)
            if request.url.path.startswith("/v1/models"):
                if request.url.path == "/v1/models":
                    return httpx2.Response(
                        200,
                        json={
                            "data": [
                                {
                                    "type": "model",
                                    "id": "claude-opus-5-5",
                                    "display_name": "Claude Opus 5.5",
                                    "created_at": "2026-10-01T00:00:00Z",
                                    "max_input_tokens": 1000000,
                                    "max_tokens": 128000,
                                    "capabilities": {
                                        "image_input": {"supported": True},
                                        "pdf_input": {"supported": True},
                                        "structured_outputs": {"supported": True},
                                    },
                                }
                            ],
                            "has_more": False,
                            "first_id": "claude-opus-5-5",
                            "last_id": "claude-opus-5-5",
                        },
                    )
                scenario = queue[0] if queue and queue[0].status in (401, 404) else None
                if scenario is not None:
                    queue.pop(0)
                    return self._error(scenario)
                return httpx2.Response(
                    200,
                    json={
                        "type": "model",
                        "id": model_id,
                        "display_name": model_id,
                        "created_at": "2026-10-01T00:00:00Z",
                    },
                )
            scenario = queue.pop(0)
            if scenario.status != 200:
                return self._error(scenario)
            return httpx2.Response(
                200,
                json={
                    "id": "msg_test",
                    "type": "message",
                    "role": "assistant",
                    "model": scenario.model or model_id,
                    "content": [{"type": "text", "text": scenario.text or ""}],
                    "stop_reason": scenario.stop_reason,
                    "stop_sequence": None,
                    "usage": {
                        "input_tokens": scenario.input_tokens,
                        "output_tokens": scenario.output_tokens,
                        "cache_read_input_tokens": 0,
                        "cache_creation_input_tokens": 0,
                    },
                },
            )

        client = DefaultHttpxClient(transport=httpx2.MockTransport(handler))
        config = ProviderConfig(
            provider="anthropic", model=model_id, api_key=SecretStr("sk-ant-test-0000"), max_retries=0
        )
        return AnthropicProvider(config, http_client=client), recorder

    @staticmethod
    def _error(scenario: Scenario) -> httpx2.Response:
        error_type = scenario.error_type or {
            400: "invalid_request_error",
            401: "authentication_error",
            402: "billing_error",
            403: "permission_error",
            404: "not_found_error",
            429: "rate_limit_error",
            500: "api_error",
            529: "overloaded_error",
        }.get(scenario.status, "api_error")
        return httpx2.Response(
            scenario.status,
            json={"type": "error", "error": {"type": error_type, "message": scenario.error_message}},
            headers={"retry-after": "7"} if scenario.status == 429 else {},
        )


_OPENAI_ERROR_TYPES = {
    400: ("invalid_request_error", None),
    401: ("invalid_request_error", "invalid_api_key"),
    402: ("billing_error", None),
    403: ("permission_error", None),
    404: ("invalid_request_error", "model_not_found"),
    429: ("requests", "rate_limit_exceeded"),
    500: ("server_error", None),
    529: ("server_error", None),
}


class OpenAIHarness:
    """Responses API (POST /v1/responses) recorded shapes."""

    name = "openai"
    model = "gpt-6.2-sol"

    def _provider(self, config: ProviderConfig, client: Any) -> AIProvider:
        from dealscout_ai.providers.openai import OpenAIProvider

        return OpenAIProvider(config, http_client=client)

    def _config(self, model_id: str) -> ProviderConfig:
        return ProviderConfig(provider="openai", model=model_id, api_key=SecretStr("sk-test-0000"), max_retries=0)

    def build(self, scenarios: list[Scenario], *, model: str | None = None) -> tuple[AIProvider, Recorder]:
        recorder = Recorder()
        queue = list(scenarios)
        model_id = model or self.model

        def handler(request: httpx2.Request) -> httpx2.Response:
            recorder.paths.append(request.url.path)
            recorder.headers.append(dict(request.headers))
            recorder.requests.append(json.loads(request.content) if request.content else {})
            if request.url.path.endswith("/models"):
                return httpx2.Response(
                    200,
                    json={
                        "object": "list",
                        "data": [
                            {"id": m, "object": "model", "created": 1763000000, "owned_by": "system"}
                            for m in self._models()
                        ],
                    },
                )
            scenario = queue.pop(0)
            if scenario.status != 200:
                kind, code = _OPENAI_ERROR_TYPES.get(scenario.status, ("server_error", None))
                if scenario.status == 400 and "credit" in scenario.error_message.lower():
                    kind = "insufficient_quota"
                return httpx2.Response(
                    scenario.status,
                    json={"error": {"message": scenario.error_message, "type": kind, "param": None, "code": code}},
                    headers={"retry-after": "7"} if scenario.status == 429 else {},
                )
            served = scenario.model or self._served_model(model_id)
            content: list[dict[str, Any]]
            if scenario.stop_reason == "refusal":
                content = [{"type": "refusal", "refusal": "I can't help with that."}]
            else:
                content = [{"type": "output_text", "text": scenario.text or "", "annotations": []}]
            incomplete = scenario.stop_reason == "max_tokens"
            return httpx2.Response(
                200,
                json={
                    "id": "resp_test",
                    "object": "response",
                    "created_at": 1763600000,
                    "status": "incomplete" if incomplete else "completed",
                    "incomplete_details": {"reason": "max_output_tokens"} if incomplete else None,
                    "model": served,
                    "output": [
                        {
                            "type": "message",
                            "id": "msg_test",
                            "status": "completed",
                            "role": "assistant",
                            "content": content,
                        }
                    ],
                    "parallel_tool_calls": True,
                    "tool_choice": "auto",
                    "tools": [],
                    "usage": self._usage(scenario),
                },
            )

        client = httpx2.Client(transport=httpx2.MockTransport(handler))
        return self._provider(self._config(model_id), client), recorder

    def _served_model(self, model_id: str) -> str:
        return model_id

    def _models(self) -> list[str]:
        return ["gpt-6.2-sol", "gpt-6.2-astra", "text-embedding-3-large"]

    def _usage(self, scenario: Scenario) -> dict[str, Any]:
        return {
            "input_tokens": scenario.input_tokens,
            "input_tokens_details": {"cached_tokens": 0},
            "output_tokens": scenario.output_tokens,
            "output_tokens_details": {"reasoning_tokens": 0},
            "total_tokens": scenario.input_tokens + scenario.output_tokens,
        }


class AzureOpenAIHarness(OpenAIHarness):
    name = "azure_openai"
    model = "dealscout-extract"  # a deployment name; Azure reports the underlying model in responses

    def _provider(self, config: ProviderConfig, client: Any) -> AIProvider:
        from dealscout_ai.providers.openai import AzureOpenAIProvider

        return AzureOpenAIProvider(config, http_client=client)

    def _config(self, model_id: str) -> ProviderConfig:
        return ProviderConfig(
            provider="azure_openai",
            model="",
            deployment=model_id,
            endpoint="https://contoso-ai.openai.azure.com/",
            api_key=SecretStr("azure-test-0000"),
            max_retries=0,
        )

    def _served_model(self, model_id: str) -> str:
        return "gpt-6.1-sol-2026-03-11"


_GEMINI_STATUS = {
    400: "INVALID_ARGUMENT",
    401: "UNAUTHENTICATED",
    402: "RESOURCE_EXHAUSTED",
    403: "PERMISSION_DENIED",
    404: "NOT_FOUND",
    429: "RESOURCE_EXHAUSTED",
    500: "INTERNAL",
    529: "UNAVAILABLE",
}


class GeminiHarness:
    """generateContent (POST /v1/models/{model}:generateContent) recorded shapes."""

    name = "gemini"
    model = "gemini-4-hydrogen"

    def build(self, scenarios: list[Scenario], *, model: str | None = None) -> tuple[AIProvider, Recorder]:
        from dealscout_ai.providers.gemini import GeminiProvider

        recorder = Recorder()
        queue = list(scenarios)
        model_id = model or self.model

        def handler(request: httpx2.Request) -> httpx2.Response:
            recorder.paths.append(request.url.path)
            recorder.headers.append(dict(request.headers))
            recorder.requests.append(json.loads(request.content) if request.content else {})
            if request.url.path.endswith("/models"):
                return httpx2.Response(
                    200,
                    json={
                        "models": [
                            {
                                "name": "models/gemini-4-hydrogen",
                                "displayName": "Gemini 4 Hydrogen",
                                "inputTokenLimit": 1048576,
                                "outputTokenLimit": 65536,
                                "supportedGenerationMethods": ["generateContent", "countTokens"],
                            },
                            {
                                "name": "models/text-embedding-005",
                                "displayName": "Embedding",
                                "supportedGenerationMethods": ["embedContent"],
                            },
                        ]
                    },
                )
            scenario = queue.pop(0)
            if scenario.status != 200:
                return httpx2.Response(
                    scenario.status,
                    json={
                        "error": {
                            "code": scenario.status,
                            "message": scenario.error_message,
                            "status": _GEMINI_STATUS.get(scenario.status, "UNKNOWN"),
                        }
                    },
                )
            finish = {"refusal": "SAFETY", "max_tokens": "MAX_TOKENS"}.get(scenario.stop_reason, "STOP")
            parts = [{"text": scenario.text}] if scenario.text else []
            return httpx2.Response(
                200,
                json={
                    "candidates": [{"content": {"role": "model", "parts": parts}, "finishReason": finish, "index": 0}],
                    "usageMetadata": {
                        "promptTokenCount": scenario.input_tokens,
                        "candidatesTokenCount": scenario.output_tokens,
                        "totalTokenCount": scenario.input_tokens + scenario.output_tokens,
                    },
                    "modelVersion": scenario.model or model_id,
                },
            )

        client = httpx2.Client(transport=httpx2.MockTransport(handler))
        config = ProviderConfig(provider="gemini", model=model_id, api_key=SecretStr("gm-test-0000"), max_retries=0)
        return GeminiProvider(config, http_client=client), recorder


class XAIHarness(OpenAIHarness):
    name = "xai"
    model = "grok-4.7"

    def _provider(self, config: ProviderConfig, client: Any) -> AIProvider:
        from dealscout_ai.providers.openai_compatible import XAIProvider

        return XAIProvider(config, http_client=client)

    def _config(self, model_id: str) -> ProviderConfig:
        return ProviderConfig(provider="xai", model=model_id, api_key=SecretStr("xai-test-0000"), max_retries=0)

    def _models(self) -> list[str]:
        return ["grok-4.7", "grok-4.3", "grok-imagine-image"]


class PerplexityHarness(OpenAIHarness):
    name = "perplexity"
    model = "anthropic/claude-sonnet-5-5"

    def _provider(self, config: ProviderConfig, client: Any) -> AIProvider:
        from dealscout_ai.providers.openai_compatible import PerplexityProvider

        return PerplexityProvider(config, http_client=client)

    def _config(self, model_id: str) -> ProviderConfig:
        return ProviderConfig(provider="perplexity", model=model_id, api_key=SecretStr("pplx-test-0000"), max_retries=0)

    def _models(self) -> list[str]:
        return ["anthropic/claude-sonnet-5-5", "openai/gpt-5.6-sol", "perplexity/sonar"]

    def _usage(self, scenario: Scenario) -> dict[str, Any]:
        return {
            "input_tokens": scenario.input_tokens,
            "output_tokens": scenario.output_tokens,
            "total_tokens": scenario.input_tokens + scenario.output_tokens,
            "input_tokens_details": {"cache_read_input_tokens": 0, "cache_creation_input_tokens": 0},
            "cost": {"currency": "USD", "total_cost": 0.0042},
        }


class CustomHarness:
    """An OpenAI-compatible Chat Completions server (Ollama-style) on this computer."""

    name = "custom"
    model = "qwen2.5:14b"
    priced = False  # local models cost nothing per call; gateways have no published price

    def build(self, scenarios: list[Scenario], *, model: str | None = None) -> tuple[AIProvider, Recorder]:
        from dealscout_ai.providers.custom import CustomOpenAIProvider

        recorder = Recorder()
        queue = list(scenarios)
        model_id = model or self.model

        def handler(request: httpx2.Request) -> httpx2.Response:
            recorder.paths.append(request.url.path)
            recorder.headers.append(dict(request.headers))
            recorder.requests.append(json.loads(request.content) if request.content else {})
            if request.url.path.endswith("/models"):
                return httpx2.Response(
                    200,
                    json={
                        "object": "list",
                        "data": [
                            {"id": "qwen2.5:14b", "object": "model", "created": 1, "owned_by": "library"},
                            {"id": "llava:13b", "object": "model", "created": 1, "owned_by": "library"},
                        ],
                    },
                )
            scenario = queue.pop(0)
            if scenario.status != 200:
                kind = "not_found_error" if scenario.status == 404 else "invalid_request_error"
                return httpx2.Response(
                    scenario.status,
                    json={"error": {"message": scenario.error_message, "type": kind, "param": None, "code": None}},
                    headers={"retry-after": "7"} if scenario.status == 429 else {},
                )
            refusal = scenario.stop_reason == "refusal"
            return httpx2.Response(
                200,
                json={
                    "id": "chatcmpl-test",
                    "object": "chat.completion",
                    "created": 1763600000,
                    "model": scenario.model or model_id,
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": None if refusal else (scenario.text or ""),
                                "refusal": "I can't help with that." if refusal else None,
                            },
                            "finish_reason": "length" if scenario.stop_reason == "max_tokens" else "stop",
                        }
                    ],
                    "usage": {
                        "prompt_tokens": scenario.input_tokens,
                        "completion_tokens": scenario.output_tokens,
                        "total_tokens": scenario.input_tokens + scenario.output_tokens,
                    },
                },
            )

        client = httpx2.Client(transport=httpx2.MockTransport(handler))
        config = ProviderConfig(provider="custom", model=model_id, base_url="http://localhost:11434/v1", max_retries=0)
        return CustomOpenAIProvider(config, http_client=client), recorder


HARNESSES = [
    AnthropicHarness(),
    OpenAIHarness(),
    AzureOpenAIHarness(),
    GeminiHarness(),
    XAIHarness(),
    PerplexityHarness(),
    CustomHarness(),
]


class ScriptedProvider:
    """A provider-neutral fake for pipeline tests: returns canned JSON per schema name and records requests."""

    provider_id = "fake"

    def __init__(self, responses: dict[str, list[str]], *, native_pdf: bool = False, image_input: bool = False):
        from dealscout_ai.base import AIProvider, ProviderConfig
        from dealscout_ai.types import Capabilities, Usage

        outer = self

        class _Fake(AIProvider):
            provider_id = "fake"

            def capabilities(self) -> Capabilities:
                return Capabilities(native_pdf=native_pdf, image_input=image_input, structured_output="strict")

            def _complete_json(self, *, system, content, schema, schema_name, max_tokens):
                outer.requests.append({"schema": schema_name, "content": list(content), "system": system})
                queue = outer.responses.get(schema_name, [])
                text = queue.pop(0) if queue else "{}"
                return text, Usage(
                    provider="fake", model="fake-1", input_tokens=100, output_tokens=20, estimated_cost_usd=0.001
                )

            def _complete_text(self, *, system, prompt, max_tokens):
                return "ok", Usage(provider="fake", model="fake-1")

            def test_connection(self):
                raise NotImplementedError

            def list_models(self):
                return []

        self.responses = responses
        self.requests: list[dict[str, object]] = []
        self.provider = _Fake(ProviderConfig(provider="fake", model="fake-1"))
