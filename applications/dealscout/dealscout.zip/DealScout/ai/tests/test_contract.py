"""Contract tests every AI adapter must pass (same scenarios, recorded responses, no live calls)."""

from __future__ import annotations

import json

import pytest
from pydantic import BaseModel

from dealscout_ai import (
    ContentRefusedError,
    InvalidKeyError,
    ModelUnavailableError,
    OutOfCreditError,
    OutputTruncatedError,
    PageText,
    ProviderUnavailableError,
    RateLimitedError,
    SchemaValidationError,
)
from dealscout_ai.testing import HARNESSES, Scenario


class ExtractedValue(BaseModel):
    concept: str
    value_as_written: str | None
    page: int | None
    label: str | None
    unit_scale: str | None
    confidence: float
    reason_if_null: str | None


GOOD = {
    "concept": "revenue",
    "value_as_written": "1,234.5",
    "page": 12,
    "label": "Revenue",
    "unit_scale": "EUR m",
    "confidence": 0.93,
    "reason_if_null": None,
}
PAGES = [PageText(page=12, text="Revenue 1,234.5", source_name="AR2025.pdf")]

pytestmark = pytest.mark.parametrize("harness", HARNESSES, ids=lambda h: h.name)


def test_valid_structured_output(harness):
    provider, rec = harness.build([Scenario(text=json.dumps(GOOD))])
    result = provider.extract_structured(PAGES, ExtractedValue, instructions="Extract revenue.")
    assert result.value.value_as_written == "1,234.5"
    assert result.attempts == 1
    assert result.usage.input_tokens == 1000 and result.usage.output_tokens == 200
    if getattr(harness, "priced", True):
        assert result.usage.estimated_cost_usd is not None and result.usage.estimated_cost_usd > 0
    assert result.provider == harness.name
    assert len(rec.requests) == 1


def test_schema_failure_retries_once_with_errors(harness):
    bad = json.dumps({**GOOD, "confidence": "very high"})
    provider, rec = harness.build([Scenario(text=bad), Scenario(text=json.dumps(GOOD))])
    result = provider.extract_structured(PAGES, ExtractedValue, instructions="Extract revenue.")
    assert result.attempts == 2
    assert result.usage.input_tokens == 2000  # usage of both calls is reported
    assert "did not match" in json.dumps(rec.requests[1])


def test_schema_failure_twice_raises(harness):
    provider, _ = harness.build([Scenario(text="not json"), Scenario(text="{}")])
    with pytest.raises(SchemaValidationError):
        provider.extract_structured(PAGES, ExtractedValue, instructions="Extract revenue.")


def test_null_with_reason_is_accepted(harness):
    missing = {
        **GOOD,
        "value_as_written": None,
        "page": None,
        "label": None,
        "unit_scale": None,
        "confidence": 0.0,
        "reason_if_null": "Revenue is not disclosed on the pages provided.",
    }
    provider, _ = harness.build([Scenario(text=json.dumps(missing))])
    result = provider.extract_structured(PAGES, ExtractedValue, instructions="Extract revenue.")
    assert result.value.value_as_written is None
    assert result.value.reason_if_null


def test_fenced_json_is_tolerated(harness):
    provider, _ = harness.build([Scenario(text="```json\n" + json.dumps(GOOD) + "\n```")])
    result = provider.extract_structured(PAGES, ExtractedValue, instructions="x")
    assert result.value.concept == "revenue"


@pytest.mark.parametrize(
    ("scenario", "error"),
    [
        (Scenario(status=401), InvalidKeyError),
        (Scenario(status=403), InvalidKeyError),
        (Scenario(status=402), OutOfCreditError),
        (Scenario(status=400, error_message="Your credit balance is too low to access the API."), OutOfCreditError),
        (Scenario(status=404), ModelUnavailableError),
        (Scenario(status=429), RateLimitedError),
        (Scenario(status=500), ProviderUnavailableError),
        (Scenario(status=529), ProviderUnavailableError),
        (Scenario(text="", stop_reason="refusal"), ContentRefusedError),
        (Scenario(text='{"concept": "rev', stop_reason="max_tokens"), OutputTruncatedError),
    ],
    ids=["401", "403", "402", "400-credit", "404", "429", "500", "529", "refusal", "truncated"],
)
def test_error_mapping(harness, scenario, error):
    provider, _ = harness.build([scenario])
    with pytest.raises(error) as caught:
        provider.extract_structured(PAGES, ExtractedValue, instructions="x")
    assert caught.value.provider == harness.name
    if error is RateLimitedError:
        assert caught.value.retryable


def test_generate_text_reports_usage(harness):
    provider, _ = harness.build([Scenario(text="Revenue grew 12%.", output_tokens=7)])
    result = provider.generate_text("Summarise.", context="facts")
    assert result.text == "Revenue grew 12%."
    assert result.usage.output_tokens == 7


def test_connection_ok_and_invalid_key(harness):
    provider, _ = harness.build([Scenario(text="OK", output_tokens=2)])
    ok = provider.test_connection()
    assert ok.ok and ok.code == "ok"
    provider, _ = harness.build([Scenario(status=401)])
    bad = provider.test_connection()
    assert not bad.ok and bad.code == "invalid_key"
    provider, _ = harness.build([Scenario(status=404)])
    missing = provider.test_connection()
    assert missing.code == "model_unavailable"
    provider, _ = harness.build([Scenario(status=402)])
    broke = provider.test_connection()
    assert broke.code == "out_of_credit"


def test_list_models(harness):
    provider, _ = harness.build([])
    models = provider.list_models()
    assert models and models[0].id
    assert any(m.recommended for m in models)
