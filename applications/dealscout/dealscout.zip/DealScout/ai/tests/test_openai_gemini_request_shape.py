"""OpenAI, Azure OpenAI and Gemini request-shape checks (generic behaviour is in test_contract.py)."""

from __future__ import annotations

import base64
import json

from pydantic import BaseModel

from dealscout_ai import PageImage, PageText, PdfDocument
from dealscout_ai.base import ProviderConfig
from dealscout_ai.pricing import price_for
from dealscout_ai.registry import PROVIDERS, create_provider
from dealscout_ai.testing import AzureOpenAIHarness, GeminiHarness, OpenAIHarness, Scenario


class Out(BaseModel):
    value: float | None
    reason: str | None


ANSWER = json.dumps({"value": 1.0, "reason": None})
PDF = PdfDocument(data=b"%PDF-1.4 test", first_page=40, source_name="AR.pdf")


def test_openai_uses_responses_api_strict_schema_and_pdf_file():
    provider, rec = OpenAIHarness().build([Scenario(text=ANSWER)])
    provider.extract_structured([PDF, PageText(page=41, text="x")], Out, instructions="Extract.")
    body = rec.requests[0]
    assert rec.paths[0] == "/v1/responses"
    assert body["model"] == "gpt-6.2-sol" and body["store"] is False and body["instructions"] == "Extract."
    fmt = body["text"]["format"]
    assert fmt["type"] == "json_schema" and fmt["strict"] is True and fmt["name"] == "Out"
    assert fmt["schema"]["additionalProperties"] is False and set(fmt["schema"]["required"]) == {"value", "reason"}
    parts = body["input"][0]["content"]
    file_part = next(p for p in parts if p["type"] == "input_file")
    assert file_part["filename"] == "AR.pdf"
    assert file_part["file_data"] == "data:application/pdf;base64," + base64.b64encode(b"%PDF-1.4 test").decode()
    assert any("page 40 of the source" in p.get("text", "") for p in parts)
    assert any('<page number="41"' in p.get("text", "") for p in parts)
    assert "reasoning" not in body  # only sent when an effort is configured


def test_openai_billing_429_is_out_of_credit_not_a_retry():
    import pytest

    from dealscout_ai import OutOfCreditError

    provider, _ = OpenAIHarness().build([Scenario(status=429, error_message="You exceeded your current quota.")])
    with pytest.raises(OutOfCreditError):
        provider.extract_structured([PageText(page=1, text="x")], Out, instructions="x")


def test_azure_uses_v1_base_url_deployment_and_page_images_instead_of_pdf():
    provider, rec = AzureOpenAIHarness().build([Scenario(text=ANSWER)])
    assert not provider.capabilities().native_pdf and provider.capabilities().image_input
    provider.extract_structured(
        [PageText(page=3, text="Revenue 10"), PageImage(page=3, data=b"\x89PNG fake")], Out, instructions="x"
    )
    assert rec.paths[0] == "/openai/v1/responses"
    body = rec.requests[0]
    assert body["model"] == "dealscout-extract"
    types = [p["type"] for p in body["input"][0]["content"]]
    assert "input_file" not in types and "input_image" in types
    assert rec.headers[0].get("authorization") == "Bearer azure-test-0000"


def test_azure_cost_uses_the_served_model_without_its_date_suffix():
    provider, _ = AzureOpenAIHarness().build([Scenario(text=ANSWER, input_tokens=1_000_000, output_tokens=0)])
    result = provider.extract_structured([PageText(page=1, text="x")], Out, instructions="x")
    assert result.usage.model == "gpt-6.1-sol-2026-03-11"
    assert result.usage.estimated_cost_usd == 2.0
    assert price_for("gemini", "models/gemini-4-hydrogen") is not None


def test_gemini_sends_inline_pdf_json_schema_and_system_instruction():
    provider, rec = GeminiHarness().build([Scenario(text=ANSWER)])
    provider.extract_structured([PDF, PageText(page=41, text="x")], Out, instructions="Extract.")
    assert rec.paths[0] == "/v1/models/gemini-4-hydrogen:generateContent"
    body = rec.requests[0]
    config = body["generationConfig"]
    assert config["responseMimeType"] == "application/json"
    assert config["responseJsonSchema"]["required"] == ["value", "reason"]
    assert body["systemInstruction"]["parts"][0]["text"] == "Extract."
    parts = body["contents"][0]["parts"]
    inline = next(p for p in parts if "inlineData" in p)
    data = inline["inlineData"]
    assert (data.get("mimeType") or data.get("mime_type")) == "application/pdf"
    assert any("page 40 of the source" in p.get("text", "") for p in parts)


def test_registry_builds_each_implemented_adapter():
    from pydantic import SecretStr

    for provider_id in ("openai", "azure_openai", "gemini"):
        assert PROVIDERS[provider_id].implemented
        config = ProviderConfig(
            provider=provider_id,
            model=PROVIDERS[provider_id].default_model or "",
            deployment="my-deployment" if provider_id == "azure_openai" else None,
            endpoint="https://contoso.openai.azure.com" if provider_id == "azure_openai" else None,
            api_key=SecretStr("test-key-0000"),
        )
        adapter = create_provider(config)
        assert adapter.provider_id == provider_id and adapter.model
    assert "api_version" not in PROVIDERS["azure_openai"].fields
