import stat
import sys

import pytest
from pydantic import BaseModel, Field

from dealscout_ai import KeyStore, last4, parse_json_text
from dealscout_ai.pricing import estimate_cost
from dealscout_ai.schema import strict_json_schema


class Inner(BaseModel):
    page: int = Field(ge=1)
    label: str = Field(max_length=200)


class Outer(BaseModel):
    items: list[Inner]
    note: str | None = None
    score: float = Field(default=0.5, le=1)


def test_strict_schema_inlines_refs_and_strips_unsupported():
    schema = strict_json_schema(Outer)
    assert "$defs" not in schema
    assert schema["additionalProperties"] is False
    assert schema["required"] == ["items", "note", "score"]
    item = schema["properties"]["items"]["items"]
    assert item["additionalProperties"] is False
    assert "minimum" not in item["properties"]["page"]
    assert "maxLength" not in item["properties"]["label"]
    assert "default" not in schema["properties"]["score"]


def test_parse_json_text_variants():
    assert parse_json_text('{"a": 1}') == {"a": 1}
    assert parse_json_text('Here you go:\n```json\n{"a": 2}\n```') == {"a": 2}
    assert parse_json_text('Sure. {"a": 3} hope that helps') == {"a": 3}
    with pytest.raises(ValueError):
        parse_json_text("no json here")


def test_keystore_file_fallback(tmp_path):
    store = KeyStore(tmp_path, force_file=True)
    assert store.backend == "file"
    assert store.get("anthropic") is None
    store.set("anthropic", "  sk-ant-abcdef123456  ")
    assert store.get("anthropic") == "sk-ant-abcdef123456"
    if sys.platform != "win32":
        mode = stat.S_IMODE((tmp_path / "secrets.json").stat().st_mode)
        assert mode == 0o600
    store.delete("anthropic")
    assert store.get("anthropic") is None
    assert "readable only by your user" in store.describe()["detail"]


def test_last4_never_reveals_short_secrets():
    assert last4("sk-ant-abcdef123456") == "3456"
    assert last4("short") == "…"
    assert last4(None) is None


def test_cost_estimate_known_and_unknown_models():
    assert estimate_cost("anthropic", "claude-opus-5-5", input_tokens=1_000_000, output_tokens=1_000_000) == 24.0
    assert estimate_cost("anthropic", "not-a-model", input_tokens=10, output_tokens=10) is None
