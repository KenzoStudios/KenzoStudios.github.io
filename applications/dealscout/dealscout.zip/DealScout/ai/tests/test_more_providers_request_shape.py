"""xAI, Perplexity and custom-endpoint specifics (the generic behaviour is in test_contract.py)."""

from __future__ import annotations

import json

import httpx2
import pytest
from pydantic import BaseModel

from dealscout_ai import PageImage, PageText, PdfDocument, ProviderUnavailableError
from dealscout_ai.base import ProviderConfig
from dealscout_ai.registry import PROVIDERS
from dealscout_ai.testing import CustomHarness, PerplexityHarness, Scenario, XAIHarness


class Out(BaseModel):
    value: float | None
    reason: str | None


ANSWER = json.dumps({"value": 1.0, "reason": None})
PAGES = [PageText(page=3, text="Revenue 10"), PageImage(page=3, data=b"\x89PNG fake")]


def test_xai_responses_api_with_page_images_not_pdf():
    provider, rec = XAIHarness().build([Scenario(text=ANSWER)])
    assert not provider.capabilities().native_pdf and provider.capabilities().image_input
    provider.extract_structured(PAGES, Out, instructions="x")
    assert rec.paths[0] == "/v1/responses" and rec.headers[0]["host"] == "api.x.ai"
    body = rec.requests[0]
    assert body["text"]["format"]["type"] == "json_schema" and body["text"]["format"]["strict"] is True
    assert body["store"] is False
    assert [p["type"] for p in body["input"][0]["content"]].count("input_image") == 1


def test_perplexity_never_searches_the_web_and_reports_actual_cost():
    provider, rec = PerplexityHarness().build([Scenario(text=ANSWER)])
    result = provider.extract_structured(PAGES, Out, instructions="x")
    body = rec.requests[0]
    assert rec.headers[0]["host"] == "api.perplexity.ai" and rec.paths[0] == "/v1/responses"
    assert "tools" not in body and "effort" not in body and "store" not in body
    assert body["response_format"]["type"] == "json_schema"
    assert body["response_format"]["json_schema"]["name"] == "Out"
    assert result.usage.estimated_cost_usd == pytest.approx(0.0042)  # the cost Perplexity reported


def test_custom_endpoint_steps_down_to_json_mode_and_remembers():
    harness = CustomHarness()
    provider, rec = harness.build(
        [
            Scenario(status=400, error_message="response_format type json_schema is not supported"),
            Scenario(text=ANSWER),
            Scenario(text=ANSWER),
        ]
    )
    provider.extract_structured([PageText(page=1, text="x")], Out, instructions="x")
    assert rec.requests[0]["response_format"]["type"] == "json_schema"
    assert rec.requests[1]["response_format"]["type"] == "json_object"
    assert "The schema is" in json.dumps(rec.requests[1])
    provider.extract_structured([PageText(page=1, text="y")], Out, instructions="x")
    assert rec.requests[2]["response_format"]["type"] == "json_object"  # remembered: no failed call first
    assert rec.paths[0] == "/v1/chat/completions"
    assert rec.headers[0]["authorization"] == "Bearer not-needed"  # local servers need no key


def test_custom_endpoint_sends_images_only_to_vision_models():
    provider, rec = CustomHarness().build([Scenario(text=ANSWER)])
    assert not provider.capabilities().image_input
    provider.extract_structured(PAGES, Out, instructions="x")
    assert "image_url" not in json.dumps(rec.requests[0])
    vision, rec2 = CustomHarness().build([Scenario(text=ANSWER)], model="llava:13b")
    assert vision.capabilities().image_input
    vision.extract_structured([*PAGES, PdfDocument(data=b"%PDF")], Out, instructions="x")
    assert "data:image/png;base64," in json.dumps(rec2.requests[0])


def test_custom_endpoint_unreachable_says_what_to_check():
    from dealscout_ai.providers.custom import CustomOpenAIProvider

    def refuse(request: httpx2.Request) -> httpx2.Response:
        raise httpx2.ConnectError("connection refused", request=request)

    config = ProviderConfig(provider="custom", model="llama3.1", base_url="http://localhost:11434/v1", max_retries=0)
    provider = CustomOpenAIProvider(config, http_client=httpx2.Client(transport=httpx2.MockTransport(refuse)))
    with pytest.raises(ProviderUnavailableError, match="Ollama or LM Studio"):
        provider.extract_structured([PageText(page=1, text="x")], Out, instructions="x")
    result = provider.test_connection()
    assert not result.ok and result.code == "unreachable"


def test_every_listed_provider_is_implemented():
    assert all(spec.implemented for spec in PROVIDERS.values())
    assert PROVIDERS["custom"].key_required is False
