"""Anthropic-specific request-shape checks (the generic behaviour is covered by test_contract.py)."""

import json

from pydantic import BaseModel

from dealscout_ai import PageText, PdfDocument
from dealscout_ai.testing import AnthropicHarness, Scenario


class Out(BaseModel):
    value: float | None
    reason: str | None


ANSWER = json.dumps({"value": 1.0, "reason": None})


def test_structured_request_uses_output_config_and_fallbacks():
    provider, rec = AnthropicHarness().build([Scenario(text=ANSWER)])
    provider.extract_structured(
        [PdfDocument(data=b"%PDF-1.4 test", first_page=40, source_name="AR.pdf"), PageText(page=41, text="x")],
        Out,
        instructions="Extract.",
    )
    body = rec.requests[0]
    fmt = body["output_config"]["format"]
    assert fmt["type"] == "json_schema"
    assert fmt["schema"]["additionalProperties"] is False
    assert set(fmt["schema"]["required"]) == {"value", "reason"}
    assert body["output_config"]["effort"] == "high"
    assert body["fallbacks"] == "default"
    assert "server-side-fallback-2026-07-01" in rec.headers[0].get("anthropic-beta", "")
    assert "tool_choice" not in body
    blocks = body["messages"][0]["content"]
    doc = next(b for b in blocks if b["type"] == "document")
    assert doc["cache_control"] == {"type": "ephemeral"}
    assert any("page 40 of the source" in b.get("text", "") for b in blocks)
    assert any('<page number="41"' in b.get("text", "") for b in blocks)


def test_older_model_gets_no_fallbacks_or_effort():
    provider, rec = AnthropicHarness().build([Scenario(text=ANSWER)], model="claude-haiku-4-5")
    provider.extract_structured([PageText(page=1, text="x")], Out, instructions="Extract.")
    body = rec.requests[0]
    assert "fallbacks" not in body
    assert "effort" not in body["output_config"]
    assert rec.paths[0] == "/v1/messages"


def test_cost_uses_served_model():
    provider, _ = AnthropicHarness().build(
        [Scenario(text=ANSWER, model="claude-opus-4-8", input_tokens=1_000_000, output_tokens=0)]
    )
    result = provider.extract_structured([PageText(page=1, text="x")], Out, instructions="x")
    assert result.usage.model == "claude-opus-4-8"
    assert result.usage.estimated_cost_usd == 5.0
