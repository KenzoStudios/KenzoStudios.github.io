#!/usr/bin/env bash
# DealScout — development mode (macOS / Linux).
# FastAPI with auto-reload on :8000 and the Next.js dev server with hot reload on :3000.
# Open http://127.0.0.1:3000 — the dev server proxies /api/* to FastAPI. Ctrl+C stops both.
set -euo pipefail
cd "$(dirname "$0")"

command -v uv >/dev/null 2>&1 || { echo "✗ uv missing — see ./start.sh for install hints"; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "✗ Node.js/npm missing — see ./start.sh for install hints"; exit 1; }

uv sync --all-packages --quiet
[ -d web/node_modules ] || (cd web && npm install)

export NEXT_TELEMETRY_DISABLED=1
trap 'trap - INT TERM EXIT; kill 0 2>/dev/null || true' INT TERM EXIT

DEALSCOUT_DEV=1 uv run uvicorn dealscout_api.app:create_app --factory --reload \
  --host 127.0.0.1 --port "${DEALSCOUT_PORT:-8000}" \
  --reload-dir api/src --reload-dir engine/src --reload-dir ai/src --reload-dir extraction/src &

(cd web && npm run dev -- --hostname 127.0.0.1 --port 3000) &

echo "→ Dev servers starting: open http://127.0.0.1:3000"
wait
