"""FX rates per deal (brief §7) and the conversion of a deal's figures into its analysis currency.

Rates are only ever entered by the analyst, each with its date and source; there are no defaults. All arithmetic is
in ``dealscout_engine.fx``; this module loads the stored rates, calls the engine and words the notes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator

from dealscout_engine.fx import (
    FxRate,
    MissingRate,
    PeriodRates,
    UsedRate,
    convert_adjustments,
    convert_financial_data,
    convert_peer,
    rate_kind,
)
from dealscout_engine.scores import Adjustment
from dealscout_engine.statements import FinancialData
from dealscout_engine.valuation.calendarise import calendarise_peer
from dealscout_engine.valuation.comps import Peer

from ..models import Deal


class PeerRate(FxRate):
    """Units of the analysis currency per 1 unit of ``currency`` (a peer's reporting or listing currency)."""

    currency: str = Field(min_length=3, max_length=3)

    @field_validator("currency")
    @classmethod
    def _upper(cls, v: str) -> str:
        return v.upper()


class FxDoc(BaseModel):
    rates: list[PeriodRates] = Field(default_factory=list, max_length=200)
    peer_rates: list[PeerRate] = Field(default_factory=list, max_length=60)

    @model_validator(mode="after")
    def _unique(self) -> FxDoc:
        periods = [r.period_id for r in self.rates]
        if len(set(periods)) != len(periods):
            raise ValueError("each period can have only one set of rates")
        currencies = [r.currency for r in self.peer_rates]
        if len(set(currencies)) != len(currencies):
            raise ValueError("each peer currency can have only one rate")
        return self


def load_fx(raw: dict[str, Any] | None) -> FxDoc:
    try:
        return FxDoc.model_validate(raw or {})
    except ValueError:
        return FxDoc()


KIND_LABEL = {"average": "average rate", "closing": "closing rate"}


def describe_used(u: UsedRate) -> str:
    return f"{u.period_id} {KIND_LABEL[u.kind]}: {u.note}"


def describe_missing(missing: list[MissingRate]) -> str:
    return ", ".join(f"{m.period_id} {KIND_LABEL[m.kind]}" for m in missing)


@dataclass
class DealConversion:
    """A deal's figures in its analysis currency, or the reasons they could not be converted."""

    reporting_currency: str
    analysis_currency: str
    data: FinancialData
    adjustments: list[Adjustment]
    used: list[UsedRate] = field(default_factory=list)
    missing: list[MissingRate] = field(default_factory=list)

    @property
    def needed(self) -> bool:
        return self.reporting_currency != self.analysis_currency

    @property
    def complete(self) -> bool:
        return not self.missing

    @property
    def currency(self) -> str:
        """The currency the figures are in: the analysis currency once converted, otherwise the reporting one."""
        return self.analysis_currency if self.needed and self.complete else self.reporting_currency

    def message(self, what: str = "The valuation") -> str | None:
        if not self.missing:
            return None
        return (
            f"{what} is computed in {self.analysis_currency}, but these {self.reporting_currency} to "
            f"{self.analysis_currency} rates are missing: {describe_missing(self.missing)}. "
            "Enter them in the Currency section of the Data tab (each rate with its date and source)."
        )

    def summary(self) -> dict[str, Any]:
        return {
            "from": self.reporting_currency,
            "to": self.analysis_currency,
            "needed": self.needed,
            "converted": self.needed and self.complete,
            "currency": self.currency,
            "notes": [describe_used(u) for u in self.used],
            "used": [u.model_dump(mode="json") for u in self.used],
            "missing": [m.model_dump(mode="json") for m in self.missing],
            "message": self.message(),
        }


def convert_deal(deal: Deal, data: FinancialData, adjustments: list[Adjustment], doc: FxDoc) -> DealConversion:
    reporting, analysis = deal.reporting_currency.upper(), deal.analysis_currency.upper()
    if reporting == analysis:
        return DealConversion(reporting, analysis, data, adjustments)
    result = convert_financial_data(data, doc.rates)
    confirmed = [a for a in adjustments if a.confirmed]
    converted_adjustments, missing_adj = convert_adjustments(confirmed, doc.rates)
    known = {(m.period_id, m.kind) for m in result.missing}
    missing = list(result.missing) + [m for m in missing_adj if (m.period_id, m.kind) not in known]
    unconfirmed = [a for a in adjustments if not a.confirmed]  # not used in any figure; amounts kept as entered
    return DealConversion(
        reporting, analysis, result.data, converted_adjustments + unconfirmed, used=result.used, missing=missing
    )


def required_rates(data: FinancialData, period_ids: list[str]) -> dict[str, set[str]]:
    """Which rate kinds each period needs, given the values stored for it."""
    needed: dict[str, set[str]] = {p: set() for p in period_ids}
    for concept_id, period_id in data.values:
        kind = rate_kind(data.taxonomy.concept(concept_id))
        if kind is not None:
            needed.setdefault(period_id, set()).add(kind)
    return needed


@dataclass
class PeerPrep:
    peers: list[Peer]
    rows: list[dict[str, Any]]
    excluded: dict[str, str]


def prepare_peers(peers: list[Peer], analysis_currency: str, doc: FxDoc, target_year_end_month: int | None) -> PeerPrep:
    """Convert each peer to the analysis currency, then calendarise it to the target's fiscal year-end."""
    rates: dict[str, FxRate] = {r.currency: FxRate(rate=r.rate, as_of=r.as_of, source=r.source) for r in doc.peer_rates}
    ready: list[Peer] = []
    rows: list[dict[str, Any]] = []
    excluded: dict[str, str] = {}
    for peer in peers:
        conv = convert_peer(peer, analysis_currency, rates)
        row: dict[str, Any] = {
            "name": peer.name,
            "currency": conv.from_currency,
            "converted": conv.converted,
            "fx_note": conv.note,
            "missing_rate": conv.missing_rate,
            "calendarised": False,
            "calendar_note": None,
            "weights": None,
        }
        if conv.missing_rate:
            excluded[peer.name] = f"{conv.note}; enter it in the Currency section of the Data tab"
            rows.append(row)
            continue
        cal = calendarise_peer(conv.peer, target_year_end_month)
        row.update(calendarised=cal.calendarised, calendar_note=cal.note, weights=cal.weights)
        if peer.fiscal_year_end_month is not None and target_year_end_month is None:
            row["calendar_note"] = "Not calendarised: the target's fiscal year-end is unknown"
        rows.append(row)
        ready.append(cal.peer)
    return PeerPrep(peers=ready, rows=rows, excluded=excluded)
