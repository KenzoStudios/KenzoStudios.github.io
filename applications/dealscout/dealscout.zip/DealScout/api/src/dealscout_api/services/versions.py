"""Saved versions of a deal (brief §14): save a snapshot, list, compare with the current deal, restore.

A version holds the deal's inputs (analysis fields of the deal, periods, every stored value with its provenance,
the assumptions document: overrides, peers, notes, entry settings, method inputs) in the same shape as the JSON
export, plus the headline results at the time. Versions are never edited. Restoring first saves the current state
as an automatic "before restore" version, so a restore can itself be undone.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

from sqlmodel import Session, col, delete, select

from dealscout_engine.taxonomy import load_taxonomy
from dealscout_engine.versions import diff_fields, diff_values, result_deltas

from ..exports import deal_json
from ..models import Deal, DealAssumptions, DealVersion, FinancialValue, Period, ValueChange, utcnow
from . import audit
from .app_settings import load_preferences
from .methods import load_methods

# deal fields that shape the analysis and travel with a version (the name, notes and workflow state do not)
DEAL_FIELDS = (
    "country",
    "sector",
    "industry",
    "listed",
    "ticker",
    "reporting_currency",
    "analysis_currency",
    "valuation_date",
    "perspective",
    "sector_template",
)
ASSUMPTION_FIELDS = tuple(f for f in DealAssumptions.model_fields if f not in {"deal_id", "updated_at"})
MAX_LISTED_DIFFS = 500


def _state(session: Session, deal: Deal, valuation: dict[str, Any]) -> dict[str, Any]:
    """The deal's inputs and headline results, in the JSON export's shape."""
    return deal_json.export_deal(session, deal, valuation)


def save_version(
    session: Session,
    deal: Deal,
    valuation: dict[str, Any],
    *,
    name: str,
    note: str | None = None,
    kind: str = "manual",
) -> DealVersion:
    """Add a version (caller commits)."""
    state = _state(session, deal, valuation)
    version = DealVersion(
        deal_id=deal.id,
        name=name.strip()[:120],
        note=(note or "").strip()[:2000] or None,
        kind=kind,
        snapshot={k: state[k] for k in ("format", "version", "deal", "periods", "values", "assumptions")},
        results=state["results"],
        created_by=load_preferences(session).user_name,
    )
    session.add(version)
    audit.record(
        session,
        "version_saved",
        deal_id=deal.id,
        detail={"version_id": version.id, "name": version.name, "kind": kind},
    )
    return version


def version_row(v: DealVersion) -> dict[str, Any]:
    snap = v.snapshot or {}
    return {
        "id": v.id,
        "name": v.name,
        "note": v.note,
        "kind": v.kind,
        "created_at": v.created_at,
        "created_by": v.created_by,
        "results": v.results,
        "counts": {"periods": len(snap.get("periods") or []), "values": len(snap.get("values") or [])},
    }


def list_versions(session: Session, deal_id: str) -> list[DealVersion]:
    stmt = select(DealVersion).where(DealVersion.deal_id == deal_id).order_by(col(DealVersion.created_at).desc())
    return list(session.exec(stmt).all())


def _cells(values: list[dict[str, Any]]) -> dict[tuple[str, str], float]:
    return {(v["period_key"], v["concept_id"]): float(v["value"]) for v in values if v.get("value") is not None}


def _peers(peers: list[dict[str, Any]]) -> dict[str, Any]:
    return {str(p.get("name") or f"Peer {i + 1}"): p for i, p in enumerate(peers or [])}


def compare(session: Session, deal: Deal, version: DealVersion, valuation: dict[str, Any]) -> dict[str, Any]:
    """What changed between the version and the current deal: inputs and headline results."""
    now = _state(session, deal, valuation)
    snap = version.snapshot or {}
    taxonomy = load_taxonomy()

    def label(concept_id: str) -> str:
        return taxonomy.concept(concept_id).name if taxonomy.has(concept_id) else concept_id

    then_deal = {k: (snap.get("deal") or {}).get(k) for k in DEAL_FIELDS}
    now_deal = {k: now["deal"].get(k) for k in DEAL_FIELDS}
    then_periods = {p["key"] for p in snap.get("periods") or []}
    now_periods = {p["key"] for p in now["periods"]}
    values = diff_values(_cells(snap.get("values") or []), _cells(now["values"]))
    a_then, a_now = snap.get("assumptions") or {}, now["assumptions"] or {}
    inputs = [
        *diff_fields("deal", then_deal, now_deal),
        *diff_fields("overrides", a_then.get("overrides") or {}, a_now.get("overrides") or {}),
        *diff_fields("peers", _peers(a_then.get("peers") or []), _peers(a_now.get("peers") or [])),
        *diff_fields("notes", a_then.get("notes") or {}, a_now.get("notes") or {}),
        *diff_fields("entry", a_then.get("entry") or {}, a_now.get("entry") or {}),
        # method inputs compared after defaults are filled in, so an unsaved default never shows as a change
        *diff_fields(
            "methods",
            load_methods(a_then.get("methods")).model_dump(mode="json"),
            load_methods(a_now.get("methods")).model_dump(mode="json"),
        ),
    ]
    # other assumption documents added later (e.g. currency settings) are compared as a whole
    for extra in sorted(set(a_then) | set(a_now)):
        if extra not in {"overrides", "peers", "notes", "entry", "methods"} and a_then.get(extra) != a_now.get(extra):
            inputs += diff_fields("assumptions", {extra: a_then.get(extra)}, {extra: a_now.get(extra)})
    return {
        "version": version_row(version),
        "periods": {"added": sorted(now_periods - then_periods), "removed": sorted(then_periods - now_periods)},
        "values": [{**d.model_dump(), "label": label(d.concept_id)} for d in values[:MAX_LISTED_DIFFS]],
        "values_total": len(values),
        "inputs": [d.model_dump(mode="json") for d in inputs[:MAX_LISTED_DIFFS]],
        "inputs_total": len(inputs),
        "results": [d.model_dump() for d in result_deltas(version.results or {}, now["results"])],
        "methods": {
            "version": (version.results or {}).get("methods") or [],
            "current": now["results"].get("methods") or [],
        },
    }


def _date(value: Any) -> date | None:
    return date.fromisoformat(value) if isinstance(value, str) and value else None


def restore(session: Session, deal: Deal, version: DealVersion) -> None:
    """Replace the deal's inputs with the version's (caller saves the "before restore" version and commits)."""
    snap = version.snapshot or {}
    actor = load_preferences(session).user_name
    reason = f"Restored version '{version.name}'"[:500]

    # deal fields
    saved_deal = snap.get("deal") or {}
    for key in DEAL_FIELDS:
        if key in saved_deal:
            value = saved_deal[key]
            setattr(deal, key, _date(value) if key == "valuation_date" else value)

    # periods
    session.exec(delete(Period).where(col(Period.deal_id) == deal.id))
    for p in snap.get("periods") or []:
        row = deal_json._clean(dict(p), Period)
        row["end_date"] = _date(row.get("end_date"))
        session.add(Period(**row, deal_id=deal.id))

    # values: every difference is logged in the value history like any other edit
    current = {
        (v.period_key, v.concept_id): v
        for v in session.exec(select(FinancialValue).where(FinancialValue.deal_id == deal.id)).all()
    }
    saved = {(v["period_key"], v["concept_id"]): v for v in snap.get("values") or []}
    for cell in sorted(set(current) | set(saved)):
        old, new = current.get(cell), saved.get(cell)
        old_value = old.value if old else None
        new_value = float(new["value"]) if new else None
        if old_value != new_value:
            session.add(
                ValueChange(
                    deal_id=deal.id,
                    period_key=cell[0],
                    concept_id=cell[1],
                    old_value=old_value,
                    new_value=new_value,
                    old_source=old.source if old else None,
                    new_source=new.get("source") if new else None,
                    reason=reason,
                    actor=actor,
                )
            )
    session.exec(delete(FinancialValue).where(col(FinancialValue.deal_id) == deal.id))
    session.flush()
    for v in saved.values():
        row = deal_json._clean(dict(v), FinancialValue)
        row["provenance"] = deal_json._provenance(row.get("provenance"))
        stamp = v.get("updated_at")
        session.add(
            FinancialValue(
                **row,
                deal_id=deal.id,
                updated_at=datetime.fromisoformat(stamp) if isinstance(stamp, str) else utcnow(),
            )
        )

    # assumptions: every field, so one added after the version was saved returns to its default
    doc = session.get(DealAssumptions, deal.id) or DealAssumptions(deal_id=deal.id)
    saved_a = snap.get("assumptions") or {}
    for field in ASSUMPTION_FIELDS:
        if field in saved_a:
            setattr(doc, field, saved_a[field])
        else:
            setattr(doc, field, DealAssumptions.model_fields[field].get_default(call_default_factory=True))
    doc.updated_at = utcnow()
    deal.updated_at = utcnow()
    session.add(doc)
    session.add(deal)
    audit.record(
        session,
        "version_restored",
        deal_id=deal.id,
        detail={"version_id": version.id, "name": version.name},
    )
