"""Text-based early-warning signs from a deal's processed documents (brief §8).

The rules scanner in :mod:`dealscout_extraction.text_signals` runs over each processed narrative document (PDF, HTML,
tagged filing, Word, OCR'd image). Results are cached in the app data folder by the file's SHA-256 and the rules
version, so the analysis endpoint re-reads a document only once. No AI is involved.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from typing import Any

from sqlmodel import Session, col, select

from dealscout_engine.scores import RedFlag
from dealscout_extraction.ingest import read_document
from dealscout_extraction.text_signals import (
    NARRATIVE_KINDS,
    RULES_VERSION,
    TextSignal,
    document_year,
    scan_document,
    to_red_flags,
)

from ..config import Settings
from ..models import Document, ExtractedItem
from .documents import document_path

log = logging.getLogger(__name__)
MAX_DOCUMENTS = 12


def _scan_cached(settings: Settings, doc: Document) -> tuple[list[TextSignal], int | None] | None:
    """Signals (without document id/filename) and the reporting year; ``None`` when the file cannot be read."""
    cache = settings.cache_dir / "text_signals" / f"{doc.sha256}-{RULES_VERSION}.json"
    if cache.exists():
        try:
            raw: dict[str, Any] = json.loads(cache.read_text(encoding="utf-8"))
            return [TextSignal.model_validate(s) for s in raw["signals"]], raw.get("year")
        except (ValueError, KeyError):
            cache.unlink(missing_ok=True)
    path = document_path(settings, doc)
    if not path.exists():
        return None
    try:
        content = read_document(path.read_bytes(), doc.filename)
    except Exception:  # a damaged file must not break the analysis screen
        log.warning("text signals: document %s could not be read", doc.id)
        return None
    signals = scan_document(content)
    year = document_year(content)
    cache.parent.mkdir(parents=True, exist_ok=True)
    tmp = cache.with_suffix(f".{uuid.uuid4().hex}.tmp")
    tmp.write_text(
        json.dumps({"signals": [s.model_dump(mode="json") for s in signals], "year": year}), encoding="utf-8"
    )
    os.replace(tmp, cache)  # atomic: a concurrent request never reads half a file
    return signals, year


def _document_period(session: Session, doc: Document, year: int | None, annual_keys: list[str]) -> str:
    """The latest annual period the document's extracted figures belong to, else the year in its wording."""
    periods = session.exec(select(ExtractedItem.period_key).where(ExtractedItem.document_id == doc.id).distinct()).all()
    annual = sorted(p for p in periods if p.startswith("FY"))
    if annual:
        return annual[-1]
    if year is not None:
        return f"FY{year}"
    return annual_keys[-1] if annual_keys else "Document"


def document_red_flags(
    session: Session, settings: Settings, deal_id: str, annual_keys: list[str]
) -> tuple[list[RedFlag], int]:
    """Early-warning signs found in the deal's processed documents and the number of documents scanned."""
    docs = session.exec(
        select(Document)
        .where(Document.deal_id == deal_id, Document.status == "processed")
        .order_by(col(Document.uploaded_at).desc())
    ).all()
    docs = [d for d in docs if d.kind in NARRATIVE_KINDS][:MAX_DOCUMENTS]
    flags: list[RedFlag] = []
    scanned = 0
    for doc in docs:
        result = _scan_cached(settings, doc)
        if result is None:
            continue
        scanned += 1
        signals, year = result
        if not signals:
            continue
        tagged = [s.model_copy(update={"document_id": doc.id, "filename": doc.filename}) for s in signals]
        flags += to_red_flags(tagged, period=_document_period(session, doc, year, annual_keys))
    flags.sort(key=lambda f: (f.severity != "high", f.signal))
    return flags, scanned
