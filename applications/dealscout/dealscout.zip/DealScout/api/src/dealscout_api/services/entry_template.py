"""Blank Excel template for manual entry (brief §12), built with openpyxl.

Conventions (xlsx skill + brief §14A): one palette (data/design/palette.json), Calibri, input cells in blue font on a
light input fill, formulas in black, subtotals as live formulas that stay blank until a component is filled,
negatives in parentheses, gridlines hidden, frozen panes, print footer with the disclaimer. Column A holds the
canonical concept id (hidden) so a re-uploaded template maps back exactly.
"""

from __future__ import annotations

import io
import json
from datetime import date
from typing import Any

from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.worksheet import Worksheet

from dealscout_engine.taxonomy import load_taxonomy

from ..config import get_settings
from ..models import Deal, Period
from .financials import STATEMENT_LABELS, template_statements
from .reference import disclaimers

FONT = "Calibri"
SCALES = {"units": 1.0, "thousands": 1e3, "millions": 1e6, "billions": 1e9}
SCALE_NAMES = {v: k for k, v in SCALES.items()}
TEMPLATE_VERSION = "1"
FIRST_ROW = 5  # first line-item row on statement sheets
HEADER_ROW = 4


def _palette() -> dict[str, Any]:
    with open(get_settings().reference_dir / "design" / "palette.json", encoding="utf-8") as fh:
        data: dict[str, Any] = json.load(fh)
    return data


def _hex(color: str) -> str:
    return color.lstrip("#").upper()


def _number_format(unit: str) -> str:
    if unit == "percent":
        return '0.0%;(0.0%);"-"'
    if unit == "per_share":
        return '#,##0.00;(#,##0.00);"-"'
    if unit in ("shares", "count"):
        return '#,##0;(#,##0);"-"'
    return '#,##0.0;(#,##0.0);"-"'


def _footer(ws: Worksheet, text: str) -> None:
    ws.oddFooter.left.text = text
    ws.oddFooter.left.size = 8
    ws.oddFooter.right.text = "Page &P of &N"
    ws.oddFooter.right.size = 8


def build_entry_template(deal: Deal, periods: list[Period], scale: float) -> bytes:
    pal = _palette()
    navy, grey_band, grey_line = _hex(pal["brand"]["navy"]), _hex(pal["grey"]["100"]), _hex(pal["grey"]["200"])
    input_fill = PatternFill("solid", fgColor="FFF9E6")  # light input fill (yellow family, softened)
    band = PatternFill("solid", fgColor=grey_band)
    header_fill = PatternFill("solid", fgColor=navy)
    thin = Side(style="thin", color=grey_line)
    blue_input = Font(name=FONT, size=10, color="0000FF")
    black = Font(name=FONT, size=10, color="000000")
    bold = Font(name=FONT, size=10, bold=True, color="000000")
    white_bold = Font(name=FONT, size=10, bold=True, color="FFFFFF")
    muted = Font(name=FONT, size=9, color=_hex(pal["grey"]["600"]))
    taxonomy = load_taxonomy()
    disc = disclaimers()
    keys = [p.key for p in periods]

    wb = Workbook()
    wb.properties.title = f"DealScout entry template: {deal.name}"
    wb.properties.subject = "Manual financial data entry"
    wb.properties.creator = "DealScout (AI-generated)"

    # ── Instructions ────────────────────────────────────────────────────
    ws = wb.active
    assert ws is not None
    ws.title = "Instructions"
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 2
    ws.column_dimensions["B"].width = 34
    ws.column_dimensions["C"].width = 22
    ws.column_dimensions["D"].width = 60
    ws["B2"] = "DealScout: financial data entry"
    ws["B2"].font = Font(name=FONT, size=20, bold=True, color=navy)
    ws["B3"] = deal.name
    ws["B3"].font = Font(name=FONT, size=12, bold=True)
    ws["B4"] = f"Reporting currency {deal.reporting_currency} · generated {date.today().isoformat()}"
    ws["B4"].font = muted
    rows: list[tuple[str, Any, str]] = [
        (
            "Units of the figures you enter",
            SCALE_NAMES.get(scale, "millions"),
            "Pick from the list. Applies to every statement sheet.",
        ),
        ("Currency", deal.reporting_currency, "Reporting currency of the statements (set on the deal)."),
    ]
    for i, (label, value, note) in enumerate(rows, start=6):
        ws.cell(row=i, column=2, value=label).font = bold
        cell = ws.cell(row=i, column=3, value=value)
        cell.font = blue_input if i == 6 else black
        cell.fill = input_fill if i == 6 else PatternFill()
        cell.border = Border(top=thin, bottom=thin, left=thin, right=thin)
        ws.cell(row=i, column=4, value=note).font = muted
    units_validation = DataValidation(type="list", formula1='"units,thousands,millions,billions"', allow_blank=False)
    units_validation.error = "Choose units, thousands, millions or billions."
    ws.add_data_validation(units_validation)
    units_validation.add("C6")

    ws["B9"] = "How to fill it in"
    ws["B9"].font = Font(name=FONT, size=12, bold=True, color=navy)
    guidance = [
        "Blue figures on a light fill are inputs: type over them. Black figures are formulas (subtotals).",
        "Enter costs, expenses and cash outflows as positive amounts (or in parentheses); DealScout records them "
        "as costs.",
        "Subtotals fill themselves from their lines. To record a subtotal exactly as reported, type over the formula.",
        "Leave a cell blank when the figure is not available. Never enter 0 for 'unknown'.",
        "Add a period by typing its key (e.g. FY2022, H1-2026) into a blank header cell to the right.",
        "Do not change column A (hidden line-item codes) or the sheet names; upload the file on the deal's data page.",
    ]
    for i, line in enumerate(guidance, start=10):
        ws.cell(row=i, column=2, value=f"• {line}").font = black
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=4)
        ws.cell(row=i, column=2).alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[i].height = 28

    ws["B17"] = "Example (format only, not real data)"
    ws["B17"].font = Font(name=FONT, size=12, bold=True, color=navy)
    example = [
        ("Line item", "FY2025", "Note"),
        ("Revenue", 1234.5, "Positive"),
        ("Cost of sales", 800.1, "Cost: entered as a positive amount"),
        ("Gross profit", '=IF(COUNT(C19:C20)=0,"",C19-C20)', "Formula: revenue − cost of sales"),
    ]
    for r, (a, b, c) in enumerate(example, start=18):
        ws.cell(row=r, column=2, value=a).font = white_bold if r == 18 else bold if r == 21 else black
        v = ws.cell(row=r, column=3, value=b)
        v.font = white_bold if r == 18 else (black if r == 21 else blue_input)
        if r in (19, 20):
            v.fill = input_fill
        v.number_format = '#,##0.0;(#,##0.0);"-"'
        ws.cell(row=r, column=4, value=c).font = white_bold if r == 18 else muted
        if r == 18:
            for col in (2, 3, 4):
                ws.cell(row=r, column=col).fill = header_fill

    ws["B24"] = disc["ai_report_notice"].replace(
        "This report was generated", "Outputs built from this data are generated"
    )
    ws["B24"].font = muted
    ws["B24"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.merge_cells("B24:D26")
    ws.page_setup.orientation = "portrait"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    _footer(ws, disc["print_footer"])

    # ── statement sheets ────────────────────────────────────────────────
    units_ref = "Instructions!$C$6"
    currency_ref = "Instructions!$C$7"
    for statement in template_statements(deal.sector_template):
        sheet: Worksheet = wb.create_sheet(STATEMENT_LABELS.get(statement["id"], statement["id"])[:31])
        sheet.sheet_view.showGridLines = False
        sheet.sheet_properties.tabColor = navy
        sheet.column_dimensions["A"].width = 24
        sheet.column_dimensions["A"].hidden = True
        sheet.column_dimensions["B"].width = 46
        for j in range(len(keys) + 3):
            sheet.column_dimensions[get_column_letter(3 + j)].width = 14
        sheet["B1"] = STATEMENT_LABELS.get(statement["id"], statement["id"])
        sheet["B1"].font = Font(name=FONT, size=14, bold=True, color=navy)
        safe_name = deal.name.replace(chr(34), "")
        note = f"(per-share figures in {deal.reporting_currency}; share counts in units)"
        sheet["B2"] = f'="{safe_name} · "&{currency_ref}&" "&{units_ref}&" {note}"'
        sheet["B2"].font = muted
        sheet.cell(row=HEADER_ROW, column=1, value="concept_id").font = muted
        sheet.cell(row=HEADER_ROW, column=2, value="Line item").font = white_bold
        sheet.cell(row=HEADER_ROW, column=2).fill = header_fill
        for j, key in enumerate(keys):
            c = sheet.cell(row=HEADER_ROW, column=3 + j, value=key)
            c.font = white_bold
            c.fill = header_fill
            c.alignment = Alignment(horizontal="right")
        row_of: dict[str, int] = {}
        for i, row in enumerate(statement["rows"]):
            row_of[row["id"]] = FIRST_ROW + i
        for i, row in enumerate(statement["rows"]):
            r = FIRST_ROW + i
            concept = taxonomy.concept(row["id"])
            sheet.cell(row=r, column=1, value=concept.id).font = muted
            label_cell = sheet.cell(row=r, column=2, value=("    " * row.get("indent", 0)) + concept.name)
            components_here = concept.aggregation == "sum" and all(c in row_of for c in concept.components)
            label_cell.font = bold if components_here else black
            if concept.sign == "negative":
                label_cell.comment = Comment(
                    "Enter as a positive amount; DealScout records it as a cost/outflow.", "DealScout"
                )
            if i % 2 == 1:
                label_cell.fill = band
            for j in range(len(keys)):
                col = 3 + j
                letter = get_column_letter(col)
                cell = sheet.cell(row=r, column=col)
                cell.number_format = _number_format(concept.unit)
                cell.border = Border(bottom=thin)
                if components_here:
                    terms = []
                    for comp in concept.components:
                        comp_sign = -1 if taxonomy.concept(comp).sign == "negative" else 1
                        parent_sign = -1 if concept.sign == "negative" else 1
                        sign = comp_sign * parent_sign
                        terms.append(("+" if sign > 0 else "-") + f"{letter}{row_of[comp]}")
                    refs = ",".join(f"{letter}{row_of[c]}" for c in concept.components)
                    expression = "".join(terms).lstrip("+")
                    cell.value = f'=IF(COUNT({refs})=0,"",{expression})'
                    cell.font = bold
                else:
                    cell.font = blue_input
                    cell.fill = input_fill
        sheet.freeze_panes = sheet.cell(row=FIRST_ROW, column=3)
        sheet.print_title_rows = f"{HEADER_ROW}:{HEADER_ROW}"
        sheet.page_setup.orientation = "landscape"
        sheet.page_setup.fitToWidth = 1
        sheet.page_setup.fitToHeight = 0
        sheet.sheet_properties.pageSetUpPr.fitToPage = True
        sheet.oddHeader.left.text = deal.name.replace("&", "&&")
        sheet.oddHeader.right.text = date.today().isoformat()
        _footer(sheet, disc["print_footer"])

    meta = wb.create_sheet("_dealscout")
    meta["A1"], meta["B1"] = "deal_id", deal.id
    meta["A2"], meta["B2"] = "template_version", TEMPLATE_VERSION
    meta["A3"], meta["B3"] = "sector_template", deal.sector_template
    meta.sheet_state = "hidden"

    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()
