from __future__ import annotations

from typing import Any

from sqlmodel import Session

from ..models import AuditEvent
from .app_settings import load_preferences


def record(session: Session, action: str, *, deal_id: str | None = None, detail: dict[str, Any] | None = None) -> None:
    """Add an audit event (caller commits). The actor is the user name set in Settings."""
    actor = load_preferences(session).user_name
    session.add(AuditEvent(deal_id=deal_id, action=action, actor=actor, detail=detail or {}))
