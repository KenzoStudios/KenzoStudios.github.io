"""Deal financial data: periods, values, change log, grid payloads and reconciliation."""

from __future__ import annotations

from datetime import date
from functools import lru_cache
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field
from sqlalchemy.exc import IntegrityError
from sqlmodel import Session, col, select

from dealscout_engine.ltm import compute_ltm, plan_ltm
from dealscout_engine.reconciliation import run_checks, summarise
from dealscout_engine.statements import FinancialData
from dealscout_engine.taxonomy import load_taxonomy

from ..config import get_settings
from ..models import Deal, DealAssumptions, FinancialValue, Period, ValueChange, utcnow
from . import audit
from .app_settings import load_preferences
from .reference import sector_template

DEFAULT_ENTRY = {"scale": 1e6, "decimal_hint": None, "fiscal_year_end": "12-31"}
STATEMENT_LABELS = {
    "income_statement": "Income statement",
    "balance_sheet": "Balance sheet",
    "cash_flow": "Cash flow",
    "memo": "Shares & memo",
    "sector_kpi": "Sector KPIs",
}


@lru_cache(maxsize=1)
def templates() -> dict[str, Any]:
    with open(get_settings().reference_dir / "taxonomy" / "templates.yaml", encoding="utf-8") as fh:
        data: dict[str, Any] = yaml.safe_load(fh)
    return data


def effective_template(deal: Deal) -> str:
    """The deal's statement template; a deal saved as "general" picks up a sector template added later."""
    if deal.sector_template != "general":
        return deal.sector_template
    return sector_template(deal.sector)


def template_statements(template_id: str) -> list[dict[str, Any]]:
    """Rows per statement for a sector template (base rows + template extras)."""
    spec = templates()
    extra = spec["templates"].get(template_id, spec["templates"]["general"])["extra"]
    statements: list[dict[str, Any]] = []
    for statement, rows in spec["base"].items():
        normalised = [r if isinstance(r, dict) else {"id": r, "indent": 0} for r in rows]
        if statement == "balance_sheet" and extra.get("balance_sheet_after_ppe"):
            at = next(i for i, r in enumerate(normalised) if r["id"] == "ppe") + 1
            normalised[at:at] = [{"id": c, "indent": 1} for c in extra["balance_sheet_after_ppe"]]
        statements.append({"id": statement, "rows": normalised})
    if extra.get("sector_kpi"):
        statements.append({"id": "sector_kpi", "rows": [{"id": c, "indent": 0} for c in extra["sector_kpi"]]})
    return statements


# ── assumptions document ───────────────────────────────────────────────────────
def assumptions_doc(session: Session, deal_id: str) -> DealAssumptions:
    doc = session.get(DealAssumptions, deal_id)
    if doc is None:
        session.add(DealAssumptions(deal_id=deal_id, entry=dict(DEFAULT_ENTRY)))
        try:
            session.commit()
        except IntegrityError:
            # a concurrent request for the same new deal created it first: use theirs
            session.rollback()
        doc = session.get(DealAssumptions, deal_id)
        assert doc is not None
        session.refresh(doc)
    return doc


def entry_settings(session: Session, deal_id: str) -> dict[str, Any]:
    return {**DEFAULT_ENTRY, **(assumptions_doc(session, deal_id).entry or {})}


# ── periods ────────────────────────────────────────────────────────────────────
def _fy_end(fiscal_year: int, fiscal_year_end: str) -> date:
    month, day = (int(x) for x in fiscal_year_end.split("-"))
    while True:
        try:
            return date(fiscal_year, month, day)
        except ValueError:
            day -= 1


def ensure_periods(session: Session, deal: Deal) -> list[Period]:
    periods = list_periods(session, deal.id)
    if periods:
        return periods
    fye = entry_settings(session, deal.id)["fiscal_year_end"]
    latest = (
        deal.valuation_date.year
        if _fy_end(deal.valuation_date.year, fye) <= deal.valuation_date
        else deal.valuation_date.year - 1
    )
    for offset in (2, 1, 0):
        fy = latest - offset
        session.add(
            Period(
                deal_id=deal.id,
                key=f"FY{fy}",
                kind="annual",
                fiscal_year=fy,
                end_date=_fy_end(fy, fye),
                label=f"FY{fy}",
            )
        )
    try:
        session.commit()
    except IntegrityError:
        # several screens load a new deal at once: another request created the default periods first
        session.rollback()
    return list_periods(session, deal.id)


def list_periods(session: Session, deal_id: str) -> list[Period]:
    periods = list(session.exec(select(Period).where(Period.deal_id == deal_id)).all())
    return sorted(periods, key=lambda p: (p.end_date or date(p.fiscal_year or 1900, 12, 31), p.sort_order, p.key))


def annual_periods(periods: list[Period]) -> list[Period]:
    return [p for p in periods if p.kind == "annual"]


def prior_map(periods: list[Period]) -> dict[str, str]:
    """Each annual period → the previous annual period."""
    annual = annual_periods(periods)
    return {annual[i].key: annual[i - 1].key for i in range(1, len(annual))}


# ── values ─────────────────────────────────────────────────────────────────────
def load_values(session: Session, deal_id: str) -> list[FinancialValue]:
    return list(session.exec(select(FinancialValue).where(FinancialValue.deal_id == deal_id)).all())


def financial_data(session: Session, deal_id: str) -> FinancialData:
    data = FinancialData(load_taxonomy())
    for v in load_values(session, deal_id):
        if load_taxonomy().has(v.concept_id):
            data.values[(v.concept_id, v.period_key)] = v.value
    return data


class CellChange(BaseModel):
    concept_id: str
    period_key: str
    value: float | None  # absolute units, taxonomy sign; None deletes the value
    entered_text: str | None = Field(default=None, max_length=120)
    reason: str | None = Field(default=None, max_length=500)
    provenance: dict[str, Any] | None = None  # document, page, label, scale … for extracted values
    confidence: float | None = None


def apply_changes(
    session: Session,
    deal: Deal,
    changes: list[CellChange],
    *,
    source: Literal["manual", "paste", "template", "extracted"] = "manual",
) -> dict[str, int]:
    taxonomy = load_taxonomy()
    keys = {p.key for p in ensure_periods(session, deal)}
    actor = load_preferences(session).user_name
    scale = entry_settings(session, deal.id)["scale"]
    existing = {(v.concept_id, v.period_key): v for v in load_values(session, deal.id)}
    counts = {"created": 0, "updated": 0, "deleted": 0, "unchanged": 0}
    for change in changes:
        if not taxonomy.has(change.concept_id):
            raise ValueError(f"Unknown line item '{change.concept_id}'.")
        if change.period_key not in keys:
            raise ValueError(f"Unknown period '{change.period_key}'. Add the period first.")
        current = existing.get((change.concept_id, change.period_key))
        if change.value is None:
            if current is None:
                counts["unchanged"] += 1
                continue
            session.add(
                ValueChange(
                    deal_id=deal.id,
                    period_key=change.period_key,
                    concept_id=change.concept_id,
                    old_value=current.value,
                    new_value=None,
                    old_source=current.source,
                    new_source=None,
                    reason=change.reason,
                    actor=actor,
                )
            )
            session.delete(current)
            counts["deleted"] += 1
            continue
        if current is not None and current.value == change.value:
            counts["unchanged"] += 1
            continue
        session.add(
            ValueChange(
                deal_id=deal.id,
                period_key=change.period_key,
                concept_id=change.concept_id,
                old_value=current.value if current else None,
                new_value=change.value,
                old_source=current.source if current else None,
                new_source=source,
                reason=change.reason,
                actor=actor,
            )
        )
        if current is None:
            session.add(
                FinancialValue(
                    deal_id=deal.id,
                    period_key=change.period_key,
                    concept_id=change.concept_id,
                    value=change.value,
                    source=source,
                    entered_scale=scale,
                    entered_text=change.entered_text,
                    currency=deal.reporting_currency,
                    updated_by=actor,
                    provenance=change.provenance or {},
                    confidence=change.confidence,
                )
            )
            counts["created"] += 1
        else:
            current.value = change.value
            current.source = source
            current.entered_scale = scale
            current.entered_text = change.entered_text
            current.provenance = change.provenance or {}
            current.confidence = change.confidence
            current.updated_by = actor
            current.updated_at = utcnow()
            session.add(current)
            counts["updated"] += 1
    if counts["created"] + counts["updated"] + counts["deleted"]:
        deal.updated_at = utcnow()
        session.add(deal)
        audit.record(session, "financials_edited", deal_id=deal.id, detail={"source": source, **counts})
    session.commit()
    return counts


def value_history(session: Session, deal_id: str, concept_id: str, period_key: str) -> list[ValueChange]:
    stmt = (
        select(ValueChange)
        .where(
            ValueChange.deal_id == deal_id, ValueChange.concept_id == concept_id, ValueChange.period_key == period_key
        )
        .order_by(col(ValueChange.at).desc())
    )
    return list(session.exec(stmt).all())


# ── grid payload ───────────────────────────────────────────────────────────────
def grid_payload(session: Session, deal: Deal) -> dict[str, Any]:
    taxonomy = load_taxonomy()
    periods = ensure_periods(session, deal)
    values = {(v.concept_id, v.period_key): v for v in load_values(session, deal.id)}
    data = financial_data(session, deal.id)
    statements = []
    for statement in template_statements(effective_template(deal)):
        rows = []
        for row in statement["rows"]:
            concept = taxonomy.concept(row["id"])
            cells: dict[str, Any] = {}
            for p in periods:
                stored = values.get((concept.id, p.key))
                if stored is not None:
                    cells[p.key] = {
                        "value": stored.value,
                        "kind": "entered",
                        "source": stored.source,
                        "updated_by": stored.updated_by,
                        "updated_at": stored.updated_at.isoformat(),
                        "entered_text": stored.entered_text,
                    }
                elif concept.aggregation != "leaf":
                    resolved = data.resolve(concept.id, p.key)
                    if resolved.value is not None:
                        cells[p.key] = {
                            "value": resolved.value,
                            "kind": "computed",
                            "formula": resolved.derivation.formula,
                            "note": resolved.derivation.note,
                        }
            rows.append(
                {
                    "concept_id": concept.id,
                    "name": concept.name,
                    "definition": concept.definition,
                    "sign": concept.sign,
                    "unit": concept.unit,
                    "aggregation": concept.aggregation,
                    "indent": row.get("indent", 0),
                    "formula": concept.formula or (" + ".join(concept.components) if concept.components else None),
                    "cells": cells,
                }
            )
        statements.append(
            {"id": statement["id"], "label": STATEMENT_LABELS.get(statement["id"], statement["id"]), "rows": rows}
        )
    # LTM columns are computed (latest YTD + last full year − prior-year YTD) and never editable
    ltm_periods = []
    for plan in plan_ltm([p.key for p in periods]):
        computed = compute_ltm(data, plan)
        if not computed:
            continue
        ltm_periods.append(
            {
                "key": plan.key,
                "label": plan.label,
                "kind": "ltm",
                "virtual": True,
                "inputs": [plan.latest_ytd, plan.prior_full_year, plan.prior_year_ytd],
            }
        )
        for statement in statements:
            for row in statement["rows"]:
                if row["concept_id"] in computed:
                    value, derivation = computed[row["concept_id"]]
                    row["cells"][plan.key] = {
                        "value": value,
                        "kind": "computed",
                        "formula": derivation.formula,
                        "note": derivation.note,
                    }
    entry = entry_settings(session, deal.id)
    checks = run_checks(data, [p.key for p in periods], prior_period=prior_map(periods), rounding_unit=entry["scale"])
    tpl = templates()
    minimum = list(tpl["quick_scan_minimum"]) + (list(tpl["quick_scan_listed"]) if deal.listed else [])
    latest = annual_periods(periods)[-1].key if annual_periods(periods) else None
    missing_minimum = [c for c in minimum if latest is None or data.get(c, latest) is None]
    return {
        "periods": [p.model_dump(mode="json") for p in periods],
        "ltm_periods": ltm_periods,
        "statements": statements,
        "entry": entry,
        "currency": deal.reporting_currency,
        "checks": [c.model_dump() for c in checks if c.status != "not_applicable"],
        "check_summary": summarise(checks),
        "quick_scan": {"minimum": minimum, "missing": missing_minimum, "period": latest},
    }
