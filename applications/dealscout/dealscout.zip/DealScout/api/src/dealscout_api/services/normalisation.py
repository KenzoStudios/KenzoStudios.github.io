"""AI-suggested one-off items (brief §7), run as a background job.

The AI reads the pages of the deal's processed documents that mention one-off terms and copies amounts as printed;
:func:`dealscout_extraction.one_offs.suggest_one_offs` verifies each against its page. Verified items are stored as
*unconfirmed* adjustments (``source="ai_suggested"``): they change no figure until the analyst confirms them.
"""

from __future__ import annotations

import uuid
from collections.abc import Callable
from typing import Any

from sqlalchemy import Engine
from sqlmodel import Session, col, select

from dealscout_engine.scores import Adjustment
from dealscout_extraction.ingest import read_document
from dealscout_extraction.one_offs import PROMPT_VERSION, suggest_one_offs

from ..config import Settings
from ..jobs import JobContext
from ..models import Deal, Document, utcnow
from . import audit
from . import financials as fin
from .ai_service import AIService
from .app_settings import load_preferences
from .documents import document_path
from .methods import load_methods

SUGGEST_STEPS = [
    ("read", "Read the deal's documents"),
    ("ai", "Find one-off items with the AI"),
    ("save", "Save suggestions for review"),
]
MAX_DOCUMENTS = 3


def _key(a: Adjustment) -> tuple[str, str, float]:
    return a.period_key, a.label.strip().lower(), round(a.amount, 2)


def make_one_off_handler(engine: Engine, settings: Settings, ai: AIService) -> Callable[[JobContext], None]:
    def handler(ctx: JobContext) -> None:
        deal_id = str(ctx.payload["deal_id"])
        with Session(engine) as session:
            provider = ai.provider_for(session)  # raises NotConnected / AIDisabled: the job fails with that message
            send_full = load_preferences(session).ai_send_scope == "full_documents"
            docs = session.exec(
                select(Document)
                .where(Document.deal_id == deal_id, Document.status == "processed")
                .order_by(col(Document.uploaded_at).desc())
            ).all()
            docs = [d for d in docs if d.kind in {"pdf", "html", "xbrl", "docx", "image"}][:MAX_DOCUMENTS]
            for d in docs:
                session.expunge(d)
        if not docs:
            raise ValueError("No processed PDF, HTML or Word documents to read. Upload the annual report first.")

        with ctx.step("read"):
            contents = []
            for d in docs:
                raw = document_path(settings, d).read_bytes()
                contents.append((d, raw, read_document(raw, d.filename)))
            ctx.note("read", f"{len(contents)} document(s)")

        found: list[Adjustment] = []
        rejected = 0
        with ctx.step("ai"):
            for d, raw, doc in contents:
                outcome = suggest_one_offs(provider, raw, doc, page_limit=16 if send_full else 8)
                rejected += len(outcome.rejected)
                with Session(engine) as session:
                    for usage in outcome.usage:
                        ai.record_usage(
                            session,
                            usage,
                            purpose="normalisation",
                            deal_id=deal_id,
                            document_id=d.id,
                            prompt_version=PROMPT_VERSION,
                        )
                    session.commit()
                for s in outcome.suggestions:
                    found.append(
                        Adjustment(
                            id=uuid.uuid4().hex[:12],
                            period_key=s.period_key,
                            label=s.label,
                            category=s.category,
                            amount=s.amount,
                            affects_ebitda=s.affects_ebitda,
                            confirmed=False,
                            source="ai_suggested",
                            rationale=s.rationale,
                            document_id=d.id,
                            page=s.page,
                            value_as_written=s.value_as_written[:60],
                        )
                    )
            ctx.note("ai", f"{len(found)} verified, {rejected} rejected (amount not on the cited page)")

        with ctx.step("save"):
            with Session(engine) as session:
                deal = session.get(Deal, deal_id)
                if deal is None:
                    raise ValueError("The deal was deleted.")
                record = fin.assumptions_doc(session, deal_id)
                methods = load_methods(record.methods)
                existing = {_key(a) for a in methods.normalisation.adjustments}
                new = [a for a in found if _key(a) not in existing]
                methods.normalisation.adjustments = [*methods.normalisation.adjustments, *new]
                record.methods = {
                    **(record.methods or {}),
                    "normalisation": methods.normalisation.model_dump(mode="json"),
                }
                record.updated_at = utcnow()
                session.add(record)
                audit.record(
                    session,
                    "one_offs_suggested",
                    deal_id=deal_id,
                    detail={"suggested": len(new), "rejected": rejected, "provider": provider.provider_id},
                )
                session.commit()
            ctx.note("save", f"{len(new)} new suggestion(s) to review")

    return handler


def payload(deal_id: str) -> dict[str, Any]:
    return {"deal_id": deal_id}
