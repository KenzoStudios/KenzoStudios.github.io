"""Uploaded documents: storage, the extraction job, the AI cache and the review actions."""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Callable
from dataclasses import asdict
from datetime import date, timedelta
from pathlib import Path
from typing import Any

from sqlalchemy.engine import Engine
from sqlmodel import Session, col, select

from dealscout_ai import AIDisabledError, NotConnectedError
from dealscout_ai.registry import PROVIDERS
from dealscout_engine.taxonomy import load_taxonomy
from dealscout_extraction.ai_extract import PROMPT_VERSION
from dealscout_extraction.ingest import check_zip_safety, sha256, sniff_kind
from dealscout_extraction.mapping import Candidate
from dealscout_extraction.numbers import parse_number
from dealscout_extraction.pipeline import ExtractionOutput, extract_ai, extract_rules, missing_core

from ..config import Settings
from ..jobs import JobContext
from ..models import Deal, Document, ExtractedItem, Job, Period, utcnow
from . import audit
from . import financials as fin
from .ai_service import AIService
from .app_settings import load_preferences

SUPPORTED = {"pdf", "xlsx", "xls", "csv", "docx", "html", "xbrl", "zip", "image"}
ACCEPTED = SUPPORTED
ARCHIVE_MEMBERS = (
    ".pdf",
    ".xlsx",
    ".xls",
    ".csv",
    ".docx",
    ".htm",
    ".html",
    ".xhtml",
    ".xbrl",
    ".xml",
    ".png",
    ".jpg",
    ".jpeg",
)
EXTRACT_STEPS = [
    ("read", "Read the document"),
    ("locate", "Find the financial statements"),
    ("map", "Map line items to the standard chart"),
    ("ai", "AI reading of notes and unrecognised lines"),
    ("save", "Prepare values for your review"),
]


class UploadRejected(ValueError):
    pass


def store_upload(
    settings: Settings, session: Session, deal: Deal, filename: str, content: bytes, *, from_archive: str | None = None
) -> list[Document]:
    """Validate and store one upload. A ZIP that is not an ESEF report package becomes one document per file."""
    if len(content) > settings.max_upload_mb * 1024 * 1024:
        raise UploadRejected(f"{filename}: larger than the {settings.max_upload_mb} MB limit.")
    if not content:
        raise UploadRejected(f"{filename}: the file is empty.")
    kind = sniff_kind(content, filename)
    if filename.lower().endswith((".xlsm", ".xltm", ".docm")):
        raise UploadRejected(f"{filename}: macro-enabled files are not accepted. Save as .xlsx/.docx and upload again.")
    if kind not in ACCEPTED:
        raise UploadRejected(
            f"{filename}: unsupported file type. Upload PDF, Excel, CSV, Word, HTML, XBRL/iXBRL, images or ZIP."
        )
    if kind in ("zip", "xlsx", "docx"):  # Excel and Word files are zip archives too
        problems = check_zip_safety(content)
        if problems:
            raise UploadRejected(f"{filename}: {' '.join(problems)}")
    if kind == "zip":
        from dealscout_extraction.ixbrl import find_report_in_package

        if find_report_in_package(content) is None:
            if from_archive:
                raise UploadRejected(f"{filename}: archives inside archives are not opened.")
            return _expand_archive(settings, session, deal, filename, content)
    doc = Document(
        deal_id=deal.id,
        filename=(f"{Path(from_archive).name} › {Path(filename).name}" if from_archive else Path(filename).name)[:255],
        stored_name="",
        size_bytes=len(content),
        sha256=sha256(content),
        kind=kind,
        uploaded_by=load_preferences(session).user_name,
        status="uploaded",
    )
    suffix = re.sub(r"[^a-z0-9.]", "", Path(filename).suffix.lower())[:8]
    doc.stored_name = f"{doc.id}{suffix}"
    folder = settings.deal_folder(deal.id)
    folder.mkdir(parents=True, exist_ok=True)
    (folder / doc.stored_name).write_bytes(content)
    session.add(doc)
    audit.record(
        session,
        "document_uploaded",
        deal_id=deal.id,
        detail={"filename": doc.filename, "size": doc.size_bytes, "sha256": doc.sha256, "kind": kind},
    )
    return [doc]


def _expand_archive(settings: Settings, session: Session, deal: Deal, filename: str, content: bytes) -> list[Document]:
    import io
    import zipfile

    stored: list[Document] = []
    with zipfile.ZipFile(io.BytesIO(content)) as zf:
        for info in zf.infolist():
            name = info.filename
            base = Path(name).name
            if info.is_dir() or not base or base.startswith(".") or "__MACOSX" in name:
                continue
            if not base.lower().endswith(ARCHIVE_MEMBERS):
                continue
            try:
                stored += store_upload(settings, session, deal, base, zf.read(info), from_archive=filename)
            except UploadRejected:
                continue
    if not stored:
        raise UploadRejected(f"{filename}: the archive holds no readable reports (PDF, Excel, CSV, Word, HTML, XBRL).")
    return stored


def document_path(settings: Settings, doc: Document) -> Path:
    return settings.deal_folder(doc.deal_id) / doc.stored_name


def viewable(settings: Settings, doc: Document) -> bytes:
    """The sanitised HTML view of a document, cached by content hash (large filings take a second to prepare)."""
    from dealscout_extraction.html_reader import viewable_html

    cache = settings.cache_dir / "views" / f"{doc.sha256}.html"
    if cache.exists():
        return cache.read_bytes()
    content = document_path(settings, doc).read_bytes()
    if content[:2] == b"PK":  # an ESEF report package: show the inline XBRL report inside it
        from dealscout_extraction.ixbrl import find_report_in_package

        found = find_report_in_package(content)
        content = found[1] if found else b""
    body = viewable_html(content)
    cache.parent.mkdir(parents=True, exist_ok=True)
    cache.write_bytes(body)
    return body


# ── AI cache: document hash + provider + model + prompt version ─────────────────
def _cache_file(settings: Settings, doc: Document, provider: str, model: str) -> Path:
    key = hashlib.sha256(f"{doc.sha256}|{provider}|{model}|{PROMPT_VERSION}".encode()).hexdigest()
    return settings.cache_dir / "ai" / f"{key}.json"


def _candidate_dict(c: Candidate) -> dict[str, Any]:
    data = asdict(c)
    data["bbox"] = list(c.bbox) if c.bbox else None
    return data


# ── the job ───────────────────────────────────────────────────────────────────
def make_extract_handler(engine: Engine, settings: Settings, ai: AIService) -> Callable[[JobContext], None]:
    taxonomy = load_taxonomy()

    def handler(ctx: JobContext) -> None:
        document_id = ctx.payload["document_id"]
        with Session(engine) as session:
            doc = session.get(Document, document_id)
            if doc is None:
                raise ValueError("The document no longer exists.")
            doc.status = "processing"
            session.add(doc)
            session.commit()
            filename, deal_id = doc.filename, doc.deal_id
            content = document_path(settings, doc).read_bytes()

        details: dict[str, str] = {}
        with ctx.step("read"):
            out = extract_rules(content, filename, taxonomy, progress=lambda k, d: details.__setitem__(k, d))
            ctx.note("read", details.get("read", ""))
        with ctx.step("locate"):
            ctx.note("locate", details.get("locate", ""))
        with ctx.step("map"):
            ctx.note("map", details.get("map", ""))
        _save(engine, document_id, deal_id, out, provider=None, model=None, replace_methods={"table_rules"})

        with ctx.step("ai"):
            with Session(engine) as session:
                try:
                    provider = ai.provider_for(session)
                except (NotConnectedError, AIDisabledError) as reason:
                    provider = None
                    ctx.note("ai", f"Skipped: {reason.message} Tables and the dictionary were used.")
                    out.not_found = [
                        {
                            "concept_id": c,
                            "reason": "Not found in the statements; connect AI to search the "
                            "notes, or enter it manually.",
                        }
                        for c in missing_core(out)
                    ]
                send_full = load_preferences(session).ai_send_scope == "full_documents"
            if provider is not None and out.doc.pages:
                cache = _cache_file(settings, _doc(engine, document_id), provider.provider_id, provider.model)
                if cache.exists():
                    cached = json.loads(cache.read_text(encoding="utf-8"))
                    out.candidates = [
                        Candidate(**{**c, "bbox": tuple(c["bbox"]) if c["bbox"] else None})
                        for c in cached["candidates"]
                    ]
                    out.not_found, out.rejected = cached["not_found"], cached["rejected"]
                    out.unmapped = [u for u in out.unmapped if u.label not in set(cached.get("mapped_labels", []))]
                    ctx.note(
                        "ai", f"Reused cached AI results ({provider.provider_id} · {provider.model}); no new cost."
                    )
                else:
                    before = {id(u) for u in out.unmapped}
                    extract_ai(
                        out,
                        content,
                        taxonomy,
                        provider,
                        tier=_tier(provider.provider_id),
                        page_limit=40 if send_full else 8,
                        progress=lambda k, d: ctx.note("ai", d),
                    )
                    mapped_labels = [u.label for u in out.unmapped if id(u) not in before]
                    cache.parent.mkdir(parents=True, exist_ok=True)
                    cache.write_text(
                        json.dumps(
                            {
                                "candidates": [_candidate_dict(c) for c in out.candidates],
                                "not_found": out.not_found,
                                "rejected": out.rejected,
                                "mapped_labels": mapped_labels,
                            }
                        ),
                        encoding="utf-8",
                    )
                    with Session(engine) as session:
                        for usage in out.usage:
                            ai.record_usage(
                                session,
                                usage,
                                purpose="extraction",
                                deal_id=deal_id,
                                document_id=document_id,
                                prompt_version=PROMPT_VERSION,
                            )
                        session.commit()
                _save(
                    engine,
                    document_id,
                    deal_id,
                    out,
                    provider=provider.provider_id,
                    model=provider.model,
                    replace_methods={"table_rules", "ai_mapping", "ai_extraction"},
                )
        with ctx.step("save"):
            _finish(engine, document_id, out)
            ctx.note("save", f"{len(out.candidates)} values ready for review")

    return handler


def _tier(provider_id: str) -> str:
    """The provider's measured accuracy tier (brief §3); unknown providers count as untested."""
    spec = PROVIDERS.get(provider_id)
    return spec.accuracy_tier if spec else "untested"


def _doc(engine: Engine, document_id: str) -> Document:
    with Session(engine) as session:
        doc = session.get(Document, document_id)
        assert doc is not None
        session.expunge(doc)
        return doc


def _save(
    engine: Engine,
    document_id: str,
    deal_id: str,
    out: ExtractionOutput,
    *,
    provider: str | None,
    model: str | None,
    replace_methods: set[str],
) -> None:
    """Replace this document's *pending* candidates; decided items are kept so a re-run never undoes a review."""
    with Session(engine) as session:
        decided = {
            (i.concept_id, i.period_key)
            for i in session.exec(
                select(ExtractedItem).where(ExtractedItem.document_id == document_id, ExtractedItem.status != "pending")
            ).all()
        }
        for item in session.exec(
            select(ExtractedItem).where(ExtractedItem.document_id == document_id, ExtractedItem.status == "pending")
        ).all():
            if item.method in replace_methods:
                session.delete(item)
        for c in out.candidates:
            if (c.concept_id, c.period_key) in decided:
                continue
            ai_made = c.method.startswith("ai_")
            session.add(
                ExtractedItem(
                    deal_id=deal_id,
                    document_id=document_id,
                    concept_id=c.concept_id,
                    period_key=c.period_key,
                    value=c.value,
                    value_as_written=c.value_as_written[:80],
                    label=c.label[:300],
                    page=c.page,
                    bbox=list(c.bbox) if c.bbox else None,
                    cell_ref=c.cell_ref,
                    sheet=c.sheet,
                    scale_factor=c.scale_factor,
                    scale_label=c.scale_label,
                    confidence=c.confidence,
                    method=c.method,
                    mapping=c.mapping,
                    provider=provider if ai_made else None,
                    model=model if ai_made else None,
                    rationale=c.rationale,
                    notes=c.notes,
                )
            )
        session.commit()


def _scale_factor(out: ExtractionOutput, table_index: int) -> float:
    scale = out.doc.tables[table_index].scale
    return scale.factor if scale is not None else 1.0


def _finish(engine: Engine, document_id: str, out: ExtractionOutput) -> None:
    with Session(engine) as session:
        doc = session.get(Document, document_id)
        assert doc is not None
        decimal_hint = "," if out.doc.language in {"de", "es", "fr", "it", "pt", "nl"} else "."
        doc.kind = out.doc.kind
        doc.page_count = out.doc.page_count
        doc.scanned_pages = out.doc.scanned_pages
        doc.language = out.doc.language
        doc.doc_type = out.doc_type
        doc.status = "processed"
        doc.meta = {
            "statements": {
                k: [
                    {"page": t.page, "score": round(t.score, 1), "consolidated": t.consolidated, "reasons": t.reasons}
                    for t in v
                ]
                for k, v in out.located.items()
            },
            "warnings": out.warnings,
            "periods": out.periods,
            "not_found": out.not_found,
            "rejected": out.rejected,
            "ai_used": out.ai_used,
            "entity_name": out.doc.entity_name,
            "currency": out.doc.currency,
            "report_member": out.doc.report_member,
            "tagged_facts": len(out.doc.inline.facts) if out.doc.inline is not None else 0,
            "ocr_pages": sum(1 for page in out.doc.pages if page.ocr),
            "page_size": [out.doc.pages[0].width, out.doc.pages[0].height] if out.doc.pages else None,
            "decimal_hint": decimal_hint,
            "unmapped": [
                {
                    "id": i,
                    "label": u.label,
                    "page": u.page,
                    "statement": u.statement,
                    "values": u.values,
                    "candidates": u.candidates,
                    "reason": u.reason,
                    "scale_factor": u.scale_factor if u.scale_factor is not None else _scale_factor(out, u.table_index),
                }
                for i, u in enumerate(out.unmapped)
            ],
        }
        session.add(doc)
        session.commit()


# ── review ────────────────────────────────────────────────────────────────────
def _month_end(year: int, month: int) -> date:
    first_next = date(year + (month // 12), month % 12 + 1, 1)
    return first_next - timedelta(days=1)


def _period_shape(key: str, fiscal_year_end: str) -> tuple[str, int, date | None]:
    """FY2025 → annual; H1-2026 / Q3-2026 / 9M-2026 → interim, ending N months after the prior year end."""
    year = int(re.findall(r"\d{4}", key)[0])
    fye_month = int(fiscal_year_end.split("-")[0])
    if key.startswith("FY"):
        return "annual", year, fin._fy_end(year, fiscal_year_end)
    months = {"H1": 6, "H2": 12, "Q1": 3, "Q2": 6, "Q3": 9, "Q4": 12, "9M": 9, "6M": 6, "3M": 3}.get(key[:2])
    kind = "half_year" if key.startswith("H") else "quarter" if key.startswith("Q") else "ytd"
    if months is None:
        return kind, year, None
    total = (year - 1) * 12 + fye_month - 1 + months  # months since year 0, zero-based
    return kind, year, _month_end(total // 12, total % 12 + 1)


def _ensure_period(session: Session, deal: Deal, key: str) -> None:
    if session.exec(select(Period).where(Period.deal_id == deal.id, Period.key == key)).first():
        return
    kind, year, end = _period_shape(key, fin.entry_settings(session, deal.id)["fiscal_year_end"])
    session.add(Period(deal_id=deal.id, key=key, kind=kind, fiscal_year=year, end_date=end, label=key))
    session.commit()


def accept_items(
    session: Session, deal: Deal, items: list[ExtractedItem], *, edited: dict[int, tuple[float, str]] | None = None
) -> dict[str, int]:
    edited = edited or {}
    actor = load_preferences(session).user_name
    for item in items:
        _ensure_period(session, deal, item.period_key)
    changes = []
    docs = {d.id: d for d in session.exec(select(Document).where(Document.deal_id == deal.id)).all()}
    for item in items:
        value, reason = edited.get(item.id or -1, (item.value, None))
        doc = docs.get(item.document_id)
        changes.append(
            fin.CellChange(
                concept_id=item.concept_id,
                period_key=item.period_key,
                value=value,
                entered_text=item.value_as_written,
                reason=reason or f"Accepted from {doc.filename if doc else 'document'} p. {item.page}",
                confidence=item.confidence,
                provenance={
                    "document_id": item.document_id,
                    "filename": doc.filename if doc else None,
                    "page": item.page,
                    "bbox": item.bbox,
                    "cell_ref": item.cell_ref,
                    "sheet": item.sheet,
                    "label": item.label,
                    "value_as_written": item.value_as_written,
                    "scale": item.scale_label,
                    "scale_factor": item.scale_factor,
                    "method": item.method,
                    "provider": item.provider,
                    "model": item.model,
                    "extracted_value": item.value,
                    "edited": item.id in edited,
                },
            )
        )
    counts = fin.apply_changes(session, deal, changes, source="extracted")
    for item in items:
        item.status = "accepted"
        item.decided_by = actor
        item.decided_at = utcnow()
        if item.id in edited:
            item.value = edited[item.id][0]
        session.add(item)
    # a newer acceptance supersedes other pending candidates for the same cell
    cells = {(i.concept_id, i.period_key) for i in items}
    for other in session.exec(
        select(ExtractedItem).where(ExtractedItem.deal_id == deal.id, ExtractedItem.status == "pending")
    ).all():
        if (other.concept_id, other.period_key) in cells:
            other.status = "rejected"
            other.decided_by = actor
            other.decided_at = utcnow()
            session.add(other)
    session.commit()
    return counts


def reject_items(session: Session, items: list[ExtractedItem]) -> None:
    actor = load_preferences(session).user_name
    for item in items:
        item.status = "rejected"
        item.decided_by = actor
        item.decided_at = utcnow()
        session.add(item)
    session.commit()


def map_unmapped_row(session: Session, doc: Document, row_id: int, concept_id: str) -> list[ExtractedItem]:
    """The analyst maps an unrecognised row; values are re-read from the stored row (never typed in again)."""
    taxonomy = load_taxonomy()
    concept = taxonomy.concept(concept_id)
    rows = doc.meta.get("unmapped", [])
    row = next((r for r in rows if r["id"] == row_id), None)
    if row is None:
        raise ValueError("That row is no longer in the unmapped list.")
    created = []
    for period_key, raw in row["values"].items():
        parsed = parse_number(raw, decimal_hint=doc.meta.get("decimal_hint"))
        if parsed.value is None or not re.match(r"^(FY|H[12]|Q[1-4]|9M|6M|3M)", period_key):
            continue
        factor = row["scale_factor"] if concept.unit == "currency" else 1.0
        value = parsed.value * factor
        if concept.sign == "negative":
            value = -abs(value)
        elif concept.sign == "positive" and value < 0:
            value = abs(value)
        item = ExtractedItem(
            deal_id=doc.deal_id,
            document_id=doc.id,
            concept_id=concept_id,
            period_key=period_key,
            value=value,
            value_as_written=raw[:80],
            label=row["label"][:300],
            page=row["page"],
            scale_factor=factor,
            confidence=0.9,
            method="user_mapping",
            mapping="user",
            rationale=f"Mapped by {load_preferences(session).user_name}.",
        )
        session.add(item)
        created.append(item)
    doc.meta = {**doc.meta, "unmapped": [r for r in rows if r["id"] != row_id]}
    session.add(doc)
    session.commit()
    return created


def document_payload(session: Session, doc: Document) -> dict[str, Any]:
    """The document plus its extraction job's state: a paused or failed job shows as such, never as reading."""
    data = doc.model_dump(mode="json")
    job = session.get(Job, doc.job_id) if doc.job_id else None
    data["job"] = (
        {"id": job.id, "status": job.status, "message": job.message, "error_code": job.error_code, "steps": job.steps}
        if job
        else None
    )
    if doc.status == "processing" and job is not None and job.status in ("paused", "failed"):
        data["status"] = job.status
    return data


# ── several documents for the same periods (brief §5.2 step 9) ────────────────────
_PART = {
    "Q1": 0.25,
    "3M": 0.25,
    "H1": 0.5,
    "6M": 0.5,
    "Q2": 0.5,
    "9M": 0.75,
    "Q3": 0.75,
    "H2": 1.0,
    "Q4": 1.0,
    "FY": 1.0,
}


def period_rank(key: str) -> float:
    """FY2025 → 2025.0, H1-2026 → 2025.5, 9M-2026 → 2025.75: how far into time a period reaches."""
    years = re.findall(r"\d{4}", key)
    if not years:
        return 0.0
    part = _PART.get(key[:2].upper(), 1.0)
    return int(years[0]) - 1 + part


def document_recency(items: list[ExtractedItem], docs: list[Document]) -> dict[str, tuple[float, str]]:
    """Newer documents first: the latest period a document reports, then its upload time."""
    latest: dict[str, float] = {}
    for item in items:
        latest[item.document_id] = max(latest.get(item.document_id, 0.0), period_rank(item.period_key))
    return {d.id: (latest.get(d.id, 0.0), d.uploaded_at.isoformat()) for d in docs}


def best_per_cell(
    items: list[ExtractedItem], recency: dict[str, tuple[float, str]], *, minimum: float = 0.0
) -> dict[tuple[str, str], ExtractedItem]:
    """One pending value per cell: from the newest document (restated figures win), then the most confident."""
    best: dict[tuple[str, str], ExtractedItem] = {}
    for item in items:
        if item.status != "pending" or item.confidence < minimum:
            continue
        key = (item.concept_id, item.period_key)
        rank = (recency.get(item.document_id, (0.0, "")), item.confidence)
        current = best.get(key)
        if current is None or rank > (recency.get(current.document_id, (0.0, "")), current.confidence):
            best[key] = item
    return best


def cross_document_differences(
    items: list[ExtractedItem], docs: list[Document], recency: dict[str, tuple[float, str]]
) -> list[dict[str, Any]]:
    """Cells that two documents report differently (beyond rounding): usually a restatement."""
    names = {d.id: d.filename for d in docs}
    by_cell: dict[tuple[str, str], dict[str, ExtractedItem]] = {}
    for item in items:
        if item.status == "rejected":
            continue
        cell = by_cell.setdefault((item.concept_id, item.period_key), {})
        known = cell.get(item.document_id)
        if known is None or item.confidence > known.confidence:
            cell[item.document_id] = item
    out = []
    for (concept_id, period_key), per_doc in by_cell.items():
        if len(per_doc) < 2:
            continue
        values = list(per_doc.values())
        reference = max(values, key=lambda i: recency.get(i.document_id, (0.0, "")))
        differing = [
            i
            for i in values
            if abs(i.value - reference.value)
            > max(0.5 * max(i.scale_factor, reference.scale_factor), 1e-3 * abs(reference.value), 0.5)
        ]
        if not differing:
            continue
        out.append(
            {
                "concept_id": concept_id,
                "period_key": period_key,
                "preferred_item_id": reference.id,
                "preferred_document": names.get(reference.document_id),
                "values": [
                    {
                        "item_id": i.id,
                        "document": names.get(i.document_id),
                        "value": i.value,
                        "value_as_written": i.value_as_written,
                        "status": i.status,
                    }
                    for i in sorted(values, key=lambda i: recency.get(i.document_id, (0.0, "")), reverse=True)
                ],
            }
        )
    return out


def review_payload(session: Session, deal: Deal) -> dict[str, Any]:
    taxonomy = load_taxonomy()
    docs = list(
        session.exec(select(Document).where(Document.deal_id == deal.id).order_by(col(Document.uploaded_at))).all()
    )
    items = list(session.exec(select(ExtractedItem).where(ExtractedItem.deal_id == deal.id)).all())
    current = {(v.concept_id, v.period_key): v for v in fin.load_values(session, deal.id)}
    # preview reconciliation: accepted data plus the best pending candidate for each empty cell
    data = fin.financial_data(session, deal.id)
    recency = document_recency(items, docs)
    best = best_per_cell(items, recency)
    for (concept_id, period_key), item in best.items():
        if (concept_id, period_key) not in current:
            data.values[(concept_id, period_key)] = item.value
    differences = cross_document_differences(items, docs, recency)
    superseded = {
        v["item_id"]: d["preferred_document"]
        for d in differences
        for v in d["values"]
        if v["item_id"] != d["preferred_item_id"]
    }
    from dealscout_engine.reconciliation import run_checks

    period_keys = sorted({p for _, p in data.values})
    checks = [
        c
        for c in run_checks(data, period_keys, rounding_unit=max((i.scale_factor for i in items), default=1.0))
        if c.status == "fail"
    ]
    out_items = []
    for item in items:
        concept = taxonomy.concept(item.concept_id)
        existing = current.get((item.concept_id, item.period_key))
        out_items.append(
            {
                **item.model_dump(mode="json"),
                "concept_name": concept.name,
                "statement": concept.statement,
                "unit": concept.unit,
                "current_value": existing.value if existing else None,
                "current_source": existing.source if existing else None,
                "conflicts": existing is not None
                and abs(existing.value - item.value) > max(1.0, abs(item.value) * 1e-6),
                "superseded_by": superseded.get(item.id),
            }
        )
    return {
        "documents": [document_payload(session, d) for d in docs],
        "items": out_items,
        "checks": [c.model_dump() for c in checks],
        "cross_document": differences,
        "core": [
            {"concept_id": c, "name": taxonomy.concept(c).name}
            for c in [
                "revenue",
                "ebitda",
                "ebit",
                "net_income",
                "total_assets",
                "cash",
                "lt_debt",
                "total_equity",
                "cfo",
                "capex",
                "shares_outstanding",
            ]
        ],
    }
