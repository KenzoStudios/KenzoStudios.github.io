"""AI-suggested peer companies (brief §9.3): names only, clearly labelled as suggestions to verify.

The model proposes listed comparables (name, ticker, exchange, country and a one-line reason). It is never asked for
and never returns financial figures: peers enter the comps table with blank numbers for the analyst to fill in from a
source they trust. A reason that contains a digit is dropped (the name is kept), so no figure written by the model
reaches the screen.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field

from dealscout_ai import AIProvider, PageText, Usage

PROMPT_VERSION = "dealscout-peers-2026-11-v1"

SYSTEM = (
    "You suggest listed comparable companies (trading peers) for a valuation by an investment professional. "
    "Rules you must follow:\n"
    "1. Suggest 5 to 10 companies whose shares are listed on a public stock exchange today, as close as possible "
    "to the target's business model, end markets, size and geography.\n"
    "2. For each give the company name, its main ticker, the exchange, the ISO 3166 two-letter country code of its "
    "headquarters and one short sentence on why it is comparable.\n"
    "3. Never write any financial figure, multiple, percentage, price, market value or year. The analyst will "
    "source every number separately. A reason with a digit is discarded.\n"
    "4. If you are unsure of a ticker or exchange, leave it empty rather than guess. Do not repeat companies "
    "already in the peer list."
)


class AIPeer(BaseModel):
    name: str = Field(max_length=200)
    ticker: str = Field(max_length=30)
    exchange: str = Field(max_length=60)
    country: str = Field(max_length=60)
    reason: str = Field(max_length=300)


class AIPeerList(BaseModel):
    peers: list[AIPeer]


class PeerSuggestion(BaseModel):
    name: str
    ticker: str | None
    exchange: str | None
    country: str | None
    reason: str | None


def deal_brief(deal: Any, sector_name: str | None, existing: list[str]) -> str:
    lines = [
        f"Target: {deal.name}",
        f"Sector: {sector_name or deal.sector}",
        f"Industry: {deal.industry or 'not given'}",
        f"Headquarters country: {deal.country.upper()}",
        f"Listed: {'yes, ticker ' + deal.ticker if deal.listed and deal.ticker else 'yes' if deal.listed else 'no'}",
    ]
    if existing:
        lines.append("Already in the peer list: " + "; ".join(existing[:50]))
    return "\n".join(lines)


_DIGIT = re.compile(r"\d")


def ai_peer_suggestions(
    provider: AIProvider, brief: str, existing: list[str]
) -> tuple[list[PeerSuggestion], int, Usage]:
    """Ask the provider for peers. Returns the cleaned suggestions, the number of reasons dropped, and usage."""
    result = provider.extract_structured(
        [PageText(page=0, source_name="deal", text=brief)], AIPeerList, instructions=SYSTEM, max_tokens=3000
    )
    taken = {e.strip().lower() for e in existing}
    out: list[PeerSuggestion] = []
    dropped = 0
    for p in result.value.peers:
        name = p.name.strip()
        ticker = p.ticker.strip() or None
        if not name or name.lower() in taken or (ticker and ticker.lower() in taken):
            continue
        taken.add(name.lower())
        reason: str | None = p.reason.strip() or None
        if reason and _DIGIT.search(reason):
            reason = None
            dropped += 1
        country = p.country.strip().upper()
        out.append(
            PeerSuggestion(
                name=name,
                ticker=ticker,
                exchange=p.exchange.strip() or None,
                country=country if re.fullmatch(r"[A-Z]{2}", country) else None,
                reason=reason,
            )
        )
    return out[:10], dropped, result.usage


def generated_at() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")
