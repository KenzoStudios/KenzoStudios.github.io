"""Reference data shipped with the repository (countries, currencies, sectors, disclaimers, palette)."""

from __future__ import annotations

import json
from functools import lru_cache
from typing import Any

import yaml

from ..config import get_settings


@lru_cache(maxsize=1)
def reference_data() -> dict[str, Any]:
    root = get_settings().reference_dir
    with open(root / "reference" / "countries.yaml", encoding="utf-8") as fh:
        countries = yaml.safe_load(fh)["countries"]
    with open(root / "reference" / "currencies.yaml", encoding="utf-8") as fh:
        currencies = yaml.safe_load(fh)["currencies"]
    with open(root / "reference" / "sectors.yaml", encoding="utf-8") as fh:
        sectors = yaml.safe_load(fh)["sectors"]
    return {
        "countries": [{"code": code, **info} for code, info in countries.items()],
        "currencies": [{"code": code, **info} for code, info in currencies.items()],
        "sectors": sectors,
    }


@lru_cache(maxsize=1)
def disclaimers() -> dict[str, Any]:
    with open(get_settings().reference_dir / "legal" / "disclaimers.json", encoding="utf-8") as fh:
        data: dict[str, Any] = json.load(fh)
    return data


def sector_template(sector_id: str) -> str:
    for sector in reference_data()["sectors"]:
        if sector["id"] == sector_id:
            return str(sector["template"])
    return "general"
