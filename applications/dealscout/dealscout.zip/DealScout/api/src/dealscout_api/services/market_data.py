"""Market data connectors (brief §9.3): a pluggable provider interface, a registry, and the built-in manual / CSV
import provider. The tool works fully without any connector: peers can always be typed in by hand.

A connector returns *quotes* (price, market cap, currency, as-of date, source) and, optionally, *fundamentals* for a
ticker. Every figure keeps its source and as-of date. No paid third-party provider ships with DealScout; a keyed
provider would read its key from the OS keychain through ``dealscout_ai.keystore.KeyStore`` and be registered with
``enabled_by_default=False``, so nothing reaches the network unless the user turns it on.

CSV conventions: one peer per row; amounts in the deal currency at the scale chosen on upload (units, thousands,
millions, billions); columns ending in ``_pct`` are percentages (``12`` or ``12%`` = 12%). Accounting negatives
``(1,234)`` and thousands separators are accepted. Rows that fail validation are reported with their row number and
reason and left out; nothing is saved until the analyst saves the peers.
"""

from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field
from datetime import date
from typing import Protocol, runtime_checkable

from pydantic import BaseModel

from dealscout_engine.valuation.comps import Peer

MAX_CSV_BYTES = 1_000_000
MAX_CSV_ROWS = 200


class Quote(BaseModel):
    ticker: str
    price: float | None = None
    market_cap: float | None = None
    currency: str | None = None
    as_of: date | None = None
    source: str


class Fundamentals(BaseModel):
    """Peer financials from a connector, in the same fields as a peer row (amounts in ``currency``)."""

    ticker: str
    currency: str | None = None
    as_of: date | None = None
    source: str
    figures: dict[str, float]


@runtime_checkable
class MarketDataProvider(Protocol):
    id: str
    label: str
    requires_key: bool

    def quote(self, ticker: str) -> Quote | None: ...

    def fundamentals(self, ticker: str) -> Fundamentals | None: ...


@dataclass
class ProviderSpec:
    id: str
    label: str
    description: str
    requires_key: bool = False
    enabled_by_default: bool = False
    built_in: bool = False


REGISTRY: dict[str, ProviderSpec] = {}


def register(spec: ProviderSpec) -> ProviderSpec:
    if spec.id in REGISTRY:
        raise ValueError(f"Market data provider {spec.id!r} is already registered")
    REGISTRY[spec.id] = spec
    return spec


def providers() -> list[ProviderSpec]:
    return list(REGISTRY.values())


# ── built-in provider: manual / CSV import ─────────────────────────────────────
register(
    ProviderSpec(
        id="csv",
        label="Manual / CSV import",
        description="Upload a CSV of peers with prices, market values and financials from your own data source.",
        requires_key=False,
        enabled_by_default=True,
        built_in=True,
    )
)

AMOUNT_COLUMNS = [
    "market_cap",
    "net_debt",
    "enterprise_value",
    "revenue",
    "ebitda",
    "ebit",
    "net_income",
    "book_equity",
    "tangible_book_equity",
    "free_cash_flow",
    "rent_expense",
    "arr",
    "nav",
    "revenue_cy",
    "ebitda_cy",
    "ebit_cy",
    "net_income_cy",
    "revenue_ny",
    "ebitda_ny",
    "ebit_ny",
    "net_income_ny",
]
PCT_COLUMNS = {
    "revenue_growth_pct": "revenue_growth",
    "ebitda_margin_pct": "ebitda_margin",
    "eps_growth_pct": "eps_growth",
}
TEXT_COLUMNS = ["name", "ticker", "exchange", "country", "currency", "as_of", "source"]
OTHER_NUMBERS = ["price", "shares"]  # market cap = price × shares when market cap is blank
COLUMNS = [*TEXT_COLUMNS[:4], "price", "shares", *AMOUNT_COLUMNS, *PCT_COLUMNS, *TEXT_COLUMNS[4:]]
POSITIVE = {"market_cap", "enterprise_value", "price", "shares", "arr", "nav"}

TEMPLATE_EXAMPLE = {
    "name": "Example Peer plc",
    "ticker": "EXMP",
    "exchange": "LSE",
    "country": "GB",
    "market_cap": "1200",
    "net_debt": "300",
    "revenue": "900",
    "ebitda": "150",
    "ebit": "110",
    "net_income": "70",
    "revenue_cy": "950",
    "ebitda_cy": "160",
    "eps_growth_pct": "8",
    "currency": "GBP",
    "as_of": "2026-10-31",
    "source": "Your data source",
}


def csv_template() -> str:
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=COLUMNS, lineterminator="\n")
    writer.writeheader()
    writer.writerow({c: TEMPLATE_EXAMPLE.get(c, "") for c in COLUMNS})
    return out.getvalue()


class RowError(BaseModel):
    row: int  # 1-based line number in the file (the header is line 1)
    name: str | None
    errors: list[str]


class CsvImport(BaseModel):
    peers: list[Peer]
    quotes: list[Quote]
    errors: list[RowError]
    warnings: list[str]


_NUMBER = re.compile(r"^-?\d+(\.\d+)?$")


def parse_number(text: str) -> float | None:
    """'1,234.5' → 1234.5; '(12)' → -12; '' → None. Raises ValueError on anything else."""
    s = text.strip().replace("−", "-").replace(" ", "").replace(" ", "")
    if s in ("", "-", "n/a", "N/A", "na", "NA"):
        return None
    negative = s.startswith("(") and s.endswith(")")
    if negative:
        s = s[1:-1]
    s = s.rstrip("%").replace(",", "")
    if not _NUMBER.match(s):
        raise ValueError(text)
    value = float(s)
    return -value if negative else value


@dataclass
class CsvImportProvider:
    """The built-in connector: quotes and fundamentals come from a CSV the analyst uploads."""

    rows: dict[str, tuple[Quote, Fundamentals]] = field(default_factory=dict)
    id: str = "csv"
    label: str = "Manual / CSV import"
    requires_key: bool = False

    def quote(self, ticker: str) -> Quote | None:
        hit = self.rows.get(ticker.upper())
        return hit[0] if hit else None

    def fundamentals(self, ticker: str) -> Fundamentals | None:
        hit = self.rows.get(ticker.upper())
        return hit[1] if hit else None

    @classmethod
    def from_import(cls, result: CsvImport) -> CsvImportProvider:
        by_ticker = {p.ticker.upper(): p for p in result.peers if p.ticker}
        rows = {}
        for q in result.quotes:
            peer = by_ticker.get(q.ticker.upper())
            if peer is None:
                continue
            figures = {
                k: v
                for k, v in peer.model_dump(exclude={"name", "ticker", "country", "include"}).items()
                if v is not None
            }
            fundamentals = Fundamentals(
                ticker=q.ticker, currency=q.currency, as_of=q.as_of, source=q.source, figures=figures
            )
            rows[q.ticker.upper()] = (q, fundamentals)
        return cls(rows=rows)


def parse_peer_csv(content: bytes, *, scale: float = 1.0, existing: set[str] | None = None) -> CsvImport:
    """Validate a peer CSV. Valid rows become peers (amounts × ``scale``); invalid rows are reported, not imported."""
    if len(content) > MAX_CSV_BYTES:
        raise ValueError("The CSV is larger than 1 MB.")
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = content.decode("latin-1")
    sample = text[:4096]
    try:
        dialect: type[csv.Dialect] | csv.Dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    reader = csv.DictReader(io.StringIO(text), dialect=dialect)
    header = [(h or "").strip().lower() for h in (reader.fieldnames or [])]
    if "name" not in header:
        raise ValueError("The CSV needs a header row with at least a 'name' column. Download the template.")
    reader.fieldnames = header
    known = set(COLUMNS)
    warnings = []
    unknown = [h for h in header if h and h not in known]
    if unknown:
        warnings.append(f"Ignored unknown columns: {', '.join(unknown[:10])}.")
    peers: list[Peer] = []
    quotes: list[Quote] = []
    errors: list[RowError] = []
    seen = {n.strip().lower() for n in existing or set()}
    for index, raw in enumerate(reader, start=2):
        if index - 1 > MAX_CSV_ROWS:
            warnings.append(f"Only the first {MAX_CSV_ROWS} rows were read.")
            break
        row = {k: (v or "").strip() for k, v in raw.items() if k}
        if not any(row.values()):
            continue
        name = row.get("name", "")
        problems: list[str] = []
        if not name:
            problems.append("Name is missing.")
        elif len(name) > 200:
            problems.append("Name is longer than 200 characters.")
        elif name.lower() in seen:
            problems.append("Duplicate peer name (already in the list or earlier in the file).")
        numbers: dict[str, float | None] = {}
        for column in [*OTHER_NUMBERS, *AMOUNT_COLUMNS, *PCT_COLUMNS]:
            if column not in row:
                continue
            try:
                numbers[column] = parse_number(row[column])
            except ValueError:
                problems.append(f"{column}: {row[column]!r} is not a number.")
        for column in POSITIVE:
            value = numbers.get(column)
            if value is not None and value <= 0:
                problems.append(f"{column} must be positive.")
        for column in PCT_COLUMNS:
            value = numbers.get(column)
            if value is not None and not -100 < value <= 1000:
                problems.append(f"{column} must be a percentage between -100 and 1000.")
        as_of: date | None = None
        if row.get("as_of"):
            try:
                as_of = date.fromisoformat(row["as_of"])
            except ValueError:
                problems.append("as_of must be a date as YYYY-MM-DD.")
        currency = row.get("currency", "").upper() or None
        if currency and not re.fullmatch(r"[A-Z]{3}", currency):
            problems.append("currency must be a 3-letter ISO code.")
        price, shares = numbers.get("price"), numbers.get("shares")
        if numbers.get("market_cap") is None and price and shares:
            numbers["market_cap"] = price * shares / scale  # scaled back up below with the other amounts
        unreadable = any(c not in numbers and row.get(c) for c in ("market_cap", "enterprise_value", "price", "shares"))
        if numbers.get("market_cap") is None and numbers.get("enterprise_value") is None and not unreadable:
            problems.append("Give a market cap, an enterprise value, or a price and share count.")
        if problems:
            errors.append(RowError(row=index, name=name or None, errors=problems))
            continue
        seen.add(name.lower())
        fields: dict[str, float | None] = {c: _scaled(numbers.get(c), scale) for c in AMOUNT_COLUMNS}
        for column, attr in PCT_COLUMNS.items():
            value = numbers.get(column)
            fields[attr] = None if value is None else value / 100
        ticker = row.get("ticker") or None
        peer = Peer(
            name=name,
            ticker=ticker,
            country=(row.get("country") or "").upper()[:2] or None,
            include=True,
            **{k: v for k, v in fields.items() if v is not None},
        )
        peers.append(peer)
        if ticker:
            quotes.append(
                Quote(
                    ticker=ticker,
                    price=price,
                    market_cap=peer.market_cap,
                    currency=currency,
                    as_of=as_of,
                    source=row.get("source") or "CSV import",
                )
            )
    if not peers and not errors:
        warnings.append("The CSV has no peer rows.")
    return CsvImport(peers=peers, quotes=quotes, errors=errors, warnings=warnings)


def _scaled(value: float | None, scale: float) -> float | None:
    return None if value is None else value * scale
