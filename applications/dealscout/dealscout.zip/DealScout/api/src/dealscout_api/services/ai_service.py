"""Glue between saved AI connections (SQLite + OS keychain) and the provider-neutral AI layer.

All AI calls made by DealScout go through :meth:`AIService.provider_for`, which enforces the "AI disabled"
switches and the monthly spend cap, and every call's usage is recorded with :meth:`record_usage`.
"""

from __future__ import annotations

import os
from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import SecretStr
from sqlalchemy import func
from sqlmodel import Session, select

from dealscout_ai import (
    PROVIDERS,
    AIDisabledError,
    AIProvider,
    ConnectionResult,
    KeyStore,
    ModelInfo,
    NotConnectedError,
    ProviderConfig,
    SpendCapReachedError,
    Usage,
    create_provider,
    get_spec,
    last4,
)

from ..config import Settings
from ..models import AIConnection, AIUsage, utcnow
from .app_settings import load_preferences

KeySource = Literal["keychain", "file", "env", "none"]


class AIService:
    def __init__(self, settings: Settings, keystore: KeyStore):
        self.settings = settings
        self.keystore = keystore

    # ── keys ───────────────────────────────────────────────────────────
    def resolve_key(self, provider: str) -> tuple[str | None, KeySource]:
        stored = self.keystore.get(provider)
        if stored:
            return stored, self.keystore.backend
        env_name = get_spec(provider).env_vars.get("api_key")
        env_value = os.environ.get(env_name) if env_name else None
        if env_value:
            return env_value, "env"
        return None, "none"

    def _env_value(self, provider: str, field: str) -> str | None:
        name = get_spec(provider).env_vars.get(field)
        return os.environ.get(name) if name else None

    # ── state for the UI (never includes a key) ────────────────────────
    def provider_states(self, session: Session) -> list[dict[str, Any]]:
        connections = {c.provider: c for c in session.exec(select(AIConnection)).all()}
        states = []
        for spec in PROVIDERS.values():
            conn = connections.get(spec.id)
            key, source = self.resolve_key(spec.id)
            states.append(
                {
                    "spec": spec.model_dump(),
                    "connection": None if conn is None else conn.model_dump(exclude={"created_at"}),
                    "key": {"present": key is not None, "source": source, "last4": last4(key)},
                    "env_model": self._env_value(spec.id, "model"),
                }
            )
        return states

    def active_connection(self, session: Session) -> AIConnection | None:
        return session.exec(select(AIConnection).where(AIConnection.is_active == True)).first()  # noqa: E712

    def status(self, session: Session) -> dict[str, Any]:
        prefs = load_preferences(session)
        conn = self.active_connection(session)
        key_present = bool(conn and self.resolve_key(conn.provider)[0])
        disabled_reason = None
        if self.settings.disable_ai:
            disabled_reason = "AI features are disabled by DEALSCOUT_DISABLE_AI in .env."
        elif not prefs.ai_enabled:
            disabled_reason = "AI features are turned off in Settings."
        return {
            "enabled": disabled_reason is None,
            "disabled_reason": disabled_reason,
            "connected": (conn is not None and key_present) or (conn is not None and conn.provider == "custom"),
            "provider": conn.provider if conn else None,
            "provider_label": get_spec(conn.provider).label if conn else None,
            "model": conn.model if conn else None,
            "last_test_code": conn.last_test_code if conn else None,
            "month_spend_usd": self.month_spend(session),
            "monthly_spend_cap_usd": prefs.monthly_spend_cap_usd,
        }

    # ── connection management ─────────────────────────────────────────
    def save_connection(
        self,
        session: Session,
        provider: str,
        *,
        model: str | None,
        api_key: str | None = None,
        base_url: str | None = None,
        endpoint: str | None = None,
        deployment: str | None = None,
        api_version: str | None = None,
        activate: bool = True,
    ) -> AIConnection:
        spec = get_spec(provider)
        if not spec.implemented:
            raise NotImplementedError(f"{spec.label} support arrives in {spec.available_in}.")
        conn = session.get(AIConnection, provider) or AIConnection(provider=provider)
        moved = (base_url or None) != (conn.base_url or None) or (endpoint or None) != (conn.endpoint or None)
        if api_key:
            self.keystore.set(provider, api_key)
        elif moved and self.keystore.get(provider):
            # a stored key is only ever sent to the address it was entered for: a new address needs the key again
            self.keystore.delete(provider)
        conn.model = model or conn.model or spec.default_model
        conn.base_url, conn.endpoint = base_url, endpoint
        conn.deployment, conn.api_version = deployment, api_version
        conn.updated_at = utcnow()
        if activate:
            for other in session.exec(select(AIConnection).where(AIConnection.provider != provider)).all():
                if other.is_active:
                    other.is_active = False
                    session.add(other)
            conn.is_active = True
        session.add(conn)
        session.commit()
        session.refresh(conn)
        return conn

    def activate(self, session: Session, provider: str) -> AIConnection:
        conn = session.get(AIConnection, provider)
        if conn is None:
            raise NotConnectedError(f"{get_spec(provider).label} has not been set up yet.", provider=provider)
        for other in session.exec(select(AIConnection)).all():
            other.is_active = other.provider == provider
            session.add(other)
        session.commit()
        session.refresh(conn)
        return conn

    def remove_key(self, provider: str) -> None:
        self.keystore.delete(provider)

    def delete_connection(self, session: Session, provider: str) -> None:
        self.keystore.delete(provider)
        conn = session.get(AIConnection, provider)
        if conn is not None:
            session.delete(conn)
            session.commit()

    # ── building providers ────────────────────────────────────────────
    def _config(self, conn: AIConnection) -> ProviderConfig:
        key, _ = self.resolve_key(conn.provider)
        spec = get_spec(conn.provider)
        if spec.key_required and not key:
            raise NotConnectedError(
                f"No API key saved for {spec.label}. Add one in Settings → Connect AI.", provider=conn.provider
            )
        model = conn.model or self._env_value(conn.provider, "model") or spec.default_model
        if not model and conn.provider != "azure_openai":
            raise NotConnectedError(
                f"Choose a model for {spec.label} in Settings → Connect AI.", provider=conn.provider
            )
        return ProviderConfig(
            provider=conn.provider,
            model=model or (conn.deployment or ""),
            api_key=SecretStr(key) if key else None,
            base_url=conn.base_url or self._env_value(conn.provider, "base_url"),
            endpoint=conn.endpoint or self._env_value(conn.provider, "endpoint"),
            deployment=conn.deployment or self._env_value(conn.provider, "deployment"),
            api_version=conn.api_version or self._env_value(conn.provider, "api_version"),
        )

    def provider_for(self, session: Session, *, purpose: Literal["extraction", "writing"] = "extraction") -> AIProvider:
        status = self.status(session)
        if not status["enabled"]:
            raise AIDisabledError(status["disabled_reason"])
        cap = status["monthly_spend_cap_usd"]
        if cap is not None and status["month_spend_usd"] >= cap:
            raise SpendCapReachedError(
                f"This month's AI spend (${status['month_spend_usd']:.2f}) has reached your cap of ${cap:.2f}. "
                "Raise the cap in Settings to continue."
            )
        conn: AIConnection | None = None
        if purpose == "writing":
            conn = session.exec(select(AIConnection).where(AIConnection.is_writing == True)).first()  # noqa: E712
        conn = conn or self.active_connection(session)
        if conn is None:
            raise NotConnectedError("No AI provider is connected. Connect one in Settings → Connect AI.")
        return create_provider(self._config(conn))

    def test(self, session: Session, provider: str) -> ConnectionResult:
        conn = session.get(AIConnection, provider)
        if conn is None:
            raise NotConnectedError(f"{get_spec(provider).label} has not been set up yet.", provider=provider)
        try:
            adapter = create_provider(self._config(conn))
            result = adapter.test_connection()
        except NotConnectedError as error:
            result = ConnectionResult(
                ok=False, provider=provider, model=conn.model, code="invalid_key", message=error.message
            )
        conn.last_test_at = utcnow()
        conn.last_test_code = result.code
        conn.last_test_message = result.message
        session.add(conn)
        if result.usage is not None:
            self.record_usage(session, result.usage, purpose="connection_test")
        session.commit()
        return result

    def adapter_for(self, session: Session, provider: str, *, model: str | None = None) -> AIProvider:
        """An adapter for one provider from its saved connection (or .env settings), e.g. for evaluations."""
        conn = session.get(AIConnection, provider) or AIConnection(provider=provider)
        if model:
            conn = AIConnection(**{**conn.model_dump(), "model": model})
        return create_provider(self._config(conn))

    def list_models(self, session: Session, provider: str) -> list[ModelInfo]:
        conn = session.get(AIConnection, provider)
        if conn is None:
            raise NotConnectedError(f"{get_spec(provider).label} has not been set up yet.", provider=provider)
        return create_provider(self._config(conn)).list_models()

    # ── usage and spend ───────────────────────────────────────────────
    def record_usage(
        self,
        session: Session,
        usage: Usage,
        *,
        purpose: str,
        deal_id: str | None = None,
        document_id: str | None = None,
        prompt_version: str | None = None,
    ) -> None:
        session.add(
            AIUsage(
                deal_id=deal_id,
                document_id=document_id,
                purpose=purpose,
                provider=usage.provider,
                model=usage.model,
                prompt_version=prompt_version,
                input_tokens=usage.input_tokens,
                output_tokens=usage.output_tokens,
                cache_read_tokens=usage.cache_read_tokens,
                cache_write_tokens=usage.cache_write_tokens,
                estimated_cost_usd=usage.estimated_cost_usd,
            )
        )

    def month_spend(self, session: Session) -> float:
        now = datetime.now(UTC)
        start = datetime(now.year, now.month, 1, tzinfo=UTC)
        total = session.exec(
            select(func.coalesce(func.sum(AIUsage.estimated_cost_usd), 0.0)).where(AIUsage.at >= start)
        ).one()
        return round(float(total or 0.0), 4)
