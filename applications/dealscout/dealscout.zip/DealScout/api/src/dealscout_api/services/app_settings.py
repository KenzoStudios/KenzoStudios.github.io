"""User preferences stored in SQLite (non-secret). Defaults live here, in one place."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field
from sqlmodel import Session, select

from ..models import AppSetting, utcnow


class Preferences(BaseModel):
    user_name: str = Field(default="Analyst", max_length=120)
    ai_enabled: bool = True
    ai_send_scope: Literal["located_pages", "full_documents"] = "located_pages"
    monthly_spend_cap_usd: float | None = Field(default=None, ge=0)
    retention_days: int | None = Field(default=None, ge=1)
    defaults_stale_days: int = Field(default=90, ge=1)
    number_locale: str = Field(default="en-US", max_length=20)
    onboarding_done: bool = False


def load_preferences(session: Session) -> Preferences:
    rows = {row.key: row.value for row in session.exec(select(AppSetting)).all()}
    known = {k: v for k, v in rows.items() if k in Preferences.model_fields}
    return Preferences.model_validate(known)


def save_preferences(session: Session, changes: dict[str, Any]) -> Preferences:
    current = load_preferences(session)
    updated = Preferences.model_validate({**current.model_dump(), **changes})
    for key in changes:
        row = session.get(AppSetting, key)
        value = getattr(updated, key)
        if row is None:
            session.add(AppSetting(key=key, value=value))
        else:
            row.value = value
            row.updated_at = utcnow()
            session.add(row)
    session.commit()
    return updated
