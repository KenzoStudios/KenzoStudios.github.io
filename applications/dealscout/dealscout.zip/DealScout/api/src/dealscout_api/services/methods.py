"""Milestone 5 valuation methods for a deal: stored inputs, runs and football-field ranges.

Each method reports a ``status``:

* ``ready``, with its result and (usually) a range for the football field;
* ``needs_input``, with the list of what is missing;
* ``error``, with the engine's message.

Unsourced market figures (LBO leverage and margins, control premia, DLOM) are never filled in: the user enters
them. Sourced defaults (the reference rate for the currency, the target-IRR convention) are used and labelled.
All arithmetic happens in ``dealscout_engine``; this module only gathers inputs and calls it.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import date
from typing import Any, Literal

from pydantic import BaseModel, Field, ValidationError, field_validator

from dealscout_engine.defaults import MarketDefaults
from dealscout_engine.quickscan import QuickScanResult
from dealscout_engine.recommendation import PremiumRange
from dealscout_engine.scores import Adjustment
from dealscout_engine.statements import FinancialData
from dealscout_engine.valuation.bridge import BridgeInputs, ev_to_equity
from dealscout_engine.valuation.dcf import Scenario, default_scenarios, validate_scenarios
from dealscout_engine.valuation.fi import (
    APVInputs,
    DDMInputs,
    FCFEInputs,
    ResidualIncomeInputs,
    ValueResult,
    price_to_tangible_book,
    run_apv,
    run_ddm,
    run_fcfe,
    run_residual_income,
    unlevered_cost_of_equity,
)
from dealscout_engine.valuation.lbo import (
    LBOInputs,
    LBOResult,
    OperatingYear,
    Tranche,
    entry_ev_from_price,
    max_entry_price,
    run_lbo,
    sensitivity_entry_exit,
    sensitivity_leverage_exit,
)
from dealscout_engine.valuation.nav import NAVInputs, NAVLine, Segment, SOTPInputs, run_nav, run_sotp
from dealscout_engine.valuation.precedents import (
    PrecedentFilters,
    PrecedentMultiple,
    PrecedentValue,
    Transaction,
    precedent_stats,
    precedent_value,
)
from dealscout_engine.valuation.strategic import (
    DLOM,
    AccretionInputs,
    LiquidationInputs,
    MarketPoint,
    RecoveryLine,
    ReplacementLine,
    SynergyInputs,
    apply_dlom,
    market_reference_points,
    replacement_value,
    run_accretion,
    run_liquidation,
    run_rate_synergy_ebitda,
    run_synergies,
    strategic_value,
)
from dealscout_engine.valuation.summary import FootballField, MethodRange, football_field

BASE_RATE_BY_CURRENCY = {"USD": "SOFR", "EUR": "EURIBOR_3M", "GBP": "SONIA"}
BASE_RATE_LABEL = {"SOFR": "SOFR", "EURIBOR_3M": "EURIBOR 3-month", "SONIA": "SONIA"}
LBO_IRR_BAND = 0.05  # football-field range: the price at the target IRR +5pp (low) and −5pp (high)
KE_BAND = 0.01  # dividend discount, residual income and FCFE: cost of equity ±1pp
FI_SECTORS = {"banks", "insurance"}  # sector ids in data/reference/sectors.yaml
NAV_SECTORS = {"real_estate", "holding"}
ENTRY_SHIFTS = [-2.0, -1.0, 0.0, 1.0, 2.0]
EXIT_SHIFTS = [-2.0, -1.0, 0.0, 1.0, 2.0]
LEVERAGE_FACTORS = [0.6, 0.8, 1.0, 1.2, 1.4]


# ── stored inputs ─────────────────────────────────────────────────────────────
def _unique_tranche_names(tranches: list[Tranche]) -> list[Tranche]:
    names = [t.name.strip().lower() for t in tranches]
    repeated = sorted({t.name for t in tranches if names.count(t.name.strip().lower()) > 1})
    if repeated:
        raise ValueError(f"give each tranche its own name (repeated: {', '.join(repeated)})")
    return tranches


class LBOSettings(BaseModel):
    entry_multiple: float | None = Field(default=None, gt=0, le=100)  # None → the DCF enterprise value
    entry_price_per_share: float | None = Field(default=None, gt=0)  # alternative to the multiple
    transaction_fee_pct: float = Field(default=0.0, ge=0, le=0.2)
    minimum_cash: float = Field(default=0.0, ge=0)
    tranches: list[Tranche] = Field(default_factory=list, max_length=12)
    rollover_equity: float = Field(default=0.0, ge=0)
    management_promote_pct: float = Field(default=0.0, ge=0, le=0.5)
    base_rate: float | None = Field(default=None, ge=0, le=1)  # None → the sourced reference rate
    interest_on_average: bool = True
    cash_sweep_pct: float = Field(default=1.0, ge=0, le=1)
    exit_year: int | None = Field(default=None, ge=1, le=15)
    exit_multiple: float | None = Field(default=None, gt=0, le=100)
    exit_cost_pct: float = Field(default=0.0, ge=0, le=0.1)
    dividend_recap_year: int | None = Field(default=None, ge=1, le=15)
    dividend_recap_x_ebitda: float = Field(default=0.0, ge=0, le=20)
    max_leverage: float | None = Field(default=None, gt=0)
    min_interest_coverage: float | None = Field(default=None, gt=0)
    target_irr: float | None = Field(default=None, gt=-0.5, lt=2)  # None → the convention in the defaults
    target_moic: float | None = Field(default=None, gt=0, le=20)
    sponsor_case: list[OperatingYear] | None = Field(default=None, max_length=15)  # None → the DCF projection

    _tranche_names = field_validator("tranches")(_unique_tranche_names)


class PrecedentSettings(BaseModel):
    transactions: list[Transaction] = Field(default_factory=list, max_length=300)
    filters: PrecedentFilters = PrecedentFilters()
    multiple: PrecedentMultiple = "ev_ebitda"


class NAVSettings(BaseModel):
    lines: list[NAVLine] = Field(default_factory=list, max_length=200)
    deferred_tax_on_gains: bool = True
    tax_rate: float | None = Field(default=None, ge=0, le=1)  # None → the valuation tax rate
    holding_discount: float = Field(default=0.0, ge=0, lt=1)


class SOTPSettings(BaseModel):
    segments: list[Segment] = Field(default_factory=list, max_length=50)
    non_core_assets: float = 0.0
    corporate_costs: float = Field(default=0.0, ge=0)
    corporate_cost_multiple: float = Field(default=0.0, ge=0, le=50)
    conglomerate_discount: float = Field(default=0.0, ge=0, lt=1)


class DDMSettings(BaseModel):
    current_dividend: float | None = Field(default=None, ge=0)  # None → dividends paid in the latest year
    high_growth: float = Field(default=0.0, gt=-1, lt=1)
    years: int = Field(default=5, ge=0, le=30)
    terminal_growth: float | None = Field(default=None, gt=-0.5, lt=0.5)  # None → the DCF terminal growth
    cost_of_equity: float | None = Field(default=None, gt=0, lt=1)  # None → the WACC build's cost of equity


class ResidualIncomeSettings(BaseModel):
    roe: list[float] = Field(default_factory=list, max_length=30)
    payout_ratio: float = Field(default=0.0, ge=0, le=1)
    terminal_growth: float = Field(default=0.0, gt=-0.5, lt=0.5)
    cost_of_equity: float | None = Field(default=None, gt=0, lt=1)


class FCFESettings(BaseModel):
    net_income: list[float] = Field(default_factory=list, max_length=15)  # one per projection year
    net_borrowing: list[float] | None = Field(default=None, max_length=15)  # None → no new borrowing
    terminal_growth: float | None = Field(default=None, gt=-0.5, lt=0.5)
    cost_of_equity: float | None = Field(default=None, gt=0, lt=1)


class APVSettings(BaseModel):
    unlevered_cost_of_equity: float | None = Field(default=None, gt=0, lt=1)  # None → pre-tax WACC
    debt_balances: list[float] | None = Field(default=None, max_length=15)  # None → the LBO debt schedule
    cost_of_debt: float | None = Field(default=None, gt=0, lt=1)  # None → the WACC pre-tax cost of debt
    expected_distress_cost: float = Field(default=0.0, ge=0)


class FISettings(BaseModel):
    ddm: DDMSettings | None = None
    residual_income: ResidualIncomeSettings | None = None
    fcfe: FCFESettings | None = None
    apv: APVSettings | None = None
    ptbv_low: float | None = Field(default=None, gt=0, le=20)
    ptbv_mid: float | None = Field(default=None, gt=0, le=20)
    ptbv_high: float | None = Field(default=None, gt=0, le=20)


class SynergySettings(BaseModel):
    cost_synergies: float = Field(default=0.0, ge=0)
    revenue_synergies: float = Field(default=0.0, ge=0)
    revenue_synergy_margin: float = Field(default=0.0, ge=0, le=1)
    phasing: list[float] = Field(default_factory=lambda: [0.33, 0.67, 1.0], min_length=1, max_length=15)
    integration_costs: list[float] = Field(default_factory=list, max_length=15)
    probability: float = Field(default=1.0, ge=0, le=1)
    share_paid_away: float = Field(default=0.0, ge=0, le=1)
    discount_rate: float | None = Field(default=None, gt=0, lt=1)  # None → WACC
    terminal_growth: float | None = Field(default=None, gt=-0.5, lt=0.5)  # None → the DCF terminal growth


class AccretionSettings(BaseModel):
    acquirer_net_income: float
    acquirer_shares: float = Field(gt=0)
    acquirer_share_price: float = Field(gt=0)
    purchase_equity_value: float | None = Field(default=None, gt=0)  # None → the blended mid equity value
    cash_share: float = Field(default=0.0, ge=0, le=1)
    debt_share: float = Field(default=0.0, ge=0, le=1)
    stock_share: float = Field(default=1.0, ge=0, le=1)
    interest_on_new_debt: float = Field(default=0.0, ge=0, lt=1)
    foregone_interest_on_cash: float = Field(default=0.0, ge=0, lt=1)
    amortisation_of_intangibles: float = Field(default=0.0, ge=0)
    transaction_costs: float = Field(default=0.0, ge=0)
    use_synergies: bool = True


class MarketReference(BaseModel):
    high_52w: float | None = Field(default=None, gt=0)
    low_52w: float | None = Field(default=None, gt=0)
    vwap_30d: float | None = Field(default=None, gt=0)
    vwap_90d: float | None = Field(default=None, gt=0)
    analyst_targets: list[float] = Field(default_factory=list, max_length=50)


class LiquidationSettings(BaseModel):
    assets: list[RecoveryLine] = Field(default_factory=list, max_length=100)
    wind_down_costs: float = Field(default=0.0, ge=0)


class ReplacementSettings(BaseModel):
    lines: list[ReplacementLine] = Field(default_factory=list, max_length=100)


class NormalisationSettings(BaseModel):
    adjustments: list[Adjustment] = Field(default_factory=list, max_length=300)
    use_adjusted_ebitda: bool = False  # valuation uses EBITDA / EBIT after confirmed one-offs


class MixLine(BaseModel):
    """One segment or region: revenue by period key (absolute units of the reporting currency)."""

    name: str = Field(max_length=80)
    revenue: dict[str, float] = Field(default_factory=dict, max_length=40)


class BreakdownSettings(BaseModel):
    """Revenue by segment and by geography (brief §11.11, §14A Report breakdowns), entered per deal."""

    segments: list[MixLine] = Field(default_factory=list, max_length=20)
    geographies: list[MixLine] = Field(default_factory=list, max_length=20)


class MethodsDoc(BaseModel):
    lbo: LBOSettings = LBOSettings()
    precedents: PrecedentSettings = PrecedentSettings()
    nav: NAVSettings = NAVSettings()
    sotp: SOTPSettings = SOTPSettings()
    fi: FISettings = FISettings()
    synergies: SynergySettings | None = None
    accretion: AccretionSettings | None = None
    liquidation: LiquidationSettings = LiquidationSettings()
    replacement: ReplacementSettings = ReplacementSettings()
    dlom: DLOM | None = None
    market: MarketReference = MarketReference()
    normalisation: NormalisationSettings = NormalisationSettings()
    breakdowns: BreakdownSettings = BreakdownSettings()
    premium: PremiumRange | None = None  # typical control premia: the analyst's range (no sourced default)
    rationale: dict[str, Any] | None = None  # last AI-written rationale, with the fingerprint of its facts
    # DCF scenarios (1 to 6, probabilities summing to 100%); pre-filled with bear / base / bull
    scenarios: list[Scenario] = Field(default_factory=default_scenarios, max_length=6)

    @field_validator("scenarios")
    @classmethod
    def _scenarios(cls, value: list[Scenario]) -> list[Scenario]:
        return validate_scenarios(value)


SECTIONS = frozenset(MethodsDoc.model_fields)


def load_methods(raw: dict[str, Any] | None) -> MethodsDoc:
    """Stored inputs. A section that no longer validates (e.g. after an upgrade) falls back to its default."""
    clean: dict[str, Any] = {}
    for key, value in (raw or {}).items():
        if key not in SECTIONS:
            continue
        try:
            MethodsDoc.model_validate({key: value})
        except ValidationError:
            continue
        clean[key] = value
    return MethodsDoc.model_validate(clean)


# ── outputs ───────────────────────────────────────────────────────────────────
class MethodOutput(BaseModel):
    id: str
    label: str
    group: Literal["lbo", "precedents", "nav", "fi", "strategic", "other"]
    status: Literal["ready", "needs_input", "error"]
    missing: list[str] = Field(default_factory=list)
    message: str | None = None
    result: dict[str, Any] | None = None
    range: MethodRange | None = None


class MethodsRun(BaseModel):
    outputs: list[MethodOutput]
    market_points: list[MarketPoint]
    football_field: FootballField | None  # Quick Scan methods plus these, after any DLOM
    dlom_applied: bool


def _range(
    method_id: str,
    label: str,
    equity: tuple[float, float, float],
    weight: float,
    *,
    ev: tuple[float | None, float | None, float | None] | None = None,
    note: str | None = None,
) -> MethodRange:
    low, mid, high = sorted(equity)
    evs = [v for v in ev or () if v is not None]
    ev_sorted = sorted(evs) if len(evs) == 3 else None
    return MethodRange(
        method_id=method_id,
        label=label,
        equity_low=low,
        equity_mid=mid,
        equity_high=high,
        ev_low=ev_sorted[0] if ev_sorted else None,
        ev_mid=ev_sorted[1] if ev_sorted else None,
        ev_high=ev_sorted[2] if ev_sorted else None,
        weight=weight,
        note=note,
    )


def _assumption(qs: QuickScanResult, key: str) -> float | None:
    value = next((a.value for a in qs.assumptions if a.key == key), None)
    return float(value) if isinstance(value, int | float) else None


def _missing(*pairs: tuple[str, object]) -> list[str]:
    return [label for label, value in pairs if value is None]


class _Context:
    """What every method needs from the deal and its Quick Scan."""

    def __init__(
        self,
        *,
        data: FinancialData,
        qs: QuickScanResult,
        defaults: MarketDefaults,
        currency: str,
        sector: str,
        perspective: str,
        valuation_date: date,
        weights: dict[str, float],
    ) -> None:
        self.data = data
        self.qs = qs
        self.defaults = defaults
        self.currency = currency.upper()
        self.sector = sector
        self.perspective = perspective
        self.valuation_date = valuation_date
        self.weights = weights
        self.bridge = qs.bridge or BridgeInputs()
        self.base = qs.base_period
        self.tax = qs.tax_rate
        self.ke = qs.wacc.cost_of_equity if qs.wacc else None
        self.g = _assumption(qs, "terminal_growth")
        self.shares = qs.dilution.basic_shares if qs.dilution else None

    def get(self, concept: str) -> float | None:
        return self.data.get(concept, self.base) if self.base else None

    def weight(self, method_id: str, default: float) -> float:
        return self.weights.get(method_id, default)


def run_methods(
    *,
    data: FinancialData,
    qs: QuickScanResult,
    doc: MethodsDoc,
    defaults: MarketDefaults,
    currency: str,
    sector: str,
    perspective: str,
    listed: bool,
    valuation_date: date,
    weights: dict[str, float],
) -> MethodsRun:
    c = _Context(
        data=data,
        qs=qs,
        defaults=defaults,
        currency=currency,
        sector=sector,
        perspective=perspective,
        valuation_date=valuation_date,
        weights=weights,
    )
    lbo_out, lbo_case = _lbo(c, doc.lbo)
    outputs = [
        lbo_out,
        _precedents(c, doc.precedents),
        _nav(c, doc.nav),
        _sotp(c, doc.sotp),
        *_fi(c, doc.fi, lbo_case),
        _synergies(c, doc.synergies),
        _liquidation(c, doc.liquidation),
        _replacement(c, doc.replacement),
    ]
    ranges = [*(qs.football_field.methods if qs.football_field else [])]
    ranges += [o.range for o in outputs if o.status == "ready" and o.range is not None]
    dlom_applied = doc.dlom is not None and not listed and bool(ranges)
    if doc.dlom is not None and dlom_applied:
        ranges = apply_dlom(ranges, doc.dlom)
    ff = (
        football_field(ranges, dilution=qs.dilution, market_cap=qs.market_cap, share_price=qs.share_price)
        if ranges
        else None
    )
    # accretion / dilution defaults to the blended value of every method as the purchase price
    outputs.insert(
        outputs.index(next(o for o in outputs if o.id == "strategic")) + 1,
        _accretion(c, doc.accretion, doc.synergies, ff),
    )
    m = doc.market
    points = market_reference_points(
        c.shares,
        high_52w=m.high_52w,
        low_52w=m.low_52w,
        vwap={"VWAP 30 days": m.vwap_30d, "VWAP 90 days": m.vwap_90d},
        analyst_targets=m.analyst_targets,
    )
    return MethodsRun(outputs=outputs, market_points=points, football_field=ff, dlom_applied=dlom_applied)


# ── LBO ───────────────────────────────────────────────────────────────────────
def _operating_case(c: _Context, s: LBOSettings) -> list[OperatingYear]:
    if s.sponsor_case:
        return s.sponsor_case
    if c.qs.dcf is None:
        return []
    return [
        OperatingYear(
            label=y.label,
            revenue=y.revenue,
            ebitda=y.ebitda,
            da=y.da,
            capex=max(y.capex, 0.0),
            change_in_nwc=y.change_in_nwc,
        )
        for y in c.qs.dcf.projection
    ]


def _lbo(c: _Context, s: LBOSettings) -> tuple[MethodOutput, LBOResult | None]:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="lbo", label="LBO", group="lbo", **kw)

    qs = c.qs
    operating = _operating_case(c, s)
    missing = []
    if not operating:
        missing.append("an operating case: complete the DCF (the LBO reuses its projection) or enter a sponsor case")
    if not s.tranches:
        missing.append("debt tranches: market leverage and margins are not sourced, so enter your financing terms")
    if qs.base_ebitda is None or qs.base_ebitda <= 0:
        missing.append("positive EBITDA in the latest year")
    if s.entry_price_per_share is not None and not c.shares:
        missing.append("the share count (to turn the price per share into an entry value)")
    if s.entry_multiple is None and s.entry_price_per_share is None and qs.dcf is None:
        missing.append("the entry multiple (there is no DCF value to start from)")
    if missing:
        return out(status="needs_input", missing=missing), None
    assert qs.base_ebitda is not None

    notes: list[str] = []
    base_rate = s.base_rate
    if base_rate is None and any(t.rate_type == "floating" for t in s.tranches):
        reference = BASE_RATE_BY_CURRENCY.get(c.currency)
        found = c.defaults.lookup("lbo", "base_rates", reference) if reference else None
        if found is None or not found.usable:
            return out(status="needs_input", missing=[f"the base rate for {c.currency} floating-rate debt"]), None
        base_rate = found.value
        name = BASE_RATE_LABEL.get(reference or "", reference)
        notes.append(f"Base rate: {name} {found.value:.2%} as of {found.as_of} ({found.source}).")
    target = s.target_irr
    if target is None:
        found = c.defaults.lookup("lbo", "target_irr")
        if not found.usable or found.value is None:
            return out(status="needs_input", missing=["the target IRR"]), None
        target = found.value
        notes.append(f"Target IRR {target:.0%}: {found.source}.")

    entry_ev: float | None = None
    entry_multiple = s.entry_multiple
    entry_source = "multiple"
    if s.entry_price_per_share is not None and c.shares:
        entry_ev = entry_ev_from_price(s.entry_price_per_share, c.shares, c.bridge)
        entry_multiple = None
        entry_source = "price_per_share"
    elif entry_multiple is None and qs.dcf is not None:
        entry_ev = qs.dcf.enterprise_value
        entry_source = "dcf"
        notes.append("Entry value: the DCF enterprise value. Enter an entry multiple to change it.")
    if c.tax is None:
        notes.append("No tax rate is resolved, so the LBO runs before tax. Enter the tax rate in Assumptions.")
    try:
        inputs = LBOInputs(
            entry_ebitda=qs.base_ebitda,
            entry_multiple=entry_multiple,
            entry_ev=entry_ev,
            existing_net_debt=ev_to_equity(0.0, c.bridge).net_debt_and_adjustments,
            transaction_fee_pct=s.transaction_fee_pct,
            minimum_cash=s.minimum_cash,
            tranches=s.tranches,
            rollover_equity=s.rollover_equity,
            management_promote_pct=s.management_promote_pct,
            operating=operating,
            tax_rate=c.tax or 0.0,
            base_rate=base_rate or 0.0,
            interest_on_average=s.interest_on_average,
            cash_sweep_pct=s.cash_sweep_pct,
            exit_year=min(s.exit_year or 5, len(operating)),
            exit_multiple=s.exit_multiple,
            exit_cost_pct=s.exit_cost_pct,
            dividend_recap_year=s.dividend_recap_year,
            dividend_recap_x_ebitda=s.dividend_recap_x_ebitda,
            max_leverage=s.max_leverage,
            min_interest_coverage=s.min_interest_coverage,
            target_irr=target,
            target_moic=s.target_moic,
        )
        case = run_lbo(inputs)
        best = max_entry_price(inputs)
        low = max_entry_price(inputs, target_irr=target + LBO_IRR_BAND)
        high = max_entry_price(inputs, target_irr=target - LBO_IRR_BAND)
        grids = [
            sensitivity_entry_exit(inputs, ENTRY_SHIFTS, EXIT_SHIFTS),
            sensitivity_leverage_exit(inputs, LEVERAGE_FACTORS, EXIT_SHIFTS),
        ]
    except ValueError as error:
        return out(status="error", message=str(error)), None
    result = {
        "case": case.model_dump(),
        "max_price": best.model_dump(),
        "band": {"low": low.model_dump(), "high": high.model_dump()},
        "sensitivities": [g.model_dump() for g in grids],
        "inputs": {
            "entry_ev": inputs.ev,
            "entry_multiple": inputs.multiple,
            "entry_source": entry_source,
            "base_rate": base_rate,
            "target_irr": target,
            "target_moic": s.target_moic,
            "exit_year": inputs.exit_year,
            "operating_case": "sponsor" if s.sponsor_case else "dcf",
        },
        "engine_inputs": inputs.model_dump(mode="json"),
        "notes": notes,
    }
    lo, mid, hi = low.equity_purchase_price, best.equity_purchase_price, high.equity_purchase_price
    if lo is None or mid is None or hi is None:
        reason = best.note or "No entry price reaches the target return with this financing and exit."
        return out(status="needs_input", missing=[reason], result=result), case
    rng = _range(
        "lbo",
        f"LBO (IRR {target + LBO_IRR_BAND:.0%} to {target - LBO_IRR_BAND:.0%})",
        (lo, mid, hi),
        c.weight("lbo", 1.0 if c.perspective == "financial_sponsor" else 0.5),
        ev=(low.entry_ev, best.entry_ev, high.entry_ev),
        note=f"The most a sponsor can pay for a {target:.0%} IRR with this financing.",
    )
    return out(status="ready", result=result, range=rng), case


# ── precedents, NAV, SOTP ────────────────────────────────────────────────────
def _precedents(c: _Context, p: PrecedentSettings) -> MethodOutput:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="precedents", label="Precedent transactions", group="precedents", **kw)

    if not p.transactions:
        return out(status="needs_input", missing=["transactions"])
    metric = {"ev_revenue": c.qs.base_revenue, "ev_ebitda": c.qs.base_ebitda, "ev_ebit": c.get("ebit")}[p.multiple]
    stats = precedent_stats(p.transactions, p.multiple, p.filters, as_of=c.valuation_date)
    value = precedent_value(stats, metric, c.bridge)
    if value.equity_low is None or value.equity_mid is None or value.equity_high is None:
        return out(status="needs_input", missing=[value.note], result=_precedent_result(value, p, c))
    rng = _range(
        "precedents",
        f"Precedent transactions: {value.label}",
        (value.equity_low, value.equity_mid, value.equity_high),
        c.weight("precedents", 0.5),
        ev=(value.ev_low, value.ev_mid, value.ev_high),
        note=value.note,
    )
    return out(status="ready", result=_precedent_result(value, p, c), range=rng)


def _precedent_result(value: PrecedentValue, p: PrecedentSettings, c: _Context) -> dict[str, Any]:
    """The engine result plus what a live spreadsheet model needs to rebuild it (valuation date, half-life, bridge)."""
    result: dict[str, Any] = value.model_dump(mode="json")
    result["engine_inputs"] = {
        "as_of": c.valuation_date.isoformat(),
        "half_life_years": p.filters.half_life_years,
        "net_debt_and_adjustments": ev_to_equity(0.0, c.bridge).net_debt_and_adjustments,
    }
    return result


def _nav(c: _Context, s: NAVSettings) -> MethodOutput:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="nav", label="Net asset value", group="nav", **kw)

    if not s.lines:
        return out(status="needs_input", missing=["assets and liabilities to revalue"])
    tax = s.tax_rate if s.tax_rate is not None else c.tax
    if s.deferred_tax_on_gains and tax is None:
        return out(status="needs_input", missing=["the tax rate for deferred tax on revaluation gains"])
    try:
        nav = run_nav(
            NAVInputs(
                lines=s.lines,
                deferred_tax_on_gains=s.deferred_tax_on_gains,
                tax_rate=tax or 0.0,
                holding_discount=s.holding_discount,
                shares=c.shares,
                share_price=c.qs.share_price,
            )
        )
    except ValueError as error:
        return out(status="needs_input", missing=[str(error)])
    rng = _range(
        "nav",
        "Net asset value",
        (nav.nav, nav.nav, nav.nav_before_discount),
        c.weight("nav", 1.0 if c.sector in NAV_SECTORS else 0.5),
        note="The high end is before the holding-company discount." if s.holding_discount else None,
    )
    result = {
        **nav.model_dump(),
        "engine_inputs": {
            "lines": [line.model_dump(mode="json") for line in s.lines],
            "deferred_tax_on_gains": s.deferred_tax_on_gains,
            "tax_rate": tax or 0.0,
            "tax_source": "entered" if s.tax_rate is not None else "valuation",
            "holding_discount": s.holding_discount,
            "shares": c.shares,
            "share_price": c.qs.share_price,
        },
    }
    return out(status="ready", result=result, range=rng)


def _sotp(c: _Context, s: SOTPSettings) -> MethodOutput:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="sotp", label="Sum of the parts", group="nav", **kw)

    if not s.segments:
        return out(status="needs_input", missing=["segments"])
    try:
        sotp = run_sotp(
            SOTPInputs(
                segments=s.segments,
                non_core_assets=s.non_core_assets,
                corporate_costs=s.corporate_costs,
                corporate_cost_multiple=s.corporate_cost_multiple,
                conglomerate_discount=s.conglomerate_discount,
                bridge=c.bridge,
            )
        )
    except ValueError as error:
        return out(status="needs_input", missing=[str(error)])
    rng = _range(
        "sotp",
        "Sum of the parts",
        sotp.equity,
        c.weight("sotp", 1.0 if c.sector in NAV_SECTORS else 0.5),
        ev=sotp.ev,
    )
    return out(status="ready", result={**sotp.model_dump(), "engine_inputs": s.model_dump(mode="json")}, range=rng)


# ── financial institutions and leveraged situations ─────────────────────────
def _band(run: Callable[[float], ValueResult], rate: float, growth: float) -> tuple[float, float, float]:
    """Values at the cost of equity +1pp, at it, and −1pp (low, mid, high).

    The −1pp end stops 0.25pp above the growth rate: a perpetuity needs the discount rate above growth, and a valid
    mid case must never fail because its sensitivity end would not be.
    """
    high_rate = max(rate - KE_BAND, growth + 0.0025)
    return run(rate + KE_BAND).value, run(rate).value, run(min(high_rate, rate)).value


def _fi(c: _Context, s: FISettings, lbo_case: LBOResult | None) -> list[MethodOutput]:
    fi_weight = 1.0 if c.sector in FI_SECTORS else 0.0
    return [
        _ddm(c, s.ddm, fi_weight),
        _residual_income(c, s.residual_income, fi_weight),
        _ptbv(c, s, fi_weight),
        _fcfe(c, s.fcfe),
        _apv(c, s.apv, lbo_case),
    ]


def _ddm(c: _Context, d: DDMSettings | None, default_weight: float) -> MethodOutput:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="ddm", label="Dividend discount", group="fi", **kw)

    if d is None:
        return out(status="needs_input", missing=["dividend assumptions"])
    dividend = d.current_dividend
    if dividend is None:
        paid = c.get("dividends_paid")
        dividend = abs(paid) if paid is not None else None
    rate = d.cost_of_equity or c.ke
    growth = d.terminal_growth if d.terminal_growth is not None else c.g
    missing = _missing(("current dividend", dividend), ("cost of equity", rate), ("terminal growth", growth))
    if missing:
        return out(status="needs_input", missing=missing)
    assert dividend is not None and rate is not None and growth is not None

    def run(ke: float) -> ValueResult:
        return run_ddm(
            DDMInputs(
                current_dividend=dividend,
                high_growth=d.high_growth,
                years=d.years,
                terminal_growth=growth,
                cost_of_equity=ke,
            )
        )

    try:
        mid = run(rate)
        values = _band(run, rate, growth)
    except ValueError as error:
        return out(status="error", message=str(error))
    rng = _range("ddm", "Dividend discount (ke ±1pp)", values, c.weight("ddm", default_weight))
    return out(status="ready", result={**mid.model_dump(), "dividend": dividend, "cost_of_equity": rate}, range=rng)


def _book_equity(c: _Context) -> float | None:
    return c.get("equity_to_shareholders") or c.get("total_equity")


def _residual_income(c: _Context, r: ResidualIncomeSettings | None, default_weight: float) -> MethodOutput:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="residual_income", label="Residual income", group="fi", **kw)

    if r is None or not r.roe:
        return out(status="needs_input", missing=["return on equity by year"])
    book = _book_equity(c)
    rate = r.cost_of_equity or c.ke
    missing = _missing(("positive book equity", book if book and book > 0 else None), ("cost of equity", rate))
    if missing:
        return out(status="needs_input", missing=missing)
    assert book is not None and rate is not None

    def run(ke: float) -> ValueResult:
        return run_residual_income(
            ResidualIncomeInputs(
                book_value=book,
                roe=r.roe,
                payout_ratio=r.payout_ratio,
                cost_of_equity=ke,
                terminal_growth=r.terminal_growth,
            )
        )

    try:
        mid = run(rate)
        values = _band(run, rate, r.terminal_growth)
    except ValueError as error:
        return out(status="error", message=str(error))
    rng = _range("residual_income", "Residual income (ke ±1pp)", values, c.weight("residual_income", default_weight))
    return out(status="ready", result={**mid.model_dump(), "book_value": book, "cost_of_equity": rate}, range=rng)


def _ptbv(c: _Context, s: FISettings, default_weight: float) -> MethodOutput:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="ptbv", label="Price / tangible book", group="fi", **kw)

    if s.ptbv_mid is None:
        return out(status="needs_input", missing=["P/TBV multiples"])
    book = _book_equity(c)
    if book is None:
        return out(status="needs_input", missing=["book equity"])
    goodwill = c.get("goodwill") or 0.0
    intangibles = c.get("other_intangibles") or 0.0
    multiples = (s.ptbv_low or s.ptbv_mid, s.ptbv_mid, s.ptbv_high or s.ptbv_mid)
    try:
        lo, mid, hi = (price_to_tangible_book(book, goodwill, intangibles, m) for m in multiples)
    except ValueError as error:
        return out(status="error", message=str(error))
    rng = _range("ptbv", "Price / tangible book", (lo, mid, hi), c.weight("ptbv", default_weight))
    return out(
        status="ready",
        result={"book_equity": book, "goodwill": goodwill, "intangibles": intangibles, "multiples": multiples},
        range=rng,
    )


def _fcfe(c: _Context, f: FCFESettings | None) -> MethodOutput:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="fcfe", label="Free cash flow to equity", group="fi", **kw)

    if f is None or not f.net_income:
        return out(status="needs_input", missing=["net income by projection year"])
    if c.qs.dcf is None:
        return out(status="needs_input", missing=["a complete DCF case (FCFE reuses its D&A, capex and NWC)"])
    years = c.qs.dcf.projection[: len(f.net_income)]
    n = len(years)
    rate = f.cost_of_equity or c.ke
    growth = f.terminal_growth if f.terminal_growth is not None else c.g
    missing = _missing(("cost of equity", rate), ("terminal growth", growth))
    if missing:
        return out(status="needs_input", missing=missing)
    assert rate is not None and growth is not None
    borrowing = (f.net_borrowing or [])[:n]
    borrowing += [0.0] * (n - len(borrowing))

    def run(ke: float) -> ValueResult:
        return run_fcfe(
            FCFEInputs(
                net_income=f.net_income[:n],
                da=[y.da for y in years],
                capex=[y.capex for y in years],
                change_in_nwc=[y.change_in_nwc for y in years],
                net_borrowing=borrowing,
                cost_of_equity=ke,
                terminal_growth=growth,
            )
        )

    try:
        mid = run(rate)
        values = _band(run, rate, growth)
    except ValueError as error:
        return out(status="error", message=str(error))
    rng = _range("fcfe", "FCFE (ke ±1pp)", values, c.weight("fcfe", 0.0))
    return out(status="ready", result={**mid.model_dump(), "cost_of_equity": rate}, range=rng)


def _apv(c: _Context, a: APVSettings | None, lbo_case: LBOResult | None) -> MethodOutput:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="apv", label="Adjusted present value", group="fi", **kw)

    if a is None:
        return out(status="needs_input", missing=["APV settings (an option for highly leveraged situations)"])
    qs = c.qs
    if qs.dcf is None:
        return out(status="needs_input", missing=["a complete DCF case (APV discounts its unlevered free cash flow)"])
    years = qs.dcf.projection
    kd = a.cost_of_debt or _assumption(qs, "pre_tax_cost_of_debt")
    ku = a.unlevered_cost_of_equity
    if ku is None and qs.wacc is not None and kd is not None:
        ku = unlevered_cost_of_equity(qs.wacc.cost_of_equity, kd, qs.wacc.debt_weight)
    debt = a.debt_balances
    source = "entered"
    if not debt and lbo_case is not None:
        debt = [lbo_case.total_debt_at_close] + [y.total_debt for y in lbo_case.schedule]
        source = "lbo"
    missing = _missing(
        ("unlevered cost of equity", ku),
        ("pre-tax cost of debt", kd),
        ("debt balances by year (or a ready LBO case)", debt or None),
        ("tax rate", c.tax),
        ("terminal growth", c.g),
    )
    if missing:
        return out(status="needs_input", missing=missing)
    assert ku is not None and kd is not None and debt and c.tax is not None and c.g is not None
    balances = (debt + [debt[-1]] * len(years))[: len(years)]  # hold the last balance flat to the horizon
    try:
        apv = run_apv(
            APVInputs(
                unlevered_fcf=[y.unlevered_fcf for y in years],
                unlevered_cost_of_equity=ku,
                terminal_growth=c.g,
                debt_balances=balances,
                cost_of_debt=kd,
                tax_rate=c.tax,
                expected_distress_cost=a.expected_distress_cost,
            )
        )
    except ValueError as error:
        return out(status="error", message=str(error))
    equity = ev_to_equity(apv.enterprise_value, c.bridge).equity_value
    rng = _range(
        "apv",
        "Adjusted present value",
        (equity, equity, equity),
        c.weight("apv", 0.0),
        ev=(apv.enterprise_value, apv.enterprise_value, apv.enterprise_value),
    )
    return out(
        status="ready",
        result={
            **apv.model_dump(),
            "equity_value": equity,
            "unlevered_cost_of_equity": ku,
            "cost_of_debt": kd,
            "debt_balances": balances,
            "debt_source": source,
        },
        range=rng,
    )


# ── strategic buyer ──────────────────────────────────────────────────────────
def _synergies(c: _Context, s: SynergySettings | None) -> MethodOutput:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="strategic", label="Strategic value (synergies)", group="strategic", **kw)

    if s is None:
        return out(status="needs_input", missing=["cost and/or revenue synergies"])
    rate = s.discount_rate or (c.qs.wacc.wacc if c.qs.wacc else None)
    growth = s.terminal_growth if s.terminal_growth is not None else c.g
    missing = _missing(("discount rate (WACC)", rate), ("tax rate", c.tax), ("terminal growth", growth))
    if missing:
        return out(status="needs_input", missing=missing)
    assert rate is not None and c.tax is not None and growth is not None
    try:
        syn = run_synergies(
            SynergyInputs(
                cost_synergies=s.cost_synergies,
                revenue_synergies=s.revenue_synergies,
                revenue_synergy_margin=s.revenue_synergy_margin,
                phasing=s.phasing,
                integration_costs=s.integration_costs,
                tax_rate=c.tax,
                discount_rate=rate,
                terminal_growth=growth,
                probability=s.probability,
                share_paid_away=s.share_paid_away,
            )
        )
    except ValueError as error:
        return out(status="error", message=str(error))
    rng = None
    d = c.qs.dcf_range
    if d:
        rng = _range(
            "strategic",
            "Strategic value (DCF + synergies)",
            strategic_value((d["equity_low"], d["equity_mid"], d["equity_high"]), syn.value),
            c.weight("strategic", 0.0),
            note="The most a strategic buyer could pay: standalone DCF value plus the risked value of synergies.",
        )
    return out(status="ready", result={**syn.model_dump(), "discount_rate": rate}, range=rng)


def _accretion(
    c: _Context, a: AccretionSettings | None, syn: SynergySettings | None, ff: FootballField | None
) -> MethodOutput:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="accretion", label="Accretion / dilution", group="strategic", **kw)

    if a is None:
        return out(status="needs_input", missing=["the acquirer's net income, shares and share price"])
    target_income = c.get("net_income_to_shareholders") or c.get("net_income")
    price = a.purchase_equity_value or (ff.blended_equity_mid if ff else None)
    missing = _missing(("target net income", target_income), ("purchase price", price), ("tax rate", c.tax))
    if missing:
        return out(status="needs_input", missing=missing)
    assert target_income is not None and price is not None and c.tax is not None
    synergies = (
        run_rate_synergy_ebitda(syn.cost_synergies, syn.revenue_synergies, syn.revenue_synergy_margin)
        if a.use_synergies and syn
        else 0.0
    )
    try:
        acc = run_accretion(
            AccretionInputs(
                acquirer_net_income=a.acquirer_net_income,
                acquirer_shares=a.acquirer_shares,
                acquirer_share_price=a.acquirer_share_price,
                target_net_income=target_income,
                purchase_equity_value=price,
                cash_share=a.cash_share,
                debt_share=a.debt_share,
                stock_share=a.stock_share,
                interest_on_new_debt=a.interest_on_new_debt,
                foregone_interest_on_cash=a.foregone_interest_on_cash,
                tax_rate=c.tax,
                pre_tax_synergies=synergies,
                amortisation_of_intangibles=a.amortisation_of_intangibles,
                transaction_costs=a.transaction_costs,
            )
        )
    except ValueError as error:
        return out(status="error", message=str(error))
    return out(
        status="ready",
        result={
            **acc.model_dump(),
            "purchase_equity_value": price,
            "price_source": "entered" if a.purchase_equity_value else "blended",
            "pre_tax_synergies": synergies,
            "target_net_income": target_income,
        },
    )


# ── other reference values ───────────────────────────────────────────────────
def _liquidation(c: _Context, s: LiquidationSettings) -> MethodOutput:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="liquidation", label="Liquidation value", group="other", **kw)

    if not s.assets:
        return out(status="needs_input", missing=["assets with recovery rates"])
    liabilities = c.get("total_liabilities")
    if liabilities is None:
        return out(status="needs_input", missing=["total liabilities in the latest balance sheet"])
    liq = run_liquidation(
        LiquidationInputs(assets=s.assets, liabilities=max(liabilities, 0.0), wind_down_costs=s.wind_down_costs)
    )
    rng = _range(
        "liquidation",
        "Liquidation value",
        (liq.equity_low, liq.equity_low, liq.equity_high),
        c.weight("liquidation", 0.0),
        note="A floor: what shareholders would receive in an orderly wind-down.",
    )
    return out(status="ready", result={**liq.model_dump(), "liabilities": liabilities}, range=rng)


def _replacement(c: _Context, s: ReplacementSettings) -> MethodOutput:
    def out(**kw: Any) -> MethodOutput:
        return MethodOutput(id="replacement", label="Replacement cost", group="other", **kw)

    if not s.lines:
        return out(status="needs_input", missing=["assets with replacement costs"])
    ev = replacement_value(s.lines)
    equity = ev_to_equity(ev, c.bridge).equity_value
    rng = _range(
        "replacement",
        "Replacement cost",
        (equity, equity, equity),
        c.weight("replacement", 0.0),
        ev=(ev, ev, ev),
        note="Depreciated cost to rebuild the asset base, less net debt.",
    )
    return out(status="ready", result={"enterprise_value": ev, "equity_value": equity}, range=rng)
