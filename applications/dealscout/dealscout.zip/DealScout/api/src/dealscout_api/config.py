"""Runtime configuration (environment + optional .env), and the per-user app data folder layout."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv
from platformdirs import user_data_dir

REPO_ROOT = Path(__file__).resolve().parents[3]
APP_NAME = "DealScout"
HOST = "127.0.0.1"  # never 0.0.0.0: DealScout must not be reachable from the network


def _bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    return default if raw is None else raw.strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    data_dir: Path
    port: int = 8000
    dev: bool = False
    open_browser: bool = True
    max_upload_mb: int = 200
    defaults_stale_days: int = 90
    disable_ai: bool = False
    web_dir: Path = field(default_factory=lambda: REPO_ROOT / "web" / "out")
    reference_dir: Path = field(default_factory=lambda: REPO_ROOT / "data")

    @property
    def db_path(self) -> Path:
        return self.data_dir / "dealscout.sqlite3"

    @property
    def uploads_dir(self) -> Path:
        return self.data_dir / "documents"

    def deal_folder(self, deal_id: str) -> Path:
        """A deal's upload folder; deal ids are 32 hex characters, so a path can never leave the uploads folder."""
        if not re.fullmatch(r"[0-9a-f]{32}", deal_id):
            raise ValueError("invalid deal id")
        return self.uploads_dir / deal_id

    @property
    def cache_dir(self) -> Path:
        return self.data_dir / "cache"

    @property
    def exports_dir(self) -> Path:
        return self.data_dir / "exports"

    @property
    def secrets_dir(self) -> Path:
        return self.data_dir / "secrets"

    def ensure_dirs(self) -> None:
        for path in (self.data_dir, self.uploads_dir, self.cache_dir, self.exports_dir, self.secrets_dir):
            path.mkdir(parents=True, exist_ok=True)


def load_settings() -> Settings:
    load_dotenv(REPO_ROOT / ".env", override=False)
    data_dir = Path(os.environ.get("DEALSCOUT_DATA_DIR") or user_data_dir(APP_NAME, appauthor=False))
    return Settings(
        data_dir=data_dir.expanduser().resolve(),
        port=_int("DEALSCOUT_PORT", 8000),
        dev=_bool("DEALSCOUT_DEV", False),
        open_browser=_bool("DEALSCOUT_OPEN_BROWSER", True),
        max_upload_mb=_int("DEALSCOUT_MAX_UPLOAD_MB", 200),
        defaults_stale_days=_int("DEALSCOUT_DEFAULTS_STALE_DAYS", 90),
        disable_ai=_bool("DEALSCOUT_DISABLE_AI", False),
    )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return load_settings()
