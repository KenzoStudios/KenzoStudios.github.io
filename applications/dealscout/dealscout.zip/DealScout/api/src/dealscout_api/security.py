"""Local-only protections: reject non-localhost Host and Origin headers.

The server binds to 127.0.0.1, so other machines cannot connect. This middleware additionally blocks
DNS-rebinding (a hostile site resolving its own hostname to 127.0.0.1 — the Host header then names that
site) and cross-site requests from other web pages open in the user's browser (their Origin is not local).
"""

from __future__ import annotations

from urllib.parse import urlsplit

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

LOCAL_HOSTNAMES = {"localhost", "127.0.0.1", "[::1]", "::1"}


def _hostname(value: str) -> str:
    value = value.strip().lower()
    if value.startswith("["):  # IPv6 literal with optional port
        return value[: value.find("]") + 1] if "]" in value else value
    return value.rsplit(":", 1)[0] if value.count(":") == 1 else value


def is_local_host_header(host: str | None) -> bool:
    return bool(host) and _hostname(host or "") in LOCAL_HOSTNAMES


def is_local_origin(origin: str) -> bool:
    if origin == "null":
        return False
    parts = urlsplit(origin)
    return parts.scheme in {"http", "https"} and (parts.hostname or "") in {"localhost", "127.0.0.1", "::1"}


class LocalOnlyMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        if not is_local_host_header(request.headers.get("host")):
            return JSONResponse({"detail": "DealScout only answers requests addressed to localhost."}, 421)
        origin = request.headers.get("origin")
        if origin is not None and not is_local_origin(origin):
            return JSONResponse({"detail": "Cross-site requests are not allowed."}, 403)
        if request.method not in {"GET", "HEAD", "OPTIONS"} and request.headers.get("sec-fetch-site") == "cross-site":
            return JSONResponse({"detail": "Cross-site requests are not allowed."}, 403)
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        response.headers.setdefault("X-Frame-Options", "DENY")
        return response
