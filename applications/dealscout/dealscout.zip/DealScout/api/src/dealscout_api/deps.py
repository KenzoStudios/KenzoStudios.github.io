"""FastAPI dependencies shared by routes."""

from __future__ import annotations

from typing import cast

from fastapi import Request

from .jobs import JobRunner
from .services.ai_service import AIService


def ai_service(request: Request) -> AIService:
    return cast(AIService, request.app.state.ai_service)


def job_runner(request: Request) -> JobRunner:
    return cast(JobRunner, request.app.state.job_runner)
