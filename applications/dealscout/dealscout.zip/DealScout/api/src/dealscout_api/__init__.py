"""dealscout_api package."""

__version__ = "0.1.0"
