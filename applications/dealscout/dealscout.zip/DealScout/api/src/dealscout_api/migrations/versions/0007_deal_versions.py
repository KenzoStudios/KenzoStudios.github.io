"""Saved versions of a deal: immutable snapshots of its inputs with the headline results (brief §14).

Revision ID: 0007
Revises: 0006
"""

from __future__ import annotations

import sqlalchemy as sa
import sqlmodel
from alembic import op

revision = "0007"
down_revision = "0006"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "dealversion",
        sa.Column("id", sqlmodel.sql.sqltypes.AutoString(), nullable=False),
        sa.Column("deal_id", sqlmodel.sql.sqltypes.AutoString(), nullable=False),
        sa.Column("name", sqlmodel.sql.sqltypes.AutoString(length=120), nullable=False),
        sa.Column("note", sqlmodel.sql.sqltypes.AutoString(length=2000), nullable=True),
        sa.Column("kind", sqlmodel.sql.sqltypes.AutoString(length=20), nullable=False),
        sa.Column("snapshot", sa.JSON(), nullable=True),
        sa.Column("results", sa.JSON(), nullable=True),
        sa.Column("created_by", sqlmodel.sql.sqltypes.AutoString(length=120), nullable=False),
        sa.Column("created_at", sqlmodel.sql.sqltypes.UTCDateTime(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    with op.batch_alter_table("dealversion", schema=None) as batch_op:
        batch_op.create_index(batch_op.f("ix_dealversion_deal_id"), ["deal_id"], unique=False)
        batch_op.create_index(batch_op.f("ix_dealversion_created_at"), ["created_at"], unique=False)


def downgrade() -> None:
    with op.batch_alter_table("dealversion", schema=None) as batch_op:
        batch_op.drop_index(batch_op.f("ix_dealversion_created_at"))
        batch_op.drop_index(batch_op.f("ix_dealversion_deal_id"))
    op.drop_table("dealversion")
