"""Wider extracted-item cell reference (tagged fact ids and HTML table cells).

Revision ID: 0004
Revises: 0003
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("extracteditem") as batch:
        batch.alter_column("cell_ref", existing_type=sa.String(length=20), type_=sa.String(length=80))


def downgrade() -> None:
    with op.batch_alter_table("extracteditem") as batch:
        batch.alter_column("cell_ref", existing_type=sa.String(length=80), type_=sa.String(length=20))
