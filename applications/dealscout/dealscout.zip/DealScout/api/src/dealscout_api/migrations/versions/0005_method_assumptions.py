"""Per-deal inputs for the Milestone 5 valuation methods (LBO, precedents, NAV/SOTP, FI, strategic, one-offs).

Revision ID: 0005
Revises: 0004
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("dealassumptions") as batch:
        batch.add_column(sa.Column("methods", sa.JSON(), nullable=True, server_default=sa.text("'{}'")))


def downgrade() -> None:
    with op.batch_alter_table("dealassumptions") as batch:
        batch.drop_column("methods")
