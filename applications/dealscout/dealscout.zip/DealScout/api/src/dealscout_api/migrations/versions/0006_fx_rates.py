"""Per-deal FX rates entered by the analyst (average and closing per period, and peer currency rates).

Revision ID: 0006
Revises: 0005
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("dealassumptions") as batch:
        batch.add_column(sa.Column("fx", sa.JSON(), nullable=True, server_default=sa.text("'{}'")))


def downgrade() -> None:
    with op.batch_alter_table("dealassumptions") as batch:
        batch.drop_column("fx")
