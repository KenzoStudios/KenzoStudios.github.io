"""Saved versions of a deal (brief §14): save, list, compare with the current deal, restore."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field, field_validator
from sqlmodel import Session

from ..db import get_session
from ..models import Deal, DealVersion
from ..services import versions as service

router = APIRouter(prefix="/api/deals/{deal_id}/versions", tags=["versions"])


class VersionIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    note: str | None = Field(default=None, max_length=2000)

    @field_validator("name")
    @classmethod
    def _strip(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("name is required")
        return value


def _deal(session: Session, deal_id: str) -> Deal:
    deal = session.get(Deal, deal_id)
    if deal is None:
        raise HTTPException(status_code=404, detail="Deal not found")
    return deal


def _version(session: Session, deal_id: str, version_id: str) -> DealVersion:
    version = session.get(DealVersion, version_id)
    if version is None or version.deal_id != deal_id:
        raise HTTPException(status_code=404, detail="Version not found")
    return version


def _valuation(session: Session, deal_id: str) -> dict[str, Any]:
    from .valuation import valuation

    return valuation(deal_id, session)


@router.get("")
def list_versions(deal_id: str, session: Session = Depends(get_session)) -> list[dict[str, Any]]:
    _deal(session, deal_id)
    return [service.version_row(v) for v in service.list_versions(session, deal_id)]


@router.post("", status_code=status.HTTP_201_CREATED)
def save_version(deal_id: str, payload: VersionIn, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    version = service.save_version(session, deal, _valuation(session, deal_id), name=payload.name, note=payload.note)
    session.commit()
    session.refresh(version)
    return service.version_row(version)


@router.get("/{version_id}/compare")
def compare_version(deal_id: str, version_id: str, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    version = _version(session, deal_id, version_id)
    return service.compare(session, deal, version, _valuation(session, deal_id))


@router.post("/{version_id}/restore")
def restore_version(deal_id: str, version_id: str, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    version = _version(session, deal_id, version_id)
    backup = service.save_version(
        session,
        deal,
        _valuation(session, deal_id),
        name=f"Before restoring '{version.name}'"[:120],
        note="Saved automatically before a restore. Restore this version to undo it.",
        kind="before_restore",
    )
    service.restore(session, deal, version)
    session.commit()
    session.refresh(backup)
    return {"restored": service.version_row(version), "backup": service.version_row(backup)}
