"""Assumptions, peers, Quick Scan valuation and market defaults."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException
from pydantic import BaseModel, Field, ValidationError
from sqlmodel import Session, select

from dealscout_engine.defaults import MarketDefaults, is_stale, load_defaults
from dealscout_engine.quickscan import DealContext, Overrides, QuickScanResult, run_quick_scan
from dealscout_engine.recommendation import Suggestion, suitability
from dealscout_engine.scores import adjusted_data, adjusted_metrics
from dealscout_engine.statements import FinancialData
from dealscout_engine.valuation.comps import BASES, MULTIPLES, Peer, multiple_stats, peer_regression
from dealscout_engine.valuation.dcf import (
    run_scenarios,
    sensitivity_growth_margin,
    sensitivity_wacc_exit,
    sensitivity_wacc_growth,
)

from ..db import get_session
from ..deps import ai_service, job_runner
from ..jobs import JobRunner
from ..models import Deal, FinancialValue, Job, utcnow
from ..services import audit, normalisation
from ..services import financials as fin
from ..services import fx as fx_service
from ..services import methods as methods_service
from ..services import recommendation as rec_service
from ..services.ai_service import AIService
from ..services.app_settings import load_preferences
from ..services.reference import reference_data

router = APIRouter(prefix="/api", tags=["valuation"])


def _deal(session: Session, deal_id: str) -> Deal:
    deal = session.get(Deal, deal_id)
    if deal is None:
        raise HTTPException(status_code=404, detail="Deal not found")
    return deal


class AssumptionsIn(BaseModel):
    overrides: dict[str, Any] | None = None
    peers: list[Peer] | None = Field(default=None, max_length=200)
    notes: dict[str, str] | None = None


@router.get("/deals/{deal_id}/assumptions")
def get_assumptions(deal_id: str, session: Session = Depends(get_session)) -> dict[str, Any]:
    _deal(session, deal_id)
    doc = fin.assumptions_doc(session, deal_id)
    return {"overrides": doc.overrides, "peers": doc.peers, "notes": doc.notes}


@router.put("/deals/{deal_id}/assumptions")
def put_assumptions(deal_id: str, payload: AssumptionsIn, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    doc = fin.assumptions_doc(session, deal_id)
    changed: list[str] = []
    if payload.overrides is not None:
        try:
            clean = Overrides.model_validate(payload.overrides).model_dump(exclude_none=True, exclude_defaults=True)
        except ValidationError as error:
            detail = error.errors(include_url=False, include_context=False)
            raise HTTPException(status_code=422, detail=detail) from error
        changed += sorted(k for k in set(clean) | set(doc.overrides) if clean.get(k) != doc.overrides.get(k))
        doc.overrides = clean
    if payload.peers is not None:
        doc.peers = [p.model_dump() for p in payload.peers]
        changed.append("peers")
    if payload.notes is not None:
        doc.notes = {k: v[:2000] for k, v in payload.notes.items() if v.strip()}
        changed.append("notes")
    doc.updated_at = utcnow()
    deal.updated_at = utcnow()
    session.add(doc)
    session.add(deal)
    if changed:
        audit.record(session, "assumptions_changed", deal_id=deal_id, detail={"fields": changed})
    session.commit()
    return {"overrides": doc.overrides, "peers": doc.peers, "notes": doc.notes}


class _Scan:
    """One Quick Scan of a deal with its stored inputs, shared by the valuation and methods endpoints."""

    def __init__(self, session: Session, deal: Deal):
        periods = fin.ensure_periods(session, deal)
        annual = fin.annual_periods(periods)
        native = fin.financial_data(session, deal.id)
        record = fin.assumptions_doc(session, deal.id)
        self.overrides = Overrides.model_validate(record.overrides or {})
        self.methods = methods_service.load_methods(record.methods)
        self.defaults: MarketDefaults = load_defaults()
        # currency (brief §7): figures move to the analysis currency at the rates entered; never at a guessed rate
        fx_doc = fx_service.load_fx(record.fx)
        self.fx = fx_service.convert_deal(deal, native, self.methods.normalisation.adjustments, fx_doc)
        message = self.fx.message()
        if message:
            raise HTTPException(status_code=409, detail=message)
        self.currency = self.fx.currency
        reported = self.fx.data
        self.methods = self.methods.model_copy(
            update={"normalisation": self.methods.normalisation.model_copy(update={"adjustments": self.fx.adjustments})}
        )
        norm = self.methods.normalisation
        confirmed = [a for a in norm.adjustments if a.confirmed]
        self.adjusted = norm.use_adjusted_ebitda and bool(confirmed)
        self.data: FinancialData = adjusted_data(reported, norm.adjustments) if self.adjusted else reported
        self.reported = reported
        with_revenue = [p for p in annual if self.data.get("revenue", p.key) is not None]
        last = with_revenue[-1] if with_revenue else (annual[-1] if annual else None)
        # peers: converted to the analysis currency, then calendarised to the target's fiscal year-end
        year_end = last.end_date if last and last.end_date else None
        prep = fx_service.prepare_peers(
            [Peer.model_validate(p) for p in record.peers],
            self.currency,
            fx_doc,
            year_end.month if year_end else None,
        )
        self.peers = prep.peers
        self.peer_rows = prep.rows
        self.peers_excluded = prep.excluded
        ctx = DealContext(
            country=deal.country,
            sector=deal.sector,
            reporting_currency=self.currency,
            listed=deal.listed,
            valuation_date=deal.valuation_date,
            last_fiscal_year_end=(last.end_date if last and last.end_date else deal.valuation_date),
            country_currency=next(
                (c["currency"] for c in reference_data()["countries"] if c["code"] == deal.country), None
            ),
        )
        # suitability guide (brief §9.1) pre-fills the weights; the analyst's own weights win
        sector: dict[str, Any] = next((x for x in reference_data()["sectors"] if x["id"] == deal.sector), {})
        base_ebitda = self.data.get("ebitda", last.key) if last else None
        self.suggestions: list[Suggestion] = suitability(
            str(sector.get("profile", "mature")),
            perspective=deal.perspective,
            loss_making=base_ebitda is not None and base_ebitda <= 0,
            listed=deal.listed,
            sector=deal.sector,
        )
        self.user_weights = dict(self.overrides.method_weights)
        self.weights = {s.method_id: s.weight for s in self.suggestions} | self.user_weights
        scan_overrides = self.overrides.model_copy(update={"method_weights": self.weights})
        self.result: QuickScanResult = run_quick_scan(
            self.data, [p.key for p in with_revenue], ctx, self.defaults, scan_overrides, self.peers
        )
        self.run = methods_service.run_methods(
            data=self.data,
            qs=self.result,
            doc=self.methods,
            defaults=self.defaults,
            currency=self.currency,
            sector=deal.sector,
            perspective=deal.perspective,
            listed=deal.listed,
            valuation_date=deal.valuation_date,
            weights=self.weights,
        )
        # the football field covers every method that is ready, after any marketability discount
        self.result = self.result.model_copy(update={"football_field": self.run.football_field})

    def normalisation_summary(self) -> dict[str, Any]:
        base = self.result.base_period
        metrics = adjusted_metrics(self.reported, base, self.methods.normalisation.adjustments) if base else None
        return {
            "use_adjusted_ebitda": self.methods.normalisation.use_adjusted_ebitda,
            "applied": self.adjusted,
            "base_period": base,
            "metrics": metrics.model_dump() if metrics else None,
            "pending_suggestions": sum(
                1 for a in self.methods.normalisation.adjustments if a.source == "ai_suggested" and not a.confirmed
            ),
        }


@router.get("/deals/{deal_id}/valuation")
def valuation(deal_id: str, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    scan = _Scan(session, deal)
    result, overrides, peers = scan.result, scan.overrides, scan.peers

    extra: dict[str, Any] = {
        "sensitivities": [],
        "scenarios": None,
        "scenarios_error": None,
        "peer_stats": [],
        "peer_stats_by_basis": {},
        "comps_basis": overrides.comps_basis,
        "regressions": [],
    }
    if result.dcf is not None and result.dcf_inputs is not None:
        base_inputs = result.dcf_inputs
        steps = [-0.01, -0.005, 0, 0.005, 0.01]
        extra["sensitivities"] = [
            sensitivity_wacc_growth(base_inputs, steps, [-0.01, -0.005, 0, 0.005, 0.01]).model_dump(),
            sensitivity_wacc_exit(base_inputs, steps, [-2, -1, 0, 1, 2]).model_dump(),
            sensitivity_growth_margin(
                base_inputs, [-0.02, -0.01, 0, 0.01, 0.02], [-0.02, -0.01, 0, 0.01, 0.02]
            ).model_dump(),
        ]
        try:
            extra["scenarios"] = run_scenarios(base_inputs, scan.methods.scenarios).model_dump()
        except ValueError as error:
            extra["scenarios_error"] = str(error)
    if peers or scan.peers_excluded:
        by_basis = {}
        for basis in BASES:
            rows = []
            for m in MULTIPLES:
                stats = multiple_stats(peers, m, exclude_outliers=overrides.exclude_peer_outliers, basis=basis)
                stats.excluded.update(scan.peers_excluded)  # peers whose currency has no rate entered
                rows.append(stats.model_dump())
            by_basis[basis] = rows
        extra["peer_stats"] = by_basis[overrides.comps_basis]
        extra["peer_stats_by_basis"] = by_basis
        target_growth = None
        growth = next((a.value for a in result.assumptions if a.key == "revenue_growth"), None)
        if isinstance(growth, list) and growth:
            target_growth = growth[0]
        margin = next((a.value for a in result.assumptions if a.key == "ebitda_margin"), None)
        for x_attr, target_x in (
            ("revenue_growth", target_growth),
            ("ebitda_margin", margin[0] if isinstance(margin, list) and margin else None),
        ):
            reg = peer_regression(peers, "ev_ebitda", x_attr, target_x)  # type: ignore[arg-type]
            if reg:
                extra["regressions"].append(reg.model_dump())
    return {
        "deal": {
            "id": deal.id,
            "name": deal.name,
            "currency": scan.currency,
            "reporting_currency": deal.reporting_currency,
            "listed": deal.listed,
            "sector": deal.sector,
            "perspective": deal.perspective,
        },
        "fx": scan.fx.summary(),
        "peer_adjustments": scan.peer_rows,
        "result": result.model_dump(mode="json"),
        **extra,
        "methods": [o.model_dump(mode="json") for o in scan.run.outputs],
        "market_points": [p.model_dump() for p in scan.run.market_points],
        "dlom_applied": scan.run.dlom_applied,
        "normalisation": scan.normalisation_summary(),
        "defaults": defaults_meta(scan.defaults),
        "analyst": load_preferences(session).user_name,
    }


def defaults_meta(defaults: MarketDefaults) -> dict[str, Any]:
    return {"version": defaults.version, "as_of": defaults.as_of}


# ── method inputs (LBO, precedents, NAV/SOTP, FI, strategic, other, normalisation) ──
@router.get("/deals/{deal_id}/methods")
def get_methods(deal_id: str, session: Session = Depends(get_session)) -> dict[str, Any]:
    _deal(session, deal_id)
    record = fin.assumptions_doc(session, deal_id)
    return methods_service.load_methods(record.methods).model_dump(mode="json")


@router.put("/deals/{deal_id}/methods/{section}")
def put_method_section(
    deal_id: str, section: str, payload: Any = Body(default=None), session: Session = Depends(get_session)
) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    if section not in methods_service.SECTIONS:
        raise HTTPException(status_code=404, detail=f"Unknown method section {section!r}")
    try:
        validated = methods_service.MethodsDoc.model_validate({section: payload})
    except ValidationError as error:
        raise HTTPException(status_code=422, detail=error.errors(include_url=False, include_context=False)) from error
    record = fin.assumptions_doc(session, deal_id)
    stored = dict(record.methods or {})
    value = validated.model_dump(mode="json")[section]
    if stored.get(section) != value:
        stored[section] = value
        record.methods = stored
        record.updated_at = utcnow()
        deal.updated_at = utcnow()
        session.add(record)
        session.add(deal)
        audit.record(session, "method_inputs_changed", deal_id=deal_id, detail={"section": section})
        session.commit()
    return methods_service.load_methods(record.methods).model_dump(mode="json")


@router.post("/deals/{deal_id}/normalisation/suggest", status_code=202)
def suggest_one_offs(
    deal_id: str,
    session: Session = Depends(get_session),
    runner: JobRunner = Depends(job_runner),
    ai: AIService = Depends(ai_service),
) -> Job:
    _deal(session, deal_id)
    ai.provider_for(session)  # a clear error (not connected, disabled, spend cap) before any job starts
    return runner.submit(
        "suggest_one_offs", steps=normalisation.SUGGEST_STEPS, deal_id=deal_id, payload=normalisation.payload(deal_id)
    )


# ── acquisition price (Milestone 6) ─────────────────────────────────────────────
def _confidences(session: Session, deal_id: str) -> list[float]:
    """Extracted values carry their confidence; values the analyst typed count as 1."""
    rows = session.exec(select(FinancialValue).where(FinancialValue.deal_id == deal_id)).all()
    return [r.confidence if r.confidence is not None else 1.0 for r in rows]


@router.get("/deals/{deal_id}/recommendation")
def recommendation(deal_id: str, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    scan = _Scan(session, deal)
    return {
        "deal": {
            "id": deal.id,
            "currency": scan.currency,
            "reporting_currency": deal.reporting_currency,
            "listed": deal.listed,
            "perspective": deal.perspective,
        },
        "fx": scan.fx.summary(),
        **rec_service.build(
            scan,
            currency=scan.currency,
            listed=deal.listed,
            value_confidences=_confidences(session, deal_id),
            stored_rationale=scan.methods.rationale,
        ),
    }


@router.post("/deals/{deal_id}/recommendation/rationale")
def write_rationale(
    deal_id: str, session: Session = Depends(get_session), ai: AIService = Depends(ai_service)
) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    scan = _Scan(session, deal)
    payload = rec_service.build(
        scan,
        currency=scan.currency,
        listed=deal.listed,
        value_confidences=_confidences(session, deal_id),
        stored_rationale=None,
    )
    if not payload["facts"]:
        raise HTTPException(status_code=409, detail="There is no suggested price yet: complete at least one method.")
    provider = ai.provider_for(session, purpose="writing")
    items = [rec_service.Fact.model_validate(f) for f in payload["facts"]]
    doc, usage = rec_service.ai_rationale(provider, items)
    ai.record_usage(session, usage, purpose="rationale", deal_id=deal_id, prompt_version=rec_service.PROMPT_VERSION)
    record = fin.assumptions_doc(session, deal_id)
    record.methods = {**(record.methods or {}), "rationale": doc.model_dump()}
    record.updated_at = utcnow()
    session.add(record)
    audit.record(session, "rationale_written", deal_id=deal_id, detail={"source": doc.source, "rejected": doc.rejected})
    session.commit()
    return recommendation(deal_id, session)


@router.get("/defaults")
def defaults_listing() -> dict[str, Any]:
    defaults = load_defaults()
    entries = []
    for path, entry in defaults.entries():
        as_of = str(entry.get("as_of")) if entry.get("as_of") else None
        entries.append(
            {
                "path": path,
                "value": entry.get("value"),
                "fields": {k: v for k, v in entry.items() if k not in {"source", "source_url", "status", "as_of"}},
                "as_of": as_of,
                "source": entry.get("source"),
                "source_url": entry.get("source_url"),
                "status": entry.get("status"),
                "stale": is_stale(as_of, defaults.stale_after_days),
            }
        )
    return {
        "version": defaults.version,
        "as_of": defaults.as_of,
        "stale_after_days": defaults.stale_after_days,
        "entries": entries,
    }
