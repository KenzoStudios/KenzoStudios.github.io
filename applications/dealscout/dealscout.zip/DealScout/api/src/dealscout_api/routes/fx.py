"""FX rates per deal: read and update the rates the analyst entered (brief §7)."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException
from pydantic import ValidationError
from sqlmodel import Session

from dealscout_engine.valuation.comps import Peer

from ..db import get_session
from ..models import Deal, utcnow
from ..services import audit
from ..services import financials as fin
from ..services import fx as fx_service
from ..services.methods import load_methods

router = APIRouter(prefix="/api/deals/{deal_id}", tags=["fx"])


def _deal(session: Session, deal_id: str) -> Deal:
    deal = session.get(Deal, deal_id)
    if deal is None:
        raise HTTPException(status_code=404, detail="Deal not found")
    return deal


def _payload(session: Session, deal: Deal) -> dict[str, Any]:
    record = fin.assumptions_doc(session, deal.id)
    doc = fx_service.load_fx(record.fx)
    periods = fin.ensure_periods(session, deal)
    data = fin.financial_data(session, deal.id)
    needed = fx_service.required_rates(data, [p.key for p in periods])
    adjustments = load_methods(record.methods).normalisation.adjustments
    for a in adjustments:  # confirmed one-offs need the average rate of their period
        if a.confirmed:
            needed.setdefault(a.period_key, set()).add("average")
    conversion = fx_service.convert_deal(deal, data, adjustments, doc)
    analysis = deal.analysis_currency.upper()
    peer_currencies = sorted(
        {str(c).upper() for p in record.peers if (c := Peer.model_validate(p).currency) and str(c).upper() != analysis}
    )
    have = {r.currency for r in doc.peer_rates}
    return {
        "reporting_currency": deal.reporting_currency,
        "analysis_currency": deal.analysis_currency,
        "needs_conversion": conversion.needed,
        "periods": [{"key": p.key, "end_date": p.end_date, "needs": sorted(needed.get(p.key, set()))} for p in periods],
        "rates": [r.model_dump(mode="json") for r in doc.rates],
        "peer_rates": [r.model_dump(mode="json") for r in doc.peer_rates],
        "peer_currencies": peer_currencies,
        "missing_peer_currencies": [c for c in peer_currencies if c not in have],
        "status": conversion.summary(),
    }


@router.get("/fx")
def get_fx(deal_id: str, session: Session = Depends(get_session)) -> dict[str, Any]:
    return _payload(session, _deal(session, deal_id))


@router.put("/fx")
def put_fx(deal_id: str, payload: Any = Body(default=None), session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    try:
        doc = fx_service.FxDoc.model_validate(payload or {})
    except ValidationError as error:
        raise HTTPException(status_code=422, detail=error.errors(include_url=False, include_context=False)) from error
    record = fin.assumptions_doc(session, deal_id)
    value = doc.model_dump(mode="json")
    if (record.fx or {}) != value:
        record.fx = value
        record.updated_at = utcnow()
        deal.updated_at = utcnow()
        session.add(record)
        session.add(deal)
        audit.record(
            session,
            "fx_rates_changed",
            deal_id=deal_id,
            detail={
                "periods": [r.period_id for r in doc.rates],
                "peer_currencies": [r.currency for r in doc.peer_rates],
            },
        )
        session.commit()
    return _payload(session, deal)
