"""Document upload, extraction jobs, the source file for highlighting, and the review actions."""

from __future__ import annotations

from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field
from sqlalchemy import update as sa_update
from sqlmodel import Session, col, select

from dealscout_engine.taxonomy import load_taxonomy

from ..config import get_settings
from ..db import get_session
from ..deps import job_runner
from ..jobs import JobRunner
from ..models import Deal, Document, ExtractedItem, utcnow
from ..services import audit
from ..services import documents as docs_service

router = APIRouter(prefix="/api/deals/{deal_id}", tags=["documents"])
MEDIA_TYPES = {
    "pdf": "application/pdf",
    "csv": "text/csv",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "xls": "application/vnd.ms-excel",
}


def _deal(session: Session, deal_id: str) -> Deal:
    deal = session.get(Deal, deal_id)
    if deal is None:
        raise HTTPException(status_code=404, detail="Deal not found")
    return deal


def _document(session: Session, deal_id: str, document_id: str) -> Document:
    doc = session.get(Document, document_id)
    if doc is None or doc.deal_id != deal_id:
        raise HTTPException(status_code=404, detail="Document not found")
    return doc


def _start(runner: JobRunner, session: Session, doc: Document) -> None:
    """Mark the document as being read, then start the job and record its id.

    The status is committed before the job exists, and afterwards only ``job_id`` is written: a fast job may already
    have marked the document processed, and this request must never overwrite that.
    """
    doc.status = "processing"
    session.add(doc)
    session.commit()
    job = runner.submit(
        "extract_document", steps=docs_service.EXTRACT_STEPS, deal_id=doc.deal_id, payload={"document_id": doc.id}
    )
    session.execute(sa_update(Document).where(col(Document.id) == doc.id).values(job_id=job.id))
    session.commit()
    session.refresh(doc)


@router.get("/documents")
def list_documents(deal_id: str, session: Session = Depends(get_session)) -> list[dict[str, Any]]:
    _deal(session, deal_id)
    rows = session.exec(select(Document).where(Document.deal_id == deal_id).order_by(col(Document.uploaded_at))).all()
    return [docs_service.document_payload(session, d) for d in rows]


@router.post("/documents", status_code=201)
async def upload_documents(
    deal_id: str,
    request: Request,
    files: list[UploadFile],
    session: Session = Depends(get_session),
    runner: JobRunner = Depends(job_runner),
) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    settings = get_settings()
    stored, rejected = [], []
    for upload in files[:50]:
        content = await upload.read(settings.max_upload_mb * 1024 * 1024 + 1)
        try:
            docs = docs_service.store_upload(settings, session, deal, upload.filename or "document", content)
        except docs_service.UploadRejected as error:
            rejected.append(str(error))
            continue
        session.commit()
        for doc in docs:
            session.refresh(doc)
            _start(runner, session, doc)
            stored.append(doc.model_dump(mode="json"))
    return {"documents": stored, "rejected": rejected}


@router.get("/documents/{document_id}/file", response_model=None)
def document_file(deal_id: str, document_id: str, session: Session = Depends(get_session)) -> FileResponse:
    """The original file. PDFs and images open inline; anything that could carry active content downloads."""
    doc = _document(session, deal_id, document_id)
    path = docs_service.document_path(get_settings(), doc)
    if not path.exists():
        raise HTTPException(status_code=404, detail="The file is missing from the data folder.")
    inline = doc.kind in ("pdf", "image")
    media = MEDIA_TYPES.get(doc.kind, "application/octet-stream") if inline else "application/octet-stream"
    if doc.kind == "image":
        media = "image/png" if path.read_bytes()[:4] == b"\x89PNG" else "image/jpeg"
    return FileResponse(
        path,
        media_type=media,
        headers={
            "Content-Disposition": f'{"inline" if inline else "attachment"}; filename="{doc.stored_name}"',
            "Cache-Control": "private, max-age=0",
            "X-Content-Type-Options": "nosniff",
        },
    )


# the review screen shows this page in an iframe: allow framing by DealScout itself only
VIEW_CSP = (
    "sandbox; default-src 'none'; img-src data:; style-src 'unsafe-inline'; font-src data:; frame-ancestors 'self'"
)


@router.get("/documents/{document_id}/view", response_model=None)
def document_view(deal_id: str, document_id: str, session: Session = Depends(get_session)) -> Response:
    """A sanitised copy of an HTML/iXBRL document for the review screen (no scripts, no network, sandboxed)."""
    doc = _document(session, deal_id, document_id)
    if doc.kind not in ("html", "xbrl", "zip"):
        raise HTTPException(status_code=409, detail="Only HTML and tagged filings have a document view.")
    body = docs_service.viewable(get_settings(), doc)
    return Response(
        content=body,
        media_type="text/html; charset=utf-8",
        headers={
            "Content-Security-Policy": VIEW_CSP,
            "X-Frame-Options": "SAMEORIGIN",
            "X-Content-Type-Options": "nosniff",
            "Referrer-Policy": "no-referrer",
            "Cache-Control": "private, max-age=0",
        },
    )


@router.post("/documents/{document_id}/extract", status_code=202)
def rerun(
    deal_id: str, document_id: str, session: Session = Depends(get_session), runner: JobRunner = Depends(job_runner)
) -> dict[str, Any]:
    doc = _document(session, deal_id, document_id)
    if doc.kind not in docs_service.SUPPORTED:
        raise HTTPException(status_code=409, detail="This file type is not read in this release.")
    _start(runner, session, doc)
    return doc.model_dump(mode="json")


@router.delete("/documents/{document_id}", status_code=204)
def delete_document(deal_id: str, document_id: str, session: Session = Depends(get_session)) -> None:
    doc = _document(session, deal_id, document_id)
    for item in session.exec(
        select(ExtractedItem).where(ExtractedItem.document_id == document_id, ExtractedItem.status == "pending")
    ).all():
        session.delete(item)
    path = docs_service.document_path(get_settings(), doc)
    path.unlink(missing_ok=True)
    audit.record(session, "document_deleted", deal_id=deal_id, detail={"filename": doc.filename})
    session.delete(doc)
    session.commit()


@router.get("/review")
def review(deal_id: str, session: Session = Depends(get_session)) -> dict[str, Any]:
    return docs_service.review_payload(session, _deal(session, deal_id))


class ReviewAction(BaseModel):
    item_id: int
    action: Literal["accept", "reject", "edit"]
    value: float | None = None  # absolute units, taxonomy sign (edit only)
    reason: str | None = Field(default=None, max_length=500)


class ReviewIn(BaseModel):
    actions: list[ReviewAction] = Field(default_factory=list, max_length=2000)
    accept_all_above: float | None = Field(default=None, ge=0, le=1)


@router.post("/review")
def review_actions(deal_id: str, payload: ReviewIn, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    items = {i.id: i for i in session.exec(select(ExtractedItem).where(ExtractedItem.deal_id == deal_id)).all()}
    to_accept: list[ExtractedItem] = []
    edited: dict[int, tuple[float, str]] = {}
    to_reject: list[ExtractedItem] = []
    if payload.accept_all_above is not None:
        # per cell: the newest document's figure (restatements win), then the most confident
        docs = list(session.exec(select(Document).where(Document.deal_id == deal_id)).all())
        all_items = list(items.values())
        recency = docs_service.document_recency(all_items, docs)
        to_accept += list(docs_service.best_per_cell(all_items, recency, minimum=payload.accept_all_above).values())
    for action in payload.actions:
        target = items.get(action.item_id)
        if target is None:
            raise HTTPException(status_code=404, detail=f"Review item {action.item_id} not found")
        if action.action == "reject":
            to_reject.append(target)
        else:
            if action.action == "edit":
                if action.value is None or not (action.reason or "").strip():
                    raise HTTPException(status_code=422, detail="An edited value needs the new value and a reason.")
                edited[action.item_id] = (action.value, action.reason or "")
            to_accept.append(target)
    if to_reject:
        docs_service.reject_items(session, to_reject)
    counts: dict[str, int] = {}
    if to_accept:
        counts = docs_service.accept_items(session, deal, to_accept, edited=edited)
    audit.record(
        session,
        "extraction_reviewed",
        deal_id=deal_id,
        detail={"accepted": len(to_accept), "edited": len(edited), "rejected": len(to_reject)},
    )
    deal.updated_at = utcnow()
    session.add(deal)
    session.commit()
    return {"counts": counts, **docs_service.review_payload(session, deal)}


class MapRowIn(BaseModel):
    document_id: str
    row_id: int
    concept_id: str


@router.post("/review/map-row")
def map_row(deal_id: str, payload: MapRowIn, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    doc = _document(session, deal_id, payload.document_id)
    if not load_taxonomy().has(payload.concept_id):
        raise HTTPException(status_code=422, detail="Unknown line item.")
    try:
        docs_service.map_unmapped_row(session, doc, payload.row_id, payload.concept_id)
    except ValueError as error:
        raise HTTPException(status_code=409, detail=str(error)) from error
    return docs_service.review_payload(session, deal)
