"""Health, app metadata, reference data, taxonomy and jobs."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session

from dealscout_engine.taxonomy import load_taxonomy

from .. import __version__
from ..db import get_session
from ..deps import job_runner
from ..jobs import JobRunner
from ..models import Job
from ..services.reference import disclaimers, reference_data

router = APIRouter(prefix="/api", tags=["meta"])


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "version": __version__}


@router.get("/meta")
def meta() -> dict[str, Any]:
    taxonomy = load_taxonomy()
    return {
        "version": __version__,
        "disclaimers": disclaimers(),
        "reference": reference_data(),
        "taxonomy_version": taxonomy.version,
    }


@router.get("/taxonomy")
def taxonomy() -> dict[str, Any]:
    tax = load_taxonomy()
    return {
        "version": tax.version,
        "statements": tax.statements,
        "concepts": [
            c.model_dump(
                include={
                    "id",
                    "name",
                    "statement",
                    "definition",
                    "sign",
                    "unit",
                    "aggregation",
                    "components",
                    "formula",
                    "period_type",
                }
            )
            for c in tax.concepts
        ],
    }


@router.get("/jobs/{job_id}")
def get_job(job_id: str, session: Session = Depends(get_session)) -> Job:
    job = session.get(Job, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.post("/jobs/{job_id}/resume", status_code=202)
def resume_job(job_id: str, runner: JobRunner = Depends(job_runner)) -> dict[str, str]:
    runner.resume(job_id)
    return {"status": "queued"}
