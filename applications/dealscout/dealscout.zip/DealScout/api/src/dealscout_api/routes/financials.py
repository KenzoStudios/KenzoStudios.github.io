"""Financial statement entry: grid, cell edits with history, periods, paste import, analysis."""

from __future__ import annotations

import re
from datetime import date
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Response, UploadFile
from pydantic import BaseModel, Field
from sqlmodel import Session, select

from dealscout_engine.capital import capital_structure
from dealscout_engine.ratios import cagr, compute_ratios
from dealscout_engine.scores import (
    adjusted_metrics,
    altman_variant,
    altman_z,
    beneish_m,
    market_capitalisation,
    piotroski_f,
    red_flags,
)
from dealscout_engine.sector_kpis import SECTOR_KPI_TEMPLATES, compute_sector_kpis
from dealscout_engine.taxonomy import load_taxonomy
from dealscout_extraction.paste import parse_pasted_table

from ..config import get_settings
from ..db import get_session
from ..models import Deal, FinancialValue, Period, utcnow
from ..services import audit
from ..services import financials as fin
from ..services import fx as fx_service
from ..services.methods import load_methods
from ..services.reference import disclaimers
from ..services.text_signals import document_red_flags

router = APIRouter(prefix="/api/deals/{deal_id}", tags=["financials"])


def _deal(session: Session, deal_id: str) -> Deal:
    deal = session.get(Deal, deal_id)
    if deal is None:
        raise HTTPException(status_code=404, detail="Deal not found")
    return deal


@router.get("/financials")
def get_financials(deal_id: str, session: Session = Depends(get_session)) -> dict[str, Any]:
    return fin.grid_payload(session, _deal(session, deal_id))


class CellsIn(BaseModel):
    changes: list[fin.CellChange] = Field(max_length=5000)
    source: Literal["manual", "paste", "template"] = "manual"


@router.put("/financials/cells")
def put_cells(deal_id: str, payload: CellsIn, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    try:
        # provenance and confidence are set only by the review flow, never by a client
        changes = [c.model_copy(update={"provenance": None, "confidence": None}) for c in payload.changes]
        counts = fin.apply_changes(session, deal, changes, source=payload.source)
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    return {"counts": counts, **fin.grid_payload(session, deal)}


@router.get("/financials/history")
def history(deal_id: str, concept_id: str, period_key: str, session: Session = Depends(get_session)) -> list[Any]:
    _deal(session, deal_id)
    return [h.model_dump(mode="json") for h in fin.value_history(session, deal_id, concept_id, period_key)]


class EntrySettingsIn(BaseModel):
    scale: Literal[1, 1000, 1000000, 1000000000] | None = None
    decimal_hint: Literal[".", ","] | None = None
    fiscal_year_end: str | None = Field(default=None, pattern=r"^(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$")


@router.patch("/financials/entry")
def patch_entry(deal_id: str, payload: EntrySettingsIn, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    doc = fin.assumptions_doc(session, deal_id)
    doc.entry = {**fin.entry_settings(session, deal_id), **payload.model_dump(exclude_unset=True)}
    doc.updated_at = utcnow()
    session.add(doc)
    session.commit()
    return fin.grid_payload(session, deal)


_PERIOD_KEY = re.compile(r"^(FY\d{4}|H[12]-\d{4}|Q[1-4]-\d{4}|9M-\d{4}|6M-\d{4}|3M-\d{4}|LTM-\d{4}-\d{2})$")


class PeriodIn(BaseModel):
    key: str = Field(max_length=20)
    kind: Literal["annual", "half_year", "quarter", "ytd", "ltm"] = "annual"
    end_date: date | None = None


@router.post("/periods", status_code=201)
def add_period(deal_id: str, payload: PeriodIn, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    fin.ensure_periods(session, deal)  # a fresh deal keeps its default annual columns
    key = payload.key.strip().upper()
    if not _PERIOD_KEY.match(key):
        raise HTTPException(status_code=422, detail="Use a period like FY2025, H1-2026, Q3-2025 or 9M-2026.")
    if session.exec(select(Period).where(Period.deal_id == deal_id, Period.key == key)).first():
        raise HTTPException(status_code=409, detail=f"Period {key} already exists.")
    year = int(re.findall(r"\d{4}", key)[0])
    end = payload.end_date
    if end is None and payload.kind == "annual":
        end = fin._fy_end(year, fin.entry_settings(session, deal_id)["fiscal_year_end"])
    session.add(Period(deal_id=deal_id, key=key, kind=payload.kind, fiscal_year=year, end_date=end, label=key))
    audit.record(session, "period_added", deal_id=deal_id, detail={"period": key})
    session.commit()
    return fin.grid_payload(session, deal)


@router.delete("/periods/{period_key}")
def delete_period(deal_id: str, period_key: str, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    period = session.exec(select(Period).where(Period.deal_id == deal_id, Period.key == period_key)).first()
    if period is None:
        raise HTTPException(status_code=404, detail="Period not found")
    values = session.exec(
        select(FinancialValue).where(FinancialValue.deal_id == deal_id, FinancialValue.period_key == period_key)
    ).all()
    if values:
        fin.apply_changes(
            session,
            deal,
            [
                fin.CellChange(concept_id=v.concept_id, period_key=period_key, value=None, reason="Period removed")
                for v in values
            ],
        )
    session.delete(period)
    audit.record(session, "period_removed", deal_id=deal_id, detail={"period": period_key, "values": len(values)})
    session.commit()
    return fin.grid_payload(session, deal)


class PasteIn(BaseModel):
    text: str = Field(max_length=500_000)
    decimal_hint: Literal[".", ","] | None = None


@router.post("/financials/paste")
def paste_preview(deal_id: str, payload: PasteIn, session: Session = Depends(get_session)) -> dict[str, Any]:
    _deal(session, deal_id)
    taxonomy = load_taxonomy()
    preview = parse_pasted_table(payload.text, taxonomy, decimal_hint=payload.decimal_hint)
    return {
        "periods": [{"key": p.key, "kind": p.kind, "raw": p.raw} for p in preview.periods],
        "scale": None
        if preview.scale is None
        else {"factor": preview.scale.factor, "label": preview.scale.label, "matched": preview.scale.matched},
        "rows": [
            {
                "label": r.label,
                "values": r.values,
                "concept_id": r.concept_id,
                "ambiguous_numbers": r.ambiguous_numbers,
                "candidates": [{"id": c, "name": taxonomy.concept(c).name} for c in r.candidates],
            }
            for r in preview.rows
        ],
        "unmatched": preview.unmatched,
        "warnings": preview.warnings,
        "concepts": [
            {"id": c.id, "name": c.name, "statement": c.statement}
            for c in taxonomy.concepts
            if c.unit not in ("schedule",)
        ],
    }


@router.get("/analysis")
def analysis(deal_id: str, session: Session = Depends(get_session)) -> dict[str, Any]:
    deal = _deal(session, deal_id)
    periods = fin.ensure_periods(session, deal)
    annual = fin.annual_periods(periods)
    native = fin.financial_data(session, deal_id)
    record = fin.assumptions_doc(session, deal_id)
    native_adjustments = load_methods(record.methods).normalisation.adjustments
    # analysis currency (brief §7): converted at the rates entered; with a rate missing, shown as reported and said so
    conversion = fx_service.convert_deal(deal, native, native_adjustments, fx_service.load_fx(record.fx))
    data = conversion.data if conversion.complete else native
    adjustments = conversion.adjustments if conversion.complete else native_adjustments
    fx_status = conversion.summary()
    if not conversion.complete:
        fx_status["message"] = (
            f"{conversion.message('The analysis')} Until then the figures are shown in {deal.reporting_currency}."
        )
    keys = [p.key for p in annual]
    ratios = compute_ratios(data, keys, prior_period=fin.prior_map(periods))
    revenue = [(p.key, data.get("revenue", p.key)) for p in annual]
    revenue = [(k, v) for k, v in revenue if v is not None]
    revenue_cagr = cagr(revenue[0][1], revenue[-1][1], len(revenue) - 1) if len(revenue) >= 2 else None
    series = {c: {k: data.get(c, k) for k in keys} for c in ("revenue", "ebitda", "ebit", "net_income", "cfo", "capex")}
    overrides = record.overrides or {}
    # scores for the latest year that has a prior year; market cap only for listed deals (Altman's X4)
    latest = keys[-1] if keys else None
    prior = fin.prior_map(periods).get(latest) if latest else None
    variant = altman_variant(listed=deal.listed, sector=deal.sector)
    scores = []
    if latest:
        market_cap = (
            market_capitalisation(
                data, latest, share_price=overrides.get("share_price"), shares=overrides.get("basic_shares")
            )
            if deal.listed
            else None
        )
        scores.append(altman_z(data, latest, variant, market_cap=market_cap).model_dump())
        if prior:
            scores += [piotroski_f(data, latest, prior).model_dump(), beneish_m(data, latest, prior).model_dump()]
    text_flags, scanned = document_red_flags(session, get_settings(), deal_id, keys)
    template = fin.effective_template(deal)
    return {
        "periods": keys,
        "currency": conversion.currency,
        "fx": fx_status,
        "ratios": [r.model_dump() for r in ratios],
        "series": series,
        "scores": {"period": latest, "prior": prior, "items": scores},
        "red_flags": [f.model_dump() for f in [*red_flags(data, keys, adjustments=adjustments), *text_flags]],
        "documents_scanned": scanned,
        "sector_kpis": {
            "template": template,
            "label": SECTOR_KPI_TEMPLATES.get(template),
            "items": [
                k.model_dump() for k in compute_sector_kpis(data, keys, template, prior_period=fin.prior_map(periods))
            ],
        },
        "adjusted": [adjusted_metrics(data, k, adjustments).model_dump() for k in keys],
        "capital_structure": [capital_structure(data, k).model_dump() for k in keys],
        "breakdowns": load_methods(record.methods).breakdowns.model_dump(),
        "revenue_cagr": {
            "value": revenue_cagr,
            "from": revenue[0][0] if revenue else None,
            "to": revenue[-1][0] if revenue else None,
        },
        "disclaimer": disclaimers()["short"],
    }


# ── Excel entry template ──────────────────────────────────────────────────────
TEMPLATE_MAX_BYTES = 10 * 1024 * 1024


@router.get("/template.xlsx")
def download_template(deal_id: str, session: Session = Depends(get_session)) -> Response:
    from ..services.entry_template import build_entry_template

    deal = _deal(session, deal_id)
    periods = fin.ensure_periods(session, deal)
    content = build_entry_template(
        deal, fin.annual_periods(periods) or periods, fin.entry_settings(session, deal_id)["scale"]
    )
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", deal.name)[:60] or "deal"
    audit.record(session, "template_downloaded", deal_id=deal_id)
    session.commit()
    return Response(
        content,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="DealScout_entry_{safe}.xlsx"'},
    )


@router.post("/template")
async def upload_template(
    deal_id: str, file: UploadFile, apply: bool = False, session: Session = Depends(get_session)
) -> dict[str, Any]:
    from dealscout_extraction.template import read_entry_template

    deal = _deal(session, deal_id)
    if not (file.filename or "").lower().endswith(".xlsx"):
        raise HTTPException(status_code=415, detail="Upload the filled-in template as an .xlsx file.")
    content = await file.read(TEMPLATE_MAX_BYTES + 1)
    if len(content) > TEMPLATE_MAX_BYTES:
        raise HTTPException(status_code=413, detail="The template is larger than 10 MB.")
    try:
        parsed = read_entry_template(content, load_taxonomy())
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    warnings = list(parsed.warnings)
    if parsed.deal_id and parsed.deal_id != deal_id:
        warnings.insert(0, "This template was downloaded for a different deal. Check before importing.")
    existing = {p.key for p in fin.ensure_periods(session, deal)}
    new_periods = [k for k in parsed.periods if k not in existing]
    preview = {
        "units": parsed.scale_label,
        "cells": len(parsed.cells),
        "periods": parsed.periods,
        "new_periods": new_periods,
        "warnings": warnings,
        "sample": [
            {"concept_id": c.concept_id, "period_key": c.period_key, "value": c.value, "cell": f"{c.sheet}!{c.cell}"}
            for c in parsed.cells[:20]
        ],
    }
    if not apply:
        return {"applied": False, **preview}
    for key in new_periods:
        year = int(re.findall(r"\d{4}", key)[0])
        kind = (
            "annual"
            if key.startswith("FY")
            else "half_year"
            if key.startswith("H")
            else "quarter"
            if key.startswith("Q")
            else "ytd"
        )
        end = fin._fy_end(year, fin.entry_settings(session, deal_id)["fiscal_year_end"]) if kind == "annual" else None
        session.add(Period(deal_id=deal_id, key=key, kind=kind, fiscal_year=year, end_date=end, label=key))
    session.commit()
    counts = fin.apply_changes(
        session,
        deal,
        [
            fin.CellChange(
                concept_id=c.concept_id,
                period_key=c.period_key,
                value=c.value,
                entered_text=c.entered_text,
                reason=f"Excel template {file.filename}",
            )
            for c in parsed.cells
        ],
        source="template",
    )
    audit.record(session, "template_uploaded", deal_id=deal_id, detail={"file": file.filename, **counts})
    session.commit()
    return {"applied": True, "counts": counts, **preview}
