"""User preferences, local data folder and AI connections ("Connect AI")."""

from __future__ import annotations

import os
import subprocess
import sys
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select as sa_select
from sqlmodel import Session, col, func, select

from dealscout_ai import ConnectionResult, ModelInfo, get_spec

from ..config import get_settings
from ..db import get_session
from ..deps import ai_service
from ..models import AIUsage
from ..services import audit
from ..services.ai_service import AIService
from ..services.app_settings import load_preferences, save_preferences

router = APIRouter(prefix="/api", tags=["settings"])


@router.get("/settings")
def get_preferences(session: Session = Depends(get_session), ai: AIService = Depends(ai_service)) -> dict[str, Any]:
    settings = get_settings()
    return {
        "preferences": load_preferences(session).model_dump(),
        "data_folder": str(settings.data_dir),
        "key_storage": ai.keystore.describe(),
        "env": {"disable_ai": settings.disable_ai, "max_upload_mb": settings.max_upload_mb},
    }


@router.patch("/settings")
def patch_preferences(changes: dict[str, Any], session: Session = Depends(get_session)) -> dict[str, Any]:
    try:
        prefs = save_preferences(session, changes)
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    return prefs.model_dump()


@router.post("/settings/open-data-folder", status_code=204)
def open_data_folder() -> None:
    folder = str(get_settings().data_dir)
    if sys.platform == "darwin":
        subprocess.Popen(["open", folder])
    elif sys.platform == "win32":
        os.startfile(folder)  # type: ignore[attr-defined]
    else:
        subprocess.Popen(["xdg-open", folder])


# ── AI connections ──────────────────────────────────────────────────────
class ConnectionIn(BaseModel):
    model: str | None = Field(default=None, max_length=120)
    api_key: str | None = Field(default=None, max_length=500)
    base_url: str | None = Field(default=None, max_length=500, pattern=r"^https?://\S+$")
    endpoint: str | None = Field(default=None, max_length=500, pattern=r"^https://\S+$")
    deployment: str | None = Field(default=None, max_length=200, pattern=r"^[A-Za-z0-9._-]+$")
    api_version: str | None = Field(default=None, max_length=40)
    activate: bool = True


@router.get("/ai/providers")
def providers(session: Session = Depends(get_session), ai: AIService = Depends(ai_service)) -> dict[str, Any]:
    return {
        "providers": ai.provider_states(session),
        "status": ai.status(session),
        "key_storage": ai.keystore.describe(),
    }


@router.get("/ai/status")
def ai_status(session: Session = Depends(get_session), ai: AIService = Depends(ai_service)) -> dict[str, Any]:
    return ai.status(session)


@router.put("/ai/connections/{provider}")
def save_connection(
    provider: str, payload: ConnectionIn, session: Session = Depends(get_session), ai: AIService = Depends(ai_service)
) -> dict[str, Any]:
    try:
        fields = set(get_spec(provider).fields)
        for name in ("base_url", "endpoint", "deployment", "api_version"):
            if getattr(payload, name) and name not in fields:
                # first-party providers have fixed addresses: never redirect a stored key elsewhere
                raise HTTPException(status_code=422, detail=f"{name} cannot be set for this provider.")
        ai.save_connection(session, provider, **payload.model_dump())
    except KeyError as error:
        raise HTTPException(status_code=404, detail=str(error)) from error
    except NotImplementedError as error:
        raise HTTPException(status_code=409, detail=str(error)) from error
    audit.record(
        session,
        "ai_connection_saved",
        detail={"provider": provider, "model": payload.model, "key_changed": bool(payload.api_key)},
    )
    session.commit()
    return {"providers": ai.provider_states(session), "status": ai.status(session)}


@router.post("/ai/connections/{provider}/activate")
def activate(
    provider: str, session: Session = Depends(get_session), ai: AIService = Depends(ai_service)
) -> dict[str, Any]:
    ai.activate(session, provider)
    return ai.status(session)


@router.post("/ai/connections/{provider}/test")
def test_connection(
    provider: str, session: Session = Depends(get_session), ai: AIService = Depends(ai_service)
) -> ConnectionResult:
    return ai.test(session, provider)


@router.get("/ai/connections/{provider}/models")
def models(
    provider: str, session: Session = Depends(get_session), ai: AIService = Depends(ai_service)
) -> list[ModelInfo]:
    return ai.list_models(session, provider)


@router.delete("/ai/connections/{provider}/key", status_code=204)
def remove_key(provider: str, session: Session = Depends(get_session), ai: AIService = Depends(ai_service)) -> None:
    ai.remove_key(provider)
    audit.record(session, "ai_key_removed", detail={"provider": provider})
    session.commit()


@router.delete("/ai/connections/{provider}", status_code=204)
def delete_connection(
    provider: str, session: Session = Depends(get_session), ai: AIService = Depends(ai_service)
) -> None:
    ai.delete_connection(session, provider)
    audit.record(session, "ai_connection_removed", detail={"provider": provider})
    session.commit()


@router.get("/ai/usage")
def usage(deal_id: str | None = None, session: Session = Depends(get_session)) -> dict[str, Any]:
    stmt = sa_select(
        col(AIUsage.provider),
        col(AIUsage.model),
        col(AIUsage.purpose),
        func.count(),
        func.sum(col(AIUsage.input_tokens)),
        func.sum(col(AIUsage.output_tokens)),
        func.sum(col(AIUsage.estimated_cost_usd)),
    ).group_by(col(AIUsage.provider), col(AIUsage.model), col(AIUsage.purpose))
    if deal_id:
        stmt = stmt.where(col(AIUsage.deal_id) == deal_id)
    rows = session.execute(stmt).all()
    recent_stmt = select(AIUsage).order_by(col(AIUsage.at).desc()).limit(50)
    if deal_id:
        recent_stmt = recent_stmt.where(AIUsage.deal_id == deal_id)
    return {
        "summary": [
            {
                "provider": p,
                "model": m,
                "purpose": pu,
                "calls": n,
                "input_tokens": i or 0,
                "output_tokens": o or 0,
                "estimated_cost_usd": c,
            }
            for p, m, pu, n, i, o, c in rows
        ],
        "recent": [u.model_dump() for u in session.exec(recent_stmt).all()],
    }
