"""Peer sourcing: AI-suggested peer names and the market data connectors (manual / CSV import)."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Response, UploadFile
from sqlmodel import Session

from ..db import get_session
from ..deps import ai_service
from ..models import Deal
from ..services import audit, market_data
from ..services import financials as fin
from ..services import peer_suggestions as ps
from ..services.ai_service import AIService
from ..services.reference import reference_data

router = APIRouter(prefix="/api", tags=["peers"])

SCALES = {1.0, 1e3, 1e6, 1e9}


def _deal(session: Session, deal_id: str) -> Deal:
    deal = session.get(Deal, deal_id)
    if deal is None:
        raise HTTPException(status_code=404, detail="Deal not found")
    return deal


def _existing(session: Session, deal_id: str) -> list[str]:
    peers = fin.assumptions_doc(session, deal_id).peers or []
    names = [str(p.get("name")) for p in peers if p.get("name")]
    return names + [str(p.get("ticker")) for p in peers if p.get("ticker")]


@router.get("/market-data/providers")
def list_providers() -> list[dict[str, Any]]:
    return [
        {
            "id": p.id,
            "label": p.label,
            "description": p.description,
            "requires_key": p.requires_key,
            "enabled": p.enabled_by_default,
            "built_in": p.built_in,
        }
        for p in market_data.providers()
    ]


@router.get("/market-data/peers-template.csv")
def peers_template() -> Response:
    return Response(
        market_data.csv_template(),
        media_type="text/csv",
        headers={"Content-Disposition": 'attachment; filename="DealScout_peers_template.csv"'},
    )


@router.post("/deals/{deal_id}/peers/import")
async def import_peers_csv(
    deal_id: str,
    file: UploadFile,
    scale: float = Query(default=1.0),
    session: Session = Depends(get_session),
) -> dict[str, Any]:
    """Validate a peer CSV and return the peers to add. Nothing is saved until the analyst saves the peer list."""
    _deal(session, deal_id)
    if scale not in SCALES:
        raise HTTPException(status_code=422, detail="Scale must be 1, 1e3, 1e6 or 1e9.")
    if not (file.filename or "").lower().endswith((".csv", ".txt")):
        raise HTTPException(status_code=415, detail="Upload the peers as a .csv file.")
    content = await file.read(market_data.MAX_CSV_BYTES + 1)
    try:
        result = market_data.parse_peer_csv(content, scale=scale, existing=set(_existing(session, deal_id)))
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    audit.record(
        session,
        "peers_csv_checked",
        deal_id=deal_id,
        detail={"file": file.filename, "valid": len(result.peers), "invalid": len(result.errors)},
    )
    session.commit()
    return {"provider": "csv", **result.model_dump(mode="json")}


@router.post("/deals/{deal_id}/peers/suggest")
def suggest_peers(
    deal_id: str, session: Session = Depends(get_session), ai: AIService = Depends(ai_service)
) -> dict[str, Any]:
    """AI-suggested listed peers: names only, no figures, to verify before use."""
    deal = _deal(session, deal_id)
    provider = ai.provider_for(session)  # 409 when no AI is connected or AI is turned off
    existing = _existing(session, deal_id)
    sector = next((s for s in reference_data()["sectors"] if s["id"] == deal.sector), None)
    brief = ps.deal_brief(deal, sector["name"] if sector else None, existing)
    suggestions, dropped, usage = ps.ai_peer_suggestions(provider, brief, existing)
    ai.record_usage(session, usage, purpose="peer_suggestions", deal_id=deal_id, prompt_version=ps.PROMPT_VERSION)
    audit.record(session, "peers_suggested", deal_id=deal_id, detail={"count": len(suggestions), "dropped": dropped})
    session.commit()
    return {
        "suggestions": [s.model_dump() for s in suggestions],
        "source": f"{provider.provider_id} · {provider.model}",
        "generated_at": ps.generated_at(),
        "reasons_dropped": dropped,
        "note": "AI suggestions to verify: check each company is listed and comparable, then enter its figures "
        "from a source you trust.",
    }
