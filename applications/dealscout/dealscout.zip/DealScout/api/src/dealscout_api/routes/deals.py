"""Deal CRUD, duplication, hard delete and audit log."""

from __future__ import annotations

import shutil
from datetime import date
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field, field_validator, model_validator
from sqlmodel import Session, col, delete, or_, select

from ..config import get_settings
from ..db import get_session
from ..models import (
    AIUsage,
    AuditEvent,
    Deal,
    DealAssumptions,
    DealVersion,
    Document,
    ExtractedItem,
    FinancialValue,
    Job,
    Period,
    ValueChange,
    utcnow,
)
from ..services import audit
from ..services.reference import reference_data, sector_template

router = APIRouter(prefix="/api/deals", tags=["deals"])

Perspective = Literal["financial_sponsor", "strategic"]
Mode = Literal["quick", "detailed"]


def _codes(kind: str) -> set[str]:
    return {item["code"] for item in reference_data()[kind]}


class DealBase(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    country: str = Field(min_length=2, max_length=2)
    sector: str
    industry: str | None = Field(default=None, max_length=120)
    listed: bool = False
    ticker: str | None = Field(default=None, max_length=30)
    reporting_currency: str = Field(min_length=3, max_length=3)
    analysis_currency: str | None = Field(default=None, min_length=3, max_length=3)
    valuation_date: date | None = None
    perspective: Perspective = "financial_sponsor"
    mode: Mode = "quick"
    notes: str | None = Field(default=None, max_length=5000)

    @field_validator("name")
    @classmethod
    def _strip(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("name is required")
        return value

    @field_validator("country", "reporting_currency", "analysis_currency")
    @classmethod
    def _upper(cls, value: str | None) -> str | None:
        return value.upper() if value else value

    @model_validator(mode="after")
    def _check_reference(self) -> DealBase:
        if self.country not in _codes("countries"):
            raise ValueError(f"unknown country {self.country}")
        if self.reporting_currency not in _codes("currencies"):
            raise ValueError(f"unknown currency {self.reporting_currency}")
        if self.analysis_currency and self.analysis_currency not in _codes("currencies"):
            raise ValueError(f"unknown currency {self.analysis_currency}")
        if self.sector not in {s["id"] for s in reference_data()["sectors"]}:
            raise ValueError(f"unknown sector {self.sector}")
        if self.ticker:
            self.ticker = self.ticker.strip().upper() or None
        if not self.listed:
            self.ticker = None
        return self


class DealCreate(DealBase):
    pass


class DealUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    country: str | None = None
    sector: str | None = None
    industry: str | None = None
    listed: bool | None = None
    ticker: str | None = None
    reporting_currency: str | None = None
    analysis_currency: str | None = None
    valuation_date: date | None = None
    perspective: Perspective | None = None
    mode: Mode | None = None
    notes: str | None = None
    archived: bool | None = None


def _to_read(deal: Deal) -> dict[str, object]:
    countries = {c["code"]: c["name"] for c in reference_data()["countries"]}
    sectors = {s["id"]: s["name"] for s in reference_data()["sectors"]}
    data = deal.model_dump()
    data["country_name"] = countries.get(deal.country, deal.country)
    data["sector_name"] = sectors.get(deal.sector, deal.sector)
    return data


def _display(value: object) -> str:
    if value is None or value == "":
        return "—"
    if isinstance(value, bool):
        return "Yes" if value else "No"
    return str(value)


def _get(session: Session, deal_id: str) -> Deal:
    deal = session.get(Deal, deal_id)
    if deal is None:
        raise HTTPException(status_code=404, detail="Deal not found")
    return deal


@router.get("")
def list_deals(
    q: str | None = None,
    sector: str | None = None,
    country: str | None = None,
    listed: bool | None = None,
    archived: bool = False,
    sort: Literal["updated", "name", "created"] = "updated",
    session: Session = Depends(get_session),
) -> dict[str, object]:
    stmt = select(Deal).where(Deal.archived == archived)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(or_(col(Deal.name).ilike(like), col(Deal.ticker).ilike(like), col(Deal.industry).ilike(like)))
    if sector:
        stmt = stmt.where(Deal.sector == sector)
    if country:
        stmt = stmt.where(Deal.country == country.upper())
    if listed is not None:
        stmt = stmt.where(Deal.listed == listed)
    order: dict[str, Any] = {
        "updated": col(Deal.updated_at).desc(),
        "name": col(Deal.name).asc(),
        "created": col(Deal.created_at).desc(),
    }
    deals = session.exec(stmt.order_by(order[sort])).all()
    return {"items": [_to_read(d) for d in deals], "total": len(deals)}


@router.post("", status_code=status.HTTP_201_CREATED)
def create_deal(payload: DealCreate, session: Session = Depends(get_session)) -> dict[str, object]:
    data = payload.model_dump()
    data["analysis_currency"] = data["analysis_currency"] or data["reporting_currency"]
    data["valuation_date"] = data["valuation_date"] or date.today()
    deal = Deal(**data, sector_template=sector_template(payload.sector))
    session.add(deal)
    audit.record(session, "deal_created", deal_id=deal.id, detail={"name": deal.name})
    session.commit()
    session.refresh(deal)
    return _to_read(deal)


@router.get("/{deal_id}")
def get_deal(deal_id: str, session: Session = Depends(get_session)) -> dict[str, object]:
    return _to_read(_get(session, deal_id))


@router.patch("/{deal_id}")
def update_deal(deal_id: str, payload: DealUpdate, session: Session = Depends(get_session)) -> dict[str, object]:
    deal = _get(session, deal_id)
    changes = payload.model_dump(exclude_unset=True)
    merged = {**deal.model_dump(), **changes}
    validated = DealBase.model_validate({k: merged[k] for k in DealBase.model_fields if k in merged})
    diff: dict[str, dict[str, str]] = {}
    for key in changes:
        value = getattr(validated, key) if key in DealBase.model_fields else changes[key]
        old_value = getattr(deal, key)
        if old_value != value:
            diff[key] = {"old": _display(old_value), "new": _display(value)}
            setattr(deal, key, value)
    if not diff:
        return _to_read(deal)  # nothing changed: no write, no audit entry
    if "sector" in diff:
        deal.sector_template = sector_template(deal.sector)
    deal.updated_at = utcnow()
    session.add(deal)
    audit.record(session, "deal_updated", deal_id=deal.id, detail={"changes": diff})
    session.commit()
    session.refresh(deal)
    return _to_read(deal)


@router.post("/{deal_id}/duplicate", status_code=status.HTTP_201_CREATED)
def duplicate_deal(deal_id: str, session: Session = Depends(get_session)) -> dict[str, object]:
    source = _get(session, deal_id)
    data = source.model_dump(exclude={"id", "created_at", "updated_at"})
    data["name"] = f"{source.name} (copy)"[:200]
    copy = Deal(**data)
    session.add(copy)
    # copy the data so the duplicate can be used to test alternative assumptions
    for period in session.exec(select(Period).where(Period.deal_id == deal_id)).all():
        session.add(Period(**period.model_dump(exclude={"id", "deal_id"}), deal_id=copy.id))
    for value in session.exec(select(FinancialValue).where(FinancialValue.deal_id == deal_id)).all():
        session.add(FinancialValue(**value.model_dump(exclude={"id", "deal_id"}), deal_id=copy.id))
    source_doc = session.get(DealAssumptions, deal_id)
    if source_doc is not None:
        session.add(DealAssumptions(**source_doc.model_dump(exclude={"deal_id"}), deal_id=copy.id))
    audit.record(session, "deal_duplicated", deal_id=copy.id, detail={"from": source.id, "from_name": source.name})
    session.commit()
    session.refresh(copy)
    return _to_read(copy)


@router.delete("/{deal_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_deal(deal_id: str, session: Session = Depends(get_session)) -> None:
    """Hard delete: the deal, its documents, jobs, usage rows and its own audit events are removed."""
    deal = _get(session, deal_id)
    name = deal.name
    for model in (
        AuditEvent,
        AIUsage,
        Job,
        FinancialValue,
        ValueChange,
        Period,
        DealAssumptions,
        DealVersion,
        ExtractedItem,
        Document,
    ):
        session.exec(delete(model).where(col(model.deal_id) == deal_id))
    session.delete(deal)
    audit.record(session, "deal_deleted", detail={"deal_id": deal_id, "name": name})
    session.commit()
    folder = get_settings().deal_folder(deal_id)
    if folder.exists():
        shutil.rmtree(folder, ignore_errors=True)


@router.get("/{deal_id}/audit")
def deal_audit(
    deal_id: str, limit: int = Query(200, le=1000), session: Session = Depends(get_session)
) -> list[AuditEvent]:
    _get(session, deal_id)
    stmt = select(AuditEvent).where(AuditEvent.deal_id == deal_id).order_by(col(AuditEvent.at).desc()).limit(limit)
    return list(session.exec(stmt).all())
