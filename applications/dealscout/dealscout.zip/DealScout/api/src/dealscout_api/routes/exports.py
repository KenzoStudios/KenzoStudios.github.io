"""Exports (brief §14, §14A): Excel workbook, PDF tear sheet, PowerPoint one-pager, and JSON export / import."""

from __future__ import annotations

import json
import re
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy.exc import SQLAlchemyError
from sqlmodel import Session

from ..db import get_session
from ..exports import deal_json
from ..exports.context import build_context
from ..exports.pdf import build_pdf
from ..exports.pptx import build_pptx
from ..exports.quality import check_workbook
from ..exports.workbook import build_workbook
from ..models import Deal
from ..services import audit

router = APIRouter(prefix="/api/deals/{deal_id}/export", tags=["exports"])

XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
PPTX = "application/vnd.openxmlformats-officedocument.presentationml.presentation"


def _deal(session: Session, deal_id: str) -> Deal:
    deal = session.get(Deal, deal_id)
    if deal is None:
        raise HTTPException(status_code=404, detail="Deal not found")
    return deal


def filename(deal: Deal, suffix: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9]+", "_", deal.name).strip("_")[:60] or "deal"
    return f"DealScout_{safe}_{deal.valuation_date:%Y%m%d}.{suffix}"


def _download(content: bytes, media: str, name: str, extra: dict[str, str] | None = None) -> Response:
    headers = {"Content-Disposition": f'attachment; filename="{name}"', "Cache-Control": "no-store", **(extra or {})}
    return Response(content=content, media_type=media, headers=headers)


@router.get("/xlsx")
def export_xlsx(deal_id: str, session: Session = Depends(get_session)) -> Response:
    deal = _deal(session, deal_id)
    ctx = build_context(session, deal)
    content = build_workbook(ctx)
    quality = check_workbook(
        content, footer=ctx.disclaimers["print_footer"], notice=ctx.disclaimers["ai_report_notice"]
    )
    if not quality.ok:
        # never offer a workbook that failed its checks
        raise HTTPException(
            status_code=500,
            detail="The workbook failed its checks: " + "; ".join((quality.errors + quality.problems)[:10]),
        )
    audit.record(
        session, "export_created", deal_id=deal_id, detail={"format": "xlsx", "recalculated": quality.recalculated}
    )
    session.commit()
    return _download(
        content, XLSX, filename(deal, "xlsx"), {"X-DealScout-Recalculated": "yes" if quality.recalculated else "no"}
    )


@router.get("/pdf")
def export_pdf(deal_id: str, session: Session = Depends(get_session)) -> Response:
    deal = _deal(session, deal_id)
    content = build_pdf(build_context(session, deal))
    audit.record(session, "export_created", deal_id=deal_id, detail={"format": "pdf"})
    session.commit()
    return _download(content, "application/pdf", filename(deal, "pdf"))


@router.get("/pptx")
def export_pptx(deal_id: str, session: Session = Depends(get_session)) -> Response:
    deal = _deal(session, deal_id)
    content = build_pptx(build_context(session, deal))
    audit.record(session, "export_created", deal_id=deal_id, detail={"format": "pptx"})
    session.commit()
    return _download(content, PPTX, filename(deal, "pptx"))


@router.get("/json")
def export_json(deal_id: str, session: Session = Depends(get_session)) -> Response:
    from .valuation import valuation

    deal = _deal(session, deal_id)
    body = deal_json.export_deal(session, deal, valuation(deal_id, session))
    audit.record(session, "export_created", deal_id=deal_id, detail={"format": "json"})
    session.commit()
    return _download(json.dumps(body, indent=2).encode(), "application/json", filename(deal, "json"))


import_router = APIRouter(prefix="/api/deals", tags=["exports"])


@import_router.post("/import", status_code=201)
def import_json(file: deal_json.DealFile, session: Session = Depends(get_session)) -> dict[str, Any]:
    from .valuation import valuation

    try:
        deal = deal_json.import_deal(session, file)
        audit.record(session, "deal_imported", deal_id=deal.id, detail={"exported_at": file.exported_at[:40]})
        session.commit()
    except (ValueError, TypeError, KeyError, SQLAlchemyError) as error:
        session.rollback()
        raise HTTPException(
            status_code=422, detail=f"The deal file could not be imported: {str(error)[:300]}"
        ) from error
    recomputed = deal_json.results_summary(valuation(deal.id, session))
    differences = deal_json.compare(file.results, recomputed)
    return {"id": deal.id, "name": deal.name, "reproduced": not differences, "differences": differences}
