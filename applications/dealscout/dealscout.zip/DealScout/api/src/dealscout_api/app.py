"""FastAPI application factory."""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from dealscout_ai import AIError, KeyStore

from . import __version__
from .config import Settings, get_settings
from .db import init_engine
from .jobs import JobRunner
from .routes import deals, documents, exports, financials, fx, meta, valuation, versions
from .routes import peers as peers_routes
from .routes import settings as settings_routes
from .security import LocalOnlyMiddleware
from .services.ai_service import AIService
from .static import mount_frontend

log = logging.getLogger("dealscout")

_AI_STATUS = {
    "not_connected": 409,
    "ai_disabled": 409,
    "spend_cap_reached": 402,
    "invalid_key": 401,
    "out_of_credit": 402,
    "model_unavailable": 404,
    "rate_limited": 429,
    "unreachable": 503,
}


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()
    settings.ensure_dirs()
    engine = init_engine(settings.db_path)

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        resumed = app.state.job_runner.resume_pending()
        if resumed:
            log.info("resumed %d interrupted job(s)", resumed)
        yield
        app.state.job_runner.shutdown()

    app = FastAPI(
        title="DealScout",
        version=__version__,
        lifespan=lifespan,
        # interactive API docs load scripts from a CDN into the app's origin: developer mode only
        docs_url="/api/docs" if settings.dev else None,
        openapi_url="/api/openapi.json" if settings.dev else None,
        redoc_url=None,
    )
    app.add_middleware(LocalOnlyMiddleware)
    app.state.settings = settings
    app.state.engine = engine
    app.state.ai_service = AIService(settings, KeyStore(settings.secrets_dir))
    app.state.job_runner = JobRunner(engine)
    from .services.documents import make_extract_handler
    from .services.normalisation import make_one_off_handler

    app.state.job_runner.register("extract_document", make_extract_handler(engine, settings, app.state.ai_service))
    app.state.job_runner.register("suggest_one_offs", make_one_off_handler(engine, settings, app.state.ai_service))

    @app.exception_handler(AIError)
    async def _ai_error(_: Request, error: AIError) -> JSONResponse:
        return JSONResponse(
            {"detail": error.message, "code": error.code, "retryable": error.retryable, "provider": error.provider},
            status_code=_AI_STATUS.get(error.code, 502),
        )

    app.include_router(meta.router)
    app.include_router(deals.router)
    app.include_router(financials.router)
    app.include_router(documents.router)
    app.include_router(valuation.router)
    app.include_router(fx.router)
    app.include_router(exports.router)
    app.include_router(exports.import_router)
    app.include_router(versions.router)
    app.include_router(settings_routes.router)
    app.include_router(peers_routes.router)
    mount_frontend(app, settings.web_dir)  # must be last: catch-all route
    return app
