"""SQLite tables (SQLModel). Every schema change needs an Alembic migration (see migrations/)."""

from __future__ import annotations

import uuid
from datetime import UTC, date, datetime
from typing import Any

from sqlalchemy import JSON, Column, UniqueConstraint
from sqlmodel import Field, SQLModel


def utcnow() -> datetime:
    return datetime.now(UTC)


def new_id() -> str:
    return uuid.uuid4().hex


class Deal(SQLModel, table=True):
    id: str = Field(default_factory=new_id, primary_key=True)
    name: str = Field(index=True, max_length=200)
    country: str = Field(max_length=2)
    sector: str = Field(max_length=60)
    industry: str | None = Field(default=None, max_length=120)
    listed: bool = False
    ticker: str | None = Field(default=None, max_length=30)
    reporting_currency: str = Field(max_length=3)
    analysis_currency: str = Field(max_length=3)
    valuation_date: date
    perspective: str = Field(default="financial_sponsor", max_length=20)  # financial_sponsor | strategic
    mode: str = Field(default="quick", max_length=10)  # quick | detailed
    status: str = Field(default="draft", max_length=20)
    sector_template: str = Field(default="general", max_length=20)
    notes: str | None = None
    archived: bool = False
    created_at: datetime = Field(default_factory=utcnow)
    updated_at: datetime = Field(default_factory=utcnow, index=True)


class AuditEvent(SQLModel, table=True):
    """Uploads, exports, overrides and other material actions, per deal (``deal_id`` null = app-level)."""

    id: int | None = Field(default=None, primary_key=True)
    deal_id: str | None = Field(default=None, index=True)
    action: str = Field(max_length=60)
    actor: str = Field(max_length=120)
    detail: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    at: datetime = Field(default_factory=utcnow, index=True)


class AppSetting(SQLModel, table=True):
    key: str = Field(primary_key=True, max_length=60)
    value: Any = Field(default=None, sa_column=Column(JSON))
    updated_at: datetime = Field(default_factory=utcnow)


class AIConnection(SQLModel, table=True):
    """Non-secret settings for a saved AI provider. The key itself lives in the OS keychain."""

    provider: str = Field(primary_key=True, max_length=30)
    model: str | None = Field(default=None, max_length=120)
    base_url: str | None = None
    endpoint: str | None = None
    deployment: str | None = None
    api_version: str | None = None
    is_active: bool = False
    is_writing: bool = False  # optional separate provider for summaries / rationale
    last_test_at: datetime | None = None
    last_test_code: str | None = Field(default=None, max_length=30)
    last_test_message: str | None = None
    created_at: datetime = Field(default_factory=utcnow)
    updated_at: datetime = Field(default_factory=utcnow)


class AIUsage(SQLModel, table=True):
    """One AI call: provider, model, tokens and estimated cost (never prompts' secrets, never keys)."""

    id: int | None = Field(default=None, primary_key=True)
    deal_id: str | None = Field(default=None, index=True)
    document_id: str | None = Field(default=None, index=True)
    purpose: str = Field(max_length=60)
    provider: str = Field(max_length=30)
    model: str = Field(max_length=120)
    prompt_version: str | None = Field(default=None, max_length=40)
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    estimated_cost_usd: float | None = None
    at: datetime = Field(default_factory=utcnow, index=True)


class Job(SQLModel, table=True):
    """A background job with per-step status. Jobs left ``running`` at shutdown resume on the next start."""

    id: str = Field(default_factory=new_id, primary_key=True)
    deal_id: str | None = Field(default=None, index=True)
    kind: str = Field(max_length=40)
    status: str = Field(default="queued", max_length=20)  # queued | running | paused | done | failed
    steps: list[dict[str, Any]] = Field(default_factory=list, sa_column=Column(JSON))
    payload: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    message: str | None = None
    error_code: str | None = Field(default=None, max_length=40)
    attempts: int = 0
    created_at: datetime = Field(default_factory=utcnow)
    updated_at: datetime = Field(default_factory=utcnow)


class Period(SQLModel, table=True):
    """A reporting period of a deal (FY2025, H1-2026, …). ``key`` is unique within the deal."""

    __table_args__ = (UniqueConstraint("deal_id", "key", name="uq_period_deal_key"),)
    id: str = Field(default_factory=new_id, primary_key=True)
    deal_id: str = Field(index=True)
    key: str = Field(max_length=20)
    kind: str = Field(default="annual", max_length=20)  # annual | half_year | quarter | ytd | ltm | projection
    fiscal_year: int | None = None
    end_date: date | None = None
    label: str | None = Field(default=None, max_length=40)
    sort_order: int = 0


class FinancialValue(SQLModel, table=True):
    """One number for (deal, concept, period), stored in absolute units of the reporting currency, signed per the
    taxonomy convention. Provenance says where it came from; every change is logged in ValueChange."""

    __table_args__ = (UniqueConstraint("deal_id", "period_key", "concept_id", name="uq_value_cell"),)
    id: int | None = Field(default=None, primary_key=True)
    deal_id: str = Field(index=True)
    period_key: str = Field(max_length=20)
    concept_id: str = Field(max_length=60)
    value: float
    source: str = Field(default="manual", max_length=20)  # manual | paste | template | extracted | xbrl
    entered_scale: float = 1.0
    entered_text: str | None = Field(default=None, max_length=120)
    currency: str | None = Field(default=None, max_length=3)
    confidence: float | None = None
    provenance: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    updated_by: str = Field(default="Analyst", max_length=120)
    updated_at: datetime = Field(default_factory=utcnow)


class ValueChange(SQLModel, table=True):
    """History of every change to a financial value (brief §2.4: who, when, old value, new value, reason)."""

    id: int | None = Field(default=None, primary_key=True)
    deal_id: str = Field(index=True)
    period_key: str = Field(max_length=20)
    concept_id: str = Field(max_length=60)
    old_value: float | None = None
    new_value: float | None = None
    old_source: str | None = Field(default=None, max_length=20)
    new_source: str | None = Field(default=None, max_length=20)
    reason: str | None = Field(default=None, max_length=500)
    actor: str = Field(max_length=120)
    at: datetime = Field(default_factory=utcnow, index=True)


class DealAssumptions(SQLModel, table=True):
    """Per-deal assumptions (Quick Scan overrides), peers, notes and entry settings, stored as JSON documents."""

    deal_id: str = Field(primary_key=True)
    overrides: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    peers: list[dict[str, Any]] = Field(default_factory=list, sa_column=Column(JSON))
    notes: dict[str, str] = Field(default_factory=dict, sa_column=Column(JSON))
    entry: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    methods: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))  # LBO, precedents, NAV … inputs
    fx: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))  # entered FX rates (period and peer)
    updated_at: datetime = Field(default_factory=utcnow)


class Document(SQLModel, table=True):
    """An uploaded file. The bytes live in the deal's folder inside the app data folder, never in the database."""

    id: str = Field(default_factory=new_id, primary_key=True)
    deal_id: str = Field(index=True)
    filename: str = Field(max_length=255)
    stored_name: str = Field(max_length=80)
    size_bytes: int = 0
    sha256: str = Field(max_length=64, index=True)
    kind: str = Field(default="unknown", max_length=20)
    page_count: int = 0
    scanned_pages: int = 0
    language: str | None = Field(default=None, max_length=10)
    doc_type: str | None = Field(default=None, max_length=40)
    status: str = Field(default="uploaded", max_length=20)  # uploaded | processing | processed | failed | unsupported
    job_id: str | None = Field(default=None, max_length=32)
    meta: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    uploaded_at: datetime = Field(default_factory=utcnow)
    uploaded_by: str = Field(default="Analyst", max_length=120)


class ExtractedItem(SQLModel, table=True):
    """A candidate value found in a document, awaiting the analyst's review (brief §2.3, §2.4)."""

    id: int | None = Field(default=None, primary_key=True)
    deal_id: str = Field(index=True)
    document_id: str = Field(index=True)
    concept_id: str = Field(max_length=60)
    period_key: str = Field(max_length=20)
    value: float
    value_as_written: str = Field(max_length=80)
    label: str = Field(max_length=300)
    page: int = 0
    bbox: list[float] | None = Field(default=None, sa_column=Column(JSON))
    cell_ref: str | None = Field(default=None, max_length=80)  # sheet cell, table cell (t1r2c3) or tagged fact id
    sheet: str | None = Field(default=None, max_length=100)
    scale_factor: float = 1.0
    scale_label: str | None = Field(default=None, max_length=40)
    confidence: float = 0.0
    method: str = Field(max_length=20)  # table_rules | ai_mapping | ai_extraction | user_mapping
    mapping: str = Field(max_length=10)
    provider: str | None = Field(default=None, max_length=30)
    model: str | None = Field(default=None, max_length=120)
    rationale: str | None = None
    notes: list[str] = Field(default_factory=list, sa_column=Column(JSON))
    status: str = Field(default="pending", max_length=12)  # pending | accepted | rejected
    decided_by: str | None = Field(default=None, max_length=120)
    decided_at: datetime | None = None
    created_at: datetime = Field(default_factory=utcnow)


class DealVersion(SQLModel, table=True):
    """A saved version of a deal (brief §14): an immutable snapshot of its inputs (periods, values with provenance,
    assumptions) and the headline results when it was saved. Restoring copies the snapshot back into the deal."""

    id: str = Field(default_factory=new_id, primary_key=True)
    deal_id: str = Field(index=True)
    name: str = Field(max_length=120)
    note: str | None = Field(default=None, max_length=2000)
    kind: str = Field(default="manual", max_length=20)  # manual | before_restore
    snapshot: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    results: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    created_by: str = Field(default="Analyst", max_length=120)
    created_at: datetime = Field(default_factory=utcnow, index=True)
