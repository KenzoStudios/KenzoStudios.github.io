"""Serve the static Next.js export, with client-side routes falling back to the app shell."""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse

_PLACEHOLDER = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>DealScout</title></head>
<body style="font-family:system-ui;margin:3rem;max-width:40rem;line-height:1.5">
<h1>DealScout API is running</h1>
<p>The web interface has not been built yet. Run <code>./start.sh</code> (or <code>.\\start.ps1</code> on Windows),
which builds it automatically, or use <code>./dev.sh</code> and open <a href="http://127.0.0.1:3000">127.0.0.1:3000</a>.</p>
</body></html>"""


def mount_frontend(app: FastAPI, web_dir: Path) -> None:
    root = web_dir.resolve()

    # HEAD as well as GET: the Next.js client router probes routes with HEAD before navigating.
    @app.api_route("/{full_path:path}", methods=["GET", "HEAD"], include_in_schema=False, response_model=None)
    def frontend(full_path: str) -> FileResponse | HTMLResponse:
        if full_path.startswith("api/"):
            raise HTTPException(status_code=404, detail="Not found")
        if not (root / "index.html").exists():
            return HTMLResponse(_PLACEHOLDER)
        candidates = [root / full_path, root / f"{full_path}.html", root / full_path / "index.html"]
        for candidate in candidates:
            resolved = candidate.resolve()
            if resolved.is_file() and resolved.is_relative_to(root):
                return FileResponse(resolved)
        return FileResponse(root / "index.html")  # unknown path → app shell (client-side routing)
