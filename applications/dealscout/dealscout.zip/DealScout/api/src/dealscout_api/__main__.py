"""``uv run dealscout``: start the local server on 127.0.0.1 and open the browser."""

from __future__ import annotations

import threading
import webbrowser

import uvicorn

from .config import HOST, get_settings


def main() -> None:
    settings = get_settings()
    url = f"http://{HOST}:{settings.port}"
    if settings.open_browser:
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    print(f"DealScout data folder: {settings.data_dir}")
    uvicorn.run("dealscout_api.app:create_app", factory=True, host=HOST, port=settings.port, log_level="info")


if __name__ == "__main__":
    main()
