"""``make seed`` — add a fictional sample deal so a fresh install has something to explore.

The company is invented; no real filings or data are used. Financial fixtures are added in Milestone 2.
"""

from __future__ import annotations

from datetime import date

from sqlmodel import Session, select

from .config import get_settings
from .db import init_engine
from .models import Deal
from .services import audit

SAMPLE_NAME = "Halvorsen Industrial Components AS (sample)"


def main() -> None:
    settings = get_settings()
    settings.ensure_dirs()
    engine = init_engine(settings.db_path)
    with Session(engine) as session:
        if session.exec(select(Deal).where(Deal.name == SAMPLE_NAME)).first():
            print("Sample deal already exists.")
            return
        deal = Deal(
            name=SAMPLE_NAME,
            country="NO",
            sector="industrials",
            industry="Machinery",
            listed=False,
            reporting_currency="NOK",
            analysis_currency="EUR",
            valuation_date=date.today(),
            perspective="financial_sponsor",
            mode="quick",
            sector_template="general",
            notes="Fictional company created by `make seed` for exploring DealScout.",
        )
        session.add(deal)
        audit.record(session, "deal_created", deal_id=deal.id, detail={"name": deal.name, "seed": True})
        session.commit()
        print(f"Created sample deal {deal.id} in {settings.data_dir}")


if __name__ == "__main__":
    main()
