"""PDF tear sheet (brief §14): 2–6 pages with the company snapshot, key financials, analysis highlights, valuation
summary and football field, suggested price and rationale, assumptions, data quality and the disclaimer. Charts are
drawn as vector graphics in the shared palette. Every figure comes from the export context (engine outputs).
"""

from __future__ import annotations

import io
from typing import Any

from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.shapes import Drawing, Line, Rect, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from .context import ExportContext
from .style import chart_colours, colours

W, H = A4
MARGIN = 16 * mm
CONTENT = W - 2 * MARGIN


def _c(hex6: str) -> colors.Color:
    return colors.HexColor(f"#{hex6}")


def _evidence(flag: dict[str, Any]) -> str:
    """For a warning sign found in a document: where it was found and a short quote."""
    if flag.get("source") != "document" or not flag.get("evidence"):
        return ""
    e = flag["evidence"][0]
    return f' Source: p. {e["page"]}, {e["filename"]}: "{e["snippet"]}"'


def _safe(text: str) -> str:
    """The standard PDF fonts cover WinAnsi only: swap the few characters outside it."""
    return (
        str(text)
        .replace("−", "-")
        .replace("→", "to")
        .replace("≥", ">=")
        .replace("≤", "<=")
        .replace("βL", "levered beta")
        .replace("β", "beta ")
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


def _money(v: float | None, ctx: ExportContext) -> str:
    if v is None:
        return "n/m"
    a = abs(v)
    div, suffix = (1e9, "bn") if a >= 1e9 else (1e6, "m") if a >= 1e6 else (1e3, "k") if a >= 1e3 else (1, "")
    return f"{'-' if v < 0 else ''}{ctx.currency} {a / div:,.{0 if a / div >= 100 else 1}f}{suffix}"


def _num(v: float | None, scale: float, digits: int = 1) -> str:
    if v is None:
        return ""
    x = v / scale
    if x == 0:
        return "-"
    return f"({abs(x):,.{digits}f})" if x < 0 else f"{x:,.{digits}f}"


def _pct(v: float | None) -> str:
    return "n/m" if v is None else (f"({abs(v):.1%})" if v < 0 else f"{v:.1%}")


def _x(v: float | None) -> str:
    return "n/m" if v is None else f"{v:.1f}x"


def styles() -> dict[str, ParagraphStyle]:
    c = colours()
    base = ParagraphStyle("base", fontName="Helvetica", fontSize=8.8, leading=11.5, textColor=_c(c["text"]))
    return {
        "body": base,
        "small": ParagraphStyle("small", parent=base, fontSize=7.5, leading=9.5, textColor=_c(c["grey_600"])),
        "h1": ParagraphStyle(
            "h1", parent=base, fontName="Helvetica-Bold", fontSize=20, leading=24, textColor=colors.white
        ),
        "meta": ParagraphStyle("meta", parent=base, fontSize=8, textColor=colors.white),
        "h2": ParagraphStyle(
            "h2",
            parent=base,
            fontName="Helvetica-Bold",
            fontSize=11,
            leading=14,
            textColor=_c(c["navy"]),
            spaceBefore=8,
            spaceAfter=4,
        ),
        "notice": ParagraphStyle(
            "notice",
            parent=base,
            fontName="Helvetica-Bold",
            fontSize=8,
            leading=10.5,
            textColor=_c(c["warning"]),
            backColor=_c(c["warning_bg"]),
            borderPadding=6,
            alignment=TA_LEFT,
        ),
        "bullet": ParagraphStyle("bullet", parent=base, leftIndent=10, bulletIndent=0, spaceAfter=2),
        "big": ParagraphStyle(
            "big", parent=base, fontName="Helvetica-Bold", fontSize=16, leading=19, textColor=_c(c["navy"])
        ),
    }


def _section(title: str, s: dict[str, ParagraphStyle]) -> Table:
    c = colours()
    t = Table(
        [
            [
                Paragraph(
                    _safe(title),
                    ParagraphStyle("band", parent=s["h2"], textColor=colors.white, spaceBefore=0, spaceAfter=0),
                )
            ]
        ],
        colWidths=[CONTENT],
    )
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), _c(c["navy"])),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]
        )
    )
    return t


def _table(head: list[str], rows: list[list[str]], widths: list[float], *, bold_rows: tuple[int, ...] = ()) -> Table:
    c = colours()
    data = [head, *rows]
    t = Table(data, colWidths=widths, repeatRows=1)
    style = [
        ("FONT", (0, 0), (-1, -1), "Helvetica", 8),
        ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 7.5),
        ("TEXTCOLOR", (0, 0), (-1, 0), _c(c["navy"])),
        ("BACKGROUND", (0, 0), (-1, 0), _c(c["grey_100"])),
        ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
        ("LINEBELOW", (0, 0), (-1, 0), 0.6, _c(c["grey_200"])),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]
    for i in range(1, len(data)):
        if i % 2 == 0:
            style.append(("BACKGROUND", (0, i), (-1, i), _c(c["grey_50"])))
    for i in bold_rows:
        style.append(("FONT", (0, i + 1), (-1, i + 1), "Helvetica-Bold", 8))
    t.setStyle(TableStyle(style))
    return t


def _football_field(
    ctx: ExportContext, rows: list[tuple[str, float, float, float, bool]], offer: tuple[float, float] | None
) -> Drawing:
    """Horizontal range bars, the blended row in navy, the suggested offer as a shaded band."""
    c = colours()
    label_w, pad = 62 * mm, 4
    bar_h, gap = 10, 8
    height = len(rows) * (bar_h + gap) + 34
    d = Drawing(CONTENT, height)
    values = [v for r in rows for v in (r[1], r[3])] + (list(offer) if offer else [])
    lo, hi = min(values), max(values)
    span = (hi - lo) or abs(hi) or 1
    lo, hi = lo - span * 0.08, hi + span * 0.08
    plot_w = CONTENT - label_w - 50

    def x(v: float) -> float:
        return label_w + (v - lo) / (hi - lo) * plot_w

    top = height - 10
    if offer:
        d.add(
            Rect(x(offer[0]), 22, x(offer[1]) - x(offer[0]), top - 22, fillColor=_c(c["accent_100"]), strokeColor=None)
        )
        d.add(
            String(
                x(offer[0]) + 2, top - 2, "Suggested offer", fontName="Helvetica", fontSize=6.5, fillColor=_c(c["navy"])
            )
        )
    for i, (label, low, mid, high, blended) in enumerate(rows):
        y = top - 12 - i * (bar_h + gap) - bar_h
        d.add(
            String(
                0,
                y + 2.5,
                _safe(label)[:48],
                fontName="Helvetica-Bold" if blended else "Helvetica",
                fontSize=7.5,
                fillColor=_c(c["text"]),
            )
        )
        colour = _c(c["navy"]) if blended else _c(chart_colours()[0])
        d.add(Rect(x(low), y, max(x(high) - x(low), 1), bar_h, fillColor=colour, strokeColor=None, rx=2, ry=2))
        d.add(Line(x(mid), y - 2, x(mid), y + bar_h + 2, strokeColor=_c(c["text"]), strokeWidth=1))
        d.add(
            String(
                x(high) + pad,
                y + 2.5,
                f"{_num(low, ctx.scale, 0)}-{_num(high, ctx.scale, 0)}",
                fontName="Helvetica",
                fontSize=6.5,
                fillColor=_c(c["grey_600"]),
            )
        )
    d.add(Line(label_w, 20, label_w + plot_w, 20, strokeColor=_c(c["grey_200"]), strokeWidth=0.6))
    for k in range(5):
        v = lo + (hi - lo) * k / 4
        d.add(
            String(
                x(v) - 10, 10, _num(v, ctx.scale, 0), fontName="Helvetica", fontSize=6.5, fillColor=_c(c["grey_600"])
            )
        )
    d.add(
        String(
            label_w, 0, f"Equity value ({ctx.unit})", fontName="Helvetica", fontSize=6.5, fillColor=_c(c["grey_600"])
        )
    )
    return d


def _revenue_chart(ctx: ExportContext) -> Drawing | None:
    series = ctx.analysis["series"]
    periods = ctx.analysis["periods"]
    rev = [series.get("revenue", {}).get(p) for p in periods]
    ebitda = [series.get("ebitda", {}).get(p) for p in periods]
    proj = (ctx.valuation["result"].get("dcf") or {}).get("projection") or []
    labels = [f"{p}A" for p in periods] + [y["label"] for y in proj]
    rev += [y["revenue"] for y in proj]
    ebitda += [y["ebitda"] for y in proj]
    if not any(v for v in rev):
        return None
    d = Drawing(CONTENT, 140)
    chart = VerticalBarChart()
    chart.x, chart.y, chart.width, chart.height = 30, 28, CONTENT - 40, 100
    chart.data = [[(v or 0) / ctx.scale for v in rev], [(v or 0) / ctx.scale for v in ebitda]]
    chart.categoryAxis.categoryNames = labels
    chart.categoryAxis.labels.fontName = "Helvetica"
    chart.categoryAxis.labels.fontSize = 6.5
    chart.valueAxis.labels.fontName = "Helvetica"
    chart.valueAxis.labels.fontSize = 6.5
    chart.valueAxis.valueMin = 0
    chart.valueAxis.gridStrokeColor = _c(colours()["grey_200"])
    chart.valueAxis.visibleGrid = True
    chart.categoryAxis.strokeColor = _c(colours()["grey_200"])
    chart.valueAxis.strokeColor = colors.white
    chart.bars[0].fillColor = _c(chart_colours()[0])
    chart.bars[1].fillColor = _c(chart_colours()[1])
    chart.bars.strokeColor = None
    chart.barSpacing = 1
    chart.groupSpacing = 6
    d.add(chart)
    c = colours()
    d.add(Rect(30, 4, 7, 7, fillColor=_c(chart_colours()[0]), strokeColor=None))
    d.add(String(40, 5, "Revenue", fontName="Helvetica", fontSize=7, fillColor=_c(c["text"])))
    d.add(Rect(80, 4, 7, 7, fillColor=_c(chart_colours()[1]), strokeColor=None))
    d.add(
        String(90, 5, f"EBITDA ({ctx.unit}; E = projection)", fontName="Helvetica", fontSize=7, fillColor=_c(c["text"]))
    )
    return d


_PCT_KEYS = {
    "revenue_growth",
    "ebitda_margin",
    "da_pct_revenue",
    "capex_pct_revenue",
    "nwc_pct_revenue",
    "tax_rate",
    "risk_free_rate",
    "equity_risk_premium",
    "country_risk_premium",
    "size_premium",
    "company_specific_premium",
    "pre_tax_cost_of_debt",
    "target_debt_to_capital",
    "terminal_growth",
    "wacc",
}


def _assumption_value(a: dict[str, Any], ctx: ExportContext) -> str:
    v = a["value"]
    if v is None:
        return "missing" if a["source"] == "missing" else "-"
    key = a["key"]

    def one(x: float) -> str:
        if key in _PCT_KEYS:
            return f"{x:.1%}"
        if key == "base_revenue":
            return _money(x, ctx)
        if key == "exit_multiple":
            return f"{x:.1f}x"
        if key == "projection_years":
            return f"{x:.0f} years"
        return f"{x:.2f}"

    if isinstance(v, list):
        return one(v[0]) if len(set(v)) == 1 else f"{one(v[0])} to {one(v[-1])}"
    return one(v)


def build_pdf(ctx: ExportContext) -> bytes:
    s = styles()
    c = colours()
    deal = ctx.deal
    res = ctx.valuation["result"]
    rec = ctx.recommendation.get("recommendation")
    rat = ctx.recommendation.get("rationale") or {}
    dq = ctx.recommendation["data_quality"]
    story: list[Any] = []

    # header band and AI notice
    header = Table(
        [
            [
                Paragraph(
                    "DealScout",
                    ParagraphStyle("brand", parent=s["meta"], fontName="Helvetica-Bold", textColor=_c(c["accent_100"])),
                ),
                Paragraph(
                    f"Data quality {dq['score']}/100 - grade {dq['grade']}",
                    ParagraphStyle("dq", parent=s["meta"], fontName="Helvetica-Bold", alignment=2),
                ),
            ],
            [Paragraph(_safe(deal.name), s["h1"]), ""],
            [
                Paragraph(
                    _safe(
                        f"{ctx.country_name} - {ctx.sector_name} - {ctx.unit} - valuation date {deal.valuation_date:%d %b %Y} - "
                        f"generated {ctx.generated:%d %b %Y}"
                    ),
                    s["meta"],
                ),
                "",
            ],
        ],
        colWidths=[CONTENT * 0.7, CONTENT * 0.3],
    )
    header.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), _c(c["navy"])),
                ("SPAN", (0, 1), (1, 1)),
                ("SPAN", (0, 2), (1, 2)),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    story += [header, Spacer(1, 8), Paragraph(_safe(ctx.disclaimers["ai_report_notice"]), s["notice"]), Spacer(1, 6)]

    # suggested price
    story.append(_section("Suggested acquisition price (indicative)", s))
    if rec:
        ps = rec.get("per_share")
        price = [
            Paragraph(
                _safe(
                    f"{_money(rec['equity_low'], ctx)} to {_money(rec['equity_high'], ctx)}  (mid {_money(rec['equity_mid'], ctx)})"
                ),
                s["big"],
            ),
            Paragraph(
                _safe(
                    "100% of equity"
                    + (
                        f"; per diluted share {ctx.currency} {ps[0]:,.2f} to {ps[2]:,.2f} (mid {ps[1]:,.2f})"
                        if ps
                        else ""
                    )
                ),
                s["body"],
            ),
        ]
        implied = rec["implied"]
        tiles = [
            ["Implied EV / EBITDA", "Implied EV / Revenue", "Implied P / E", "Premium to market"],
            [
                _x(implied["EV / EBITDA"][1]),
                _x(implied["EV / Revenue"][1]),
                _x(implied["P / E"][1]),
                _pct(rec["premium_to_market"][1]) if rec.get("premium_to_market") else "n/a (private)",
            ],
        ]
        t = Table(tiles, colWidths=[CONTENT / 4] * 4)
        t.setStyle(
            TableStyle(
                [
                    ("FONT", (0, 0), (-1, 0), "Helvetica", 7),
                    ("TEXTCOLOR", (0, 0), (-1, 0), _c(c["grey_600"])),
                    ("FONT", (0, 1), (-1, 1), "Helvetica-Bold", 12),
                    ("TEXTCOLOR", (0, 1), (-1, 1), _c(c["navy"])),
                    ("BOX", (0, 0), (-1, -1), 0.5, _c(c["grey_200"])),
                    ("INNERGRID", (0, 0), (-1, -1), 0.5, _c(c["grey_200"])),
                ]
            )
        )
        story += [*price, Spacer(1, 6), t, Spacer(1, 6)]
        for chk in rec.get("checks", []):
            mark = {"pass": "PASS", "warn": "CHECK", "fail": "FAIL"}.get(chk["status"], "NOT TESTED")
            story.append(Paragraph(f"<b>{mark}</b> - {_safe(chk['label'])}: {_safe(chk['detail'])}", s["bullet"]))
    else:
        story.append(Paragraph("No suggested price yet: complete at least one valuation method.", s["body"]))

    # football field
    ff = res.get("football_field")
    if ff and ff.get("methods"):
        rows = [
            (m["label"], m["equity_low"], m["equity_mid"], m["equity_high"], False)
            for m in ff["methods"]
            if m.get("included", True)
        ]
        if ff.get("blended_equity_low") is not None:
            rows.append(
                (
                    "Blended (weighted)",
                    ff["blended_equity_low"],
                    ff["blended_equity_mid"],
                    ff["blended_equity_high"],
                    True,
                )
            )
        story += [
            Spacer(1, 6),
            _section(f"Football field ({ctx.unit})", s),
            Spacer(1, 4),
            _football_field(ctx, rows, (rec["equity_low"], rec["equity_high"]) if rec else None),
        ]

    # rationale
    if rat:
        story += [Spacer(1, 6), _section("Rationale", s)]
        story += [Paragraph(_safe(b), s["bullet"], bulletText="•") for b in rat.get("bullets", [])]
        risks = [Paragraph(_safe(b), s["bullet"], bulletText="•") for b in rat.get("risks", [])]
        high = [
            Paragraph(_safe(b), s["bullet"], bulletText="•")
            for b in (rat.get("high_end") or ["No single method sets the high end."])
        ]
        story.append(KeepTogether([Paragraph("Key risks", s["h2"]), *risks]))
        story.append(KeepTogether([Paragraph("What would need to be true for the high end", s["h2"]), *high]))
        story.append(
            Paragraph(
                "AI-written; every number inserted from the engine."
                if rat.get("source") != "template"
                else "Standard wording; numbers from the engine.",
                s["small"],
            )
        )

    # key financials
    chart = _revenue_chart(ctx)
    story += [
        Spacer(1, 8),
        KeepTogether([_section(f"Key financials ({ctx.unit})", s), *([Spacer(1, 4), chart] if chart else [])]),
    ]
    periods = ctx.analysis["periods"]
    series = ctx.analysis["series"]
    lines = [
        ("Revenue", "revenue"),
        ("EBITDA", "ebitda"),
        ("EBIT", "ebit"),
        ("Net income", "net_income"),
        ("Cash from operations", "cfo"),
        ("Capex", "capex"),
    ]
    rows_ = [
        [label, *[_num(series.get(k, {}).get(p), ctx.scale) for p in periods]]
        for label, k in lines
        if any(series.get(k, {}).get(p) is not None for p in periods)
    ]
    if rows_:
        widths = [CONTENT * 0.34] + [CONTENT * 0.66 / max(len(periods), 1)] * len(periods)
        story += [Spacer(1, 4), _table([ctx.unit, *periods], rows_, widths)]
    ratios = {(r["ratio_id"], r["period_id"]): r["value"] for r in ctx.analysis["ratios"]}
    ratio_lines = [
        ("EBITDA margin", "ebitda_margin", _pct),
        ("ROIC", "roic", _pct),
        ("Net debt / EBITDA", "net_debt_to_ebitda", _x),
        ("Interest coverage", "interest_coverage", _x),
        ("FCF / EBITDA", "fcf_conversion_ebitda", _pct),
    ]
    rrows = [
        [label, *[fmt(ratios.get((rid, p))) if ratios.get((rid, p)) is not None else "" for p in periods]]
        for label, rid, fmt in ratio_lines
        if any(ratios.get((rid, p)) is not None for p in periods)
    ]
    if rrows and periods:
        widths = [CONTENT * 0.34] + [CONTENT * 0.66 / len(periods)] * len(periods)
        story += [Spacer(1, 4), _table(["Ratios", *periods], rrows, widths)]

    # analysis highlights
    story += [Spacer(1, 8), _section("Analysis highlights", s)]
    for sc in ctx.analysis.get("scores", {}).get("items", []):
        value = "partial" if sc.get("missing") else (f"{sc['value']:.2f}" if sc.get("value") is not None else "n/m")
        band = f" - {sc['zone']} zone" if sc.get("zone") and not sc.get("missing") else ""
        story.append(
            Paragraph(
                f"<b>{_safe(sc['name'])}</b>: {_safe(value + band)}"
                + (" (indicative)" if sc["name"] == "Beneish M" else ""),
                s["bullet"],
                bulletText="•",
            )
        )
    flags = [f for f in ctx.analysis.get("red_flags", []) if f["severity"] != "none"]
    if flags:
        story.append(
            _table(
                ["Early warning sign", "Period", "Severity", "Why it matters"],
                [
                    [
                        Paragraph(_safe(f["signal"]), s["small"]),
                        f["period"],
                        f["severity"].upper(),
                        Paragraph(_safe(f["explanation"] + _evidence(f)), s["small"]),
                    ]
                    for f in flags
                ],
                [CONTENT * 0.28, CONTENT * 0.1, CONTENT * 0.1, CONTENT * 0.52],
            )
        )
    else:
        story.append(
            Paragraph("No warning signs from the rules that could be tested with the figures entered.", s["body"])
        )

    # assumptions and data quality
    story += [Spacer(1, 8), _section("Assumptions and data quality", s)]
    arows = []
    for a in res["assumptions"]:
        text = _assumption_value(a, ctx)
        arows.append(
            [
                Paragraph(_safe(a["label"]), s["small"]),
                text,
                a["source"],
                Paragraph(
                    _safe((a.get("detail") or "") + (f" (as of {a['as_of']})" if a.get("as_of") else "")), s["small"]
                ),
            ]
        )
    if arows:
        story.append(
            _table(
                ["Assumption", "Value", "Source", "Detail"],
                arows,
                [CONTENT * 0.28, CONTENT * 0.14, CONTENT * 0.12, CONTENT * 0.46],
            )
        )
    story.append(Spacer(1, 4))
    story.append(
        Paragraph(
            f"<b>Data quality {dq['score']}/100 (grade {dq['grade']}).</b> " + _safe(" ".join(dq.get("notes", []))),
            s["body"],
        )
    )
    story.append(
        Paragraph(_safe("Documents: " + (", ".join(ctx.documents) or "none (figures entered by hand)")), s["small"])
    )

    # disclaimer
    story += [Spacer(1, 8), _section("Disclaimer", s)]
    story += [Paragraph(_safe(p), s["small"]) for p in [ctx.disclaimers["ai_report_notice"], *ctx.disclaimers["full"]]]

    def decorate(canvas: Any, doc: Any) -> None:
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(_c(c["grey_600"]))
        canvas.drawString(MARGIN, 9 * mm, _safe(ctx.disclaimers["print_footer"]).replace("&amp;", "&"))
        canvas.drawRightString(W - MARGIN, 9 * mm, f"Page {doc.page}")
        if doc.page > 1:
            canvas.drawString(MARGIN, H - 9 * mm, _safe(f"{deal.name} - DealScout").replace("&amp;", "&"))
        canvas.restoreState()

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=A4,
        leftMargin=MARGIN,
        rightMargin=MARGIN,
        topMargin=14 * mm,
        bottomMargin=16 * mm,
        title=f"{deal.name} - DealScout tear sheet",
        author="DealScout (AI-generated)",
        subject="Indicative acquisition analysis (AI-generated)",
    )
    doc.build(story, onFirstPage=decorate, onLaterPages=decorate)
    return buf.getvalue()
