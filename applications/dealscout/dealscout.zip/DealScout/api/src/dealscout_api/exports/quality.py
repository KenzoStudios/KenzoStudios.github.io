"""Checks run on a generated workbook before it is offered for download (brief §14A).

LibreOffice (optional prerequisite) recalculates the file headless; the recalculated copy is then scanned for
formula errors, the expected tabs, chart data and the disclaimer in every required place. Without LibreOffice the
structural checks still run and the result says the formulas were not recalculated.
"""

from __future__ import annotations

import io
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from openpyxl import load_workbook

ERRORS = ("#REF!", "#VALUE!", "#DIV/0!", "#NAME?", "#N/A", "#NUM!", "#NULL!")
REQUIRED_TABS = ("Report", "Financials", "Valuation Summary", "Sources", "Disclaimer")


@dataclass
class QualityReport:
    recalculated: bool
    errors: list[str] = field(default_factory=list)
    problems: list[str] = field(default_factory=list)
    values: dict[str, object] = field(default_factory=dict)  # selected recalculated outputs

    @property
    def ok(self) -> bool:
        return not self.errors and not self.problems


def soffice_path() -> str | None:
    for name in ("soffice", "libreoffice"):
        found = shutil.which(name)
        if found:
            return found
    mac = Path("/Applications/LibreOffice.app/Contents/MacOS/soffice")
    return str(mac) if mac.exists() else None


def recalculate(content: bytes, *, timeout: float = 90) -> bytes | None:
    """A recalculated copy (LibreOffice computes every formula on load), or None when LibreOffice is unavailable."""
    soffice = soffice_path()
    if soffice is None:
        return None
    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / "in" / "workbook.xlsx"
        out = Path(tmp) / "out"
        src.parent.mkdir()
        out.mkdir()
        src.write_bytes(content)
        profile = Path(tmp) / "profile"
        try:
            subprocess.run(
                [
                    soffice,
                    f"-env:UserInstallation={profile.as_uri()}",
                    "--headless",
                    "--calc",
                    "--convert-to",
                    "xlsx",
                    "--outdir",
                    str(out),
                    str(src),
                ],
                capture_output=True,
                timeout=timeout,
                check=False,
            )
        except (subprocess.TimeoutExpired, OSError):
            return None
        result = out / "workbook.xlsx"
        return result.read_bytes() if result.exists() else None


def check_workbook(content: bytes, *, footer: str, notice: str) -> QualityReport:
    recalculated = recalculate(content)
    report = QualityReport(recalculated=recalculated is not None)
    formulas = load_workbook(io.BytesIO(content))
    missing = [t for t in REQUIRED_TABS if t not in formulas.sheetnames]
    if missing:
        report.problems.append(f"Missing tabs: {', '.join(missing)}")
    if formulas.sheetnames[0] != "Report":
        report.problems.append("The Report tab is not first")
    for ws in formulas.worksheets:
        if footer not in (ws.oddFooter.left.text or ""):
            report.problems.append(f"{ws.title}: the AI disclaimer is not in the print footer")
        for chart in ws._charts:
            if not chart.series:
                report.problems.append(f"{ws.title}: a chart has no data")
    report_text = " ".join(
        str(c.value) for row in formulas["Report"].iter_rows() for c in row if isinstance(c.value, str)
    )
    if notice not in report_text:
        report.problems.append("The AI-report notice is missing from the Report tab")
    if "Disclaimer" in formulas.sheetnames:
        text = " ".join(str(c.value) for row in formulas["Disclaimer"].iter_rows() for c in row if c.value)
        if notice not in text:
            report.problems.append("The Disclaimer tab does not carry the notice")
    if recalculated is not None:
        values = load_workbook(io.BytesIO(recalculated), data_only=True)
        for ws in values.worksheets:
            for row in ws.iter_rows():
                for c in row:
                    if isinstance(c.value, str) and c.value in ERRORS:
                        report.errors.append(f"{ws.title}!{c.coordinate} {c.value}")
        if "DCF" in values.sheetnames:
            for row in values["DCF"].iter_rows(min_col=2, max_col=3):
                if row[0].value in ("Enterprise value", "Equity value"):
                    report.values[str(row[0].value)] = row[1].value
    return report
