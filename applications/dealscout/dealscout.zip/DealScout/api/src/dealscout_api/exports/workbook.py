"""The "Create Excel" analysis workbook (brief §14A).

Tab order: Report, Financials, Valuation Summary, Assumptions, WACC, Projections, DCF, then the method tabs used in the
deal (Comps, Precedents, LBO, NAV & SOTP), Sources and Disclaimer.

The DCF chain is a live model: inputs in blue on Assumptions, formulas in black, links between tabs in green, so a
changed assumption flows through WACC, Projections, DCF, Valuation Summary and the Report. LBO, Precedents and
NAV & SOTP are live models too (``live_methods.py``); the remaining method results are DealScout engine outputs,
written as values and labelled as such. Only
functions LibreOffice can evaluate are used (no XLOOKUP / FILTER / SORT / UNIQUE / SEQUENCE).
"""

from __future__ import annotations

import io
import re
from dataclasses import dataclass, field
from typing import Any

from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.chart.text import RichText, Text
from openpyxl.chart.title import Title
from openpyxl.comments import Comment
from openpyxl.drawing.line import LineProperties
from openpyxl.drawing.text import CharacterProperties, Paragraph, ParagraphProperties, RegularTextRun
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment
from openpyxl.worksheet.worksheet import Worksheet

from .context import ExportContext
from .style import (
    FACTOR,
    MULT,
    NUM,
    PCT,
    PRICE,
    back_link,
    band,
    chart_colours,
    col,
    colours,
    fill,
    font,
    header_row,
    label_cell,
    neutralise_injected_formulas,
    print_header_footer,
    ref,
    setup_sheet,
    subhead,
    value_cell,
    zebra,
)

ENGINE_NOTE = "Computed by the DealScout engine; shown as a value."


@dataclass
class Refs:
    """Absolute references to cells other tabs link to."""

    cells: dict[str, str] = field(default_factory=dict)

    def __getitem__(self, key: str) -> str:
        return self.cells[key]

    def get(self, key: str) -> str | None:
        return self.cells.get(key)

    def items(self, key: str) -> list[str]:
        """A list stored as "a|b|c"."""
        value = self.cells.get(key)
        return value.split("|") if value else []

    def pairs(self, key: str) -> dict[str, str]:
        """A mapping stored as "k:v|k:v"."""
        return dict(x.split(":", 1) for x in self.items(key))


def _title(text: str) -> Title:
    run = CharacterProperties(sz=1100, b=True, solidFill=colours()["navy"])
    para = Paragraph(pPr=ParagraphProperties(defRPr=run), r=[RegularTextRun(rPr=run, t=text)])
    title = Title(tx=Text(rich=RichText(p=[para])))
    title.overlay = False
    return title


def _style_chart(chart: Any, title: str, *, y_title: str | None = None, legend: bool = True) -> None:
    chart.title = _title(title)
    chart.visible_cells_only = False  # football-field helper columns are hidden
    chart.style = 2
    chart.roundedCorners = False
    chart.height, chart.width = 7.0, 15.5
    if hasattr(chart, "x_axis"):
        chart.x_axis.delete = False
        chart.y_axis.delete = False
        if chart.y_axis.majorGridlines is not None:
            chart.y_axis.majorGridlines.spPr = GraphicalProperties(ln=LineProperties(solidFill="E6EAF0"))
        if y_title:
            chart.y_axis.title = y_title
    if legend and chart.legend is not None:
        chart.legend.position = "b"
        chart.legend.overlay = False
    elif not legend:
        chart.legend = None


def _colour_series(chart: Any, *, line: bool = False) -> None:
    palette = chart_colours()
    for i, s in enumerate(chart.series):
        colour = palette[i % len(palette)]
        if line:
            s.graphicalProperties.line.solidFill = colour
            s.graphicalProperties.line.width = 22000
            s.smooth = False
        else:
            s.graphicalProperties.solidFill = colour
            s.graphicalProperties.line.solidFill = colour


def _note(cell: Any, text: str) -> None:
    cell.comment = Comment(text, "DealScout")


# ── Assumptions ────────────────────────────────────────────────────────────────────
def _assumption_sources(ctx: ExportContext) -> dict[str, str]:
    out = {}
    for a in ctx.valuation["result"]["assumptions"]:
        src = {
            "user": "Analyst",
            "historical": "Company history",
            "default": "Market default",
            "convention": "Convention",
            "derived": "Derived",
            "missing": "MISSING",
        }.get(a["source"], a["source"])
        detail = f": {a['detail']}" if a.get("detail") else ""
        as_of = f" (as of {a['as_of']})" if a.get("as_of") else ""
        out[a["key"]] = f"{src}{detail}{as_of}"[:250]
    return out


def build_assumptions(wb: Workbook, ctx: ExportContext, r: Refs) -> bool:
    res = ctx.valuation["result"]
    di = res.get("dcf_inputs")
    w = res.get("wacc")
    if not di or not w:
        return False
    ws = wb.create_sheet("Assumptions")
    setup_sheet(
        ws,
        widths={"B": 40, "C": 14, "D": 14, "E": 14, "F": 14, "G": 14, "H": 14, "I": 14, "J": 14},
        landscape=True,
        tab_colour=colours()["accent"],
    )
    back_link(ws)
    s = ctx.scale
    src = _assumption_sources(ctx)
    dr = di["drivers"]
    years = len(dr["revenue_growth"])
    last = 3 + years
    row = band(ws, 3, f"Assumptions: inputs in blue ({ctx.unit} unless stated)", max(last, 4))

    def put(key: str, label: str, value: Any, fmt: str, source: str = "") -> None:
        nonlocal row
        label_cell(ws, row, label)
        value_cell(ws, row, 3, value, fmt, kind="input")
        note = ws.cell(row=row, column=4, value=source)
        note.font = font(8, italic=True, colour=colours()["grey_600"])
        r.cells[key] = ref("Assumptions", row, 3)
        row += 1

    row = subhead(ws, row + 1, "Operating base", max(last, 4))
    base_nwc = dr.get("base_nwc")
    if base_nwc is None:
        base_nwc = dr["base_revenue"] * dr["nwc_pct_revenue"][0]
    put(
        "base_revenue",
        f"Base-year revenue ({ctx.unit})",
        dr["base_revenue"] / s,
        NUM,
        src.get("base_revenue", "Company history"),
    )
    put("base_ebitda", f"Base-year EBITDA ({ctx.unit})", (res.get("base_ebitda") or 0) / s, NUM, "Company history")
    ni = ctx.analysis["series"].get("net_income", {}).get(res.get("base_period") or "", None)
    put("net_income", f"Base-year net income ({ctx.unit})", (ni or 0) / s, NUM, "Company history")
    put(
        "base_nwc",
        f"Opening net working capital ({ctx.unit})",
        base_nwc / s,
        NUM,
        "Base revenue × NWC % when not reported",
    )
    put(
        "nol", f"Tax losses brought forward ({ctx.unit})", dr.get("nol_opening", 0) / s, NUM, src.get("nol_opening", "")
    )
    put("tax", "Tax rate", dr["tax_rate"], PCT, src.get("tax_rate", ""))
    put("sbc_addback", "Add back share-based pay (1 = yes)", 1 if dr.get("sbc_treatment") == "add_back" else 0, "0", "")

    row = subhead(ws, row + 1, "Discount rate", max(last, 4))
    inputs = {i["name"]: i["value"] for i in w["derivation"]["inputs"]}
    put("rf", "Risk-free rate", inputs.get("risk_free_rate"), PCT, src.get("risk_free_rate", ""))
    put("erp", "Equity risk premium", inputs.get("equity_risk_premium"), PCT, src.get("equity_risk_premium", ""))
    put(
        "crp", "Country risk premium", inputs.get("country_risk_premium") or 0, PCT, src.get("country_risk_premium", "")
    )
    put("size", "Size premium", inputs.get("size_premium") or 0, PCT, src.get("size_premium", ""))
    put(
        "specific",
        "Company-specific premium",
        inputs.get("company_specific_premium") or 0,
        PCT,
        src.get("company_specific_premium", ""),
    )
    put("beta_u", "Unlevered beta", w.get("unlevered_beta"), "0.00", src.get("unlevered_beta", ""))
    put(
        "beta_l_override",
        "Levered beta override (blank = relever)",
        None if w.get("unlevered_beta") is not None else w["levered_beta"],
        "0.00",
        "Enter to replace the relevered beta",
    )
    put("kd", "Pre-tax cost of debt", inputs.get("pre_tax_cost_of_debt"), PCT, src.get("pre_tax_cost_of_debt", ""))
    put("dw", "Target debt / (debt + equity)", w["debt_weight"], PCT, src.get("target_debt_to_capital", ""))

    row = subhead(ws, row + 1, "Terminal value and timing", max(last, 4))
    put("g", "Terminal growth", di["terminal_growth"], PCT, src.get("terminal_growth", ""))
    put("exit", "Exit EV / EBITDA", di["exit_multiple"], MULT, src.get("exit_multiple", ""))
    put("method", "Terminal method (gordon, exit_multiple, average)", di["terminal_method"], "@", "")
    put("mid", "Mid-year convention (1 = yes)", 1 if di.get("mid_year", True) else 0, "0", "")
    stub = res["dcf"]["projection"][0]["period_fraction"] if res.get("dcf") else 1.0
    put("stub", "First-year stub fraction", stub, "0.000", "Days from the valuation date to the first year end ÷ 365")

    row = subhead(ws, row + 1, f"Enterprise value to equity value ({ctx.unit}, effect on equity)", max(last, 4))
    first_bridge = row
    for item in res["dcf"]["bridge"]["items"] if res.get("dcf") else []:
        if not item["included"] or item["amount"] == 0:
            continue
        put(f"bridge_{item['key']}", item["label"], item["amount"] / s, NUM, item.get("note") or "")
    r.cells["bridge_range"] = f"'Assumptions'!$C${first_bridge}:$C${max(row - 1, first_bridge)}"
    if row == first_bridge:
        put("bridge_none", "No bridge items", 0, NUM, "")
        r.cells["bridge_range"] = f"'Assumptions'!$C${first_bridge}:$C${first_bridge}"
    per_share = res["dcf"].get("per_share") if res.get("dcf") else None
    put(
        "shares",
        "Diluted shares (millions)",
        (per_share["diluted_shares"] / 1e6) if per_share else None,
        "#,##0.00",
        "Treasury-stock method at the DCF value (engine)" if per_share else "Share count unknown",
    )
    mc = res.get("market_cap")
    put("market_cap", f"Market capitalisation ({ctx.unit})", mc / s if mc else None, NUM, "Listed deals only")

    row = subhead(ws, row + 1, "Projection drivers", max(last, 4))
    labels = di.get("year_labels") or [f"Year {t + 1}" for t in range(years)]
    row = header_row(ws, row, ["Driver", "", *labels], shade=[False, False, *([True] * years)])
    grid = [
        ("growth", "Revenue growth", dr["revenue_growth"]),
        ("margin", "EBITDA margin", dr["ebitda_margin"]),
        ("da", "D&A % of revenue", dr["da_pct_revenue"]),
        ("capex", "Capex % of revenue", dr["capex_pct_revenue"]),
        ("nwc", "NWC % of revenue", dr["nwc_pct_revenue"]),
        ("sbc", "Share-based pay % of revenue", dr.get("sbc_pct_revenue") or [0.0] * years),
    ]
    for key, label, values in grid:
        label_cell(ws, row, label)
        for t, v in enumerate(values):
            value_cell(ws, row, 4 + t, v, PCT, kind="input")
        r.cells[f"drv_{key}"] = str(row)
        row += 1
    r.cells["years"] = str(years)
    r.cells["labels"] = "|".join(labels)
    ws.freeze_panes = "C4"
    return True


# ── WACC ─────────────────────────────────────────────────────────────────────────
def build_wacc(wb: Workbook, ctx: ExportContext, r: Refs) -> None:
    ws = wb.create_sheet("WACC")
    setup_sheet(ws, widths={"B": 44, "C": 14, "D": 50}, tab_colour=colours()["accent"])
    back_link(ws)
    row = band(ws, 3, "Weighted average cost of capital", 4)
    lines = [
        ("rf", "Risk-free rate", f"={r['rf']}", PCT, "link"),
        ("beta_u", "Unlevered beta", f"={r['beta_u']}", "0.00", "link"),
        ("dw", "Debt / (debt + equity)", f"={r['dw']}", PCT, "link"),
        ("de", "Debt / equity", "=IF(1-C{dw}=0,0,C{dw}/(1-C{dw}))", PCT, "formula"),
        ("tax", "Tax rate", f"={r['tax']}", PCT, "link"),
        (
            "beta_l",
            "Levered beta (Hamada)",
            f'=IF({r["beta_l_override"]}<>"",{r["beta_l_override"]},C{{beta_u}}*(1+(1-C{{tax}})*C{{de}}))',
            "0.00",
            "formula",
        ),
        ("erp", "Equity risk premium", f"={r['erp']}", PCT, "link"),
        ("crp", "Country risk premium", f"={r['crp']}", PCT, "link"),
        ("size", "Size premium", f"={r['size']}", PCT, "link"),
        ("spec", "Company-specific premium", f"={r['specific']}", PCT, "link"),
        ("ke", "Cost of equity", "=C{rf}+C{beta_l}*C{erp}+C{crp}+C{size}+C{spec}", PCT, "formula"),
        ("kd", "Pre-tax cost of debt", f"={r['kd']}", PCT, "link"),
        ("kd_at", "After-tax cost of debt", "=C{kd}*(1-C{tax})", PCT, "formula"),
        ("ew", "Equity weight", "=1-C{dw}", PCT, "formula"),
        ("wacc", "WACC", "=C{ew}*C{ke}+C{dw}*C{kd_at}", PCT, "formula"),
    ]
    rows = {key: row + i for i, (key, *_rest) in enumerate(lines)}
    for key, label, formula, fmt, kind in lines:
        rr = rows[key]
        label_cell(ws, rr, label, bold=key in ("ke", "wacc"))
        value_cell(ws, rr, 3, formula.format(**rows), fmt, kind=kind, bold=key in ("ke", "wacc"))
    r.cells["wacc"] = ref("WACC", rows["wacc"], 3)
    r.cells["ke"] = ref("WACC", rows["ke"], 3)
    ws.cell(
        row=rows["wacc"] + 2,
        column=2,
        value="Hamada: βL = βU × (1 + (1 − t) × D/E). Cost of equity = rf + βL × ERP + premia.",
    ).font = font(8, italic=True, colour=colours()["grey_600"])


# ── Projections and DCF ────────────────────────────────────────────────────────────
def build_projections(wb: Workbook, ctx: ExportContext, r: Refs) -> None:
    ws = wb.create_sheet("Projections")
    years = int(r["years"])
    labels = r["labels"].split("|")
    widths = {"B": 34, "C": 12} | {col(4 + t): 12 for t in range(years)}
    setup_sheet(ws, widths=widths, landscape=True, tab_colour=colours()["accent"])
    back_link(ws)
    last = 3 + years
    row = band(ws, 3, f"Projections ({ctx.unit})", last)
    row = header_row(ws, row, ["", "Base", *labels], shade=[False, False, *([True] * years)])
    a = "'Assumptions'!"
    keys = [
        "growth",
        "revenue",
        "margin",
        "ebitda",
        "da_pct",
        "da",
        "ebit",
        "nol_avail",
        "nol_used",
        "tax",
        "nopat",
        "sbc_pct",
        "sbc",
        "capex_pct",
        "capex",
        "nwc_pct",
        "nwc",
        "dnwc",
        "ufcf",
    ]
    rows = {k: row + i for i, k in enumerate(keys)}
    labels_map = {
        "growth": ("Revenue growth", True),
        "revenue": ("Revenue", False),
        "margin": ("EBITDA margin", True),
        "ebitda": ("EBITDA", False),
        "da_pct": ("D&A % of revenue", True),
        "da": ("− D&A", False),
        "ebit": ("EBIT", False),
        "nol_avail": ("Tax losses available", True),
        "nol_used": ("Tax losses used", True),
        "tax": ("− Cash taxes", False),
        "nopat": ("NOPAT", False),
        "sbc_pct": ("Share-based pay % of revenue", True),
        "sbc": ("Share-based pay", False),
        "capex_pct": ("Capex % of revenue", True),
        "capex": ("− Capex", False),
        "nwc_pct": ("NWC % of revenue", True),
        "nwc": ("Net working capital", False),
        "dnwc": ("− Increase in NWC", False),
        "ufcf": ("Unlevered free cash flow", False),
    }
    for k, (label, italic) in labels_map.items():
        label_cell(ws, rows[k], label, italic=italic, bold=k in ("ebitda", "ebit", "ufcf"), indent=1 if italic else 0)
    value_cell(ws, rows["revenue"], 3, f"={r['base_revenue']}", NUM, kind="link")
    value_cell(ws, rows["nwc"], 3, f"={r['base_nwc']}", NUM, kind="link")
    drv = {k: int(r[f"drv_{k}"]) for k in ("growth", "margin", "da", "capex", "nwc", "sbc")}
    for t in range(years):
        c, p = col(4 + t), col(3 + t)
        acol = col(4 + t)
        f = {
            "growth": (f"={a}{acol}{drv['growth']}", PCT, "link"),
            "revenue": (f"={p}{rows['revenue']}*(1+{c}{rows['growth']})", NUM, "formula"),
            "margin": (f"={a}{acol}{drv['margin']}", PCT, "link"),
            "ebitda": (f"={c}{rows['revenue']}*{c}{rows['margin']}", NUM, "formula"),
            "da_pct": (f"={a}{acol}{drv['da']}", PCT, "link"),
            "da": (f"={c}{rows['revenue']}*{c}{rows['da_pct']}", NUM, "formula"),
            "ebit": (f"={c}{rows['ebitda']}-{c}{rows['da']}", NUM, "formula"),
            "nol_avail": (
                f"={r['nol']}" if t == 0 else f"={p}{rows['nol_avail']}-{p}{rows['nol_used']}",
                NUM,
                "link" if t == 0 else "formula",
            ),
            "nol_used": (f"=MIN({c}{rows['nol_avail']},MAX({c}{rows['ebit']},0))", NUM, "formula"),
            "tax": (f"=MAX({c}{rows['ebit']}-{c}{rows['nol_used']},0)*{r['tax']}", NUM, "formula"),
            "nopat": (f"={c}{rows['ebit']}-{c}{rows['tax']}", NUM, "formula"),
            "sbc_pct": (f"={a}{acol}{drv['sbc']}", PCT, "link"),
            "sbc": (f"={c}{rows['revenue']}*{c}{rows['sbc_pct']}", NUM, "formula"),
            "capex_pct": (f"={a}{acol}{drv['capex']}", PCT, "link"),
            "capex": (f"={c}{rows['revenue']}*{c}{rows['capex_pct']}", NUM, "formula"),
            "nwc_pct": (f"={a}{acol}{drv['nwc']}", PCT, "link"),
            "nwc": (f"={c}{rows['revenue']}*{c}{rows['nwc_pct']}", NUM, "formula"),
            "dnwc": (f"={c}{rows['nwc']}-{p}{rows['nwc']}", NUM, "formula"),
            "ufcf": (
                f"={c}{rows['nopat']}+{c}{rows['da']}-{c}{rows['capex']}-{c}{rows['dnwc']}+IF({r['sbc_addback']}=1,{c}{rows['sbc']},0)",
                NUM,
                "formula",
            ),
        }
        for k, (formula, fmt, kind) in f.items():
            value_cell(
                ws,
                rows[k],
                4 + t,
                formula,
                fmt,
                kind=kind,
                italic=labels_map[k][1],
                bold=k in ("ebitda", "ebit", "ufcf"),
            )
    for k in ("revenue", "ebitda", "ebit", "ufcf", "capex", "da", "dnwc"):
        r.cells[f"proj_{k}"] = str(rows[k])
    ws.freeze_panes = "C5"


def build_dcf(wb: Workbook, ctx: ExportContext, r: Refs) -> None:
    ws = wb.create_sheet("DCF")
    years = int(r["years"])
    labels = r["labels"].split("|")
    widths = {"B": 40, "C": 14} | {col(4 + t): 12 for t in range(years)}
    setup_sheet(ws, widths=widths, landscape=True, tab_colour=colours()["accent"])
    back_link(ws)
    last = 3 + years
    row = band(ws, 3, f"Discounted cash flow: FCFF ({ctx.unit})", last)
    row = header_row(ws, row, ["", "", *labels], shade=[False, False, *([True] * years)])
    keys = ["ufcf", "frac", "end", "time", "factor", "pv"]
    rows = {k: row + i for i, k in enumerate(keys)}
    names = {
        "ufcf": "Unlevered free cash flow",
        "frac": "Period fraction",
        "end": "Time to period end (years)",
        "time": "Discount time (mid-year if on)",
        "factor": "Discount factor",
        "pv": "Present value of FCF",
    }
    for k, n in names.items():
        label_cell(ws, rows[k], n, bold=k == "pv")
    p = "'Projections'!"
    for t in range(years):
        c, prev = col(4 + t), col(3 + t)
        value_cell(ws, rows["ufcf"], 4 + t, f"={p}{c}{r['proj_ufcf']}", NUM, kind="link")
        value_cell(
            ws, rows["frac"], 4 + t, f"={r['stub']}" if t == 0 else "=1", "0.000", kind="link" if t == 0 else "formula"
        )
        value_cell(
            ws,
            rows["end"],
            4 + t,
            f"={c}{rows['frac']}" if t == 0 else f"={prev}{rows['end']}+{c}{rows['frac']}",
            "0.000",
        )
        value_cell(
            ws, rows["time"], 4 + t, f"=IF({r['mid']}=1,{c}{rows['end']}-{c}{rows['frac']}/2,{c}{rows['end']})", "0.000"
        )
        value_cell(ws, rows["factor"], 4 + t, f"=1/(1+{r['wacc']})^{c}{rows['time']}", FACTOR)
        value_cell(ws, rows["pv"], 4 + t, f"={c}{rows['ufcf']}*{c}{rows['frac']}*{c}{rows['factor']}", NUM, bold=True)
    lc = col(3 + years)
    row = rows["pv"] + 2
    row = subhead(ws, row, "Terminal value and enterprise value", last)
    summary = [
        ("sum_pv", "Sum of PV of free cash flows", f"=SUM(D{rows['pv']}:{lc}{rows['pv']})", NUM),
        ("fcf_n", "Final-year free cash flow", f"={lc}{rows['ufcf']}", NUM),
        ("ebitda_n", "Final-year EBITDA", f"={p}{lc}{r['proj_ebitda']}", NUM),
        ("wacc", "WACC", f"={r['wacc']}", PCT),
        ("g", "Terminal growth", f"={r['g']}", PCT),
        ("exit", "Exit EV / EBITDA", f"={r['exit']}", MULT),
        ("tv_g", "Terminal value: Gordon growth", "=C{fcf_n}*(1+C{g})/(C{wacc}-C{g})", NUM),
        ("tv_x", "Terminal value: exit multiple", "=C{ebitda_n}*C{exit}", NUM),
        ("tv_factor", "Terminal discount factor (end of final year)", f"=1/(1+C{{wacc}})^{lc}{rows['end']}", FACTOR),
        ("pv_g", "PV of Gordon terminal value", "=C{tv_g}*C{tv_factor}", NUM),
        ("pv_x", "PV of exit-multiple terminal value", "=C{tv_x}*C{tv_factor}", NUM),
        (
            "pv_tv",
            "PV of terminal value used",
            f'=IF({r["method"]}="gordon",C{{pv_g}},IF({r["method"]}="exit_multiple",C{{pv_x}},(C{{pv_g}}+C{{pv_x}})/2))',
            NUM,
        ),
        ("ev", "Enterprise value", "=C{sum_pv}+C{pv_tv}", NUM),
        ("tv_share", "Terminal value share of EV", "=IF(C{ev}>0,C{pv_tv}/C{ev},0)", PCT),
        ("impl_mult", "Gordon value implies EV / EBITDA of", "=IF(C{ebitda_n}>0,C{tv_g}/C{ebitda_n},0)", MULT),
        ("impl_g", "Exit value implies perpetual growth of", "=(C{tv_x}*C{wacc}-C{fcf_n})/(C{tv_x}+C{fcf_n})", PCT),
        ("bridge", "+ EV-to-equity bridge (net)", f"=SUM({r['bridge_range']})", NUM),
        ("equity", "Equity value", "=C{ev}+C{bridge}", NUM),
        (
            "per_share",
            "Value per diluted share",
            f'=IF(N({r["shares"]})>0,C{{equity}}*{ctx.scale / 1e6:g}/{r["shares"]},"n/a")',
            PRICE,
        ),
    ]
    srows = {k: row + i for i, (k, *_x) in enumerate(summary)}
    for k, label, formula, fmt in summary:
        bold = k in ("ev", "equity")
        label_cell(ws, srows[k], label, bold=bold)
        kind = "link" if formula.startswith("='") or formula.startswith("='Projections") else "formula"
        value_cell(ws, srows[k], 3, formula.format(**srows), fmt, kind=kind, bold=bold)
    for k in ("ev", "equity", "per_share"):
        r.cells[f"dcf_{k}"] = ref("DCF", srows[k], 3)
    ev_engine = ctx.valuation["result"]["dcf"]["enterprise_value"] / ctx.scale
    chk = ws.cell(row=srows["per_share"] + 2, column=2, value="Check: enterprise value matches the DealScout engine")
    chk.font = font(9, italic=True, colour=colours()["grey_600"])
    value_cell(ws, srows["per_share"] + 2, 3, f'=IF(ABS(C{srows["ev"]}-{ev_engine:.6f})<0.05,"✓","✗")', "@")
    _note(
        ws.cell(row=srows["per_share"] + 2, column=3),
        f"Engine EV {ev_engine:,.3f} {ctx.unit}. ✗ appears once you change an input, which is expected.",
    )
    r.cells["dcf_check"] = ref("DCF", srows["per_share"] + 2, 3)
    ws.freeze_panes = "C5"


# ── Valuation Summary ───────────────────────────────────────────────────────────────
def build_summary(wb: Workbook, ctx: ExportContext, r: Refs) -> None:
    from .live_methods import summary_formulas  # imports this module

    ws = wb.create_sheet("Valuation Summary")
    setup_sheet(
        ws,
        widths={"B": 44, "C": 13, "D": 13, "E": 13, "F": 11, "G": 11, "H": 3, "I": 12},
        landscape=True,
        tab_colour=colours()["navy"],
    )
    back_link(ws)
    s = ctx.scale
    ff = ctx.valuation["result"].get("football_field") or {}
    methods = [m for m in ff.get("methods", []) if m.get("included", True)]
    row = band(ws, 3, f"Valuation summary: equity value ({ctx.unit})", 9)
    row = header_row(ws, row, ["Method", "Low", "Mid", "High", "Weight", "Share", "", "Range"])
    first = row
    for m in methods:
        label_cell(ws, row, m["label"])
        discounted = "lack of marketability" in (m.get("note") or "")
        is_dcf = m["method_id"] == "dcf" and r.get("dcf_equity") and not discounted
        live = None if discounted else summary_formulas(m["method_id"], r)
        if live:
            for i, formula in enumerate(live):
                value_cell(ws, row, 3 + i, formula, NUM, kind="link")
        else:
            value_cell(ws, row, 3, m["equity_low"] / s, NUM, kind="value")
            value_cell(
                ws,
                row,
                4,
                f"={r['dcf_equity']}" if is_dcf else m["equity_mid"] / s,
                NUM,
                kind="link" if is_dcf else "value",
            )
            value_cell(ws, row, 5, m["equity_high"] / s, NUM, kind="value")
        value_cell(ws, row, 6, m["weight"], "0.00", kind="input")
        row += 1
    lastm = max(row - 1, first)
    for rr in range(first, lastm + 1):
        value_cell(ws, rr, 7, f"=IF(SUM($F${first}:$F${lastm})=0,0,F{rr}/SUM($F${first}:$F${lastm}))", PCT)
        value_cell(ws, rr, 9, f"=E{rr}-C{rr}", NUM)  # chart helper: bar length
    if methods:
        _note(
            ws.cell(row=first, column=3),
            "Green values link to live model tabs (DCF mid, precedents, NAV, SOTP); black values are DealScout engine "
            "outputs (DCF low and high ends, LBO goal seek, other methods). Weights (blue) are editable.",
        )
    zebra(ws, first, lastm, 2, 7)
    row = lastm + 2
    label_cell(ws, row, "Blended value (weighted)", bold=True)
    for c_ in (3, 4, 5):
        L = col(c_)
        value_cell(ws, row, c_, f"=SUMPRODUCT({L}{first}:{L}{lastm},$G${first}:$G${lastm})", NUM, bold=True)
    blended = row
    r.cells["blend_low"], r.cells["blend_mid"], r.cells["blend_high"] = (
        ref("Valuation Summary", blended, c_) for c_ in (3, 4, 5)
    )
    row += 2
    row = subhead(ws, row, "Suggested acquisition price (100% of equity)", 9)
    row = header_row(ws, row, ["", "Low", "Mid", "High"])
    price_rows = {
        "equity": ("Equity value", [f"=C{blended}", f"=D{blended}", f"=E{blended}"], NUM),
        "per_share": (
            "Per diluted share",
            # equity is in the entry scale and shares in millions: convert before dividing
            [f'=IF(N({r["shares"]})>0,{c}{blended}*{ctx.scale / 1e6:g}/{r["shares"]},"n/a")' for c in "CDE"],
            PRICE,
        ),
        "ev": ("Enterprise value", [f"={c}{blended}-SUM({r['bridge_range']})" for c in "CDE"], NUM),
    }
    pr = {}
    for key, (label, formulas, fmt) in price_rows.items():
        label_cell(ws, row, label, bold=key == "equity")
        for i, f in enumerate(formulas):
            value_cell(ws, row, 3 + i, f, fmt, bold=key == "equity")
        pr[key] = row
        row += 1
    implied = [
        ("EV / Revenue", [f"=IF({r['base_revenue']}>0,{c}{pr['ev']}/{r['base_revenue']},0)" for c in "CDE"]),
        ("EV / EBITDA", [f"=IF({r['base_ebitda']}>0,{c}{pr['ev']}/{r['base_ebitda']},0)" for c in "CDE"]),
        ("P / E", [f"=IF({r['net_income']}>0,{c}{pr['equity']}/{r['net_income']},0)" for c in "CDE"]),
    ]
    for label, formulas in implied:
        label_cell(ws, row, f"Implied {label}", italic=True, indent=1)
        for i, f in enumerate(formulas):
            value_cell(ws, row, 3 + i, f, MULT, italic=True)
        r.cells[f"impl_{label}"] = ref("Valuation Summary", row, 4)
        row += 1
    label_cell(ws, row, "Premium to market capitalisation", italic=True, indent=1)
    for i, c in enumerate("CDE"):
        value_cell(
            ws, row, 3 + i, f'=IF(N({r["market_cap"]})>0,{c}{pr["equity"]}/{r["market_cap"]}-1,"n/a")', PCT, italic=True
        )
    r.cells["premium_mid"] = ref("Valuation Summary", row, 4)
    r.cells["ps_low"], r.cells["ps_mid"], r.cells["ps_high"] = (
        ref("Valuation Summary", pr["per_share"], c_) for c_ in (3, 4, 5)
    )
    row += 2
    rec = ctx.recommendation.get("recommendation")
    if rec and rec.get("checks"):
        row = subhead(ws, row, "Checks at the suggested price (engine)", 9)
        for chk in rec["checks"]:
            label_cell(ws, row, chk["label"])
            _status_cell(ws, row, 3, chk["status"])
            cell = ws.cell(row=row, column=4, value=chk["detail"])
            cell.font = font(9)
            row += 1
    # football field: stacked bar (transparent low + coloured range)
    if methods:
        chart = BarChart()
        chart.type = "bar"
        chart.grouping = "stacked"
        chart.overlap = 100
        cats = Reference(ws, min_col=2, min_row=first, max_row=lastm)
        base = Reference(ws, min_col=3, min_row=first - 1, max_row=lastm)
        length = Reference(ws, min_col=9, min_row=first - 1, max_row=lastm)
        chart.add_data(base, titles_from_data=True)
        chart.add_data(length, titles_from_data=True)
        chart.set_categories(cats)
        chart.series[0].graphicalProperties.noFill = True
        chart.series[0].graphicalProperties.line.noFill = True
        chart.series[1].graphicalProperties.solidFill = chart_colours()[0]
        chart.series[1].graphicalProperties.line.solidFill = chart_colours()[0]
        _style_chart(chart, f"Football field: equity value ({ctx.unit})", legend=False)
        chart.y_axis.title = ctx.unit
        chart.x_axis.scaling.orientation = "maxMin"
        ws.add_chart(chart, f"B{row + 2}")
        r.cells["ff_anchor_rows"] = f"{first}|{lastm}"
    ws.column_dimensions["I"].hidden = True
    ws.freeze_panes = "C5"


def _status_cell(ws: Worksheet, row: int, column: int, status: str) -> None:
    c = colours()
    look = {
        "pass": ("● Pass", c["positive"], c["positive_bg"]),
        "warn": ("▲ Check", c["warning"], c["warning_bg"]),
        "fail": ("■ Fail", c["negative"], c["negative_bg"]),
        "high": ("■ High", c["negative"], c["negative_bg"]),
        "medium": ("▲ Medium", c["warning"], c["warning_bg"]),
        "none": ("● No concern", c["positive"], c["positive_bg"]),
    }.get(status, ("– Not tested", c["grey_600"], c["grey_100"]))
    cell = ws.cell(row=row, column=column, value=look[0])
    cell.font = font(9, bold=True, colour=look[1])
    cell.fill = fill(look[2])
    cell.alignment = Alignment(horizontal="center")


# ── Financials ──────────────────────────────────────────────────────────────────
_TOKEN = re.compile(r"[a-z_][a-z0-9_]*")


def build_financials(wb: Workbook, ctx: ExportContext, r: Refs) -> None:
    ws = wb.create_sheet("Financials")
    grid = ctx.grid
    periods = [p for p in grid["periods"] if p.get("kind", "annual") in ("annual", "fy")] or grid["periods"]
    keys = [p["key"] for p in periods] + [p["key"] for p in grid.get("ltm_periods", [])]
    heads = [f"{p['key']}A" if not p["key"].endswith("A") else p["key"] for p in periods] + [
        p["label"] for p in grid.get("ltm_periods", [])
    ]
    proj_labels = r["labels"].split("|") if r.get("labels") else []
    ncols = len(keys) + len(proj_labels)
    widths = {"B": 38} | {col(3 + i): 11 for i in range(ncols)}
    setup_sheet(ws, widths=widths, landscape=True, tab_colour=colours()["navy"])
    back_link(ws)
    s = ctx.scale
    last = 2 + ncols
    row = band(ws, 3, f"Financial analysis ({ctx.unit}; A = actual, E = DealScout projection)", last)
    shade = [False] + [False] * len(keys) + [True] * len(proj_labels)
    concept_rows: dict[str, int] = {}
    for st in grid["statements"]:
        row = subhead(ws, row + 1, st["label"], last)
        row = header_row(ws, row, [f"{ctx.unit}", *heads, *proj_labels], shade=shade)
        first = row
        rows_in: dict[str, int] = {}
        for item in st["rows"]:
            if not any(item["cells"].get(k) and item["cells"][k].get("value") is not None for k in keys):
                continue
            rows_in[item["concept_id"]] = row
            row += 1
        for item in st["rows"]:
            rr = rows_in.get(item["concept_id"])
            if rr is None:
                continue
            bold = item["aggregation"] != "leaf"
            label_cell(ws, rr, item["name"], bold=bold, indent=int(item.get("indent", 0)))
            unit_scale = s if item["unit"] == "currency" else 1
            for i, k in enumerate(keys):
                cell = item["cells"].get(k)
                if not cell or cell.get("value") is None:
                    continue
                formula = _formula_for(item, rows_in, col(3 + i))
                if formula and cell.get("kind") == "computed":
                    value_cell(ws, rr, 3 + i, formula, NUM, bold=bold)
                else:
                    kind = "input" if cell.get("kind") == "entered" else "value"
                    value_cell(
                        ws,
                        rr,
                        3 + i,
                        cell["value"] / unit_scale,
                        NUM if item["unit"] == "currency" else PCT if item["unit"] == "percent" else "#,##0.00",
                        kind=kind,
                        bold=bold,
                    )
            concept_rows.setdefault(item["concept_id"], rr)
        if rows_in:
            zebra(ws, first, max(rows_in.values()), 2, last)
    # projections (income statement lines link to the live Projections tab)
    proj_map = {"revenue": "proj_revenue", "ebitda": "proj_ebitda", "ebit": "proj_ebit"}
    for cid, key in proj_map.items():
        if cid in concept_rows and r.get(key):
            for t in range(len(proj_labels)):
                value_cell(
                    ws, concept_rows[cid], 3 + len(keys) + t, f"='Projections'!{col(4 + t)}{r[key]}", NUM, kind="link"
                )
    # growth and margin rows (formulas) under the key lines
    row += 1
    row = subhead(ws, row, "Growth and margins", last)
    row = header_row(ws, row, ["", *heads, *proj_labels], shade=shade)
    n_all = len(keys) + len(proj_labels)
    for cid, label in (("revenue", "Revenue growth"), ("ebitda", "EBITDA growth")):
        if cid in concept_rows:
            label_cell(ws, row, label, italic=True, indent=1)
            for i in range(1, n_all):
                c, p = col(3 + i), col(2 + i)
                rr = concept_rows[cid]
                value_cell(ws, row, 3 + i, f'=IF(N({p}{rr})>0,{c}{rr}/{p}{rr}-1,"")', PCT, italic=True)
            row += 1
    for cid, label in (
        ("gross_profit", "Gross margin"),
        ("ebitda", "EBITDA margin"),
        ("ebit", "EBIT margin"),
        ("net_income", "Net margin"),
    ):
        if cid in concept_rows and "revenue" in concept_rows:
            label_cell(ws, row, label, italic=True, indent=1)
            for i in range(n_all):
                c = col(3 + i)
                value_cell(
                    ws,
                    row,
                    3 + i,
                    f'=IF(N({c}{concept_rows["revenue"]})>0,{c}{concept_rows[cid]}/{c}{concept_rows["revenue"]},"")',
                    PCT,
                    italic=True,
                )
            r.cells[f"fin_{cid}_margin_row"] = str(row)
            row += 1
    # balance check
    ta, tl, te = (concept_rows.get(k) for k in ("total_assets", "total_liabilities", "total_equity"))
    if ta and tl and te:
        label_cell(ws, row, "Balance sheet balances (assets = liabilities + equity)", italic=True)
        for i in range(len(keys)):
            c = col(3 + i)
            value_cell(
                ws,
                row,
                3 + i,
                f'=IF(OR({c}{ta}="",{c}{tl}="",{c}{te}=""),"",IF(ABS({c}{ta}-{c}{tl}-{c}{te})<0.5,"✓","✗"))',
                "@",
            )
        ws.conditional_formatting.add(
            f"C{row}:{col(2 + len(keys))}{row}",
            CellIsRule(
                operator="equal",
                formula=['"✗"'],
                font=font(10, bold=True, colour=colours()["negative"]),
                fill=fill(colours()["negative_bg"]),
            ),
        )
        ws.conditional_formatting.add(
            f"C{row}:{col(2 + len(keys))}{row}",
            CellIsRule(operator="equal", formula=['"✓"'], font=font(10, bold=True, colour=colours()["positive"])),
        )
        row += 1
    r.cells["fin_rows"] = "|".join(f"{k}:{v}" for k, v in concept_rows.items())
    r.cells["fin_keys"] = "|".join(keys)

    # ratios (engine)
    row += 1
    row = band(ws, row, "Ratio analysis (DealScout engine)", last)
    ratio_rows: dict[str, int] = {}
    groups = ["growth", "profitability", "returns", "cash", "leverage", "liquidity", "efficiency"]
    by_id: dict[str, dict[str, Any]] = {}
    for rt in ctx.analysis["ratios"]:
        by_id.setdefault(rt["ratio_id"], {"label": rt["label"], "group": rt["group"], "unit": rt["unit"], "values": {}})
        by_id[rt["ratio_id"]]["values"][rt["period_id"]] = rt["value"]
    akeys = ctx.analysis["periods"]
    for g in groups:
        items = [
            (rid, v) for rid, v in by_id.items() if v["group"] == g and any(x is not None for x in v["values"].values())
        ]
        if not items:
            continue
        row = subhead(ws, row, g.capitalize() if g != "cash" else "Cash flow quality", last)
        row = header_row(ws, row, ["", *akeys])
        for rid, v in items:
            fmt = {"pct": PCT, "x": MULT, "days": "0", "currency": NUM}.get(v["unit"], "0.00")
            label_cell(ws, row, v["label"])
            for i, k in enumerate(akeys):
                val = v["values"].get(k)
                if val is None:
                    continue
                value_cell(ws, row, 3 + i, val / s if v["unit"] == "currency" else val, fmt, kind="value")
            ratio_rows[rid] = row
            row += 1
    r.cells["ratio_rows"] = "|".join(f"{k}:{v}" for k, v in ratio_rows.items())
    r.cells["ratio_keys"] = "|".join(akeys)
    row = _sector_kpi_rows(ws, ctx, row, akeys)

    # scores
    scores = ctx.analysis.get("scores", {}).get("items", [])
    if scores:
        row = subhead(ws, row + 1, f"Scores ({ctx.analysis['scores'].get('period')})", last)
        for sc in scores:
            label_cell(
                ws, row, f"{sc['name']}{' (' + sc['variant'].replace('_', ' ') + ')' if sc.get('variant') else ''}"
            )
            value_cell(ws, row, 3, None if sc.get("missing") else sc["value"], "0.00", kind="value")
            band_text = (sc.get("zone") or "").capitalize() or (
                "Partial: " + ", ".join(sc["missing"][:2]) if sc.get("missing") else ""
            )
            cell = ws.cell(
                row=row,
                column=4,
                value=(band_text + (" · indicative" if sc["name"] == "Beneish M" else "")).strip(" ·"),
            )
            cell.font = font(9, italic=True)
            row += 1
    # normalisation
    adjusted = [a for a in ctx.analysis.get("adjusted", []) if a["items"]]
    if adjusted:
        row = subhead(ws, row + 1, f"Normalisation: reported to adjusted EBITDA ({ctx.unit})", last)
        for m in adjusted:
            label_cell(ws, row, f"Reported EBITDA {m['period']}", bold=True)
            value_cell(ws, row, 3, (m["reported_ebitda"] or 0) / s, NUM, kind="value", bold=True)
            top = row
            row += 1
            for item in m["items"]:
                if not (
                    item.get("affects_ebitda")
                    if item.get("affects_ebitda") is not None
                    else item["category"] != "impairment"
                ):
                    continue
                label_cell(ws, row, f"Remove: {item['label']}", indent=1)
                value_cell(ws, row, 3, -item["amount"] / s, NUM, kind="input")
                row += 1
            label_cell(ws, row, f"Adjusted EBITDA {m['period']}", bold=True)
            value_cell(ws, row, 3, f"=SUM(C{top}:C{row - 1})", NUM, bold=True)
            row += 2
    ws.freeze_panes = "C5"

    # charts: revenue and EBITDA (bars), margin (separate chart: no dual axis), leverage and returns trends
    _financial_charts(ws, ctx, r, concept_rows, keys, proj_labels, row + 1)


def _sector_kpi_rows(ws: Worksheet, ctx: ExportContext, row: int, akeys: list[str]) -> int:
    """Sector KPIs (engine values) under the ratios, only for sectors with a KPI set and only rows with a value."""
    sector = ctx.analysis.get("sector_kpis") or {}
    by_id: dict[str, dict[str, Any]] = {}
    for k in sector.get("items", []):
        entry = by_id.setdefault(k["ratio_id"], {"label": k["label"], "unit": k["unit"], "values": {}})
        entry["values"][k["period_id"]] = k["value"]
    items = [v for v in by_id.values() if any(x is not None for x in v["values"].values())]
    if not items:
        return row
    last = 2 + len(akeys)
    row = subhead(ws, row, f"{sector.get('label') or 'Sector KPIs'} (reported or computed by DealScout)", last)
    row = header_row(ws, row, ["", *akeys])
    for v in items:
        fmt = {"pct": PCT, "x": MULT, "currency": NUM}.get(v["unit"], "#,##0")
        label_cell(ws, row, v["label"])
        for i, k in enumerate(akeys):
            val = v["values"].get(k)
            if val is None:
                continue
            value_cell(ws, row, 3 + i, val / ctx.scale if v["unit"] == "currency" else val, fmt, kind="value")
        row += 1
    return row


def _formula_for(item: dict[str, Any], rows_in: dict[str, int], c: str) -> str | None:
    """A subtotal as a formula over the rows above, when every input row is on the sheet."""
    if item["aggregation"] == "sum" and item.get("formula"):
        parts = [p.strip() for p in item["formula"].split("+")]
        if parts and all(p in rows_in for p in parts):
            return "=" + "+".join(f"{c}{rows_in[p]}" for p in parts)
        return None
    if item["aggregation"] == "formula" and item.get("formula"):
        tokens = set(_TOKEN.findall(item["formula"]))
        if tokens and all(t in rows_in for t in tokens):
            return "=" + _TOKEN.sub(lambda m: f"{c}{rows_in[m.group(0)]}", item["formula"])
    return None


def _financial_charts(
    ws: Worksheet, ctx: ExportContext, r: Refs, rows: dict[str, int], keys: list[str], proj: list[str], at: int
) -> None:
    n = len(keys) + len(proj)
    if "revenue" in rows and n:
        chart = BarChart()
        chart.type = "col"
        cats = Reference(ws, min_col=3, max_col=2 + n, min_row=_header_row_for(ws, rows["revenue"]))
        for cid in ("revenue", "ebitda"):
            if cid in rows:
                data = Reference(ws, min_col=2, max_col=2 + n, min_row=rows[cid])
                chart.add_data(data, from_rows=True, titles_from_data=True)
        chart.set_categories(cats)
        _colour_series(chart)
        _style_chart(chart, f"Revenue and EBITDA ({ctx.unit})")
        ws.add_chart(chart, f"B{at}")
        mrow = r.get("fin_ebitda_margin_row")
        if mrow:
            line = LineChart()
            line.add_data(
                Reference(ws, min_col=2, max_col=2 + n, min_row=int(mrow)), from_rows=True, titles_from_data=True
            )
            line.set_categories(cats)
            _colour_series(line, line=True)
            _style_chart(line, "EBITDA margin", legend=False)
            line.y_axis.numFmt = "0%"
            ws.add_chart(line, f"{col(10)}{at}")
    ratio_rows = r.pairs("ratio_rows")
    akeys = r.items("ratio_keys")
    for i, (ids, title, fmt) in enumerate(
        (
            (["net_debt_to_ebitda"], "Leverage (net debt / EBITDA)", "0.0x"),
            (["roic", "roe"], "Returns (ROIC, ROE)", "0%"),
            (["dso", "dio", "dpo"], "Working capital days", "0"),
        )
    ):
        present = [x for x in ids if x in ratio_rows]
        if not present or not akeys:
            continue
        line = LineChart()
        for x in present:
            line.add_data(
                Reference(ws, min_col=2, max_col=2 + len(akeys), min_row=int(ratio_rows[x])),
                from_rows=True,
                titles_from_data=True,
            )
        line.set_categories(
            Reference(
                ws,
                min_col=3,
                max_col=2 + len(akeys),
                min_row=int(ratio_rows[present[0]]) - _offset_to_header(ws, int(ratio_rows[present[0]])),
            )
        )
        _colour_series(line, line=True)
        _style_chart(line, title, legend=len(present) > 1)
        line.y_axis.numFmt = fmt
        ws.add_chart(line, f"{col(2 if i % 2 == 0 else 10)}{at + 16 + 16 * (i // 2)}")


def _header_row_for(ws: Worksheet, row: int) -> int:
    """The header row of the table a data row belongs to (the nearest row above whose first label is the unit)."""
    for rr in range(row - 1, 3, -1):
        v = ws.cell(row=rr, column=3).value
        if isinstance(v, str) and ws.cell(row=rr, column=3).font and ws.cell(row=rr, column=3).font.b:
            return rr
    return row - 1


def _offset_to_header(ws: Worksheet, row: int) -> int:
    return row - _header_row_for(ws, row)


# ── Report ───────────────────────────────────────────────────────────────────────
def build_report(wb: Workbook, ctx: ExportContext, r: Refs, tabs: list[str]) -> None:
    ws = wb["Report"]
    setup_sheet(
        ws, widths={"B": 26, "C": 16, "D": 16, "E": 16, "F": 16, "G": 16, "H": 16}, tab_colour=colours()["navy"]
    )
    c = colours()
    deal = ctx.deal
    dq = ctx.recommendation["data_quality"]
    last = 8
    # header band
    for rr in (2, 3, 4):
        for cc in range(2, last + 1):
            ws.cell(row=rr, column=cc).fill = fill(c["navy"])
    ws.cell(row=2, column=2, value="DealScout").font = font(9, bold=True, colour=c["accent_100"])
    ws.cell(row=3, column=2, value=deal.name).font = font(22, bold=True, colour="FFFFFF")
    ws.row_dimensions[3].height = 30
    meta = (
        f"{ctx.country_name} · {ctx.sector_name} · {ctx.unit} · valuation date {deal.valuation_date:%d %b %Y} · "
        f"generated {ctx.generated:%d %b %Y %H:%M} UTC"
    )
    ws.cell(row=4, column=2, value=meta).font = font(9, colour="FFFFFF")
    badge = ws.cell(row=2, column=last, value=f"Data quality {dq['score']}/100 · {dq['grade']}")
    badge.font = font(9, bold=True, colour=c["navy"])
    badge.fill = fill(
        {"A": c["positive_bg"], "B": c["positive_bg"], "C": c["warning_bg"], "D": c["negative_bg"]}[dq["grade"]]
    )
    badge.alignment = Alignment(horizontal="center")
    # AI notice
    ws.merge_cells(start_row=6, start_column=2, end_row=8, end_column=last)
    notice = ws.cell(row=6, column=2, value=ctx.disclaimers["ai_report_notice"])
    notice.font = font(9, bold=True, colour=c["warning"])
    notice.fill = fill(c["warning_bg"])
    notice.alignment = Alignment(wrap_text=True, vertical="center")
    for rr in (6, 7, 8):
        ws.row_dimensions[rr].height = 18
    # contents
    row = 10
    ws.cell(row=row, column=2, value="Contents").font = font(10, bold=True, colour=c["navy"])
    for i, name in enumerate(tabs):
        cell = ws.cell(row=row, column=3 + i % 6, value=name)
        if i % 6 == 5:
            row += 1
        cell.hyperlink = f"#'{name}'!A1"
        cell.font = font(9, colour=c["accent"])
    row += 2

    rec = ctx.recommendation.get("recommendation")
    rat = ctx.recommendation.get("rationale") or {}
    # executive summary
    row = band(ws, row, "Executive summary", last)
    bullets = _summary_bullets(ctx)
    for b in bullets:
        ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=last)
        cell = ws.cell(row=row, column=2, value=f"•  {b}")
        cell.font = font(10)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 28 if len(b) > 95 else 15
        row += 1
    row += 1
    # key metrics (formulas linking to Financials / Valuation Summary)
    row = band(ws, row, "Key metrics", last)
    tiles = _kpi_tiles(ctx, r)
    for i, (label, formula, fmt, hint) in enumerate(tiles):
        cc = [2, 3, 5, 7][i % 4]
        rr = row + (i // 4) * 3
        lab = ws.cell(row=rr, column=cc, value=label)
        lab.font = font(8, colour=c["grey_600"])
        value_cell(ws, rr + 1, cc, formula, fmt, kind="link", bold=True)
        ws.cell(row=rr + 1, column=cc).font = font(13, bold=True, colour=c["navy"])
        ws.cell(row=rr + 1, column=cc).alignment = Alignment(horizontal="left")
        h = ws.cell(row=rr + 2, column=cc, value=hint)
        h.font = font(8, italic=True, colour=c["grey_600"])
    row += ((len(tiles) + 3) // 4) * 3 + 1

    # valuation snapshot
    row = band(ws, row, f"Valuation snapshot ({ctx.unit})", last)
    if r.get("blend_mid"):
        lines = [
            (
                "Blended equity value: low / mid / high",
                [f"={r['blend_low']}", f"={r['blend_mid']}", f"={r['blend_high']}"],
                NUM,
            ),
            ("Per diluted share: low / mid / high", [f"={r['ps_low']}", f"={r['ps_mid']}", f"={r['ps_high']}"], PRICE),
            ("Implied EV / EBITDA at mid", [f"={r['impl_EV / EBITDA']}"], MULT),
            ("Implied P / E at mid", [f"={r['impl_P / E']}"], MULT),
            ("Premium to market capitalisation at mid", [f"={r['premium_mid']}"], PCT),
        ]
        for label, formulas, fmt in lines:
            label_cell(ws, row, label)
            for i, f in enumerate(formulas):
                value_cell(ws, row, 5 + i, f, fmt, kind="link")
            row += 1
        if rec:
            for chk in rec.get("checks", []):
                label_cell(ws, row, chk["label"])
                _status_cell(ws, row, 5, chk["status"])
                row = _wrapped(ws, row, chk["detail"], last, start=6)
        _mini_football_field(wb, ws, r, row + 1)
        row += 17
    else:
        label_cell(ws, row, "No valuation yet: complete the DCF inputs or another method.")
        row += 2

    # rationale
    if rat:
        row = band(ws, row, "Rationale", last)
        for b in rat.get("bullets", []):
            row = _wrapped(ws, row, f"•  {b}", last)
        row = subhead(ws, row + 1, "Key risks", last)
        for b in rat.get("risks", []):
            row = _wrapped(ws, row, f"•  {b}", last)
        row = subhead(ws, row + 1, "What would need to be true for the high end", last)
        for b in rat.get("high_end", []) or ["No single method sets the high end."]:
            row = _wrapped(ws, row, f"•  {b}", last)
        src = "AI-written (numbers from the engine)" if rat.get("source") != "template" else "Standard wording"
        ws.cell(row=row, column=2, value=f"{src}.").font = font(8, italic=True, colour=c["grey_600"])
        row += 2

    # breakdowns: segment and geography mix, costs, margin bridge, cash flow, working capital, capital structure
    from .report_breakdowns import add_breakdowns  # imports this module

    row = add_breakdowns(wb, ws, ctx, r, row)

    # early warning signs and strengths
    flags = ctx.analysis.get("red_flags", [])
    row = band(ws, row, "Early warning signs", last)
    row = header_row(ws, row, ["Signal", "Period", "Metric", "Severity", "Why it matters", "", ""])
    concerns = [f for f in flags if f["severity"] != "none"]
    for f in concerns or []:
        label_cell(ws, row, f["signal"])
        ws.cell(row=row, column=3, value=f["period"]).font = font(9)
        from_text = f.get("source") == "document"
        if from_text and f["metric"] is None:
            ws.cell(row=row, column=4, value="Text").font = font(9, italic=True)
        else:
            value_cell(ws, row, 4, f["metric"], PCT if from_text else "0.00", kind="value")
        _status_cell(ws, row, 5, f["severity"])
        why = f"{f['explanation']} (threshold {f['threshold']})"
        if from_text and f.get("evidence"):
            why += " " + _evidence_text(f["evidence"])
        row = _wrapped(ws, row, why, last, start=6)
    for sc in ctx.analysis.get("scores", {}).get("items", []):
        if sc["name"] == "Altman Z" and sc.get("zone") in ("distress", "grey"):
            label_cell(ws, row, f"Altman Z in the {sc['zone']} zone")
            _status_cell(ws, row, 5, "high" if sc["zone"] == "distress" else "medium")
            row = _wrapped(ws, row, "Bankruptcy-risk score below the safe threshold.", last, start=6)
        if sc["name"] == "Beneish M" and sc.get("value") is not None and sc["value"] > -1.78:
            label_cell(ws, row, "Beneish M above −1.78")
            _status_cell(ws, row, 5, "medium")
            row = _wrapped(
                ws, row, "Indicative earnings-manipulation screen flags the accounts for closer review.", last, start=6
            )
    if not concerns:
        ws.cell(
            row=row, column=2, value="No warning signs from the rules that could be tested with the figures entered."
        ).font = font(9, italic=True)
        row += 1
    strengths = _strengths(ctx)
    row = subhead(ws, row + 1, "Strengths", last)
    for s_ in strengths or ["None identified from the figures entered."]:
        row = _wrapped(ws, row, f"•  {s_}", last)

    # recommendations
    row = band(ws, row + 1, "Recommended next steps (indicative; further work, not investment advice)", last)
    for i, (step, finding) in enumerate(_next_steps(ctx), start=1):
        row = _wrapped(ws, row, f"{i}. {step} (prompted by {finding})", last)

    # assumptions and limitations
    row = band(ws, row + 1, "Key assumptions and limitations", last)
    res = ctx.valuation["result"]
    defaulted = [a["label"] for a in res["assumptions"] if a["source"] in ("default", "convention")]
    missing = [a["label"] for a in res["assumptions"] if a["source"] == "missing"]
    limitations = [
        f"Market defaults or conventions used for: {', '.join(defaulted) or 'none'}.",
        f"Missing inputs: {', '.join(missing) or 'none'}.",
        f"Documents used: {', '.join(ctx.documents) or 'none (figures entered by hand)'}.",
        f"Data quality {dq['score']}/100 (grade {dq['grade']}). " + " ".join(dq.get("notes", [])),
        "Live models recalculate in this workbook: the DCF chain (Assumptions → WACC → Projections → DCF), LBO, "
        "Precedents and NAV & SOTP. The LBO maximum price (a goal seek), sensitivity tables and the other methods are "
        "DealScout engine outputs shown as values.",
    ]
    for line in limitations:
        row = _wrapped(ws, row, line, last)
    row += 1
    ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=last)
    foot = ws.cell(row=row, column=2, value=ctx.disclaimers["print_footer"])
    foot.font = font(8, italic=True, colour=c["grey_600"])
    ws.print_area = f"A1:{col(last)}{row}"


def _evidence_text(evidence: list[dict[str, Any]]) -> str:
    """'Source: p. 4, report.pdf: "quote"' for each quoted page of a document-based warning sign."""
    return " ".join(f'Source: p. {e["page"]}, {e["filename"]}: "{e["snippet"]}"' for e in evidence[:2])


def _wrapped(ws: Worksheet, row: int, text: str, last: int, *, start: int = 2) -> int:
    ws.merge_cells(start_row=row, start_column=start, end_row=row, end_column=last)
    cell = ws.cell(row=row, column=start, value=text)
    cell.font = font(9)
    cell.alignment = Alignment(wrap_text=True, vertical="top")
    width_chars = 16 * (last - start + 1) + (10 if start == 2 else 0)
    ws.row_dimensions[row].height = 13 * max(1, -(-len(text) // max(width_chars, 1)))
    return row + 1


def _money(v: float | None, ctx: ExportContext) -> str:
    if v is None:
        return "n/m"
    a = abs(v)
    div, suffix = (1e9, "bn") if a >= 1e9 else (1e6, "m") if a >= 1e6 else (1e3, "k") if a >= 1e3 else (1, "")
    return f"{'−' if v < 0 else ''}{ctx.currency} {a / div:,.{0 if a / div >= 100 else 1}f}{suffix}"


def _summary_bullets(ctx: ExportContext) -> list[str]:
    deal = ctx.deal
    res = ctx.valuation["result"]
    rec = ctx.recommendation.get("recommendation")
    out = [
        f"{deal.name} is a {'listed' if deal.listed else 'private'} {ctx.sector_name.lower()} company"
        f"{(' (' + deal.industry + ')') if deal.industry else ''} in {ctx.country_name}, analysed from the "
        f"{'financial sponsor' if deal.perspective == 'financial_sponsor' else 'strategic buyer'} perspective.",
    ]
    cagr = ctx.analysis.get("revenue_cagr", {})
    if res.get("base_revenue"):
        margin = (res.get("base_ebitda") or 0) / res["base_revenue"] if res["base_revenue"] else None
        growth = (
            f", revenue growing {cagr['value']:.1%} a year from {cagr['from']} to {cagr['to']}"
            if cagr.get("value") is not None
            else ""
        )
        out.append(
            f"Latest year ({res.get('base_period')}): revenue {_money(res['base_revenue'], ctx)} and EBITDA "
            f"{_money(res.get('base_ebitda'), ctx)}"
            + (f" ({margin:.1%} margin)" if margin is not None else "")
            + f"{growth}."
        )
    high = [f for f in ctx.analysis.get("red_flags", []) if f["severity"] == "high"]
    out.append(
        f"{len(high)} high-severity warning sign(s) found."
        if high
        else "No high-severity warning signs from the rules tested."
    )
    if rec:
        out.append(
            f"Blended equity value {_money(rec['equity_low'], ctx)} to {_money(rec['equity_high'], ctx)} (mid {_money(rec['equity_mid'], ctx)}); "
            "this is the suggested acquisition price range for 100% of the equity."
        )
        fails = [c_ for c_ in rec.get("checks", []) if c_["status"] in ("warn", "fail")]
        if fails:
            out.append("Checks to resolve: " + "; ".join(c_["label"] for c_ in fails) + ".")
    dq = ctx.recommendation["data_quality"]
    out.append(f"Data quality {dq['score']}/100 (grade {dq['grade']}).")
    return out[:6]


def _kpi_tiles(ctx: ExportContext, r: Refs) -> list[tuple[str, str, str, str]]:
    fin_rows = r.pairs("fin_rows")
    keys = r.items("fin_keys")
    ratio_rows = r.pairs("ratio_rows")
    akeys = r.items("ratio_keys")
    base = ctx.valuation["result"].get("base_period")
    tiles: list[tuple[str, str, str, str]] = []

    def fin_cell(cid: str) -> str | None:
        if cid not in fin_rows or base not in keys:
            return None
        return f"'Financials'!{col(3 + keys.index(base))}{fin_rows[cid]}"

    def ratio_cell(rid: str) -> str | None:
        if rid not in ratio_rows or base not in akeys:
            return None
        return f"'Financials'!{col(3 + akeys.index(base))}{ratio_rows[rid]}"

    for cid, label in (("revenue", "Revenue"), ("ebitda", "EBITDA"), ("net_income", "Net income")):
        cell = fin_cell(cid)
        if cell:
            tiles.append((f"{label} ({ctx.unit})", f"={cell}", NUM, base or ""))
    for rid, label, fmt in (
        ("ebitda_margin", "EBITDA margin", PCT),
        ("free_cash_flow", f"Free cash flow ({ctx.unit})", NUM),
        ("net_debt_to_ebitda", "Net debt / EBITDA", MULT),
        ("roic", "ROIC", PCT),
    ):
        cell = ratio_cell(rid)
        if cell:
            tiles.append((label, f"={cell}", fmt, base or ""))
    cagr = ctx.analysis.get("revenue_cagr", {})
    if cagr.get("value") is not None:
        tiles.append(("Revenue CAGR", f"={cagr['value']}", PCT, f"{cagr['from']}–{cagr['to']} (engine)"))
    return tiles[:8]


def _strengths(ctx: ExportContext) -> list[str]:
    out = []
    for sc in ctx.analysis.get("scores", {}).get("items", []):
        if sc["name"] == "Altman Z" and sc.get("zone") == "safe":
            out.append(f"Altman Z of {sc['value']:.2f} is in the safe zone.")
        if sc["name"] == "Piotroski F" and sc.get("value") is not None and sc["value"] >= 7 and not sc.get("missing"):
            out.append(f"Piotroski F-score of {sc['value']:.0f} of 9 signals strong fundamentals.")
    clean = {f["signal"] for f in ctx.analysis.get("red_flags", []) if f["severity"] == "none"}
    if clean:
        out.append("No concern on: " + ", ".join(sorted(clean)[:5]).lower() + ".")
    rec = ctx.recommendation.get("recommendation") or {}
    passes = [c_["label"] for c_ in rec.get("checks", []) if c_["status"] == "pass"]
    if passes:
        out.append("Price checks passed: " + ", ".join(passes) + ".")
    return out


def _next_steps(ctx: ExportContext) -> list[tuple[str, str]]:
    steps: list[tuple[str, str]] = []
    for f in ctx.analysis.get("red_flags", []):
        if f["severity"] == "high":
            steps.append((f"Investigate {f['signal'].lower()} with management", f"early warning sign ({f['period']})"))
    rec = ctx.recommendation.get("recommendation") or {}
    for c_ in rec.get("checks", []):
        if c_["label"] == "LBO affordability" and c_["status"] != "pass":
            steps.append(
                (
                    "Deprioritise or renegotiate: the mid price does not clear the target IRR with this financing",
                    "LBO affordability check",
                )
            )
        if c_["label"] == "Control premium" and c_["status"] == "warn":
            steps.append(
                ("Reconcile the implied premium with recent takeovers in this market", "control premium check")
            )
        if c_["label"] == "Synergies paid away" and c_["status"] != "pass":
            steps.append(("Validate the synergy case before paying away more than half of it", "synergy check"))
    warnings = " ".join(ctx.valuation["result"].get("warnings", []))
    if "Terminal value" in warnings:
        steps.append(
            ("Test the valuation at a 200 bp higher WACC and a lower exit multiple", "terminal value above 75% of EV")
        )
    dq = ctx.recommendation["data_quality"]
    if dq["score"] < 70:
        steps.append(
            (
                "Verify extracted figures against the source documents and request management accounts",
                f"data quality grade {dq['grade']}",
            )
        )
    if any(a["source"] == "missing" for a in ctx.valuation["result"]["assumptions"]):
        steps.append(("Fill the missing inputs listed below before relying on the range", "missing inputs"))
    if len(steps) < 4:
        steps.append(("Proceed to full due diligence on the figures and assumptions", "screening complete"))
    if len(steps) < 4:
        steps.append(("Request the latest interim accounts to update the LTM figures", "recency of data"))
    return steps[:8]


def _mini_football_field(wb: Workbook, ws: Worksheet, r: Refs, row: int) -> None:
    anchor = r.get("ff_anchor_rows")
    if not anchor:
        return
    first, lastm = (int(x) for x in anchor.split("|"))
    vs = wb["Valuation Summary"]
    chart = BarChart()
    chart.type = "bar"
    chart.grouping = "stacked"
    chart.overlap = 100
    chart.add_data(Reference(vs, min_col=3, min_row=first - 1, max_row=lastm), titles_from_data=True)
    chart.add_data(Reference(vs, min_col=9, min_row=first - 1, max_row=lastm), titles_from_data=True)
    chart.set_categories(Reference(vs, min_col=2, min_row=first, max_row=lastm))
    chart.series[0].graphicalProperties.noFill = True
    chart.series[0].graphicalProperties.line.noFill = True
    chart.series[1].graphicalProperties.solidFill = chart_colours()[0]
    chart.series[1].graphicalProperties.line.solidFill = chart_colours()[0]
    _style_chart(chart, "Football field: equity value", legend=False)
    chart.x_axis.scaling.orientation = "maxMin"
    chart.width = 17.5
    ws.add_chart(chart, f"B{row}")


# ── method tabs (engine outputs) ─────────────────────────────────────────────────────
def _table(ws: Worksheet, row: int, head: list[str], rows: list[list[Any]], fmts: list[str], last: int) -> int:
    row = header_row(ws, row, head)
    first = row
    for values in rows:
        for i, v in enumerate(values):
            if i == 0:
                label_cell(ws, row, str(v))
            else:
                value_cell(ws, row, 2 + i, v, fmts[i - 1] if i - 1 < len(fmts) else NUM, kind="value")
        row += 1
    if rows:
        zebra(ws, first, row - 1, 2, last)
        _note(ws.cell(row=first, column=3), ENGINE_NOTE)
    return row + 1


def build_method_tabs(wb: Workbook, ctx: ExportContext, r: Refs) -> list[str]:
    s = ctx.scale
    made = []
    peers = ctx.valuation.get("peer_stats") or []
    if any(p.get("n") for p in peers):
        ws = wb.create_sheet("Comps")
        setup_sheet(
            ws, widths={"B": 26} | {col(3 + i): 11 for i in range(7)}, landscape=True, tab_colour=colours()["grey_500"]
        )
        back_link(ws)
        row = band(ws, 3, "Trading comparables: peer multiple statistics (engine)", 9)
        row = _table(
            ws,
            row,
            ["Multiple", "Peers", "Min", "25th", "Median", "Mean", "75th", "Max"],
            [
                [p["label"], p["n"], p["min"], p["p25"], p["median"], p["mean"], p["p75"], p["max"]]
                for p in peers
                if p.get("n")
            ],
            ["0", MULT, MULT, MULT, MULT, MULT, MULT],
            9,
        )
        comps = ctx.valuation["result"].get("comps") or []
        if comps:
            row = band(ws, row, f"Implied values ({ctx.unit})", 9)
            _table(
                ws,
                row,
                ["Multiple", "Target metric", "Low", "Mid", "High", "Equity low", "Equity mid", "Equity high"],
                [
                    [
                        c_["label"],
                        (c_["target_metric"] or 0) / s,
                        c_["multiple_low"],
                        c_["multiple_mid"],
                        c_["multiple_high"],
                        (c_["equity_low"] or 0) / s,
                        (c_["equity_mid"] or 0) / s,
                        (c_["equity_high"] or 0) / s,
                    ]
                    for c_ in comps
                ],
                [NUM, MULT, MULT, MULT, NUM, NUM, NUM],
                9,
            )
        made.append("Comps")
    from .live_methods import build_live_method_tabs

    made += build_live_method_tabs(wb, ctx, r)
    return made


# ── Sources and Disclaimer ───────────────────────────────────────────────────────────
def build_sources(wb: Workbook, ctx: ExportContext) -> None:
    ws = wb.create_sheet("Sources")
    setup_sheet(
        ws,
        widths={"B": 26, "C": 10, "D": 14, "E": 30, "F": 12, "G": 30, "H": 16, "I": 11, "J": 14},
        landscape=True,
        tab_colour=colours()["grey_200"],
    )
    back_link(ws)
    row = band(ws, 3, "Sources: every stored value with its document, location and confidence", 10)
    row = header_row(
        ws,
        row,
        [
            "Concept",
            "Period",
            f"Value ({ctx.unit})",
            "Document",
            "Page / cell",
            "Label in source",
            "As written",
            "Confidence",
            "Method",
        ],
    )
    first = row
    for sr in ctx.sources:
        vals = [
            sr["concept_id"],
            sr["period"],
            sr["value"] / ctx.scale,
            sr["document"] or "Entered by hand",
            sr["location"],
            sr["label"],
            sr["as_written"],
            sr["confidence"],
            sr["method"],
        ]
        for i, v in enumerate(vals):
            cell = ws.cell(row=row, column=2 + i, value=v)
            cell.font = font(9)
            if i == 2:
                cell.number_format = NUM
            if i == 7:
                cell.number_format = "0%"
        row += 1
    if row > first:
        zebra(ws, first, row - 1, 2, 10)
        ws.auto_filter.ref = f"B{first - 1}:J{row - 1}"
    ws.freeze_panes = f"C{first}"
    ws.print_title_rows = f"{first - 1}:{first - 1}"


def build_disclaimer(wb: Workbook, ctx: ExportContext) -> None:
    ws = wb.create_sheet("Disclaimer")
    setup_sheet(ws, widths={"B": 110}, tab_colour=colours()["grey_200"])
    back_link(ws)
    row = band(ws, 3, "Disclaimer", 2)
    for para in [ctx.disclaimers["ai_report_notice"], *ctx.disclaimers["full"]]:
        cell = ws.cell(row=row, column=2, value=para)
        cell.font = font(10)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 14 * max(1, -(-len(para) // 120))
        row += 1


# ── assemble ───────────────────────────────────────────────────────────────────────
def build_workbook(ctx: ExportContext) -> bytes:
    wb = Workbook()
    wb.active.title = "Report"
    r = Refs()
    model = build_assumptions(wb, ctx, r)
    if model:
        build_wacc(wb, ctx, r)
        build_projections(wb, ctx, r)
        build_dcf(wb, ctx, r)
    else:
        for key in ("bridge_range", "shares", "market_cap", "base_revenue", "base_ebitda", "net_income"):
            r.cells.setdefault(key, "0")
        r.cells["bridge_range"] = "0"
    build_financials(wb, ctx, r)
    method_tabs = build_method_tabs(wb, ctx, r)
    build_summary(wb, ctx, r)
    build_sources(wb, ctx)
    build_disclaimer(wb, ctx)
    order = [
        "Report",
        "Financials",
        "Valuation Summary",
        "Assumptions",
        "WACC",
        "Projections",
        "DCF",
        *method_tabs,
        "Sources",
        "Disclaimer",
    ]
    wb._sheets = [wb[name] for name in order if name in wb.sheetnames]
    build_report(wb, ctx, r, [n for n in order if n in wb.sheetnames and n != "Report"])
    generated = f"{ctx.generated:%d %b %Y}"
    for ws in wb.worksheets:
        neutralise_injected_formulas(ws)
        print_header_footer(ws, ctx.deal.name, generated, ctx.disclaimers["print_footer"])
        if ws.title not in ("Report",):
            ws.print_title_rows = ws.print_title_rows or "1:3"
    props = wb.properties
    props.title = f"{ctx.deal.name}: DealScout analysis"
    props.subject = "Indicative acquisition analysis (AI-generated)"
    props.creator = "DealScout (AI-generated)"
    props.lastModifiedBy = "DealScout (AI-generated)"
    wb.active = 0
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
