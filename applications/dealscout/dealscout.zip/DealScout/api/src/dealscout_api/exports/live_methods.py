"""Live method tabs of the "Create Excel" workbook (brief §14A): LBO, Precedents and NAV & SOTP.

Each tab rebuilds the engine's calculation with formulas, so an analyst can change an input (blue) and see the
result update; links to other tabs are green and formulas black. Only functions LibreOffice evaluates are used
(INDEX/MATCH, SUMPRODUCT, PERCENTILE, MEDIAN, IRR, IFERROR).

LBO interest on average balances is circular (interest depends on the closing balance, which depends on the cash left
after interest). Instead of Excel's iterative calculation the tab unrolls the engine's fixed-point solve: the visible
debt schedule is the sixth pass (its average balances use the fifth pass's closing balances), and passes 1 to 5 sit
in a collapsed row group below it. Each pass shrinks the error by roughly rate ÷ 2, so six passes match the engine's converged schedule to well
within rounding. With "interest on average balances" set to 0 every pass is the opening-balance calculation.

The LBO range on the football field (the most a sponsor can pay at the target IRR ± 5pp) is a goal seek, which
needs iterative calculation; it stays an engine value, labelled as such.
"""

from __future__ import annotations

from datetime import date
from typing import Any

from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.chart.series import SeriesLabel
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment
from openpyxl.worksheet.worksheet import Worksheet

from dealscout_engine.valuation.lbo import Tranche

from .context import ExportContext
from .style import (
    MULT,
    NUM,
    PCT,
    PRICE,
    back_link,
    band,
    col,
    colours,
    font,
    header_row,
    label_cell,
    setup_sheet,
    subhead,
    value_cell,
    zebra,
)
from .workbook import ENGINE_NOTE, Refs, _colour_series, _note, _style_chart, _table

PASSES = 6  # solver passes for interest on average balances (the last one is the visible schedule)
DATE = "dd mmm yyyy"


def _muted(ws: Worksheet, row: int, text: str, column: int = 4) -> None:
    cell = ws.cell(row=row, column=column, value=text)
    cell.font = font(8, italic=True, colour=colours()["grey_600"])
    cell.alignment = Alignment(indent=1 if column > 2 else 0)


def _has_model(r: Refs) -> bool:
    return bool(r.get("tax")) and r.get("bridge_range") not in (None, "0")


def _adjustment(ws: Worksheet, row: int, r: Refs, engine_value: float, label: str) -> str:
    """Net EV-to-equity adjustment (cash-like less debt-like): linked to Assumptions when the DCF chain exists."""
    label_cell(ws, row, label)
    if _has_model(r):
        value_cell(ws, row, 3, f"=SUM({r['bridge_range']})", NUM, kind="link")
        _muted(ws, row, "Sum of the bridge items on Assumptions")
    else:
        value_cell(ws, row, 3, engine_value, NUM, kind="input")
        _muted(ws, row, "Net of debt-like and cash-like items (engine)")
    return f"$C${row}"


def _min_med_max(cells: list[str]) -> list[str]:
    joined = ",".join(cells)
    return [f"=MIN({joined})", f"=MEDIAN({joined})", f"=MAX({joined})"]


# ── LBO ──────────────────────────────────────────────────────────────────────────
def build_lbo(wb: Workbook, ctx: ExportContext, r: Refs, res: dict[str, Any]) -> None:
    s = ctx.scale
    ei = res["engine_inputs"]
    ops = ei["operating"]
    n = len(ops)
    models = [Tranche.model_validate(t) for t in ei["tranches"]]
    order = sorted(
        (i for i, t in enumerate(models) if t.sweepable),
        key=lambda i: (models[i].priority, models[i].kind != "revolver"),
    )
    order += [i for i, t in enumerate(models) if not t.sweepable]
    tranches = [models[i] for i in order]
    nt = len(tranches)
    revolver = next((t.name for t in models if t.kind == "revolver"), None)
    recap_name = next((t.name for t in models if t.kind in ("term_loan_b", "term_loan_a")), None)
    model = _has_model(r)

    ws = wb.create_sheet("LBO")
    last = max(15, 3 + n)
    setup_sheet(
        ws, widths={"B": 36} | {col(c): 11 for c in range(3, last + 1)}, landscape=True, tab_colour=colours()["accent"]
    )
    back_link(ws)
    row = band(ws, 3, f"Leveraged buyout: live model ({ctx.unit}; inputs in blue)", last)

    # transaction inputs
    row = subhead(ws, row + 1, "Transaction and exit inputs", last)
    cells: dict[str, str] = {}

    def put(key: str, label: str, value: Any, fmt: str, note: str = "", kind: str = "input") -> None:
        nonlocal row
        label_cell(ws, row, label)
        value_cell(ws, row, 3, value, fmt, kind=kind)
        if note:
            _muted(ws, row, note)
        cells[key] = f"$C${row}"
        row += 1

    if model:
        put("ebitda0", "Entry EBITDA", f"={r['base_ebitda']}", NUM, "Base-year EBITDA on Assumptions", "link")
    else:
        put("ebitda0", "Entry EBITDA", ei["entry_ebitda"] / s, NUM)
    source = res["inputs"].get("entry_source")
    put(
        "mult",
        "Entry EV / EBITDA",
        res["inputs"]["entry_multiple"],
        MULT,
        {"dcf": "Implied by the DCF enterprise value", "price_per_share": "Implied by the offer price per share"}.get(
            source or "", "As entered"
        ),
    )
    if model:
        put("refi", "Existing net debt refinanced", f"=-SUM({r['bridge_range']})", NUM, "EV-to-equity bridge", "link")
    else:
        put("refi", "Existing net debt refinanced", ei["existing_net_debt"] / s, NUM)
    put("fee", "Transaction fees (% of EV)", ei["transaction_fee_pct"], PCT)
    put("min_cash", "Minimum cash", ei["minimum_cash"] / s, NUM, "Left on the balance sheet at close")
    put("rollover", "Rollover equity", ei["rollover_equity"] / s, NUM)
    put("promote", "Management promote (% of exit equity)", ei["management_promote_pct"], PCT)
    if model:
        put("tax", "Tax rate", f"={r['tax']}", PCT, "Assumptions", "link")
    else:
        put("tax", "Tax rate", ei["tax_rate"], PCT)
    put(
        "avg",
        "Interest on average balances (1 = yes)",
        1 if ei["interest_on_average"] else 0,
        "0",
        "0 = opening balances",
    )
    put("sweep", "Cash sweep (% of excess cash)", ei["cash_sweep_pct"], PCT)
    put("exit_year", "Exit year", ei["exit_year"], "0", f"1 to {n}")
    if ei.get("exit_multiple") is None:
        put("exit_mult", "Exit EV / EBITDA", f"={cells['mult']}", MULT, "Default: the entry multiple", "formula")
    else:
        put("exit_mult", "Exit EV / EBITDA", ei["exit_multiple"], MULT)
    put("exit_cost", "Exit costs (% of exit EV)", ei["exit_cost_pct"], PCT)
    put("recap_year", "Dividend recap year (blank = none)", ei.get("dividend_recap_year"), "0")
    put("recap_x", "Dividend recap (x EBITDA of that year)", ei["dividend_recap_x_ebitda"], MULT)
    put("max_lev", "Covenant: maximum net debt / EBITDA", ei.get("max_leverage"), MULT, "Blank = not tested")
    put(
        "min_cov",
        "Covenant: minimum EBITDA / cash interest",
        ei.get("min_interest_coverage"),
        MULT,
        "Blank = not tested",
    )
    put("target", "Target sponsor IRR", ei["target_irr"], PCT, "Reference for the engine's maximum price below")

    # tranches
    row = subhead(ws, row + 1, f"Debt tranches ({ctx.unit}; rows in cash-sweep order)", last)
    heads = [
        "Tranche",
        "Kind",
        "Size (x EBITDA)",
        "Amount",
        "Rate type",
        "Fixed rate",
        "Margin",
        "Base floor",
        "Amortisation",
        "PIK (1 = yes)",
        "Sweep (1 = yes)",
        "Fee",
        "Commitment",
        "Principal",
    ]
    row = header_row(ws, row, heads)
    tr_first = row
    tr_row: dict[str, int] = {}
    for t in tranches:
        tr_row[t.name] = row
        label_cell(ws, row, t.name)
        ws.cell(row=row, column=3, value=t.kind.replace("_", " ")).font = font(9)
        value_cell(ws, row, 4, t.size_x_ebitda, MULT, kind="input")
        value_cell(ws, row, 5, None if t.amount is None else t.amount / s, NUM, kind="input")
        cell = ws.cell(row=row, column=6, value=t.rate_type)
        cell.font = font(10, colour="0000FF")
        cell.alignment = Alignment(horizontal="right")
        value_cell(ws, row, 7, t.fixed_rate, PCT, kind="input")
        value_cell(ws, row, 8, t.margin, PCT, kind="input")
        value_cell(ws, row, 9, t.base_rate_floor, PCT, kind="input")
        value_cell(ws, row, 10, t.amortization_pct, PCT, kind="input")
        value_cell(ws, row, 11, 1 if t.pik else 0, "0", kind="input")
        value_cell(ws, row, 12, 1 if t.sweepable else 0, "0", kind="input")
        value_cell(ws, row, 13, t.fee_pct, PCT, kind="input")
        value_cell(ws, row, 14, None if t.commitment is None else t.commitment / s, NUM, kind="input")
        value_cell(ws, row, 15, f"=IF(ISNUMBER(E{row}),E{row},N(D{row})*{cells['ebitda0']})", NUM, bold=True)
        row += 1
    tr_last = max(row - 1, tr_first)
    if not tranches:
        label_cell(ws, row, "No debt tranches: the returns are unlevered.", italic=True)
        row += 1
    principal = f"$O${tr_first}:$O${tr_last}"
    pik_range = f"$K${tr_first}:$K${tr_last}"
    _muted(
        ws,
        row,
        "Rate type: fixed or floating (base rate + margin, base floored). Principal = amount, else size × entry EBITDA. "
        "To change the sweep order, change the priority in DealScout.",
        2,
    )
    row += 1

    # sources and uses
    row = subhead(ws, row + 1, f"Sources and uses ({ctx.unit})", last)
    su: dict[str, int] = {}

    def line(key: str, label: str, formula: str, fmt: str = NUM, bold: bool = False) -> None:
        nonlocal row
        label_cell(ws, row, label, bold=bold)
        value_cell(ws, row, 3, formula, fmt, bold=bold)
        su[key] = row
        row += 1

    line("ev", "Entry enterprise value", f"={cells['mult']}*{cells['ebitda0']}", bold=True)
    row = header_row(ws, row, ["Uses", "Amount"])
    uses_first = row
    line("u_equity", "Purchase of equity", f"=C{su['ev']}-{cells['refi']}")
    line("u_refi", "Refinance existing net debt", f"={cells['refi']}")
    line("u_fees", "Transaction fees", f"=C{su['ev']}*{cells['fee']}")
    line("u_fin", "Financing fees", f"=SUMPRODUCT({principal},$M${tr_first}:$M${tr_last})" if tranches else "=0")
    line("u_cash", "Cash to balance sheet", f"={cells['min_cash']}")
    line("u_total", "Total uses", f"=SUM(C{uses_first}:C{row - 1})", bold=True)
    row = header_row(ws, row, ["Sources", "Amount"])
    src_first = row
    for t in tranches:
        line(f"s_{t.name}", t.name, f"=O{tr_row[t.name]}")
    line("s_roll", "Rollover equity", f"={cells['rollover']}")
    debt_sum = f"SUM({principal})" if tranches else "0"
    line("s_sponsor", "Sponsor equity", f"=C{su['u_total']}-{debt_sum}-{cells['rollover']}", bold=True)
    line("s_total", "Total sources", f"=SUM(C{src_first}:C{row - 1})", bold=True)
    line("lev0", "Total debt / entry EBITDA at close", f"={debt_sum}/{cells['ebitda0']}", MULT)
    sponsor = f"$C${su['s_sponsor']}"

    # operating case
    labels = [o["label"] for o in ops]
    first_c, last_c = 4, 3 + n
    lc = col(last_c)
    row = subhead(ws, row + 1, f"Operating case ({ctx.unit})", last)
    head = header_row(ws, row, ["", "At close", *labels], shade=[False, False, *([True] * n)])
    year_head = row
    row = head
    year_row = row
    label_cell(ws, row, "Year", italic=True)
    for yi in range(n):
        value_cell(ws, row, first_c + yi, yi + 1, "0", kind="value", italic=True)
    row += 1
    op_rows: dict[str, int] = {}
    linked = res["inputs"].get("operating_case") == "dcf" and bool(r.get("proj_dnwc")) and int(r.get("years") or 0) >= n
    for key, label, proj in (
        ("ebitda", "EBITDA", "proj_ebitda"),
        ("da", "D&A", "proj_da"),
        ("capex", "Capex", "proj_capex"),
        ("dnwc", "Increase in net working capital", "proj_dnwc"),
    ):
        label_cell(ws, row, label, bold=key == "ebitda")
        for yi in range(n):
            c = col(first_c + yi)
            if linked:
                ref = f"'Projections'!{c}{r[proj]}"
                formula = f"=MAX({ref},0)" if key == "capex" else f"={ref}"
                value_cell(ws, row, first_c + yi, formula, NUM, kind="link", bold=key == "ebitda")
            else:
                field = {"dnwc": "change_in_nwc"}.get(key, key)
                value_cell(ws, row, first_c + yi, ops[yi][field] / s, NUM, kind="input", bold=key == "ebitda")
        op_rows[key] = row
        row += 1
    if linked:
        _muted(ws, op_rows["ebitda"] - 1, "Linked to the Projections tab (DCF case)", 3 + n + 1)
    label_cell(ws, row, "Base rate (floating debt)")
    curve = ei.get("base_rate_curve") or []
    for yi in range(n):
        value_cell(ws, row, first_c + yi, curve[yi] if yi < len(curve) else ei["base_rate"], PCT, kind="input")
    op_rows["base"] = row
    row += 1
    label_cell(ws, row, "Dividend recap paid out")
    for yi in range(n):
        c = col(first_c + yi)
        value_cell(
            ws,
            row,
            first_c + yi,
            f"=IF(AND(N({cells['recap_year']})>0,{c}${year_row}={cells['recap_year']}),{cells['recap_x']}*{c}{op_rows['ebitda']},0)",
            NUM,
        )
    op_rows["dividend"] = row
    row += 1

    # interest rates
    row = subhead(ws, row + 1, "Interest rates", last)
    rate_row: dict[str, int] = {}
    for t in tranches:
        tr = tr_row[t.name]
        label_cell(ws, row, t.name)
        for k in range(n):
            c = col(first_c + k)
            value_cell(
                ws,
                row,
                first_c + k,
                f'=IF($F${tr}="fixed",N($G${tr}),MAX({c}${op_rows["base"]},N($I${tr}))+N($H${tr}))',
                PCT,
            )
        rate_row[t.name] = row
        row += 1

    # schedule blocks: the visible schedule (last pass) first, then the solver passes in a collapsed group
    agg_keys = [
        "cash_int",
        "pik_int",
        "taxes",
        "ocf",
        "mand_total",
        "available",
        "excess",
        "draw",
        "to_sweep",
        "swept",
        "cash",
        "total_debt",
        "net_debt",
        "leverage",
        "coverage",
    ]

    def layout(start: int) -> dict[str, Any]:
        rows: dict[str, Any] = {"subhead": start, "head": start + 1}
        cur = start + 2
        for part in ("open", "int", "mand", "sweep", "close"):
            rows[part] = {t.name: cur + i for i, t in enumerate(tranches)}
            cur += nt
        for key in agg_keys:
            rows[key] = cur
            cur += 1
        rows["end"] = cur - 1
        return rows

    row += 1
    final = layout(row)
    passes = [layout(final["end"] + 3)]
    for _ in range(PASSES - 2):
        passes.append(layout(passes[-1]["end"] + 1))
    blocks = [*passes, final]  # pass 1 … pass K-1, then the final pass

    names = {
        "open": "Opening",
        "int": "Interest",
        "mand": "Scheduled repayment",
        "sweep": "Cash sweep",
        "close": "Closing",
    }
    agg_labels = {
        "cash_int": "Cash interest",
        "pik_int": "PIK interest (added to principal)",
        "taxes": "Cash taxes (on EBIT after all interest)",
        "ocf": "Cash flow before financing",
        "mand_total": "Scheduled repayments",
        "available": "Cash available after interest and repayments",
        "excess": "Excess over minimum cash",
        "draw": "Revolver drawn",
        "to_sweep": "Cash available to sweep",
        "swept": "Cash sweep",
        "cash": "Closing cash",
        "total_debt": "Total debt",
        "net_debt": "Net debt",
        "leverage": "Net debt / EBITDA",
        "coverage": "EBITDA / cash interest",
    }
    for b_i, b in enumerate(blocks):
        is_final = b is final
        prev_close = b["open"] if b_i == 0 else blocks[b_i - 1]["close"]
        title = (
            f"Debt schedule ({ctx.unit})"
            if is_final
            else f"Interest solver pass {b_i + 1} of {PASSES - 1} (average balances without iterative calculation)"
        )
        subhead(ws, b["subhead"], title, last)
        header_row(ws, b["head"], ["", "", *labels], shade=[False, False, *([True] * n)])
        for part, label in names.items():
            for t in tranches:
                label_cell(
                    ws,
                    b[part][t.name],
                    f"{label}: {t.name}",
                    indent=0 if part == "close" else 1,
                    bold=part == "close" and is_final,
                )
        for key in agg_keys:
            label_cell(ws, b[key], agg_labels[key], bold=key in ("cash", "total_debt") and is_final)
        if is_final:
            for t in tranches:
                value_cell(ws, b["open"][t.name], 3, f"=O{tr_row[t.name]}", NUM)
                value_cell(ws, b["close"][t.name], 3, f"=O{tr_row[t.name]}", NUM, bold=True)
            value_cell(ws, b["cash"], 3, f"={cells['min_cash']}", NUM, bold=True)
            value_cell(ws, b["total_debt"], 3, f"={debt_sum}", NUM, bold=True)
            value_cell(ws, b["net_debt"], 3, f"=C{b['total_debt']}-C{b['cash']}", NUM)
            value_cell(
                ws, b["leverage"], 3, f'=IF({cells["ebitda0"]}>0,C{b["net_debt"]}/{cells["ebitda0"]},"n/m")', MULT
            )
        for k in range(n):
            ci = first_c + k
            c, p = col(ci), col(ci - 1)
            ebitda = f"{c}{op_rows['ebitda']}"
            for t in tranches:
                tr = tr_row[t.name]
                if is_final:
                    opening = f"=$O${tr}" if k == 0 else f"={p}{final['close'][t.name]}"
                    value_cell(ws, b["open"][t.name], ci, opening, NUM)
                else:
                    value_cell(ws, b["open"][t.name], ci, f"={c}{final['open'][t.name]}", NUM)
                o = f"{c}{b['open'][t.name]}"
                pc = f"{c}{prev_close[t.name]}"
                value_cell(
                    ws, b["int"][t.name], ci, f"={c}{rate_row[t.name]}*IF({cells['avg']}=1,({o}+{pc})/2,{o})", NUM
                )
                recap = f"+{c}{op_rows['dividend']}" if t.name == recap_name else ""
                value_cell(
                    ws,
                    b["mand"][t.name],
                    ci,
                    f"=MIN($O${tr}*$J${tr},{o}+{c}{b['int'][t.name]}*$K${tr}{recap})",
                    NUM,
                )
            pre = {
                t.name: (
                    f"({c}{b['open'][t.name]}+{c}{b['int'][t.name]}*$K${tr_row[t.name]}"
                    + (f"+{c}{op_rows['dividend']}" if t.name == recap_name else "")
                    + f"-{c}{b['mand'][t.name]})"
                )
                for t in tranches
            }
            ints = f"{c}{b['int'][tranches[0].name]}:{c}{b['int'][tranches[-1].name]}" if tranches else None
            mands = f"{c}{b['mand'][tranches[0].name]}:{c}{b['mand'][tranches[-1].name]}" if tranches else None
            agg = {
                "cash_int": f"=SUMPRODUCT({ints},1-{pik_range})" if ints else "=0",
                "pik_int": f"=SUMPRODUCT({ints},{pik_range})" if ints else "=0",
                "taxes": f"=MAX({ebitda}-{c}{op_rows['da']}-{c}{b['cash_int']}-{c}{b['pik_int']},0)*{cells['tax']}",
                "ocf": f"={ebitda}-{c}{op_rows['capex']}-{c}{op_rows['dnwc']}-{c}{b['taxes']}",
                "mand_total": f"=SUM({mands})" if mands else "=0",
                "available": (
                    f"={cells['min_cash'] if k == 0 else f'{p}{final["cash"]}'}+{c}{b['ocf']}-{c}{b['cash_int']}"
                    f"-{c}{b['mand_total']}"
                ),
                "excess": f"={c}{b['available']}-{cells['min_cash']}",
                "draw": (
                    f"=IF({c}{b['excess']}<0,MIN(-{c}{b['excess']},MAX(N($N${tr_row[revolver]})-{pre[revolver]},0)),0)"
                    if revolver
                    else "=0"
                ),
                "to_sweep": f"=IF({c}{b['excess']}<0,0,{c}{b['excess']}*{cells['sweep']})",
                "swept": (
                    f"=SUM({c}{b['sweep'][tranches[0].name]}:{c}{b['sweep'][tranches[-1].name]})" if tranches else "=0"
                ),
                "cash": f"=IF({c}{b['excess']}<0,{c}{b['available']}+{c}{b['draw']},{c}{b['available']}-{c}{b['swept']})",
                "total_debt": (
                    f"=SUM({c}{b['close'][tranches[0].name]}:{c}{b['close'][tranches[-1].name]})" if tranches else "=0"
                ),
                "net_debt": f"={c}{b['total_debt']}-{c}{b['cash']}",
                "leverage": f'=IF({ebitda}>0,{c}{b["net_debt"]}/{ebitda},"n/m")',
                "coverage": f'=IF({c}{b["cash_int"]}>0,{ebitda}/{c}{b["cash_int"]},"n/m")',
            }
            for key, formula in agg.items():
                fmt = MULT if key in ("leverage", "coverage") else NUM
                value_cell(ws, b[key], ci, formula, fmt, bold=is_final and key in ("cash", "total_debt"))
            for i, t in enumerate(tranches):
                tr = tr_row[t.name]
                above = f"-SUM({c}{b['sweep'][tranches[0].name]}:{c}{b['sweep'][tranches[i - 1].name]})" if i else ""
                value_cell(
                    ws,
                    b["sweep"][t.name],
                    ci,
                    f"=IF(AND({c}{b['excess']}>=0,$L${tr}=1),MAX(MIN({c}{b['to_sweep']}{above},{pre[t.name]}),0),0)",
                    NUM,
                )
                draw = f"+{c}{b['draw']}" if t.name == revolver else ""
                value_cell(
                    ws,
                    b["close"][t.name],
                    ci,
                    f"={pre[t.name]}-{c}{b['sweep'][t.name]}{draw}",
                    NUM,
                    bold=is_final,
                )
        if not is_final:
            ws.row_dimensions.group(b["subhead"], b["end"], outline_level=1, hidden=True)
    ws.cell(
        row=final["end"] + 1, column=2, value=f"Solver passes 1 to {PASSES - 1}: expand the grouped rows below."
    ).font = font(8, italic=True, colour=colours()["grey_600"])
    row = passes[-1]["end"] + 2

    # covenants
    row = subhead(ws, row, "Covenant checks", last)
    for key, label, test in (
        ("max_lev", "Leverage covenant", "leverage"),
        ("min_cov", "Interest cover covenant", "coverage"),
    ):
        label_cell(ws, row, label)
        for k in range(n):
            c = col(first_c + k)
            v = f"{c}{final[test]}"
            cmp_ = f"{v}>{cells[key]}" if key == "max_lev" else f"{v}<{cells[key]}"
            value_cell(
                ws,
                row,
                first_c + k,
                f'=IF(OR(N({cells[key]})=0,NOT(ISNUMBER({v}))),"",IF({cmp_},"✗ Breach","✓ Pass"))',
                "@",
            )
        row += 1

    # exit and returns
    row = subhead(ws, row + 1, f"Exit and sponsor returns ({ctx.unit})", last)
    ret: dict[str, int] = {}

    def rline(key: str, label: str, formula: str, fmt: str = NUM, bold: bool = False) -> None:
        nonlocal row
        label_cell(ws, row, label, bold=bold)
        value_cell(ws, row, 3, formula, fmt, bold=bold)
        ret[key] = row
        row += 1

    rline(
        "ebitda", "Exit-year EBITDA", f"=INDEX($D${op_rows['ebitda']}:${lc}${op_rows['ebitda']},{cells['exit_year']})"
    )
    rline("ev", "Exit enterprise value", f"={cells['exit_mult']}*C{row - 1}", bold=True)
    rline(
        "debt",
        "Debt at exit (PIK included)",
        f"=INDEX($D${final['total_debt']}:${lc}${final['total_debt']},{cells['exit_year']})",
    )
    rline("cash", "Cash at exit", f"=INDEX($D${final['cash']}:${lc}${final['cash']},{cells['exit_year']})")
    rline(
        "equity",
        "Exit equity value",
        f"=C{ret['ev']}*(1-{cells['exit_cost']})-(C{ret['debt']}-C{ret['cash']})",
        bold=True,
    )
    rline("dist", "Distributable after management promote", f"=MAX(C{ret['equity']},0)*(1-{cells['promote']})")
    rline("share", "Sponsor share of equity", f"={sponsor}/({sponsor}+{cells['rollover']})", PCT)
    row = header_row(ws, row, ["Cash flows", "At close", *labels], shade=[False, False, *([True] * n)])
    flows: dict[str, int] = {}
    holders = [("sponsor", "Sponsor", sponsor, f"C{ret['share']}")]
    if ei["rollover_equity"]:
        holders.append(("rollover", "Rollover", cells["rollover"], f"(1-C{ret['share']})"))
    for key, label, invested, share in holders:
        label_cell(ws, row, f"{label} cash flows")
        value_cell(ws, row, 3, f"=-{invested}", NUM)
        for k in range(n):
            c = col(first_c + k)
            value_cell(
                ws,
                row,
                first_c + k,
                f"=IF({c}${year_row}<={cells['exit_year']},{c}{op_rows['dividend']}*{share},0)"
                f"+IF({c}${year_row}={cells['exit_year']},C{ret['dist']}*{share},0)",
                NUM,
            )
        flows[key] = row
        row += 1
    for key, label, invested, _share in holders:
        fr = flows[key]
        rline(f"irr_{key}", f"{label} IRR", f'=IFERROR(IRR(C{fr}:{lc}{fr}),"n/a")', PCT, bold=key == "sponsor")
        rline(
            f"moic_{key}",
            f"{label} MOIC",
            f'=IF({invested}>0,SUM(D{fr}:{lc}{fr})/{invested},"n/a")',
            MULT,
            bold=key == "sponsor",
        )
    r.cells["lbo_irr"] = f"'LBO'!$C${ret['irr_sponsor']}"
    r.cells["lbo_moic"] = f"'LBO'!$C${ret['moic_sponsor']}"
    engine_irr = res["case"]["sponsor"]["irr"]
    if engine_irr is not None:
        label_cell(ws, row, "Check: sponsor IRR matches the DealScout engine", italic=True)
        value_cell(ws, row, 3, f'=IF(ABS(N(C{ret["irr_sponsor"]})-{engine_irr:.10f})<0.0005,"✓","✗")', "@")
        _note(
            ws.cell(row=row, column=3),
            f"Engine IRR {engine_irr:.2%}. ✗ appears once you change an input, which is expected.",
        )
        row += 1

    # after-exit years greyed out (and labelled in the year row note)
    grey = colours()["grey_500"]
    ws.conditional_formatting.add(
        f"D{year_head}:{lc}{row}",
        FormulaRule(formula=[f"D${year_row}>{cells['exit_year']}"], font=font(9, italic=True, colour=grey)),
    )
    _muted(ws, year_row, "Years after the exit year are greyed and ignored by the returns.", 3 + n + 1)

    # engine outputs (goal seek and sensitivities)
    row = band(ws, row + 1, f"Engine outputs: maximum price and sensitivities ({ctx.unit})", last)
    mp = res["max_price"]
    bands = res.get("band", {})
    row = _table(
        ws,
        row,
        ["Maximum price at", "EV / EBITDA", "Entry EV", "Equity price"],
        [
            [label, x.get("entry_multiple"), (x.get("entry_ev") or 0) / s, (x.get("equity_purchase_price") or 0) / s]
            for label, x in (
                (f"Target IRR + 5pp ({mp['target_irr'] + 0.05:.0%})", bands.get("low") or {}),
                (f"Target IRR ({mp['target_irr']:.0%})", mp),
                (f"Target IRR − 5pp ({mp['target_irr'] - 0.05:.0%})", bands.get("high") or {}),
            )
        ],
        [MULT, NUM, NUM],
        last,
    )
    _muted(ws, row - 1, "A goal seek on entry price: an engine value (Excel would need iterative calculation).", 2)
    for grid in res.get("sensitivities", []):
        row = band(ws, row, grid["title"], last)
        row = _table(
            ws,
            row,
            [f"{grid['row_label']} \\ {grid['col_label']}", *[f"{x:.1f}x" for x in grid["cols"]]],
            [[f"{rv:.1f}x", *row_vals] for rv, row_vals in zip(grid["rows"], grid["values"], strict=True)],
            [PCT] * len(grid["cols"]),
            last,
        )

    # charts: debt by tranche (stacked) and leverage (separate chart, no dual axis)
    if tranches:
        chart = BarChart()
        chart.type = "col"
        chart.grouping = "stacked"
        chart.overlap = 100
        for t in tranches:
            chart.add_data(
                Reference(ws, min_col=2, max_col=last_c, min_row=final["close"][t.name]),
                from_rows=True,
                titles_from_data=True,
            )
        chart.set_categories(Reference(ws, min_col=3, max_col=last_c, min_row=final["head"]))
        for series, t in zip(chart.series, tranches, strict=True):
            series.tx = SeriesLabel(v=t.name)
        _colour_series(chart)
        _style_chart(chart, f"Debt outstanding by tranche ({ctx.unit})")
        ws.add_chart(chart, f"B{row + 1}")
        line_chart = LineChart()
        line_chart.add_data(
            Reference(ws, min_col=2, max_col=last_c, min_row=final["leverage"]), from_rows=True, titles_from_data=True
        )
        line_chart.set_categories(Reference(ws, min_col=3, max_col=last_c, min_row=final["head"]))
        _colour_series(line_chart, line=True)
        _style_chart(line_chart, "Leverage (net debt / EBITDA)", legend=False)
        line_chart.y_axis.numFmt = '0.0"x"'
        ws.add_chart(line_chart, f"{col(9)}{row + 1}")
    # the visible schedule's header needs "At close" in column C
    ws.cell(row=final["head"], column=3, value="At close")
    ws.freeze_panes = "C4"


# ── Precedent transactions ───────────────────────────────────────────────────────
def build_precedents(wb: Workbook, ctx: ExportContext, r: Refs, res: dict[str, Any]) -> None:
    s = ctx.scale
    st = res["stats"]
    ei = res.get("engine_inputs") or {}
    rows_in = sorted(st.get("rows") or [], key=lambda x: (x["multiple"], x["raw_weight"]))
    ws = wb.create_sheet("Precedents")
    setup_sheet(
        ws,
        widths={"B": 38, "C": 12, "D": 12, "E": 12, "F": 12, "G": 12, "H": 10, "I": 10, "J": 10, "K": 10, "L": 10},
        landscape=True,
        tab_colour=colours()["accent"],
    )
    back_link(ws)
    last = 12
    row = band(ws, 3, f"Precedent transactions: {res['label']} ({ctx.unit}; includes control premia)", last)
    row = subhead(ws, row + 1, "Inputs", last)
    label_cell(ws, row, "Valuation date")
    value_cell(
        ws, row, 3, date.fromisoformat(ei.get("as_of") or ctx.deal.valuation_date.isoformat()), DATE, kind="input"
    )
    as_of = f"$C${row}"
    row += 1
    label_cell(ws, row, "Recency half-life in years (blank = equal weights)")
    value_cell(ws, row, 3, ei.get("half_life_years"), "0.0", kind="input")
    half = f"$C${row}"
    row += 1
    metric_label = {"ev_revenue": "revenue", "ev_ebitda": "EBITDA", "ev_ebit": "EBIT"}[res["multiple_id"]]
    label_cell(ws, row, f"Target {metric_label} (latest year)")
    link_key = {"ev_revenue": "base_revenue", "ev_ebitda": "base_ebitda"}.get(res["multiple_id"])
    if link_key and _has_model(r):
        value_cell(ws, row, 3, f"={r[link_key]}", NUM, kind="link")
    else:
        value_cell(
            ws, row, 3, None if res.get("target_metric") is None else res["target_metric"] / s, NUM, kind="input"
        )
    metric = f"$C${row}"
    row += 1
    adj = _adjustment(ws, row, r, -(ei.get("net_debt_and_adjustments") or 0.0) / s, "EV-to-equity adjustment (net)")
    row += 2

    row = subhead(ws, row, "Transactions used (sorted by multiple)", last)
    row = header_row(
        ws,
        row,
        [
            "Transaction",
            "Announced",
            "EV",
            f"Target {metric_label}",
            "Multiple given",
            "Multiple used",
            "Age (years)",
            "Raw weight",
            "Weight",
            "Cum. before",
            "Position",
        ],
    )
    first = row
    for t in rows_in:
        label_cell(ws, row, t["name"])
        value_cell(ws, row, 3, date.fromisoformat(t["announced"]), DATE, kind="input")
        value_cell(ws, row, 4, None if t["ev"] is None else t["ev"] / s, NUM, kind="input")
        value_cell(ws, row, 5, None if t["metric"] is None else t["metric"] / s, NUM, kind="input")
        value_cell(ws, row, 6, t["given_multiple"], MULT, kind="input")
        row += 1
    lastr = max(row - 1, first)
    g = f"$G${first}:$G${lastr}"
    w = f"$I${first}:$I${lastr}"
    pos = f"$L${first}:$L${lastr}"
    for rr in range(first, lastr + 1) if rows_in else []:
        value_cell(
            ws, rr, 7, f'=IF(ISNUMBER(F{rr}),F{rr},IF(AND(ISNUMBER(D{rr}),N(E{rr})>0),D{rr}/E{rr},""))', MULT, bold=True
        )
        value_cell(ws, rr, 8, f"=MAX(({as_of}-C{rr})/365.25,0)", "0.00")
        value_cell(ws, rr, 9, f"=IF(N({half})>0,0.5^(H{rr}/{half}),1)", "0.000")
        value_cell(ws, rr, 10, f"=I{rr}/SUM({w})", PCT)
        value_cell(ws, rr, 11, "=0" if rr == first else f"=SUM(I${first}:I{rr - 1})", "0.000")
        value_cell(ws, rr, 12, f"=IF(SUM({w})-$I${lastr}>0,K{rr}/(SUM({w})-$I${lastr}),0)", "0.000")
    if rows_in:
        zebra(ws, first, lastr, 2, last)
    _muted(
        ws,
        lastr + 1,
        "Equal weights use PERCENTILE and MEDIAN. With a half-life, the weighted percentile interpolates between "
        "positions, so keep the rows sorted by multiple.",
        2,
    )
    row = lastr + 3

    row = subhead(ws, row, "Statistics", last)
    stat_rows: dict[str, int] = {}

    def weighted(q: str) -> str:
        k = f"MATCH({q},{pos},1)"
        return (
            f"IF(COUNT({g})=1,$G${first},IF({k}>=COUNT({g}),INDEX({g},COUNT({g})),INDEX({g},{k})+(INDEX({g},{k}+1)"
            f"-INDEX({g},{k}))*({q}-INDEX({pos},{k}))/(INDEX({pos},{k}+1)-INDEX({pos},{k}))))"
        )

    for key, label, q, plain in (
        ("n", "Transactions", None, f"=COUNT({g})"),
        ("p25", "25th percentile", "0.25", f"PERCENTILE({g},0.25)"),
        ("median", "Median", "0.5", f"MEDIAN({g})"),
        ("p75", "75th percentile", "0.75", f"PERCENTILE({g},0.75)"),
        ("mean", "Mean (weighted)", None, f"=SUMPRODUCT({g},{w})/SUM({w})"),
    ):
        label_cell(ws, row, label, bold=key == "median")
        formula = plain if q is None else f"=IF(N({half})>0,{weighted(q)},{plain})"
        value_cell(ws, row, 3, formula if rows_in else None, "0" if key == "n" else MULT, bold=key == "median")
        stat_rows[key] = row
        row += 1
    if st.get("median_premium") is not None:
        label_cell(ws, row, "Median premium paid (engine)")
        value_cell(ws, row, 3, st["median_premium"], PCT, kind="value")
        row += 1
    row += 1
    row = subhead(ws, row, f"Implied value ({ctx.unit})", last)
    row = header_row(ws, row, ["", "Multiple", "EV", "Equity"])
    refs = {}
    for key, label in (("p25", "Low (25th percentile)"), ("median", "Mid (median)"), ("p75", "High (75th percentile)")):
        label_cell(ws, row, label, bold=key == "median")
        value_cell(ws, row, 3, f"=C{stat_rows[key]}", MULT)
        value_cell(ws, row, 4, f'=IF(N({metric})>0,C{row}*{metric},"n/a")', NUM)
        value_cell(ws, row, 5, f'=IF(ISNUMBER(D{row}),D{row}+{adj},"n/a")', NUM, bold=True)
        refs[key] = f"'Precedents'!$E${row}"
        row += 1
    if res.get("equity_mid") is not None:
        r.cells["precedents_cells"] = "|".join(refs[k] for k in ("p25", "median", "p75"))
        label_cell(ws, row, "Check: mid equity value matches the DealScout engine", italic=True)
        value_cell(ws, row, 3, f'=IF(ABS(N(E{row - 2})-{res["equity_mid"] / s:.6f})<0.05,"✓","✗")', "@")
        row += 1
    if st.get("excluded"):
        row = subhead(ws, row + 1, "Transactions not used", last)
        for name, why in st["excluded"].items():
            label_cell(ws, row, name)
            ws.cell(row=row, column=3, value=why).font = font(9, italic=True)
            row += 1
    ws.freeze_panes = "C4"


# ── NAV and SOTP ─────────────────────────────────────────────────────────────────
_SIGN = {"asset": 1, "liability": -1}


def build_nav_sotp(
    wb: Workbook, ctx: ExportContext, r: Refs, nav: dict[str, Any] | None, sotp: dict[str, Any] | None
) -> None:
    s = ctx.scale
    ws = wb.create_sheet("NAV & SOTP")
    last = 14
    setup_sheet(
        ws, widths={"B": 34} | {col(c): 11 for c in range(3, last + 1)}, landscape=True, tab_colour=colours()["accent"]
    )
    back_link(ws)
    row = 3
    if nav:
        ei = nav["engine_inputs"]
        row = band(ws, row, f"Net asset value: live model ({ctx.unit}; inputs in blue)", last)
        row = subhead(ws, row + 1, "Inputs", last)
        inp: dict[str, str] = {}

        def put(key: str, label: str, value: Any, fmt: str, kind: str = "input", note: str = "") -> None:
            nonlocal row
            label_cell(ws, row, label)
            value_cell(ws, row, 3, value, fmt, kind=kind)
            if note:
                _muted(ws, row, note)
            inp[key] = f"$C${row}"
            row += 1

        if ei["tax_source"] == "valuation" and r.get("tax"):
            put("tax", "Tax rate on revaluation gains", f"={r['tax']}", PCT, "link", "Assumptions")
        else:
            put("tax", "Tax rate on revaluation gains", ei["tax_rate"], PCT)
        put("dt_on", "Deduct deferred tax on gains (1 = yes)", 1 if ei["deferred_tax_on_gains"] else 0, "0")
        put("hd", "Holding-company discount", ei["holding_discount"], PCT)
        put(
            "shares",
            "Shares (millions)",
            None if not ei.get("shares") else ei["shares"] / 1e6,
            "#,##0.00",
            note="Basic shares",
        )
        put("price", "Share price", ei.get("share_price"), PRICE)
        row = subhead(ws, row + 1, f"Assets and liabilities at fair value ({ctx.unit})", last)
        row = header_row(
            ws,
            row,
            [
                "Line",
                "Side",
                "Method",
                "Book value",
                "Appraisal / deal",
                "NOI",
                "Cap rate",
                "Metric",
                "Multiple",
                "Taxable (1 = yes)",
                "Fair value",
                "Revaluation",
                "Sign",
            ],
        )
        first = row
        for line in ei["lines"]:
            label_cell(ws, row, line["name"])
            ws.cell(row=row, column=3, value=line["side"]).font = font(9)
            ws.cell(row=row, column=4, value=line["method"].replace("_", " ")).font = font(9)
            value_cell(ws, row, 5, line["book_value"] / s, NUM, kind="input")
            value_cell(
                ws, row, 6, None if line.get("fair_value") is None else line["fair_value"] / s, NUM, kind="input"
            )
            value_cell(ws, row, 7, None if line.get("noi") is None else line["noi"] / s, NUM, kind="input")
            value_cell(ws, row, 8, line.get("cap_rate"), PCT, kind="input")
            value_cell(ws, row, 9, None if line.get("metric") is None else line["metric"] / s, NUM, kind="input")
            value_cell(ws, row, 10, line.get("multiple"), MULT, kind="input")
            value_cell(ws, row, 11, 1 if line.get("taxable", True) else 0, "0", kind="input")
            fair = {
                "book": f"=E{row}",
                "appraisal": f"=F{row}",
                "transaction": f"=F{row}",
                "cap_rate": f"=IF(N(H{row})>0,G{row}/H{row},0)",
                "multiple": f"=I{row}*J{row}",
            }[line["method"]]
            value_cell(ws, row, 12, fair, NUM, bold=True)
            value_cell(ws, row, 13, f"=L{row}-E{row}", NUM)
            value_cell(ws, row, 14, _SIGN[line["side"]], "0", kind="value")
            row += 1
        lastr = max(row - 1, first)
        zebra(ws, first, lastr, 2, last)
        sign = f"$N${first}:$N${lastr}"
        totals: dict[str, int] = {}
        row += 1
        row = subhead(ws, row, f"Net asset value ({ctx.unit})", last)

        def tline(key: str, label: str, formula: str, fmt: str = NUM, bold: bool = False, italic: bool = False) -> None:
            nonlocal row
            label_cell(ws, row, label, bold=bold, italic=italic, indent=1 if italic else 0)
            value_cell(ws, row, 3, formula, fmt, bold=bold, italic=italic)
            totals[key] = row
            row += 1

        tline("book", "Book NAV", f"=SUMPRODUCT({sign},$E${first}:$E${lastr})")
        tline("fair", "Fair-value NAV", f"=SUMPRODUCT({sign},$L${first}:$L${lastr})", italic=True)
        tline("gain", "Revaluation gain", f"=C{totals['fair']}-C{totals['book']}")
        tline(
            "taxable",
            "Taxable revaluation gain",
            f"=SUMPRODUCT({sign},$M${first}:$M${lastr},$K${first}:$K${lastr})",
            italic=True,
        )
        tline("dt", "Deferred tax on gains", f"=-IF({inp['dt_on']}=1,MAX(C{totals['taxable']},0)*{inp['tax']},0)")
        tline("before", "NAV before holding discount", f"=C{totals['fair']}+C{totals['dt']}", italic=True)
        tline("hd", "Holding discount", f"=-IF(C{totals['before']}>0,C{totals['before']}*{inp['hd']},0)")
        tline("nav", "NAV", f"=C{totals['before']}+C{totals['hd']}", bold=True)
        tline(
            "per_share",
            "NAV per share",
            f'=IF(N({inp["shares"]})>0,C{totals["nav"]}*{s / 1e6:g}/{inp["shares"]},"n/a")',
            PRICE,
        )
        tline(
            "premium",
            "Share price premium to NAV (negative = discount)",
            f'=IF(AND(ISNUMBER(C{totals["per_share"]}),N({inp["price"]})>0),{inp["price"]}/C{totals["per_share"]}-1,"n/a")',
            PCT,
        )
        nav_cell = f"'NAV & SOTP'!$C${totals['nav']}"
        before_cell = f"'NAV & SOTP'!$C${totals['before']}"
        r.cells["nav_cells"] = "|".join([nav_cell, nav_cell, before_cell])
        label_cell(ws, row, "Check: NAV matches the DealScout engine", italic=True)
        value_cell(ws, row, 3, f'=IF(ABS(C{totals["nav"]}-{nav["nav"] / s:.6f})<0.05,"✓","✗")', "@")
        row += 2
    if sotp:
        ei = sotp["engine_inputs"]
        row = band(ws, row, f"Sum of the parts: live model ({ctx.unit}; inputs in blue)", last)
        row = header_row(
            ws,
            row,
            [
                "Segment",
                "Metric",
                "Metric value",
                "Multiple low",
                "Multiple mid",
                "Multiple high",
                "Value given",
                "Low",
                "Mid",
                "High",
            ],
        )
        first = row
        for seg in ei["segments"]:
            label_cell(ws, row, seg["name"])
            ws.cell(row=row, column=3, value=seg.get("metric_label") or "").font = font(9)
            value_cell(ws, row, 4, None if seg.get("metric") is None else seg["metric"] / s, NUM, kind="input")
            value_cell(ws, row, 5, seg.get("multiple_low"), MULT, kind="input")
            value_cell(ws, row, 6, seg.get("multiple_mid"), MULT, kind="input")
            value_cell(ws, row, 7, seg.get("multiple_high"), MULT, kind="input")
            value_cell(ws, row, 8, None if seg.get("value") is None else seg["value"] / s, NUM, kind="input")
            for i, m in enumerate(("E", "F", "G")):
                mult = f"IF(ISNUMBER({m}{row}),{m}{row},F{row})" if m != "F" else f"F{row}"
                value_cell(ws, row, 9 + i, f"=IF(ISNUMBER(H{row}),H{row},N(D{row})*{mult})", NUM)
            row += 1
        lastr = max(row - 1, first)
        zebra(ws, first, lastr, 2, 11)
        row += 1
        lines: dict[str, int] = {}
        label_cell(ws, row, "Corporate costs (annual)")
        value_cell(ws, row, 3, ei["corporate_costs"] / s, NUM, kind="input")
        costs = row
        row += 1
        label_cell(ws, row, "Capitalised at (x)")
        value_cell(ws, row, 3, ei["corporate_cost_multiple"], MULT, kind="input")
        cmult = row
        row += 1
        label_cell(ws, row, "Non-core assets")
        value_cell(ws, row, 3, ei["non_core_assets"] / s, NUM, kind="input")
        noncore = row
        row += 1
        label_cell(ws, row, "Conglomerate discount")
        value_cell(ws, row, 3, ei["conglomerate_discount"], PCT, kind="input")
        disc = row
        row += 1
        engine_adj = (sotp["equity"][1] - sotp["ev"][1]) / s
        adj = _adjustment(ws, row, r, engine_adj, "EV-to-equity adjustment (net)")
        row += 2
        row = header_row(ws, row, ["", "Low", "Mid", "High"])
        for key, label in (
            ("gross", "Sum of segments"),
            ("corp", "− Capitalised corporate costs"),
            ("noncore", "+ Non-core assets"),
            ("before", "EV before discount"),
            ("disc", "− Conglomerate discount"),
            ("ev", "Enterprise value"),
            ("equity", "Equity value"),
        ):
            label_cell(ws, row, label, bold=key in ("ev", "equity"))
            lines[key] = row
            for i in range(3):
                c = col(3 + i)
                src = col(9 + i)
                formula = {
                    "gross": f"=SUM({src}{first}:{src}{lastr})",
                    "corp": f"=-$C${costs}*$C${cmult}",
                    "noncore": f"=$C${noncore}",
                    "before": f"={c}{lines.get('gross', 0)}+{c}{lines.get('corp', 0)}+{c}{lines.get('noncore', 0)}",
                    "disc": f"=-MAX({c}{lines.get('before', 0)},0)*$C${disc}",
                    "ev": f"={c}{lines.get('before', 0)}+{c}{lines.get('disc', 0)}",
                    "equity": f"={c}{lines.get('ev', 0)}+{adj}",
                }[key]
                value_cell(ws, row, 3 + i, formula, NUM, bold=key in ("ev", "equity"))
            row += 1
        r.cells["sotp_cells"] = "|".join(f"'NAV & SOTP'!${col(3 + i)}${lines['equity']}" for i in range(3))
        _note(
            ws.cell(row=lines["equity"], column=3),
            "Valuation Summary takes the lowest, middle and highest of the three.",
        )
    ws.freeze_panes = "C4"


def summary_formulas(method_id: str, r: Refs) -> list[str] | None:
    """Low, mid and high equity value formulas for the Valuation Summary, when the method's tab is live."""
    key = {"precedents": "precedents_cells", "nav": "nav_cells", "sotp": "sotp_cells"}.get(method_id)
    cells = r.items(key) if key else []
    return _min_med_max(cells) if len(cells) == 3 else None


def build_live_method_tabs(wb: Workbook, ctx: ExportContext, r: Refs) -> list[str]:
    """The method tabs with live formulas, in workbook order. Returns the tab names made."""
    methods = {m["id"]: m for m in ctx.valuation.get("methods", [])}
    made = []
    pre = methods.get("precedents")
    if pre and pre.get("result") and pre["result"].get("stats", {}).get("n"):
        build_precedents(wb, ctx, r, pre["result"])
        made.append("Precedents")
    lbo = methods.get("lbo")
    if lbo and lbo.get("result") and lbo["result"].get("engine_inputs"):
        build_lbo(wb, ctx, r, lbo["result"])
        made.append("LBO")
    nav = methods.get("nav") or {}
    sotp = methods.get("sotp") or {}
    nav_res = nav.get("result") if nav.get("status") == "ready" else None
    sotp_res = sotp.get("result") if sotp.get("status") == "ready" else None
    if nav_res or sotp_res:
        build_nav_sotp(wb, ctx, r, nav_res, sotp_res)
        made.append("NAV & SOTP")
    return made


__all__ = ["ENGINE_NOTE", "build_live_method_tabs", "summary_formulas"]
