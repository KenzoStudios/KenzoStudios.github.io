"""Everything an export needs, gathered once from the same endpoints the web app uses, so exports always match the
screen. No calculation happens here: values come from the engine through those endpoints.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from sqlmodel import Session, col, select

from ..models import Deal, Document, FinancialValue
from ..services import financials as fin
from ..services.reference import disclaimers, reference_data


@dataclass
class ExportContext:
    deal: Deal
    generated: datetime
    analyst: str
    sector_name: str
    country_name: str
    grid: dict[str, Any]
    analysis: dict[str, Any]
    valuation: dict[str, Any]
    recommendation: dict[str, Any]
    sources: list[dict[str, Any]]
    documents: list[str]
    disclaimers: dict[str, Any]

    @property
    def currency(self) -> str:
        # the analysis currency once the figures are converted (brief §7); otherwise the reporting currency
        return str(self.valuation.get("deal", {}).get("currency") or self.deal.reporting_currency)

    @property
    def scale(self) -> float:
        return float(self.grid["entry"]["scale"])

    @property
    def unit(self) -> str:
        label = {1: "", 1e3: "k", 1e6: "m", 1e9: "bn"}.get(self.scale, "")
        return f"{self.currency} {label}".strip()


def build_context(session: Session, deal: Deal) -> ExportContext:
    # local imports: the route modules import services that import this package's siblings
    from ..routes.financials import analysis
    from ..routes.valuation import recommendation, valuation

    refs = reference_data()
    sector = next((s for s in refs["sectors"] if s["id"] == deal.sector), {"name": deal.sector})
    country = next((c for c in refs["countries"] if c["code"] == deal.country), {"name": deal.country})
    val = valuation(deal.id, session)
    rows = session.exec(select(FinancialValue).where(FinancialValue.deal_id == deal.id)).all()
    docs = session.exec(select(Document).where(Document.deal_id == deal.id).order_by(col(Document.uploaded_at))).all()
    sources = []
    for r in rows:
        p = r.provenance or {}
        sources.append(
            {
                "concept_id": r.concept_id,
                "period": r.period_key,
                "value": r.value,
                "source": r.source,
                "document": p.get("filename") or "",
                "location": (
                    f"p. {p['page']}" if p.get("page") else f"{p.get('sheet') or ''} {p.get('cell_ref') or ''}".strip()
                ),
                "label": p.get("label") or "",
                "as_written": p.get("value_as_written") or r.entered_text or "",
                "confidence": r.confidence,
                "method": p.get("method") or r.source,
            }
        )
    sources.sort(key=lambda s: (s["concept_id"], s["period"]))
    return ExportContext(
        deal=deal,
        generated=datetime.now(UTC),
        analyst=str(val.get("analyst") or "Analyst"),
        sector_name=str(sector.get("name", deal.sector)),
        country_name=str(country.get("name", deal.country)),
        grid=_grid_in_analysis_currency(session, deal, fin.grid_payload(session, deal), val),
        analysis=analysis(deal.id, session),
        valuation=val,
        recommendation=recommendation(deal.id, session),
        sources=sources,
        documents=[d.filename for d in docs],
        disclaimers=disclaimers(),
    )


def _grid_in_analysis_currency(
    session: Session, deal: Deal, grid: dict[str, Any], val: dict[str, Any]
) -> dict[str, Any]:
    """The Financials grid in the currency the valuation used, so every tab of an export shares one currency.

    Stored and computed money cells convert at the period's average (flows) or closing (balances) rate, as in the
    engine. An LTM column uses the rates of its latest year-to-date period.
    """
    if not (val.get("fx") or {}).get("converted"):
        return grid
    from dealscout_engine.fx import convert_amount, rate_kind
    from dealscout_engine.taxonomy import load_taxonomy

    from ..models import DealAssumptions
    from ..services import fx as fx_service

    record = session.get(DealAssumptions, deal.id)
    doc = fx_service.load_fx(record.fx if record else None)
    by_period = {r.period_id: r for r in doc.rates}
    for ltm in grid.get("ltm_periods", []):
        inputs = ltm.get("inputs") or []
        if inputs and inputs[0] in by_period:
            by_period[ltm["key"]] = by_period[inputs[0]]
    taxonomy = load_taxonomy()
    for statement in grid["statements"]:
        for row in statement["rows"]:
            kind = rate_kind(taxonomy.concept(row["concept_id"]))
            if kind is None:
                continue
            for period_key, cell in row["cells"].items():
                rates = by_period.get(period_key)
                fx = rates.get(kind) if rates else None
                if fx is not None and isinstance(cell.get("value"), int | float):
                    cell["value"] = convert_amount(cell["value"], fx.rate)
    grid["currency_note"] = f"Converted from {deal.reporting_currency} at the rates entered in DealScout"
    return grid
