"""One style module for every export (brief §14A): palette from data/design/palette.json, one font, number formats,
and helpers for bands, tables, links and print setup. Every tab uses these, so the workbook stays consistent.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from functools import lru_cache
from typing import Any

from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from ..config import get_settings

FONT = "Calibri"


@lru_cache(maxsize=1)
def palette() -> dict[str, Any]:
    with open(get_settings().reference_dir / "design" / "palette.json", encoding="utf-8") as fh:
        data: dict[str, Any] = json.load(fh)
    return data


def hex_(colour: str) -> str:
    return colour.lstrip("#").upper()


def colours() -> dict[str, str]:
    p = palette()
    return {
        "navy": hex_(p["brand"]["navy"]),
        "navy_100": hex_(p["brand"]["navy_100"]),
        "accent": hex_(p["brand"]["accent"]),
        "accent_100": hex_(p["brand"]["accent_100"]),
        "grey_50": hex_(p["grey"]["50"]),
        "grey_100": hex_(p["grey"]["100"]),
        "grey_200": hex_(p["grey"]["200"]),
        "grey_500": hex_(p["grey"]["500"]),
        "grey_600": hex_(p["grey"]["600"]),
        "text": hex_(p["grey"]["900"]),
        "negative": hex_(p["semantic"]["negative"]),
        "negative_bg": hex_(p["semantic"]["negative_bg"]),
        "warning": hex_(p["semantic"]["warning"]),
        "warning_bg": hex_(p["semantic"]["warning_bg"]),
        "positive": hex_(p["semantic"]["positive"]),
        "positive_bg": hex_(p["semantic"]["positive_bg"]),
    }


def chart_colours() -> list[str]:
    return [hex_(c) for c in palette()["chart"]["categorical_light"]]


# number formats: zeros as a dash, negatives in parentheses
NUM = '#,##0.0;(#,##0.0);"–"'
NUM0 = '#,##0;(#,##0);"–"'
PCT = '0.0%;(0.0%);"–"'
MULT = '0.0"x";(0.0"x");"–"'
PRICE = '#,##0.00;(#,##0.00);"–"'
FACTOR = "0.000"

# banking colour convention for model tabs
INPUT = "0000FF"  # hard-coded inputs
LINK = "008000"  # links to other tabs
FORMULA = "000000"


def font(size: float = 10, *, bold: bool = False, italic: bool = False, colour: str | None = None) -> Font:
    return Font(name=FONT, size=size, bold=bold, italic=italic, color=colour or colours()["text"])


def fill(colour: str) -> PatternFill:
    return PatternFill("solid", start_color=colour, end_color=colour)


THIN = Side(style="thin", color="D5DBE3")
BOTTOM = Border(bottom=THIN)


def setup_sheet(
    ws: Worksheet, *, widths: Mapping[str, float], landscape: bool = False, tab_colour: str | None = None
) -> None:
    """Gridlines off, narrow margin column A, column widths, tab colour and print setup."""
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 2
    for col, w in widths.items():
        ws.column_dimensions[col].width = w
    if tab_colour:
        ws.sheet_properties.tabColor = tab_colour
    ws.page_setup.orientation = "landscape" if landscape else "portrait"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    ws.page_margins.left = ws.page_margins.right = 0.5


def print_header_footer(ws: Worksheet, company: str, generated: str, footer: str) -> None:
    ws.oddHeader.left.text = f"{company}: DealScout"
    ws.oddHeader.right.text = generated
    ws.oddFooter.left.text = footer
    ws.oddFooter.right.text = "Page &P of &N"
    for part in (ws.oddHeader.left, ws.oddHeader.right, ws.oddFooter.left, ws.oddFooter.right):
        part.size = 8
        part.font = FONT


def band(ws: Worksheet, row: int, text: str, last_col: int, *, size: float = 12) -> int:
    """A full-width navy section band; returns the next row."""
    c = colours()
    for col in range(2, last_col + 1):
        ws.cell(row=row, column=col).fill = fill(c["navy"])
    cell = ws.cell(row=row, column=2, value=text)
    cell.font = font(size, bold=True, colour="FFFFFF")
    cell.alignment = Alignment(vertical="center")
    ws.row_dimensions[row].height = 20
    return row + 1


def subhead(ws: Worksheet, row: int, text: str, last_col: int) -> int:
    c = colours()
    for col in range(2, last_col + 1):
        cell = ws.cell(row=row, column=col)
        cell.border = Border(bottom=Side(style="medium", color=c["accent"]))
    ws.cell(row=row, column=2, value=text).font = font(10, bold=True, colour=c["navy"])
    return row + 1


def header_row(
    ws: Worksheet, row: int, labels: list[str], *, start_col: int = 2, shade: list[bool] | None = None
) -> int:
    c = colours()
    for i, label in enumerate(labels):
        cell = ws.cell(row=row, column=start_col + i, value=label)
        cell.font = font(9, bold=True, colour=c["grey_600"] if i == 0 else c["navy"])
        cell.fill = fill(c["grey_200"] if shade and shade[i] else c["grey_100"])
        cell.alignment = Alignment(horizontal="left" if i == 0 else "right", vertical="center")
        cell.border = BOTTOM
    return row + 1


def label_cell(
    ws: Worksheet, row: int, text: str, *, col: int = 2, bold: bool = False, italic: bool = False, indent: int = 0
) -> None:
    cell = ws.cell(row=row, column=col, value=text)
    cell.font = font(9 if italic else 10, bold=bold, italic=italic, colour=colours()["grey_600"] if italic else None)
    cell.alignment = Alignment(indent=indent, vertical="top")


def value_cell(
    ws: Worksheet,
    row: int,
    col: int,
    value: Any,
    fmt: str = NUM,
    *,
    kind: str = "formula",
    bold: bool = False,
    italic: bool = False,
) -> None:
    """kind: input (blue), link (green), formula (black), value (engine output, black)."""
    cell = ws.cell(row=row, column=col, value=value)
    if isinstance(value, str) and value.startswith("="):
        mark_formula(ws, cell.coordinate)
    colour = {"input": INPUT, "link": LINK}.get(kind, FORMULA)
    cell.font = font(9 if italic else 10, bold=bold, italic=italic, colour=colour)
    cell.number_format = fmt
    cell.alignment = Alignment(horizontal="right")


def zebra(ws: Worksheet, first: int, last: int, first_col: int, last_col: int) -> None:
    shade = fill(colours()["grey_50"])
    for r in range(first, last + 1):
        if (r - first) % 2 == 1:
            for col in range(first_col, last_col + 1):
                ws.cell(row=r, column=col).fill = shade


def back_link(ws: Worksheet) -> None:
    cell = ws.cell(row=1, column=2, value="← Back to Report")
    cell.hyperlink = "#'Report'!A1"
    cell.font = font(9, colour=colours()["accent"])


def col(n: int) -> str:
    return get_column_letter(n)


def ref(sheet: str, row: int, column: int, *, absolute: bool = True) -> str:
    c = f"${col(column)}${row}" if absolute else f"{col(column)}{row}"
    return f"'{sheet}'!{c}"


def mark_formula(ws: Worksheet, coordinate: str) -> None:
    """Record a formula DealScout wrote itself; anything else that looks like a formula is neutralised."""
    marked: set[str] = ws.__dict__.setdefault("_dealscout_formulas", set())
    marked.add(coordinate)


def neutralise_injected_formulas(ws: Worksheet) -> int:
    """Store as plain text every cell that openpyxl would write as a formula but DealScout did not create.

    Text from documents, deal names, imported deal files or the AI (for example ``=HYPERLINK(...)``) must never run
    as a formula in the analyst's Excel. Returns how many cells were neutralised.
    """
    marked: set[str] = ws.__dict__.get("_dealscout_formulas", set())
    count = 0
    for row in ws.iter_rows():
        for cell in row:
            if cell.data_type == "f" and cell.coordinate not in marked:
                cell.data_type = "s"
                count += 1
    return count
