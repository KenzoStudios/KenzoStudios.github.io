"""Exports: Excel workbook, PDF tear sheet, PowerPoint one-pager, JSON deal files (brief §14, §14A)."""
