"""Report tab breakdowns (brief §14A): each a compact table plus a native chart.

Segment and geography mix, cost structure, EBITDA margin bridge, cash flow from EBITDA to free cash flow, working
capital days, capital structure and debt maturities. Figures link to the Financials tab by formula (green) so they
follow any change there; segment and geography revenue are inputs entered per deal (blue). A breakdown without the
data it needs is skipped with a one-line note.

Waterfalls are stacked columns over an invisible base held in hidden helper columns (J to N) next to the table;
increases and decreases use the two poles of the diverging palette and the table shows the signed values, so colour
is never the only cue.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.chart.legend import LegendEntry
from openpyxl.chart.marker import DataPoint
from openpyxl.worksheet.worksheet import Worksheet

from .context import ExportContext
from .style import (
    NUM,
    PCT,
    col,
    colours,
    font,
    header_row,
    hex_,
    label_cell,
    palette,
    subhead,
    value_cell,
    zebra,
)
from .workbook import Refs, _colour_series, _style_chart

HELPER = 10  # first hidden helper column (J)
CHART_ROWS = 15
MAX_PERIODS = 5


@dataclass
class _Fin:
    """Where Financials keeps each concept and ratio."""

    rows: dict[str, str]
    keys: list[str]
    ratio_rows: dict[str, str]
    ratio_keys: list[str]

    def cell(self, cid: str, period: str) -> str | None:
        if cid not in self.rows or period not in self.keys:
            return None
        return f"'Financials'!{col(3 + self.keys.index(period))}{self.rows[cid]}"

    def ratio(self, rid: str, period: str) -> str | None:
        if rid not in self.ratio_rows or period not in self.ratio_keys:
            return None
        return f"'Financials'!{col(3 + self.ratio_keys.index(period))}{self.ratio_rows[rid]}"

    def n(self, cid: str, period: str) -> str:
        """N(cell) or 0, for sums where a missing line counts as zero."""
        c = self.cell(cid, period)
        return f"N({c})" if c else "0"


def _note(ws: Worksheet, row: int, text: str) -> int:
    ws.cell(row=row, column=2, value=text).font = font(8, italic=True, colour=colours()["grey_600"])
    return row + 1


def _periods(ctx: ExportContext, fin: _Fin) -> list[str]:
    annual = [p["key"] for p in ctx.grid["periods"] if p.get("kind", "annual") in ("annual", "fy")]
    return [k for k in annual if k in fin.keys][-MAX_PERIODS:]


def _has(ctx: ExportContext, cid: str, period: str) -> bool:
    for st in ctx.grid["statements"]:
        for item in st["rows"]:
            if item["concept_id"] == cid:
                cell = item["cells"].get(period)
                return bool(cell and cell.get("value") is not None)
    return False


def _value(ctx: ExportContext, cid: str, period: str) -> float | None:
    for st in ctx.grid["statements"]:
        for item in st["rows"]:
            if item["concept_id"] == cid:
                cell = item["cells"].get(period) or {}
                v = cell.get("value")
                return float(v) if v is not None else None
    return None


def _chart_from_rows(ws: Worksheet, rows: list[int], head: int, n: int, title: str, *, kind: str, fmt: str) -> Any:
    if kind == "line":
        chart: Any = LineChart()
    else:
        chart = BarChart()
        chart.type = "col"
        if kind == "stacked":
            chart.grouping = "stacked"
            chart.overlap = 100
    for rr in rows:
        chart.add_data(Reference(ws, min_col=2, max_col=2 + n, min_row=rr), from_rows=True, titles_from_data=True)
    chart.set_categories(Reference(ws, min_col=3, max_col=2 + n, min_row=head))
    _colour_series(chart, line=kind == "line")
    _style_chart(chart, title, legend=len(rows) > 1)
    chart.y_axis.numFmt = fmt
    chart.width, chart.height = 11.3, 6.6
    return chart


def _waterfall(ws: Worksheet, steps: list[tuple[int, str, str]], title: str, fmt: str) -> Any:
    """steps: (table row whose column C holds the value, "total" | "step", short category label).

    Helper columns J to O on the same rows: base, increase, decrease, total, running total, label.
    """
    k, up, down, tot, cum = (col(HELPER + i) for i in range(5))
    ws.cell(row=steps[0][0] - 1, column=HELPER, value="Base")
    ws.cell(row=steps[0][0] - 1, column=HELPER + 1, value="Increase")
    ws.cell(row=steps[0][0] - 1, column=HELPER + 2, value="Decrease")
    ws.cell(row=steps[0][0] - 1, column=HELPER + 3, value="Total")
    prev: int | None = None
    for rr, kind, short in steps:
        ws.cell(row=rr, column=HELPER + 5, value=short)
        if kind == "total" or prev is None:
            value_cell(ws, rr, HELPER, "=0", NUM)
            value_cell(ws, rr, HELPER + 1, "=0", NUM)
            value_cell(ws, rr, HELPER + 2, "=0", NUM)
            value_cell(ws, rr, HELPER + 3, f"=C{rr}", NUM)
            value_cell(ws, rr, HELPER + 4, f"=C{rr}", NUM)
        else:
            value_cell(ws, rr, HELPER + 4, f"={cum}{prev}+C{rr}", NUM)
            value_cell(ws, rr, HELPER, f"=MIN({cum}{prev},{cum}{rr})", NUM)
            value_cell(ws, rr, HELPER + 1, f"=MAX(C{rr},0)", NUM)
            value_cell(ws, rr, HELPER + 2, f"=MAX(-C{rr},0)", NUM)
            value_cell(ws, rr, HELPER + 3, "=0", NUM)
        prev = rr
    _ = (k, up, down, tot)
    first, last = steps[0][0], steps[-1][0]
    chart = BarChart()
    chart.type = "col"
    chart.grouping = "stacked"
    chart.overlap = 100
    for i in range(4):
        chart.add_data(Reference(ws, min_col=HELPER + i, min_row=first - 1, max_row=last), titles_from_data=True)
    chart.set_categories(Reference(ws, min_col=HELPER + 5, min_row=first, max_row=last))
    p = palette()["chart"]
    chart.series[0].graphicalProperties.noFill = True
    chart.series[0].graphicalProperties.line.noFill = True
    for s_, colour in zip(
        chart.series[1:],
        (hex_(p["diverging_light"][-1]), hex_(p["diverging_light"][0]), hex_(palette()["brand"]["navy"])),
        strict=True,
    ):
        s_.graphicalProperties.solidFill = colour
        s_.graphicalProperties.line.solidFill = colour
    _style_chart(chart, title)
    chart.legend.legendEntry = [LegendEntry(idx=0, delete=True)]  # the invisible base
    chart.y_axis.numFmt = fmt
    chart.gapWidth = 60
    chart.width, chart.height = 11.3, 6.6
    return chart


def _table_rows(
    ws: Worksheet, row: int, periods: list[str], lines: list[tuple[str, list[str | None], str, bool]]
) -> tuple[int, dict[str, int], int]:
    """lines: (label, formula per period or None, number format, bold). Returns (next row, row by label, header)."""
    head = row
    row = header_row(ws, row, ["", *periods])
    first = row
    rows: dict[str, int] = {}
    for label, formulas, fmt, bold in lines:
        label_cell(ws, row, label, bold=bold)
        for i, f in enumerate(formulas):
            if f is not None:
                value_cell(ws, row, 3 + i, f, fmt, kind="link" if "'Financials'!" in f else "formula", bold=bold)
        rows[label] = row
        row += 1
    zebra(ws, first, row - 1, 2, 2 + len(periods))
    return row, rows, head


# ── the breakdowns ──────────────────────────────────────────────────────────────
def _mix(ws: Worksheet, ctx: ExportContext, fin: _Fin, row: int, kind: str) -> tuple[int, Any]:
    lines = (ctx.analysis.get("breakdowns") or {}).get(kind) or []
    title = {"segments": "Revenue by segment", "geographies": "Revenue by geography"}[kind]
    row = subhead(ws, row, f"{title} ({ctx.unit})", 8)
    if not lines:
        return _note(
            ws, row, f"No {kind[:-1] if kind == 'segments' else 'geography'} data entered for this deal."
        ), None
    order = [p["key"] for p in ctx.grid["periods"]]
    periods = sorted(
        {k for line in lines for k in line["revenue"]}, key=lambda k: (order.index(k) if k in order else 99, k)
    )
    periods = periods[-(MAX_PERIODS - 1) :]
    s = ctx.scale
    head = row
    row = header_row(ws, row, ["", *periods, f"Share {periods[-1]}"])
    first = row
    for line in lines:
        label_cell(ws, row, line["name"])
        for i, k in enumerate(periods):
            v = line["revenue"].get(k)
            value_cell(ws, row, 3 + i, None if v is None else v / s, NUM, kind="input")
        row += 1
    lastr = row - 1
    label_cell(ws, row, "Total", bold=True)
    for i in range(len(periods)):
        c = col(3 + i)
        value_cell(ws, row, 3 + i, f"=SUM({c}{first}:{c}{lastr})", NUM, bold=True)
    total = row
    lc = col(2 + len(periods))
    for rr in range(first, lastr + 1):
        value_cell(ws, rr, 3 + len(periods), f'=IF(N({lc}{total})>0,{lc}{rr}/{lc}{total},"")', PCT)
    row += 1
    rev = [fin.cell("revenue", k) for k in periods]
    if any(rev):
        label_cell(ws, row, "Difference to reported revenue", italic=True, indent=1)
        for i, ref in enumerate(rev):
            if ref:
                value_cell(ws, row, 3 + i, f"={col(3 + i)}{total}-{ref}", NUM, italic=True)
        row += 1
    zebra(ws, first, lastr, 2, 3 + len(periods))
    chart = _chart_from_rows(
        ws, list(range(first, lastr + 1)), head, len(periods), f"{title} ({ctx.unit})", kind="stacked", fmt="#,##0"
    )
    return row, chart


def _cost_structure(ws: Worksheet, ctx: ExportContext, fin: _Fin, row: int, periods: list[str]) -> tuple[int, Any]:
    row = subhead(ws, row, "Cost structure (% of revenue)", 8)
    items = [
        (cid, label) for cid, label in (("cogs", "Cost of sales"), ("sga", "SG&A"), ("rnd", "R&D")) if cid in fin.rows
    ]
    if "revenue" not in fin.rows or not items or not periods:
        return _note(ws, row, "Needs revenue and at least one of cost of sales, SG&A or R&D."), None
    lines = []
    for cid, label in items:
        formulas: list[str | None] = []
        for k in periods:
            rev, cost = fin.cell("revenue", k), fin.cell(cid, k)
            formulas.append(f'=IF(AND(N({rev})>0,ISNUMBER({cost})),-{cost}/{rev},"")' if rev and cost else None)
        lines.append((label, formulas, PCT, False))
    row, rows, head = _table_rows(ws, row, periods, lines)
    chart = _chart_from_rows(
        ws, list(rows.values()), head, len(periods), "Cost structure (% of revenue)", kind="line", fmt="0%"
    )
    return row, chart


def _margin_bridge(ws: Worksheet, ctx: ExportContext, fin: _Fin, row: int, periods: list[str]) -> tuple[int, Any]:
    row = subhead(ws, row, "EBITDA margin bridge, year on year", 8)
    if len(periods) < 2 or not all(c in fin.rows for c in ("revenue", "ebitda")):
        return _note(ws, row, "Needs revenue and EBITDA for two years."), None
    p, k = periods[-2], periods[-1]
    if not all(fin.cell(c, x) and _has(ctx, c, x) for c in ("revenue", "ebitda") for x in (p, k)):
        return _note(ws, row, "Needs revenue and EBITDA for two years."), None

    def share(cid: str, period: str) -> str:
        return f"{fin.n(cid, period)}/{fin.cell('revenue', period)}"

    head = row
    row = header_row(ws, row, ["Step", "Margin points", "", "", "", ""])
    steps: list[tuple[int, str, str]] = []
    label_cell(ws, row, f"EBITDA margin {p}", bold=True)
    value_cell(ws, row, 3, f"={share('ebitda', p)}", PCT, bold=True)
    start = row
    steps.append((row, "total", p))
    row += 1
    for cid, label in (("cogs", "Cost of sales"), ("sga", "SG&A"), ("rnd", "R&D")):
        if cid not in fin.rows:
            continue
        label_cell(ws, row, f"{label} (change in % of revenue)", indent=1)
        value_cell(ws, row, 3, f"={share(cid, k)}-{share(cid, p)}", PCT)
        steps.append((row, "step", label))
        row += 1
    label_cell(ws, row, "Other operating items", indent=1)
    end = row + 1
    value_cell(ws, row, 3, f"=C{end}-C{start}" + (f"-SUM(C{start + 1}:C{row - 1})" if row - 1 > start else ""), PCT)
    steps.append((row, "step", "Other"))
    row += 1
    label_cell(ws, row, f"EBITDA margin {k}", bold=True)
    value_cell(ws, row, 3, f"={share('ebitda', k)}", PCT, bold=True)
    steps.append((row, "total", k))
    row += 1
    zebra(ws, head + 1, row - 1, 2, 3)
    margins = [
        (_value(ctx, "ebitda", x) or 0) / (_value(ctx, "revenue", x) or 1) for x in (p, k) if _value(ctx, "revenue", x)
    ]
    if len(margins) < 2 or min(margins) <= 0:
        return _note(ws, row, "Chart omitted: the bridge crosses zero (see the table)."), None
    return row, _waterfall(ws, steps, f"EBITDA margin bridge {p} to {k}", "0%")


def _cash_flow(ws: Worksheet, ctx: ExportContext, fin: _Fin, row: int, periods: list[str]) -> tuple[int, Any]:
    row = subhead(ws, row, f"Cash flow: EBITDA to free cash flow ({ctx.unit})", 8)
    ok = [k for k in periods if all(fin.cell(c, k) and _has(ctx, c, k) for c in ("ebitda", "cfo", "capex"))]
    if not ok:
        return _note(ws, row, "Needs EBITDA, cash from operations and capex."), None
    periods = ok
    lines: list[tuple[str, list[str | None], str, bool]] = [
        ("EBITDA", [f"={fin.cell('ebitda', k)}" for k in periods], NUM, True),
        ("Taxes paid", [f"={fin.n('taxes_paid', k)}" for k in periods], NUM, False),
        ("Change in working capital", [f"={fin.n('change_in_working_capital', k)}" for k in periods], NUM, False),
    ]
    row, rows, _head = _table_rows(ws, row, periods, lines)
    other = row
    label_cell(ws, row, "Other operating items")
    cfo_row = row + 1
    capex_row = row + 2
    fcf_row = row + 3
    for i, k in enumerate(periods):
        c = col(3 + i)
        value_cell(
            ws,
            other,
            3 + i,
            f"={c}{cfo_row}-{c}{rows['EBITDA']}-{c}{rows['Taxes paid']}-{c}{rows['Change in working capital']}",
            NUM,
        )
        value_cell(ws, cfo_row, 3 + i, f"={fin.cell('cfo', k)}", NUM, kind="link", bold=True)
        value_cell(ws, capex_row, 3 + i, f"={fin.cell('capex', k)}", NUM, kind="link")
        value_cell(ws, fcf_row, 3 + i, f"={c}{cfo_row}+{c}{capex_row}", NUM, bold=True)
        value_cell(
            ws,
            fcf_row + 1,
            3 + i,
            f'=IF(N({c}{rows["EBITDA"]})>0,{c}{fcf_row}/{c}{rows["EBITDA"]},"")',
            PCT,
            italic=True,
        )
    label_cell(ws, cfo_row, "Cash from operations", bold=True)
    label_cell(ws, capex_row, "Capex")
    label_cell(ws, fcf_row, "Free cash flow", bold=True)
    label_cell(ws, fcf_row + 1, "FCF conversion (% of EBITDA)", italic=True, indent=1)
    row = fcf_row + 3
    # waterfall for the latest year, built in its own small table (column C) so the helper columns line up
    k = periods[-1]
    lc = col(2 + len(periods))
    label_cell(ws, row, f"Bridge {k}", bold=True)
    row += 1
    steps: list[tuple[int, str, str]] = []
    for label, src, kind in (
        ("EBITDA", rows["EBITDA"], "total"),
        ("Taxes paid", rows["Taxes paid"], "step"),
        ("Working capital", rows["Change in working capital"], "step"),
        ("Other operating", other, "step"),
        ("Capex", capex_row, "step"),
        ("Free cash flow", fcf_row, "total"),
    ):
        label_cell(ws, row, label, indent=1)
        value_cell(ws, row, 3, f"={lc}{src}", NUM)
        steps.append((row, kind, label))
        row += 1
    vals = [_value(ctx, c, k) for c in ("ebitda", "cfo", "capex")]
    if any(v is None for v in vals) or (vals[1] or 0) + (vals[2] or 0) < 0 or (vals[0] or 0) <= 0:
        return _note(ws, row, "Chart omitted: free cash flow is negative (see the table)."), None
    return row, _waterfall(ws, steps, f"EBITDA to free cash flow {k} ({ctx.unit})", "#,##0")


def _wc_days(ws: Worksheet, ctx: ExportContext, fin: _Fin, row: int) -> tuple[int, Any]:
    row = subhead(ws, row, "Working capital days", 8)
    keys = fin.ratio_keys[-MAX_PERIODS:]
    items = [
        (rid, label)
        for rid, label in (
            ("dso", "Days sales outstanding"),
            ("dio", "Days inventory outstanding"),
            ("dpo", "Days payables outstanding"),
            ("cash_conversion_cycle", "Cash conversion cycle"),
        )
        if rid in fin.ratio_rows
    ]
    if not items or not keys:
        return _note(ws, row, "Needs receivables, inventory or payables with revenue and cost of sales."), None
    lines = [
        (label, [f"={fin.ratio(rid, k)}" if fin.ratio(rid, k) else None for k in keys], "0", False)
        for rid, label in items
    ]
    row, rows, head = _table_rows(ws, row, keys, lines)
    plotted = [rows[label] for rid, label in items if rid != "cash_conversion_cycle"] or list(rows.values())
    return row, _chart_from_rows(ws, plotted, head, len(keys), "Working capital days", kind="line", fmt="0")


def _capital(ws: Worksheet, ctx: ExportContext, fin: _Fin, row: int, periods: list[str]) -> tuple[int, Any]:
    row = subhead(ws, row, f"Capital structure ({ctx.unit})", 8)
    structures = {c["period"]: c for c in ctx.analysis.get("capital_structure") or []}
    periods = [
        k
        for k in periods
        if structures.get(k, {}).get("debt") is not None or structures.get(k, {}).get("equity") is not None
    ]
    if not periods:
        return _note(ws, row, "Needs borrowings or equity on the balance sheet."), None
    lines: list[tuple[str, list[str | None], str, bool]] = [
        ("Borrowings", [f"={fin.n('st_debt', k)}+{fin.n('lt_debt', k)}" for k in periods], NUM, False),
        (
            "Lease liabilities",
            [f"={fin.n('current_lease_liabilities', k)}+{fin.n('non_current_lease_liabilities', k)}" for k in periods],
            NUM,
            False,
        ),
        ("Book equity", [f"={fin.n('total_equity', k)}" for k in periods], NUM, False),
        (
            "Cash and short-term investments",
            [f"={fin.n('cash', k)}+{fin.n('st_investments', k)}" for k in periods],
            NUM,
            False,
        ),
    ]
    row, rows, head = _table_rows(ws, row, periods, lines)
    label_cell(ws, row, "Debt and leases / total capital", italic=True, indent=1)
    for i in range(len(periods)):
        c = col(3 + i)
        b, le, e = rows["Borrowings"], rows["Lease liabilities"], rows["Book equity"]
        value_cell(
            ws,
            row,
            3 + i,
            f'=IF(MAX({c}{b},0)+MAX({c}{le},0)+MAX({c}{e},0)>0,({c}{b}+{c}{le})/(MAX({c}{b},0)+MAX({c}{le},0)+MAX({c}{e},0)),"")',
            PCT,
            italic=True,
        )
    row += 1
    chart = _chart_from_rows(
        ws,
        [rows["Borrowings"], rows["Lease liabilities"], rows["Book equity"]],
        head,
        len(periods),
        f"Capital structure ({ctx.unit})",
        kind="stacked",
        fmt="#,##0",
    )
    return row, chart


def _maturities(ws: Worksheet, ctx: ExportContext, fin: _Fin, row: int, periods: list[str]) -> tuple[int, Any]:
    row = subhead(ws, row, f"Debt maturity profile vs liquidity ({ctx.unit})", 8)
    structures = [c for c in ctx.analysis.get("capital_structure") or [] if c.get("maturities_total") is not None]
    if not structures:
        return _note(
            ws,
            row,
            "No debt maturity analysis entered (memo lines: debt due within 1 year, 1 to 2, 2 to 5, after 5 years).",
        ), None
    cs = structures[-1]
    k = cs["period"]
    s = ctx.scale

    def ref(cid: str) -> tuple[str, str]:
        c = fin.cell(cid, k)
        return (f"=N({c})", "link") if c else ("=0", "formula")

    head = row
    row = header_row(ws, row, ["", k])
    first = row
    label_cell(ws, row, "Cash and short-term investments")
    value_cell(ws, row, 3, f"={fin.n('cash', k)}+{fin.n('st_investments', k)}", NUM, kind="link")
    cash_row = row
    row += 1
    label_cell(ws, row, "Undrawn committed facilities")
    f, kind = ref("credit_facilities")
    value_cell(ws, row, 3, f, NUM, kind=kind)
    undrawn = row
    row += 1
    label_cell(ws, row, "Liquidity available", bold=True)
    value_cell(ws, row, 3, f"=C{cash_row}+C{undrawn}", NUM, bold=True)
    liquid = row
    row += 1
    bucket_rows = []
    for b in cs["maturities"]:
        label_cell(ws, row, f"Debt due: {b['label'].lower()}", indent=1)
        f, kind = ref(b["concept_id"])
        if kind == "formula" and b["amount"] is not None:
            value_cell(ws, row, 3, b["amount"] / s, NUM, kind="value")
        else:
            value_cell(ws, row, 3, f, NUM, kind=kind)
        bucket_rows.append(row)
        row += 1
    label_cell(ws, row, "Liquidity cover of debt due within 1 year", italic=True, indent=1)
    value_cell(ws, row, 3, f'=IF(C{bucket_rows[0]}>0,C{liquid}/C{bucket_rows[0]},"n/m")', '0.0"x"', italic=True)
    row += 1
    zebra(ws, first, row - 1, 2, 3)
    _ = head
    # chart: liquidity first (its own colour), then the four maturity buckets
    chart = BarChart()
    chart.type = "col"
    rows_ = [liquid, *bucket_rows]
    # contiguous helper range in column J for the chart (liquidity + buckets) with labels in K
    for i, rr in enumerate(rows_):
        value_cell(ws, first + i, HELPER, f"=C{rr}", NUM)
        ws.cell(row=first + i, column=HELPER + 1, value="Liquidity" if i == 0 else cs["maturities"][i - 1]["label"])
    chart.add_data(Reference(ws, min_col=HELPER, min_row=first, max_row=first + len(rows_) - 1), titles_from_data=False)
    chart.set_categories(Reference(ws, min_col=HELPER + 1, min_row=first, max_row=first + len(rows_) - 1))
    _colour_series(chart)
    point = DataPoint(idx=0)
    point.graphicalProperties.solidFill = hex_(palette()["chart"]["categorical_light"][1])
    point.graphicalProperties.line.solidFill = hex_(palette()["chart"]["categorical_light"][1])
    chart.series[0].dPt = [point]
    _style_chart(chart, f"Debt maturities vs liquidity {k} ({ctx.unit})", legend=False)
    chart.y_axis.numFmt = "#,##0"
    chart.width, chart.height = 11.3, 6.6
    return row, chart


def add_breakdowns(wb: Workbook, ws: Worksheet, ctx: ExportContext, r: Refs, row: int) -> int:
    """Write the breakdowns band from ``row``; returns the next free row."""
    from .style import band

    fin = _Fin(r.pairs("fin_rows"), r.items("fin_keys"), r.pairs("ratio_rows"), r.items("ratio_keys"))
    periods = _periods(ctx, fin)
    row = band(ws, row, "Breakdowns", 8)
    pairs = [
        (lambda rr: _mix(ws, ctx, fin, rr, "segments"), lambda rr: _mix(ws, ctx, fin, rr, "geographies")),
        (lambda rr: _cost_structure(ws, ctx, fin, rr, periods), lambda rr: _margin_bridge(ws, ctx, fin, rr, periods)),
        (lambda rr: _cash_flow(ws, ctx, fin, rr, periods), lambda rr: _wc_days(ws, ctx, fin, rr)),
        (lambda rr: _capital(ws, ctx, fin, rr, periods), lambda rr: _maturities(ws, ctx, fin, rr, periods)),
    ]
    for left, right in pairs:
        row, c1 = left(row)
        row, c2 = right(row + 1)
        charts = [c for c in (c1, c2) if c is not None]
        for i, chart in enumerate(charts):
            ws.add_chart(chart, f"{'B' if i == 0 else 'E'}{row + 1}")
        row += (CHART_ROWS if charts else 0) + 1
    for i in range(7):
        ws.column_dimensions[col(HELPER + i)].hidden = True
    return row
