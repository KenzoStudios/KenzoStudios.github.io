"""One-slide summary for an investment-committee pre-screen (brief §14), built with python-pptx.

16:9, Calibri, the shared palette. Left: the suggested range, three stat callouts and a native football-field chart.
Right: rationale bullets and the checks. The AI disclaimer runs along the bottom. All figures come from the engine.
"""

from __future__ import annotations

import io

from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

from .context import ExportContext
from .style import chart_colours, colours

FONT = "Calibri"


def _rgb(hex6: str) -> RGBColor:
    return RGBColor.from_string(hex6)


def _money(v: float | None, ctx: ExportContext) -> str:
    if v is None:
        return "n/m"
    a = abs(v)
    div, suffix = (1e9, "bn") if a >= 1e9 else (1e6, "m") if a >= 1e6 else (1e3, "k") if a >= 1e3 else (1, "")
    return f"{'−' if v < 0 else ''}{ctx.currency} {a / div:,.{0 if a / div >= 100 else 1}f}{suffix}"


def _text(
    slide,
    x,
    y,
    w,
    h,
    runs,
    *,
    size=14,
    colour="text",
    bold=False,
    align=PP_ALIGN.LEFT,
    anchor=MSO_ANCHOR.TOP,
    fill=None,
):
    c = colours()
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = Inches(0.08)
    tf.margin_top = tf.margin_bottom = Inches(0.04)
    if fill:
        box.fill.solid()
        box.fill.fore_color.rgb = _rgb(c[fill])
    paragraphs = runs if isinstance(runs, list) else [runs]
    for i, para in enumerate(paragraphs):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.space_after = Pt(4)
        r = p.add_run()
        r.text = para
        r.font.name = FONT
        r.font.size = Pt(size)
        r.font.bold = bold
        r.font.color.rgb = _rgb(c[colour]) if colour in c else _rgb(colour)
    return box


def _bullets(slide, x, y, w, h, items: list[str], *, size=12):
    c = colours()
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = True
    tf.margin_left = Inches(0.08)
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.space_after = Pt(5)
        r = p.add_run()
        r.text = f"•  {item}"
        r.font.name = FONT
        r.font.size = Pt(size)
        r.font.color.rgb = _rgb(c["text"])
    return box


def build_pptx(ctx: ExportContext) -> bytes:
    c = colours()
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank
    deal = ctx.deal
    rec = ctx.recommendation.get("recommendation")
    rat = ctx.recommendation.get("rationale") or {}
    dq = ctx.recommendation["data_quality"]

    # title area on a navy panel
    panel = slide.shapes.add_shape(1, 0, 0, prs.slide_width, Inches(1.35))
    panel.fill.solid()
    panel.fill.fore_color.rgb = _rgb(c["navy"])
    panel.line.fill.background()
    _text(slide, 0.5, 0.18, 9.5, 0.6, deal.name, size=30, colour="FFFFFF", bold=True)
    _text(
        slide,
        0.5,
        0.78,
        9.5,
        0.4,
        f"{ctx.sector_name} · {ctx.country_name} · {ctx.unit} · valuation date {deal.valuation_date:%d %b %Y} · indicative pre-screen",
        size=12,
        colour=c["navy_100"],
    )
    _text(
        slide,
        10.3,
        0.35,
        2.55,
        0.65,
        [f"Data quality {dq['score']}/100", f"Grade {dq['grade']}"],
        size=13,
        colour="navy",
        bold=True,
        align=PP_ALIGN.CENTER,
        anchor=MSO_ANCHOR.MIDDLE,
        fill={"A": "positive_bg", "B": "positive_bg", "C": "warning_bg", "D": "negative_bg"}[dq["grade"]],
    )

    if rec:
        _text(slide, 0.5, 1.55, 7.4, 0.35, "Suggested acquisition price, 100% of equity", size=12, colour="grey_600")
        _text(
            slide,
            0.5,
            1.85,
            7.4,
            0.7,
            f"{_money(rec['equity_low'], ctx)} to {_money(rec['equity_high'], ctx)}",
            size=34,
            colour="navy",
            bold=True,
        )
        ps = rec.get("per_share")
        callouts = [
            (_money(rec["equity_mid"], ctx), "Mid value"),
            (f"{ctx.currency} {ps[1]:,.2f}" if ps else "n/a", "Mid per diluted share"),
            (
                f"{rec['implied']['EV / EBITDA'][1]:.1f}x" if rec["implied"]["EV / EBITDA"][1] else "n/m",
                "Implied EV / EBITDA",
            ),
        ]
        for i, (value, label) in enumerate(callouts):
            x = 0.5 + i * 2.5
            _text(slide, x, 2.7, 2.35, 0.5, value, size=22, colour="navy", bold=True)
            _text(slide, x, 3.18, 2.35, 0.3, label, size=11, colour="grey_600")
        # football field: stacked bar, transparent base + coloured range (native, editable)
        ff = ctx.valuation["result"].get("football_field") or {}
        methods = [m for m in ff.get("methods", []) if m.get("included", True)][:7]
        if methods:
            data = CategoryChartData()
            data.categories = [m["label"][:46] for m in methods][::-1]
            data.add_series("Low", [m["equity_low"] / ctx.scale for m in methods][::-1])
            data.add_series("Range", [(m["equity_high"] - m["equity_low"]) / ctx.scale for m in methods][::-1])
            frame = slide.shapes.add_chart(
                XL_CHART_TYPE.BAR_STACKED, Inches(0.4), Inches(3.6), Inches(7.6), Inches(3.25), data
            )
            chart = frame.chart
            chart.has_legend = False
            chart.has_title = True
            chart.chart_title.text_frame.text = f"Equity value by method ({ctx.unit})"
            title_run = chart.chart_title.text_frame.paragraphs[0].runs[0]
            title_run.font.size, title_run.font.bold, title_run.font.name = Pt(12), True, FONT
            title_run.font.color.rgb = _rgb(c["navy"])
            plot = chart.plots[0]
            plot.gap_width = 60
            base, rng = plot.series
            base.format.fill.background()
            base.format.line.fill.background()
            rng.format.fill.solid()
            rng.format.fill.fore_color.rgb = _rgb(chart_colours()[0])
            for axis in (chart.category_axis, chart.value_axis):
                axis.tick_labels.font.size = Pt(10)
                axis.tick_labels.font.name = FONT
                axis.tick_labels.font.color.rgb = _rgb(c["grey_600"])
                axis.format.line.color.rgb = _rgb(c["grey_200"])
            chart.value_axis.has_major_gridlines = True
            chart.value_axis.major_gridlines.format.line.color.rgb = _rgb(c["grey_200"])
            chart.value_axis.tick_labels.number_format = "#,##0"
            chart.value_axis.tick_labels.number_format_is_linked = False
    else:
        _text(
            slide,
            0.5,
            1.7,
            7.4,
            1.0,
            "No suggested price yet: complete at least one valuation method.",
            size=18,
            colour="grey_600",
        )

    # right column: rationale and checks
    _text(slide, 8.4, 1.55, 4.45, 0.35, "Why this range", size=14, colour="navy", bold=True)
    bullets = (rat.get("bullets") or [])[:4]
    _bullets(slide, 8.4, 1.9, 4.45, 2.9, bullets or ["Complete the valuation to generate the rationale."], size=12)
    if rec and rec.get("checks"):
        _text(slide, 8.4, 4.85, 4.45, 0.35, "Checks", size=14, colour="navy", bold=True)
        marks = {"pass": "Pass", "warn": "Check", "fail": "Fail", "n/a": "Not tested"}
        y = 5.2
        for chk in rec["checks"][:3]:
            tone = {"pass": "positive", "warn": "warning", "fail": "negative"}.get(chk["status"], "grey_600")
            _text(
                slide,
                8.4,
                y,
                1.05,
                0.32,
                marks.get(chk["status"], chk["status"]),
                size=11,
                colour=tone,
                bold=True,
                align=PP_ALIGN.CENTER,
                anchor=MSO_ANCHOR.MIDDLE,
                fill={"positive": "positive_bg", "warning": "warning_bg", "negative": "negative_bg"}.get(
                    tone, "grey_100"
                ),
            )
            _text(slide, 9.55, y - 0.02, 3.3, 0.55, chk["label"], size=11, colour="text")
            y += 0.5

    _text(
        slide,
        0.5,
        6.95,
        12.35,
        0.4,
        ctx.disclaimers["print_footer"] + " Indicative only; not investment advice.",
        size=10,
        colour="grey_600",
    )
    slide.notes_slide.notes_text_frame.text = ctx.disclaimers["ai_report_notice"]

    core = prs.core_properties
    core.title = f"{deal.name}: DealScout pre-screen"
    core.author = "DealScout (AI-generated)"
    core.subject = "Indicative acquisition analysis (AI-generated)"
    buf = io.BytesIO()
    prs.save(buf)
    return buf.getvalue()
