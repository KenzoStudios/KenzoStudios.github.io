"""JSON export / import of a full deal for reproducibility (brief §14).

The file holds the deal, its periods, every stored value with its provenance, all inputs (overrides, peers, notes,
entry settings, method inputs) and the headline results at export time. Uploaded documents themselves are not
included (they stay in the local data folder); their names and page references travel with each value. Importing
creates a new deal, recomputes it, and reports whether the results match the ones recorded in the file.
"""

from __future__ import annotations

from datetime import UTC, date, datetime
from typing import Any

from pydantic import BaseModel, Field
from sqlmodel import Session, select

from ..models import Deal, DealAssumptions, FinancialValue, Period

FORMAT = "dealscout.deal"
VERSION = 1


class DealFile(BaseModel):
    format: str = FORMAT
    version: int = VERSION
    exported_at: str
    deal: dict[str, Any]
    periods: list[dict[str, Any]] = Field(max_length=500)
    values: list[dict[str, Any]] = Field(max_length=100_000)
    assumptions: dict[str, Any]
    results: dict[str, Any]


# never taken from a file: identities, workflow state and timestamps are DealScout's own
_NEVER = {"id", "deal_id", "status", "archived", "created_at", "updated_at"}


def _clean(row: dict[str, Any], model: Any) -> dict[str, Any]:
    return {k: v for k, v in row.items() if k in model.model_fields and k not in _NEVER}


def _provenance(value: Any) -> dict[str, Any]:
    """Provenance is a flat record of short scalars (document name, page, label…); anything else is dropped."""
    if not isinstance(value, dict):
        return {}
    out: dict[str, Any] = {}
    for k, v in list(value.items())[:30]:
        if isinstance(k, str) and len(k) <= 40 and (v is None or isinstance(v, bool | int | float)):
            out[k] = v
        elif isinstance(k, str) and len(k) <= 40 and isinstance(v, str):
            out[k] = v[:300]
        elif (
            isinstance(k, str)
            and k == "bbox"
            and isinstance(v, list)
            and len(v) == 4
            and all(isinstance(x, int | float) for x in v)
        ):
            out[k] = v
    return out


def results_summary(valuation: dict[str, Any]) -> dict[str, Any]:
    res = valuation["result"]
    ff = res.get("football_field") or {}
    return {
        "dcf_enterprise_value": (res.get("dcf") or {}).get("enterprise_value"),
        "blended_equity_low": ff.get("blended_equity_low"),
        "blended_equity_mid": ff.get("blended_equity_mid"),
        "blended_equity_high": ff.get("blended_equity_high"),
        "methods": sorted(m["method_id"] for m in ff.get("methods", [])),
    }


def export_deal(session: Session, deal: Deal, valuation: dict[str, Any]) -> dict[str, Any]:
    periods = session.exec(select(Period).where(Period.deal_id == deal.id)).all()
    values = session.exec(select(FinancialValue).where(FinancialValue.deal_id == deal.id)).all()
    doc = session.get(DealAssumptions, deal.id)
    return DealFile(
        exported_at=datetime.now(UTC).isoformat(timespec="seconds"),
        deal=deal.model_dump(mode="json", exclude={"id", "created_at", "updated_at", "archived", "status"}),
        periods=[p.model_dump(mode="json", exclude={"id", "deal_id"}) for p in periods],
        values=[v.model_dump(mode="json", exclude={"id", "deal_id"}) for v in values],
        assumptions=doc.model_dump(mode="json", exclude={"deal_id", "updated_at"}) if doc else {},
        results=results_summary(valuation),
    ).model_dump()


def import_deal(session: Session, file: DealFile) -> Deal:
    if file.format != FORMAT or file.version > VERSION:
        raise ValueError(f"Not a DealScout deal file (format {file.format!r}, version {file.version}).")
    data = dict(file.deal)
    data["valuation_date"] = date.fromisoformat(data["valuation_date"])
    data["name"] = f"{data['name']} (imported)"[:200]
    deal = Deal(**_clean(data, Deal))
    session.add(deal)
    for p in file.periods:
        row = dict(p)
        if row.get("end_date"):
            row["end_date"] = date.fromisoformat(row["end_date"])
        session.add(Period(**_clean(row, Period), deal_id=deal.id))
    for v in file.values:
        row = dict(v)
        row["provenance"] = _provenance(row.get("provenance"))
        session.add(FinancialValue(**_clean(row, FinancialValue), deal_id=deal.id))
    a = file.assumptions or {}
    session.add(
        DealAssumptions(
            deal_id=deal.id,
            overrides=a.get("overrides") or {},
            peers=a.get("peers") or [],
            notes=a.get("notes") or {},
            entry=a.get("entry") or {},
            methods=a.get("methods") or {},
            fx=a.get("fx") or {},
        )
    )
    return deal


def compare(expected: dict[str, Any], actual: dict[str, Any], *, tolerance: float = 1e-6) -> list[str]:
    """Differences between the results recorded in the file and the recomputed ones (relative tolerance)."""
    out = []
    for key, want in expected.items():
        got = actual.get(key)
        if isinstance(want, int | float) and isinstance(got, int | float):
            if abs(got - want) > tolerance * max(abs(want), 1):
                out.append(f"{key}: file {want:,.2f}, recomputed {got:,.2f}")
        elif want != got:
            out.append(f"{key}: file {want}, recomputed {got}")
    return out
