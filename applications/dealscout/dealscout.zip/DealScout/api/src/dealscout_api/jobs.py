"""In-process background jobs tracked in SQLite, with per-step status, pause/resume and restart recovery.

Handlers receive a :class:`JobContext` and mark progress with ``ctx.step(key)``. Results must be written to
the database as each step completes, so a paused or interrupted job never loses finished work; on resume
the handler is called again and should skip steps already marked ``done`` (``ctx.is_done(key)``).
"""

from __future__ import annotations

import logging
import threading
from collections.abc import Callable, Iterator
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from typing import Any

from sqlalchemy.engine import Engine
from sqlalchemy.orm.attributes import flag_modified
from sqlmodel import Session, select

from dealscout_ai import AIError

from .models import Job, utcnow

log = logging.getLogger(__name__)


class JobContext:
    def __init__(self, engine: Engine, job_id: str):
        self.engine = engine
        self.job_id = job_id

    def load(self) -> Job:
        with Session(self.engine) as session:
            job = session.get(Job, self.job_id)
            assert job is not None
            session.expunge(job)
            return job

    @property
    def payload(self) -> dict[str, Any]:
        return self.load().payload

    def is_done(self, key: str) -> bool:
        return any(s["key"] == key and s["status"] == "done" for s in self.load().steps)

    def _update_step(self, key: str, **changes: Any) -> None:
        with Session(self.engine) as session:
            job = session.get(Job, self.job_id)
            assert job is not None
            for step in job.steps:
                if step["key"] == key:
                    step.update(changes)
            flag_modified(job, "steps")
            job.updated_at = utcnow()
            session.add(job)
            session.commit()

    @contextmanager
    def step(self, key: str, detail: str | None = None) -> Iterator[None]:
        self._update_step(key, status="running", detail=detail, started_at=utcnow().isoformat())
        try:
            yield
        except Exception as exc:
            self._update_step(key, status="failed", detail=str(exc)[:500], finished_at=utcnow().isoformat())
            raise
        self._update_step(key, status="done", finished_at=utcnow().isoformat())

    def note(self, key: str, detail: str) -> None:
        self._update_step(key, detail=detail)


Handler = Callable[[JobContext], None]


class JobRunner:
    def __init__(self, engine: Engine, *, max_workers: int = 2):
        self.engine = engine
        self.handlers: dict[str, Handler] = {}
        self._pool = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="dealscout-job")
        self._timers: list[threading.Timer] = []

    def register(self, kind: str, handler: Handler) -> None:
        self.handlers[kind] = handler

    def submit(
        self,
        kind: str,
        *,
        steps: list[tuple[str, str]],
        deal_id: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> Job:
        if kind not in self.handlers:
            raise KeyError(f"no handler registered for job kind {kind!r}")
        job = Job(
            kind=kind,
            deal_id=deal_id,
            payload=payload or {},
            steps=[{"key": k, "label": label, "status": "pending", "detail": None} for k, label in steps],
        )
        with Session(self.engine) as session:
            session.add(job)
            session.commit()
            session.refresh(job)
            session.expunge(job)
        self._pool.submit(self._run, job.id)
        return job

    def resume_pending(self) -> int:
        """At start-up: jobs interrupted mid-run go back to the queue and are restarted."""
        with Session(self.engine) as session:
            jobs = session.exec(select(Job).where(Job.status.in_(["queued", "running"]))).all()  # type: ignore[attr-defined]
            ids = []
            for job in jobs:
                job.status = "queued"
                for step in job.steps:
                    if step["status"] == "running":
                        step["status"] = "pending"
                flag_modified(job, "steps")
                session.add(job)
                ids.append(job.id)
            session.commit()
        for job_id in ids:
            self._pool.submit(self._run, job_id)
        return len(ids)

    def resume(self, job_id: str) -> None:
        with Session(self.engine) as session:
            job = session.get(Job, job_id)
            if job is None or job.status not in {"paused", "failed"}:
                return
            job.status, job.message, job.error_code = "queued", None, None
            session.add(job)
            session.commit()
        self._pool.submit(self._run, job_id)

    def _set(self, job_id: str, **changes: Any) -> None:
        with Session(self.engine) as session:
            job = session.get(Job, job_id)
            if job is None:
                return
            for key, value in changes.items():
                setattr(job, key, value)
            job.updated_at = utcnow()
            session.add(job)
            session.commit()

    def _run(self, job_id: str) -> None:
        with Session(self.engine) as session:
            job = session.get(Job, job_id)
            if job is None or job.status not in {"queued"}:
                return
            kind, attempts = job.kind, job.attempts
        handler = self.handlers.get(kind)
        if handler is None:
            self._set(job_id, status="failed", message=f"Unknown job kind {kind}")
            return
        self._set(job_id, status="running", attempts=attempts + 1)
        try:
            handler(JobContext(self.engine, job_id))
        except AIError as error:
            self._set(job_id, status="paused", message=error.message, error_code=error.code)
            if error.retryable and attempts < 5:
                delay = error.retry_after or min(60.0, 5.0 * (2**attempts))
                timer = threading.Timer(delay, self.resume, args=(job_id,))
                timer.daemon = True
                timer.start()
                self._timers.append(timer)
            return
        except Exception as error:
            log.exception("job %s failed", job_id)
            self._set(job_id, status="failed", message=str(error)[:1000], error_code="error")
            return
        self._set(job_id, status="done", message=None, error_code=None)

    def shutdown(self) -> None:
        for timer in self._timers:
            timer.cancel()
        self._pool.shutdown(wait=False, cancel_futures=True)
