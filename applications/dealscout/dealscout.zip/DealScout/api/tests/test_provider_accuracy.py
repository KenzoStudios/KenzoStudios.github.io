"""The per-provider accuracy command, run with a scripted provider (no keys, no network)."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

from dealscout_ai.testing import ScriptedProvider
from dealscout_extraction import synthetic

ROOT = Path(__file__).resolve().parents[2]


def _script():
    spec = importlib.util.spec_from_file_location("provider_accuracy", ROOT / "scripts" / "provider_accuracy.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_evaluate_provider_scores_verified_answers(tmp_path):
    (tmp_path / "ar.pdf").write_bytes(synthetic.english_annual_report())
    spec = {
        "id": "fjordline",
        "country": "GB",
        "filename": "ar.pdf",
        "number_format": "thousands ','",
        "expected": [
            {"concept": "revenue", "period": "FY2025", "value_as_written": "1,250.4", "page": 2},
            {"concept": "total_assets", "period": "FY2025", "value_as_written": "1,376.0", "page": 3},
            {"concept": "cash", "period": "FY2025", "value_as_written": "145.5", "page": 3},
        ],
    }
    answer = {
        "values": [
            {
                "concept_id": "revenue",
                "period": "2025",
                "value_as_written": "1,250.4",
                "page": 2,
                "label": "Revenue",
                "unit_scale": "€ million",
                "confidence": 0.95,
                "reason_if_null": None,
            },
            {
                "concept_id": "total_assets",
                "period": "2025",
                "value_as_written": "1,376.0",
                "page": 3,
                "label": "Total assets",
                "unit_scale": "€ million",
                "confidence": 0.95,
                "reason_if_null": None,
            },
            # invented: not printed anywhere, so it is rejected and counts as not found
            {
                "concept_id": "cash",
                "period": "2025",
                "value_as_written": "999.9",
                "page": 3,
                "label": "Cash",
                "unit_scale": "€ million",
                "confidence": 0.9,
                "reason_if_null": None,
            },
        ]
    }
    fake = ScriptedProvider({"AIExtractionResult": [json.dumps(answer)]})
    result = _script().evaluate_provider(fake.provider, [spec], tmp_path)
    assert (result.correct, result.wrong, result.missed) == (2, 0, 1)
    assert result.documents == 1 and result.cost_usd > 0
    assert result.tier == "untested"  # too few values to grade a provider


def test_measured_tiers_feed_the_connect_screen(tmp_path):
    from dealscout_ai import registry

    path = tmp_path / "provider_accuracy.json"
    path.write_text(json.dumps({"providers": {"gemini": {"tier": "medium"}, "nope": {"tier": "high"}}}))
    before = registry.PROVIDERS["gemini"].accuracy_tier
    try:
        registry._apply_measured_tiers(path)
        assert registry.PROVIDERS["gemini"].accuracy_tier == "medium"
    finally:
        registry.PROVIDERS["gemini"].accuracy_tier = before
