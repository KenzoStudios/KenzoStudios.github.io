"""Milestone 5 methods through the API: inputs per section, runs, football field, normalisation, scores."""

from __future__ import annotations

import json
import time

from test_financials_valuation import M, make_deal, seed_quick_scan

from dealscout_ai.testing import AnthropicHarness, Scenario

TRANCHES = [
    {"name": "Term Loan B", "kind": "term_loan_b", "size_x_ebitda": 3.0, "rate_type": "floating", "margin": 0.0375},
    {"name": "Senior notes", "kind": "senior_notes", "size_x_ebitda": 1.0, "rate_type": "fixed", "fixed_rate": 0.07},
]


def methods_by_id(v):
    return {m["id"]: m for m in v["methods"]}


def ff_ids(v):
    return {m["method_id"] for m in v["result"]["football_field"]["methods"]}


def test_lbo_needs_financing_then_runs(client):
    deal = make_deal(client)
    seed_quick_scan(client, deal["id"])
    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    lbo = methods_by_id(v)["lbo"]
    assert lbo["status"] == "needs_input" and any("tranches" in m for m in lbo["missing"])
    assert "lbo" not in ff_ids(v)

    r = client.put(
        f"/api/deals/{deal['id']}/methods/lbo",
        json={"tranches": TRANCHES, "entry_multiple": 9.0, "minimum_cash": 10 * M, "max_leverage": 5.0},
    )
    assert r.status_code == 200, r.text
    assert r.json()["lbo"]["entry_multiple"] == 9.0
    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    lbo = methods_by_id(v)["lbo"]
    assert lbo["status"] == "ready", lbo
    res = lbo["result"]
    assert res["inputs"]["entry_multiple"] == 9.0 and res["inputs"]["target_irr"] == 0.2
    assert any("EURIBOR 3-month" in n for n in res["notes"])  # the sourced EUR base rate, labelled
    assert len(res["case"]["schedule"]) == 5 and res["case"]["sponsor"]["irr"] is not None
    assert [len(g["values"]) for g in res["sensitivities"]] == [5, 5]
    rng = lbo["range"]
    assert rng["equity_low"] < rng["equity_mid"] < rng["equity_high"]  # +5pp IRR is the low end
    assert "lbo" in ff_ids(v)


def test_invalid_and_unknown_sections(client):
    deal = make_deal(client)
    bad = [{**TRANCHES[0], "margin": 3}]
    assert client.put(f"/api/deals/{deal['id']}/methods/lbo", json={"tranches": bad}).status_code == 422
    assert client.put(f"/api/deals/{deal['id']}/methods/nope", json={}).status_code == 404
    assert client.get(f"/api/deals/{deal['id']}/methods").json()["lbo"]["tranches"] == []


def test_precedents_nav_dlom_and_market_points(client):
    deal = make_deal(client)
    seed_quick_scan(client, deal["id"])
    deals = [
        {"announced": f"202{i}-06-30", "target": f"Target {i}", "ev": (8 + i) * 100 * M, "ebitda": 100 * M}
        for i in range(1, 5)
    ]
    assert client.put(f"/api/deals/{deal['id']}/methods/precedents", json={"transactions": deals}).status_code == 200
    nav = {"lines": [{"name": "Plant", "book_value": 500 * M, "method": "appraisal", "fair_value": 600 * M}]}
    assert client.put(f"/api/deals/{deal['id']}/methods/nav", json=nav).status_code == 200
    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    by_id = methods_by_id(v)
    assert by_id["precedents"]["status"] == "ready"
    assert by_id["precedents"]["range"]["ev_mid"] == 10.5 * 160 * M  # median 10.5x × FY2025 EBITDA
    assert by_id["nav"]["status"] == "ready"
    assert by_id["nav"]["result"]["deferred_tax"] == 100 * M * 0.3
    dcf_mid = next(m for m in v["result"]["football_field"]["methods"] if m["method_id"] == "dcf")["equity_mid"]

    dlom = {"low": 0.1, "mid": 0.2, "high": 0.3, "applies_to": "all_methods"}
    assert client.put(f"/api/deals/{deal['id']}/methods/dlom", json=dlom).status_code == 200
    v2 = client.get(f"/api/deals/{deal['id']}/valuation").json()
    assert v2["dlom_applied"] is True
    dcf2 = next(m for m in v2["result"]["football_field"]["methods"] if m["method_id"] == "dcf")
    assert abs(dcf2["equity_mid"] - dcf_mid * 0.8) < 1

    market = {"high_52w": 12.0, "low_52w": 8.0, "analyst_targets": [10.0, 11.0]}
    assert client.put(f"/api/deals/{deal['id']}/methods/market", json=market).status_code == 200
    v3 = client.get(f"/api/deals/{deal['id']}/valuation").json()
    assert [p["label"] for p in v3["market_points"]] == ["52-week high", "52-week low", "Median analyst target"]
    assert v3["market_points"][0]["equity"] == 12.0 * 50 * M


def test_normalisation_and_scores(client):
    deal = make_deal(client)
    seed_quick_scan(client, deal["id"])
    norm = {
        "use_adjusted_ebitda": True,
        "adjustments": [
            {
                "id": "r1",
                "period_key": "FY2025",
                "label": "Plant closure",
                "category": "restructuring",
                "amount": -20 * M,
                "confirmed": True,
            },
            {"id": "s1", "period_key": "FY2025", "label": "Suggested", "amount": -99 * M, "source": "ai_suggested"},
        ],
    }
    assert client.put(f"/api/deals/{deal['id']}/methods/normalisation", json=norm).status_code == 200
    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    assert v["result"]["base_ebitda"] == 180 * M  # only the confirmed item counts
    n = v["normalisation"]
    assert n["applied"] and n["pending_suggestions"] == 1
    assert n["metrics"]["reported_ebitda"] == 160 * M and n["metrics"]["adjusted_ebitda"] == 180 * M

    a = client.get(f"/api/deals/{deal['id']}/analysis").json()
    assert a["scores"]["period"] == "FY2025"
    assert [s["name"] for s in a["scores"]["items"]] == ["Altman Z", "Piotroski F", "Beneish M"]
    assert next(x for x in a["adjusted"] if x["period"] == "FY2025")["ebitda_adjustment"] == 20 * M
    assert isinstance(a["red_flags"], list)


def _wait_job(client, job_id, timeout=20.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        job = client.get(f"/api/jobs/{job_id}").json()
        if job["status"] in {"done", "failed", "paused"}:
            return job
        time.sleep(0.05)
    raise AssertionError("job did not finish")


def test_one_off_suggestions_need_ai_then_land_unconfirmed(client, app, monkeypatch):
    deal = make_deal(client)
    r = client.post(f"/api/deals/{deal['id']}/normalisation/suggest")
    assert r.status_code == 409 and "No AI provider" in r.json()["detail"]

    html = (
        b"<html><body><h1>Annual report 2025</h1><p>Note 7 Exceptional items (EUR million)</p>"
        b"<table><tr><th></th><th>2025</th><th>2024</th></tr>"
        b"<tr><td>Restructuring costs</td><td>(12.5)</td><td>-</td></tr></table></body></html>"
    )
    up = client.post(f"/api/deals/{deal['id']}/documents", files=[("files", ("report.html", html))])
    assert up.status_code == 201, up.text
    doc_id = up.json()["documents"][0]["id"]
    deadline = time.time() + 20
    while client.get(f"/api/deals/{deal['id']}/documents").json()[0]["status"] != "processed":
        assert time.time() < deadline
        time.sleep(0.05)

    answer = {
        "items": [
            {
                "label": "Restructuring costs",
                "category": "restructuring",
                "effect": "cost",
                "period": "2025",
                "value_as_written": "(12.5)",
                "page": 1,
                "unit_scale": "EUR million",
                "below_ebitda": False,
                "rationale": "Presented as exceptional.",
                "confidence": 0.9,
            },
            {
                "label": "Invented",
                "category": "other",
                "effect": "cost",
                "period": "2025",
                "value_as_written": "(3.3)",
                "page": 1,
                "unit_scale": "EUR million",
                "below_ebitda": False,
                "rationale": "Not printed.",
                "confidence": 0.9,
            },
        ]
    }
    provider, _ = AnthropicHarness().build([Scenario(text=json.dumps(answer))])
    monkeypatch.setattr(type(app.state.ai_service), "provider_for", lambda self, session, **kw: provider)
    job = client.post(f"/api/deals/{deal['id']}/normalisation/suggest").json()
    done = _wait_job(client, job["id"])
    assert done["status"] == "done", done
    items = client.get(f"/api/deals/{deal['id']}/methods").json()["normalisation"]["adjustments"]
    assert len(items) == 1
    s = items[0]
    assert s["source"] == "ai_suggested" and s["confirmed"] is False
    assert s["amount"] == -12.5 * M and s["document_id"] == doc_id and s["period_key"] == "FY2025"


def test_valuation_band_never_fails_a_valid_mid_case(client):
    """ke 3% with growth 2.5% is valid; its -1pp sensitivity end must not turn the method into an error."""
    deal = make_deal(client)
    seed_quick_scan(client, deal["id"])
    fi = {
        "ddm": {
            "current_dividend": 50 * M,
            "high_growth": 0.0,
            "years": 0,
            "terminal_growth": 0.025,
            "cost_of_equity": 0.03,
        }
    }
    assert client.put(f"/api/deals/{deal['id']}/methods/fi", json=fi).status_code == 200
    ddm = methods_by_id(client.get(f"/api/deals/{deal['id']}/valuation").json())["ddm"]
    assert ddm["status"] == "ready", ddm
    assert ddm["range"]["equity_low"] < ddm["range"]["equity_mid"] < ddm["range"]["equity_high"]


def test_lbo_settings_reject_duplicate_tranche_names(client):
    deal = make_deal(client)
    dup = [TRANCHES[0], {**TRANCHES[1], "name": TRANCHES[0]["name"]}]
    r = client.put(f"/api/deals/{deal['id']}/methods/lbo", json={"tranches": dup})
    assert r.status_code == 422 and "its own name" in r.text
