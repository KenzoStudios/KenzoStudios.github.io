"""The LBO, Precedents and NAV & SOTP tabs are live models: recalculated in LibreOffice they match the engine."""

from __future__ import annotations

import io

import pytest
from openpyxl import load_workbook
from test_financials_valuation import M, make_deal, seed_quick_scan

from dealscout_api.exports.quality import ERRORS, recalculate, soffice_path

pytestmark = pytest.mark.skipif(soffice_path() is None, reason="LibreOffice is not installed")

LBO = {
    "entry_multiple": 9.0,
    "transaction_fee_pct": 0.02,
    "minimum_cash": 10 * M,
    "rollover_equity": 20 * M,
    "management_promote_pct": 0.05,
    "cash_sweep_pct": 0.75,
    "exit_year": 4,
    "exit_multiple": 8.5,
    "exit_cost_pct": 0.01,
    "dividend_recap_year": 2,
    "dividend_recap_x_ebitda": 0.5,
    "max_leverage": 5.0,
    "min_interest_coverage": 2.0,
    "tranches": [
        {
            "name": "Senior notes",
            "kind": "senior_notes",
            "size_x_ebitda": 1.0,
            "rate_type": "fixed",
            "fixed_rate": 0.07,
        },
        {
            "name": "Term Loan B",
            "kind": "term_loan_b",
            "size_x_ebitda": 2.5,
            "rate_type": "floating",
            "margin": 0.0375,
            "amortization_pct": 0.01,
            "priority": 2,
        },
        {
            "name": "Term Loan A",
            "kind": "term_loan_a",
            "size_x_ebitda": 1.5,
            "rate_type": "floating",
            "margin": 0.03,
            "base_rate_floor": 0.01,
            "amortization_pct": 0.1,
            "fee_pct": 0.02,
            "priority": 1,
        },
        {
            "name": "Mezzanine",
            "kind": "mezzanine",
            "amount": 80 * M,
            "rate_type": "fixed",
            "fixed_rate": 0.12,
            "pik": True,
        },
        {
            "name": "Revolver",
            "kind": "revolver",
            "rate_type": "floating",
            "margin": 0.03,
            "commitment": 50 * M,
            "priority": 0,
        },
    ],
}

TRANSACTIONS = [
    {"announced": "2021-06-30", "target": "Alpha", "ev": 900 * M, "ebitda": 100 * M},
    {"announced": "2022-03-31", "target": "Beta", "ev": 1100 * M, "ebitda": 100 * M},
    {"announced": "2023-09-30", "target": "Gamma", "ev_ebitda": 8.2},
    {"announced": "2024-12-31", "target": "Delta", "ev": 1300 * M, "ebitda": 125 * M},
    {"announced": "2025-06-30", "target": "Epsilon", "ev": 700 * M, "ebitda": 70 * M, "premium_paid": 0.3},
    {"announced": "2025-01-31", "target": "Excluded", "ev": 500 * M, "ebitda": 50 * M, "include": False},
]

NAV = {
    "lines": [
        {"name": "Plant", "book_value": 100 * M, "method": "appraisal", "fair_value": 150 * M},
        {"name": "Offices", "book_value": 200 * M, "method": "cap_rate", "noi": 20 * M, "cap_rate": 0.08},
        {
            "name": "Stake",
            "book_value": 50 * M,
            "method": "multiple",
            "metric": 10 * M,
            "multiple": 7.0,
            "taxable": False,
        },
        {"name": "Cash", "book_value": 40 * M},
        {"name": "Bank debt", "side": "liability", "book_value": 120 * M},
        {"name": "Bond", "side": "liability", "book_value": 100 * M, "method": "transaction", "fair_value": 95 * M},
    ],
    "holding_discount": 0.1,
}

SOTP = {
    "segments": [
        {"name": "Machines", "metric": 100 * M, "multiple_low": 7.0, "multiple_mid": 8.0, "multiple_high": 9.5},
        {"name": "Services", "metric": 40 * M, "multiple_mid": 10.0},
        {"name": "Property", "value": 120 * M},
    ],
    "non_core_assets": 30 * M,
    "corporate_costs": 10 * M,
    "corporate_cost_multiple": 6.0,
    "conglomerate_discount": 0.1,
}


def seeded(client, *, lbo=None, half_life=None):
    deal = make_deal(client, listed=False)
    seed_quick_scan(client, deal["id"])
    base = f"/api/deals/{deal['id']}/methods"
    assert client.put(f"{base}/lbo", json=lbo or LBO).status_code == 200
    filters = {"half_life_years": half_life} if half_life else {}
    assert client.put(f"{base}/precedents", json={"transactions": TRANSACTIONS, "filters": filters}).status_code == 200
    assert client.put(f"{base}/nav", json=NAV).status_code == 200
    assert client.put(f"{base}/sotp", json=SOTP).status_code == 200
    return deal


def first_rows(ws, column: int = 3) -> dict[str, object]:
    """Label in column B → value in ``column`` for the first row with that label (the visible LBO schedule)."""
    out: dict[str, object] = {}
    for row in ws.iter_rows(min_col=2, max_col=max(column, 2)):
        label = row[0].value
        if isinstance(label, str) and label not in out:
            out[label] = row[column - 2].value
    return out


def row_values(ws, label: str, n: int) -> list[object]:
    for row in ws.iter_rows(min_col=2, max_col=3 + n):
        if row[0].value == label:
            return [c.value for c in row[1 : 1 + n]]
    raise KeyError(label)


def recalculated(client, deal_id: str, content: bytes | None = None):
    content = content or client.get(f"/api/deals/{deal_id}/export/xlsx").content
    wb = load_workbook(io.BytesIO(recalculate(content)), data_only=True)
    errors = [
        f"{ws.title}!{c.coordinate}" for ws in wb.worksheets for row in ws.iter_rows() for c in row if c.value in ERRORS
    ]
    assert errors == []
    return wb


def methods(client, deal_id: str) -> tuple[dict, dict]:
    v = client.get(f"/api/deals/{deal_id}/valuation").json()
    return v, {m["id"]: m for m in v["methods"]}


@pytest.mark.parametrize("average", [True, False])
def test_lbo_tab_recalculates_to_the_engine(client, average):
    deal = seeded(client, lbo={**LBO, "interest_on_average": average})
    _v, ms = methods(client, deal["id"])
    case = ms["lbo"]["result"]["case"]
    wb = recalculated(client, deal["id"])
    ws = wb["LBO"]
    rows = first_rows(ws)
    assert rows["Sponsor equity"] == pytest.approx(case["sponsor"]["equity_invested"] / M, rel=1e-9)
    assert rows["Total uses"] == pytest.approx(sum(u["amount"] for u in case["uses"]) / M, rel=1e-9)
    n = len(case["schedule"])
    for label, key in (
        ("Total debt", "total_debt"),
        ("Closing cash", "closing_cash"),
        ("Cash interest", "cash_interest"),
        ("PIK interest (added to principal)", "pik_interest"),
        ("Cash sweep", "sweep"),
        ("Cash taxes (on EBIT after all interest)", "cash_taxes"),
    ):
        got = row_values(ws, label, n + 1)[1:]  # skip the "At close" column
        want = [y[key] / M for y in case["schedule"]]
        assert got == pytest.approx(want, rel=1e-7, abs=1e-6), label
    assert rows["Exit equity value"] == pytest.approx(case["exit_equity"] / M, rel=1e-7)
    assert rows["Sponsor IRR"] == pytest.approx(case["sponsor"]["irr"], abs=1e-7)
    assert rows["Sponsor MOIC"] == pytest.approx(case["sponsor"]["moic"], rel=1e-7)
    assert rows["Rollover IRR"] == pytest.approx(case["rollover"]["irr"], abs=1e-7)
    assert rows["Check: sponsor IRR matches the DealScout engine"] == "✓"
    assert any(c.value == "✓ Pass" or c.value == "✗ Breach" for row in ws.iter_rows() for c in row)


def test_lbo_revolver_draw_matches_the_engine(client):
    """A cash shortfall draws the revolver: a heavily amortising term loan forces it."""
    lbo = {
        **LBO,
        "dividend_recap_year": None,
        "tranches": [
            {
                "name": "Term Loan A",
                "kind": "term_loan_a",
                "size_x_ebitda": 4.0,
                "rate_type": "fixed",
                "fixed_rate": 0.08,
                "amortization_pct": 0.3,
            },
            {"name": "Revolver", "kind": "revolver", "rate_type": "fixed", "fixed_rate": 0.06, "commitment": 200 * M},
        ],
    }
    deal = seeded(client, lbo=lbo)
    _v, ms = methods(client, deal["id"])
    case = ms["lbo"]["result"]["case"]
    assert any(y["revolver_draw"] > 0 for y in case["schedule"])
    ws = recalculated(client, deal["id"])["LBO"]
    n = len(case["schedule"])
    got = row_values(ws, "Revolver drawn", n + 1)[1:]
    assert got == pytest.approx([y["revolver_draw"] / M for y in case["schedule"]], rel=1e-7, abs=1e-6)
    assert first_rows(ws)["Sponsor IRR"] == pytest.approx(case["sponsor"]["irr"], abs=1e-7)


def test_changing_an_lbo_input_in_excel_matches_the_engine_rerun(client):
    deal = seeded(client)
    content = client.get(f"/api/deals/{deal['id']}/export/xlsx").content
    edit = load_workbook(io.BytesIO(content))
    ws = edit["LBO"]
    cell = next(row[1] for row in ws.iter_rows(min_col=2, max_col=3) if row[0].value == "Exit EV / EBITDA")
    cell.value = 10.0
    buf = io.BytesIO()
    edit.save(buf)
    irr = first_rows(recalculated(client, deal["id"], buf.getvalue())["LBO"])["Sponsor IRR"]
    client.put(f"/api/deals/{deal['id']}/methods/lbo", json={**LBO, "exit_multiple": 10.0})
    _v, ms = methods(client, deal["id"])
    assert irr == pytest.approx(ms["lbo"]["result"]["case"]["sponsor"]["irr"], abs=1e-7)


@pytest.mark.parametrize("half_life", [None, 3.0])
def test_precedents_nav_and_sotp_tabs_match_exactly(client, half_life):
    deal = seeded(client, half_life=half_life)
    v, ms = methods(client, deal["id"])
    wb = recalculated(client, deal["id"])
    pre = ms["precedents"]["result"]
    ws = wb["Precedents"]
    rows = first_rows(ws)
    assert rows["Transactions"] == 5
    for label, key in (("25th percentile", "p25"), ("Median", "median"), ("75th percentile", "p75")):
        assert rows[label] == pytest.approx(pre["stats"][key], rel=1e-9)
    assert rows["Mean (weighted)"] == pytest.approx(pre["stats"]["mean"], rel=1e-9)
    equity = first_rows(ws, 5)
    for label, key in (
        ("Low (25th percentile)", "equity_low"),
        ("Mid (median)", "equity_mid"),
        ("High (75th percentile)", "equity_high"),
    ):
        assert equity[label] == pytest.approx(pre[key] / M, rel=1e-9)

    nav = ms["nav"]["result"]
    nav_rows = first_rows(wb["NAV & SOTP"])
    assert nav_rows["NAV"] == pytest.approx(nav["nav"] / M, rel=1e-9)
    assert -nav_rows["Deferred tax on gains"] == pytest.approx(nav["deferred_tax"] / M, rel=1e-9)
    assert nav_rows["NAV before holding discount"] == pytest.approx(nav["nav_before_discount"] / M, rel=1e-9)
    sotp = ms["sotp"]["result"]
    eq = row_values(wb["NAV & SOTP"], "Equity value", 3)
    assert eq == pytest.approx([x / M for x in sotp["equity"]], rel=1e-9)

    # the Valuation Summary takes these ranges by formula, and the blended value still matches
    summary = wb["Valuation Summary"]
    ff = {m["method_id"]: m for m in v["result"]["football_field"]["methods"]}
    for mid in ("precedents", "nav", "sotp"):
        got = row_values(summary, ff[mid]["label"], 3)
        assert got == pytest.approx([ff[mid][k] / M for k in ("equity_low", "equity_mid", "equity_high")], rel=1e-9)
    blended = first_rows(summary, 4)["Blended value (weighted)"]
    assert blended == pytest.approx(v["result"]["football_field"]["blended_equity_mid"] / M, rel=1e-9)


def test_summary_links_to_live_tabs(client):
    deal = seeded(client)
    wb = load_workbook(io.BytesIO(client.get(f"/api/deals/{deal['id']}/export/xlsx").content))
    v, _ms = methods(client, deal["id"])
    label = next(m["label"] for m in v["result"]["football_field"]["methods"] if m["method_id"] == "precedents")
    cells = next(r for r in wb["Valuation Summary"].iter_rows(min_col=2, max_col=5) if r[0].value == label)
    assert cells[2].value.startswith("=MEDIAN('Precedents'!") and cells[2].font.color.rgb.endswith("008000")
    lbo = wb["LBO"]
    hidden = [r for r, d in lbo.row_dimensions.items() if d.hidden and d.outline_level == 1]
    assert hidden  # the solver passes are grouped and collapsed


def test_report_breakdowns_and_capital_structure(client):
    deal = seeded(client)
    lines = {
        "cogs": {"FY2024": -540 * M, "FY2025": -590 * M},
        "sga": {"FY2024": -180 * M, "FY2025": -190 * M},
        "cfo": {"FY2024": 100 * M, "FY2025": 115 * M},
        "taxes_paid": {"FY2024": -25 * M, "FY2025": -28 * M},
        "receivables": {"FY2025": 160 * M},
        "credit_facilities": {"FY2025": 80 * M},
        "debt_due_within_1y": {"FY2025": 50 * M},
        "debt_due_1_2y": {"FY2025": 60 * M},
        "debt_due_2_5y": {"FY2025": 150 * M},
        "debt_due_after_5y": {"FY2025": 40 * M},
    }
    changes = [{"concept_id": k, "period_key": p, "value": v} for k, ps in lines.items() for p, v in ps.items()]
    r = client.put(f"/api/deals/{deal['id']}/financials/cells", json={"changes": changes, "source": "manual"})
    assert r.status_code == 200, r.text
    mix = {"segments": [{"name": "A", "revenue": {"FY2025": 600 * M}}, {"name": "B", "revenue": {"FY2025": 400 * M}}]}
    assert client.put(f"/api/deals/{deal['id']}/methods/breakdowns", json=mix).status_code == 200

    analysis = client.get(f"/api/deals/{deal['id']}/analysis").json()
    cs = next(c for c in analysis["capital_structure"] if c["period"] == "FY2025")
    assert cs["debt"] == 300 * M and cs["maturities_total"] == 300 * M
    assert cs["liquidity_cover"] == pytest.approx(180 / 50)

    content = client.get(f"/api/deals/{deal['id']}/export/xlsx").content
    report = load_workbook(io.BytesIO(content))["Report"]
    labels = {c.value for row in report.iter_rows(min_col=2, max_col=2) for c in row if isinstance(c.value, str)}
    for heading in (
        "Revenue by segment (EUR m)",
        "Cost structure (% of revenue)",
        "EBITDA margin bridge, year on year",
        "Cash flow: EBITDA to free cash flow (EUR m)",
        "Working capital days",
        "Capital structure (EUR m)",
        "Debt maturity profile vs liquidity (EUR m)",
    ):
        assert heading in labels
    assert "No geography data entered for this deal." in labels
    assert len(report._charts) >= 7  # football field plus the breakdown charts
    rows = first_rows(recalculated(client, deal["id"], content)["Report"])
    assert rows["Liquidity cover of debt due within 1 year"] == pytest.approx(180 / 50, rel=1e-9)
    assert rows["Total"] == pytest.approx(1000)  # segment revenue in the entry scale
