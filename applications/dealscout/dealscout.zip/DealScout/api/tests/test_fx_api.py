"""FX rates per deal: the missing-rate path, a converted valuation and peer conversion/calendarisation."""

import pytest
from test_financials_valuation import M, make_deal, seed_quick_scan


def _rate(rate, source="Central bank reference rate", as_of="2025-12-31"):
    return {"rate": rate, "as_of": as_of, "source": source}


def _all_rates(average, closing):
    return [
        {"period_id": p, "average": _rate(average), "closing": _rate(closing)} for p in ("FY2023", "FY2024", "FY2025")
    ]


def test_same_currency_needs_no_rates(client):
    deal = make_deal(client)
    fx = client.get(f"/api/deals/{deal['id']}/fx").json()
    assert fx["needs_conversion"] is False
    assert fx["status"]["converted"] is False and fx["status"]["message"] is None


def test_missing_rate_blocks_valuation_with_a_clear_message(client):
    deal = make_deal(client, analysis_currency="USD")
    seed_quick_scan(client, deal["id"])
    fx = client.get(f"/api/deals/{deal['id']}/fx").json()
    assert fx["needs_conversion"] is True
    needs = {p["key"]: p["needs"] for p in fx["periods"]}
    assert needs["FY2025"] == ["average", "closing"] and needs["FY2023"] == ["average"]
    assert "FY2025 closing rate" in fx["status"]["message"]

    for path in ("valuation", "recommendation"):
        r = client.get(f"/api/deals/{deal['id']}/{path}")
        assert r.status_code == 409
        assert "EUR to USD rates are missing" in r.json()["detail"]
        assert "FY2025 average rate" in r.json()["detail"]

    # the analysis still shows, in the reporting currency, and says why
    analysis = client.get(f"/api/deals/{deal['id']}/analysis").json()
    assert analysis["currency"] == "EUR"
    assert analysis["fx"]["converted"] is False
    assert "shown in EUR" in analysis["fx"]["message"]

    # one rate entered: still blocked, now naming only what is left
    partial = [{"period_id": "FY2025", "average": _rate(1.1), "closing": _rate(1.05)}]
    assert client.put(f"/api/deals/{deal['id']}/fx", json={"rates": partial}).status_code == 200
    detail = client.get(f"/api/deals/{deal['id']}/valuation").json()["detail"]
    assert "FY2024 average rate" in detail and "FY2025" not in detail


def test_rates_are_validated(client):
    deal = make_deal(client, analysis_currency="USD")
    url = f"/api/deals/{deal['id']}/fx"
    assert client.put(url, json={"rates": [{"period_id": "FY2025", "average": _rate(0)}]}).status_code == 422
    assert (
        client.put(url, json={"rates": [{"period_id": "FY2025", "average": _rate(1.1, source="")}]}).status_code == 422
    )
    twice = [{"period_id": "FY2025"}, {"period_id": "FY2025"}]
    assert client.put(url, json={"rates": twice}).status_code == 422
    assert client.put(url, json={"peer_rates": [{"currency": "GBP", "rate": 1.2}]}).status_code == 422  # no date


def test_converted_valuation_matches_a_manual_conversion(client):
    # the same company entered twice: once in EUR, once in EUR with USD analysis at a flat 1.25 rate
    eur = make_deal(client)
    seed_quick_scan(client, eur["id"])
    usd = make_deal(client, analysis_currency="USD")
    seed_quick_scan(client, usd["id"])
    r = client.put(f"/api/deals/{usd['id']}/fx", json={"rates": _all_rates(1.25, 1.25)})
    assert r.status_code == 200 and r.json()["status"]["converted"] is True

    base = client.get(f"/api/deals/{eur['id']}/valuation").json()
    conv = client.get(f"/api/deals/{usd['id']}/valuation").json()
    assert conv["deal"]["currency"] == "USD" and conv["deal"]["reporting_currency"] == "EUR"
    assert conv["fx"]["converted"] is True
    assert "FY2025 closing rate: converted at 1.25 (2025-12-31, Central bank reference rate)" in conv["fx"]["notes"]
    # with one flat rate every amount scales by 1.25; growth, margins and multiples are unchanged
    assert conv["result"]["base_revenue"] == pytest.approx(1000 * M * 1.25)
    assert conv["result"]["dcf"]["enterprise_value"] == pytest.approx(base["result"]["dcf"]["enterprise_value"] * 1.25)
    ff, ff0 = conv["result"]["football_field"], base["result"]["football_field"]
    assert ff["blended_equity_mid"] == pytest.approx(ff0["blended_equity_mid"] * 1.25)
    assert ff["blended_per_share"]["mid"] == pytest.approx(ff0["blended_per_share"]["mid"] * 1.25)

    rec = client.get(f"/api/deals/{usd['id']}/recommendation").json()
    assert rec["deal"]["currency"] == "USD" and rec["fx"]["converted"] is True
    analysis = client.get(f"/api/deals/{usd['id']}/analysis").json()
    assert analysis["currency"] == "USD"
    assert analysis["series"]["revenue"]["FY2025"] == pytest.approx(1250 * M)


def test_average_and_closing_rates_apply_to_flows_and_balances(client):
    deal = make_deal(client, analysis_currency="USD")
    seed_quick_scan(client, deal["id"])
    client.put(f"/api/deals/{deal['id']}/fx", json={"rates": _all_rates(1.2, 1.0)})
    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    r = v["result"]
    assert r["base_revenue"] == pytest.approx(1200 * M)  # 1,000 EUR m × 1.2 average
    assert r["base_ebitda"] == pytest.approx(192 * M)  # 160 × 1.2
    assert r["bridge"]["gross_debt"] == pytest.approx(300 * M)  # 300 × 1.0 closing
    assert r["bridge"]["cash"] == pytest.approx(100 * M)


def test_peers_in_other_currencies_and_year_ends(client):
    deal = make_deal(client)
    seed_quick_scan(client, deal["id"])  # FY periods end 31 December
    peers = [
        {"name": "Euro Co", "enterprise_value": 800 * M, "ebitda": 100 * M},
        {"name": "Sterling Co", "currency": "GBP", "enterprise_value": 900 * M, "ebitda": 100 * M},
        {
            "name": "March Co",
            "fiscal_year_end_month": 3,
            "enterprise_value": 920 * M,
            "ebitda": 80 * M,
            "ebitda_next": 120 * M,
        },
        {"name": "Yen Co", "currency": "JPY", "enterprise_value": 1000 * M, "ebitda": 100 * M},
    ]
    assert client.put(f"/api/deals/{deal['id']}/assumptions", json={"peers": peers}).status_code == 200
    client.put(
        f"/api/deals/{deal['id']}/fx",
        json={"peer_rates": [{"currency": "gbp", **_rate(1.17, "ECB reference rate")}]},
    )
    fx = client.get(f"/api/deals/{deal['id']}/fx").json()
    assert fx["peer_currencies"] == ["GBP", "JPY"] and fx["missing_peer_currencies"] == ["JPY"]

    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    rows = {r["name"]: r for r in v["peer_adjustments"]}
    assert rows["Sterling Co"]["converted"] and "GBP converted at 1.17" in rows["Sterling Co"]["fx_note"]
    assert rows["March Co"]["calendarised"] and rows["March Co"]["weights"] == [0.25, 0.75]
    assert rows["Yen Co"]["missing_rate"]
    stats = next(s for s in v["peer_stats"] if s["multiple_id"] == "ev_ebitda")
    # Euro 8.0x, Sterling 9.0x (unchanged by conversion), March 920 / (0.25 × 80 + 0.75 × 120) = 8.364x
    assert stats["values"] == pytest.approx({"Euro Co": 8.0, "Sterling Co": 9.0, "March Co": 920 / 110})
    assert "No JPY to EUR rate entered" in stats["excluded"]["Yen Co"]


def test_excel_financials_use_the_analysis_currency(client):
    """Every tab of a converted deal's workbook is in one currency: flows at the average, balances at the closing rate."""
    import io

    from openpyxl import load_workbook

    deal = make_deal(client, analysis_currency="USD")
    seed_quick_scan(client, deal["id"])
    client.put(f"/api/deals/{deal['id']}/fx", json={"rates": _all_rates(1.2, 1.0)})
    r = client.get(f"/api/deals/{deal['id']}/export/xlsx")
    assert r.status_code == 200
    ws = load_workbook(io.BytesIO(r.content))["Financials"]
    found = {}
    for row in ws.iter_rows():
        label = row[0].value if row[0].value is not None else (row[1].value if len(row) > 1 else None)
        if label in ("Revenue", "Cash and cash equivalents"):
            nums = [c.value for c in row if isinstance(c.value, int | float)]
            found.setdefault(label, nums)
    assert 1200 in [round(v) for v in found["Revenue"]]  # 1,000 EUR m × 1.2 average, in USD m
    assert 100 in [round(v) for v in found["Cash and cash equivalents"]]  # closing rate 1.0
