from datetime import date

from conftest import DEAL


def test_create_get_list_update_duplicate_delete(client, settings):
    r = client.post("/api/deals", json=DEAL)
    assert r.status_code == 201, r.text
    deal = r.json()
    assert deal["country"] == "DE" and deal["reporting_currency"] == "EUR"
    assert deal["analysis_currency"] == "EUR"  # defaults to reporting currency
    assert deal["valuation_date"] == date.today().isoformat()
    assert deal["sector_template"] == "general"
    assert deal["country_name"] == "Germany"
    assert deal["ticker"] is None

    r = client.get("/api/deals", params={"q": "acme"})
    assert r.json()["total"] == 1
    assert client.get("/api/deals", params={"q": "nomatch"}).json()["total"] == 0
    assert client.get("/api/deals", params={"sector": "banks"}).json()["total"] == 0

    r = client.patch(f"/api/deals/{deal['id']}", json={"listed": True, "ticker": "acm", "sector": "banks"})
    assert r.status_code == 200, r.text
    assert r.json()["ticker"] == "ACM"
    assert r.json()["sector_template"] == "bank"

    audit = client.get(f"/api/deals/{deal['id']}/audit").json()
    assert {e["action"] for e in audit} == {"deal_created", "deal_updated"}
    assert set(audit[0]["detail"]["changes"]) == {"listed", "ticker", "sector"}
    assert audit[0]["detail"]["changes"]["ticker"] == {"old": "—", "new": "ACM"}
    # saving identical values records nothing
    client.patch(f"/api/deals/{deal['id']}", json={"name": deal["name"], "country": "DE"})
    assert len(client.get(f"/api/deals/{deal['id']}/audit").json()) == 2
    assert audit[0]["actor"] == "Analyst"

    dup = client.post(f"/api/deals/{deal['id']}/duplicate").json()
    assert dup["name"].endswith("(copy)") and dup["id"] != deal["id"]

    folder = settings.uploads_dir / deal["id"]
    folder.mkdir(parents=True)
    (folder / "report.pdf").write_bytes(b"%PDF")
    assert client.delete(f"/api/deals/{deal['id']}").status_code == 204
    assert not folder.exists()
    assert client.get(f"/api/deals/{deal['id']}").status_code == 404
    assert client.get("/api/deals").json()["total"] == 1


def test_validation_errors(client):
    assert client.post("/api/deals", json={**DEAL, "country": "XX"}).status_code == 422
    assert client.post("/api/deals", json={**DEAL, "reporting_currency": "ABC"}).status_code == 422
    assert client.post("/api/deals", json={**DEAL, "sector": "nope"}).status_code == 422
    assert client.post("/api/deals", json={**DEAL, "name": "   "}).status_code == 422
    assert client.post("/api/deals", json={**DEAL, "perspective": "hostile"}).status_code == 422


def test_actor_is_user_name_from_settings(client):
    client.patch("/api/settings", json={"user_name": "J. Analyst"})
    deal = client.post("/api/deals", json=DEAL).json()
    assert client.get(f"/api/deals/{deal['id']}/audit").json()[0]["actor"] == "J. Analyst"


def test_meta_and_taxonomy(client):
    meta = client.get("/api/meta").json()
    assert "not investment advice" in meta["disclaimers"]["short"]
    codes = [c["code"] for c in meta["reference"]["countries"]]
    assert "JP" in codes and "NO" in codes and False not in codes  # YAML must not read NO as false
    tax = client.get("/api/taxonomy").json()
    assert any(c["id"] == "ebitda" for c in tax["concepts"])


def test_new_deal_survives_concurrent_first_loads(client):
    """The cockpit loads four endpoints at once for a new deal; none may fail creating its default rows."""
    from concurrent.futures import ThreadPoolExecutor

    deal = client.post("/api/deals", json={**__import__("conftest").DEAL, "valuation_date": "2026-03-31"}).json()
    paths = ["recommendation", "valuation", "analysis", "review", "financials", "methods"] * 3
    with ThreadPoolExecutor(max_workers=8) as pool:
        codes = list(pool.map(lambda p: client.get(f"/api/deals/{deal['id']}/{p}").status_code, paths))
    assert codes == [200] * len(paths)
