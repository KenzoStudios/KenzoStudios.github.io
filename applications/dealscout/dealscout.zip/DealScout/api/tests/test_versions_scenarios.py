"""Saved versions (save, list, compare, restore with undo), custom scenarios and per-year driver overrides."""

from test_financials_valuation import M, cells, make_deal, seed_quick_scan


def _ready_deal(client):
    deal = make_deal(client)
    seed_quick_scan(client, deal["id"])
    return deal


def test_save_list_compare_and_restore_a_version(client):
    deal = _ready_deal(client)
    deal_id = deal["id"]
    assert client.get(f"/api/deals/{deal_id}/versions").json() == []
    assert client.post(f"/api/deals/{deal_id}/versions", json={"name": "  "}).status_code == 422

    saved = client.post(f"/api/deals/{deal_id}/versions", json={"name": "IC draft", "note": "Before diligence"})
    assert saved.status_code == 201, saved.text
    v1 = saved.json()
    assert v1["name"] == "IC draft" and v1["kind"] == "manual" and v1["note"] == "Before diligence"
    assert v1["results"]["blended_equity_mid"] > 0
    assert v1["counts"]["values"] > 0
    before_mid = v1["results"]["blended_equity_mid"]

    # change inputs: a value, an assumption, a note and a period
    cells(deal_id, client, {"revenue": {"FY2025": 1200 * M}})
    put = client.put(
        f"/api/deals/{deal_id}/assumptions",
        json={"overrides": {**client.get(f"/api/deals/{deal_id}/assumptions").json()["overrides"], "tax_rate": 0.2}},
    )
    assert put.status_code == 200
    assert client.post(f"/api/deals/{deal_id}/periods", json={"key": "FY2022"}).status_code == 201
    client.patch(f"/api/deals/{deal_id}", json={"perspective": "strategic", "mode": "detailed"})

    diff = client.get(f"/api/deals/{deal_id}/versions/{v1['id']}/compare").json()
    assert diff["periods"] == {"added": ["FY2022"], "removed": []}
    revenue = next(d for d in diff["values"] if d["concept_id"] == "revenue")
    assert revenue["version"] == 1000 * M and revenue["current"] == 1200 * M and revenue["label"] == "Revenue"
    changed = {(d["section"], d["key"]) for d in diff["inputs"]}
    assert (
        ("overrides", "tax_rate") in changed and ("deal", "perspective") in changed and ("deal", "mode") not in changed
    )
    mid = next(r for r in diff["results"] if r["key"] == "blended_equity_mid")
    assert mid["version"] == before_mid and mid["current"] != before_mid and mid["change"] is not None

    restored = client.post(f"/api/deals/{deal_id}/versions/{v1['id']}/restore")
    assert restored.status_code == 200, restored.text
    backup = restored.json()["backup"]
    assert backup["kind"] == "before_restore" and "IC draft" in backup["name"]

    after = client.get(f"/api/deals/{deal_id}/versions/{v1['id']}/compare").json()
    assert after["values"] == [] and after["periods"] == {"added": [], "removed": []}
    assert after["inputs"] == []
    after_deal = client.get(f"/api/deals/{deal_id}").json()
    assert after_deal["perspective"] == "financial_sponsor" and after_deal["mode"] == "detailed"  # mode is a view
    v = client.get(f"/api/deals/{deal_id}/valuation").json()
    assert v["result"]["football_field"]["blended_equity_mid"] == before_mid

    # the restore is logged in the value history and audit log, and can itself be undone
    history = client.get(
        f"/api/deals/{deal_id}/financials/history", params={"concept_id": "revenue", "period_key": "FY2025"}
    ).json()
    assert history[0]["new_value"] == 1000 * M and "Restored version" in history[0]["reason"]
    actions = [e["action"] for e in client.get(f"/api/deals/{deal_id}/audit").json()]
    assert actions[:2] == ["version_restored", "version_saved"] and actions.count("version_saved") == 2
    client.post(f"/api/deals/{deal_id}/versions/{backup['id']}/restore")
    grid = client.get(f"/api/deals/{deal_id}/financials").json()
    assert "FY2022" in [p["key"] for p in grid["periods"]]
    assert client.get(f"/api/deals/{deal_id}").json()["perspective"] == "strategic"

    listing = client.get(f"/api/deals/{deal_id}/versions").json()
    assert len(listing) == 3 and listing[0]["kind"] == "before_restore"

    other = make_deal(client)
    assert client.get(f"/api/deals/{other['id']}/versions/{v1['id']}/compare").status_code == 404
    assert client.delete(f"/api/deals/{deal_id}").status_code == 204


def test_custom_scenarios_are_stored_validated_and_run(client):
    deal = _ready_deal(client)
    deal_id = deal["id"]
    methods = client.get(f"/api/deals/{deal_id}/methods").json()
    assert [s["name"] for s in methods["scenarios"]] == ["bear", "base", "bull"]

    bad_sum = [{"name": "a", "probability": 0.5}, {"name": "b", "probability": 0.3}]
    assert client.put(f"/api/deals/{deal_id}/methods/scenarios", json=bad_sum).status_code == 422
    seven = [{"name": f"s{i}", "probability": 1 / 7} for i in range(7)]
    assert client.put(f"/api/deals/{deal_id}/methods/scenarios", json=seven).status_code == 422

    custom = [
        {"name": "Downside", "probability": 0.2, "growth_shift": -0.03, "margin_shift": -0.02, "wacc_shift": 0.01},
        {"name": "Base", "probability": 0.5},
        {"name": "Upside", "probability": 0.2, "exit_multiple_shift": 1.0, "terminal_growth_shift": 0.0025},
        {"name": "Strong upside", "probability": 0.1, "growth_shift": 0.04, "margin_shift": 0.03},
    ]
    r = client.put(f"/api/deals/{deal_id}/methods/scenarios", json=custom)
    assert r.status_code == 200, r.text
    v = client.get(f"/api/deals/{deal_id}/valuation").json()
    assert v["scenarios_error"] is None
    names = [s["name"] for s in v["scenarios"]["scenarios"]]
    assert names == ["Downside", "Base", "Upside", "Strong upside"]
    evs = {s["name"]: s["enterprise_value"] for s in v["scenarios"]["scenarios"]}
    assert evs["Downside"] < evs["Base"] < evs["Strong upside"]
    assert v["scenarios"]["scenarios"][2]["terminal_growth"] > v["scenarios"]["scenarios"][1]["terminal_growth"]

    # a scenario that breaks the DCF reports why instead of dropping silently
    broken = [{"name": "Hot", "probability": 1.0, "terminal_growth_shift": 0.1}]
    assert client.put(f"/api/deals/{deal_id}/methods/scenarios", json=broken).status_code == 200
    v = client.get(f"/api/deals/{deal_id}/valuation").json()
    assert v["scenarios"] is None and "Hot" in v["scenarios_error"]

    # exports keep working with custom scenarios
    assert client.get(f"/api/deals/{deal_id}/export/pdf").status_code == 200


def test_per_year_driver_overrides_via_api(client):
    deal = _ready_deal(client)
    deal_id = deal["id"]
    overrides = client.get(f"/api/deals/{deal_id}/assumptions").json()["overrides"]
    per_year = {
        "revenue_growth": [0.12, 0.1, 0.08, 0.06, 0.04],
        "capex_pct_revenue": [0.07, 0.06, 0.05, 0.05, 0.05],
        "nwc_pct_revenue": [0.1, 0.1, 0.11, 0.11, 0.12],
    }
    r = client.put(f"/api/deals/{deal_id}/assumptions", json={"overrides": {**overrides, **per_year}})
    assert r.status_code == 200, r.text
    v = client.get(f"/api/deals/{deal_id}/valuation").json()
    proj = v["result"]["dcf"]["projection"]
    assert [round(y["revenue_growth"], 4) for y in proj] == per_year["revenue_growth"]
    assert abs(proj[0]["capex"] - proj[0]["revenue"] * 0.07) < 1
    resolved = {a["key"]: a for a in v["result"]["assumptions"]}
    assert resolved["capex_pct_revenue"]["value"] == per_year["capex_pct_revenue"]
    for fmt in ("pdf", "xlsx", "pptx"):
        assert client.get(f"/api/deals/{deal_id}/export/{fmt}").status_code == 200, fmt
