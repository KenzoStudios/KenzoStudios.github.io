from dealscout_ai import ConnectionResult, Usage
from dealscout_api.services import ai_service as ai_service_module

SECRET = "sk-test-not-a-real-key-9876"


class FakeProvider:
    def __init__(self, ok=True):
        self.ok = ok

    def test_connection(self):
        usage = Usage(
            provider="anthropic", model="claude-opus-5-5", input_tokens=10, output_tokens=2, estimated_cost_usd=0.5
        )
        if self.ok:
            return ConnectionResult(
                ok=True, provider="anthropic", model="claude-opus-5-5", code="ok", message="Connected", usage=usage
            )
        return ConnectionResult(
            ok=False,
            provider="anthropic",
            model="claude-opus-5-5",
            code="invalid_key",
            message="Anthropic rejected the API key (invalid or revoked).",
        )


def test_providers_catalogue_and_status_without_connection(client):
    data = client.get("/api/ai/providers").json()
    ids = [p["spec"]["id"] for p in data["providers"]]
    assert ids[0] == "anthropic" and "azure_openai" in ids and "custom" in ids
    assert data["status"]["connected"] is False
    assert data["key_storage"]["backend"] == "file"


def test_save_key_never_returned_and_test_connection(client, app, monkeypatch):
    r = client.put("/api/ai/connections/anthropic", json={"api_key": SECRET, "model": "claude-opus-5-5"})
    assert r.status_code == 200, r.text
    assert SECRET not in r.text
    anthropic_state = next(p for p in r.json()["providers"] if p["spec"]["id"] == "anthropic")
    assert anthropic_state["key"] == {"present": True, "source": "file", "last4": "9876"}
    assert r.json()["status"]["connected"] is True

    for path in ["/api/ai/providers", "/api/ai/status", "/api/settings"]:
        assert SECRET not in client.get(path).text

    monkeypatch.setattr(ai_service_module, "create_provider", lambda config: FakeProvider(ok=True))
    result = client.post("/api/ai/connections/anthropic/test").json()
    assert result["ok"] is True
    assert client.get("/api/ai/usage").json()["summary"][0]["purpose"] == "connection_test"
    assert client.get("/api/ai/status").json()["month_spend_usd"] == 0.5

    monkeypatch.setattr(ai_service_module, "create_provider", lambda config: FakeProvider(ok=False))
    result = client.post("/api/ai/connections/anthropic/test").json()
    assert result["code"] == "invalid_key"

    assert client.delete("/api/ai/connections/anthropic/key").status_code == 204
    state = next(p for p in client.get("/api/ai/providers").json()["providers"] if p["spec"]["id"] == "anthropic")
    assert state["key"]["present"] is False


def test_env_key_is_used_when_nothing_saved(client, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-from-env-1234")
    state = next(p for p in client.get("/api/ai/providers").json()["providers"] if p["spec"]["id"] == "anthropic")
    assert state["key"]["source"] == "env" and state["key"]["last4"] == "1234"


def test_unknown_provider_is_rejected(client):
    r = client.put("/api/ai/connections/not-a-provider", json={"api_key": "sk-x", "model": "m"})
    assert r.status_code == 404


def test_custom_endpoint_needs_no_key_but_a_valid_url(client):
    bad = client.put("/api/ai/connections/custom", json={"base_url": "ftp://example", "model": "llama3.1"})
    assert bad.status_code == 422
    ok = client.put("/api/ai/connections/custom", json={"base_url": "http://localhost:11434/v1", "model": "llama3.1"})
    assert ok.status_code == 200, ok.text
    state = next(p for p in ok.json()["providers"] if p["spec"]["id"] == "custom")
    assert state["connection"]["base_url"] == "http://localhost:11434/v1" and not state["key"]["present"]


def test_ai_disabled_and_spend_cap_block_calls(client, app):
    from sqlmodel import Session

    from dealscout_api.db import get_engine

    client.put("/api/ai/connections/anthropic", json={"api_key": SECRET})
    service = app.state.ai_service
    with Session(get_engine()) as session:
        service.record_usage(
            session, Usage(provider="anthropic", model="m", estimated_cost_usd=12.0), purpose="extraction"
        )
        session.commit()
    client.patch("/api/settings", json={"monthly_spend_cap_usd": 10})
    with Session(get_engine()) as session:
        try:
            service.provider_for(session)
            raise AssertionError("expected spend cap error")
        except Exception as error:
            assert getattr(error, "code", "") == "spend_cap_reached"
    client.patch("/api/settings", json={"monthly_spend_cap_usd": None, "ai_enabled": False})
    with Session(get_engine()) as session:
        try:
            service.provider_for(session)
            raise AssertionError("expected disabled error")
        except Exception as error:
            assert getattr(error, "code", "") == "ai_disabled"
    assert client.get("/api/ai/status").json()["enabled"] is False


def test_stored_key_is_never_sent_to_a_new_address(client):
    """Security: a saved key only goes to the address it was entered for (first-party addresses are fixed)."""
    assert (
        client.put("/api/ai/connections/anthropic", json={"api_key": SECRET, "model": "claude-opus-5-5"}).status_code
        == 200
    )
    r = client.put("/api/ai/connections/anthropic", json={"base_url": "https://attacker.example/"})
    assert r.status_code == 422
    state = next(p for p in client.get("/api/ai/providers").json()["providers"] if p["spec"]["id"] == "anthropic")
    assert state["key"]["present"] is True and state["connection"]["base_url"] is None

    ok = client.put(
        "/api/ai/connections/custom", json={"base_url": "http://localhost:11434/v1", "api_key": SECRET, "model": "m"}
    )
    assert ok.status_code == 200
    moved = client.put("/api/ai/connections/custom", json={"base_url": "http://127.0.0.1:9999/v1", "model": "m"})
    assert moved.status_code == 200
    custom = next(p for p in moved.json()["providers"] if p["spec"]["id"] == "custom")
    assert custom["key"]["present"] is False  # the key must be entered again for the new address
