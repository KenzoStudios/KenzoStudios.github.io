"""Peer sourcing: AI-suggested peers (names only), CSV import through the market data connector, new multiples."""

from __future__ import annotations

import json

import pytest
from test_financials_valuation import M, make_deal, seed_quick_scan

from dealscout_ai.testing import AnthropicHarness, Scenario
from dealscout_api.services import market_data


# ── AI-suggested peers ───────────────────────────────────────────────────────────
def test_peer_suggestions_names_only(client, app, monkeypatch):
    deal = make_deal(client)
    client.put(f"/api/deals/{deal['id']}/assumptions", json={"peers": [{"name": "Existing Peer AG", "include": True}]})
    r = client.post(f"/api/deals/{deal['id']}/peers/suggest")
    assert r.status_code == 409 and "Connect" in r.json()["detail"]  # no AI connected: graceful message

    answer = {
        "peers": [
            {
                "name": "Krones AG",
                "ticker": "KRN",
                "exchange": "XETRA",
                "country": "de",
                "reason": "Packaging and process machinery for similar end markets.",
            },
            {
                "name": "GEA Group AG",
                "ticker": "G1A",
                "exchange": "XETRA",
                "country": "DE",
                "reason": "Trades at 9.5x EBITDA with 20% margins.",  # figures: reason dropped, name kept
            },
            {"name": "Existing Peer AG", "ticker": "", "exchange": "", "country": "DE", "reason": "Already listed."},
            {"name": "Unknown Ticker Co", "ticker": "", "exchange": "", "country": "Germany", "reason": "Close fit."},
        ]
    }
    provider, rec = AnthropicHarness().build([Scenario(text=json.dumps(answer))])
    monkeypatch.setattr(type(app.state.ai_service), "provider_for", lambda self, session, **kw: provider)
    r = client.post(f"/api/deals/{deal['id']}/peers/suggest")
    assert r.status_code == 200, r.text
    body = r.json()
    names = [s["name"] for s in body["suggestions"]]
    assert names == ["Krones AG", "GEA Group AG", "Unknown Ticker Co"]  # the existing peer is not repeated
    krones, gea, unknown = body["suggestions"]
    assert krones == {
        "name": "Krones AG",
        "ticker": "KRN",
        "exchange": "XETRA",
        "country": "DE",
        "reason": "Packaging and process machinery for similar end markets.",
    }
    assert gea["reason"] is None and body["reasons_dropped"] == 1
    assert unknown["ticker"] is None and unknown["country"] is None
    assert "suggestions to verify" in body["note"]
    # no figures anywhere in what is returned for a suggestion
    for s in body["suggestions"]:
        assert set(s) == {"name", "ticker", "exchange", "country", "reason"}
    # the prompt carries the deal context and forbids figures; usage is recorded
    sent = json.dumps(rec.requests[-1])
    assert "Acme Industrial GmbH" in sent and "Existing Peer AG" in sent and "Never write any financial figure" in sent
    usage = client.get("/api/ai/usage", params={"deal_id": deal["id"]}).json()
    assert [s["purpose"] for s in usage["summary"]] == ["peer_suggestions"]
    # suggestions are not saved as peers
    assert len(client.get(f"/api/deals/{deal['id']}/assumptions").json()["peers"]) == 1


# ── market data connector: manual / CSV import ──────────────────────────────────
GOOD = (
    "name,ticker,country,market_cap,net_debt,revenue,ebitda,rent_expense,revenue_cy,ebitda_cy,eps_growth_pct,"
    "currency,as_of,source\n"
    'Alpha plc,ALP,gb,"1,200",300,900,150,25,950,160,8%,GBP,2026-10-31,Broker note\n'
    "Beta SA,BET,FR,800,(50),600,90,,,,12,EUR,2026-10-31,\n"
)


def test_csv_template_and_providers(client):
    r = client.get("/api/market-data/peers-template.csv")
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/csv")
    header = r.text.splitlines()[0].split(",")
    assert header[0] == "name" and "eps_growth_pct" in header and "revenue_ny" in header
    # the template's example row imports cleanly
    parsed = market_data.parse_peer_csv(r.content)
    assert len(parsed.peers) == 1 and not parsed.errors
    providers = client.get("/api/market-data/providers").json()
    assert [p["id"] for p in providers] == ["csv"]
    assert providers[0]["enabled"] and not providers[0]["requires_key"]


def test_csv_import_valid_rows(client):
    deal = make_deal(client)
    r = client.post(
        f"/api/deals/{deal['id']}/peers/import",
        params={"scale": 1e6},
        files={"file": ("peers.csv", GOOD.encode(), "text/csv")},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["errors"] == [] and len(body["peers"]) == 2
    alpha, beta = body["peers"]
    assert alpha["market_cap"] == 1200 * M and alpha["net_debt"] == 300 * M and alpha["rent_expense"] == 25 * M
    assert alpha["revenue_cy"] == 950 * M and alpha["eps_growth"] == pytest.approx(0.08)
    assert alpha["country"] == "GB" and alpha["ticker"] == "ALP"
    assert beta["net_debt"] == -50 * M and beta["eps_growth"] == pytest.approx(0.12) and beta["rent_expense"] is None
    assert body["quotes"][0] == {
        "ticker": "ALP",
        "price": None,
        "market_cap": 1200 * M,
        "currency": "GBP",
        "as_of": "2026-10-31",
        "source": "Broker note",
    }
    assert body["quotes"][1]["source"] == "CSV import"
    # nothing saved until the analyst saves the peers
    assert client.get(f"/api/deals/{deal['id']}/assumptions").json()["peers"] == []


def test_csv_import_invalid_rows_reported():
    text = (
        "name,ticker,market_cap,enterprise_value,revenue,price,shares,eps_growth_pct,as_of,currency,colour\n"
        "Good Co,GC,500,,100,,,,,,blue\n"
        ",NONAME,500,,100,,,,,,\n"
        "Bad Number,BN,abc,,100,,,,,,\n"
        "No Value,NV,,,100,,,,,,\n"
        "Negative Cap,NC,-5,,100,,,,,,\n"
        "Good Co,GC2,400,,100,,,,,,\n"
        "Bad Growth,BG,400,,100,,,5000,,,\n"
        "Bad Date,BD,400,,100,,,,31/10/2026,EURO,\n"
        "From Price,FP,,,100,12.5,40,,,,\n"
    )
    result = market_data.parse_peer_csv(text.encode(), existing={"Existing"})
    assert [p.name for p in result.peers] == ["Good Co", "From Price"]
    assert result.peers[1].market_cap == pytest.approx(500)  # 12.5 × 40
    errors = {e.row: e for e in result.errors}
    assert errors[3].errors == ["Name is missing."]
    assert errors[4].errors == ["market_cap: 'abc' is not a number."]
    assert errors[5].errors == ["Give a market cap, an enterprise value, or a price and share count."]
    assert "market_cap must be positive." in errors[6].errors
    assert errors[7].errors[0].startswith("Duplicate peer name")
    assert "eps_growth_pct must be a percentage between -100 and 1000." in errors[8].errors
    assert set(errors[9].errors) == {"as_of must be a date as YYYY-MM-DD.", "currency must be a 3-letter ISO code."}
    assert result.warnings == ["Ignored unknown columns: colour."]
    # the connector interface serves quotes and fundamentals from the import
    provider = market_data.CsvImportProvider.from_import(result)
    assert isinstance(provider, market_data.MarketDataProvider)
    assert provider.quote("fp").price == 12.5 and provider.fundamentals("GC").figures["revenue"] == 100
    assert provider.quote("NOPE") is None


def test_csv_import_rejects_bad_files(client):
    deal = make_deal(client)
    url = f"/api/deals/{deal['id']}/peers/import"
    r = client.post(url, files={"file": ("peers.xlsx", b"x", "application/octet-stream")})
    assert r.status_code == 415
    r = client.post(url, files={"file": ("peers.csv", b"ticker,price\nA,1\n", "text/csv")})
    assert r.status_code == 422 and "name" in r.json()["detail"]
    r = client.post(url, params={"scale": 7}, files={"file": ("peers.csv", GOOD.encode(), "text/csv")})
    assert r.status_code == 422


# ── new multiples and bases through the valuation endpoint ──────────────────────
def test_valuation_peer_stats_by_basis_and_new_multiples(client):
    deal = make_deal(client)
    seed_quick_scan(client, deal["id"])
    peers = [
        {
            "name": f"Peer {i}",
            "include": True,
            "enterprise_value": m * 100 * M,
            "market_cap": m * 80 * M,
            "ebitda": 100 * M,
            "ebitda_cy": 125 * M,
            "net_income": 40 * M,
            "eps_growth": 0.1,
            "rent_expense": 25 * M,
        }
        for i, m in enumerate([7.0, 8.0, 9.0, 10.0])
    ]
    client.put(f"/api/deals/{deal['id']}/assumptions", json={"peers": peers})
    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    assert v["comps_basis"] == "ltm" and set(v["peer_stats_by_basis"]) == {"ltm", "cy", "ny"}
    stats = {s["multiple_id"]: s for s in v["peer_stats"]}
    assert stats["ev_ebitdar"]["median"] == pytest.approx(6.8)  # 850 / 125
    assert stats["peg"]["median"] == pytest.approx(1.7)  # P/E 17 / 10
    cy = {s["multiple_id"]: s for s in v["peer_stats_by_basis"]["cy"]}
    assert cy["ev_ebitda"]["median"] == pytest.approx(6.8) and cy["ev_ebitdar"]["n"] == 0
    # industrials: no sector multiple in the football field by default
    ids = {m["method_id"] for m in v["result"]["football_field"]["methods"]}
    assert not ids & {"comps_ev_ebitdar", "comps_peg", "comps_ev_arr", "comps_p_nav"}

    overrides = client.get(f"/api/deals/{deal['id']}/assumptions").json()["overrides"]
    r = client.put(f"/api/deals/{deal['id']}/assumptions", json={"overrides": {**overrides, "comps_basis": "cy"}})
    assert r.status_code == 200, r.text
    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    assert v["comps_basis"] == "cy"
    bar = next(m for m in v["result"]["football_field"]["methods"] if m["method_id"] == "comps_ev_ebitda")
    assert bar["label"].endswith("(CY)")
    r = client.put(f"/api/deals/{deal['id']}/assumptions", json={"overrides": {"comps_basis": "fy"}})
    assert r.status_code == 422


def test_sector_multiples_suggested_for_transport(client):
    deal = make_deal(client, sector="transport")
    r = client.get(f"/api/deals/{deal['id']}/recommendation").json()
    suit = {s["method_id"]: s for s in r["suitability"]}
    assert suit["comps_ev_ebitdar"]["relevance"] == "secondary" and suit["comps_ev_ebitdar"]["weight"] == 0.5
    assert suit["comps_p_nav"]["weight"] == 0
