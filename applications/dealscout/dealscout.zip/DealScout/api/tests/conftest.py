from __future__ import annotations

import dataclasses

import pytest
from fastapi.testclient import TestClient

from dealscout_api import config as config_module


@pytest.fixture
def settings(tmp_path, monkeypatch):
    monkeypatch.setenv("DEALSCOUT_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("DEALSCOUT_TEST_NO_KEYRING", "1")
    for name in ["ANTHROPIC_API_KEY", "ANTHROPIC_MODEL", "DEALSCOUT_DISABLE_AI"]:
        monkeypatch.delenv(name, raising=False)
    config_module.get_settings.cache_clear()
    base = config_module.get_settings()
    yield dataclasses.replace(base, web_dir=tmp_path / "web-out")
    config_module.get_settings.cache_clear()


@pytest.fixture
def app(settings):
    from dealscout_api.app import create_app

    return create_app(settings)


@pytest.fixture
def client(app):
    with TestClient(app, base_url="http://127.0.0.1:8000") as test_client:
        yield test_client


DEAL = {
    "name": "Acme Industrial GmbH",
    "country": "de",
    "sector": "industrials",
    "industry": "Machinery",
    "listed": False,
    "reporting_currency": "eur",
    "perspective": "financial_sponsor",
}
