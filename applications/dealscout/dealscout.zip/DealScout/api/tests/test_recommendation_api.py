"""Milestone 6: suitability weights, recommendation, data quality and the rationale (numbers never from the AI)."""

from __future__ import annotations

import json

from test_financials_valuation import M, make_deal, seed_quick_scan
from test_methods_api import TRANCHES

from dealscout_ai.testing import AnthropicHarness, Scenario

BASE = {
    "risk_free_rate": 0.03,
    "equity_risk_premium": 0.05,
    "unlevered_beta": 0.9,
    "tax_rate": 0.3,
    "pre_tax_cost_of_debt": 0.05,
    "country_risk_premium": 0.0,
}


def overrides(client, deal_id, **extra):
    r = client.put(f"/api/deals/{deal_id}/assumptions", json={"overrides": {**BASE, **extra}})
    assert r.status_code == 200, r.text


def test_recommendation_payload_and_weights(client):
    deal = make_deal(client)
    seed_quick_scan(client, deal["id"])
    client.put(f"/api/deals/{deal['id']}/methods/lbo", json={"tranches": TRANCHES, "entry_multiple": 9.0})
    r = client.get(f"/api/deals/{deal['id']}/recommendation").json()
    suit = {s["method_id"]: s for s in r["suitability"]}
    # industrials = cyclical profile; financial sponsor makes the LBO primary
    assert suit["lbo"]["relevance"] == "primary" and suit["lbo"]["available"] and suit["lbo"]["reason"]
    assert suit["dcf"]["weight"] == 1.0 and not suit["dcf"]["overridden"]
    rec = r["recommendation"]
    assert rec["equity_low"] < rec["equity_mid"] < rec["equity_high"]
    assert any(c["label"] == "LBO affordability" for c in rec["checks"])
    assert rec["implied"]["EV / EBITDA"][1] > 0
    assert r["data_quality"]["grade"] in "ABCD" and 0 <= r["data_quality"]["score"] <= 100
    assert r["rationale"]["source"] == "template" and len(r["rationale"]["bullets"]) >= 3

    # the analyst's weight wins over the suggestion
    overrides(client, deal["id"], method_weights={"lbo": 0})
    r2 = client.get(f"/api/deals/{deal['id']}/recommendation").json()
    lbo = next(s for s in r2["suitability"] if s["method_id"] == "lbo")
    assert lbo["weight"] == 0 and lbo["overridden"] and lbo["suggested_weight"] == 1.0
    assert r2["recommendation"]["equity_mid"] != rec["equity_mid"]


def test_premium_range_check(client):
    deal = make_deal(client, listed=True, ticker="ACME")
    seed_quick_scan(client, deal["id"])
    overrides(client, deal["id"], share_price=20.0)
    r = client.get(f"/api/deals/{deal['id']}/recommendation").json()
    check = next(c for c in r["recommendation"]["checks"] if c["label"] == "Control premium")
    assert check["status"] == "n/a"  # no sourced default: the analyst enters the typical range
    client.put(
        f"/api/deals/{deal['id']}/methods/premium", json={"low": 0.2, "high": 0.45, "source": "Our deal database"}
    )
    r = client.get(f"/api/deals/{deal['id']}/recommendation").json()
    check = next(c for c in r["recommendation"]["checks"] if c["label"] == "Control premium")
    assert check["status"] in ("pass", "warn") and "Our deal database" in check["detail"]
    assert r["recommendation"]["premium_to_market"][1] == r["recommendation"]["equity_mid"] / (20.0 * 50 * M) - 1


def test_ai_rationale_numbers_come_from_the_engine(client, app, monkeypatch):
    deal = make_deal(client)
    seed_quick_scan(client, deal["id"])
    r = client.post(f"/api/deals/{deal['id']}/recommendation/rationale")
    assert r.status_code == 409  # no AI connected

    answer = {
        "rationale": [
            {"text": "The suggested range runs from {price_low} to {price_high}, with a mid of {price_mid}."},
            {"text": "The blend rests on {methods}."},
            {"text": "The company is worth 12 times EBITDA."},  # invented number: rejected
            {"text": "This uses {not_a_fact}."},  # unknown placeholder: rejected
        ],
        "risks": [{"text": "Data quality is {data_quality}."}],
        "high_end": [{"text": "The high end needs the {high_end_method} high case to hold."}],
    }
    provider, rec = AnthropicHarness().build([Scenario(text=json.dumps(answer))])
    monkeypatch.setattr(type(app.state.ai_service), "provider_for", lambda self, session, **kw: provider)
    r = client.post(f"/api/deals/{deal['id']}/recommendation/rationale")
    assert r.status_code == 200, r.text
    rat = r.json()["rationale"]
    assert rat["source"].startswith("anthropic") and rat["rejected"] == 2 and not rat["stale"]
    assert len(rat["bullets"]) == 2 and "{" not in rat["bullets"][0] and "EUR" in rat["bullets"][0]
    assert "{price_mid}" in json.dumps(rec.requests[0])  # the model sees placeholders with their values

    # a changed input makes the stored rationale stale; the template takes over until it is rewritten
    overrides(client, deal["id"], tax_rate=0.25)
    rat = client.get(f"/api/deals/{deal['id']}/recommendation").json()["rationale"]
    assert rat["stale"] and rat["source"] == "template" and rat["previous_source"].startswith("anthropic")
