from conftest import DEAL

M = 1e6


def cells(deal_id, client, rows, source="manual"):
    changes = [
        {"concept_id": c, "period_key": p, "value": v} for c, by_period in rows.items() for p, v in by_period.items()
    ]
    r = client.put(f"/api/deals/{deal_id}/financials/cells", json={"changes": changes, "source": source})
    assert r.status_code == 200, r.text
    return r.json()


def make_deal(client, **extra):
    return client.post("/api/deals", json={**DEAL, "valuation_date": "2026-03-31", **extra}).json()


def test_grid_defaults_periods_and_template(client):
    deal = make_deal(client)
    grid = client.get(f"/api/deals/{deal['id']}/financials").json()
    assert [p["key"] for p in grid["periods"]] == ["FY2023", "FY2024", "FY2025"]
    assert grid["entry"]["scale"] == M
    ids = [s["id"] for s in grid["statements"]]
    assert ids[:3] == ["income_statement", "balance_sheet", "cash_flow"]
    assert "revenue" in grid["quick_scan"]["missing"]


def test_cells_computed_subtotals_checks_and_history(client):
    deal = make_deal(client)
    grid = cells(
        deal["id"],
        client,
        {
            "revenue": {"FY2025": 1000 * M},
            "cogs": {"FY2025": -600 * M},
            "total_assets": {"FY2025": 900 * M},
            "total_liabilities_and_equity": {"FY2025": 850 * M},
        },
    )
    income = next(s for s in grid["statements"] if s["id"] == "income_statement")
    gp = next(r for r in income["rows"] if r["concept_id"] == "gross_profit")
    assert gp["cells"]["FY2025"] == {"value": 400 * M, "kind": "computed", "formula": "revenue + cogs", "note": None}
    failing = [c for c in grid["checks"] if c["status"] == "fail"]
    assert any(c["check_id"] == "balance_sheet_balances" for c in failing)

    cells(deal["id"], client, {"revenue": {"FY2025": 1010 * M}})
    history = client.get(
        f"/api/deals/{deal['id']}/financials/history", params={"concept_id": "revenue", "period_key": "FY2025"}
    ).json()
    assert [h["new_value"] for h in history] == [1010 * M, 1000 * M]
    assert history[0]["old_value"] == 1000 * M and history[0]["actor"] == "Analyst"

    bad = client.put(
        f"/api/deals/{deal['id']}/financials/cells",
        json={"changes": [{"concept_id": "nope", "period_key": "FY2025", "value": 1}]},
    )
    assert bad.status_code == 422
    bad = client.put(
        f"/api/deals/{deal['id']}/financials/cells",
        json={"changes": [{"concept_id": "revenue", "period_key": "FY1999", "value": 1}]},
    )
    assert bad.status_code == 422


def test_periods_add_and_remove(client):
    deal = make_deal(client)
    assert client.post(f"/api/deals/{deal['id']}/periods", json={"key": "fy2022"}).status_code == 201
    assert client.post(f"/api/deals/{deal['id']}/periods", json={"key": "FY2022"}).status_code == 409
    assert client.post(f"/api/deals/{deal['id']}/periods", json={"key": "last year"}).status_code == 422
    cells(deal["id"], client, {"revenue": {"FY2022": 5 * M}})
    grid = client.delete(f"/api/deals/{deal['id']}/periods/FY2022").json()
    assert "FY2022" not in [p["key"] for p in grid["periods"]]


def test_paste_preview(client):
    deal = make_deal(client)
    text = "Income statement\tEUR m\nLine\tFY2025\tFY2024\nRevenue\t1,200.0\t1,100.0\nCost of sales\t(700.0)\t(650.0)\nWidgets\t1\t2"
    preview = client.post(f"/api/deals/{deal['id']}/financials/paste", json={"text": text}).json()
    assert preview["scale"]["factor"] == M
    assert [p["key"] for p in preview["periods"]] == ["FY2025", "FY2024"]
    assert preview["rows"][0]["concept_id"] == "revenue"
    assert preview["unmatched"] == 1


def seed_quick_scan(client, deal_id):
    cells(
        deal_id,
        client,
        {
            "revenue": {"FY2023": 800 * M, "FY2024": 900 * M, "FY2025": 1000 * M},
            "ebitda": {"FY2023": 120 * M, "FY2024": 140 * M, "FY2025": 160 * M},
            "da_total": {"FY2023": -32 * M, "FY2024": -36 * M, "FY2025": -40 * M},
            "capex": {"FY2023": -40 * M, "FY2024": -45 * M, "FY2025": -50 * M},
            "lt_debt": {"FY2025": 300 * M},
            "cash": {"FY2025": 100 * M},
            "total_equity": {"FY2025": 700 * M},
            "shares_outstanding": {"FY2025": 50 * M},
        },
    )
    r = client.put(
        f"/api/deals/{deal_id}/assumptions",
        json={
            "overrides": {
                "risk_free_rate": 0.03,
                "equity_risk_premium": 0.05,
                "unlevered_beta": 0.9,
                "tax_rate": 0.3,
                "pre_tax_cost_of_debt": 0.05,
                "country_risk_premium": 0.0,
            }
        },
    )
    assert r.status_code == 200, r.text


def test_quick_scan_valuation_end_to_end(client):
    deal = make_deal(client)
    seed_quick_scan(client, deal["id"])
    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    result = v["result"]
    assert result["missing"] == []
    assert result["dcf"]["enterprise_value"] > 0
    assert result["football_field"]["blended_per_share"]["mid"] > 0
    assert len(v["sensitivities"]) == 3 and len(v["sensitivities"][0]["values"]) == 5
    assert {s["name"] for s in v["scenarios"]["scenarios"]} == {"bear", "base", "bull"}
    sources = {a["key"]: a["source"] for a in result["assumptions"]}
    assert sources["risk_free_rate"] == "user" and sources["revenue_growth"] == "historical"

    analysis = client.get(f"/api/deals/{deal['id']}/analysis").json()
    margin = next(r for r in analysis["ratios"] if r["ratio_id"] == "ebitda_margin" and r["period_id"] == "FY2025")
    assert margin["value"] == 0.16
    assert analysis["revenue_cagr"]["value"] > 0.11

    peers = [
        {
            "name": f"Peer {i}",
            "enterprise_value": m * 100 * M,
            "ebitda": 100 * M,
            "market_cap": m * 80 * M,
            "net_income": 40 * M,
        }
        for i, m in enumerate([7, 8, 9, 10])
    ]
    client.put(f"/api/deals/{deal['id']}/assumptions", json={"peers": peers})
    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    assert any(m["method_id"] == "comps_ev_ebitda" for m in v["result"]["football_field"]["methods"])
    assert any(s["multiple_id"] == "ev_ebitda" and s["median"] == 8.5 for s in v["peer_stats"])


def test_invalid_overrides_rejected(client):
    deal = make_deal(client)
    r = client.put(f"/api/deals/{deal['id']}/assumptions", json={"overrides": {"projection_years": 40}})
    assert r.status_code == 422


def test_duplicate_copies_data_and_delete_removes_it(client):
    deal = make_deal(client)
    seed_quick_scan(client, deal["id"])
    copy = client.post(f"/api/deals/{deal['id']}/duplicate").json()
    grid = client.get(f"/api/deals/{copy['id']}/financials").json()
    revenue = next(r for r in grid["statements"][0]["rows"] if r["concept_id"] == "revenue")
    assert revenue["cells"]["FY2025"]["value"] == 1000 * M
    assert client.get(f"/api/deals/{copy['id']}/assumptions").json()["overrides"]["tax_rate"] == 0.3
    assert client.delete(f"/api/deals/{copy['id']}").status_code == 204
    from sqlmodel import Session, select

    from dealscout_api.db import get_engine
    from dealscout_api.models import FinancialValue

    with Session(get_engine()) as session:
        assert not session.exec(select(FinancialValue).where(FinancialValue.deal_id == copy["id"])).all()
        assert session.exec(select(FinancialValue).where(FinancialValue.deal_id == deal["id"])).all()


def test_defaults_listing(client):
    r = client.get("/api/defaults")
    assert r.status_code == 200
    assert "entries" in r.json()
