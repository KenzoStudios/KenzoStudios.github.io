from fastapi.testclient import TestClient

from dealscout_api.security import is_local_host_header, is_local_origin


def test_host_and_origin_helpers():
    assert is_local_host_header("127.0.0.1:8000")
    assert is_local_host_header("localhost:3000")
    assert is_local_host_header("[::1]:8000")
    assert not is_local_host_header("evil.example:8000")
    assert not is_local_host_header("127.0.0.1.evil.example")
    assert is_local_origin("http://localhost:3000")
    assert not is_local_origin("https://evil.example")
    assert not is_local_origin("null")


def test_rejects_foreign_host_dns_rebinding(app):
    with TestClient(app, base_url="http://attacker.example") as c:
        assert c.get("/api/health").status_code == 421


def test_rejects_cross_site_origin(client):
    r = client.post("/api/deals", json={}, headers={"Origin": "https://evil.example"})
    assert r.status_code == 403
    r = client.get("/api/health", headers={"Origin": "http://localhost:3000"})
    assert r.status_code == 200
    assert r.headers["x-frame-options"] == "DENY"
