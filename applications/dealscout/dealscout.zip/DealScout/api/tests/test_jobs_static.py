import time

from dealscout_ai import RateLimitedError


def _wait(client, job_id, statuses, timeout=5.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        job = client.get(f"/api/jobs/{job_id}").json()
        if job["status"] in statuses:
            return job
        time.sleep(0.05)
    raise AssertionError(f"job stuck in {job['status']}")


def test_job_runs_steps_and_pauses_on_ai_error(client, app):
    runner = app.state.job_runner
    calls = {"n": 0}

    def handler(ctx):
        with ctx.step("read"):
            pass
        calls["n"] += 1
        if calls["n"] == 1:
            raise RateLimitedError("slow down", provider="anthropic", retry_after=0.1)
        if not ctx.is_done("map"):
            with ctx.step("map"):
                pass

    runner.register("selftest", handler)
    job = runner.submit("selftest", steps=[("read", "Read pages"), ("map", "Map concepts")])
    paused = _wait(client, job.id, {"paused", "done"})
    assert paused["status"] in {"paused", "done"}
    done = _wait(client, job.id, {"done"})  # auto-retried after retry_after
    assert [s["status"] for s in done["steps"]] == ["done", "done"]


def test_failed_job_reports_message(client, app):
    runner = app.state.job_runner

    def boom(ctx):
        with ctx.step("a"):
            raise ValueError("bad table")

    runner.register("boom", boom)
    job = runner.submit("boom", steps=[("a", "A")])
    failed = _wait(client, job.id, {"failed"})
    assert "bad table" in failed["message"]
    assert failed["steps"][0]["status"] == "failed"


def test_placeholder_when_web_not_built(client):
    r = client.get("/")
    assert r.status_code == 200 and "web interface has not been built" in r.text


def test_spa_fallback(client, settings):
    out = settings.web_dir
    out.mkdir(parents=True)
    (out / "index.html").write_text("<html>shell</html>")
    (out / "deal.html").write_text("<html>deal</html>")
    assert client.get("/deal").text == "<html>deal</html>"
    assert client.get("/some/unknown/route").text == "<html>shell</html>"
    assert client.get("/../../etc/passwd").text == "<html>shell</html>"
    assert client.get("/api/nope").status_code == 404
    assert client.head("/deal").status_code == 200
