"""Document-based warning signs and sector KPIs in /analysis, the data grid and the exports."""

from __future__ import annotations

import io

import pytest
from openpyxl import load_workbook
from test_documents import _deal, _upload, _wait_doc
from test_exports import seeded
from test_financials_valuation import M, cells, make_deal

from dealscout_extraction import synthetic
from dealscout_extraction.text_signals import RULES_VERSION


def test_document_warning_signs_in_analysis(client, settings):
    deal_id = _deal(client)
    doc_id = _upload(client, deal_id, "halvard-2025.pdf", synthetic.warning_signs_report())["documents"][0]["id"]
    _wait_doc(client, deal_id, doc_id)
    analysis = client.get(f"/api/deals/{deal_id}/analysis").json()
    flags = {f["id"]: f for f in analysis["red_flags"] if f["source"] == "document"}
    assert set(flags) == {
        "text_going_concern",
        "text_qualified_opinion",
        "text_restatement",
        "text_related_party",
        "text_customer_concentration",
    }
    assert analysis["documents_scanned"] == 1
    gc = flags["text_going_concern"]
    assert gc["severity"] == "high" and gc["period"] == "FY2025"
    evidence = gc["evidence"][0]
    assert evidence == {
        "document_id": doc_id,
        "filename": "halvard-2025.pdf",
        "page": 2,
        "snippet": evidence["snippet"],
    }
    assert "going concern" in evidence["snippet"].lower() and len(evidence["snippet"]) <= 202
    assert flags["text_customer_concentration"]["metric"] == pytest.approx(0.34)
    # high-severity document signs come first among the document flags
    severities = [f["severity"] for f in analysis["red_flags"] if f["source"] == "document"]
    assert severities == sorted(severities, key=lambda s: s != "high")
    # the scan is cached by file hash and rules version
    cached = list((settings.cache_dir / "text_signals").glob(f"*-{RULES_VERSION}.json"))
    assert len(cached) == 1
    again = client.get(f"/api/deals/{deal_id}/analysis").json()
    assert [f["id"] for f in again["red_flags"]] == [f["id"] for f in analysis["red_flags"]]


def test_clean_document_adds_no_warning_signs(client):
    deal_id = _deal(client)
    doc_id = _upload(client, deal_id, "clean.pdf", synthetic.clean_report())["documents"][0]["id"]
    _wait_doc(client, deal_id, doc_id)
    analysis = client.get(f"/api/deals/{deal_id}/analysis").json()
    assert [f for f in analysis["red_flags"] if f["source"] == "document"] == []
    assert all(f["source"] == "figures" for f in analysis["red_flags"])


def test_missing_file_does_not_break_analysis(client, settings):
    deal_id = _deal(client)
    doc_id = _upload(client, deal_id, "halvard.pdf", synthetic.warning_signs_report())["documents"][0]["id"]
    _wait_doc(client, deal_id, doc_id)
    for f in settings.deal_folder(deal_id).iterdir():
        f.unlink()
    analysis = client.get(f"/api/deals/{deal_id}/analysis").json()
    assert analysis["documents_scanned"] == 0


def test_bank_sector_kpis_grid_and_analysis(client):
    deal = make_deal(client, sector="banks", industry="Retail banks")
    grid = client.get(f"/api/deals/{deal['id']}/financials").json()
    kpi_rows = [r["concept_id"] for s in grid["statements"] if s["id"] == "sector_kpi" for r in s["rows"]]
    assert {"cet1_ratio", "net_interest_margin", "cost_income_ratio", "gross_loans"} <= set(kpi_rows)
    cells(
        deal["id"],
        client,
        {
            "revenue": {"FY2025": 100 * M},
            "net_interest_income": {"FY2025": 30 * M},
            "interest_earning_assets": {"FY2024": 900 * M, "FY2025": 1100 * M},
            "bank_operating_income": {"FY2025": 50 * M},
            "bank_operating_expenses": {"FY2025": -27.5 * M},  # costs are stored negative
            "cet1_ratio": {"FY2025": 0.142},
        },
    )
    analysis = client.get(f"/api/deals/{deal['id']}/analysis").json()
    sector = analysis["sector_kpis"]
    assert sector["template"] == "bank" and sector["label"] == "Bank KPIs"
    by = {(k["ratio_id"], k["period_id"]): k for k in sector["items"]}
    assert by[("net_interest_margin", "FY2025")]["value"] == pytest.approx(0.03)
    assert by[("cost_income_ratio", "FY2025")]["value"] == pytest.approx(0.55)
    assert by[("cet1_ratio", "FY2025")]["derivation"]["kind"] == "reported"
    assert by[("npl_ratio", "FY2025")]["value"] is None


def test_general_sector_has_no_kpi_block(client):
    deal = make_deal(client)
    sector = client.get(f"/api/deals/{deal['id']}/analysis").json()["sector_kpis"]
    assert sector == {"template": "general", "label": None, "items": []}


def test_retail_template_for_consumer_discretionary(client):
    deal = make_deal(client, sector="consumer_discretionary", industry="Specialty retail")
    grid = client.get(f"/api/deals/{deal['id']}/financials").json()
    kpi = next(s for s in grid["statements"] if s["id"] == "sector_kpi")
    assert [r["concept_id"] for r in kpi["rows"]] == ["like_for_like_growth", "store_count"]


def test_exports_carry_document_signs_and_sector_kpis(client):
    deal = seeded(client)
    doc_id = _upload(client, deal["id"], "halvard-2025.pdf", synthetic.warning_signs_report())["documents"][0]["id"]
    _wait_doc(client, deal["id"], doc_id)
    r = client.get(f"/api/deals/{deal['id']}/export/xlsx")
    assert r.status_code == 200, r.text
    wb = load_workbook(io.BytesIO(r.content))
    report = [str(c.value) for row in wb["Report"].iter_rows() for c in row if c.value is not None]
    assert "Going-concern doubt" in report
    assert any("Source: p. 2, halvard-2025.pdf" in v for v in report)
    pdf = client.get(f"/api/deals/{deal['id']}/export/pdf")
    assert pdf.status_code == 200


def test_excel_financials_sector_kpis(client):
    deal = make_deal(client, sector="software", industry="Application software (SaaS)")
    cells(
        deal["id"],
        client,
        {
            "revenue": {"FY2024": 80 * M, "FY2025": 100 * M},
            "ebitda": {"FY2024": 5 * M, "FY2025": 15 * M},
            "arr": {"FY2024": 100 * M, "FY2025": 130 * M},
            "net_revenue_retention": {"FY2025": 1.12},
        },
    )
    analysis = client.get(f"/api/deals/{deal['id']}/analysis").json()
    rule40 = next(
        k for k in analysis["sector_kpis"]["items"] if k["ratio_id"] == "rule_of_40" and k["period_id"] == "FY2025"
    )
    assert rule40["value"] == pytest.approx(0.40)
    r = client.get(f"/api/deals/{deal['id']}/export/xlsx")
    assert r.status_code == 200, r.text
    ws = load_workbook(io.BytesIO(r.content))["Financials"]
    labels = {row[0].value: row for row in ws.iter_rows(min_col=2) if row[0].value}
    assert any(str(k).startswith("SaaS KPIs") for k in labels)
    assert "Rule of 40" in labels
    nrr = labels["Net revenue retention"]
    assert any(c.value == pytest.approx(1.12) and "%" in c.number_format for c in nrr[1:] if c.value is not None)
