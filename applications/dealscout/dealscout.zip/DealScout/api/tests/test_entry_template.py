import io

from openpyxl import load_workbook

from conftest import DEAL


def row_of(ws, concept_id):
    return next(r for r in range(5, ws.max_row + 1) if ws.cell(row=r, column=1).value == concept_id)


def test_template_download_fill_upload_roundtrip(client):
    deal = client.post("/api/deals", json={**DEAL, "valuation_date": "2026-03-31"}).json()
    r = client.get(f"/api/deals/{deal['id']}/template.xlsx")
    assert r.status_code == 200
    assert "attachment" in r.headers["content-disposition"]
    wb = load_workbook(io.BytesIO(r.content))
    assert wb.sheetnames[:4] == ["Instructions", "Income statement", "Balance sheet", "Cash flow"]
    inc = wb["Income statement"]
    assert [inc.cell(row=4, column=c).value for c in (3, 4, 5)] == ["FY2023", "FY2024", "FY2025"]
    assert inc.cell(row=row_of(inc, "gross_profit"), column=5).value.startswith("=IF(COUNT(")
    assert "not prepared or reviewed" in inc.oddFooter.left.text

    wb["Instructions"]["C6"] = "thousands"
    inc.cell(row=row_of(inc, "revenue"), column=5, value=1234.5)
    inc.cell(row=row_of(inc, "cogs"), column=5, value=800)  # cost entered positive
    inc.cell(row=row_of(inc, "income_tax"), column=5, value="(25.0)")
    inc.cell(row=4, column=6, value="FY2026")  # user adds a period
    inc.cell(row=row_of(inc, "revenue"), column=6, value=1300)
    inc.cell(row=row_of(inc, "sga"), column=5, value="n/a text")
    wb["Shares & memo"].cell(row=row_of(wb["Shares & memo"], "shares_outstanding"), column=5, value=12_000_000)
    buf = io.BytesIO()
    wb.save(buf)
    files = {
        "file": ("filled.xlsx", buf.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    }

    preview = client.post(f"/api/deals/{deal['id']}/template", files=files).json()
    assert preview["applied"] is False and preview["units"] == "thousands"
    assert preview["new_periods"] == ["FY2026"]
    assert any("not a number" in w for w in preview["warnings"])

    applied = client.post(f"/api/deals/{deal['id']}/template?apply=true", files=files).json()
    assert applied["applied"] and applied["counts"]["created"] == 5
    grid = client.get(f"/api/deals/{deal['id']}/financials").json()
    rows = {r["concept_id"]: r for s in grid["statements"] for r in s["rows"]}
    assert rows["revenue"]["cells"]["FY2025"]["value"] == 1_234_500
    assert rows["cogs"]["cells"]["FY2025"]["value"] == -800_000  # stored as a cost
    assert rows["income_tax"]["cells"]["FY2025"]["value"] == -25_000
    assert rows["revenue"]["cells"]["FY2026"]["source"] == "template"
    assert rows["shares_outstanding"]["cells"]["FY2025"]["value"] == 12_000_000  # share counts are not scaled
    assert rows["gross_profit"]["cells"]["FY2025"]["kind"] == "computed"


def test_upload_rejects_wrong_files(client):
    deal = client.post("/api/deals", json=DEAL).json()
    r = client.post(f"/api/deals/{deal['id']}/template", files={"file": ("x.xlsm", b"PK", "application/octet-stream")})
    assert r.status_code == 415
    r = client.post(
        f"/api/deals/{deal['id']}/template", files={"file": ("x.xlsx", b"not a zip", "application/octet-stream")}
    )
    assert r.status_code == 422
