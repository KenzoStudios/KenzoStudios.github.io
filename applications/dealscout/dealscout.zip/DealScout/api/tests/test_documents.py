"""Document upload → extraction job → review → accepted values with provenance."""

from __future__ import annotations

import json
import time

import pytest

from conftest import DEAL
from dealscout_ai import RateLimitedError
from dealscout_ai.testing import ScriptedProvider
from dealscout_extraction import synthetic


def _deal(client) -> str:
    return client.post("/api/deals", json=DEAL).json()["id"]


def _wait_doc(client, deal_id, doc_id, statuses=("processed",), timeout=20.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        doc = next(d for d in client.get(f"/api/deals/{deal_id}/documents").json() if d["id"] == doc_id)
        if doc["status"] in statuses:
            return doc
        job = client.get(f"/api/jobs/{doc['job_id']}").json() if doc.get("job_id") else None
        if job and job["status"] in {"failed", "paused"} and "paused" not in statuses:
            raise AssertionError(f"job {job['status']}: {job['message']}")
        time.sleep(0.05)
    raise AssertionError(f"document stuck in {doc['status']}")


def _wait_job(client, job_id, statuses, timeout=20.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        job = client.get(f"/api/jobs/{job_id}").json()
        if job["status"] in statuses:
            return job
        time.sleep(0.05)
    raise AssertionError(f"job stuck in {job['status']}")


def _upload(client, deal_id, name, content):
    response = client.post(f"/api/deals/{deal_id}/documents", files=[("files", (name, content))])
    assert response.status_code == 201, response.text
    return response.json()


def test_upload_extract_without_ai_and_review(client):
    deal_id = _deal(client)
    result = _upload(client, deal_id, "annual-report-2025.pdf", synthetic.english_annual_report())
    assert result["rejected"] == []
    doc = _wait_doc(client, deal_id, result["documents"][0]["id"])
    assert doc["kind"] == "pdf" and doc["page_count"] == 5 and doc["doc_type"] == "annual_report"
    assert doc["meta"]["statements"]["balance_sheet"][0]["page"] == 3
    assert doc["meta"]["statements"]["balance_sheet"][0]["consolidated"] is True

    job = client.get(f"/api/jobs/{doc['job_id']}").json()
    ai_step = next(s for s in job["steps"] if s["key"] == "ai")
    assert ai_step["status"] == "done" and "Skipped" in ai_step["detail"]

    review = client.get(f"/api/deals/{deal_id}/review").json()
    items = {(i["concept_id"], i["period_key"]): i for i in review["items"]}
    revenue = items[("revenue", "FY2025")]
    assert revenue["value"] == pytest.approx(1_250.4e6) and revenue["page"] == 2
    assert revenue["status"] == "pending" and revenue["method"] == "table_rules"
    assert revenue["bbox"] and len(revenue["bbox"]) == 4
    assert revenue["concept_name"] == "Revenue" and revenue["provider"] is None
    assert items[("cogs", "FY2025")]["value"] < 0  # costs stored negative whatever the print
    # not found without AI → listed with a reason, never guessed
    assert any(n["concept_id"] == "shares_outstanding" for n in doc["meta"]["not_found"])

    # the source file is served inline for the highlight viewer
    file = client.get(f"/api/deals/{deal_id}/documents/{doc['id']}/file")
    assert file.status_code == 200 and file.headers["content-type"] == "application/pdf"
    assert file.headers["content-disposition"].startswith("inline") and file.content[:5] == b"%PDF-"

    # accept everything at or above 0.9
    response = client.post(f"/api/deals/{deal_id}/review", json={"accept_all_above": 0.9})
    assert response.status_code == 200, response.text
    accepted = [i for i in response.json()["items"] if i["status"] == "accepted"]
    assert accepted and all(i["confidence"] >= 0.9 for i in accepted)

    grid = client.get(f"/api/deals/{deal_id}/financials").json()
    revenue_row = next(r for s in grid["statements"] for r in s["rows"] if r["concept_id"] == "revenue")
    cell = revenue_row["cells"]["FY2025"]
    assert cell["value"] == pytest.approx(1_250.4e6) and cell["source"] == "extracted"
    history = client.get(
        f"/api/deals/{deal_id}/financials/history", params={"concept_id": "revenue", "period_key": "FY2025"}
    ).json()
    assert history and history[0]["new_source"] == "extracted"
    activity = client.get(f"/api/deals/{deal_id}/audit").json()
    assert {"document_uploaded", "extraction_reviewed"} <= {e["action"] for e in activity}


def test_provenance_edit_and_reject(client, app):
    deal_id = _deal(client)
    doc_id = _upload(client, deal_id, "ar.pdf", synthetic.english_annual_report())["documents"][0]["id"]
    _wait_doc(client, deal_id, doc_id)
    items = client.get(f"/api/deals/{deal_id}/review").json()["items"]
    by_key = {(i["concept_id"], i["period_key"]): i for i in items}
    revenue, ebit = by_key[("revenue", "FY2025")], by_key[("cogs", "FY2024")]

    # an edit needs a reason
    bad = client.post(
        f"/api/deals/{deal_id}/review",
        json={"actions": [{"item_id": revenue["id"], "action": "edit", "value": 1.0}]},
    )
    assert bad.status_code == 422
    response = client.post(
        f"/api/deals/{deal_id}/review",
        json={
            "actions": [
                {"item_id": revenue["id"], "action": "edit", "value": 1_251e6, "reason": "Restated in note 3"},
                {"item_id": ebit["id"], "action": "reject"},
            ]
        },
    )
    assert response.status_code == 200, response.text
    after = {i["id"]: i for i in response.json()["items"]}
    assert after[revenue["id"]]["status"] == "accepted" and after[revenue["id"]]["value"] == 1_251e6
    assert after[ebit["id"]]["status"] == "rejected"

    from sqlmodel import Session, select

    from dealscout_api.models import FinancialValue

    with Session(app.state.engine) as session:
        stored = session.exec(
            select(FinancialValue).where(FinancialValue.deal_id == deal_id, FinancialValue.concept_id == "revenue")
        ).one()
        assert stored.value == 1_251e6 and stored.source == "extracted"
        assert stored.provenance["page"] == 2 and stored.provenance["edited"] is True
        assert stored.provenance["filename"] == "ar.pdf" and stored.provenance["extracted_value"] == pytest.approx(
            1_250.4e6
        )
        assert stored.confidence is not None
        assert not session.exec(
            select(FinancialValue).where(FinancialValue.deal_id == deal_id, FinancialValue.concept_id == "cogs")
        ).all()


def test_rerun_keeps_decisions_and_delete_removes_pending(client, app):
    deal_id = _deal(client)
    doc_id = _upload(client, deal_id, "ar.pdf", synthetic.english_annual_report())["documents"][0]["id"]
    _wait_doc(client, deal_id, doc_id)
    first = client.get(f"/api/deals/{deal_id}/review").json()["items"]
    revenue = next(i for i in first if (i["concept_id"], i["period_key"]) == ("revenue", "FY2025"))
    client.post(f"/api/deals/{deal_id}/review", json={"actions": [{"item_id": revenue["id"], "action": "accept"}]})

    response = client.post(f"/api/deals/{deal_id}/documents/{doc_id}/extract")
    assert response.status_code == 202
    time.sleep(0.1)
    _wait_doc(client, deal_id, doc_id)
    second = client.get(f"/api/deals/{deal_id}/review").json()["items"]
    revenue_items = [i for i in second if (i["concept_id"], i["period_key"]) == ("revenue", "FY2025")]
    assert len(revenue_items) == 1 and revenue_items[0]["status"] == "accepted"  # no duplicate pending candidate
    assert len(second) == len(first)

    assert client.delete(f"/api/deals/{deal_id}/documents/{doc_id}").status_code == 204
    review = client.get(f"/api/deals/{deal_id}/review").json()
    assert review["documents"] == [] and all(i["status"] != "pending" for i in review["items"])
    settings = app.state.settings
    assert not list((settings.uploads_dir / deal_id).glob("*"))


def test_upload_validation(client):
    deal_id = _deal(client)
    response = client.post(
        f"/api/deals/{deal_id}/documents",
        files=[
            ("files", ("empty.pdf", b"")),
            ("files", ("macro.xlsm", b"PK\x03\x04rest")),
            ("files", ("program.exe", b"MZ\x90\x00binary")),
        ],
    )
    assert response.status_code == 201
    body = response.json()
    assert body["documents"] == [] and len(body["rejected"]) == 3
    assert any("empty" in r for r in body["rejected"]) and any("macro" in r for r in body["rejected"])
    assert client.get("/api/deals/nope/documents").status_code == 404


def test_excel_and_csv_are_read(client):
    deal_id = _deal(client)
    doc_id = _upload(client, deal_id, "mgmt.xlsx", synthetic.management_accounts_xlsx())["documents"][0]["id"]
    doc = _wait_doc(client, deal_id, doc_id)
    assert doc["kind"] == "xlsx"
    items = client.get(f"/api/deals/{deal_id}/review").json()["items"]
    revenue = [i for i in items if i["concept_id"] == "revenue"]
    assert revenue and all(i["cell_ref"] and i["sheet"] for i in revenue)


def test_user_maps_an_unrecognised_row(client):
    deal_id = _deal(client)
    pdf = synthetic.english_annual_report(sga_label="Overheads and selling costs")
    doc_id = _upload(client, deal_id, "ar.pdf", pdf)["documents"][0]["id"]
    doc = _wait_doc(client, deal_id, doc_id)
    row = next(u for u in doc["meta"]["unmapped"] if u["label"] == "Overheads and selling costs")
    assert (
        client.post(
            f"/api/deals/{deal_id}/review/map-row",
            json={"document_id": doc_id, "row_id": row["id"], "concept_id": "zzz"},
        ).status_code
        == 422
    )
    response = client.post(
        f"/api/deals/{deal_id}/review/map-row", json={"document_id": doc_id, "row_id": row["id"], "concept_id": "sga"}
    )
    assert response.status_code == 200, response.text
    sga = [i for i in response.json()["items"] if i["concept_id"] == "sga"]
    assert {i["period_key"]: i["value"] for i in sga}["FY2025"] == pytest.approx(-201.5e6)
    assert all(i["method"] == "user_mapping" for i in sga)
    doc = next(d for d in response.json()["documents"] if d["id"] == doc_id)
    assert all(u["label"] != "Overheads and selling costs" for u in doc["meta"]["unmapped"])


def _fake_ai():
    return ScriptedProvider(
        {
            "AIMappingResult": [
                json.dumps({"items": [{"row": 0, "concept_id": "sga", "confidence": 0.9, "rationale": "SG&A."}]})
            ],
            "AIExtractionResult": [
                json.dumps(
                    {
                        "values": [
                            {
                                "concept_id": "da_total",
                                "period": "2025",
                                "value_as_written": "55.0",
                                "page": 4,
                                "label": "Depreciation and amortisation",
                                "unit_scale": "€ million",
                                "confidence": 0.9,
                                "reason_if_null": None,
                            }
                        ]
                    }
                )
            ],
        }
    )


def test_ai_step_records_usage_and_reuses_the_cache(client, app, monkeypatch):
    fake = _fake_ai()
    monkeypatch.setattr(app.state.ai_service, "provider_for", lambda session, **_: fake.provider)
    deal_id = _deal(client)
    pdf = synthetic.english_annual_report(sga_label="Overheads and selling costs")
    doc_id = _upload(client, deal_id, "ar.pdf", pdf)["documents"][0]["id"]
    doc = _wait_doc(client, deal_id, doc_id)
    assert doc["meta"]["ai_used"] is True
    items = client.get(f"/api/deals/{deal_id}/review").json()["items"]
    da = next(i for i in items if (i["concept_id"], i["period_key"]) == ("da_total", "FY2025"))
    assert da["method"] == "ai_extraction" and da["provider"] == "fake" and da["model"] == "fake-1"
    assert da["value"] == pytest.approx(-55.0e6)
    assert any(i["concept_id"] == "sga" and i["method"] == "ai_mapping" for i in items)
    usage = client.get("/api/ai/usage", params={"deal_id": deal_id}).json()
    assert any(row["purpose"] == "extraction" and row["provider"] == "fake" for row in usage["summary"])
    calls = len(fake.requests)

    client.post(f"/api/deals/{deal_id}/documents/{doc_id}/extract")
    time.sleep(0.1)
    _wait_doc(client, deal_id, doc_id)
    assert len(fake.requests) == calls  # same document, provider, model and prompt version → no new AI cost
    job = client.get(f"/api/jobs/{client.get(f'/api/deals/{deal_id}/documents').json()[0]['job_id']}").json()
    assert "cached" in next(s for s in job["steps"] if s["key"] == "ai")["detail"]
    again = client.get(f"/api/deals/{deal_id}/review").json()["items"]
    assert any(i["concept_id"] == "da_total" for i in again)


def test_ai_error_pauses_the_job_after_saving_rules_results(client, app, monkeypatch):
    fake = _fake_ai()

    def rate_limited(**_):
        raise RateLimitedError("Too many requests", provider="fake", retry_after=3600)

    monkeypatch.setattr(fake.provider, "_complete_json", rate_limited)
    monkeypatch.setattr(app.state.ai_service, "provider_for", lambda session, **_: fake.provider)
    deal_id = _deal(client)
    doc_id = _upload(client, deal_id, "ar.pdf", synthetic.english_annual_report())["documents"][0]["id"]
    doc = next(d for d in client.get(f"/api/deals/{deal_id}/documents").json() if d["id"] == doc_id)
    job = _wait_job(client, doc["job_id"], {"paused", "done", "failed"})
    assert job["status"] == "paused" and job["error_code"] == "rate_limited"
    items = client.get(f"/api/deals/{deal_id}/review").json()["items"]
    assert any(i["concept_id"] == "revenue" for i in items)  # table results were kept


def test_ltm_columns_in_grid(client):
    deal_id = _deal(client)
    cells = [
        {"concept_id": "revenue", "period_key": "FY2025", "value": 1000.0},
        {"concept_id": "revenue", "period_key": "H1-2025", "value": 480.0},
        {"concept_id": "revenue", "period_key": "H1-2026", "value": 530.0},
        {"concept_id": "cash", "period_key": "H1-2026", "value": 77.0},
    ]
    for key, kind in (("H1-2025", "half_year"), ("H1-2026", "half_year")):
        assert client.post(f"/api/deals/{deal_id}/periods", json={"key": key, "kind": kind}).status_code in (
            200,
            201,
        )
    assert client.put(f"/api/deals/{deal_id}/financials/cells", json={"changes": cells}).status_code == 200
    grid = client.get(f"/api/deals/{deal_id}/financials").json()
    assert [p["key"] for p in grid["ltm_periods"]] == ["LTM-H1-2026"]
    rows = {r["concept_id"]: r for s in grid["statements"] for r in s["rows"]}
    ltm = rows["revenue"]["cells"]["LTM-H1-2026"]
    assert ltm["value"] == pytest.approx(1050.0) and ltm["kind"] == "computed"
    assert rows["cash"]["cells"]["LTM-H1-2026"]["value"] == pytest.approx(77.0)


def test_hard_delete_removes_documents(client, app):
    deal_id = _deal(client)
    doc_id = _upload(client, deal_id, "ar.pdf", synthetic.english_annual_report())["documents"][0]["id"]
    _wait_doc(client, deal_id, doc_id)
    response = client.delete(f"/api/deals/{deal_id}")
    assert response.status_code == 204, response.text
    assert not (app.state.settings.uploads_dir / deal_id).exists()
    from sqlmodel import Session, select

    from dealscout_api.models import Document, ExtractedItem

    with Session(app.state.engine) as session:
        assert not session.exec(select(Document).where(Document.deal_id == deal_id)).all()
        assert not session.exec(select(ExtractedItem).where(ExtractedItem.deal_id == deal_id)).all()


def test_tagged_filing_upload_view_and_review(client):
    deal_id = _deal(client)
    doc_id = _upload(client, deal_id, "brightmart-10k.htm", synthetic.sec_retailer_10k())["documents"][0]["id"]
    doc = _wait_doc(client, deal_id, doc_id)
    assert doc["kind"] == "xbrl" and doc["doc_type"] == "annual_report"
    assert doc["meta"]["entity_name"] == "Brightmart Stores, Inc." and doc["meta"]["tagged_facts"] > 10
    items = {(i["concept_id"], i["period_key"]): i for i in client.get(f"/api/deals/{deal_id}/review").json()["items"]}
    revenue = items[("revenue", "FY2025")]
    assert revenue["method"] == "xbrl" and revenue["cell_ref"] == "f1" and revenue["confidence"] >= 0.97
    unmapped = doc["meta"]["unmapped"]
    assert unmapped and unmapped[0]["scale_factor"] == 1e6

    # the original HTML is never served inline on the app's origin
    raw = client.get(f"/api/deals/{deal_id}/documents/{doc_id}/file")
    assert raw.headers["content-disposition"].startswith("attachment")
    assert raw.headers["content-type"] == "application/octet-stream"
    # the review view is sanitised and sandboxed, with ids for every fact and cell
    view = client.get(f"/api/deals/{deal_id}/documents/{doc_id}/view")
    assert view.status_code == 200
    assert (
        "sandbox" in view.headers["content-security-policy"]
        and "default-src 'none'" in view.headers["content-security-policy"]
    )
    # the review screen frames this page: same-origin framing only (the app's other pages stay DENY)
    assert view.headers["x-frame-options"] == "SAMEORIGIN"
    assert "frame-ancestors 'self'" in view.headers["content-security-policy"]
    assert client.get(f"/api/deals/{deal_id}").headers["x-frame-options"] == "DENY"
    body = view.text
    assert "<script" not in body.lower() and 'id="f1"' in body and ":target" in body
    assert 'id="t1r1c' in body

    # mapping a company-specific element uses the tagged figure and its scale
    row = unmapped[0]
    response = client.post(
        f"/api/deals/{deal_id}/review/map-row",
        json={"document_id": doc_id, "row_id": row["id"], "concept_id": "other_operating_expense"},
    )
    assert response.status_code == 200, response.text
    mapped = [i for i in response.json()["items"] if i["concept_id"] == "other_operating_expense"]
    assert {i["period_key"]: i["value"] for i in mapped}["FY2025"] == pytest.approx(-22.1e6)


def test_zip_archive_expands_and_esef_package_stays_whole(client):
    import io
    import zipfile

    deal_id = _deal(client)
    archive = io.BytesIO()
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("reports/annual-report.pdf", synthetic.english_annual_report())
        zf.writestr("reports/mgmt.xlsx", synthetic.management_accounts_xlsx())
        zf.writestr("__MACOSX/._annual-report.pdf", b"junk")
        zf.writestr("notes.txt", b"ignored")
    result = _upload(client, deal_id, "data-room.zip", archive.getvalue())
    names = sorted(d["filename"] for d in result["documents"])
    assert names == ["data-room.zip › annual-report.pdf", "data-room.zip › mgmt.xlsx"]
    package = _upload(client, deal_id, "ortel-2025.zip", synthetic.esef_package())["documents"]
    assert len(package) == 1 and package[0]["kind"] == "zip"
    doc = _wait_doc(client, deal_id, package[0]["id"])
    assert doc["meta"]["report_member"].endswith("-fr.xhtml") and doc["doc_type"] == "annual_report"
    view = client.get(f"/api/deals/{deal_id}/documents/{doc['id']}/view")
    assert view.status_code == 200 and 'id="r25"' in view.text


def test_word_and_html_uploads_are_read(client):
    deal_id = _deal(client)
    doc_id = _upload(client, deal_id, "mgmt.docx", synthetic.word_statements_docx())["documents"][0]["id"]
    doc = _wait_doc(client, deal_id, doc_id)
    assert doc["kind"] == "docx"
    items = client.get(f"/api/deals/{deal_id}/review").json()["items"]
    assert any(i["concept_id"] == "revenue" and i["cell_ref"].startswith("t1r") for i in items)
    assert client.get(f"/api/deals/{deal_id}/documents/{doc_id}/view").status_code == 409


def test_restated_figures_across_documents(client):
    deal_id = _deal(client)
    older = _upload(client, deal_id, "annual-report-2025.pdf", synthetic.english_annual_report())["documents"][0]["id"]
    _wait_doc(client, deal_id, older)
    newer_csv = (
        b"Consolidated income statement (EUR million)\n"
        b"Line item,FY2026,FY2025\n"
        b"Revenue,1400.0,1262.9\n"
        b"Cost of sales,(905.0),(812.3)\n"
        b"Gross profit,495.0,450.6\n"
        b"Operating profit,260.0,236.8\n"
    )
    newer = _upload(client, deal_id, "results-2026.csv", newer_csv)["documents"][0]["id"]
    _wait_doc(client, deal_id, newer)
    review = client.get(f"/api/deals/{deal_id}/review").json()
    diffs = {(d["concept_id"], d["period_key"]): d for d in review["cross_document"]}
    revenue = diffs[("revenue", "FY2025")]
    assert revenue["preferred_document"] == "results-2026.csv"
    assert {v["document"] for v in revenue["values"]} == {"results-2026.csv", "annual-report-2025.pdf"}
    assert ("cogs", "FY2025") not in diffs  # same figure in both: no flag
    old_item = next(
        i
        for i in review["items"]
        if i["document_id"] == older and (i["concept_id"], i["period_key"]) == ("revenue", "FY2025")
    )
    assert old_item["superseded_by"] == "results-2026.csv"

    client.post(f"/api/deals/{deal_id}/review", json={"accept_all_above": 0.0})
    grid = client.get(f"/api/deals/{deal_id}/financials").json()
    row = next(r for s in grid["statements"] for r in s["rows"] if r["concept_id"] == "revenue")
    assert row["cells"]["FY2025"]["value"] == pytest.approx(1_262.9e6)  # the restated figure from the newer document
