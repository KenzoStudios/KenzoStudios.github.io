# DealScout — Build Prompt for Claude Code

You are building DealScout, a web application for investment professionals (PE, M&A, corporate development, equity research, family offices) that performs a fast, comprehensive first-pass analysis of a company and suggests a ballpark acquisition price range.

Read this whole document before writing any code. Then produce a short implementation plan (architecture, folder structure, milestones), list any open questions, and build it milestone by milestone, committing working, tested code at each step.

## 0. Skills to use

Claude Code skills are installed for this build. Use the ones below at the points named, and copy this section into the repo's `CLAUDE.md` during Milestone 1 so every later session follows it too. Many other design skills are installed; ignore the ones listed under "Do not use".

| Skill | Use it for | When |
|---|---|---|
| `claude-api` | The Anthropic (Claude) adapter of the AI layer: current model strings, native PDF/document input, structured outputs / tool use with JSON schemas, prompt caching, token and cost accounting. For the other providers, read their official API docs instead | Before writing the Anthropic adapter (Milestone 3) and whenever it changes |
| `xlsx` | The "Create Excel" workbook (§14A) and the blank manual-entry template (§12): live formulas only, colour conventions, zero formula errors, LibreOffice recalculation check | Milestone 7, and Milestone 2 for the entry template |
| `dataviz` | Every chart in §11, in the web UI and in the Excel/PDF/PPTX exports: chart form, one shared palette, light/dark, semantic red/amber/green that never relies on colour alone | Milestone 2 onwards, whenever a chart is built |
| `app-design` | All web UI work: the deal flow, extraction review screen, grids, dashboards, assumptions and valuation tabs, states, keyboard, browser verification, accessibility audit | Every milestone that touches `web/` |
| `shadcn` | Adding, composing, theming and debugging shadcn/ui components through the shadcn CLI, reading `components.json` | Every milestone that touches `web/` |
| `break-ui` | Stress-testing statement grids, financial tables and the review screen with worst-case data (huge and negative numbers, long labels, missing periods, 0 and 300+ rows, non-Latin labels) | End of each UI milestone |
| `web-design-guidelines` | Pre-ship rules audit of the UI code | End of each UI milestone |
| `playwright-cli` | Looking at screens while building, and alongside the Playwright end-to-end tests in §16 | Every UI milestone |
| `pdf` | The PDF tear sheet (§14) and handling PDF inputs in tests | Milestones 3 and 7 |
| `pptx` | The python-pptx one-page slide summary (§14) | Milestone 7 |
| `ui-ux-pro-max` | Lookups and checklists only: stack guidelines (`--stack nextjs`, `--stack shadcn`), UX guidelines (`--domain ux`, e.g. "data table", "form validation", "loading states", "keyboard navigation"), and its "Before Delivering App UI" checklist | Start of each UI milestone (look up the screens you're about to build) and end of each UI milestone (run the checklist next to web-design-guidelines) |

Rules for applying them:

- **The brief is the brand override for `app-design`.** The visual specs in §14A and §17 win. Skip `app-design`'s direction-setting step and do not generate a new palette or "signature" style; use its build, states, verification and audit phases. Record the UI system once in `DESIGN.md` (tokens, density, component measurements) and reuse it.
- **One palette everywhere.** Define the palette once (navy primary, one accent, soft greys, semantic red/amber/green) and share it between the web UI, charts, Excel, PDF and PPTX.
- **Excel formulas must recalculate in LibreOffice**, because §14A's CI check recalculates with it. Use `INDEX`/`MATCH`; never `XLOOKUP`, `XMATCH`, `FILTER`, `SORT`, `UNIQUE` or `SEQUENCE`. Do sorting, filtering and de-duplication in Python before writing cells.
- **Check current model names and capabilities before hard-coding any.** For Claude, use the `claude-api` skill. For OpenAI, Azure OpenAI, Google Gemini, xAI and Perplexity, check each provider's official API documentation at build time (model names, structured-output support, PDF/file input, pricing). Never rely on remembered model names.
- **`ui-ux-pro-max` is for lookups and checklists only.** Never run its `--design-system` generator or adopt any palette, font or style it suggests; the visual specs in §14A and §17 are fixed. `dataviz` stays the main chart skill; `--domain chart` is a second opinion only. Run searches with: `python3 "$HOME/.claude/skills/ui-ux-pro-max/scripts/search.py" "<query>" --domain <domain>` (or `--stack <stack>`).
- **Do not use** `website-design`, `website-presentation-hero`, `design-taste-frontend`, `frontend-design`, `image-to-code`, `design-md-library`, `frontend-slides`, `mckinsey` or `mckinsey-plus` on this project. They target marketing sites, bold visual styles or hand-made decks, and conflict with the restrained, dense UI this brief asks for. The ui-ux-pro-max design-system generator is also out (the palette is fixed); see the `ui-ux-pro-max` rule above for its permitted lookups. Keep motion minimal; Emil Kowalski's animation skills are not needed beyond the basic rules inside `app-design`.

## 1. Product purpose and positioning

DealScout is a screening tool, not a replacement for a full valuation. An analyst should be able to upload whatever financial documents they have (or type numbers in), and within minutes get:

- A clean, normalized set of historical financials with every number traceable to its source.
- A financial health and quality-of-earnings scan.
- Valuations from multiple methods (DCF, trading comps, precedent transactions, LBO, NAV / sum-of-the-parts, and others suited to the company type).
- A "football field" summary and a suggested acquisition price range with a clearly explained rationale.
- Exportable output (Excel model with live formulas, PDF tear sheet, slide one-pager) that the analyst can take to a manager to decide whether a full analysis is worth doing.

Every screen and export must carry a short disclaimer: outputs are indicative estimates for internal screening, depend on user assumptions and extracted data, and are not investment advice or a fairness opinion.

**Document-first.** The main path is: the analyst uploads the company's documents, an AI model reads them, and the analysis is built from what it found in them. The financials, the qualitative summary, the quality-of-earnings flags, the suggested methods and the rationale all come from that reading. Manual entry exists to fill gaps and correct values, and as a fallback when there are no documents or no AI is connected.

**Bring your own AI.** DealScout is downloaded from GitHub and runs on each person's own computer at localhost (§3). It ships with no AI account or key. Each person connects the AI their company allows: Claude (the default and recommended option), OpenAI / ChatGPT models, Microsoft Copilot's models via Azure OpenAI, Google Gemini, xAI Grok, Perplexity, or any OpenAI-compatible endpoint (a company AI gateway or a local model). Every document read and every text generated runs on, and is billed to, the key they connected. An AI connection is optional: without one, DealScout still works from tagged filings, the synonym dictionary and manual entry.

## 2. Non-negotiable design principles

1. **The LLM finds and explains; code calculates.** Use the connected AI model (Claude by default; any provider in §3) to locate, interpret, map and summarize information in documents. All arithmetic — ratios, projections, DCF, LBO, multiples, IRR — is done in deterministic, unit-tested code. The LLM never produces a final number by itself.
2. **Jurisdiction- and format-agnostic extraction.** Do NOT build the parser around the structure of a US 10-K. Documents vary by country, accounting standard, language, layout and file type. The extraction engine must search for financial concepts (e.g. "revenue", "net debt", "diluted shares") wherever they appear, using a canonical taxonomy plus synonyms, and must work equally on a 10-K, a UK annual report, a German Geschäftsbericht, Spanish cuentas anuales, a Japanese 有価証券報告書, an Indian annual report, an unaudited management account in Excel, or a scanned PDF.
3. **Full traceability.** Every extracted value stores: source file, page/sheet, table/cell or text span, the original label as written, original units/scale/currency, the conversion applied, and a confidence score. The user can click any number and see the highlighted source.
4. **Human in the loop.** Extraction always ends in a review screen. Low-confidence values and failed reconciliation checks are flagged. Every manual override is recorded (who — the user name set in Settings, when, old value, new value, reason).
5. **Ranges, not false precision.** Present valuations as ranges with sensitivities. Round displayed outputs sensibly. Make every assumption visible and editable.
6. **Reading the documents is the primary path; manual entry is a complete fallback.** The default flow starts with an upload and the connected AI reading the documents. A user with no documents, or without any AI connected, must still be able to run the whole analysis from tagged filings (XBRL/iXBRL), rules-based table extraction and typed or pasted numbers.
7. **Sensible defaults, fully overridable.** Quick Scan mode should produce a result with minimal input; Detailed mode exposes everything.
8. **No silent failures.** If something can't be found, say so and ask the user for it rather than guessing.
9. **Each person brings their own AI, and no provider is hard-wired.** The repository contains no key and no shared account. Documents are read only with the provider and key the person connected on their own machine, and their usage and cost are shown to them. Extraction, mapping and writing logic talk to one provider-neutral interface, never to a vendor SDK directly, so switching provider never changes results logic, schemas or validation.

## 3. Recommended architecture and stack

Use this unless you have a strong, stated reason to deviate:

**How it runs: a local app, downloaded from GitHub.** DealScout is published as a GitHub repository. Each person clones or downloads it, runs one start command, and uses it in their browser at `http://localhost:8000` on their own computer, like a local development site. There is no Docker, no hosted server, no login and no shared database: one person, one machine, their own deals, their own AI key (or none). Design everything for that.

- **Backend:** Python 3.12+, FastAPI, Pydantic v2 models, SQLModel/SQLAlchemy on **SQLite** (a single database file). Document processing runs as background tasks in the same Python process, tracked in a SQLite job table with per-step status, so long jobs survive page reloads and resume after a restart. No Redis, Celery or separate worker service.
- **Calculation engine:** a pure-Python package (`dealscout_engine/`) with no web or LLM dependencies, using `numpy`/`pandas`, fully unit-tested. The API and UI call into it. This separation is mandatory.
- **Document processing:** `PyMuPDF` and `pdfplumber` for PDFs, `camelot`/`tabula` or equivalent for table detection, `ocrmypdf`/Tesseract for scanned documents (with language packs), `openpyxl`/`pandas` for Excel/CSV, `python-docx` for Word, `BeautifulSoup`/`lxml` for HTML, and an XBRL / iXBRL parser (e.g. `arelle` or a lightweight custom iXBRL reader) for structured filings.
- **AI layer (multi-provider):** an `ai/` package with one provider-neutral interface that the rest of the code uses, and one adapter per provider behind it.
  - **The interface:** `extract_structured(content, json_schema) -> validated object`, `generate_text(prompt, context) -> text`, `test_connection()`, `list_models()`, and per-call usage (input/output tokens and estimated cost). Content is passed as page text with page numbers, optional page images, or a native PDF where the provider supports it.
  - **Capability flags per provider and model:** native PDF input, image input, JSON-schema structured output (strict or best-effort), maximum context, prompt caching, price per token. The pipeline adapts to them: send native PDF pages when supported; otherwise send extracted text with page markers plus page images for tables when vision is supported; otherwise text only. When strict structured output isn't available, ask for JSON, validate against the same Pydantic schema, and retry once with the validation errors. The same schema, validation and "never invent a number" rules (§5.3) apply to every provider.
  - **Providers to support:**

    | Provider | Connection | Notes |
    |---|---|---|
    | **Anthropic Claude** (default, recommended) | API key from the Claude Console; official `anthropic` SDK (follow the `claude-api` skill) | Native PDF input and structured outputs. The reference provider: build and tune prompts on it first. |
    | **OpenAI** (the models behind ChatGPT) | API key from the OpenAI Platform; official `openai` SDK | Structured outputs and file/PDF input; check current docs. |
    | **Microsoft Copilot / Azure OpenAI** | Azure OpenAI endpoint URL, deployment name, API version and key (or Microsoft Entra ID sign-in, if feasible); `openai` SDK's Azure client | Consumer and Microsoft 365 Copilot have no general-purpose API for this. Companies that standardise on Copilot normally have Azure OpenAI (or Azure AI Foundry), which serves the same OpenAI models under their Microsoft agreement. Label it "Microsoft Copilot / Azure OpenAI" and explain this on the connect screen. |
    | **Google Gemini** | API key from Google AI Studio (`google-genai` SDK); optionally Vertex AI with a Google Cloud project for companies on Google Workspace / Cloud | Native PDF input and JSON-schema output; check current docs. |
    | **xAI Grok** | API key from the xAI console; OpenAI-compatible endpoint via the `openai` SDK with xAI's base URL | Check current support for structured outputs and file input; fall back to text + JSON validation. |
    | **Perplexity** | API key from Perplexity's API settings; OpenAI-compatible endpoint | Built around web search: answers may mix in web content that isn't in the user's documents. Turn web search off for document extraction if the API allows it, and otherwise warn the user that results are less reliable for extraction. Its search is a good fit for optional peer and precedent-transaction suggestions (§9.3), clearly labelled as web-sourced and to be verified. |
    | **Custom OpenAI-compatible endpoint** | Base URL, model name, optional key | Covers company AI gateways and local models (Ollama, LM Studio) for teams that may not send documents outside the company. Warn that small local models may extract poorly. |

  - **Use official SDKs only** (`anthropic`, `openai`, `google-genai`); don't add a third-party multi-provider wrapper library.
  - **Quality differs by provider.** Run the extraction accuracy evaluation (§16) against each provider you can test, publish the results in `docs/providers.md`, and show a short note on the connect screen ("tested extraction accuracy: high / medium / limited / untested"). Mark providers you could not test as untested rather than guessing.
  - **Caching:** cache results by document hash + provider + model + prompt version, so re-runs don't re-bill and switching provider doesn't reuse another model's answers.
- **Connect your AI (bring your own key):**
  - On first launch, and from Settings at any time, a "Connect AI" screen lets the user pick a provider, enter what it needs (key, plus endpoint and deployment for Azure, or base URL for custom) and choose a model from that provider's current list. A "Test connection" button makes a minimal call and reports success, an invalid key, missing credit or a model that isn't available. The upload step prompts the user to connect if they haven't, with "Continue without AI" as a visible alternative.
  - Explain on that screen that a chat subscription is not an API key: Claude Pro/Max, ChatGPT Plus/Pro, Gemini via Google One, SuperGrok, Copilot Pro and Perplexity Pro are used in their own apps. DealScout needs an API key from the provider's developer console (or the company's Azure/Google Cloud setup), which is billed separately per use. Link to each provider's key page. DealScout must never sign in to a chat subscription on the user's behalf.
  - Several providers can be saved; one is active. Optional: a separate provider for writing (summaries and rationale) than for extraction. Each deal records which provider and model produced each extracted value and each piece of text.
  - Store keys in the operating system's keychain (macOS Keychain, Windows Credential Manager, Linux Secret Service) via the `keyring` package, one entry per provider; if no keychain is available, fall back to a file in the app's data folder readable only by the user, and say so on screen. Advanced users may set provider variables in `.env` instead (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `AZURE_OPENAI_*`, `GEMINI_API_KEY`, `XAI_API_KEY`, `PERPLEXITY_API_KEY`, `CUSTOM_AI_BASE_URL`). Never send a saved key to the browser (show only its last 4 characters), never log it, and let the user replace or remove it at any time.
  - Optional settings: a monthly spend cap after which AI calls stop and the user is told why.
  - Handle errors the same way for every provider: invalid or revoked key, rate limit (retry with backoff), out of credit, model retired, content refused. Pause the job with a message and resume once fixed; never lose already-extracted results.
  - A usage panel shows provider, model, tokens and estimated cost per document and per deal.
- **Frontend:** Next.js (App Router, built as a static export with `output: 'export'`, so FastAPI can serve it; all data comes from the FastAPI API. A static export can't pre-build a page per deal, so route deal pages client-side, e.g. `/deal?id=…`, and have FastAPI fall back to the app shell for unknown paths) + TypeScript + Tailwind + a component library (shadcn/ui, built with the `shadcn` skill). Charts with Recharts or ECharts (designed with the `dataviz` skill). A spreadsheet-style grid (e.g. AG Grid community or TanStack Table) for financial statements and manual entry. A PDF viewer (PDF.js) that can highlight source locations.
- **Exports:** `openpyxl` / `XlsxWriter` for Excel (with live formulas, not pasted values; follow the `xlsx` skill), a PDF report (WeasyPrint or headless Chromium), `python-pptx` for a one-page slide summary.
- **Running it (no Docker):**
  - **One start command:** `./start.sh` on macOS/Linux and `start.ps1` on Windows. It checks prerequisites and names any that are missing with the install command, installs Python dependencies (with `uv`, into a local virtual environment) and web dependencies (`npm`) on first run, builds the frontend if it has changed, starts FastAPI on `127.0.0.1:8000` serving both the API and the built frontend, and opens the browser. Ctrl+C stops everything.
  - **Development mode:** `./dev.sh` / `dev.ps1` runs the FastAPI server with reload and the Next.js dev server with hot reload side by side, with the frontend proxying API calls.
  - **Prerequisites,** documented in the README with install commands for macOS (Homebrew) and Windows (winget): Python 3.12+, Node.js 20+, `uv`. Optional: Tesseract with language packs (only needed to read scanned documents; without it the app says scanned pages can't be read and asks for manual input); LibreOffice (only needed to run the Excel recalculation tests).
  - **Local data:** the database, uploaded documents, cache and exports live in a per-user app data folder outside the repository (e.g. via `platformdirs`), shown in Settings with an "Open folder" button. `.gitignore` excludes `.env`, data folders, virtual environments and build output, so nobody can commit their deals or key by accident.
  - `.env.example` documents every optional variable. A `Makefile` (plus equivalent npm or PowerShell scripts for Windows) provides `test`, `lint` and `seed` (loads a sample deal from fixtures).

Suggested repository layout:

```
dealscout/
  engine/            # pure calculation library (valuation, ratios, projections) + tests
  extraction/        # ingestion, OCR, table detection, concept search, LLM mapping, reconciliation
  ai/                # provider-neutral AI interface + one adapter per provider (Anthropic, OpenAI, Azure OpenAI, Gemini, xAI, Perplexity, custom)
  api/               # FastAPI app, routes, persistence, background job runner, settings and key storage
  web/               # Next.js frontend (static export served by the API)
  scripts/           # start/dev scripts for macOS, Linux and Windows
  data/defaults/     # market assumption defaults (versioned, dated, sourced)
  data/taxonomy/     # canonical financial concepts + multilingual synonyms
  tests/fixtures/    # sample documents from multiple jurisdictions + expected outputs
  docs/              # methodology notes, user guide
```

## 4. Core user flow

1. **Create a Deal** — target name, country, sector/industry (with suggestions), listed or private, ticker (optional), reporting currency, analysis currency, valuation date, perspective (financial sponsor vs strategic buyer).
2. **Add data** — upload documents (any number, any mix) for the connected AI to read; this is the default and the first option shown. If no AI is connected, prompt the user to connect one here, or continue without AI (tagged filings, rules-based extraction and manual entry only). Manual entry and pasting a table from Excel are offered alongside, for gaps and for users without documents.
3. **Extraction review** — side-by-side view: normalized statements on the left, source document on the right with highlighted locations. Flags, confidence, reconciliation results, missing items. User confirms or corrects.
4. **Normalization** — adjustments to get to clean, comparable figures (see §7).
5. **Company analysis dashboard** — ratios, trends, quality-of-earnings flags, qualitative summary.
6. **Assumptions** — projections, WACC, peers, transactions, LBO structure, asset values. Pre-filled with defaults; everything editable.
7. **Valuation** — each method on its own tab, plus scenarios (bear/base/bull) and sensitivities.
8. **Summary & acquisition price** — football field, blended range, suggested offer price, implied multiples and premia, key risks, and "what would need to be true" notes.
9. **Export / share** — Excel, PDF, PPTX, JSON; save versions; duplicate a deal to test alternatives.

Offer two modes:

- **Quick Scan** — minimal questions, defaults everywhere, results in a couple of minutes.
- **Detailed** — all assumptions exposed, method-by-method control.

## 5. Document ingestion and extraction (the hardest part — design it carefully)

### 5.1 Accepted inputs

PDF (text-based and scanned), XLSX/XLS/CSV, DOCX, HTML, XBRL and iXBRL (e.g. SEC filings, EU ESEF annual reports), images (PNG/JPG of statements), and ZIP archives containing any of these. Multiple documents per deal (e.g. three annual reports plus the latest quarterly/half-year report).

### 5.2 Pipeline

1. **Fingerprint & classify** each file: hash, type, page count, text vs scanned, detected language(s), likely document type (annual report, interim report, audited accounts, management accounts, investor presentation, prospectus, credit agreement, valuation report, other), company name, period(s) covered, auditor (if any).
2. **Structured data first.** If the file contains XBRL/iXBRL tags, extract tagged facts first — these are high-confidence. Map US GAAP, IFRS and local taxonomies to the canonical model.
3. **Text and layout extraction.** Run OCR where needed. Extract text with positions; detect tables and reconstruct rows/columns, including multi-line labels, merged headers, and column headers that indicate period (e.g. "2025", "FY24", "9M 2026", "31.12.2025", "令和6年度").
4. **Locate the primary statements by search, not by position.** Find the income statement, balance sheet, cash flow statement, statement of changes in equity and key notes by scoring pages/tables against concept signatures (headings and line items in many languages, e.g. "Consolidated Statement of Profit or Loss", "Gewinn- und Verlustrechnung", "Cuenta de pérdidas y ganancias", "Compte de résultat", "Conto economico", "損益計算書"). Prefer consolidated over standalone/parent-only unless the user chooses otherwise; record which was used.
5. **Concept mapping.** Map each line item to the canonical taxonomy (§6) using: (a) the synonym dictionary, (b) structural cues (position, subtotals, sign), and (c) an LLM call that returns the mapping with a rationale and confidence as structured JSON. Line items that don't map stay as "unmapped" in a reviewable bucket — never discarded.
6. **Targeted search for items not in the main statements.** Many critical inputs live in notes or text: share counts (basic, diluted, treasury), options/RSUs and strike prices, debt maturities and interest rates, lease liabilities, pension deficits, minority interests, associates, contingent liabilities, segment data, D&A split, capex, stock-based compensation, one-offs, headcount, guidance. For each, run a concept search across all documents and return candidates with evidence; let the user pick if ambiguous.
7. **Normalize numbers.** Handle: scale indicators ("in thousands", "€m", "en miles de euros", "in Mio. EUR", "百万円", "₹ crore", "lakhs"); decimal and thousand separators (1,234.56 vs 1.234,56 vs 1 234,56); negatives in parentheses or with trailing minus; dashes meaning zero; footnote markers attached to numbers; currencies; fiscal year ends that don't match the calendar year; 52/53-week years; restated comparatives (prefer the latest restated figures and flag the change).
8. **Periods.** Build a period model: annual, half-year, quarterly, year-to-date. Compute LTM automatically when interim data is present (LTM = latest YTD + prior full year − prior-year YTD), and show the calculation.
9. **Reconciliation checks** (run automatically, show pass/fail):
   - Assets = Liabilities + Equity.
   - Subtotals equal the sum of their components (within rounding tolerance).
   - Cash flow: opening cash + net change (+ FX effect) = closing cash, and closing cash matches the balance sheet.
   - Net income agrees between income statement and cash flow / equity statement.
   - Same-period figures agree across documents (e.g. FY2025 in the 2025 and 2026 reports — differences flagged as restatements).
   - Sign sanity (e.g. revenue positive, capex an outflow).
10. **Confidence scoring** per value combining: source type (XBRL > clean table > OCR table > narrative text > LLM inference), reconciliation success, and mapping certainty. Colour-code in the UI.

### 5.3 LLM usage rules for extraction

These rules apply to every provider, through the AI interface in §3. Follow the `claude-api` skill for the Anthropic adapter and each provider's official docs for the others.

- Send only relevant pages/chunks, not whole documents, where possible; for long documents, first locate, then extract.
- Every LLM extraction response must include: value as written, page reference, the exact label, units/scale as stated, and a confidence level. Validate the response against a Pydantic schema; retry once on schema failure, then flag for manual input.
- The LLM must never invent a number. If it can't find something, it returns `null` with a reason.
- Log prompts, provider, model, tokens and cost per deal locally, shown in the usage panel. Never log keys.
- All calls use the provider and key connected on this machine (§3). Prompts are written once, provider-neutral, and versioned; per-provider tweaks live in the adapter, not in the extraction logic.
- The confidence score of an AI-extracted value also reflects the provider's measured accuracy tier (§3), and the review screen shows which provider and model produced it.

### 5.4 Qualitative extraction

Using the documents, generate a short cited summary: business description, segments and geographies, customers/concentration, key risks, recent events (acquisitions, disposals, litigation), management and ownership, auditor and audit opinion (flag any qualified opinion, emphasis of matter or going-concern language), and outlook/guidance. Every statement links to its source page.

## 6. Canonical financial data model

Define a versioned canonical taxonomy (in `data/taxonomy/`, as YAML/JSON) covering at least:

- **Income statement:** revenue (and by segment), COGS, gross profit, SG&A, R&D, other operating income/expense, EBITDA (computed), D&A (split depreciation / amortization / right-of-use depreciation), EBIT, net interest, other financial items, share of associates, pre-tax income, tax, net income, minority interest share, net income to shareholders, EPS (basic/diluted), stock-based compensation, identified one-off items.
- **Balance sheet:** cash and equivalents, restricted cash, short-term investments, receivables, inventory, other current assets, PP&E, right-of-use assets, goodwill, other intangibles, investments in associates, deferred tax assets, other non-current assets; payables, accrued liabilities, short- and long-term debt (by instrument where available), lease liabilities (current/non-current), pension deficit, provisions, deferred tax liabilities, other liabilities; share capital, reserves, treasury shares, minority interest, total equity.
- **Cash flow:** CFO, change in working capital components, capex (maintenance vs growth if disclosed), acquisitions, disposals, CFI, dividends, buybacks, debt issued/repaid, lease principal payments, CFF, FX effect.
- **Capital structure and memo items:** basic shares, diluted shares, options/warrants/RSUs with strikes, convertibles, debt maturity schedule and rates, credit facilities, net operating losses (tax losses carried forward), employee count, dividends per share.
- **Asset-level data (for NAV):** list of assets with type, book value, fair value if disclosed, and source (investment properties, land, reserves, investments, subsidiaries, etc.).
- **Market data (if listed):** share price, date, 52-week range, market cap, beta, analyst consensus (only if user provides or a configured data provider supplies it).

Each concept has: canonical ID, display name, definition, sign convention, expected statement, aggregation rules, and synonyms by language and accounting standard (US GAAP, IFRS, UK FRS 102, German HGB, Spanish PGC, French PCG, Italian OIC, Japanese GAAP, Ind AS, and others). Make it easy to extend.

## 7. Normalization layer

- Separate reported vs adjusted figures; show both.
- **Adjusted EBITDA/EBIT:** user-tagged and LLM-suggested one-offs (restructuring, impairments, litigation, gains on disposal), each requiring user confirmation.
- **Lease treatment toggle:** pre-IFRS 16 / post-IFRS 16 / ASC 842 consistency, so multiples are comparable (EBITDA with or without lease costs, net debt with or without lease liabilities). Apply the same convention to target and peers.
- **Net debt / EV bridge builder** with explicit debt-like and cash-like items: gross debt, leases (toggle), pensions (net of tax, toggle), preferred equity, minority interest, associates, excess vs operating cash (with a minimum operating cash assumption), earn-outs, provisions as debt-like (toggle).
- **Working capital:** definition, days metrics (DSO, DIO, DPO), normalized level.
- **Currency conversion:** analysis currency selectable; FX rates entered or fetched, with average rates for P&L and closing rates for balance sheet. Show the rate and date used.
- **Calendarization** of different fiscal year ends for comparability with peers.

## 8. Company analysis module

Dashboard with tables and charts over all available historical periods plus LTM (charts per the `dataviz` skill):

- **Growth:** revenue, EBITDA, EBIT, EPS, FCF — YoY and CAGR.
- **Profitability:** gross, EBITDA, EBIT, net margins; segment margins.
- **Returns:** ROIC (with clearly stated invested capital definition), ROE, ROA, DuPont decomposition.
- **Cash generation:** FCF, FCF conversion (FCF/EBITDA, FCF/net income), capex/revenue, capex/D&A, cash conversion cycle.
- **Leverage & liquidity:** net debt/EBITDA, interest coverage, debt/equity, current and quick ratios, debt maturity profile.
- **Scores:** Altman Z (with the correct variant for public/private/non-manufacturing), Piotroski F-score, Beneish M-score (flagged as indicative).
- **Quality-of-earnings red flags** (rules-based, each with explanation): receivables or inventory growing much faster than revenue, persistent gap between net income and CFO, frequent "one-offs", rising capitalized costs, auditor changes, qualified opinions, going-concern language, related-party transactions, restatements, large goodwill relative to equity, customer concentration, rising leverage.
- **Sector-specific KPIs** where data permits (e.g. SaaS: ARR, net retention, Rule of 40; banks: CET1, NIM, cost/income, NPL ratio; insurers: combined ratio, solvency ratio; real estate: occupancy, LTV, NOI, yield; retail: like-for-like sales, sales per sq m; energy/mining: reserves, production, cost per unit).

## 9. Valuation methods

Implement each as an engine module with a typed input object, a typed output object, and unit tests against hand-checked examples. Every method shows its inputs, workings and outputs, and has a short "methodology" explainer.

### 9.1 Method suitability guide

Based on sector, maturity and data availability, suggest which methods are most relevant and default weights (user-editable). Examples: banks/insurers → P/TBV, P/E, dividend discount, residual income (not EV/EBITDA or FCFF DCF); real estate and holding companies → NAV first; asset-heavy cyclicals → mid-cycle multiples, replacement cost; high-growth loss-making → EV/Revenue, EV/ARR, DCF with long explicit period; mature cash-generative → DCF, EV/EBITDA, LBO. Explain why for each suggestion.

### 9.2 Discounted cash flow (FCFF)

- Explicit forecast period (default 5 years, configurable 3–15), optional fade period.
- Projection drivers: revenue growth, EBITDA margin, D&A % revenue, capex % revenue, NWC % revenue (or days), tax rate (with NOL usage), SBC treatment toggle.
- Default projections seeded from historical trends and (if available) management guidance or consensus, labelled clearly as assumptions.
- **WACC builder:** risk-free rate (by currency), equity risk premium, country risk premium, beta (input, peer-derived unlevered/relevered using Hamada, or sector default), optional size premium and company-specific premium, pre-tax cost of debt, tax rate, target capital structure. Show the full calculation.
- **Terminal value:** Gordon growth and exit multiple, both computed and cross-checked (implied multiple from Gordon; implied growth from exit multiple). Warn if terminal value exceeds ~75% of EV or if growth ≥ risk-free rate.
- Mid-year convention toggle, stub period handling for valuation dates mid-year.
- EV → equity value via the net debt bridge; per-share value using the treasury stock method for options and if-converted logic for convertibles (iterating where dilution depends on price).
- **Sensitivity tables:** WACC × terminal growth, WACC × exit multiple, revenue growth × margin.
- **Scenarios:** bear/base/bull with probability weights.
- Also offer FCFE, dividend discount model and residual income variants for financial institutions, and APV as an option for highly leveraged situations.

### 9.3 Trading comparables

- Peer set entered manually (name, ticker, country, financials, price) or uploaded as a spreadsheet; optional pluggable market-data connector (provider configurable via API key — design an adapter interface; the tool must work fully without one).
- Optional LLM-assisted peer suggestions (clearly labelled as suggestions to verify).
- **Multiples:** EV/Revenue, EV/EBITDA, EV/EBIT, P/E, P/B, P/TBV, EV/EBITDAR, P/FCF, PEG, sector-specific (EV/ARR, P/NAV, EV/reserves, etc.), on LTM, current-year and next-year bases.
- **Statistics:** min, 25th percentile, median, mean, 75th percentile, max; outlier exclusion toggle.
- Peer scatter plots (e.g. EV/EBITDA vs growth, EV/Revenue vs margin) with a regression line and the target's implied position.
- Apply chosen range to the target's metrics → implied EV and equity value.

### 9.4 Precedent transactions

- Transactions entered/uploaded (date, target, acquirer, EV, metrics, multiples, premium paid, % acquired, cash/stock).
- Recency weighting option; filter by date, geography, size.
- Implied valuation range; note that these include control premia.

### 9.5 LBO analysis (key for acquisition price)

- **Sources & uses:** purchase price (from entry multiple or price per share), refinanced debt, transaction fees, financing fees, minimum cash; sponsor equity, rollover equity, and debt tranches.
- **Debt tranches:** revolver, Term Loan A/B, senior notes, high yield, mezzanine/PIK, seller note — each with size (× EBITDA or amount), rate (fixed or base rate + margin), amortization, fees, cash sweep priority, PIK toggle.
- **Operating model:** reuse the DCF projections (with an option for a separate sponsor case).
- **Debt schedule** with cash sweep, interest calculated on average balances (with a circularity toggle and iterative solver, or beginning balance for simplicity), minimum cash.
- **Covenant checks:** leverage and interest coverage by year, flagged on breach.
- **Exit:** exit year, exit multiple (default = entry), exit EV → equity → returns.
- **Returns:** IRR, MOIC, for sponsor and management/rollover; dividend recap option.
- **Goal seek:** maximum entry price that achieves a target IRR (e.g. 20%) and/or MOIC (e.g. 2.5x) under the given leverage constraints — this is a primary input to the acquisition price.
- **Sensitivity tables:** entry multiple × exit multiple → IRR; leverage × exit multiple → IRR.

### 9.6 NAV / sum-of-the-parts

- **NAV:** start from book balance sheet, revalue assets and liabilities to fair value (asset-by-asset table with method per asset: appraisal, cap rate on NOI, multiple, recent transaction, book), deduct liabilities and deferred taxes on revaluation gains (toggle), optional holding-company discount, NAV per share, premium/discount to market price.
- **SOTP:** value each segment with its own method/multiple, add non-core assets, subtract net debt and corporate costs (capitalized), optional conglomerate discount.

### 9.7 Other methods (include; enable per suitability)

- Liquidation / orderly wind-down value (with recovery rates by asset class).
- Replacement cost (for asset-heavy businesses).
- Market-based reference points for listed targets: current price, 52-week high/low, VWAP periods (if price data is provided), analyst targets (if provided).
- Strategic buyer analysis: synergy valuation (cost and revenue synergies with phasing, integration costs, probability haircut), share of synergies paid away, and a simple accretion/dilution analysis for a strategic acquirer (cash/stock/debt mix).
- Private company adjustments: discount for lack of marketability (configurable), no per-share output if share count is unknown.

## 10. Acquisition price recommendation

- **Football field chart:** horizontal bars for each method's low–high range, with the current share price/market cap (if listed) and the suggested offer range overlaid.
- **Blended valuation:** weighted by user-editable weights (pre-filled from the suitability guide); show the weighting table.
- **Suggested acquisition price range** (low / mid / high) for 100% of equity and per share, with:
  - Implied EV/Revenue, EV/EBITDA, P/E at the suggested price.
  - Implied control premium vs current price and vs VWAP (if listed), compared against typical premium ranges (user-editable defaults by market).
  - LBO affordability check (does the price clear the target IRR at reasonable leverage?).
  - Synergy check for strategic buyers (how much of synergy value is paid away).
  - A plain-language rationale of 5–10 bullet points, generated from the engine outputs (the LLM writes the prose; numbers are inserted from the engine, not generated).
  - Key risks and "what would need to be true" for the high end.
  - Data quality score for the whole analysis (based on extraction confidence and how many defaults were used), shown prominently.
- An EV-to-equity bridge waterfall at the suggested price.

## 11. Visualizations (required set)

Design every chart with the `dataviz` skill, using the single shared palette. All charts interactive (hover tooltips, toggle series), exportable as PNG/SVG, and included in the PDF/PPT exports:

1. Football field (valuation ranges).
2. Historical + projected revenue, EBITDA and margin (combo bar/line).
3. Free cash flow bridge (EBITDA → FCF waterfall).
4. EV-to-equity bridge (waterfall).
5. DCF sensitivity heatmaps.
6. LBO: debt paydown (stacked area by tranche), leverage over time, IRR sensitivity heatmap.
7. Peer multiple distribution (box/strip plot) with the target marked.
8. Peer scatter (multiple vs growth/margin) with regression.
9. Ratio trend sparklines on the analysis dashboard.
10. Capital structure (stacked bar) and debt maturity profile.
11. Segment and geography mix.
12. Scenario comparison (bear/base/bull bars).

Tables: formatted financial statements (units and currency shown in headers, negatives in parentheses, periods as columns), with conditional formatting for flags.

## 12. Manual data entry

- Spreadsheet-style grid preloaded with canonical line items for the selected sector template (general corporate, bank, insurer, real estate, SaaS, resources).
- Paste directly from Excel (auto-detect periods and units).
- Download a blank Excel template (built per the `xlsx` skill); re-upload it filled in.
- Unit/scale and currency selectors per sheet.
- Live reconciliation checks while typing.
- Mix-and-match: extracted values and manual values can coexist; overrides are tracked and visually distinct.
- "Minimum viable input" path for Quick Scan: e.g. revenue, EBITDA, D&A, capex, net debt, share count, and price — everything else defaulted and labelled as such.

## 13. Market assumptions and defaults

- Ship a versioned defaults file (`data/defaults/market_assumptions.yaml`) with: risk-free rates by currency, equity risk premium, country risk premia, sector unlevered betas, sector multiple ranges, typical control premia, typical LBO leverage and pricing, default tax rates by country, DLOM ranges.
- Every default must carry a source and an as-of date. Do not invent figures: where you cannot verify a value, leave a clearly marked placeholder and list it in a `DEFAULTS_TO_VERIFY.md` file for the user to populate.
- The UI shows when each default was last updated and warns if it is older than a configurable threshold (default 90 days).
- A Defaults screen in Settings to update defaults locally; per-deal overrides never change the defaults. Updated defaults files shipped in new GitHub releases are picked up on the next start without overwriting the user's local edits (show which values differ).

## 14. Exports and collaboration

- **Excel workbook:** generated with a prominent "Create Excel" button on the deal summary page (and in the deal menu). Full specification in §14A below.
- **PDF tear sheet** (2–6 pages, see the `pdf` skill): company snapshot, key financials, analysis highlights, valuation summary, football field, suggested price and rationale, assumptions, data quality, disclaimer.
- **PPTX one-pager** for a manager or investment committee pre-screen (python-pptx, see the `pptx` skill).
- **JSON export/import** of a full deal for reproducibility.
- Deal versioning (snapshots), duplication, notes/comments per assumption, and a deal list with search and filters.

## 14A. "Create Excel" — the analysis workbook

This is a headline feature. Build it following the `xlsx` skill. One click on Create Excel produces a polished `.xlsx` workbook that an analyst can send to a manager as-is. It must look like it came from a top-tier advisory firm: stunning, clean and consistent, not a raw data dump. Build it with `XlsxWriter` (best formatting control, native charts) or `openpyxl`, and write the formatting rules once in a shared style module so every tab is consistent.

### Workbook structure (tab order)

1. **Report** — the narrative analysis (first tab, opens by default).
2. **Financials** — the full professional financial analysis.
3. **Valuation Summary** — football field and suggested price range.
4. **Supporting model tabs:** Assumptions, Projections, WACC, DCF, Comps, Precedents, LBO, NAV/SOTP (only those methods used in the deal).
5. **Sources** — every extracted value with document, page/cell and confidence.
6. **Disclaimer** — full disclaimer text.

Model tabs use live formulas linked across tabs (inputs in blue font, formulas in black, links to other tabs in green — standard banking convention), so the analyst can change an assumption in Excel and see everything update. The Report and Financials tabs should also reference model cells by formula wherever the figure is a number, so they stay in sync. Use only functions LibreOffice can evaluate (`INDEX`/`MATCH`, not `XLOOKUP`/`FILTER`/`SORT`/`UNIQUE`/`SEQUENCE`), since the CI check recalculates with LibreOffice.

### Report tab

A one-to-three-screen executive report, laid out like a printed research note (designed to print cleanly to A4 and US Letter, portrait, fit to page width):

- **Header band:** DealScout name, company name, country, sector, reporting currency and units, valuation date, date generated, and a data quality score badge.
- **AI-report notice** directly under the header, visible without scrolling, in a coloured callout box: "This report was generated automatically by AI (DealScout). It has not been prepared, reviewed or verified by a qualified financial professional. It is an indicative screening tool only and is not investment advice, a valuation opinion or a fairness opinion. Figures may contain extraction or calculation errors; verify all data against source documents before relying on it."
- **Executive summary:** 4–6 bullets covering what the company does, financial condition, headline valuation range and suggested acquisition price range.
- **Key metrics strip:** KPI tiles (revenue, EBITDA and margin, net income, FCF, net debt/EBITDA, ROIC, revenue CAGR) with arrows or colour for direction vs prior year.
- **Breakdowns:** revenue by segment and geography, cost structure (COGS, SG&A, R&D as % of revenue), margin bridge year-on-year, cash flow breakdown (EBITDA → FCF), capital structure and debt maturities, working capital (DSO/DIO/DPO). Each breakdown is a compact table plus a native Excel chart.
- **Early warning signs:** a traffic-light table (🔴 high / 🟠 medium / 🟢 no concern; use cell fill colour plus a text label, never colour alone) built from the rules in §8: earnings vs cash flow divergence, receivables/inventory outpacing revenue, rising leverage, weakening interest coverage, near-term debt maturities vs liquidity, margin erosion, Altman Z / Beneish M flags, audit opinion issues, going-concern language, restatements, related-party transactions, customer concentration, goodwill vs equity. Each row has: signal, metric value, threshold, severity, and a one-sentence explanation with a source reference.
- **Strengths:** a short matching list of positive signals.
- **Valuation snapshot:** mini football field chart, blended range, suggested offer range, implied multiples and premium.
- **Recommendations:** 4–8 practical, clearly labelled indicative next steps for the analyst, such as "proceed to full due diligence", "request management accounts for H2", "investigate the jump in receivables", "test valuation sensitivity to a 200 bp higher WACC", or "deprioritise: valuation does not clear the target IRR at the current price". Each recommendation is linked to the finding that prompted it. These are suggestions for further work, never buy/sell advice.
- **Key assumptions and limitations:** what was defaulted, what was missing, which documents were used.
- **Footer disclaimer** repeated at the bottom of the tab and set as the print footer on every page of every tab: "AI-generated report — not prepared or reviewed by a financial professional. For internal screening only."

The narrative text is written by the LLM from the engine's results; every number in the text is inserted from the engine (never generated by the LLM), and the LLM is instructed to avoid definitive investment language.

### Financials tab

A full professional-style financial analysis covering all historical periods, LTM and projections, with periods as columns, actuals and projections visually separated (e.g. a subtle shaded header and an "A" / "E" suffix):

- Income statement (reported and adjusted), with growth % and margin % rows in italic beneath the key lines.
- Balance sheet, with a balance check row.
- Cash flow statement, with FCF derivation and a cash reconciliation check.
- Ratio analysis grouped under subheaders: growth, profitability, returns (ROIC, ROE, ROA, DuPont), liquidity, leverage and coverage, efficiency (asset turnover, DSO/DIO/DPO, cash conversion cycle), cash flow quality, per-share data.
- Scores: Altman Z, Piotroski F, Beneish M, each with a band interpretation.
- Normalisation adjustments table (reported → adjusted EBITDA, with each adjustment itemised).
- Net debt / EV bridge.
- Sector-specific KPIs where available.
- Charts alongside the tables: revenue and EBITDA with margin line, FCF and conversion, leverage trend, returns trend, working capital days.
- Check cells (e.g. balance sheet balances) displayed as ✓ / ✗ with conditional formatting.

### Visual design requirements ("stunning")

- **Colour palette:** a restrained, premium palette — deep navy primary (e.g. `#0B1F3A`), a single accent (e.g. teal `#0FA3A3` or gold `#C9A227`), soft greys for bands and gridlines, plus semantic red/amber/green used only for warnings. Define the palette once and use it everywhere, including in the charts (and share it with the web UI, PDF and PPTX).
- **Typography:** one clean font family throughout (e.g. Calibri or Aptos as the safe default; Arial fallback). Title 20–24pt bold, section headers 12–14pt bold with a coloured underline or band, body 10–11pt.
- **Layout:** gridlines hidden; column A as a narrow left margin; consistent column widths; generous white space; section headers as full-width coloured bands; alternating subtle row shading in large tables; frozen panes on headers and labels; logical grouping (Excel outline) so detail rows can collapse.
- **Number formats:** thousands separators, negatives in parentheses, percentages to one decimal place, multiples as `0.0x`, units and currency stated in every table header (e.g. "EUR m"). No visible `#####`, errors or unformatted raw floats anywhere.
- **Charts:** native Excel charts (not images) so they stay editable; consistent palette; no 3D effects or default chart styling; clear titles, labelled axes, minimal gridlines, data labels where helpful.
- **Navigation:** a contents block on the Report tab with hyperlinks to each tab, and a "← Back to Report" link at the top of every other tab. Tab colours grouped by type (report/summary vs model vs sources).
- **Print setup on every tab:** orientation, fit to width, repeated header rows, header with company name and date, footer with the AI disclaimer and page numbers.
- **Workbook properties:** title, subject and author set to "DealScout (AI-generated)". Input cells unlocked and formula cells locked, with sheet protection off by default but available as an export option.
- **Optional:** company or firm logo placeholder in the Report header (user can upload their firm's logo in settings).

### Quality checks before the file is offered for download

- Open the generated file programmatically and verify: no formula errors, all expected tabs present, every chart has data, the disclaimer appears on the Report tab, the Disclaimer tab and in the print footers.
- Recalculate with LibreOffice in headless mode in tests (the `xlsx` skill's recalculation check) and compare key outputs to the engine results (within rounding).
- Render the Report and Financials tabs to PDF/PNG in CI and keep snapshot images so visual regressions are caught.
- Include a sample generated workbook from a fixture company in `docs/examples/`.

## 15. Security, privacy and compliance

These documents may be confidential or contain material non-public information. DealScout is a single-user local app (no login, no accounts, no roles), so the protections focus on the user's own machine and on what leaves it:

- The server binds to `127.0.0.1` only, never `0.0.0.0`, so other devices on the network can't reach it. Reject requests whose `Host` or `Origin` isn't localhost (protects against DNS rebinding and other websites calling the local API).
- Documents, the database and exports stay in the local app data folder (§3); nothing is uploaded anywhere except the selected pages sent to the AI provider the user connected. The connect screen states where that provider processes data and links to its data-use policy, so users can pick the one their company has approved. Recommend full-disk encryption (FileVault / BitLocker) in the README rather than building custom file encryption.
- Audit log of uploads, exports and overrides, per deal.
- Configurable data retention and hard delete of a deal and all its files.
- AI provider keys live in the OS keychain (§3), is never written to the repo, logs, exports or JSON deal files, and is never sent to the browser. The repo ships `.env.example` only; `.gitignore` covers `.env` and all local data.
- Clear documentation of which data is sent to the AI provider; a setting to restrict what is sent (e.g. only located pages), and an option to disable LLM features entirely (manual + rules-based extraction still works).
- Input validation, file type checks, size limits, and malware-safe handling of uploads (no execution of embedded content, macros ignored).

## 16. Testing and quality

- Engine unit tests for every formula with hand-verified expected results (e.g. a textbook DCF, a simple LBO with known IRR, treasury stock method, Gordon growth, WACC). Aim for high coverage on `engine/`.
- Property tests (e.g. Hypothesis): balance sheets balance after normalization; EV bridge is reversible; IRR of known cash flows matches.
- Extraction fixtures from multiple jurisdictions and formats (use publicly available filings): a US 10-K (with XBRL), a US 10-Q, a UK annual report, an EU ESEF iXBRL report, a German report, a Spanish report, a Japanese report, an Indian report, a scanned PDF, an Excel management account. For each, store expected values for a core set of line items, and track extraction accuracy in a test report, per AI provider and model (plus a "no AI" baseline), feeding `docs/providers.md`.
- AI adapter tests: every adapter passes the same contract tests against recorded responses (no live calls or keys in CI): structured output parsing, schema-failure retry, `null`-with-reason handling, error mapping (invalid key, rate limit, out of credit) and usage/cost reporting. Live accuracy runs are a separate, manual command that uses the developer's own keys. Don't commit copyrighted documents you can't redistribute — provide a download script instead.
- End-to-end tests (Playwright) for the main flow: create deal → upload → review → value → export. Use `playwright-cli` to look at screens while building them.
- UI stress tests with the `break-ui` skill on the statement grids, tables and review screen, and a `web-design-guidelines` audit at the end of each UI milestone.
- Linting/formatting (ruff, mypy, ESLint, Prettier), CI workflow running all tests.

## 17. UX and design notes

Build the web UI with the `app-design` and `shadcn` skills, treating the notes below and §14A's palette as the brand override (see §0).

- Clean, dense, professional look suitable for finance users — think terminal-grade clarity, not consumer app. Dark and light modes.
- Number formatting respects user locale settings but is consistent within a deal; units and currency always visible.
- Keyboard-friendly grids; undo/redo on assumption changes.
- Every number clickable → shows its derivation (formula, inputs) or its source location.
- Progress indicators for document processing with per-step status.
- Contextual help: a short explainer for every metric and method.
- Accessible (WCAG 2.1 AA): colour is never the only signal for flags.

## 18. Milestones

Build in this order; each milestone must end with working, tested, demoable software:

1. **Foundation:** repo scaffold, the `start` and `dev` scripts for macOS/Linux and Windows (no Docker), SQLite models, deal CRUD, the provider-neutral AI interface with the Anthropic adapter, the "Connect AI" settings screen (provider picker, OS-keychain key storage, test-connection call), canonical taxonomy v1, engine package skeleton with CI (GitHub Actions on macOS, Windows and Linux). Copy §0 into `CLAUDE.md`. *(Skills: `shadcn`, `app-design` for the app shell and deal CRUD screens.)*
2. **Manual entry + core engine:** statement grid, reconciliation checks, ratios, DCF, comps, football field, basic summary. (A user can run a full Quick Scan with typed numbers.) *(Skills: `app-design`, `shadcn`, `dataviz`, `xlsx` for the entry template, `break-ui`.)*
3. **Document ingestion v1:** PDF/Excel/CSV parsing, table detection, concept search and LLM mapping, review screen with source highlighting, LTM calculation. Add the OpenAI, Azure OpenAI and Google Gemini adapters, with the capability-based fallbacks (text + page images, JSON validation) proven on at least one provider without native PDF input. *(Skills: `claude-api`, `pdf`, `app-design` for the review screen.)*
4. **Structured filings & OCR:** XBRL/iXBRL, scanned documents, multilingual synonyms, multi-document period reconciliation. Add the xAI Grok, Perplexity and custom OpenAI-compatible adapters, and the per-provider accuracy report. *(Skills: `claude-api`.)*
5. **LBO, NAV/SOTP, precedents, financial-institution methods, strategic/synergy analysis.** *(Skills: `dataviz` for the LBO and sensitivity charts, `app-design` for the method tabs.)*
6. **Acquisition price module:** suitability guide, weighting, recommendation, rationale generation, data quality score. *(Skills: `claude-api` for rationale prose, `dataviz` for the football field and bridges.)*
7. **Exports:** the "Create Excel" workbook (Report and Financials tabs first, styled per §14A, with live formulas and quality checks), then PDF, PPTX and JSON. *(Skills: `xlsx`, `dataviz`, `pdf`, `pptx`.)*
8. **Hardening and release:** security review, performance (large documents, 300+ pages), extraction accuracy evaluation across fixtures, docs and user guide. Test a fresh download-and-start on macOS and Windows following only the README, and prepare the repo for public GitHub release (README with screenshots, LICENSE, `.gitignore` audit, no secrets or private documents in history). *(Skills: `web-design-guidelines`, `break-ui`, `playwright-cli`.)*

## 19. Definition of done

- A user can upload a set of annual/interim reports from at least five different countries/standards and get correctly mapped core financials (revenue, EBITDA, net income, total assets, cash, debt, equity, CFO, capex, share count) with source links, or a clear request for any item that couldn't be found.
- A user with no documents can complete a valuation by manual entry alone.
- On a fresh macOS or Windows machine with the prerequisites installed, someone can download the repo from GitHub, run the one start command, connect their own AI key and analyse a document at `http://localhost:8000`, following only the README. Without a key, the app offers to connect one or continue without AI, and tagged filings, rules-based extraction and manual entry still work.
- The same deal can be extracted with Claude, OpenAI and Gemini (and every other adapter passes its contract tests), with each value recording which provider and model produced it, and the same validation and "never invent a number" rules enforced for all.
- The repository contains no API keys, deal data or documents that can't be redistributed.
- All valuation methods produce outputs that match independent hand calculations in tests.
- The summary shows a football field, a suggested acquisition price range with rationale, implied multiples/premia, an LBO affordability check and a data quality score.
- "Create Excel" produces a polished workbook with a Report tab (breakdowns, early warning signs, strengths, recommendations, AI disclaimer) and a full Financials tab, styled per §14A, with no formula errors, and it recalculates correctly when inputs are changed in Excel.
- Disclaimers are present on screen and in every export.
- README covers prerequisites and install commands for macOS and Windows, how to get and connect an API key for each supported AI provider and roughly what it costs (and why a chat subscription isn't enough), the measured accuracy per provider, the start command, where local data is stored, configuration, architecture, methodology and known limitations.

## 20. How to work

- Start by presenting your plan and any questions; then proceed without waiting on minor decisions (state your assumption and continue).
- Load the skills named in §0 at the point they apply; don't load the ones it excludes.
- Keep the engine pure and well-documented; write tests alongside code, not after.
- Prefer clarity over cleverness in financial code — analysts will audit it. Name variables as a banker would (e.g. `unlevered_fcf`, `terminal_value_gordon`, `net_debt`).
- When a financial convention is ambiguous (e.g. treatment of leases, SBC, minority interest), implement the common convention, make it a toggle, and document it in `docs/methodology.md`.
- Never hardcode market data without a source and date.
- At the end of each milestone, summarise what was built, what's tested, and what's next.
