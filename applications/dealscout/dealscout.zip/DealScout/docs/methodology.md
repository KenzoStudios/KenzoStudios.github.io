# Methodology notes

Financial conventions used by the DealScout engine. Where a convention is ambiguous, the common practice is
implemented, made a toggle, and documented here. This file grows with each milestone.

## Sign conventions (taxonomy v1)

Values are stored **signed as they affect their parent subtotal**, so every subtotal is literally the sum of its
components:

- Income statement: revenue and other income positive; expenses negative (`cogs`, `sga`, `da_total`, `interest_expense`,
  `income_tax` …).
- Cash flow statement: inflows positive, outflows negative (`capex`, `dividends_paid`, `debt_repaid`, `lease_principal_payments` …).
- Balance sheet: assets, liabilities and equity positive; contra items negative (`treasury_shares`).
- Memo items such as `sbc` are stored as positive magnitudes and are never added into a subtotal.

The expected sign of each concept (`positive | negative | either`) drives the sign-sanity reconciliation check.

## Resolving a value

For any (concept, period) the engine uses, in order:

1. a stored value (reported, extracted or typed) — it always wins, so a reported subtotal is kept as reported and the
   difference to its components is surfaced by the reconciliation checks rather than silently replaced;
2. for a `sum` concept, the sum of its available components; missing components are listed in the derivation
   (treated as zero only for that computed figure, never hidden);
3. for a `formula` concept, the formula when every input resolves (e.g. `EBITDA = EBIT − D&A`, with D&A stored negative);
4. otherwise the value is **missing**, and the UI asks for it. The engine never guesses.

Every resolved number carries a `Derivation` (kind, formula, inputs) so the UI can show how it was produced.

## EBITDA

EBITDA is always computed (`ebit − da_total`) unless the user enters it directly (Quick Scan minimum input). A
company's own "EBITDA" or "adjusted EBITDA" is stored separately as `ebitda_reported` and is shown for comparison
only. Impairments are excluded from D&A and treated as candidate one-off items.

## Last twelve months (LTM)

For flow items: `LTM = latest year-to-date + prior full year − prior-year year-to-date`, shown with its inputs.
Balance-sheet items use the latest balance. An LTM column appears in the data grid automatically when a period such
as H1-2026 has its full-year (FY2025) and prior-year (H1-2025) counterparts; it is computed by the engine
(`dealscout_engine.ltm`) and cannot be edited.

## Tagged filings (XBRL / iXBRL / ESEF)

Tagged facts are read first (brief §5.2 step 2). Only facts without dimensions are used: a segment or scenario member
is a breakdown, not the consolidated total. The `scale` attribute sets the unit, `sign="-"` makes a figure negative,
and the iXBRL number formats (dot or comma decimals, dash for zero) are applied. Periods follow the filing's own
naming: a retailer's "fiscal 2025" ending on 31 January 2026 is FY2025 (`dei:DocumentFiscalYearFocus`).

XBRL values carry the element's meaning, so they are converted to the taxonomy's sign convention: costs and outflows
become negative (`CostOfRevenue` 8,105 → −8,105; `PaymentsToAcquirePropertyPlantAndEquipment` 455 → −455); a tax
benefit stays a positive number. Elements that report the change in a balance rather than its cash effect are negated
(`IncreaseDecreaseInAccountsReceivable` 42 → −42 cash; `IncomeTaxesPaidNet` → negative). Shares outstanding come from
the cover page (dated after the year end) and are attached to the reporting year with that date noted.

Company-specific elements (extensions) are not guessed: an extension whose own label is a dictionary label (e.g.
"EBITDA") is mapped at a slightly lower confidence with a note; the rest are listed for mapping.

## Several documents for the same period

When two documents report the same line and period differently (beyond half a rounding unit), the review lists both,
marks the newer document as preferred (the one reaching the latest period; then the later upload) and notes it on the
older value. "Accept all high-confidence" takes the newer figure, so restated comparatives win.

## Extracted values: confidence

Each value read from a document carries a confidence between 0 and 1, built from:

| Factor | Values |
|---|---|
| Source | tagged XBRL fact 0.97 · Excel/CSV cell 0.92 · HTML table 0.88 · PDF text-layer or Word table 0.85 · OCR table 0.60 · AI from narrative text ≤ 0.90 · AI from a scanned image ≤ 0.50 |
| Label mapping | exact dictionary match ×1.00 · shortened label ("… being total comprehensive income") ×0.95 · spelling variant ×0.85 · AI mapping ×0.80 · mapped by you 0.90 |
| Provider tier (AI values) | high ×1.00 · medium ×0.90 · limited ×0.75 · untested ×0.85 |
| Reconciliation | value ties out in a passing check +0.10 (max 0.99) · value in a failing check ×0.80, with the reason noted |
| No unit statement | ×0.70 (figures read as units) |

Labels: **High** ≥ 0.90, **Medium** ≥ 0.75, **Low** below. "Accept all high-confidence" accepts, per cell, the best
pending value at or above 0.90. Fuzzy label matches may differ only in spelling, never in a word ("intangible" never
matches "tangible"); Japanese and Chinese labels match exactly only.

AI values are verified before they are offered: the figure as written must appear on a page that was sent (the page
is corrected if the model cited the wrong one), DealScout parses the number itself, and anything that cannot be
verified is listed as *rejected by verification* rather than stored.

## Manual entry sign rule

Costs, expenses and cash outflows (concepts with `sign: negative`, e.g. cost of sales, D&A, capex, income tax,
minority share of profit) may be typed, pasted or uploaded as positive amounts; they are stored as negatives. The
grid shows them in parentheses. Concepts that can genuinely take either sign (e.g. other financial items, one-offs)
are stored exactly as entered.

## Quick Scan: how each assumption is resolved

In order: **your override → company history → sourced market default → stated convention**. Each assumption shows
which applied, with the source and as-of date for defaults (flagged when older than 90 days). If none applies the
assumption is reported as **missing** and the DCF does not run.

| Assumption | History rule | Default / convention |
|---|---|---|
| Revenue growth | CAGR over the last ≤3 years, bounded to −10%…+25%, fading linearly to terminal growth | Flat at terminal growth if only one year (convention) |
| EBITDA margin | Held at the base-year margin | — (missing) |
| D&A, capex % of revenue | Average of the last ≤3 years | — (missing) |
| NWC % of revenue | Average of (receivables + inventory − payables) ÷ revenue | 0% when no working-capital data (convention) |
| Tax rate | — | Statutory rate for the country (default); else base-year effective rate |
| Risk-free rate | — | 10-year local-currency government yield for the reporting currency (EUR = German Bund) |
| ERP | — | Damodaran implied ERP (default) |
| Country risk premium | — | Damodaran CRP for the country — **not added** when the risk-free rate is the country's own local-currency government yield (that yield already prices sovereign default risk; adding the premium would double count). EUR is the exception because its risk-free rate is the Bund. |
| Beta | — | Sector unlevered beta (Damodaran, US industries), relevered with Hamada at the target D/(D+E) |
| Cost of debt | Interest expense ÷ average gross debt, bounded to [rf, rf + 10%] | — (missing) |
| Target D/(D+E) | Book debt ÷ (debt + book equity) | 0% if no balance sheet (convention) |
| Terminal growth | — | 2.0% long-run nominal growth, capped 0.5pp below the risk-free rate (convention) |
| Exit multiple | Peer median EV/EBITDA | Sector EV/EBITDA (default); otherwise the multiple implied by the Gordon terminal value (derived) |

Statutory tax rates in the defaults combine central and local corporate taxes where applicable (e.g. Germany
corporate + trade tax).

## DCF conventions

- FCFF = EBIT − cash taxes + D&A − capex − increase in NWC. Cash taxes apply to positive EBIT after tax-loss
  carryforwards (NOLs) are used up.
- Stock-based compensation is treated as a real expense by default (no add-back); a toggle adds it back.
- Stub period: the first projected year is cut to the fraction of the year left after the valuation date.
- Mid-year convention (default on): each cash flow is discounted from the middle of its period; the terminal value
  from the end of the final year.
- Terminal value: Gordon growth by default; the exit-multiple value and the cross-checks (implied multiple, implied
  growth) are always shown. Warnings when terminal value > 75% of EV, growth ≥ risk-free rate, or the two methods
  differ by more than 30%.
- Quick Scan DCF range: low = WACC +1pp and growth −0.5pp; high = WACC −1pp and growth +0.5pp.
- Scenarios (default): bear −2pp growth and margin (25%), base (50%), bull +2pp (25%). The analyst can define 1 to 6
  named scenarios per deal (stored with the method inputs), each shifting revenue growth and EBITDA margin in every
  projection year, WACC, the exit multiple and, optionally, terminal growth. Probabilities must add up to 100%; the
  probability-weighted EV and equity are shown. A scenario whose shifts make WACC ≤ terminal growth is reported, not
  dropped.
- Quick Scan versus Detailed mode: Quick Scan uses one value per driver (growth fades linearly from the bounded
  historical CAGR to terminal growth). Detailed mode sets revenue growth, EBITDA margin, D&A, capex and NWC (% of
  revenue) per projection year; a shorter list is padded with its last value, a longer one is cut to the forecast
  period.

## EV ↔ equity bridge

Equity = EV − gross debt − lease liabilities (toggle, default on: IFRS 16 / ASC 842 basis) − pension deficit (toggle,
optionally net of tax) − preferred equity − non-controlling interests − provisions (toggle, default off) − earn-outs +
excess cash (cash − minimum operating cash) + short-term investments + investments in associates. Per-share values use
the treasury stock method for options/warrants/RSUs and if-converted for convertibles, solved iteratively.

## Trading comparables

Multiples are computed from the peer financials entered. Non-meaningful multiples (non-positive denominators) are
excluded and listed. Statistics use linear-interpolation percentiles (Excel `PERCENTILE.INC`). Optional outlier
exclusion uses 1.5 × IQR. The implied range applies the 25th percentile / median / 75th percentile to the target
metric; EV multiples go through the bridge, equity multiples are equity values directly. Default football-field
weights: DCF 1, EV/EBITDA 1, EV/Revenue 0.5, P/E 0.5, others 0 (editable from Milestone 6).

## Currency conversion

When the analysis currency differs from the reporting currency, the analysis, valuation and acquisition price are
computed in the analysis currency (`dealscout_engine.fx`). Rates are entered by the analyst per period, each with
its date and source, quoted as units of the analysis currency per 1 unit of the reporting currency. There are no
default rates: if a rate a stored figure needs is missing, the valuation and price are not computed and the missing
rates are named; the analysis tab shows the figures in the reporting currency and says so.

- Income statement and cash flow (duration items): the period's **average** rate. Balance sheet and other
  point-in-time amounts (cash at year-end, share price): the period's **closing** rate. Per-share amounts convert
  like amounts; share counts, ratios and percentages do not. Opening cash on the cash-flow statement uses the same
  column's closing rate.
- Only stored values are converted; subtotals are recomputed from converted lines. Flows at average rates and
  balances at closing rates no longer tie exactly (the currency translation difference); this is shown, not hidden.
- Confirmed one-off adjustments convert at their period's average rate. The bridge comes from the converted balance
  sheet (closing rate). Amounts typed on the valuation tabs (overrides such as share price, method inputs, peers
  without a currency) are read in the analysis currency.
- Peers can carry their own currency. One rate per currency (entered with its date and source) converts all of the
  peer's figures, so its multiples are unchanged; a peer whose currency has no rate is excluded from the statistics
  with that reason.

## Calendarisation

A peer whose fiscal year ends in a different month is put on the target's fiscal year (the month of the target's
latest full year) by time-weighting its two overlapping fiscal years (`dealscout_engine.valuation.calendarise`).
With `d = (target year-end month − peer year-end month) mod 12`, calendarised = (12 − d)/12 × FY_A + d/12 × FY_B,
where FY_A is the peer's last fiscal year ending on or before the target's year-end and FY_B the following one
(the "next FY" fields). Example: target December, peer March: calendar 2025 = 0.25 × FY Mar-2025 + 0.75 × FY
Mar-2026. Only flows (revenue, EBITDA, EBIT, net income, FCF) are calendarised; market values and balances are
used as they stand. If FY_B is needed but not entered, that figure is left missing (its multiple drops out with a
reason) rather than mixing year-ends. Conversion is applied first, then calendarisation.
### Additional multiples

| Multiple | Peer figure | Target figure |
|---|---|---|
| EV / EBITDAR | EV ÷ (EBITDA + rent / lease cost); rent entered as a positive cost | EBITDA + \|`lease_expense`\| |
| PEG | (market cap ÷ net income) ÷ (expected EPS growth × 100); not meaningful when growth ≤ 0 | equity = PEG × (target EPS growth × 100) × net income; the growth is the analyst's `target_eps_growth` override (no default) |
| EV / ARR | EV ÷ annual recurring revenue | `arr` (sector KPI) |
| P / NAV | market cap ÷ reported NAV (e.g. EPRA NTA) | `reported_nav` (sector KPI, real estate template) |

Example: P/E 20x and 10% expected EPS growth give a PEG of 2.0; a target with net income 50 and 8% growth is then
worth 2.0 × 8 × 50 = 800.

Sector multiples appear in the football field only when they carry a weight. The suitability guide gives weight 0.5
(secondary) to EV/ARR for software, P/NAV for real estate and holdings (asset-based profile) and EV/EBITDAR for
transport, consumer discretionary and healthcare (rent-heavy operators); PEG is a reference (weight 0) for growth
companies and not suitable when the target is loss-making. Everywhere else they are reference points at weight 0.

### Bases: LTM, current year, next year

The `comps_basis` override (default `ltm`) selects the basis for peer statistics and the implied values. On `cy` /
`ny`, flow multiples (EV/Revenue, EV/EBITDA, EV/EBIT, P/E, PEG) use the peer's `*_cy` / `*_ny` figures, and the
target's revenue, EBITDA and EBIT come from years 1 and 2 of the DCF projection (so the DCF must run). The projection
has no net income, so P/E and PEG give no target value on a forward basis. P/B, P/TBV, EV/ARR and P/NAV are
point-in-time and identical on every basis; EV/EBITDAR and P/FCF have no forward figures. The DCF exit multiple always
uses the LTM peer EV/EBITDA median. Football-field labels carry the basis, e.g. "EV / EBITDA (CY)".

### Peer sourcing

- **AI-suggested peers** (`POST /api/deals/{id}/peers/suggest`): the connected AI proposes 5 to 10 listed companies
  (name, ticker, exchange, country, one-line reason) from the deal's name, sector, industry and country. It is told
  never to write figures; any reason containing a digit is dropped. Suggestions are labelled "AI suggestions to
  verify", are not saved, and an added suggestion becomes a peer row with blank figures for the analyst to source.
- **Market data connectors** (`services/market_data.py`): a `MarketDataProvider` protocol (`quote(ticker)` → price,
  market cap, currency, as-of date, source; `fundamentals(ticker)` optional) and a registry. The only built-in
  provider is manual / CSV import; no paid provider ships and the tool works fully without one. A keyed provider
  would read its key from the OS keychain (`dealscout_ai.keystore`) and be disabled by default.
- **CSV import** (`POST /api/deals/{id}/peers/import?scale=…`, template at `/api/market-data/peers-template.csv`):
  amounts in the deal currency at the chosen scale; `_pct` columns are percentages; `(1,234)` negatives are accepted;
  market cap = price × shares (absolute count) when blank. Rows with a missing or duplicate name, a non-numeric value,
  a non-positive market cap / EV / price / ARR / NAV, an out-of-range percentage, a bad date or currency code, or no
  market value at all are reported by row and skipped. Valid rows are added to the editor; nothing is saved until the
  analyst saves the peers.

## LBO (Milestone 5)

- Operating case: the DCF projection, or a separate sponsor case. Entry value: an entry multiple, a price per share
  (equity for all basic shares plus the net debt bridge), or the DCF enterprise value when neither is given.
- Uses: purchase of equity, refinancing of the bridge's net debt and adjustments, transaction fees (% of EV), financing
  fees (% of each tranche), minimum cash. Sources: tranches, rollover equity, sponsor equity (the balance).
- Interest on average balances solved by iteration (toggle: opening balances). Floating rate = max(base, floor) + margin;
  the base rate defaults to the sourced SOFR / EURIBOR 3M / SONIA for the currency and is labelled with its date.
- Cash sweep repays prepayable tranches (revolver, term loans, "other") in priority order; notes, high yield, mezzanine
  and seller notes are repaid at exit. A revolver with a commitment is drawn only for shortfalls.
- Exit: exit multiple (default the entry multiple) × exit-year EBITDA, less exit costs and net debt. Management promote
  is a share of exit equity.
- Maximum entry price: bisection on the entry multiple (0.5x–50x) for the target IRR (convention 20%, editable) and,
  if given, the target MOIC, with the exit multiple held fixed. Football-field range: price at target IRR +5pp (low)
  and −5pp (high).
- Leverage, margins and fees have no sourced market defaults; the LBO waits for your financing terms.

## Other methods (Milestone 5)

- Precedents: recency weights halve every `half_life_years`; weighted percentiles match NumPy's linear method with
  equal weights. Values include control premia.
- NAV: deferred tax on net taxable revaluation gains (toggle); holding discount applies to a positive NAV. Range: low =
  after discount, high = before.
- SOTP: segment multiples (low/mid/high) or entered values, less capitalised corporate costs, plus non-core assets,
  less a conglomerate discount, then the net debt bridge.
- DDM (two-stage), residual income, FCFE: range at cost of equity ±1pp. APV: unlevered cost of equity = pre-tax WACC;
  debt from the LBO schedule unless entered; permanent-debt shield D × t after the forecast.
- Synergies: phased run-rate EBITDA less integration costs, taxed, discounted at WACC, terminal value, × probability.
  Strategic value = DCF range + risked synergy value (weight 0 by default).
- Liquidation: book × recovery (low/high) less liabilities and wind-down costs, floored at zero. Replacement cost:
  cost × (1 − physical) × (1 − functional) × (1 − economic), then the bridge.
- DLOM: user-entered only; applies to trading comps (or all methods) for private companies; the high discount sets
  the low end.
- Default weights: LBO 1 for a financial sponsor else 0.5; precedents 0.5; NAV/SOTP 1 for real estate and holding
  companies else 0.5; DDM/RI/P-TBV 1 for banks and insurers else 0; FCFE, APV, strategic, liquidation, replacement 0.

## Scores, flags and normalisation (Milestone 5)

- Altman Z: public manufacturing (market cap), private Z′ or non-manufacturing Z″ by listing and sector; retained
  earnings read from reserves. Piotroski F: nine binary tests. Beneish M: eight-variable model, threshold −1.78,
  indicative only.
- One-off adjustments: amount = effect on reported profit (cost negative). Adjusted = reported − amount; impairments
  adjust EBIT only by default. Only confirmed items count; the valuation uses adjusted EBITDA/EBIT when switched on.
- AI-suggested one-offs: the AI copies amounts as printed with their page; code verifies the figure is on the page,
  applies the unit statement, and stores the item unconfirmed.

## Acquisition price (Milestone 6)

- Suitability guide: each method is primary (weight 1), secondary (0.5), reference (0) or not suitable (0) by the
  sector's profile (mature, cyclical, growth, regulated, asset-based, financial, asset-light financial), the buyer
  type and whether EBITDA is negative; each carries its reason. The analyst's weights override the suggestion.
- Suggested range = the weighted blend of methods with results (low / mid / high), for 100% of equity and per diluted
  share. Implied EV/Revenue, EV/EBITDA (EV via the net debt bridge) and P/E at each point.
- Checks: control premium vs market value against the analyst's typical range (no sourced default); LBO affordability
  (mid price ≤ the price that earns the target IRR); synergies paid away = (mid − standalone value) ÷ risked synergy
  value, where standalone is market value if listed, else the DCF mid (≤ 50% pass, ≤ 100% check, above fail).
- Data quality score (0–100) = 50% average confidence of the financial figures (typed figures count as 1) + 30% share
  of assumptions that are company-specific (analyst, history or derived, not defaults or conventions) + 20%
  completeness. Grades: A ≥ 85, B ≥ 70, C ≥ 50, D below.
- Rationale: written from labelled facts formatted from engine outputs. The AI may cite a value only by placeholder;
  code fills in the values and discards any sentence containing a digit the AI wrote. When inputs change, the stored
  AI text is marked stale and the standard wording is shown until it is rewritten.

## Warning signs in document text

- A rules-based phrase scanner (`dealscout_extraction.text_signals`, no AI) reads the page text of every processed
  narrative document (PDF, HTML, tagged filing, Word, OCR'd image; not spreadsheets) in English, German, Spanish,
  French, Italian, Dutch, Portuguese and Japanese. Signals: going-concern doubt (material uncertainty / substantial
  doubt) and a qualified or adverse opinion or disclaimer (high); an emphasis-of-matter paragraph, a change of auditor,
  a restatement of prior periods (high when it corrects an error) and significant related-party loans, guarantees or
  trading (medium); customer concentration with a printed share (one customer: 10% medium, 25% high; a group of top
  customers: 30% medium, 50% high).
- False positives are avoided by negation cues just before or inside the phrase ("no material uncertainty",
  "unqualified opinion", "not restated"), short negations after it (German "nicht", Japanese "認められない"), and by
  ignoring conditional sentences such as the auditor's standard "whether a material uncertainty exists".
- Each sign shows the document, page and a quote of at most 200 characters, and is listed with the figure-based signs
  (`source: "document"`). Its period is the latest year of the figures extracted from that document, else the year
  in its wording ("year ended 31 December 2025"). Results are cached by file hash and rules version.
- Phrase rules find wording, not judgement: read the quoted page before relying on a sign.

## Sector KPIs

Shown for the deal's statement template only (sectors.yaml → template). A KPI with a formula is computed when all its
inputs are entered on the Data tab (Sector KPIs block); otherwise the company's reported figure is used and marked
"reported"; a note says when the two differ.

| Template | KPI | Formula |
|---|---|---|
| Bank | CET1 ratio | reported |
| | Net interest margin | net interest income ÷ average interest-earning assets (opening and closing) |
| | Cost ÷ income | operating expenses ÷ total operating income (positive income only) |
| | NPL ratio | non-performing loans ÷ gross loans |
| Insurer | Combined ratio | (net claims incurred + operating expenses) ÷ net earned premiums |
| | Solvency ratio | eligible own funds ÷ SCR |
| SaaS | ARR, net revenue retention | reported; ARR growth = ARR ÷ prior ARR − 1 |
| | Rule of 40 | revenue growth + EBITDA margin (convention; some use FCF margin) |
| Real estate | Occupancy, NOI | reported |
| | LTV | net debt (borrowings − cash − short-term investments, leases excluded) ÷ investment property |
| | NOI yield | NOI ÷ investment property |
| Retail | Like-for-like sales growth, stores | reported; revenue per store = revenue ÷ stores |

Consumer discretionary deals use the retail template. A deal saved with the general template picks up its sector's
template automatically.

## Capital structure and debt maturities

- Per balance-sheet date (engine `capital.py`): borrowings = short- + long-term debt (leases kept apart), lease
  liabilities (current + non-current), book equity, cash + short-term investments, undrawn committed facilities.
  Debt share of capital = (borrowings + leases) ÷ (borrowings + leases + book equity), positive parts only.
- Maturity profile: memo lines `debt_due_within_1y`, `debt_due_1_2y`, `debt_due_2_5y`, `debt_due_after_5y` from the
  maturity note (borrowings only, excluding leases). Debt not covered by the buckets is reported as unallocated.
  Liquidity cover = (cash + short-term investments + undrawn facilities) ÷ debt due within one year.
- Segment and geography revenue are entered per deal (`breakdowns` section of the method inputs) and shown as entered,
  with the difference to reported revenue.

## Live models in the Excel workbook

- LBO, Precedents and NAV & SOTP tabs rebuild the engine's calculation with formulas (inputs blue, links green,
  formulas black); Valuation Summary takes the precedent, NAV and SOTP ranges by formula (low = MIN, mid = MEDIAN,
  high = MAX of the tab's three values, matching the football field's sorting). Recalculated in LibreOffice they match
  the engine exactly (tests in `api/tests/test_live_models.py`).
- LBO interest on average balances: the engine solves the circularity by iteration. The workbook matches it without
  Excel's iterative calculation by unrolling the fixed point: six passes per year (passes 1 to 5 in a collapsed row
  group, the visible debt schedule is pass 6), each using the previous pass's closing balances. The error shrinks by
  roughly rate ÷ 2 per pass, so the schedule and sponsor IRR agree with the engine to better than 1e-7. Setting the
  "interest on average balances" input to 0 gives the opening-balance convention. Tranche rows are written in
  cash-sweep order (priority, revolver first on ties); changing the priority needs DealScout.
- Exit year is an input: the schedule runs over every projection year, the returns read the exit year with INDEX,
  and later years are greyed. Sponsor IRR uses IRR() over the cash-flow row; MOIC = proceeds ÷ equity invested.
- Still engine values: the LBO maximum price at the target IRR ± 5pp (a goal seek) and the IRR sensitivity tables.
- Precedents: equal weights use PERCENTILE and MEDIAN (identical to the engine's linear percentile). With a recency
  half-life, weights are 0.5^(age ÷ half-life) and the weighted percentile interpolates between positions
  (cumulative weight before ÷ (total − last weight)) with MATCH/INDEX, so rows stay sorted by multiple.
- NAV: fair value per line by method (book, appraisal or deal price, NOI ÷ cap rate, metric × multiple); deferred tax
  on positive net taxable gains (toggle); holding discount on a positive NAV.
