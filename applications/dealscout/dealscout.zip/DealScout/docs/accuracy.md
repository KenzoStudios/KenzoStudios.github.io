# Extraction accuracy

Run 2026-11-26 with tables and the dictionary only (no AI). Documents and hand-read values: `tests/fixtures/manifest.yaml`; regenerate with `uv run python scripts/accuracy_report.py --write`.

**90 of 94 values correct (96%)** across 6 documents read. A value is correct when the figure as printed and its page match.

| Document | Country | Status | Correct | Wrong | Not found | Null items left empty | Time |
|---|---|---|---|---|---|---|---|
| us_colgate_10k_fy2025 | US | read | 16/16 | 0 | 0 | 0/2 | 0.4s |
| uk_rightmove_ara_2025 | GB | read | 16/16 | 0 | 0 | 2/2 | 1.9s |
| de_hoermann_gb_2025 | DE | read | 14/14 | 0 | 0 | 2/4 | 0.8s |
| es_ebro_foods_ccaa_2025 | ES | read | 16/16 | 0 | 0 | 2/2 | 1.5s |
| jp_ezaki_glico_yuho_fy2025 | JP | read | 14/16 | 2 | 0 | 0/2 | 0.5s |
| fr_vicat_esef_2025 | FR | read | 14/16 | 2 | 0 | 2/2 | 0.3s |

## Differences

**us_colgate_10k_fy2025**

- Returned for an item the manifest leaves empty: lt_debt FY2025: returned 6,871 (p. 0)
- Returned for an item the manifest leaves empty: lt_debt FY2024: returned 7,289 (p. 0)

**de_hoermann_gb_2025**

- Returned for an item the manifest leaves empty: lt_debt FY2025: returned 50.000 (p. 40)
- Returned for an item the manifest leaves empty: lt_debt FY2024: returned 50.000 (p. 40)

**jp_ezaki_glico_yuho_fy2025**

- Wrong: cash FY2025: got 68,631 p. 64, expected 64,737 p. 71
- Wrong: cash FY2024: got 60,243 p. 64, expected 56,610 p. 71
- Returned for an item the manifest leaves empty: lt_debt FY2025: returned 108 (p. 65)
- Returned for an item the manifest leaves empty: lt_debt FY2024: returned 155 (p. 65)

**fr_vicat_esef_2025**

- Wrong: ebit FY2025: got 444 768 p. 0, expected 479 849 p. 7.1.1 Comptes consolidés au 31 décembre 2025 > Compte de résultat consolidé
- Wrong: ebit FY2024: got 457 220 p. 0, expected 457 794 p. 7.1.1 Comptes consolidés au 31 décembre 2025 > Compte de résultat consolidé


Not found is the expected outcome for items the statements do not show on one line (the AI step searches the notes for those once a provider is connected). Every value still goes through the review screen.
