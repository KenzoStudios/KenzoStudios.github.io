# DealScout user guide

DealScout gives you a first-pass analysis of a company and an indicative acquisition price range. It runs on your
own computer: documents, figures and results stay in a local folder, and your AI provider key stays in your
operating system's keychain. Everything it produces is a screening estimate for internal use, not investment advice.

## 1. Start

1. Install the prerequisites in the [README](../README.md#prerequisites) (uv and Node.js; Tesseract and LibreOffice
   are optional).
2. Run `./start.sh` (macOS / Linux) or `.\start.ps1` (Windows). The first run takes a few minutes; your browser opens
   at http://127.0.0.1:8000.
3. Optional: **Connect AI** (left sidebar) and paste a key for Claude, OpenAI, Azure OpenAI, Gemini, xAI, Perplexity
   or any OpenAI-compatible endpoint (for example Ollama). DealScout works without AI: you type or paste figures
   and the rules-based reader still reads tables and tagged filings.

## 2. Create a deal

**New deal** asks for the company name, country, sector, reporting currency, valuation date, whether the company is
listed, and the buyer's perspective (financial sponsor or strategic buyer). The sector and perspective drive the
method suggestions later; you can edit them at any time with **Edit details**.

## 3. Add data

- **Documents tab:** upload annual reports, interim accounts, management accounts or filings (PDF, Excel, CSV, Word,
  HTML, SEC iXBRL, ESEF packages, XBRL, images). Tagged filings are read from their tags first. Scans need Tesseract
  or an AI provider that reads images.
- **Review tab:** every value found is shown next to its source with the location highlighted. Accept, correct or
  reject each one; values that differ between documents are flagged. Only accepted values reach the analysis.
- **Data tab:** a statement grid for typing or pasting figures, with live reconciliation checks and an Excel entry
  template. LTM columns are computed when interim periods are present.

## 4. Analyse

The **Analysis** tab shows growth, margins, returns, cash conversion, leverage and working-capital ratios with
trends; Altman Z, Piotroski F and Beneish M scores (Beneish is indicative); early warning signs with their
thresholds; and **one-off items**. Add one-offs yourself or click **Suggest with AI**: the AI proposes items with the
page they came from, every amount is checked against that page, and nothing changes until you tick **Confirmed**.
Switch on **Value on adjusted EBITDA and EBIT** to use the adjusted figures in the valuation.

## 5. Value

The **Valuation** tab has one sub-tab per method family. Each shows its result first and its inputs below; press
**Save and run** after editing.

| Sub-tab | What you enter | Notes |
|---|---|---|
| Acquisition price | Weights (optional), typical control premium (listed deals) | The suggested range, checks, rationale and data quality |
| Summary & DCF | Assumptions panel: growth, margins, WACC inputs, terminal value | Every default shows its source and date; peers for trading comps |
| LBO | Debt tranches (size, margin or fixed rate, amortisation), entry and exit, target IRR | Leverage and margins have no defaults: they are your financing terms |
| Precedents | Transactions with EV and metrics (or the multiple as reported) | Recency weighting and filters; values include control premia |
| NAV / SOTP | Assets and liabilities with revaluation method; segments with multiples | Deferred tax on gains, holding and conglomerate discounts |
| Financial institutions | Dividends, ROE path, P/TBV multiples, FCFE, APV | Weighted for banks and insurers only by default |
| Strategic | Synergies (phasing, integration costs, probability); acquirer figures | Strategic value is shown for reference; accretion/dilution EPS |
| Other | Liquidation recoveries, replacement costs, DLOM, market reference points | DLOM applies to private companies only |

Inputs DealScout cannot source (LBO leverage and margins, control premia, DLOM) are never filled in for you: a method
that needs them says what is missing.

## 6. Read the acquisition price

The **Acquisition price** sub-tab shows the suggested range for 100% of the equity and per share, the implied
EV/Revenue, EV/EBITDA and P/E, premia to market value and VWAP, and three checks: control premium against your
typical range, LBO affordability at the target IRR, and the share of synergies paid away. The **data quality score**
(0–100, grade A to D) reflects how confident the figures are, how many assumptions are company-specific rather than
defaults, and whether required inputs are missing.

The weighting table lists every method with its suitability (primary, secondary, reference, not suitable) and the
reason. Change a weight and press **Save weights and rerun**; the reset arrow returns it to the suggestion.

The **rationale** is standard wording until you press **Write with AI**. The AI writes the sentences; every number in
them is filled in by DealScout from the engine, and any sentence where the AI wrote a number itself is discarded.
When inputs change, the AI version is marked out of date until you rewrite it.

## 7. Export

- **Create Excel** (deal header, and in each deal's menu on the deals list): a workbook with a narrative Report tab,
  full Financials, the valuation summary, a live DCF model (change an assumption in Excel and the DCF, summary and
  report update), method tabs, every source value and the disclaimer. Each workbook is recalculated and checked for
  formula errors before download when LibreOffice is installed.
- **Export → PDF tear sheet / PowerPoint one-pager:** for sharing a summary.
- **Export → JSON deal file:** the whole deal (figures with their sources, every input, the results). **Import deal
  file** on the deals list recreates it and tells you whether the results were reproduced exactly.

## 8. Your data and privacy

- Data lives in your user data folder (shown in **Settings**); uploaded documents never leave your computer unless
  an AI provider is connected, and then only the pages needed are sent. **Settings** controls whether AI is used,
  how much of each document may be sent, and a monthly spend cap.
- Keys are stored in the operating system keychain; the browser only ever sees the last four characters.
- The server listens on 127.0.0.1 only and rejects requests from other sites.

## 9. Troubleshooting

| Symptom | What to do |
|---|---|
| A method says "needs more input" | The list under it names exactly what is missing |
| Scanned pages are listed for manual entry | Install Tesseract, or connect an AI provider that reads images |
| "Create Excel" says the workbook failed its checks | Report the message shown; the file is not offered while it has errors |
| AI calls fail | **Connect AI → Test connection** shows the provider's message; check the key, model and spend cap |
| The page can't reach the server | Make sure the terminal running `./start.sh` is still open |
