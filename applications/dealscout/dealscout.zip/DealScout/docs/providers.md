# AI providers

DealScout calls AI only through the provider-neutral interface in `ai/` (`dealscout_ai`). Every adapter is held to
the same contract tests (`ai/tests/test_contract.py`, recorded responses, no network): schema-checked JSON with one
retry on validation errors, typed errors (invalid key, out of credit, model unavailable, rate limited, unreachable,
refused, truncated), usage and estimated cost on every call, and a connection test.

Whatever the provider, **the AI never supplies a final number**: every figure it returns must be printed on a page that
was sent, DealScout parses the number itself, and the analyst accepts it on the review screen.

## Status in this release (checked against official documentation on 2026-11-20)

| Provider | Adapter | Default model | Structured output | Document input | Accuracy tier |
|---|---|---|---|---|---|
| Anthropic Claude | `providers/anthropic.py` | `claude-opus-5-5` | `output_config.format` JSON schema | Native PDF (cached) | untested |
| OpenAI | `providers/openai.py` (Responses API) | `gpt-6.2-sol` | `text.format` JSON schema, `strict: true` | Native PDF (`input_file`) | untested |
| Azure OpenAI | `providers/openai.py` (v1 API) | your deployment | same as OpenAI | Page text + page images (see below) | untested |
| Google Gemini | `providers/gemini.py` (`generateContent`) | `gemini-4-hydrogen` | `response_json_schema` | Native PDF (inline) | untested |
| xAI Grok | `providers/openai_compatible.py` (Responses API) | `grok-4.7` | `text.format` JSON schema, strict | Page text + page images | untested |
| Perplexity | `providers/openai_compatible.py` (Agent API) | `anthropic/claude-sonnet-5-5` | `response_format` JSON schema | Page text + page images | untested |
| Custom endpoint | `providers/custom.py` (Chat Completions) | your model | JSON schema → JSON mode → prompt-only | Page text (+ images for vision models) | untested |

"Untested" means no measured extraction accuracy yet; AI confidence is then scaled by the "untested" factor (0.85)
and every value still goes through review. The rules-only baseline (no AI) is in [accuracy.md](accuracy.md).

### Measuring a provider

The evaluation is a manual command because it makes live, billed calls with **your** keys (from the OS keychain or
`.env`, never printed):

```bash
uv run python scripts/fetch_fixtures.py                  # the public filings, once
uv run python scripts/provider_accuracy.py               # plan: providers with a key, documents, rough cost
uv run python scripts/provider_accuracy.py --yes --write # run them; store tiers and refresh the table below
```

Each provider is asked for the manifest's core items on the relevant pages (the same request the app makes for items
the statements don't show), so the score measures the AI, not the rules underneath. Answers are verified against the
pages as in the app. Tiers: **high** ≥ 95 % correct, **medium** ≥ 85 %, **limited** below (at least 20 values scored);
they are stored in `data/ai/provider_accuracy.json` and shown on the Connect AI screen.

<!-- accuracy:start -->

Not run yet in this repository — no provider has been measured.

<!-- accuracy:end -->

## Capability fallbacks

The extraction pipeline chooses what to send from each adapter's `capabilities()`:

1. **Native PDF** (Claude, OpenAI, Gemini): a slice of the relevant pages, with a note mapping slice page 1 to the
   source page so citations stay correct.
2. **Text + page images** (Azure OpenAI): the page text with `<page number="…">` markers plus a rendered image of each
   page. Azure deployment names hide the underlying model and only image-capable deployments accept PDF files, so the
   adapter declares `native_pdf = False`. This is the fallback path the brief asks to prove; it is covered by
   `test_azure_uses_v1_base_url_deployment_and_page_images_instead_of_pdf` and the pipeline tests that run on a
   provider without PDF input.
3. **Text only**: providers without vision get the page text with page markers.

Scanned pages without OCR text can only be read from their image. They are sent as page images to providers that read
images; a figure the AI reads there cannot be checked against text, so it is accepted only if the AI cites a scanned
page it was shown, capped at 0.5 confidence and flagged "check it on the image".

For **custom endpoints** the structured-output request steps down when the server rejects it: JSON schema, then JSON
mode (with the schema in the prompt), then prompt-only. The step that worked is remembered. Ollama silently ignores
modes it does not know, which is why every answer is validated against the same Pydantic schema regardless.

## Provider notes

**OpenAI.** Responses API with `store=False` (responses are not retained for later retrieval). Billing failures also
arrive as HTTP 429 (`insufficient_quota`, `credit_balance_exhausted`, spend limits); DealScout reports them as *out of
credit* and does not retry them like rate limits. A reasoning effort is sent only if configured.

**Azure OpenAI.** Uses the v1 data-plane API (`https://<resource>.openai.azure.com/openai/v1/`) with the plain OpenAI
client, so no API version is needed. Enter the endpoint, the deployment name and a key. Retired models answer
`410 Gone` (reported as *model unavailable*); prompts stopped by the content filter are reported as *refused*. The
model list shows your deployment, because `/openai/v1/models` lists Azure's catalogue, not your deployments.

**Google Gemini.** Uses `generateContent`, which Google still supports but now calls legacy in favour of the
Interactions API. It was chosen because its request and response are fully typed in `google-genai` 3.6; moving to the
Interactions API is a tracked follow-up. Keywords outside Gemini's schema subset are dropped silently by the API, so
answers are always validated against the Pydantic model. The SDK makes a single attempt unless retries are configured;
the adapter sets `retry_options` from the connection's retry count.

**xAI.** Responses API at `https://api.x.ai/v1` (Chat Completions is marked legacy). Inline PDFs are not accepted
(only uploaded files or URLs), so pages go as text plus images. xAI keeps API data 30 days for abuse checks and does
not train on it without permission; zero data retention is opt-in.

**Perplexity.** The Sonar Chat Completions API reached end of life on 2026-09-27. DealScout uses the Agent API
(`responses.create` at `https://api.perplexity.ai/v1`) with models named `provider/model`. No tools and no effort
preset are sent, so document reading never searches the web. The first request with a new schema can take
10–30 s. Out of credit is HTTP 402. The cost Perplexity reports with each response is recorded instead of an estimate.

**Custom endpoints.** Ollama (`http://localhost:11434/v1`), LM Studio (`http://localhost:1234/v1`), llama.cpp, vLLM or
a company gateway. No key is needed for local servers. Models whose names indicate vision (llava, qwen2.5vl, gemma3 …)
also get page images. A model on this computer is recorded at zero cost; a gateway's cost is unknown.

## Cost estimates

Prices live in `ai/src/dealscout_ai/pricing.py`, each with its source and fetch date. Unknown models show "cost
unknown" rather than a guess. Assumptions:

- Cached and cache-write tokens are counted inside the reported input tokens (OpenAI `input_tokens`, Gemini
  `prompt_token_count`) and billed at their own rates.
- Output includes reasoning/thinking tokens.
- `gemini-4-carbon` uses its standard price from 2026-12-01 (4.00 / 20.00 per M tokens), not the introductory price
  that runs to 2026-11-30.
- Azure prices are looked up by the model the deployment reports in each response (date suffix removed); the GPT-6.2
  family had no published Azure price on 2026-11-20.

Typical per-document costs will be published here after the Milestone 4 evaluation.

## Still unconfirmed in the official documentation (2026-11-20)

- xAI: the status code for exhausted prepaid credits (mapped from the message); whether 429s carry `Retry-After`.
- Perplexity: whether `text.format` is also honoured (the reference uses `response_format`, which DealScout sends).
- Ollama/LM Studio: whether `strict` is honoured (answers are validated either way).

- Whether OpenAI `input_tokens` / Gemini `prompt_token_count` include cached tokens (assumed yes).
- OpenAI's error code for an unknown model (mapped by HTTP 404).
- Azure GPT-6.2 prices and retirement dates; PDF input through Azure Chat Completions (not used).
- Which Gemini inline size limit applies to PDFs (20 MB or 50 MB); DealScout sends page slices well below both.
