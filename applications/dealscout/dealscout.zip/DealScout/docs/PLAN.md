# DealScout — Implementation plan

Source of truth: [`docs/BRIEF.md`](BRIEF.md). This file records how the brief is being built and the
assumptions taken where it left a choice open.

## Architecture

```
browser ──HTTP (127.0.0.1:8000)──▶ FastAPI (api/)
                                    ├─ serves the static Next.js export (web/out) + client-side routes
                                    ├─ /api/* JSON routes (deals, data, valuation, settings, jobs, exports)
                                    ├─ in-process job runner (SQLite job table, resumes on restart)
                                    ├─ extraction/  ──▶ ai/ (provider-neutral interface ▶ adapters)
                                    └─ engine/  (pure maths: no web, no AI, no I/O)
SQLite + documents + cache + exports live in the per-user app data folder (platformdirs), never in the repo.
```

Dependency direction (enforced by separate packages in one `uv` workspace):

| Package | Import name | May depend on | Must not depend on |
|---|---|---|---|
| `engine/` | `dealscout_engine` | numpy, pandas, pydantic, pyyaml | web, AI, DB, file formats |
| `ai/` | `dealscout_ai` | pydantic, httpx, official SDKs (`anthropic`, `openai`, `google-genai`), keyring | engine, DB |
| `extraction/` | `dealscout_extraction` | engine (taxonomy, number parsing), ai, PDF/Excel/HTML/XBRL libs | DB, web |
| `api/` | `dealscout_api` | everything above, FastAPI, SQLModel, exporters | — |

Key decisions:

- **Single process, single user.** FastAPI binds to `127.0.0.1` only; a middleware rejects any request whose
  `Host` or `Origin` is not localhost (DNS-rebinding / cross-site protection). No auth, no accounts.
- **Persistence:** SQLModel on one SQLite file; schema migrations with Alembic (batch mode for SQLite), run
  automatically at start-up so new GitHub releases upgrade the user's database in place.
- **Jobs:** a `job` table with per-step status JSON; a background thread pool runs them; on start-up any job left
  `running` is reset to `queued` and resumed. Extraction results are written per step, so nothing is lost on pause.
- **AI layer:** `AIProvider` protocol — `extract_structured`, `generate_text`, `test_connection`, `list_models`,
  each returning a `Usage` record (tokens, estimated cost). Capability flags per provider/model drive the
  content strategy (native PDF → text + page images → text only) and the structured-output strategy (strict
  schema → JSON + Pydantic validation + one retry with errors). Keys live in the OS keychain via `keyring`
  (fallback: a `0600` file in the app data folder, shown as such in Settings). Keys never reach the browser.
- **Frontend:** Next.js App Router, `output: 'export'` in production builds, served by FastAPI; deal pages are
  client-routed (`/deal?id=…`). Tailwind + shadcn/ui; TanStack Table for grids (custom keyboard editing and
  Excel paste — AG Grid Community lacks clipboard paste); ECharts for charts (native heatmap, boxplot,
  waterfall, scatter + regression); PDF.js for source highlighting.
- **Exports:** XlsxWriter (formatting control + native charts, formulas only, LibreOffice-safe functions),
  headless Chromium via Playwright for the PDF tear sheet (avoids WeasyPrint's Pango system dependency on
  Windows), python-pptx for the one-pager.
- **One palette** defined once in `data/design/palette.json` and consumed by the web theme, ECharts theme,
  Excel style module, PDF CSS and PPTX builder.

## Milestones (from §18) and what "done" means here

1. ✅ **Foundation** — workspace scaffold, `start`/`dev` scripts (sh + ps1), SQLite models + Alembic, deal CRUD,
   AI interface + Anthropic adapter, Connect AI screen (picker, keychain storage, test connection),
   taxonomy v1, engine skeleton, CI matrix (macOS/Windows/Linux), `CLAUDE.md`.
2. ✅ **Manual entry + core engine** — statement grid, reconciliation, ratios, DCF, comps, football field,
   summary; full Quick Scan from typed numbers; blank Excel entry template.
3. ✅ **Document ingestion v1** — PDF/Excel/CSV, tables, concept search, LLM mapping, review screen with
   highlighting, LTM; OpenAI, Azure OpenAI, Gemini adapters + capability fallbacks.
4. ✅ **Structured filings & OCR** — XBRL/iXBRL, OCR, multilingual synonyms, multi-document reconciliation;
   xAI, Perplexity, custom adapters; per-provider accuracy report.
5. ✅ **LBO, NAV/SOTP, precedents, FI methods, synergies** — plus liquidation, replacement cost, DLOM, market
   reference points, scores, red flags and AI-suggested one-off adjustments.
6. ✅ **Acquisition price module** — suitability, weights, recommendation, rationale prose, data quality score.
7. ✅ **Exports** — Create Excel (§14A), PDF, PPTX, JSON.
8. ✅ **Hardening and release.**

## Open questions (assumption taken in brackets — work continues on the assumption)

- Perplexity retired Sonar Chat Completions (2026-09-27). [Use its Agent API through `responses.create` with no tools,
  so extraction never searches the web; web-sourced peer suggestions come with the comps work in Milestone 5.]
- Which EBIT when a filing tags both "EBIT courant" (recurring) and reported operating profit? [Whatever matches the
  dictionary label, with both shown on the review screen; the user decides. Vicat's report is the example.]
- OCR engine. [Tesseract through PyMuPDF, optional as the brief says; an AI that reads images is the fallback, with
  image-only values capped at 0.5 confidence.]

- Where do one-off normalisation and the analysis scores (Altman Z, Beneish M, Piotroski) land? The brief does not
  assign them a milestone. [Milestone 5, with the other analysis methods.]
- Which Gemini API? Google now calls `generateContent` legacy in favour of the Interactions API. [`generateContent`
  for Milestone 3 because the SDK types it fully; move in a later milestone — see docs/providers.md.]
- Azure OpenAI PDF input? Deployment names hide the model, and only vision deployments accept PDFs. [Send page text
  plus page images; this is also the "no native PDF" fallback the brief asks to prove.]

1. **Licence** for the public GitHub release? [MIT, added in M8.]
2. **Provider keys for testing:** none are available in this build environment. [All adapters are verified with
   contract tests against recorded responses; `docs/providers.md` marks every provider "untested" until the
   live accuracy command is run with real keys.]
3. **Market defaults:** values are sourced from public datasets with an as-of date where they can be verified;
   anything not verifiable is a `null` placeholder listed in `DEFAULTS_TO_VERIFY.md`. [The engine refuses to use
   a placeholder silently — it asks the user for the value.]
4. **Fixture filings:** public filings are fetched by `scripts/fetch_fixtures.py`, not committed. [Synthetic
   fixtures that we author ourselves are committed so CI runs offline.]
5. **Locale:** number formatting follows the browser locale, fixed per deal once chosen. [Default `en-US`
   grouping with the deal currency code shown in every header.]
