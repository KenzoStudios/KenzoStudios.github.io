# DealScout — one start command (Windows PowerShell).
# Checks prerequisites, installs dependencies on first run, rebuilds the web app if it changed,
# then serves everything at http://127.0.0.1:8000 and opens your browser. Ctrl+C stops it.
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

$missing = $false
if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
    Write-Host "x uv is not installed (it manages Python and DealScout's Python packages). Install it with:"
    Write-Host "    winget install --id=astral-sh.uv -e"
    $missing = $true
}
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "x Node.js 20+ is not installed (needed to build the web interface). Install it with:"
    Write-Host "    winget install --id=OpenJS.NodeJS.LTS -e"
    $missing = $true
} else {
    $nodeMajor = [int](node -p "process.versions.node.split('.')[0]")
    if ($nodeMajor -lt 20) {
        Write-Host "x Node.js $nodeMajor found; DealScout needs Node.js 20 or newer:"
        Write-Host "    winget upgrade --id=OpenJS.NodeJS.LTS -e"
        $missing = $true
    }
}
if ($missing) {
    Write-Host "Install the missing prerequisites above (then open a new terminal), and run .\start.ps1 again."
    exit 1
}
if (-not (Get-Command tesseract -ErrorAction SilentlyContinue)) {
    Write-Host "i Optional: Tesseract is not installed, so scanned (image-only) pages can't be read."
    Write-Host "    winget install --id=UB-Mannheim.TesseractOCR -e"
}

Write-Host "-> Installing / checking Python dependencies (uv installs Python 3.12 automatically if needed)..."
uv sync --all-packages --frozen --quiet
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "-> Checking the web interface build..."
uv run --frozen python scripts/web_build.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$port = if ($env:DEALSCOUT_PORT) { $env:DEALSCOUT_PORT } else { "8000" }
Write-Host "-> Starting DealScout at http://127.0.0.1:$port  (Ctrl+C to stop)"
uv run --frozen dealscout
