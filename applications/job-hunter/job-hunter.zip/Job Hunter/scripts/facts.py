"""Reads profile/facts.md and checks text against it.

Used by autofill (suggested extra lines) and tailor_cv.py (tailored CV summaries). Two checks:
  dash_problems(text)  long dashes or a spaced hyphen used as a dash (the user's rule for anything written for him)
  untraceable(text)    words and figures that appear nowhere in facts.md or his CVs, so may be invented

  python3 scripts/facts.py "<text>"    # run both checks on a line and print what fails
"""
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
FACTS = ROOT / "profile" / "facts.md"

DASHES = {"—": "an em dash", "–": "an en dash", "‒": "a figure dash", "―": "a horizontal bar",
          "−": "a minus sign"}
# Words any sentence needs, which carry no claim of their own. Everything else must be found in facts.md or a CV.
GLUE = set("""
a an the and or nor but of in on at to for from by with without as into onto over under across through throughout
both also while where when who whom whose which that this these those it its is are was were be been being am
has have had having do does did i me my mine he him his she her they them their our we us you your
plus than then after before during within including such each every other any all some more most less least
very well so not no only just still yet up down out about around per via between among toward towards
can could would should will shall may might must one two three four five six seven eight nine ten
""".split())


def stem(w):
    w = w.lower().replace("’", "'").strip("'")
    w = re.sub(r"'s$", "", w)
    for suf in ("ations", "ation", "ings", "ing", "ers", "er", "ies", "ied", "ed", "es", "s", "ly"):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            return w[: -len(suf)]
    return w


WORD = re.compile(r"[A-Za-zÀ-ɏ][A-Za-zÀ-ɏ'’]*")
NUM = re.compile(r"\d+(?:[.,:]\d+)*")
AMP = re.compile(r"\b[A-Za-z]{1,4}&[A-Za-z]{1,4}\b")


def dash_problems(text):
    out = [f"contains {name}" for ch, name in DASHES.items() if ch in text]
    if re.search(r"\s-+\s|--", text) or re.search(r"(^|\s)-\s", text):
        out.append("uses a hyphen as a dash")
    return out


def facts_text():
    return FACTS.read_text() if FACTS.exists() else ""


def sections():
    """facts.md as {heading: [bullet, ...]}; continuation lines are joined onto their bullet."""
    out, cur = {}, None
    for line in facts_text().splitlines():
        if line.startswith("## "):
            cur = line[3:].strip()
            out[cur] = []
        elif cur is not None and line.startswith("- "):
            out[cur].append(line[2:].strip())
        elif cur is not None and line.startswith("  ") and out[cur]:
            out[cur][-1] += " " + line.strip()
    return out


def contact_block():
    """The letter header line in facts.md: 'London, England | (+44) ... | email | linkedin'."""
    sec = facts_text().split("## Contact block", 1)
    if len(sec) < 2:
        return ""
    for line in sec[1].splitlines()[1:]:
        if line.strip():
            return line.strip()
    return ""


class Corpus:
    """Every word stem and figure in facts.md and the CVs, for untraceable()."""

    def __init__(self, texts):
        joined = "\n".join(texts)
        self.stems = {stem(w) for w in WORD.findall(joined)}
        self.words = {w.lower().replace("’", "'") for w in WORD.findall(joined)}
        self.nums = set(NUM.findall(joined))
        self.raw = joined

    def untraceable(self, text):
        bad = [a for a in AMP.findall(text) if a not in self.raw]  # "M&A", "P&L": checked whole
        text = AMP.sub(" ", text)
        for n in NUM.findall(text):
            if n not in self.nums:
                bad.append(n)
        for w in WORD.findall(text):
            lw = w.lower().replace("’", "'")
            if lw in GLUE or lw in self.words or stem(lw) in self.stems:
                continue
            bad.append(w)
        return bad


def corpus(extra_texts=()):
    texts = [facts_text()]
    try:
        import cvparse
        for key in cvparse.cv_keys():
            p = cvparse.cv_path(key)
            if p:
                texts.append(cvparse.plain_text(p))
    except Exception:  # the CVs are a bonus; facts.md alone is enough to check against
        pass
    texts.extend(extra_texts)
    return Corpus(texts)


if __name__ == "__main__":
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
    line = " ".join(sys.argv[1:])
    if not line:
        sys.exit(__doc__)
    probs = dash_problems(line)
    bad = corpus().untraceable(line)
    if bad:
        probs.append("not found in facts.md or the CVs: " + ", ".join(bad))
    print("ok" if not probs else "\n".join(probs))
