"""The answer bank: ready answers for the free-text questions on application forms.

Two sources, both read by the browser extension's Questions group (through serve.py):
  profile/answers.json       standard answers, the same everywhere (availability, right to work, LinkedIn...)
  data/answers/<id>.json     answers for one role (why this firm, why this role, about you...), written by the daily
                             run from that role's cover letter spec (data/letters/<id>.json) and profile/facts.md

Every answer is checked before the extension sees it: no dashes, none of make_letter.py's banned phrases, every word
and figure traceable to facts.md, the CVs, or (for role answers) that role's letter and posting, a sensible length,
and never a salary, equal-opportunity, date-of-birth, "how did you hear" or consent question.

  python3 scripts/answers.py todo           # roles in To do or Interested without an answers file
  python3 scripts/answers.py check <id>     # check data/answers/<id>.json (exit 1 if anything fails)
  python3 scripts/answers.py check --all    # check every answers file and profile/answers.json
  python3 scripts/answers.py show <id>      # print what the extension would get for a role
"""
import json
import pathlib
import re
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import facts  # noqa: E402
import make_letter  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parent.parent
STANDARD = ROOT / "profile" / "answers.json"
DIR = ROOT / "data" / "answers"
LETTERS = ROOT / "data" / "letters"
JOBS = ROOT / "data" / "jobs.json"
KEYS = ("why_firm", "why_role", "about_you", "strength", "motivation", "other")
# (min, max) words for role answers
LENGTHS = {"why_firm": (120, 180), "why_role": (120, 180), "about_you": (100, 150), "strength": (60, 150),
           "motivation": (60, 150), "other": (30, 180)}
# Questions the bank never answers: the user does these himself.
NEVER = re.compile(r"salary|compensation|pay expect|remuneration|equal opportunit|diversity|gender|ethnic|\brace\b|"
                   r"disabilit|veteran|sexual|orientation|religio|date of birth|\bbirth|\bage\b|how did you (hear|find)|"
                   r"where did you (hear|find)|referr|consent|privacy|i agree|declar", re.I)
# Words application forms themselves use, which carry no claim about the user ("Yes", "sponsorship", a URL's "www").
FORM_WORDS = set("""yes no available availability sponsorship sponsor visa need needed require required www https http com
ireland eu european union relocate""".split())
# Questions each role answer is offered for, unless the file gives its own patterns. Regexes on the question label,
# case-insensitive, written so JavaScript can use them as they are.
DEFAULT_PATTERNS = {
    "why_firm": [r"why (do|would) you (want|like) to (work|join)", r"why (are you interested in|do you want to join) ",
                 r"what (attracts|interests|draws|excites) you (to|about) (us|our|the (firm|company|business|bank|team))",
                 r"why (us|this (firm|company|business|bank))\b", r"interest in (working (at|for|with) )?(us|our|the (firm|company))"],
    "why_role": [r"why (this|the) (role|position|job|opportunity)", r"why are you (interested in|applying for) (this|the) (role|position|job)",
                 r"what (interests|attracts|excites|draws) you (to|about) (this|the) (role|position|job|opportunity)",
                 r"why (are you|do you want to be) (a |an )?good fit", r"why have you applied"],
    "about_you": [r"tell us (a little |a bit |more )?about yourself", r"about you(rself)?\b", r"introduce yourself",
                  r"describe yourself", r"(personal|professional) (statement|summary)"],
    "strength": [r"(greatest|key|main|biggest) strength", r"what (would|can|will) you bring", r"why should we (hire|choose)",
                 r"what makes you (a strong|the right|suitable)"],
    "motivation": [r"motivat", r"what drives you", r"career (goals|aspirations|plans)", r"where do you see yourself"],
    "other": [],
}


# ---------------------------------------------------------------- reading
def _read(path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return None


def standard_raw():
    d = _read(STANDARD)
    if isinstance(d, dict):
        d = d.get("answers")
    return d if isinstance(d, list) else []


def role_raw(job_id):
    if not re.fullmatch(r"[0-9a-f]{6,20}", job_id or ""):
        return None
    return _read(DIR / f"{job_id}.json")


def job_record(job_id):
    d = _read(JOBS) or {}
    return next((j for j in d.get("jobs", []) if j.get("id") == job_id), None)


def role_sources(job_id, job=None):
    """Texts a role answer may draw on besides facts.md and the CVs: the role's letter spec, its posting, and the
    style guide's vocabulary."""
    out = [_style_words()]
    spec = _read(LETTERS / f"{job_id}.json") or {}
    out += spec.get("paragraphs") or []
    out += [s.get("claim", "") for s in spec.get("sources") or [] if isinstance(s, dict)]
    out += [spec.get("firm") or "", spec.get("role") or ""]
    job = job or job_record(job_id) or {}
    for k in ("firm", "title", "team", "sector", "location"):
        out.append(job.get(k) or "")
    out += job.get("posting_highlights") or []
    out += job.get("firm_facts") or []
    return [t for t in out if t]


def _style_words():
    """profile/style-guide.md: the register's own vocabulary ("keen", "drawn to", "I would relish", "strengths").
    It describes the user's experience in the same terms as facts.md, so it adds words, not claims."""
    try:
        return (ROOT / "profile" / "style-guide.md").read_text()
    except OSError:
        return ""


# ---------------------------------------------------------------- checking
_BASE = {}


def base_corpus():
    """facts.md and the CVs, cached until facts.md changes."""
    mt = facts.FACTS.stat().st_mtime if facts.FACTS.exists() else 0
    if _BASE.get("mt") != mt:
        _BASE.update(mt=mt, texts=[facts.facts_text()] + _cv_texts())
    return _BASE["texts"]


def _cv_texts():
    try:
        import cvparse
        return [cvparse.plain_text(p) for p in (cvparse.cv_path(k) for k in cvparse.cv_keys()) if p]
    except Exception:  # the CVs are a bonus; facts.md alone is enough to check against
        return []


def words(text):
    return len((text or "").split())


def problems(entry, corpus, role=True):
    """Why an answer can't be offered (an empty list if it can)."""
    out = []
    text = (entry.get("answer") or "").strip()
    key = entry.get("key") or ""
    if not text:
        return ["empty answer"]
    label = " ".join([key, entry.get("question") or ""] + list(entry.get("patterns") or []))
    if NEVER.search(label):
        out.append("a question the user always answers himself (salary, equal opportunities, date of birth, how you heard, consent)")
    out += facts.dash_problems(text)
    out += make_letter.phrase_problems(text)
    bad = [w for w in corpus.untraceable(text) if w.lower() not in FORM_WORDS]
    if bad:
        out.append("not found in facts.md, the CVs" + (", the letter or the posting" if role else "") + ": " +
                   ", ".join(dict.fromkeys(bad)))
    if role:
        if key not in KEYS:
            out.append(f"unknown key {key!r}")
        lo, hi = LENGTHS.get(key, (1, 400))
        n = words(text)
        if not lo <= n <= hi:
            out.append(f"is {n} words; {key} should be {lo} to {hi}")
    for p in entry.get("patterns") or []:
        try:
            re.compile(p)
        except re.error:
            out.append(f"pattern {p!r} is not a valid regex")
    return out


def check_role(job_id):
    """(ok answers, held back) for one role. Each ok answer gets its patterns, question and word count filled in."""
    d = role_raw(job_id)
    if not isinstance(d, dict):
        return [], []
    corpus = facts.Corpus(base_corpus() + role_sources(job_id))
    ok, held = [], []
    for e in d.get("answers") or []:
        if not isinstance(e, dict):
            continue
        e = dict(e)
        e["patterns"] = list(e.get("patterns") or DEFAULT_PATTERNS.get(e.get("key"), []))
        why = problems(e, corpus)
        if why:
            held.append({"key": e.get("key"), "question": e.get("question"), "why": "; ".join(why)})
        else:
            e["words"] = words(e["answer"])
            e.setdefault("kind", "long")
            ok.append(e)
    return ok, held


def locations():
    """The Locations section of profile/preferences.md (London, Dublin), for the relocation answer."""
    try:
        text = (ROOT / "profile" / "preferences.md").read_text()
    except OSError:
        return ""
    m = re.search(r"^## Locations\n(.*?)(?=^## )", text, re.M | re.S)
    return m.group(1) if m else ""


def check_standard():
    corpus = facts.Corpus(base_corpus() + [locations()])
    ok, held = [], []
    for e in standard_raw():
        if not isinstance(e, dict):
            continue
        why = problems(e, corpus, role=False)
        if why:
            held.append({"key": e.get("key"), "why": "; ".join(why)})
        else:
            ok.append(dict(e, kind=e.get("kind") or "short"))
    return ok, held


def bank(job_id):
    """What GET /api/answers/<id> returns."""
    std, std_held = check_standard()
    role, held = check_role(job_id) if job_id else ([], [])
    return {"standard": std, "role": role, "held_back": std_held + held}


def ready(job_id):
    return bool(re.fullmatch(r"[0-9a-f]{6,20}", job_id or "")) and (DIR / f"{job_id}.json").is_file()


def open_roles():
    d = _read(JOBS) or {}
    return [j for j in d.get("jobs", []) if (j.get("status") or "new") in ("new", "interested") and not j.get("vault")]


# ---------------------------------------------------------------- command line
def main():
    args = sys.argv[1:]
    cmd = args[0] if args else ""
    if cmd == "todo":
        todo = [j for j in open_roles() if not ready(j["id"])]
        for j in todo:
            letter = "letter spec ok" if (LETTERS / f"{j['id']}.json").exists() else "NO LETTER SPEC"
            print(f"{j['id']}  {letter:<15} {j['firm']} - {j['title']}")
        if not todo:
            print("every open role has answers")
    elif cmd == "check":
        every = args[1:2] == ["--all"]
        ids = [p.stem for p in sorted(DIR.glob("*.json"))] if every else args[1:2]
        if not ids and not every:
            sys.exit(__doc__)
        failed = 0
        if every:
            std, held = check_standard()
            print(f"profile/answers.json  {len(std)} standard answers ok")
            for h in held:
                failed += 1
                print(f"profile/answers.json  {h['key']}: {h['why']}")
        for i in ids:
            if role_raw(i) is None:
                print(f"{i}: no data/answers/{i}.json (or not valid JSON)")
                failed += 1
                continue
            ok, held = check_role(i)
            for e in ok:
                print(f"{i}  ok    {e['key']:<10} {e['words']:>3} words")
            for h in held:
                failed += 1
                print(f"{i}  HELD  {h['key']}: {h['why']}")
        sys.exit(1 if failed else 0)
    elif cmd == "show" and len(args) > 1:
        print(json.dumps(bank(args[1]), indent=2, ensure_ascii=False))
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
