"""Check whether tracked postings are still accepting applications, and manage the vault.

Roles you're still considering (status new or interested) are checked every day. A closed one moves to the vault:
it disappears from the dashboard but stays in data/jobs.json with `vault: true` and `closed_on`. Vaulted roles are
re-checked daily. If one reopens it comes back with `reopened_on`; if it stays closed for more than 30 days it
moves to data/expired.json. Roles you've applied to or passed on are never checked or vaulted.

  python3 scripts/postings.py auto            # check every due posting where the job board can be read reliably;
                                              # prints the ones that still need a manual check
  python3 scripts/postings.py set ID open     # record a manual check (open | closed)
  python3 scripts/postings.py expire          # move roles vaulted for more than 30 days to data/expired.json
  python3 scripts/postings.py list            # show what's due and what's in the vault
"""
import datetime
import json
import pathlib
import re
import sys
import urllib.error
import urllib.request

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import store  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parent.parent
JOBS = ROOT / "data" / "jobs.json"
EXPIRED = ROOT / "data" / "expired.json"
CHECKED = ("new", "interested")
VAULT_DAYS = 30
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
TODAY = datetime.date.today()


def load():
    return json.loads(JOBS.read_text())


def save(data):
    """Atomic (temp file, then rename); callers hold store.locked() so the server's writes aren't lost."""
    store.save(data, JOBS)


def due(data):
    return [j for j in data["jobs"] if (j.get("status") or "new") in CHECKED]


def fetch(url, accept="text/html"):
    """Return (status, body). Status 0 means the request failed outright."""
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": accept, "Accept-Language": "en-GB"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, ""
    except Exception:
        return 0, ""


def check(url):
    """'open', 'closed' or 'unknown' (needs a manual check)."""
    m = re.match(r"https?://(?:job-boards|boards)(?:\.eu)?\.greenhouse\.io/([^/]+)/jobs/(\d+)", url)
    if m:
        eu = ".eu" if ".eu." in url else ""
        code, _ = fetch(f"https://boards-api{eu}.greenhouse.io/v1/boards/{m[1]}/jobs/{m[2]}", "application/json")
        return {200: "open", 404: "closed"}.get(code, "unknown")
    m = re.match(r"https?://jobs\.ashbyhq\.com/([^/]+)/([0-9a-f-]{36})", url)
    if m:
        code, body = fetch(f"https://api.ashbyhq.com/posting-api/job-board/{m[1]}", "application/json")
        if code != 200:
            return "unknown"
        return "open" if m[2] in body else "closed"
    m = re.match(r"https?://jobs\.lever\.co/([^/]+)/([0-9a-f-]{36})", url)
    if m:
        code, _ = fetch(f"https://api.lever.co/v0/postings/{m[1]}/{m[2]}", "application/json")
        return {200: "open", 404: "closed"}.get(code, "unknown")
    m = re.match(r"https?://([^.]+)\.(wd\d+)\.myworkdayjobs\.com/(?:[a-z]{2}-[A-Z]{2}/)?([^/]+)/job/(.+?)/?$", url)
    if m:
        code, body = fetch(f"https://{m[1]}.{m[2]}.myworkdayjobs.com/wday/cxs/{m[1]}/{m[3]}/job/{m[4]}", "application/json")
        if code == 200 and '"jobPostingInfo"' in body:
            return "closed" if '"canApply":false' in body.replace(" ", "") else "open"
        if code in (404, 410):
            return "closed"
        return rendered(url)
    if "linkedin.com/jobs/view/" in url:
        # The public page keeps the applicant count after a job closes, so look for the Apply button itself.
        # LinkedIn's guest feed shows it only while the job takes applications ("Not currently accepting
        # applications" is only shown to signed-in users).
        jid = re.search(r"(\d{8,})", url)
        feed = f"https://www.linkedin.com/jobs-guest/jobs/api/jobPosting/{jid[1]}" if jid else url
        code, body = fetch(feed)
        if code in (404, 410):
            return "closed"
        if code == 200:
            low = body.lower()
            if re.search(r"(no longer|not currently) accepting applications", low):
                return "closed"
            if "top-card-layout__cta--primary" in low:
                return "open"
            if "top-card-layout__cta-container" in low:
                return "closed"
        return "unknown"
    code, body = fetch(url)
    if code in (404, 410):
        return "closed"
    if code == 200 and re.search(r"no longer (accepting|available)|position (has been )?filled|job (has )?expired", body, re.I):
        return "closed"
    return "unknown"


def rendered(url):
    """Load the page in Chrome for boards that only render client-side (Workday)."""
    import subprocess
    try:
        text = subprocess.run(["node", str(ROOT / "scripts/dev/pagetext.mjs"), url], capture_output=True, text=True,
                              timeout=90).stdout
    except Exception:
        return "unknown"
    if re.search(r"page you are looking for doesn.t exist|no longer (accepting|available)|job (has been )?(closed|filled)", text, re.I):
        return "closed"
    if re.search(r"\bApply\b", text) and len(text) > 400:
        return "open"
    return "unknown"


def apply(job, result):
    """Record a check result on a job and move it in or out of the vault. Returns a short description."""
    job["last_checked"] = TODAY.isoformat()
    if result == "closed":
        if not job.get("vault"):
            job["vault"] = True
            job["closed_on"] = TODAY.isoformat()
            return "closed: moved to the vault"
        return "still closed"
    if result == "open" and job.get("vault"):
        job["vault"] = False
        job.pop("closed_on", None)
        job["reopened_on"] = TODAY.isoformat()
        return "reopened: back on the dashboard"
    return result


def expire(data):
    keep, gone = [], []
    for j in data["jobs"]:
        closed = j.get("closed_on")
        if j.get("vault") and closed and (TODAY - datetime.date.fromisoformat(closed)).days > VAULT_DAYS:
            gone.append(j)
        else:
            keep.append(j)
    if gone:
        old = json.loads(EXPIRED.read_text()) if EXPIRED.exists() else []
        store.write_json(EXPIRED, old + gone)
        data["jobs"] = keep
    return gone


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "list"
    data = load()
    if cmd == "auto":
        # The checks take minutes, so they run without the lock; the results are then applied to a fresh read of
        # jobs.json, so a status the user set on the dashboard meanwhile is kept.
        manual, results = [], {}
        for j in due(data):
            r = check(j["url"])
            if r == "unknown":
                manual.append(j)
            else:
                results[j["id"]] = r
        with store.locked(JOBS):
            data = load()
            for j in due(data):
                if j["id"] in results:
                    r = results[j["id"]]
                    print(f"{j['id']}  {r:<6}  {apply(j, r):<32} {j['firm']} - {j['title']}")
            save(data)
        if manual:
            print("\nCheck these by hand (open the posting and look for an open application), then record each with "
                  "`python3 scripts/postings.py set ID open|closed`:")
            for j in manual:
                print(f"{j['id']}  {'(vault) ' if j.get('vault') else ''}{j['firm']} - {j['title']}\n            {j['url']}")
    elif cmd in ("set", "expire"):
        with store.locked(JOBS):
            locked_cmd(cmd, load())
    elif cmd == "list":
        for j in due(data):
            tag = f"vault since {j['closed_on']}" if j.get("vault") else "on dashboard"
            print(f"{j['id']}  {tag:<22} last checked {j.get('last_checked', 'never'):<10}  {j['firm']} - {j['title']}")
    else:
        sys.exit(__doc__)


def locked_cmd(cmd, data):
    if cmd == "set":
        job_id, result = sys.argv[2], sys.argv[3]
        if result not in ("open", "closed"):
            sys.exit("result must be open or closed")
        for j in data["jobs"]:
            if j["id"] == job_id:
                if (j.get("status") or "new") not in CHECKED:
                    sys.exit(f"{job_id} is {j['status']}; applied and passed roles are not checked")
                print(apply(j, result))
                save(data)
                return
        sys.exit(f"unknown id {job_id}")
    elif cmd == "expire":
        gone = expire(data)
        save(data)
        for j in gone:
            print(f"expired after {VAULT_DAYS} days in the vault: {j['firm']} - {j['title']}")
        if not gone:
            print("nothing to expire")


if __name__ == "__main__":
    main()
