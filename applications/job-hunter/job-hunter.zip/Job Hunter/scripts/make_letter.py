"""Turn a letter spec into a ready-to-attach .docx and .pdf in letters/.

Usage: python3 scripts/make_letter.py data/letters/<job-id>.json
Spec fields: firm, role, city, paragraphs (list of str); optional date, salutation.
Prints the two output paths (relative to the project root).
"""
import datetime
import json
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import user  # noqa: E402

NAME = user.name()  # from profile/user.json (the setup window)
CONTACT = user.contact_line()
PDF_BIN = ROOT / "scripts" / ".bin" / "letter_pdf"


def safe(s):
    return re.sub(r"[^\w&' -]+", "", s).strip()


def pdf_tool():
    src = ROOT / "scripts" / "letter_pdf.swift"
    if not PDF_BIN.exists() or PDF_BIN.stat().st_mtime < src.stat().st_mtime:
        PDF_BIN.parent.mkdir(exist_ok=True)
        subprocess.run(["swiftc", "-O", str(src), "-o", str(PDF_BIN)], check=True)
    return PDF_BIN


BANNED = [
    "i am writing to express", "i am writing to apply", "i'm writing to express", "passionate", "delve", "tapestry",
    "testament to", "in today's", "fast-paced world", "ever-evolving", "synergy", "leverage my", "esteemed",
    "dynamic team", "unique blend", "align perfectly", "aligns perfectly", "perfect fit", "i am confident that",
    "i believe i would be a great", "thrilled to", "eager to contribute", "look no further", "furthermore",
    "moreover", "additionally,", "in conclusion", "not only", "seamless", "cutting-edge", "game-changer",
    "navigate the complexities", "invaluable", "honed", "spearhead", "foster", "robust",
    "genuinely", "really", "took that as a sign", "doing something right", "when i care", "if i care",
    # casual register (the user, 19 Oct 2026)
    "truly", "honestly", "absolutely", "incredibly", "enormously", "hugely", "massively", "super ", "amazing",
    "awesome", "fantastic", "wonderful", "brilliant", "fascinated", "fascinating", "thrilled", "delighted", "dream",
    "i'll admit", "to be honest", "to be straightforward", "pretty simple", "a fair few", "a bit ", "a lot of",
    "lots of", "plenty of", "kind of", "sort of", "stuff", "sort it out", "sorting things out", "picked up the phone",
    "the buck stopped", "earn their keep", "earning their keep", "haggle", " fun", "nice ", "glad", "happy to",
    "whenever suits", "free to start", "get stuck in", "hit the ground running", "no-brainer", "at the end of the day",
    "quiet compliment", "chuffed", "keen as", "great ",
]


def phrase_problems(text):
    """Long dashes, a spaced hyphen used as a dash, stock AI phrasing and casual words. Also used by answers.py."""
    problems = []
    for ch, name in (("\u2014", "em dash"), ("\u2013", "en dash")):
        if ch in text:
            problems.append(f"contains an {name}")
    if " - " in text:
        problems.append("uses a spaced hyphen as a dash; rewrite the sentence")
    low = text.lower()
    for b in BANNED:
        pat = r"(?<![\w'])" + re.escape(b.strip()) + r"(?![\w'])"
        if b.strip() in ("kind of", "sort of"):
            pat = r"(?<!the )(?<!this )(?<!that )(?<!what )" + pat  # "the kind of role" is fine; the hedge isn't
        if b.strip() == "great":
            pat += r"(?! deal)"
        if re.search(pat, low):
            problems.append(f'uses "{b.strip()}"')
    if re.search(r"\blov(e|ed|es|ing)\b", low):
        problems.append('uses "love"; use professional words such as "keen" or "drawn to"')
    return problems


def lint(paragraphs):
    """Refuse letters with long dashes or stock AI phrasing; warn on odd length."""
    text = " ".join(paragraphs)
    problems = phrase_problems(text)
    words = len(text.split())
    if not 500 <= words <= 640:
        problems.append(f"is {words} words; aim for 520-620 so it fills the page")
    if problems:
        sys.exit("Letter rejected: " + "; ".join(problems))
    return words


def main(spec_path):
    from docx import Document  # here, so answers.py and serve.py can use the phrase checks without python-docx
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Cm, Pt

    spec = json.loads(pathlib.Path(spec_path).read_text())
    words = lint(spec["paragraphs"])
    date = spec.get("date") or datetime.date.today().strftime("%-d %B %Y")
    full = {
        "name": NAME,
        "contact": CONTACT,
        "date": date,
        "re": f"Re: {spec['role']}, {spec['firm']} ({spec['city']})",
        "salutation": spec.get("salutation") or "Dear Hiring Team,",
        "paragraphs": spec["paragraphs"],
        "signoff": "Best,",
    }
    out_dir = ROOT / "letters"
    out_dir.mkdir(exist_ok=True)
    base = out_dir / f"{NAME} - Cover Letter {safe(spec['firm'])} {safe(spec['role'])}"[:180]

    tmp = ROOT / "data" / f".spec-{pathlib.Path(spec_path).stem}.json"
    tmp.write_text(json.dumps(full))
    pdf_path = base.with_suffix(".pdf")
    out = subprocess.run([str(pdf_tool()), str(tmp), str(pdf_path)], check=True, capture_output=True, text=True).stdout
    size = float(re.search(r"size=([\d.]+)", out).group(1))
    fill = float(re.search(r"fill=([\d.]+)", out).group(1))
    tmp.unlink()
    doc = Document()
    sec = doc.sections[0]
    sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
    for side in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
        setattr(sec, side, Cm(2.2))
    normal = doc.styles["Normal"]
    normal.font.name, normal.font.size = "Arial", Pt(size)

    def add(text, size=size, bold=False, after=6, justify=False):
        p = doc.add_paragraph()
        r = p.add_run(text)
        r.bold, r.font.size = bold, Pt(size)
        p.paragraph_format.space_after = Pt(after)
        if justify:
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        return p

    add(full["name"], size + 5.5, True, 2)
    add(full["contact"], size - 1, after=14)
    add(full["date"], after=2)
    add(full["re"], bold=True, after=12)
    add(full["salutation"], after=8)
    for para in full["paragraphs"]:
        add(para, after=8, justify=True)
    add(full["signoff"], after=2)
    add(full["name"], after=0)
    docx_path = base.with_suffix(".docx")
    doc.save(docx_path)

    print(docx_path.relative_to(ROOT))
    print(pdf_path.relative_to(ROOT))
    print(f"{words} words, {size:.2f}pt, page {fill:.0%} full")


if __name__ == "__main__":
    main(sys.argv[1])
