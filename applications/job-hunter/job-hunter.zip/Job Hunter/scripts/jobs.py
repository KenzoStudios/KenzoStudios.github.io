"""Helpers for data/jobs.json.

  python3 scripts/jobs.py seen                 # print firm | title | url | status of every tracked job (to skip repeats)
  python3 scripts/jobs.py add picks.json       # merge new picks in, give them ids, print the ids
  python3 scripts/jobs.py set-letter ID DOCX PDF   # attach letter file names to a job
  python3 scripts/jobs.py run "note"           # record that a search run happened today
"""
import datetime
import hashlib
import json
import pathlib
import re
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import store  # noqa: E402
import user  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parent.parent
JOBS = ROOT / "data" / "jobs.json"
CV_FOR_SECTOR = {
    "Asset management / PE": "CV Asset Management",
    "Consulting": "CV Consulting",
    "Tech sales": "CV Tech",
    "Business development": "CV Tech",
    "Startups & GTM": "CV Tech",
}


def load():
    return store.load(JOBS)


def save(data):
    """Atomic (temp file, then rename); callers hold store.locked() so the server's writes aren't lost."""
    store.save(data, JOBS)


def norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def key(job):
    return norm(job["firm"]) + "|" + norm(job["title"]) + "|" + norm(job.get("location", "").split(",")[0])


def main():
    with store.locked(JOBS):
        run(sys.argv[1] if len(sys.argv) > 1 else "")


def run(cmd):
    data = load()
    today = datetime.date.today().isoformat()
    if cmd == "seen":
        for j in data["jobs"]:
            print(f"{j['firm']} | {j['title']} | {j['url']} | {j.get('status', 'new')}")
    elif cmd == "add":
        picks = json.loads(pathlib.Path(sys.argv[2]).read_text())
        urls = {j["url"] for j in data["jobs"]}
        keys = {key(j) for j in data["jobs"]}
        for p in picks:
            if re.search(r"\.pdf($|[?#])", p["url"], re.I) and not p.get("apply_email"):
                print("skip (link is a PDF, not a posting; use the careers or application page, or set apply_email):",
                      p["firm"], "-", p["title"])
                continue
            if p["url"] in urls or key(p) in keys:
                print("skip (already tracked):", p["firm"], "-", p["title"])
                continue
            p["id"] = hashlib.sha1(p["url"].encode()).hexdigest()[:10]
            if not p.get("cv"):
                p["cv"] = CV_FOR_SECTOR.get(p["sector"]) if p["sector"] in CV_FOR_SECTOR and not user.industries() else user.default_cv(p["sector"])
                if p["sector"] == "Business development" and p.get("in_financial_services"):
                    p["cv"] = "CV Asset Management"
            p.setdefault("status", "new")
            p["found_on"] = today
            data["jobs"].append(p)
            urls.add(p["url"])
            keys.add(key(p))
            print(p["id"], p["cv"], "|", p["firm"], "-", p["title"])
        save(data)
    elif cmd == "set-letter":
        job_id, docx, pdf = sys.argv[2:5]
        for j in data["jobs"]:
            if j["id"] == job_id:
                j["letter_docx"] = pathlib.Path(docx).name
                j["letter_pdf"] = pathlib.Path(pdf).name
                save(data)
                return
        sys.exit(f"unknown job id {job_id}")
    elif cmd == "run":
        data["runs"].append({"date": today, "note": sys.argv[2] if len(sys.argv) > 2 else ""})
        save(data)
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
