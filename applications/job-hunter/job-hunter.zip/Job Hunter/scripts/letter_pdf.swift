// Renders a cover letter JSON spec to a one-page A4 PDF with CoreText.
// Usage: letter_pdf <spec.json> <out.pdf>
import Foundation
import CoreText
import CoreGraphics
import AppKit

struct Spec: Decodable {
    let name: String
    let contact: String
    let date: String
    let re: String
    let salutation: String
    let paragraphs: [String]
    let signoff: String
}

let args = CommandLine.arguments
guard args.count == 3 else { fputs("usage: letter_pdf spec.json out.pdf\n", stderr); exit(2) }
let spec = try JSONDecoder().decode(Spec.self, from: Data(contentsOf: URL(fileURLWithPath: args[1])))

let pageW: CGFloat = 595.28, pageH: CGFloat = 841.89
let margin: CGFloat = 62
var bodySize: CGFloat = 10.5

func font(_ name: String, _ size: CGFloat) -> CTFont { CTFontCreateWithName(name as CFString, size, nil) }

func para(_ text: String, _ f: CTFont, spacingAfter: CGFloat, align: NSTextAlignment = .justified) -> NSAttributedString {
    let style = NSMutableParagraphStyle()
    style.alignment = align
    style.paragraphSpacing = spacingAfter
    style.lineHeightMultiple = 1.08
    return NSAttributedString(string: text + "\n", attributes: [.font: f as NSFont, .paragraphStyle: style])
}

func build(_ size: CGFloat) -> NSAttributedString {
    let s = NSMutableAttributedString()
    let reg = font("Helvetica", size), bold = font("Helvetica-Bold", size)
    s.append(para(spec.name, font("Helvetica-Bold", size + 6), spacingAfter: 2, align: .left))
    s.append(para(spec.contact, font("Helvetica", size - 1), spacingAfter: size * 1.6, align: .left))
    s.append(para(spec.date, reg, spacingAfter: 2, align: .left))
    s.append(para(spec.re, bold, spacingAfter: size * 1.2, align: .left))
    s.append(para(spec.salutation, reg, spacingAfter: size * 0.8, align: .left))
    for p in spec.paragraphs { s.append(para(p, reg, spacingAfter: size * 0.8)) }
    s.append(para(spec.signoff, reg, spacingAfter: 2, align: .left))
    s.append(para(spec.name, reg, spacingAfter: 0, align: .left))
    return s
}

// Pick the largest body size (9 to 11.5pt) that still fits on one page, so a letter fills the page.
let frameRect = CGRect(x: margin, y: margin, width: pageW - 2 * margin, height: pageH - 2 * margin)
func height(_ t: NSAttributedString) -> CGFloat {
    let fs = CTFramesetterCreateWithAttributedString(t as CFAttributedString)
    return CTFramesetterSuggestFrameSizeWithConstraints(fs, CFRange(location: 0, length: 0), nil,
        CGSize(width: frameRect.width, height: .greatestFiniteMagnitude), nil).height
}
bodySize = 11.5
var text = build(bodySize)
while bodySize > 9 && height(text) > frameRect.height {
    bodySize -= 0.25
    text = build(bodySize)
}
let fill = height(text) / frameRect.height
print(String(format: "size=%.2f fill=%.2f", bodySize, fill))

var box = CGRect(x: 0, y: 0, width: pageW, height: pageH)
let info = [kCGPDFContextTitle as String: spec.re, kCGPDFContextAuthor as String: spec.name] as CFDictionary
guard let ctx = CGContext(URL(fileURLWithPath: args[2]) as CFURL, mediaBox: &box, info) else { exit(1) }
ctx.beginPDFPage(nil)
let fs = CTFramesetterCreateWithAttributedString(text as CFAttributedString)
let frame = CTFramesetterCreateFrame(fs, CFRange(location: 0, length: 0), CGPath(rect: frameRect, transform: nil), nil)
CTFrameDraw(frame, ctx)
ctx.endPDFPage()
ctx.closePDF()
