"""Safe writes to data/jobs.json, shared by serve.py, jobs.py, postings.py and tracker.py.

The dashboard server and the daily run's scripts all write data/jobs.json. Two rules keep it whole:
  atomic_write(path, text)   writes a temporary file next to it, then renames it over the original, so a reader
                             never sees half a file and a crash never leaves one behind
  locked()                   one writer at a time, across threads and processes (an flock on data/.jobs.lock);
                             read, change and save inside it so nobody's change is lost

  with store.locked():
      data = store.load()
      ...change data...
      store.save(data)
"""
import contextlib
import fcntl
import json
import os
import pathlib
import tempfile
import threading

ROOT = pathlib.Path(__file__).resolve().parent.parent
JOBS = ROOT / "data" / "jobs.json"
_THREAD_LOCK = threading.RLock()
_held = threading.local()


def atomic_write(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        if path.exists():
            os.chmod(tmp, path.stat().st_mode & 0o777)
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def write_json(path, data):
    atomic_write(path, json.dumps(data, indent=2, ensure_ascii=False))


@contextlib.contextmanager
def locked(jobs=None):
    """Hold the jobs.json write lock (re-entrant within a thread)."""
    jobs = pathlib.Path(jobs or JOBS)
    with _THREAD_LOCK:
        depth = getattr(_held, "depth", 0)
        if depth:
            _held.depth = depth + 1
            try:
                yield
            finally:
                _held.depth -= 1
            return
        jobs.parent.mkdir(parents=True, exist_ok=True)
        with open(jobs.parent / ".jobs.lock", "a") as lf:
            fcntl.flock(lf, fcntl.LOCK_EX)
            _held.depth = 1
            try:
                yield
            finally:
                _held.depth = 0
                fcntl.flock(lf, fcntl.LOCK_UN)


def load(jobs=None):
    jobs = pathlib.Path(jobs or JOBS)
    return json.loads(jobs.read_text()) if jobs.exists() else {"jobs": [], "runs": []}


def save(data, jobs=None):
    write_json(jobs or JOBS, data)
