"""Go through every firm in profile/firms.json and list its open London and Dublin roles that might suit the user.

Firms on Greenhouse, Lever, Ashby, SmartRecruiters, Workday, Oracle, Jibe, Pinpoint,
Teamtailor, Rippling, BambooHR, Yello and Oleeo are read through their public job APIs, so nothing is
missed because a search engine didn't index it. Firms on other systems are listed for a manual look, oldest check first.
A firm entry may carry "titles", a regex that replaces the sector's title filter (Accenture lists hundreds of IT roles,
so it keeps only strategy ones). Roles already tracked in data/jobs.json, roles needing another language and plainly wrong roles (engineering, legal,
senior titles, internships) are filtered out. The result is a shortlist to read and verify, not a set of picks.

  python3 scripts/sweep.py                    # sweep every firm; writes data/sweep.json and data/coverage.json
  python3 scripts/sweep.py --sector Consulting   # one sector only
  python3 scripts/sweep.py --firm "AlphaSights"  # one firm only (handy when adding a firm)
  python3 scripts/sweep.py checked "L.E.K. Consulting" 3   # record a manual check of a page-only firm (3 roles kept)
"""
import concurrent.futures
import datetime
import json
import pathlib
import re
import sys
import urllib.error
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent.parent
FIRMS = ROOT / "profile" / "firms.json"
JOBS = ROOT / "data" / "jobs.json"
OUT = ROOT / "data" / "sweep.json"
COVERAGE = ROOT / "data" / "coverage.json"
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
TODAY = datetime.date.today()
MAX_AGE_DAYS = 45  # postings older than this are dropped; RUN.md asks for ~30 days, the margin allows for refreshed dates

sys.path.insert(0, str(ROOT / "scripts"))
import user  # noqa: E402

# Where to look: the cities in profile/user.json ("locations"), else London and Dublin.
_PLACES = [c.strip() for c in user.details().get("locations") or [] if isinstance(c, str) and c.strip()]
CITIES = re.compile(r"\b(" + "|".join(re.escape(c.lower()) for c in _PLACES) + r")\b", re.I) if _PLACES else \
    re.compile(r"\b(london|dublin)\b", re.I)
# Dublin OH and London ON: only a worry when the cities are London and Dublin.
ELSEWHERE = re.compile(r"\b(ohio|oh|ca|united states|usa|ontario|sydney|australia)\b", re.I) if not _PLACES or \
    {c.lower() for c in _PLACES} <= {"london", "dublin"} else re.compile(r"(?!x)x")
# For industries the user typed in (not the built-in five below): only internships and the like are always dropped.
# The /job-hunter-setup skill can give an industry its own "titles" (keep) and "exclude" (drop) patterns.
BASIC_NEVER = re.compile(r"\b(intern|internship|summer|apprentice|work experience|spring week)\b", re.I)
INDUSTRIES = {i["name"]: i for i in user.industries()}
# Titles that are never right for him, whatever the firm.
NEVER = re.compile(
    r"\b(engineer|engineering|developer|devops|architect|scientist|designer|counsel|lawyer|legal|paralegal|accountant|"
    r"accounting|tax|audit|payroll|compliance|aml|kyc|risk|controller|treasury|recruit\w*|talent|actuar\w*|copywriter|"
    r"receivable|data science|design|researcher|product (analyst|owner)|systems|sox|freight|hr|human resources|"
    r"people partner|office manager|receptionist|assistant|secretary|facilities|it support|cyber|security|"
    r"intern|internship|industrial placement|summer|apprentice|work experience|insight|spring week|"
    r"vice president|vp|director|head of|managing|principal|partner(?!ship)|senior manager|lead|chief|md|staff|"
    r"marketing|auditor|trading|trader|m&a|"
    # seller titles that ask for 5+ years of closing
    r"sales manager|manager, sales|strategic account|enterprise account|senior account|sales specialist|"
    r"(senior|sr\.?) [\w ]*(manager|leader|executive)|sales leader)\b", re.I)
# Language roles: "German Speaker", "Bilingual", or a title written in another language.
LANGUAGE = re.compile(r"\b(?!english)\w+ speak(er|ing)\b|\bbilingual\b|\bnative\b|\bfluent\b|\bfrancophone\b|associ[ée]\(?e?\)?,|"
                      r"\bfluen(t|cy)\b|\b(french|german|italian|spanish|portuguese|polish|dutch|arabic|danish|swedish|norwegian|"
                      r"finnish|hebrew|nordic|nordics|dach|switzerland|austria|africa|mena|benelux|iberia|italy|france|germany|spain|israel|saudi|mea|"
                      r"south africa|cee|central eastern europe)\b", re.I)
# Role words worth reading, per sector. Consulting firms hire generalists, so their entry titles are kept broadly.
WANT = {
    "Asset management / PE": r"investor relations|\bir\b|client|distribution|product (specialist|strateg|manage)|fundrais|"
                             r"capital (raising|formation|markets)|business development|sales|relationship|partnership|"
                             r"wealth|private (client|bank)|\blp\b|institutional|placement|coverage",
    "Consulting": r"consultant|associate|analyst|client service|business development|research|strategy|graduate|"
                  r"sales|account|partnership",
    "Tech sales": r"account (executive|manager|development)|\bae\b|sales|\bsdr\b|\bbdr\b|business development|partner|"
                  r"customer success|solutions|client|relationship|go.to.market|\bgtm\b|commercial|growth",
    "Business development": r"business development|partnership|commercial|growth|strategy|origination|sales|"
                            r"relationship|client|account|corporate development|associate|analyst",
    "Startups & GTM": r"go.to.market|\bgtm\b|business operations|biz ?ops|strateg(y|ic)|operations associate|"
                      r"founder.?s? associate|chief of staff|partnership|account (executive|manager|development)|\bae\b|"
                      r"sales|\bsdr\b|\bbdr\b|commercial|revenue|growth|solutions|customer success|business development|"
                      r"deployment strateg|associate|analyst",
}


def fetch(url, data=None, accept="application/json"):
    """Return (status, parsed JSON or None). Status 0 means the request failed outright."""
    headers = {"User-Agent": UA, "Accept": accept, "Accept-Language": "en-GB"}
    body = None
    if data is not None:
        body = json.dumps(data).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            return r.status, json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        return e.code, None
    except Exception:
        return 0, None


def iso(value):
    """Turn the various date shapes the boards use into YYYY-MM-DD, or None."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return datetime.date.fromtimestamp(value / 1000).isoformat()
    m = re.match(r"\d{4}-\d{2}-\d{2}", str(value))
    if m:
        return m[0]
    m = re.search(r"(\d+)\+? days? ago", str(value), re.I)  # Workday: "Posted 3 Days Ago", "Posted 30+ Days Ago"
    if m:
        return (TODAY - datetime.timedelta(days=int(m[1]))).isoformat()
    if re.search(r"today", str(value), re.I):
        return TODAY.isoformat()
    if re.search(r"yesterday", str(value), re.I):
        return (TODAY - datetime.timedelta(days=1)).isoformat()
    return None


# ------------------------------------------------------------------ one reader per job board

def greenhouse(f):
    # EU boards (job-boards.eu.greenhouse.io) are served by the main API host too; the EU API host doesn't answer.
    code, d = fetch(f"https://boards-api.greenhouse.io/v1/boards/{f['slug']}/jobs")
    if code != 200 or not d:
        return None
    return [{"title": j["title"], "location": j["location"]["name"], "url": j["absolute_url"],
             "posted": iso(j.get("updated_at") or j.get("first_published"))} for j in d["jobs"]]


def lever(f):
    host = "api.eu.lever.co" if f.get("eu") else "api.lever.co"
    code, d = fetch(f"https://{host}/v0/postings/{f['slug']}?mode=json")
    if code != 200 or d is None:
        return None
    out = []
    for j in d:
        cat = j.get("categories") or {}
        locs = [cat.get("location") or ""] + list(cat.get("allLocations") or [])
        out.append({"title": j["text"], "location": " / ".join(x for x in dict.fromkeys(locs) if x),
                    "url": j["hostedUrl"], "posted": iso(j.get("createdAt"))})
    return out


def ashby(f):
    code, d = fetch(f"https://api.ashbyhq.com/posting-api/job-board/{f['slug']}")
    if code != 200 or not d:
        return None
    out = []
    for j in d.get("jobs", []):
        if j.get("isListed") is False:
            continue
        locs = [j.get("location") or ""] + [s.get("location", "") for s in j.get("secondaryLocations") or []]
        out.append({"title": j["title"], "location": " / ".join(x for x in locs if x), "url": j["jobUrl"],
                    "posted": iso(j.get("publishedAt"))})
    return out


def smartrecruiters(f):
    out, offset = [], 0
    while offset < 1000:
        code, d = fetch(f"https://api.smartrecruiters.com/v1/companies/{f['slug']}/postings?limit=100&offset={offset}")
        if code != 200 or not d:
            return out or None
        for j in d.get("content", []):
            loc = j.get("location") or {}
            out.append({"title": j["name"], "location": ", ".join(x for x in (loc.get("city"), loc.get("country")) if x),
                        "url": f"https://jobs.smartrecruiters.com/{f['slug']}/{j['id']}", "posted": iso(j.get("releasedDate"))})
        offset += 100
        if offset >= d.get("totalFound", 0):
            return out


def workday_facets(api):
    """Find the location filter values for London and Dublin, as {facetParameter: [ids]}."""
    code, d = fetch(api, {"limit": 1, "offset": 0, "searchText": "", "appliedFacets": {}})
    if code != 200 or not d:
        return None
    found = {}

    def walk(facets):
        for fa in facets:
            for v in fa.get("values", []):
                if "facetParameter" in v:
                    walk([v])
                elif "location" in fa.get("facetParameter", "").lower() and CITIES.search(v.get("descriptor") or ""):
                    found.setdefault(fa["facetParameter"], []).append(v["id"])
    walk(d.get("facets", []))
    return found


def workday(f):
    base = f"https://{f['tenant']}.{f['wd']}.myworkdayjobs.com"
    api = f"{base}/wday/cxs/{f['tenant']}/{f['site']}/jobs"
    facets = workday_facets(api)
    if facets is None:
        return None
    # Filter by office where the board offers it; otherwise search the city names.
    queries = [("", {k: v}) for k, v in facets.items()] or [("London", {}), ("Dublin", {})]
    out, seen = [], set()
    for text, applied in queries:
        offset, total = 0, 0
        while offset < 1000:
            code, d = fetch(api, {"limit": 20, "offset": offset, "searchText": text, "appliedFacets": applied})
            if code != 200 or not d:
                break
            for j in d.get("jobPostings", []):
                path = j.get("externalPath", "")
                if not path or path in seen:
                    continue
                seen.add(path)
                loc = j.get("locationsText") or ""
                where = text or "London or Dublin"  # the office filter or city search already placed it there
                if re.match(r"\d+ Locations", loc):
                    loc = f"{where} (one of {loc.lower()})"
                elif not CITIES.search(loc):
                    loc = f"{where} ({loc})" if loc else where
                out.append({"title": j.get("title", ""), "location": loc, "url": f"{base}/{f['site']}{path}",
                            "posted": iso(j.get("postedOn"))})
            total = total or d.get("total", 0)  # Workday only reports the total on the first page
            offset += 20
            if offset >= total:
                break
    return out


def jibe(f):
    """iCIMS Jibe career sites (ZS, MSCI, Allvue): slug is the site's host name."""
    out = []
    for city in ("London", "Dublin"):
        code, d = fetch(f"https://{f['slug']}/api/jobs?location={city}&limit=100")
        if code != 200 or not d:
            return out or None
        for j in (x["data"] for x in d.get("jobs", [])):
            out.append({"title": j["title"].strip(), "location": j.get("full_location") or j.get("city") or "",
                        "url": f"https://{f['slug']}/jobs/{j['slug']}", "posted": iso(j.get("posted_date"))})
    return list({j["url"]: j for j in out}.values())


def pinpoint(f):
    """Pinpoint career sites (CIL): slug is the site's host name."""
    code, d = fetch(f"https://{f['slug']}/postings.json")
    if code != 200 or not d:
        return None
    return [{"title": j["title"], "location": (j.get("location") or {}).get("city") or "", "url": j["url"],
             "posted": None, "deadline": iso(j.get("deadline_at"))} for j in d.get("data", [])]


def teamtailor(f):
    """Teamtailor career sites (Oxera), read from their RSS feed."""
    import email.utils
    import xml.etree.ElementTree as ET
    req = urllib.request.Request(f"https://{f['slug']}.teamtailor.com/jobs.rss", headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            root = ET.fromstring(r.read())
    except Exception:
        return None
    ns = {"tt": "https://teamtailor.com/locations"}
    out = []
    for it in root.iter("item"):
        when = it.findtext("pubDate")
        out.append({"title": it.findtext("title") or "", "url": it.findtext("link") or "",
                    "location": " / ".join(c.text or "" for c in it.findall(".//tt:city", ns)),
                    "posted": email.utils.parsedate_to_datetime(when).date().isoformat() if when else None})
    return out


def rippling(f):
    out, page = [], 0
    while page < 20:
        code, d = fetch(f"https://ats.rippling.com/api/v2/board/{f['slug']}/jobs?page={page}&pageSize=100")
        if code != 200 or not d:
            return out or None
        for j in d.get("items", []):
            out.append({"title": j["name"], "location": " / ".join(l.get("name", "") for l in j.get("locations") or []),
                        "url": j["url"], "posted": None})
        page += 1
        if page >= d.get("totalPages", 0):
            break
    merged = {}
    for j in out:  # the board lists a role once per office
        if j["url"] in merged:
            merged[j["url"]]["location"] += " / " + j["location"]
        else:
            merged[j["url"]] = j
    return list(merged.values())


def oracle(f):
    """Oracle Recruiting Cloud (J.P. Morgan, Schroders, Lazard, Jefferies): slug is the host, site the siteNumber."""
    out = {}
    for city in ("London", "Dublin"):
        offset = 0
        while offset < 600:
            code, d = fetch(f"https://{f['slug']}/hcmRestApi/resources/latest/recruitingCEJobRequisitions?onlyData=true"
                            f"&expand=requisitionList.secondaryLocations&finder=findReqs;siteNumber={f['site']},"
                            f"limit=25,offset={offset},keyword={city}")
            if code != 200 or not d or not d.get("items"):
                if not out and city == "London":
                    return None
                break
            reqs = d["items"][0].get("requisitionList") or []
            for r in reqs:
                locs = [r.get("PrimaryLocation") or ""] + [x.get("Name", "") for x in r.get("secondaryLocations") or []]
                out[r["Id"]] = {"title": r["Title"], "location": " / ".join(x for x in locs if x), "posted": iso(r.get("PostedDate")),
                                "url": f"https://{f['slug']}/hcmUI/CandidateExperience/en/sites/{f['site']}/job/{r['Id']}"}
            offset += 25
            if offset >= d["items"][0].get("TotalJobsCount", 0) or not reqs:
                break
    return list(out.values())


def bamboohr(f):
    code, d = fetch(f"https://{f['slug']}.bamboohr.com/careers/list")
    if code != 200 or not d:
        return None
    return [{"title": j["jobOpeningName"], "location": (j.get("location") or {}).get("city") or "", "posted": None,
             "url": f"https://{f['slug']}.bamboohr.com/careers/{j['id']}"} for j in d.get("result", [])]


def page_text(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "text/html, */*", "X-Requested-With": "XMLHttpRequest"})
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            return r.read().decode("utf-8", "replace")
    except Exception:
        return None


def yello(f):
    """Yello / Recsolu boards (Kearney): slug is the host, board the job_board id. Results come 25 a page as JSON-wrapped HTML."""
    import html as h
    out = []
    for page in range(1, 30):
        body = page_text(f"https://{f['slug']}/job_boards/{f['board']}/search?page_number={page}")
        if body is None:
            return out or None
        try:
            chunk = json.loads(body).get("html", "")
        except ValueError:
            return out or None
        rows = re.findall(r'req_title"[^>]*href="([^"]+)">(.*?)</a><div>(.*?)</div>.*?post-time[^>]*>([^<]*)<', chunk, re.S)
        if not rows:
            break
        more = json.loads(body).get("more_requisitions")
        for href, title, spans, age in rows:
            parts = [h.unescape(x).strip() for x in re.findall(r"<span>(.*?)</span>", spans)]
            m = re.match(r"(\d+)([dwmy])", age.strip())
            days = int(m[1]) * {"d": 1, "w": 7, "m": 30, "y": 365}[m[2]] if m else None
            out.append({"title": h.unescape(title).strip(), "location": parts[-1] if parts else "",
                        "url": f"https://{f['slug']}{href}",
                        "posted": (TODAY - datetime.timedelta(days=days)).isoformat() if days is not None else None})
        if not more:
            break
    return out


def oleeo(f):
    """Oleeo / tal.net boards (L.E.K., Evercore): read the listing pages in "boards". The office is in the title."""
    import html as h
    out = {}
    for url in f["boards"]:
        body = page_text(url)
        if body is None:
            return None
        for href, title in re.findall(r'<a[^>]+href="([^"]*/opp/\d+[^"]*)"[^>]*>(.*?)</a>', body, re.S):
            title = h.unescape(re.sub(r"<[^>]+>", "", title)).strip()
            out[href] = {"title": title, "location": title, "url": h.unescape(href), "posted": None}
    return list(out.values())


READERS = {"greenhouse": greenhouse, "lever": lever, "ashby": ashby, "smartrecruiters": smartrecruiters, "workday": workday,
           "jibe": jibe, "pinpoint": pinpoint, "teamtailor": teamtailor, "rippling": rippling, "oracle": oracle,
           "bamboohr": bamboohr, "yello": yello, "oleeo": oleeo}


# ------------------------------------------------------------------ filtering

def norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def tracked():
    data = json.loads(JOBS.read_text()) if JOBS.exists() else {"jobs": []}
    urls = {j["url"] for j in data["jobs"]}
    names = {norm(j["firm"].split("(")[0]) + "|" + norm(j["title"]) for j in data["jobs"]}
    ids = {m[0] for j in data["jobs"] for m in [re.search(r"\d{7,}", j["url"])] if m}  # same posting, different URL shape
    return urls, names, ids


def keep(f, job, seen):
    """Return None to keep the role, or the reason it was dropped."""
    urls, names, ids = seen
    title = job["title"].strip()
    places = [x for x in re.split(r" / |;", job["location"] or "") if CITIES.search(x) and not ELSEWHERE.search(x)]
    if not places:
        return "location"
    m = re.search(r"\d{7,}", job["url"])
    if job["url"] in urls or norm(f["firm"].split("(")[0]) + "|" + norm(title) in names or (m and m[0] in ids):
        return "tracked"
    if LANGUAGE.search(title):
        return "language"
    ind = INDUSTRIES.get(f["sector"], {})
    never = re.compile(ind["exclude"], re.I) if ind.get("exclude") else NEVER if f["sector"] in WANT else BASIC_NEVER
    if never.search(title) or re.match(r"placement\b", title, re.I):  # a "Placement, ..." title is a year-long internship
        return "role"
    want = f.get("titles") or ind.get("titles") or WANT.get(f["sector"]) or "."
    if not re.search(want, title, re.I):  # a firm can narrow its own titles
        return "role"
    # Graduate and class-of-2027 intakes stay open for months, so their age says nothing; only the date matters elsewhere.
    intake = re.search(r"\b20(2[7-9])\b|graduate|january|class of|new grad|entry.level", title, re.I)
    if not intake and job.get("posted") and (TODAY - datetime.date.fromisoformat(job["posted"])).days > MAX_AGE_DAYS:
        return "old"
    return None


def sweep(f, seen):
    reader = READERS.get(f.get("ats"))
    if not reader:
        return f, None, []
    try:
        jobs = reader(f)
    except Exception:
        jobs = None
    if jobs is None:
        return f, "failed", []
    kept = []
    for j in jobs:
        if keep(f, j, seen) is None:
            kept.append({"firm": f["firm"], "sector": f["sector"], **j})
    return f, len(jobs), kept


def main():
    args = sys.argv[1:]
    coverage = json.loads(COVERAGE.read_text()) if COVERAGE.exists() else {}
    if args[:1] == ["checked"]:
        coverage[args[1]] = {"checked": TODAY.isoformat(), "method": "manual", "kept": int(args[2]) if len(args) > 2 else None}
        COVERAGE.write_text(json.dumps(coverage, indent=2, ensure_ascii=False))
        return print(f"Recorded a manual check of {args[1]}.")
    firms = json.loads(FIRMS.read_text())
    if "--sector" in args:
        firms = [f for f in firms if f["sector"] == args[args.index("--sector") + 1]]
    if "--firm" in args:
        firms = [f for f in firms if norm(f["firm"]) == norm(args[args.index("--firm") + 1])]
    seen = tracked()

    results, manual, failed = [], [], []
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        for f, total, kept in pool.map(lambda f: sweep(f, seen), firms):
            if total is None:
                manual.append(f)
                continue
            if total == "failed":
                failed.append(f)
                continue
            coverage[f["firm"]] = {"checked": TODAY.isoformat(), "method": f["ats"], "listed": total, "kept": len(kept)}
            results.extend(kept)

    order = {s: i for i, s in enumerate(list(INDUSTRIES) + [w for w in WANT if w not in INDUSTRIES])}
    results.sort(key=lambda j: (order.get(j["sector"], 99), j["firm"], j["title"]))
    last = lambda f: (coverage.get(f["firm"]) or {}).get("checked") or "0000"
    manual.sort(key=last)
    OUT.write_text(json.dumps({"date": TODAY.isoformat(), "roles": results,
                               "manual": [{"firm": f["firm"], "sector": f["sector"], "url": f.get("url"),
                                           "last_checked": last(f) if last(f) != "0000" else None} for f in manual],
                               "failed": [f["firm"] for f in failed]}, indent=2, ensure_ascii=False))
    COVERAGE.write_text(json.dumps(coverage, indent=2, ensure_ascii=False))

    sector = None
    for j in results:
        if j["sector"] != sector:
            sector = j["sector"]
            print(f"\n## {sector}")
        print(f"- {j['firm']} | {j['title']} | {j['location']} | posted {j.get('posted') or '?'} | {j['url']}")
    print(f"\n{len(results)} roles to read across {len(firms) - len(manual) - len(failed)} firms read through their job boards.")
    if failed:
        print("Board didn't answer (check by hand): " + ", ".join(f["firm"] for f in failed))
    if manual:
        print(f"\n{len(manual)} firms need a look on their own careers page, oldest check first:")
        for f in manual:
            print(f"- {f['firm']} ({f['sector']}), last checked {last(f) if last(f) != '0000' else 'never'}: {f.get('url')}")
    print(f"\nSaved to {OUT.relative_to(ROOT)}.")


if __name__ == "__main__":
    main()
