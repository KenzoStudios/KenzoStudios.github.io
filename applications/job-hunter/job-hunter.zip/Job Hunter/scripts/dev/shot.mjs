// Screenshot a page for design review.
// node scripts/dev/shot.mjs <url> <out.png> [--w 1440] [--h 900] [--dark] [--webkit] [--full] [--click "<css selector>"]... [--wait 600]
// --click may repeat; each click runs in order before the shot. Prints console errors.
import { chromium, webkit } from 'playwright-core';
const a = process.argv.slice(2);
const url = a[0], out = a[1];
const opt = (k, d) => { const i = a.indexOf(k); return i >= 0 ? a[i + 1] : d; };
const clicks = a.flatMap((v, i) => (v === '--click' ? [a[i + 1]] : []));
const engine = a.includes('--webkit') ? webkit : chromium;
const browser = await engine.launch();
const page = await browser.newPage({
  viewport: { width: +opt('--w', 1440), height: +opt('--h', 900) },
  colorScheme: a.includes('--dark') ? 'dark' : 'light',
  deviceScaleFactor: +(process.env.DPR||1),
});
const errors = [];
page.on('console', m => m.type() === 'error' && errors.push(m.text()));
page.on('pageerror', e => errors.push(String(e)));
await page.goto(url, { waitUntil: 'networkidle' });
await page.waitForTimeout(+opt('--wait', 600));
for (const sel of clicks) { await page.click(sel); await page.waitForTimeout(400); }
await page.screenshot({ path: out, fullPage: a.includes('--full') });
console.log('saved', out, errors.length ? '\nconsole errors:\n' + errors.join('\n') : '(no console errors)');
await browser.close();
