// Print the rendered text of a page (for job boards that only render in a browser, e.g. Workday).
// Usage: node scripts/dev/pagetext.mjs <url>
import { chromium } from './node_modules/playwright-core/index.mjs';
const b = await chromium.launch({ channel: 'chrome' });
const p = await b.newPage();
try { await p.goto(process.argv[2], { waitUntil: 'networkidle', timeout: 45000 }); } catch (e) {}
await p.waitForTimeout(2500);
console.log((await p.evaluate(() => document.body.innerText)).replace(/\s+/g, ' '));
await b.close();
