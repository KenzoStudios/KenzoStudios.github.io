// Print a local HTML file to PDF with headless Chrome, using the page's own @page size and margins.
// Usage: node scripts/dev/print_pdf.mjs <in.html> <out.pdf>   (prints "pages=<n>")
import { chromium } from './node_modules/playwright-core/index.mjs';
import { pathToFileURL } from 'node:url';
import { readFileSync } from 'node:fs';
const [inp, out] = process.argv.slice(2);
const b = await chromium.launch({ channel: 'chrome' });
const p = await b.newPage();
await p.goto(pathToFileURL(inp).href, { waitUntil: 'load' });
await p.pdf({ path: out, preferCSSPageSize: true, printBackground: true });
await b.close();
const pages = (readFileSync(out, 'latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
console.log('pages=' + pages);
