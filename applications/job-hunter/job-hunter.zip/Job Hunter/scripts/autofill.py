"""What the browser extension needs to fill an application form for one role. Used by serve.py.

  match(url, jobs, active)  which tracked role an application page belongs to
  payload(job, how)         the role, profile fields, CV entries, suggested extra lines and files

  python3 scripts/autofill.py <page url>     # show which role a page matches and the extras it would offer
  python3 scripts/autofill.py --id <job id>  # print the full payload for a role
  python3 scripts/autofill.py --employment [CV key]  # the employment entries autofill uses (after employment.json)

Reads data/jobs.json, profile/facts.md and the CVs; writes nothing. Extra lines come from
data/autofill/<id>.json when the daily run wrote one, otherwise from facts.md matched to the posting.
"""
import json
import math
import pathlib
import re
import sys
import time
import urllib.parse

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import cvparse  # noqa: E402
import facts  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parent.parent
JOBS = ROOT / "data" / "jobs.json"
AUTOFILL_DIR = ROOT / "data" / "autofill"
EMPLOYMENT = ROOT / "profile" / "employment.json"  # corrections to the CV's employment entries (read first)
TAILORED_DIR = ROOT / "data" / "tailored"
CVS_DIR = ROOT / "cvs"
LETTERS = ROOT / "letters"
ACTIVE_FOR = 2 * 60 * 60  # an Apply click counts for two hours
# Job boards that host many firms: the firm is the first part of the path, not the host.
SHARED_HOSTS = re.compile(r"(^|\.)(greenhouse\.io|lever\.co|ashbyhq\.com|smartrecruiters\.com|linkedin\.com|"
                          r"workable\.com|pinpointhq\.com|teamtailor\.com|recruitee\.com|bamboohr\.com)$")
UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I)
STOP = set("""a an the and or of in on at to for from by with as into across over our your their its is are be will you
we they this that these those who what which work working team teams role roles help support including client clients
across within new more most other per each such than then also day days year years strong experience ability skills
""".split())


# ---------------------------------------------------------------- matching
def load_jobs():
    return json.loads(JOBS.read_text()).get("jobs", []) if JOBS.exists() else []


def norm_url(u):
    """Comparable form of a URL: no scheme, www, query, fragment, trailing slash or apply suffix."""
    try:
        p = urllib.parse.urlsplit(u.strip())
    except ValueError:
        return ""
    host = (p.hostname or "").lower()
    host = host[4:] if host.startswith("www.") else host
    path = re.sub(r"/+$", "", p.path)
    path = re.sub(r"/(apply|application|applymanually|autofillwithresume|useMyLastApplication|confirmation|"
                  r"thank-?you|thanks|submitted|success)(/.*)?$", "", path, flags=re.I)
    return host + path.lower()


def ats_ids(u):
    """Posting ids in a URL: Greenhouse numbers, Lever/Ashby UUIDs, Workday requisitions, and the like."""
    out = set()
    try:
        p = urllib.parse.urlsplit(u)
    except ValueError:
        return out
    q = urllib.parse.parse_qs(p.query)
    for k in ("gh_jid", "token", "jobId", "job_id", "jobid", "currentJobId", "jid", "id"):
        for v in q.get(k, []):
            if re.fullmatch(r"[\w-]{5,}", v):
                out.add(v.lower())
    out.update(m.lower() for m in UUID.findall(p.path))
    for m in re.findall(r"/jobs?/(\d{5,})", p.path):
        out.add(m)
    m = re.search(r"_((?:[A-Z]{1,3}[-_]?)?\d{3,}(?:-\d+)?)(?:/|$)", p.path)  # Workday: ..._R2052751 or _JR7603-1
    if m:
        out.add(m.group(1).lower())
        out.add(re.sub(r"-\d+$", "", m.group(1).lower()))
    m = re.search(r"/view/(?:[\w-]*-)?(\d{8,})", p.path)  # LinkedIn
    if m:
        out.add(m.group(1))
    m = re.search(r"smartrecruiters\.com/[^/]+/(\d{6,})", u)
    if m:
        out.add(m.group(1))
    return out


def site_key(u):
    try:
        p = urllib.parse.urlsplit(u)
    except ValueError:
        return ""
    host = (p.hostname or "").lower()
    host = host[4:] if host.startswith("www.") else host
    if SHARED_HOSTS.search(host):
        parts = [x for x in p.path.split("/") if x]
        if parts and parts[0] == "embed":  # boards.greenhouse.io/embed/job_app?for=<firm>
            firm = urllib.parse.parse_qs(p.query).get("for", [""])[0]
            return host + "/" + firm.lower()
        return host + "/" + (parts[0].lower() if parts else "")
    return host


def match(url, jobs, active=None):
    """(job, how, candidates). how: url | ats | site | active | none."""
    live = [j for j in jobs if not j.get("vault")]
    want = norm_url(url)
    if want:
        for j in live:
            if norm_url(j.get("url", "")) == want:
                return j, "url", []
    ids = ats_ids(url)
    if ids:
        for j in live:
            if ids & ats_ids(j.get("url", "")):
                return j, "ats", []
    act = None
    if active and time.time() - active.get("at", 0) < ACTIVE_FOR:
        act = next((j for j in live if j["id"] == active.get("id")), None)
    key = site_key(url)
    same = [j for j in live if key and site_key(j.get("url", "")) == key]
    if act and act in same:
        return act, "active", []
    if len(same) == 1:
        return same[0], "site", []
    if act:
        return act, "active", same
    return None, "none", same


# ---------------------------------------------------------------- profile
def _phone(raw):
    digits = re.sub(r"\D", "", raw)
    if digits.startswith("44"):
        nat = "0" + digits[2:]
        return "+44 " + digits[2:6] + " " + digits[6:], nat[:5] + " " + nat[5:], "+44"
    return raw, raw, ""


ADDR = {}


def fields(cv):
    global ADDR
    try:
        ADDR = json.loads((ROOT / "profile" / "address.json").read_text())
    except (OSError, ValueError):
        ADDR = {}
    """The single-value form fields, in the order the panel lists them."""
    c = cv.get("contact", {})
    block = facts.contact_block()  # facts.md is the source of truth for contact details
    parts = [x.strip() for x in block.split("|")] if block else []
    location = parts[0] if parts else c.get("location", "")
    email = next((x for x in parts if "@" in x), c.get("email", ""))
    phone_raw = next((x for x in parts if re.search(r"\d{4}", x) and "@" not in x), c.get("phone", ""))
    link = next((x for x in parts if "linkedin" in x), "")
    linkedin = ("https://www." + link) if link and not link.startswith("http") else (link or c.get("linkedin", ""))
    phone, phone_nat, code = _phone(phone_raw)
    name = cv.get("name", "")
    first, _, last = name.partition(" ")
    city = ADDR.get("city") or location.split(",")[0].strip()
    rtw = " ".join(cv.get("right_to_work", [])).lower()
    uk = "uk citizenship" in rtw or "british" in facts.facts_text().lower()
    irish = "irish" in rtw
    edu = (education(cv) or [{}])[0]
    history = work_history(experience(cv))
    out = [
        ("first_name", "First name", "Contact", first, True),
        ("last_name", "Last name", "Contact", last, True),
        ("full_name", "Full name", "Contact", name, True),
        ("preferred_name", "Preferred name", "Contact", first, True),
        ("email", "Email", "Contact", email, True),
        ("phone", "Phone", "Contact", phone, True),
        ("phone_national", "Phone (UK format)", "Contact", phone_nat, False),
        ("phone_code", "Country code", "Contact", code, True),
        ("linkedin", "LinkedIn", "Contact", linkedin, True),
        ("address_line1", "Address", "Address", ADDR.get("line1", ""), True),
        ("address_line2", "Address line 2", "Address", ADDR.get("line2", ""), bool(ADDR.get("line2"))),
        ("town", "Town", "Address", ADDR.get("town", ""), True),
        ("county", "County", "Address", ADDR.get("county", ""), True),
        ("postcode", "Postcode", "Address", ADDR.get("postcode", ""), True),
        ("location", "Location", "Location and right to work", location, True),
        ("city", "City", "Location and right to work", city, True),
        ("country", "Country", "Location and right to work", "United Kingdom" if "england" in location.lower()
         or "london" in location.lower() else "", True),
        ("work_auth_uk", "Right to work, UK", "Location and right to work", "Yes" if uk else "", True),
        ("work_auth_ie", "Right to work, EU", "Location and right to work", "Yes" if irish else "",
         True),
        ("sponsorship", "Visa sponsorship", "Location and right to work", "No" if uk else "", True),
        ("work_limited", "Time-limited permission", "Location and right to work", "No" if uk else "", True),
        ("citizenship", "Citizenship", "Location and right to work",
         " and ".join(x for x, ok in (("British", uk), ("Irish", irish)) if ok), True),
        ("start_date", "Earliest start", "Location and right to work", "January 2027", True),
        ("over_18", "Aged 18 or over", "Location and right to work", "Yes" if "25 years old" in facts.facts_text() else "",
         True),
        ("school", "School", "Education", edu.get("school", ""), True),
        ("degree", "Degree", "Education", edu.get("degree", ""), True),
        ("degree_level", "Degree type", "Education", edu.get("level", ""), True),
        ("field", "Field of study", "Education", edu.get("field", ""), True),
        ("grade", "Grade", "Education", edu.get("grade", ""), True),
        ("graduation", "Graduation", "Education", ((edu.get("end") or {}).get("text") or ""), True),
        ("work_history", "Work history", "Experience", history, True),
        ("current_company", "Current company", "Experience", edu.get("school", ""), False),
        ("current_title", "Current title", "Experience", "Master's student", False),
    ]
    extra = {
        # dates in a form the extension can write as dd/mm/yyyy, yyyy-mm-dd, a month list and so on
        "start_date": {"date": {"year": 2027, "month": 1, "day": 1, "text": "January 2027"}},
        "graduation": {"date": dict(edu.get("end") or {}, day=1)} if (edu.get("end") or {}).get("year") else {},
        "grade": {"alts": edu.get("grade_names", []), "numeric": edu.get("gpa") or edu.get("points") or ""},
    }
    return [dict({"key": k, "label": l, "group": g, "value": v, "default": d}, **extra.get(k, {}))
            for k, l, g, v, d in out if v]


# UK degree classifications, as application forms list them
CLASSES = {
    "1st": ["First-Class Honours", "First Class Honours", "First", "1st"],
    "2:1": ["Upper Second-Class Honours", "Upper Second", "Second Class Honours (Upper Division)", "2:1", "2.1", "2i"],
    "2:2": ["Lower Second-Class Honours", "Lower Second", "Second Class Honours (Lower Division)", "(2:2)", "2:2",
            "2.2", "2ii"],
    "3rd": ["Third-Class Honours", "Third Class Honours", "Third", "3rd"],
}


def _user_name():
    import user
    return user.name()


def education(cv):
    """The CV's education entries with their grades in the forms application forms ask for: the classification of a
    UK degree (written out as forms list it), a GPA (with "in progress" and the expected date where the CV says so) and
    IB points. Everything comes from the CV's own lines; facts.md has the same."""
    out = []
    for e in cv.get("education", []):
        e = dict(e)
        cls = e.get("classification")
        if cls:
            key = {"first": "1st", "1st": "1st"}.get(cls.lower(), cls)
            e["grade"] = cls
            e["grade_names"] = CLASSES.get(key, [cls])
        gpa = re.match(r"(\d\.\d+)\s*GPA", e.get("grade") or "")
        if gpa:
            e["gpa"] = gpa.group(1)
            e["grade_names"] = [e["grade"], gpa.group(1)]
        pts = re.match(r"(\d+)\s*points", e.get("grade") or "", re.I)
        if pts:
            e["points"] = pts.group(1)
            e["grade_names"] = list(dict.fromkeys([e["grade"], pts.group(1) + " points", pts.group(1)]))
        e["status"] = "In progress" if e.get("current") else "Completed"
        if e.get("current") and (e.get("end") or {}).get("year"):
            e["expected"] = e["end"]
        out.append(e)
    return out


def employment_overrides():
    try:
        d = json.loads(EMPLOYMENT.read_text())
        return [e for e in d.get("employers", []) if isinstance(e, dict) and e.get("roles")]
    except (OSError, ValueError):
        return []


def _split_employer(e, o):
    """The CV entry e for one employer, as the roles profile/employment.json gives it. Bullets are the CV's own;
    a bullet matching a 'replace' pattern is swapped for its facts.md wording, then each goes to the role whose
    patterns it matches (or the "rest" role)."""
    bullets = []
    for b in e.get("bullets", []):
        for r in o.get("replace", []):
            if re.search(r["pattern"], b, re.I):
                b = r["with"]
                break
        if b not in bullets:
            bullets.append(b)
    roles, taken = [], set()
    for role in o["roles"]:
        pats = role.get("bullets_matching")
        mine = [] if pats == "rest" else [b for b in bullets if any(re.search(p, b, re.I) for p in pats or [])]
        taken.update(mine)
        roles.append((role, mine))
    out = []
    for role, mine in roles:
        if role.get("bullets_matching") == "rest":
            mine = [b for b in bullets if b not in taken]
        x = {k: v for k, v in e.items() if k not in ("bullets", "dates")}
        x.update(title=role["title"], start=role["start"], end=role["end"], bullets=mine, current=False,
                 dates=f"{role['start']['text']} – {role['end']['text']}", history=o.get("history", ""))
        for k in ("location", "department"):
            if o.get(k):
                x[k] = o[k]
        out.append(x)
    return out


def experience(cv):
    """The CV's employment entries, with profile/employment.json's corrections applied (an employer may be split
    into its roles), most recent first."""
    out = []
    overrides = employment_overrides()
    for e in cv.get("experience", []):
        o = next((o for o in overrides if re.search(o.get("match") or re.escape(o["company"]), e.get("company", ""), re.I)),
                 None)
        out.extend(_split_employer(e, o) if o else [e])
    return sorted(out, key=lambda e: ((e.get("end") or {}).get("year") or 9999, (e.get("end") or {}).get("month") or 12),
                  reverse=True)


def work_history(exp):
    """One line per employer, for a single free-text work-history box."""
    lines, seen = [], set()
    for e in exp:
        if e["company"] in seen:
            continue
        seen.add(e["company"])
        same = [x for x in exp if x["company"] == e["company"]]
        title = e.get("history") or e.get("title", "")
        start = min(same, key=lambda x: ((x.get("start") or {}).get("year") or 0, (x.get("start") or {}).get("month") or 0))
        end = same[0]
        lines.append(f"{e['company']}, {title}, {(start.get('start') or {}).get('text', '')} to "
                     f"{'Present' if end.get('current') else (end.get('end') or {}).get('text', '')}")
    return "\n".join(lines)


def _entries(cv):
    return experience(cv), education(cv)


# ---------------------------------------------------------------- extras
def _words(s):
    return {facts.stem(w) for w in re.findall(r"[A-Za-z][A-Za-z&']+", s.lower()) if len(w) > 3 and w not in STOP}


def _attach_for(heading, cv):
    h = heading.lower()
    for e in cv.get("experience", []):
        if e["company"].split()[0].lower() in h:
            return e["company"]
    if h.startswith("education"):
        return "Education"
    return None


CV_START = re.compile(r"^(\w+ed|Built|Led|Won|Ran|Made|Took|Held|Grew|Oversight|Relationships|Managers|Comfortable|"
                      r"1st|Dissertation)\b")


def _candidates(cv):
    """Fact sentences from facts.md that read as CV lines: they start with a verb or a plain noun phrase, and have no
    third person, notes or dashes."""
    out = []
    for heading, bullets in facts.sections().items():
        attach = _attach_for(heading, cv)
        if not attach:
            continue
        for b in bullets:
            b = re.sub(r"\s*\((?:Don't|Use|don't)[^)]*\)", "", b)
            for sent in re.split(r"(?<=[.!?])\s+", b):
                pieces = [sent] if not re.search(r"\b(he|him|his|she|her|they|them|nobody)\b", sent, re.I) \
                    else [x for x in sent.split(";") if not re.search(r"\b(he|him|his|they|nobody)\b", x, re.I)]
                for s in pieces:
                    s = s.strip().rstrip(".;:").replace(" / ", " and ")
                    s = re.sub(r"\b([a-z]+)/([a-z]+)\b", r"\1 and \2", s[0].lower() + s[1:])
                    s = re.sub(r"\s+", " ", s[0].upper() + s[1:])
                    if len(s.split()) < 5 or facts.dash_problems(s) or not CV_START.match(s):
                        continue
                    out.append({"text": s + ".", "attach": attach})
    return out


# Topics a posting can ask for and a fact can show: (words in a posting, words in a fact line). A fact line is
# offered when it shares a topic with one of the posting's highlights.
TOPICS = {
    "client relationships": (r"client|relationship|investor relations|\blps?\b|account manag|named accounts|stakeholder",
                             r"relationship|client service|site visit"),
    "revenue": (r"revenue|quota|new business|new logo|commercial|sales", r"generated .*revenue"),
    "fund mechanics": (r"capital call|drawdown|distributions\b|fund (admin|operations|formation|regulation)|aifmd|"
                       r"depositary|cash flow|private (equity|credit|markets)|\bpe\b", r"drawdown|capital call|cash flow"),
    "valuation": (r"valuation|\bdcf\b|\bnav\b|ipev|due diligence", r"valuation|ipev"),
    "modelling": (r"model(l)?ing|financial model|\bp&l\b|budget|forecast|excel|cost structure|financial impact",
                  r"budget and p&l"),
    "AI": (r"\bai\b|genai|\bllms?\b|automation|machine learning", r"\bai\b"),
    "process change": (r"process|operating model|efficien|optimi[sz]|transformation|streamlin", r"bottleneck|redesign"),
    "training others": (r"\btrain|mentor|coach|people management", r"\btrain"),
    "pitching": (r"\bpitch|present|demo|executive|board", r"pitch"),
    "real assets": (r"real estate|infrastructure|real assets|private credit|brookfield|bridgepoint",
                    r"real estate|infrastructure|brookfield"),
}


def _cap(s):
    return s[:1].upper() + s[1:]


def _topics(s, side):
    s = s.lower()
    return {t for t, pats in TOPICS.items() if re.search(pats[side], s)}


def auto_extras(job, cv, limit=4):
    """Up to four fact lines that share a topic with the posting's highlights and aren't on the CV already."""
    highlights = [h for h in job.get("posting_highlights") or [] if h]
    if not highlights:
        return []
    on_cv = [_words(b) for e in cv.get("experience", []) + cv.get("education", []) for b in e.get("bullets", [])]
    title_t = _topics(job.get("title", "") + " " + (job.get("team") or ""), 0)
    scored = []
    for c in _candidates(cv):
        w = _words(c["text"])
        if any(len(w & b) / max(1, len(w | b)) >= 0.45 for b in on_cv):
            continue  # already on this CV
        ct = _topics(c["text"], 1)
        best, hit = None, set()
        for h in highlights:
            shared = ct & _topics(h, 0)
            if len(shared) > len(hit):
                best, hit = h, shared
        if best:
            scored.append((len(hit) + 0.5 * len(ct & title_t), c, best, hit))
    scored.sort(key=lambda x: -x[0])
    out = []
    for score, c, h, hit in scored[:limit]:
        out.append(dict(c, reason=_cap(" and ".join(sorted(hit))) + f'. Posting: "{h}"', source="facts.md"))
    return out


def extras(job, cv):
    """(lines, held_back). The daily run's data/autofill/<id>.json wins; each line is checked against the facts."""
    f = AUTOFILL_DIR / f"{job['id']}.json"
    if not f.exists():
        return auto_extras(job, cv), []
    try:
        spec = json.loads(f.read_text())
    except ValueError:
        return auto_extras(job, cv), [{"text": f.name, "why": "not valid JSON"}]
    corpus = facts.corpus()
    lines, held = [], []
    for x in (spec.get("extras") or [])[:4]:
        text = (x.get("text") or "").strip()
        why = facts.dash_problems(text)
        bad = corpus.untraceable(text)
        if bad:
            why.append("not in facts.md or the CV: " + ", ".join(bad[:5]))
        if why:
            held.append({"text": text, "why": "; ".join(why)})
        else:
            lines.append({"text": text, "reason": x.get("reason", ""), "attach": x.get("attach"),
                          "source": "daily run"})
    return lines, held


# ---------------------------------------------------------------- files
def _file(kind, name, label):
    return {"url": f"/api/file/{kind}/{urllib.parse.quote(name)}", "name": name, "label": label}


def tailored(job):
    f = TAILORED_DIR / f"{job['id']}.json"
    if not f.exists():
        return None
    try:
        t = json.loads(f.read_text())
    except ValueError:
        return None
    out = {k: t.get(k) for k in ("status", "created", "approved_at", "reason", "changes", "source_cv")}
    out["summary"] = (t.get("diff") or {}).get("summary")  # before and after, so the wording itself is approved
    files = {}
    for kind in ("docx", "pdf"):
        name = t.get(kind)
        if name and (CVS_DIR / name).is_file():
            files[kind] = _file("cvs", name, "Tailored CV, " + ("Word" if kind == "docx" else "PDF"))
    out["files"] = files
    return out


def files(job):
    out = {}
    key = job.get("cv")
    if key and cvparse.cv_path(key):
        out["cv"] = dict(_file("cv", key, key), name=f"{_user_name()} - CV.pdf", key=key)
    for kind, label in (("letter_pdf", "Cover letter, PDF"), ("letter_docx", "Cover letter, Word")):
        name = job.get(kind)
        if name and (LETTERS / name).is_file():
            out[kind] = _file("letters", name, label)
    return out


# ---------------------------------------------------------------- payload
def payload(job, how, candidates=()):
    key = job.get("cv") or "CV"
    try:
        cv = cvparse.parse_key(key)
    except FileNotFoundError:
        cv = {"name": "", "contact": {}, "education": [], "experience": [], "skills": [], "right_to_work": []}
    exp, edu = _entries(cv)
    lines, held = extras(job, cv)
    return {
        "matched": how,
        "job": {k: job.get(k) for k in ("id", "firm", "title", "sector", "location", "url", "cv", "status")},
        "candidates": [{"id": j["id"], "firm": j["firm"], "title": j["title"]} for j in candidates],
        "cv_file": cv.get("file"),
        "fields": fields(cv),
        "summary": cv.get("summary", ""),
        "experience": exp,
        "education": edu,
        "skills": cv.get("skills", []),
        "extras": lines,
        "extras_held_back": held,
        "files": files(job),
        "tailored": tailored(job),
    }


def roles(jobs):
    """Every role on the dashboard, for the panel's picker. Applied and passed ones go last."""
    order = {"new": 0, "interested": 0, "applied": 1, "pass": 2}
    live = [j for j in jobs if not j.get("vault")]
    live.sort(key=lambda j: (order.get(j.get("status", "new"), 0), -(j.get("fit") or 0)))
    return [{"id": j["id"], "firm": j["firm"], "title": j["title"], "status": j.get("status", "new")} for j in live]


def main():
    args = sys.argv[1:]
    jobs = load_jobs()
    if args[:1] == ["--employment"]:
        cv = cvparse.parse_key(args[1] if len(args) > 1 else "CV")
        for e in experience(cv):
            print(f"{e['company']} | {e['title']} | {e['start']['text']} – {e['end']['text']}")
            for b in e.get("bullets", []):
                print("   •", b)
        print("\nWork history box:\n" + work_history(experience(cv)))
        return
    if args[:1] == ["--id"]:
        job = next((j for j in jobs if j["id"] == args[1]), None)
        if not job:
            sys.exit("unknown id")
        print(json.dumps(payload(job, "id"), indent=2, ensure_ascii=False))
    elif args:
        job, how, cands = match(args[0], jobs)
        if not job:
            print("no match", "(candidates: " + ", ".join(c["firm"] for c in cands) + ")" if cands else "")
            return
        p = payload(job, how)
        print(f"{how}: {job['id']} {job['firm']} | {job['title']}")
        for x in p["extras"]:
            print(f"  + {x['text']}  [{x['reason']}]")
        for x in p["extras_held_back"]:
            print(f"  held back: {x['text']}  ({x['why']})")
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
