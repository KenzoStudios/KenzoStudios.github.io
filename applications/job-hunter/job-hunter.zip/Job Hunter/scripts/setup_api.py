"""The setup window's changes to the profile (see scripts/user.py for the files). Used by serve.py.

Every function returns (state, error): the new setup state for the window, or a message saying what was wrong.
Uploaded files are only ever written inside profile/cvs/ and profile/sample-letters/, and removing a CV never deletes
a file that lives elsewhere (a CV registered by `path`, such as one in Documents, is only unlisted).
"""
import datetime
import pathlib
import re

import user

UPLOAD_TYPES = {".pdf", ".docx", ".doc", ".txt", ".md", ".rtf", ".pages"}
MAX_BYTES = 15 * 1024 * 1024
MAX_INDUSTRIES = 10
DETAIL_FIELDS = ("name", "email", "phone", "city", "linkedin")


def _clean(s, n=200):
    return re.sub(r"\s+", " ", s).strip()[:n] if isinstance(s, str) else ""


def save_details(body):
    if not isinstance(body, dict):
        return None, "send the details as an object"
    d = user.details()
    for k in DETAIL_FIELDS:
        if k in body:
            d[k] = _clean(body[k])
    if "locations" in body:
        locs = body["locations"]
        locs = locs.split(",") if isinstance(locs, str) else locs if isinstance(locs, list) else []
        d["locations"] = list(dict.fromkeys(_clean(c, 60) for c in locs if _clean(c, 60)))[:10]
    if d.get("email") and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", d["email"]):
        return None, "that email address doesn't look right"
    user._write(user.USER, d)
    return user.state(), None


def save_options(body):
    """Settings that are switches rather than text: tailor_cvs."""
    if not isinstance(body, dict) or not isinstance(body.get("tailor_cvs"), bool):
        return None, "send {\"tailor_cvs\": true or false}"
    d = user.details()
    d["tailor_cvs"] = body["tailor_cvs"]
    user._write(user.USER, d)
    return user.state(), None


def _stored_name(original, folder):
    stem, ext = pathlib.Path(original).stem, pathlib.Path(original).suffix.lower()
    base = re.sub(r"[^A-Za-z0-9 ._()&-]+", "", stem).strip()[:80] or "file"
    name, n = f"{base}{ext}", 2
    while (folder / name).exists():
        name, n = f"{base} ({n}){ext}", n + 1
    return name


def upload(kind, original, data, label=""):
    """Store an uploaded CV or writing sample."""
    ext = pathlib.Path(original or "").suffix.lower()
    if kind not in ("cv", "sample"):
        return None, "kind must be cv or sample"
    if ext not in UPLOAD_TYPES:
        return None, "upload a PDF, Word, Pages, RTF or text file"
    if not data:
        return None, "the file was empty"
    if len(data) > MAX_BYTES:
        return None, "files can be up to 15 MB"
    now = datetime.datetime.now().isoformat(timespec="seconds")
    if kind == "cv":
        cvs = user.cvs()
        key = _clean(label, 40) or _clean(pathlib.Path(original).stem, 40) or f"CV {len(cvs) + 1}"
        if any(c["key"].lower() == key.lower() for c in cvs):
            return None, f"you already have a CV called “{key}”; give this one another name"
        user.CV_DIR.mkdir(parents=True, exist_ok=True)
        name = _stored_name(original, user.CV_DIR)
        (user.CV_DIR / name).write_bytes(data)
        cvs.append({"key": key, "file": name, "original": _clean(original, 120), "uploaded": now})
        user._write(user.CVS, cvs)
    else:
        samples = user.samples()
        if len(samples) >= user.MAX_SAMPLES:
            return None, f"you can add up to {user.MAX_SAMPLES} letters; remove one first"
        user.SAMPLE_DIR.mkdir(parents=True, exist_ok=True)
        name = _stored_name(original, user.SAMPLE_DIR)
        (user.SAMPLE_DIR / name).write_bytes(data)
        n = max([int(s["id"][1:]) for s in samples if re.fullmatch(r"s\d+", str(s.get("id")))] or [0]) + 1
        samples.append({"id": f"s{n}", "file": name, "original": _clean(original, 120), "uploaded": now})
        user._write(user.SAMPLES, samples)
    return user.state(), None


def remove(kind, ident):
    if kind == "cv":
        cvs = user.cvs()
        c = next((c for c in cvs if c["key"] == ident), None)
        if not c:
            return None, "no such CV"
        if not c.get("path"):  # only files the window stored itself are deleted
            f = (user.CV_DIR / c["file"]).resolve()
            if f.parent == user.CV_DIR.resolve() and f.is_file():
                f.unlink()
        user._write(user.CVS, [x for x in cvs if x is not c])
    elif kind == "sample":
        samples = user.samples()
        s = next((s for s in samples if s.get("id") == ident), None)
        if not s:
            return None, "no such letter"
        f = (user.SAMPLE_DIR / s["file"]).resolve()
        if f.parent == user.SAMPLE_DIR.resolve() and f.is_file():
            f.unlink()
        user._write(user.SAMPLES, [x for x in samples if x is not s])
    else:
        return None, "kind must be cv or sample"
    return user.state(), None


def save_cv_note(key, note):
    cvs = user.cvs()
    c = next((c for c in cvs if c["key"] == key), None)
    if not c:
        return None, "no such CV"
    c["note"] = _clean(note, 300)
    user._write(user.CVS, cvs)
    return user.state(), None


def save_industries(items):
    """The industries, in order. An existing industry keeps its key (roles and colours follow it); new ones get one."""
    if not isinstance(items, list):
        return None, "send a list of industries"
    old = {i["name"].lower(): i for i in user.industries()}
    keys = {c["key"] for c in user.cvs()}
    out, used = [], set()
    for it in items[:MAX_INDUSTRIES]:
        if not isinstance(it, dict):
            continue
        name = _clean(it.get("name"), 60)
        if not name or name.lower() in used:
            continue
        used.add(name.lower())
        prev = old.get(name.lower(), {})
        key = prev.get("key") or user.slug(name)
        while any(o["key"] == key for o in out):
            key += "x"
        entry = {"key": key, "name": name, "notes": _clean(it.get("notes", prev.get("notes", "")), 400)}
        cv = it.get("cv", prev.get("cv"))
        if cv in keys:
            entry["cv"] = cv
        if prev.get("color"):
            entry["color"] = prev["color"]
        out.append(entry)
    user._write(user.INDUSTRIES, out)
    return user.state(), None


def complete():
    st = user.state()
    missing = [k for k in ("details", "cvs", "samples", "industries") if not st["ready"][k]]
    if missing:
        return None, "still to do: " + ", ".join(missing)
    d = user.details()
    d["setup_complete"] = True
    d.setdefault("setup_completed_on", user.today())
    user._write(user.USER, d)
    return user.state(), None
