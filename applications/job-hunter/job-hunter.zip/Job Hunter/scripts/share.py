"""Make a copy of Job Hunter to give to someone else, with none of this user's personal data in it.

  python3 scripts/share.py        # writes dist/Job Hunter.zip and prints its path

The copy has the app, the scripts, the browser extension and the /job-hunter-setup skill. It leaves out everything
personal: the profile (details, CVs, writing samples, industries, facts, preferences, answers, address), every role and
application (data/), letters, tailored CVs, prep sheets, snapshots and local Claude settings. In their place it puts the
starter profile from templates/profile/ and an empty tracker, so the setup window opens on first launch.
"""
import json
import pathlib
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
TOP = "Job Hunter"
# Never copied: personal data, generated files, design history, local settings.
SKIP_DIRS = {".git", "data", "letters", "cvs", "prep", "snapshots", "screenshots", "design", "dist", "profile",
             "__pycache__", ".bin", "backup"}
SKIP_FILES = {".DS_Store", "settings.local.json", "run.log"}
SKIP_SUFFIXES = {".pyc", ".log"}
# The standing-answer defaults a new user starts with: nothing that belongs to this user.
MY_ANSWERS = {
    "about": "Your standing answers for application forms (edit in the extension: Options > My answers). "
             "mode: fill = autofill fills it; leave = left for you.",
    "answers": {
        "hear_about": {"value": "Company careers website", "mode": "fill"},
        "salary": {"value": "", "mode": "leave"},
        "previously_employed": {"value": "", "mode": "leave"},
        "relocation": {"value": "", "mode": "leave"},
        "dob": {"value": "", "mode": "leave"},
    },
}
START_HERE = """# Job Hunter: start here

Job Hunter finds roles for you every weekday, writes a cover letter for each in your own voice, picks the right CV, and
tracks your applications. It runs on your own computer with Claude doing the searching and writing.

## Start it
1. In the Claude desktop app's **Code** tab, start a new local session in an empty folder made for Job Hunter
   (for example Documents\\Job Hunter or ~/Documents/Job Hunter).
2. Drag this zip into the chat and type **run**.

(Already unzipped? Open the unzipped folder in the Code tab and type **run**.)

Claude does the rest: it opens the dashboard, asks before installing anything it needs, and walks you through setup
(about 15 minutes). You add your details, your CVs (as many as you like), up to five cover letters you've written, and the
industries you want in your own words, such as "Capital raising". Claude then learns how you write, builds your profile
and schedules a search for weekday mornings. After that, type **run** any time to see what's new.

You need the Claude desktop app (on a Mac or Windows PC) and, for autofill, Google Chrome.

## For Claude
If the user gave you this zip or folder and said "run":
- If you can't run commands on their computer (for example in a chat without Claude Code), tell them Job Hunter runs
  through the Code tab of the Claude desktop app and give them the steps above.
- If it's a zip, unzip it into the session's current folder so that its contents (CLAUDE.md, serve.py, scripts/ and the
  rest) sit directly in that folder, not inside a nested "Job Hunter" folder. If the current folder already holds other
  files, ask before unzipping there. This way, opening that folder later and typing run just works.
- Then read `CLAUDE.md` and follow `.claude/skills/job-hunter-start/SKILL.md`.

You can reopen Setup any time from the top of the dashboard to add CVs, change your industries or reconnect Claude.

## Autofill (optional)
To fill application forms from your CV, load the `extension` folder in Chrome (chrome://extensions, Developer mode,
Load unpacked). See extension/README.md.
"""


def _wanted(rel):
    parts = rel.parts
    if parts[0] in SKIP_DIRS or any(p in SKIP_DIRS - {"profile"} for p in parts[:-1]):
        return False
    if parts[0] == ".claude" and not (len(parts) > 1 and parts[1] in ("skills", "launch.json")):
        return False
    return rel.name not in SKIP_FILES and rel.suffix not in SKIP_SUFFIXES


def build(out=None):
    out = pathlib.Path(out or DIST / f"{TOP}.zip")
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".zip.tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(ROOT.rglob("*")):
            rel = p.relative_to(ROOT)
            if p.is_file() and not p.is_symlink() and _wanted(rel):
                info = zipfile.ZipInfo.from_file(p, f"{TOP}/{rel.as_posix()}")
                info.compress_type = zipfile.ZIP_DEFLATED
                with open(p, "rb") as f:
                    z.writestr(info, f.read())
        for t in sorted((ROOT / "templates" / "profile").iterdir()):
            if t.is_file():
                z.write(t, f"{TOP}/profile/{t.name}")
        z.writestr(f"{TOP}/profile/my_answers.json", json.dumps(MY_ANSWERS, indent=2, ensure_ascii=False) + "\n")
        z.writestr(f"{TOP}/data/jobs.json", json.dumps({"jobs": [], "runs": []}, indent=2) + "\n")
        z.writestr(f"{TOP}/START HERE.md", START_HERE)
    tmp.replace(out)
    return out


def check(path):
    """Personal markers that must never be in the copy. Returns the files that contain one."""
    sys.path.insert(0, str(ROOT / "scripts"))
    import user
    d = user.details()
    marks = [m for m in (d.get("email"), d.get("phone"), (d.get("linkedin") or "").split("/")[-1]) if m and len(m) > 5]
    marks += [c.get("file") for c in user.cvs() if c.get("file")]
    bad = []
    with zipfile.ZipFile(path) as z:
        for n in z.namelist():
            if n.endswith((".js", ".py", ".md", ".json", ".html", ".txt", ".command", ".css", ".swift", ".mjs")):
                text = z.read(n).decode("utf-8", "ignore")
                hit = [m for m in marks if m in text]
                if hit:
                    bad.append((n, hit))
    return bad


if __name__ == "__main__":
    p = build()
    bad = check(p)
    print(p)
    for n, hit in bad:
        print("  contains personal data:", n, hit)
    sys.exit(1 if bad else 0)
