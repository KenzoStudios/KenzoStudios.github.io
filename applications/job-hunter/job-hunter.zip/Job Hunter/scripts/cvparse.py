"""Read the user's four CVs (.docx) into structured JSON for autofill.

  python3 scripts/cvparse.py               # parse all four CVs and print a one-line summary of each
  python3 scripts/cvparse.py "CV Tech"     # print one CV as JSON
  python3 scripts/cvparse.py --check       # compare every bullet with macOS textutil's plain-text export

The CV keys and file names come from serve.py (CVS, CV_FILES, CV_DIR). Bullets are kept word for word:
autofill pastes them 1:1. The CV files themselves are only ever read.
"""
import datetime
import json
import pathlib
import re
import subprocess
import sys

from docx import Document
from docx.oxml.ns import qn

ROOT = pathlib.Path(__file__).resolve().parent.parent
HEADINGS = {
    "professional summary": "summary", "summary": "summary", "profile": "summary",
    "education": "education",
    "professional experience": "experience", "experience": "experience", "work experience": "experience",
    "technical skills": "skills", "skills": "skills",
    "other information": "other", "interests": "other", "additional information": "other",
}
SPLIT = re.compile(r"\t+\s*|\s{3,}")  # a tab, or a run of spaces used to push text to the right
MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
DATE = r"(?:[A-Za-z]{3,9}\.?\s+)?\d{4}"
DATES = re.compile(rf"({DATE})\s*[\u2013\u2014-]\s*({DATE}|present|current|now)\s*$", re.I)
_cache = {}


def _serve():
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    import serve
    return serve


def cv_keys():
    return list(_serve().CVS)


def cv_path(key):
    return _serve().cv_file(key)


def plain_text(path):
    return "\n".join(p.text for p in Document(str(path)).paragraphs)


def _date(s):
    s = s.strip()
    if re.match(r"present|current|now", s, re.I):
        return {"text": "Present", "month": None, "year": None}
    m = re.match(r"([A-Za-z]{3,9})\.?\s+(\d{4})", s)
    if m:
        mon = MONTHS.get(m.group(1)[:3].lower())
        return {"text": f"{m.group(1)[:3].title()} {m.group(2)}", "month": mon, "year": int(m.group(2))}
    y = re.search(r"\d{4}", s)
    return {"text": y.group(0) if y else s, "month": None, "year": int(y.group(0)) if y else None}


def _dates(text):
    """'Senior Analyst\t Oct. 2023 – Aug. 2025' -> ('Senior Analyst', {dates...}) or (text, None)."""
    m = DATES.search(text)
    if not m:
        return text.strip(), None
    start, end = _date(m.group(1)), _date(m.group(2))
    today = datetime.date.today()
    current = end["year"] is None or (end["year"], end["month"] or 12) >= (today.year, today.month)
    return text[: m.start()].strip(" \t,"), {
        "text": m.group(0).strip(), "start": start, "end": end, "current": current,
    }


def _is_list(p):
    ppr = p._p.pPr
    return ppr is not None and ppr.numPr is not None


def _bold_start(p):
    for r in p.runs:
        if r.text.strip():
            return bool(r.bold)
    return False


def _heading(p):
    t = re.sub(r"\s+", " ", p.text).strip().lower()
    return HEADINGS.get(t) if t and _bold_start(p) and "\t" not in p.text else None


def _split2(text):
    parts = [x.strip() for x in SPLIT.split(text.strip()) if x.strip()]
    return (parts[0], " ".join(parts[1:])) if len(parts) > 1 else (text.strip(), "")


def _company(text):
    left, loc = _split2(text)
    m = re.match(r"^(.*?)\s*\((.*)\)\s*$", left)
    name, note = (m.group(1), m.group(2)) if m else (left, "")
    return {"company": name.strip(), "descriptor": note.strip(), "location": loc}


def _degree(line):
    d = {"degree_line": line}
    low = line.lower()
    if re.search(r"\bmaster|\bmsc\b|\bmba\b|\bma\b(?= in)|\bmim\b", low):
        d["level"] = "Master's Degree"
    elif re.search(r"\bba\b|\bbsc\b|bachelor|\(hons\)", low):
        d["level"] = "Bachelor's Degree"
    elif re.search(r"baccalaureate|a.level|gcse|high school", low):
        d["level"] = "High School"
    m = re.search(r"\bin\s+(.+?)(?:\s+\d[\d.]*\s*GPA|\s*\(|\.?$)", line)
    if m and d.get("level") != "High School":
        d["field"] = m.group(1).strip(" .")
    head = re.split(r"\s+in\s+", line, 1)[0]
    d["degree"] = re.sub(r"^\S*\d:\d\S*\s+(\(Hons\)\s+)?", "", head).strip()  # '2:2 (Hons) BA' -> 'BA'
    if d.get("field"):
        d["degree"] = f"{d['degree']} in {d['field']}"
    gpa = re.search(r"(\d\.\d+)\s*GPA", line)
    if gpa:
        d["grade"] = f"{gpa.group(1)} GPA"
    cls = re.match(r"(\d:\d|First|1st)\b", line)
    if cls:
        d["classification"] = cls.group(1)  # kept apart: facts.md says not to volunteer it
    ib = re.match(r"(\d+)\s+Points(?:\s+in\s+(?:the\s+)?(.+))?", line, re.I)
    if ib:
        d["grade"] = f"{ib.group(1)} points"
        if ib.group(2):
            d["degree"] = ib.group(2).strip(" .")
    return d


def parse(path):
    path = pathlib.Path(path)
    key = (str(path), path.stat().st_mtime)
    if key in _cache:
        return _cache[key]
    doc = Document(str(path))
    cv = {"file": path.name, "name": "", "contact": {}, "right_to_work": [], "summary": "",
          "education": [], "experience": [], "skills": [], "other": []}
    section, head_lines, summary = None, [], []
    for p in doc.paragraphs:
        text = p.text.rstrip()
        if not text.strip():
            continue
        h = _heading(p)
        if h:
            section = h
            continue
        if section is None:
            if not cv["name"]:
                cv["name"] = text.strip()
            else:
                head_lines.append(text.strip())
        elif section == "summary":
            summary.append(text.strip())
        elif section == "skills":
            cv["skills"] += [s.strip() for s in text.split("|") if s.strip()]
        elif section == "other":
            cv["other"].append(text.strip())
        elif section in ("education", "experience"):
            items = cv[section]
            if _is_list(p):
                if items:
                    items[-1]["bullets"].append(text.strip())
                continue
            rest, dates = _dates(text)
            if section == "education":
                if _bold_start(p) and not dates:
                    school, loc = _split2(text)
                    items.append({"school": school, "location": loc, "bullets": []})
                elif items:
                    items[-1].update(_degree(rest))
                    if dates:
                        items[-1].update(dates=dates["text"], start=dates["start"], end=dates["end"],
                                         current=dates["current"])
            else:
                if _bold_start(p) and not dates and (SPLIT.search(text) or not items):
                    items.append(dict(_company(text), department="", title="", bullets=[]))
                elif not items:
                    continue
                elif dates:
                    e = items[-1]
                    if e["title"]:  # a second role at the same firm
                        e = dict(e, title="", bullets=[])
                        items.append(e)
                    e.update(title=rest, dates=dates["text"], start=dates["start"], end=dates["end"],
                             current=dates["current"])
                else:
                    items[-1]["department"] = text.strip()
    cv["summary"] = " ".join(summary)
    if head_lines:
        line = head_lines[0]
        email = re.search(r"[\w.+-]+@[\w-]+(\.[\w-]+)+", line)
        phone = re.search(r"\(?\+\d{1,3}\)?[\s\d]{6,}\d", line)
        link = re.search(r"linkedin\.com/in/[\w-]+", line)
        cv["contact"] = {
            "location": line.split("|")[0].strip(),
            "email": email.group(0) if email else "",
            "phone": re.sub(r"\s+", " ", phone.group(0)).strip() if phone else "",
            "linkedin": "https://www." + link.group(0) if link else "",
        }
    for line in head_lines[1:]:
        if re.search(r"citizen|residen|visa|right to work", line, re.I):
            cv["right_to_work"] += [s.strip() for s in line.split("|") if s.strip()]
    _cache[key] = cv
    return cv


def parse_key(key):
    p = cv_path(key)
    if not p:
        raise FileNotFoundError(f"no file for {key!r} (see profile/cvs.json)")
    return dict(parse(p), key=key)


def _norm(s):
    return re.sub(r"\s+", " ", s.replace("\u2022", " ").replace("\u25cf", " ")).strip()


def check(key):
    """Every bullet and the summary must appear as a whole line of textutil's export."""
    path = cv_path(key)
    out = subprocess.run(["textutil", "-convert", "txt", "-stdout", str(path)], capture_output=True, text=True,
                         check=True).stdout
    lines = {_norm(l) for l in out.splitlines()}
    cv = parse(path)
    want = [cv["summary"]] + [b for e in cv["experience"] + cv["education"] for b in e["bullets"]] + cv["other"]
    missing = [w for w in want if _norm(w) not in lines]
    return len(want), missing


def main():
    args = sys.argv[1:]
    if args and args[0] == "--check":
        bad = 0
        for key in cv_keys():
            n, missing = check(key)
            print(f"{key}: {n - len(missing)}/{n} lines match textutil exactly")
            for m in missing:
                bad += 1
                print("   MISSING:", m)
        sys.exit(1 if bad else 0)
    if args:
        print(json.dumps(parse_key(args[0]), indent=2, ensure_ascii=False))
        return
    for key in cv_keys():
        try:
            cv = parse_key(key)
        except FileNotFoundError as e:
            print(f"{key}: {e}")
            continue
        exp = ", ".join(f"{e['company']} ({len(e['bullets'])})" for e in cv["experience"])
        print(f"{key}: {cv['file']} | {len(cv['education'])} education | experience: {exp} | "
              f"{len(cv['skills'])} skills")


if __name__ == "__main__":
    main()
