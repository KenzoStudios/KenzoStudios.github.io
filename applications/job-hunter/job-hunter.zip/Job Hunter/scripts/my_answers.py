"""The user's standing answers for the questions autofill used to leave to him: how he heard about the role, salary,
equal-opportunity questions, date of birth, previous employment, notice period and relocation.

Stored in profile/my_answers.json and edited from the extension (Options > My answers, or the panel). Each answer has
a mode: "fill" (autofill fills it) or "leave" (the box is left for the user). Used by serve.py:

  GET /api/my-answers            view()
  PUT /api/my-answers {answers}  update(changes)

  python3 scripts/my_answers.py          # print the current answers and modes

Values are never invented: the defaults are the user's own (salary from profile/preferences.md, notice period from
profile/answers.json), equal-opportunity answers default to declining, and date of birth is empty until he sets it.
"""
import copy
import json
import pathlib
import re
import sys
import threading

ROOT = pathlib.Path(__file__).resolve().parent.parent
FILE = ROOT / "profile" / "my_answers.json"
ANSWERS = ROOT / "profile" / "answers.json"
sys.path.insert(0, str(ROOT / "scripts"))
import store  # noqa: E402

MODES = ("fill", "leave")
DECLINE = "Prefer not to say"
_LOCK = threading.Lock()

# key, label, group, default value, default mode, hint; salary has extra fields (see SALARY_EXTRA)
SPEC = [
    ("hear_about", "How did you hear about us", "Application", "Company careers website", "fill",
     "Picked from the nearest option on a list."),
    ("salary", "Salary expectations", "Application", "£65,000 base", "fill",
     "Free-text salary boxes get the sentence below; number-only boxes get the number; a list of ranges gets the "
     "option that contains it. Roles in Ireland or paid in euro use the euro figures."),
    ("previously_employed", "Previously employed here", "Application", "No", "fill", ""),
    ("notice_period", "Notice period", "Application", None, "fill", "From profile/answers.json."),
    ("relocation", "Open to relocation", "Application", "Yes", "fill",
     "Yes/No questions only. Long relocation questions use your answer bank."),
    ("dob", "Date of birth", "Personal", "", "leave", "As YYYY-MM-DD. Empty: always left for you."),
    ("gender", "Gender", "Equal opportunity", DECLINE, "fill", ""),
    ("ethnicity", "Ethnicity", "Equal opportunity", DECLINE, "fill", ""),
    ("sexual_orientation", "Sexual orientation", "Equal opportunity", DECLINE, "fill", ""),
    ("disability", "Disability", "Equal opportunity", DECLINE, "fill", ""),
    ("veteran", "Veteran status", "Equal opportunity", DECLINE, "fill", ""),
    ("religion", "Religion or belief", "Equal opportunity", DECLINE, "fill", ""),
    ("age_range", "Age range", "Equal opportunity", DECLINE, "fill", ""),
]
# Salary: the short value above, plus these. From profile/preferences.md: target £65k+ base (or €75k+ in Dublin).
SALARY_EXTRA = {
    "free_text": "£65,000 base, open to discussion depending on the overall package",
    "number": 65000,
    "eur_value": "€75,000 base",
    "eur_free_text": "€75,000 base, open to discussion depending on the overall package",
    "eur_number": 75000,
}
EEO_NOTE = ("Equal-opportunity answers: “Prefer not to say” picks the nearest decline option (“I do not wish to "
            "answer”, “Decline to self-identify”). Write your own answer to use it instead.")
MAX_LEN = 400


def _notice_default():
    try:
        for a in json.loads(ANSWERS.read_text()).get("answers", []):
            if a.get("key") == "notice_period" and a.get("answer"):
                return a["answer"]
    except (OSError, ValueError):
        pass
    return ""


def defaults():
    out = {}
    for key, label, group, value, mode, hint in SPEC:
        out[key] = {"value": _notice_default() if value is None else value, "mode": mode}
        if key == "salary":
            out[key].update(SALARY_EXTRA)
    return out


def _read():
    try:
        d = json.loads(FILE.read_text())
        return d.get("answers") if isinstance(d, dict) and isinstance(d.get("answers"), dict) else {}
    except (OSError, ValueError):
        return {}


def current():
    """Every answer: the saved one where there is one, the default otherwise."""
    out, saved = defaults(), _read()
    for key, rec in out.items():
        s = saved.get(key)
        if isinstance(s, dict):
            for k, v in s.items():
                if k in rec and _valid(key, k, v) is None:
                    rec[k] = v
    return out


def view():
    cur = current()
    rows = []
    for key, label, group, value, mode, hint in SPEC:
        rows.append(dict(cur[key], key=key, label=label, group=group, hint=hint))
    return {"answers": rows, "eeo_note": EEO_NOTE, "file": "profile/my_answers.json"}


def _clean(v):
    return re.sub(r"[\x00-\x1f\x7f]+", " ", v).strip()


def _valid(key, field, v):
    """An error message, or None if v may be stored as answers[key][field]."""
    if field == "mode":
        return None if v in MODES else "mode must be fill or leave"
    if field in ("number", "eur_number"):
        if key != "salary":
            return "unknown field " + field
        ok = v is None or (isinstance(v, (int, float)) and not isinstance(v, bool) and 0 <= v <= 10_000_000)
        return None if ok else field + " must be a number"
    if field in ("value", "free_text", "eur_value", "eur_free_text"):
        if field != "value" and key != "salary":
            return "unknown field " + field
        if not isinstance(v, str) or len(v) > MAX_LEN:
            return field + f" must be text of at most {MAX_LEN} characters"
        if key == "dob" and _clean(v) and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", _clean(v)):
            return "date of birth must be YYYY-MM-DD"
        return None
    return "unknown field " + field


def update(changes):
    """Merge changes into the saved answers. changes: {key: {value?, mode?, ...}} or [{key, value?, mode?}].
    Returns (view, None) or (None, error). The file is written atomically."""
    if isinstance(changes, list):
        try:
            changes = {c["key"]: {k: v for k, v in c.items() if k != "key"} for c in changes}
        except (TypeError, KeyError):
            return None, "answers must be a list of {key, value?, mode?}"
    if not isinstance(changes, dict) or not changes:
        return None, "send {\"answers\": {key: {value?, mode?}}}"
    keys = {s[0] for s in SPEC}
    for key, rec in changes.items():
        if key not in keys:
            return None, "unknown answer " + str(key)[:40]
        if not isinstance(rec, dict) or not rec:
            return None, key + " needs value and/or mode"
        for field, v in rec.items():
            err = _valid(key, field, v)
            if err:
                return None, key + ": " + err
    with _LOCK:
        saved = current()
        for key, rec in changes.items():
            for field, v in rec.items():
                saved[key][field] = _clean(v) if isinstance(v, str) else v
        store.write_json(FILE, {
            "about": "the user's standing answers for application forms (edit in the extension: Options > My answers). "
                     "mode: fill = autofill fills it; leave = left for the user.",
            "answers": saved,
        })
    return view(), None


def main():
    for a in view()["answers"]:
        print(f"{a['mode']:5}  {a['label']}: {a['value'] or '(empty)'}")


if __name__ == "__main__":
    main()
