"""After the application: stages, events, follow-up nudges, the apply queue, form snapshots and interview prep.

Used by serve.py for the dashboard's tracker endpoints, and by the daily run:

  python3 scripts/tracker.py followups        # move overdue follow-up nudges on to the next date (applied stage only)
  python3 scripts/tracker.py queue            # the apply queue, as the dashboard's "Start applying" sees it
  python3 scripts/tracker.py prep-due         # roles at interview stage with no prep sheet in prep/
  python3 scripts/tracker.py prep-skeleton ID # print a starting prep sheet (posting, evidence table, letter) to fill in
  python3 scripts/tracker.py prep-check ID    # check prep/<id>.md for dashes and banned phrases
  python3 scripts/tracker.py email ID --date YYYY-MM-DD --kind KIND --subject "..." --sender a@b.com --thread T
                                              # record an email from the firm (the daily Gmail check); moves the stage on
  python3 scripts/tracker.py external --firm F --title T --sector S --location L --applied YYYY-MM-DD [--url U]
                                              # add an application the user made outside Job Hunter (found in Gmail)
  python3 scripts/tracker.py no-reply         # applications with no contact for 4 weeks become rejected (assumed)
  python3 scripts/tracker.py gmail-checked    # note that Gmail was read today (the dashboard shows it)
  python3 scripts/tracker.py sheet            # the Tracker tab's rows, as the Excel export sees them

Stages move when the user sets them on the dashboard, when an email from the firm says so (`email`), and when four weeks
pass with no contact at all (`no-reply`). An email only moves a stage forward, or to rejected.
"""
import datetime
import html
import json
import pathlib
import re
import shutil
import subprocess
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import store  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parent.parent
SNAPSHOTS = ROOT / "snapshots"
PREP = ROOT / "prep"
LETTERS = ROOT / "data" / "letters"
STAGES = ("applied", "screening", "assessment", "interview", "offer", "rejected", "withdrawn")
CLOSED_STAGES = ("rejected", "withdrawn")
EVENT_KINDS = ("interview", "assessment", "call", "deadline", "other")
OPEN_STAGES = ("applied", "screening", "assessment", "interview", "offer")
# What an email from the firm says, and the stage it moves the application to (None: contact only, no stage change).
CONTACT_KINDS = {"acknowledged": None, "update": None, "screening": "screening", "assessment": "assessment",
                 "interview": "interview", "offer": "offer", "rejected": "rejected", "closed": "rejected"}
NO_REPLY_DAYS = 28  # four weeks with no contact at all: assume the answer is no
NO_REPLY_NOTE = "No reply in 4 weeks, so assumed rejected"
FIRST_NUDGE, LATER_NUDGES = 7, 14  # days after applying, then every 14 days while the stage is still "applied"
SOON = 14  # a deadline within this many days puts a role at the front of the queue


def today():
    return datetime.date.today()


def iso_date(s):
    """The first YYYY-MM-DD in a free-text field ("c. 2026-10-07 (LinkedIn: ...)"), as a date, or None."""
    m = re.search(r"\b(\d{4})-(\d{2})-(\d{2})\b", s or "") if isinstance(s, str) else None
    if not m:
        return None
    try:
        return datetime.date(int(m[1]), int(m[2]), int(m[3]))
    except ValueError:
        return None


def valid_date(s):
    """A YYYY-MM-DD string, or None if it isn't one."""
    if not isinstance(s, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        return None
    try:
        return datetime.date.fromisoformat(s).isoformat()
    except ValueError:
        return None


def valid_datetime(s):
    """An ISO date or datetime ("2026-11-03T10:00:00+00:00", "...Z", "2026-11-03"), normalised, or None."""
    if not isinstance(s, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}([T ][0-9:.]+(Z|[+-]\d{2}:?\d{2})?)?", s.strip()):
        return None
    s = s.strip()
    if len(s) == 10:
        return valid_date(s)
    try:
        return datetime.datetime.fromisoformat(s.replace("Z", "+00:00").replace(" ", "T")).isoformat()
    except ValueError:
        return None


def clean(s, n=2000):
    return s.strip()[:n] if isinstance(s, str) else ""


# ---------------------------------------------------------------- stages
def mark_applied(job, on=None):
    """Status became applied: start tracking it, without overwriting anything already recorded."""
    on = on or today().isoformat()
    job.setdefault("applied_on", on)
    if not job.get("stage"):
        job["stage"] = "applied"
        job.setdefault("stage_history", []).append({"stage": "applied", "date": on, "note": ""})
    if "follow_up_on" not in job and job.get("stage") == "applied":
        job["follow_up_on"] = (datetime.date.fromisoformat(job["applied_on"]) + datetime.timedelta(FIRST_NUDGE)).isoformat()


def unmark_applied(job):
    """Status moved off applied (an undo). Tracking that was only the automatic start is removed again;
    anything the user recorded himself (a later stage, events) is kept."""
    hist = job.get("stage_history") or []
    if job.get("stage") == "applied" and len(hist) <= 1 and not job.get("events"):
        for k in ("stage", "stage_history", "applied_on", "follow_up_on"):
            job.pop(k, None)


def set_stage(job, stage, date=None, note=""):
    """Record a stage (a stage implies the role was applied for, so status follows)."""
    date = date or today().isoformat()
    if job.get("status") != "applied":
        job["status"] = "applied"
        job["status_changed"] = today().isoformat()
        mark_applied(job, date)
        if stage == "applied":
            if note:
                job["stage_history"][-1]["note"] = note
            return
    job["stage"] = stage
    job.setdefault("stage_history", []).append({"stage": stage, "date": date, "note": note})
    job.pop("no_reply", None)
    if stage in CLOSED_STAGES:
        job["follow_up_on"] = None


def set_event(job, body):
    """Add, update or delete an event. Returns an error message or None."""
    events = job.setdefault("events", [])
    eid = body.get("event_id")
    if eid is not None:
        ev = next((e for e in events if e.get("id") == eid), None)
        if not ev:
            return "unknown event"
        if body.get("delete") is True:
            events.remove(ev)
            return None
    elif body.get("delete"):
        return "event_id needed to delete"
    else:
        ev = None
    kind = body.get("kind", ev and ev.get("kind"))
    at = body.get("at", ev and ev.get("at"))
    if kind not in EVENT_KINDS:
        return "kind must be one of " + ", ".join(EVENT_KINDS)
    at = valid_datetime(at)
    if not at:
        return "at must be an ISO date or datetime"
    link = body.get("link", ev and ev.get("link")) or ""
    if link and not re.match(r"https?://", link, re.I):
        return "link must start with http:// or https://"
    if ev is None:
        n = max([int(m[1]) for e in events for m in [re.fullmatch(r"e(\d+)", str(e.get("id", "")))] if m] or [0])
        ev = {"id": f"e{n + 1}"}
        events.append(ev)
    ev.update(kind=kind, at=at, title=clean(body.get("title", ev.get("title")), 200),
              note=clean(body.get("note", ev.get("note"))), link=clean(link, 1000))
    events.sort(key=lambda e: e.get("at") or "")
    return None


# ---------------------------------------------------------------- emails from firms, and the four-week rule
def record_contact(job, date, kind, subject="", sender="", thread=""):
    """An email from the firm about this application. Returns what changed, as a short phrase, or None if it was
    already recorded. Only the subject, the sender's address and the Gmail thread id are kept, never the body."""
    if kind not in CONTACT_KINDS:
        raise ValueError("kind must be one of " + ", ".join(CONTACT_KINDS))
    date = valid_date(date)
    if not date:
        raise ValueError("date must be YYYY-MM-DD")
    contacts = job.setdefault("contacts", [])
    if any(c.get("thread") == thread and c.get("kind") == kind and c.get("date") == date for c in contacts if thread):
        return None
    contacts.append({"date": date, "kind": kind, "subject": clean(subject, 200), "from": clean(sender, 200),
                     "thread": clean(thread, 64)})
    contacts.sort(key=lambda c: c["date"])
    note = "From Gmail: " + (clean(subject, 160) or kind)
    if job.get("status") != "applied":
        job.pop("vault", None)  # applied after all: never leave it in the closed-postings vault
        set_stage(job, "applied", date if kind == "acknowledged" else (job.get("applied_on") or date), note)
    elif kind == "acknowledged" and iso_date(job.get("applied_on")) and date < job["applied_on"]:
        # the firm's receipt proves an earlier date than the one recorded when it was marked applied
        for h in job.get("stage_history") or []:
            if h.get("stage") == "applied" and h.get("date") == job["applied_on"]:
                h["date"] = date
        job["applied_on"] = date
    target = CONTACT_KINDS[kind]
    cur = job.get("stage") or "applied"
    if target is None:
        if job.get("no_reply"):  # a firm wrote after all: the application is open again
            reached = [h["stage"] for h in job.get("stage_history") or [] if h.get("stage") in OPEN_STAGES]
            set_stage(job, reached[-1] if reached else "applied", date, note)
            return "reopened"
        return "contact"
    if target == "rejected":
        if cur == "rejected" and not job.get("no_reply"):
            return "contact"
        set_stage(job, "rejected", date, note)
        return "rejected"
    if cur in CLOSED_STAGES and not job.get("no_reply"):
        return "contact"  # rejected or withdrawn already; an old invitation doesn't reopen it
    if cur in OPEN_STAGES and OPEN_STAGES.index(target) <= OPEN_STAGES.index(cur):
        return "contact"
    set_stage(job, target, date, note)
    if target != "rejected":
        job["follow_up_on"] = None  # the firm has moved it on, so there's nothing to chase
    return target


def last_contact(job):
    """The latest sign of life: applying, an email from the firm, a stage the user set, or an interview or test that has
    happened. None for a role that hasn't been applied for."""
    dates = [iso_date(job.get("applied_on"))]
    dates += [iso_date(c.get("date")) for c in job.get("contacts") or []]
    dates += [iso_date(h.get("date")) for h in job.get("stage_history") or [] if h.get("note") != NO_REPLY_NOTE]
    dates += [iso_date(e.get("at")) for e in job.get("events") or [] if iso_date(e.get("at")) and iso_date(e.get("at")) <= today()]
    dates = [d for d in dates if d]
    return max(dates) if dates else None


def upcoming_event(job, on=None):
    on = on or today()
    return next((e for e in sorted(job.get("events") or [], key=lambda e: e.get("at") or "")
                 if iso_date(e.get("at")) and iso_date(e.get("at")) >= on), None)


def no_reply_due(job, on=None):
    """Applied, still open (not an offer), nothing booked, and no contact for four weeks."""
    on = on or today()
    if job.get("status") != "applied" or (job.get("stage") or "applied") not in OPEN_STAGES[:-1] or upcoming_event(job, on):
        return False
    last = last_contact(job)
    return bool(last) and (on - last).days >= NO_REPLY_DAYS


def apply_no_reply(data, on=None):
    on = on or today()
    changed = []
    for j in data.get("jobs", []):
        if no_reply_due(j, on):
            last = last_contact(j)
            set_stage(j, "rejected", on.isoformat(), NO_REPLY_NOTE)
            j["no_reply"] = last.isoformat()
            changed.append((j, last))
    return changed


def add_external(data, firm, title, sector, location, applied, url=""):
    """An application the user made outside Job Hunter (it turned up in Gmail). Returns the job."""
    import hashlib
    applied = valid_date(applied)
    if not applied:
        raise ValueError("--applied must be YYYY-MM-DD")
    norm = lambda s: re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()  # noqa: E731
    for j in data["jobs"]:
        if norm(j.get("firm")) == norm(firm) and norm(j.get("title")) == norm(title):
            return j
    job = {"id": hashlib.sha1(f"external|{firm}|{title}".encode()).hexdigest()[:10], "firm": firm, "title": title,
           "sector": sector, "location": location, "url": url, "status": "applied", "status_changed": applied,
           "found_on": applied, "source": "gmail", "reason": "", "red_flags": ""}
    mark_applied(job, applied)
    data["jobs"].append(job)
    return job


# ---------------------------------------------------------------- the Tracker tab and its Excel export
STATUS_LABELS = {"applied": "Applied", "screening": "Screening", "assessment": "Assessment", "interview": "Interview",
                 "offer": "Offer", "rejected": "Rejected", "no_reply": "No reply (4 wks)", "withdrawn": "Withdrawn"}
OUTCOMES = {"applied": "Pending", "screening": "In process", "assessment": "In process", "interview": "In process",
            "offer": "Offer", "rejected": "Rejected", "no_reply": "Rejected", "withdrawn": "Withdrawn"}
KIND_LABELS = {"acknowledged": "Application received", "update": "Update", "screening": "Screening invite",
               "assessment": "Assessment invite", "interview": "Interview invite", "offer": "Offer",
               "rejected": "Rejected by email", "closed": "Role withdrawn by the firm"}


def sheet_rows(jobs, on=None):
    """One row per application, newest first. The four-week rule is applied here too, so the sheet is right even
    before the daily run has recorded it."""
    on = on or today()
    rows = []
    for j in jobs:
        if j.get("status") != "applied":
            continue
        stage = j.get("stage") or "applied"
        status = "no_reply" if (stage == "rejected" and j.get("no_reply")) or no_reply_due(j, on) else stage
        last = last_contact(j)
        reached = [h.get("stage") for h in j.get("stage_history") or [] if h.get("stage") in OPEN_STAGES]
        furthest = max(reached + ([stage] if stage in OPEN_STAGES else []) or ["applied"], key=OPEN_STAGES.index)
        contacts = j.get("contacts") or []
        nxt = upcoming_event(j, on)
        if status == "no_reply":
            latest = f"No reply since {(iso_date(j.get('no_reply')) or last).strftime('%-d %b')}" if (j.get("no_reply") or last) else "No reply"
        elif contacts:
            c = contacts[-1]
            latest = KIND_LABELS.get(c["kind"], c["kind"])
            if c.get("subject") and c["kind"] != "acknowledged":
                latest += f": {c['subject']}"
        else:
            h = (j.get("stage_history") or [{}])[-1]
            latest = "Waiting to hear" if stage == "applied" else (h.get("note") or STATUS_LABELS.get(stage, stage))
        rows.append({
            "id": j["id"], "firm": j.get("firm") or "", "title": j.get("title") or "", "sector": j.get("sector") or "",
            "location": j.get("location") or "", "applied_on": iso_date(j.get("applied_on")), "status": status,
            "status_label": STATUS_LABELS.get(status, status), "outcome": OUTCOMES.get(status, ""),
            "furthest": STATUS_LABELS[furthest], "last_contact": last,
            "days_since": (on - last).days if last and OUTCOMES.get(status) in ("Pending", "In process") else None,
            "latest": latest, "next": (f"{(nxt.get('title') or nxt.get('kind') or '').strip()} {nxt.get('at', '')[:10]}".strip() if nxt else ""),
            "from_gmail": bool(contacts) or j.get("source") == "gmail", "url": j.get("url") or "", "cv": j.get("cv") or "",
        })
    order = ["offer", "interview", "assessment", "screening", "applied", "no_reply", "rejected", "withdrawn"]
    rows.sort(key=lambda r: (order.index(r["status"]), -(r["applied_on"] or datetime.date.min).toordinal()))
    return rows


def sheet_xlsx(jobs, path, on=None):
    """Write the Tracker as an Excel workbook: the applications, colour-coded by status, and a summary sheet."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    on = on or today()
    rows = sheet_rows(jobs, on)
    # light fills with dark text, one per status, in the order of the process
    fills = {"applied": ("E8EAED", "3B3E45"), "screening": ("DCE8FB", "1F3F73"), "assessment": ("E9E2FB", "45307A"),
             "interview": ("D5F3EC", "155A4B"), "offer": ("D9F2A8", "2E4A06"), "rejected": ("FADCDB", "7A1F1C"),
             "no_reply": ("F6E9E8", "8A4A47"), "withdrawn": ("EFEFEF", "6B6B6B")}
    outcome_fill = {"Pending": "applied", "In process": "interview", "Offer": "offer", "Rejected": "rejected",
                    "Withdrawn": "withdrawn"}
    head_fill, head_font = PatternFill("solid", fgColor="16171B"), Font(bold=True, color="FFFFFF")
    thin = Side(style="thin", color="DADCE0")
    wb = Workbook()
    ws = wb.active
    ws.title = "Applications"
    cols = [("Firm", 26), ("Role", 46), ("Sector", 20), ("Location", 26), ("Applied on", 13), ("Status", 18),
            ("Outcome", 12), ("Furthest stage", 15), ("Last contact", 13), ("Days since contact", 11),
            ("Latest update", 60), ("Next booked", 26), ("CV sent", 20), ("Posting", 14)]
    for i, (name, width) in enumerate(cols, 1):
        c = ws.cell(row=1, column=i, value=name)
        c.fill, c.font = head_fill, head_font
        c.alignment = Alignment(vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.row_dimensions[1].height = 30
    for r, row in enumerate(rows, 2):
        vals = [row["firm"], row["title"], row["sector"], row["location"], row["applied_on"], row["status_label"],
                row["outcome"], row["furthest"], row["last_contact"], row["days_since"], row["latest"], row["next"],
                row["cv"], "Open posting" if row["url"] else ""]
        for i, v in enumerate(vals, 1):
            c = ws.cell(row=r, column=i, value=v)
            c.border = Border(bottom=thin)
            c.alignment = Alignment(vertical="top", wrap_text=i in (2, 11))
            if isinstance(v, datetime.date):
                c.number_format = "d mmm yyyy"
        bg, fg = fills[row["status"]]
        for col in (6,):
            ws.cell(row=r, column=col).fill = PatternFill("solid", fgColor=bg)
            ws.cell(row=r, column=col).font = Font(bold=True, color=fg)
        obg, ofg = fills[outcome_fill.get(row["outcome"], "applied")]
        ws.cell(row=r, column=7).fill = PatternFill("solid", fgColor=obg)
        ws.cell(row=r, column=7).font = Font(color=ofg)
        if row["url"]:
            link = ws.cell(row=r, column=14)
            link.hyperlink, link.font = row["url"], Font(color="1F5FBF", underline="single")
    ws.freeze_panes = "C2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{max(len(rows) + 1, 2)}"

    sm = wb.create_sheet("Summary")
    sm.column_dimensions["A"].width, sm.column_dimensions["B"].width = 26, 10
    sm["A1"], sm["A1"].font = f"Applications as of {on.strftime('%-d %B %Y')}", Font(bold=True, size=13)
    sm["A2"] = f"No contact for {NO_REPLY_DAYS // 7} weeks counts as rejected."
    sm["A2"].font = Font(italic=True, color="6B6B6B")
    r = 4
    for title, key, order in (("Outcome", "outcome", ["Pending", "In process", "Offer", "Rejected", "Withdrawn"]),
                              ("Status", "status", list(STATUS_LABELS))):
        sm.cell(row=r, column=1, value=title).fill = head_fill
        sm.cell(row=r, column=1).font = head_font
        sm.cell(row=r, column=2, value="Count").fill = head_fill
        sm.cell(row=r, column=2).font = head_font
        r += 1
        for k in order:
            n = sum(1 for x in rows if x[key] == k)
            label = STATUS_LABELS.get(k, k) if key == "status" else k
            fk = k if key == "status" else outcome_fill[k]
            a = sm.cell(row=r, column=1, value=label)
            a.fill, a.font = PatternFill("solid", fgColor=fills[fk][0]), Font(color=fills[fk][1], bold=True)
            sm.cell(row=r, column=2, value=n)
            r += 1
        sm.cell(row=r, column=1, value="Total").font = Font(bold=True)
        sm.cell(row=r, column=2, value=len(rows)).font = Font(bold=True)
        r += 2
    wb.save(path)
    return len(rows)


# ---------------------------------------------------------------- follow-ups
def next_nudge(job, after):
    """The first nudge date strictly after `after`: applied_on + 7, then every 14 days."""
    applied = iso_date(job.get("applied_on"))
    if not applied:
        return None
    d = applied + datetime.timedelta(FIRST_NUDGE)
    while d <= after:
        d += datetime.timedelta(LATER_NUDGES)
    return d


def bump_followups(data, on=None):
    """Overdue nudges (before today) on roles still at the applied stage move to the next date. Returns the changes."""
    on = on or today()
    changed = []
    for j in data.get("jobs", []):
        if j.get("status") != "applied" or (j.get("stage") or "applied") != "applied" or no_reply_due(j, on):
            continue
        due = iso_date(j.get("follow_up_on"))
        if not due or due >= on:
            continue
        nxt = next_nudge(j, on - datetime.timedelta(1))
        if nxt:
            j["follow_up_on"] = nxt.isoformat()
            changed.append((j, due, nxt))
    return changed


# ---------------------------------------------------------------- the apply queue
def queue(jobs, sector=None, include_interested=False, on=None):
    """Roles to apply to, best first: closing within 14 days (soonest first), then fit, then newest."""
    on = on or today()
    statuses = ("new", "interested") if include_interested else ("new",)
    rows = []
    for j in jobs:
        if j.get("vault") or (j.get("status") or "new") not in statuses:
            continue
        if sector and (j.get("sector") or "").lower() != sector.lower():
            continue
        dl, posted = iso_date(j.get("deadline")), iso_date(j.get("posted"))
        days = (dl - on).days if dl else None
        if days is not None and days < 0:
            continue  # the deadline has passed
        soon = days is not None and days <= SOON
        why = []
        if days is not None and days <= SOON:
            why.append("closes today" if days == 0 else "closes tomorrow" if days == 1 else f"closes in {days} days")
        if j.get("fit") is not None:
            why.append(f"fit {j['fit']}")
        if posted:
            age = (on - posted).days
            why.append("posted today" if age <= 0 else "posted yesterday" if age == 1 else f"posted {age} days ago")
        key = (0 if soon else 1, days if soon else 0, -(j.get("fit") or 0), -(posted.toordinal() if posted else 0))
        rows.append((key, {"id": j["id"], "firm": j.get("firm"), "title": j.get("title"), "url": j.get("url"),
                           "sector": j.get("sector"), "status": j.get("status") or "new", "why": " / ".join(why)}))
    rows.sort(key=lambda r: r[0])
    out = []
    for i, (_, r) in enumerate(rows, 1):
        r["priority"] = i
        out.append(r)
    return out


# ---------------------------------------------------------------- snapshots
SNAP_CSS = """
@page{size:A4;margin:14mm 15mm 14mm}
*{box-sizing:border-box}
body{margin:0;font:400 VAR_SIZE/1.42 -apple-system,"Helvetica Neue",Arial,sans-serif;color:#16181D;background:#fff}
header{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;padding-bottom:10px;border-bottom:2px solid #16181D}
.mark{display:inline-block;width:9px;height:9px;border-radius:50%;background:#9CCB3B;margin-right:7px;vertical-align:1px}
.brand{font-weight:700;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#16181D}
.kind{font-size:10px;color:#5E636B;margin-top:3px}
h1{margin:10px 0 2px;font-size:20px;line-height:1.15;letter-spacing:-.01em}
.firm{font-size:13px;color:#3B3E45}
.meta{display:grid;grid-template-columns:auto 1fr;gap:3px 12px;margin:12px 0 14px;font-size:10.5px;color:#3B3E45}
.meta b{font-weight:600;color:#16181D}
.meta a{color:#3B3E45;word-break:break-all}
.stamp{text-align:right;font-size:10px;color:#5E636B;white-space:nowrap}
.stamp b{display:block;font-size:12px;color:#16181D}
h2{margin:14px 0 6px;font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:#5E636B;border-bottom:1px solid #DADCE0;padding-bottom:4px}
table{width:100%;border-collapse:collapse}
td{padding:4px 0;vertical-align:top;border-bottom:1px solid #EEEFF1}
td.q{width:36%;padding-right:12px;color:#3B3E45}
td.a{white-space:pre-wrap;word-break:break-word}
ul{margin:0;padding-left:16px}
footer{margin-top:14px;padding-top:6px;border-top:1px solid #DADCE0;font-size:9px;color:#5E636B}
"""


def snapshot_html(job, snap, size="10.5px"):
    e = lambda s: html.escape(str(s or ""))  # noqa: E731
    when = snap.get("captured_at") or ""
    try:
        dt = datetime.datetime.fromisoformat(when.replace("Z", "+00:00")).astimezone()
        stamp = dt.strftime("%-d %B %Y"), dt.strftime("%H:%M %Z").strip(), dt.strftime("%H:%M:%S %Z").strip()
    except ValueError:
        stamp = when, "", ""
    rows = "".join(f'<tr><td class="q">{e(f["label"])}</td><td class="a">{e(f["value"])}</td></tr>'
                   for f in snap["fields"]) or '<tr><td class="q">No fields captured</td><td class="a"></td></tr>'
    files = "".join(f"<li>{e(n)}</li>" for n in snap["files"]) or "<li>None recorded</li>"
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Application record: {e(job.get('firm'))}</title>
<style>{SNAP_CSS.replace('VAR_SIZE', size)}</style></head><body>
<header><div><div class="brand"><span class="mark"></span>Job Hunter</div><div class="kind">Application record: what was on the form when it was sent</div>
<h1>{e(job.get('title'))}</h1><div class="firm">{e(job.get('firm'))}{(' · ' + e(job.get('location'))) if job.get('location') else ''}</div></div>
<div class="stamp"><b>{e(stamp[0])}</b>{e(stamp[1])}</div></header>
<div class="meta"><b>Form</b><a href="{e(snap['url'])}">{e(snap['url'])}</a><b>Posting</b><a href="{e(job.get('url'))}">{e(job.get('url'))}</a>
<b>Captured</b><span>{e(stamp[0])}, {e(stamp[2])}</span><b>Job Hunter id</b><span>{e(job.get('id'))}</span></div>
<h2>Questions and answers</h2><table>{rows}</table>
<h2>Attached files</h2><ul>{files}</ul>
<footer>Made by Job Hunter from the values on the page as the application was sent. Equal-opportunity, salary and
password fields are never recorded.</footer>
</body></html>"""


def clean_snapshot(body):
    """The snapshot body, checked and trimmed, or None."""
    fields = body.get("fields")
    if not isinstance(fields, list) or not isinstance(body.get("url"), str):
        return None
    out = []
    for f in fields[:300]:
        if isinstance(f, dict) and isinstance(f.get("label"), str) and isinstance(f.get("value"), (str, int, float, bool)):
            v = str(f["value"]).strip()
            if v:
                out.append({"label": clean(f["label"], 300) or "(no label)", "value": v[:12000]})
    files = [clean(n, 300) for n in (body.get("files") or [])[:30] if isinstance(n, str) and n.strip()]
    when = valid_datetime(body.get("captured_at") or "") or datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    return {"url": clean(body["url"], 2000), "fields": out, "files": files, "captured_at": when}


def node():
    for c in (shutil.which("node"), "/opt/homebrew/bin/node", "/usr/local/bin/node"):
        if c and pathlib.Path(c).exists():
            return c
    return None


def render_snapshot(job, snap, out_dir=SNAPSHOTS):
    """Print the record to snapshots/<id>-<yyyymmdd-hhmmss>.pdf with headless Chrome; returns the file name.
    Shrinks the type up to twice to keep it on one page."""
    out_dir = pathlib.Path(out_dir)
    out_dir.mkdir(exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    name = f"{job['id']}-{stamp}.pdf"
    tmp = out_dir / f".{job['id']}-{stamp}.html"
    exe = node()
    if not exe:
        raise RuntimeError("node is not installed, so the PDF can't be printed")
    try:
        for size in ("10.5px", "9.5px", "8.5px"):
            tmp.write_text(snapshot_html(job, snap, size))
            r = subprocess.run([exe, str(ROOT / "scripts" / "dev" / "print_pdf.mjs"), str(tmp), str(out_dir / name)],
                               capture_output=True, text=True, timeout=90, cwd=str(ROOT / "scripts" / "dev"))
            if r.returncode != 0:
                raise RuntimeError("printing the PDF failed: " + (r.stderr or r.stdout).strip()[-300:])
            m = re.search(r"pages=(\d+)", r.stdout)
            if not m or int(m[1]) <= 1:
                break
    finally:
        tmp.unlink(missing_ok=True)
    return name


# ---------------------------------------------------------------- interview prep
def prep_due(data):
    return [j for j in data.get("jobs", []) if j.get("stage") == "interview" and not (PREP / f"{j['id']}.md").exists()]


def prep_skeleton(job):
    spec = {}
    try:
        spec = json.loads((LETTERS / f"{job['id']}.json").read_text())
    except (OSError, ValueError):
        pass
    ev = [e for e in job.get("events") or [] if e.get("kind") in ("interview", "assessment", "call")]
    lines = [f"# {job.get('firm')}: {job.get('title')}", "", "Interview prep. Facts only from profile/facts.md, the posting and the letter.", "",
             "## Logistics"]
    lines += [f"- {e.get('at')}: {e.get('title') or e.get('kind')}{(' (' + e['link'] + ')') if e.get('link') else ''}"
              + (f". {e['note']}" if e.get("note") else "") for e in ev] or ["- Date, time, format and who: (fill in)"]
    lines += [f"- Posting: {job.get('url')}", f"- Applied on {job.get('applied_on') or '?'}; CV sent: {job.get('cv')}", "",
              "## The pitch (60 seconds)", "(Who I am, why this firm, why this role, what I bring: four sentences from the letter.)", "",
              "## Evidence table", "| What they want (posting) | My evidence (facts.md) | Story to tell |", "|---|---|---|"]
    lines += [f"| {h} | | |" for h in job.get("posting_highlights") or []]
    lines += ["", "## Likely questions and answer outlines", "1. Why this firm?", "   - ", "2. Why this role?", "   - ",
              "3. Walk me through your CV.", "   - ", "4. (role-specific, from the posting)", "   - ", "",
              "## Questions to ask them", "1. ", "2. ", "3. ", "", "## Firm facts to have to hand"]
    lines += [f"- {f}" for f in job.get("firm_facts") or []]
    lines += [f"- {s.get('claim')} ({s.get('url')})" for s in spec.get("sources") or [] if isinstance(s, dict)]
    lines += ["", "## The letter, for reference", ""] + [p + "\n" for p in spec.get("paragraphs") or []]
    return "\n".join(lines)


def prep_problems(text):
    import facts
    import make_letter
    return list(dict.fromkeys(facts.dash_problems(text) + make_letter.phrase_problems(text)))


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else ""
    if cmd == "followups":
        with store.locked():
            data = store.load()
            changed = bump_followups(data)
            if changed:
                store.save(data)
        for j, was, now in changed:
            print(f"{j['id']}  follow-up {was} -> {now}  {j['firm']} - {j['title']}")
        if not changed:
            print("no overdue follow-ups")
    elif cmd == "queue":
        for r in queue(store.load()["jobs"], include_interested="--all" in args):
            print(f"{r['priority']:>2}. {r['id']}  {r['firm']} - {r['title']}  ({r['why']})")
    elif cmd == "prep-due":
        due = prep_due(store.load())
        for j in due:
            print(f"{j['id']}  {j['firm']} - {j['title']}")
        if not due:
            print("no interview-stage roles without a prep sheet")
    elif cmd == "prep-skeleton" and len(args) > 1:
        job = next((j for j in store.load()["jobs"] if j["id"] == args[1]), None)
        if not job:
            sys.exit("unknown id")
        print(prep_skeleton(job))
    elif cmd == "prep-check" and len(args) > 1:
        p = PREP / f"{args[1]}.md"
        if not p.exists():
            sys.exit(f"no {p.relative_to(ROOT)}")
        probs = prep_problems(p.read_text())
        print("ok" if not probs else "\n".join(probs))
        sys.exit(1 if probs else 0)
    elif cmd in ("email", "external"):
        opts = flags(args[1:])
        with store.locked():
            data = store.load()
            if cmd == "external":
                try:
                    job = add_external(data, opts.get("firm", ""), opts.get("title", ""), opts.get("sector", ""),
                                       opts.get("location", ""), opts.get("applied", ""), opts.get("url", ""))
                except ValueError as e:
                    sys.exit(str(e))
                store.save(data)
                print(job["id"], job["firm"], "-", job["title"])
                return
            job = next((j for j in data["jobs"] if j["id"] == opts.get("_id")), None)
            if not job:
                sys.exit("unknown id")
            try:
                what = record_contact(job, opts.get("date"), opts.get("kind"), opts.get("subject", ""),
                                      opts.get("sender", ""), opts.get("thread", ""))
            except ValueError as e:
                sys.exit(str(e))
            if what:
                store.save(data)
            print(f"{job['id']}  {what or 'already recorded'}  (stage {job.get('stage')})  {job['firm']} - {job['title']}")
    elif cmd == "no-reply":
        with store.locked():
            data = store.load()
            changed = apply_no_reply(data)
            if changed:
                store.save(data)
        for j, last in changed:
            print(f"{j['id']}  no reply since {last}: assumed rejected  {j['firm']} - {j['title']}")
        if not changed:
            print("nothing has gone four weeks without a reply")
    elif cmd == "gmail-checked":
        with store.locked():
            data = store.load()
            data["gmail_checked"] = today().isoformat()
            store.save(data)
        print("gmail checked", data["gmail_checked"])
    elif cmd == "sheet":
        for r in sheet_rows(store.load()["jobs"]):
            print(f"{r['id']}  {r['status_label']:<17} {r['outcome']:<10} {str(r['last_contact'] or ''):<10}  "
                  f"{r['firm']} - {r['title']}  |  {r['latest']}")
    else:
        sys.exit(__doc__)


def flags(args):
    """`ID --key value ...` as a dict; the bare first word is `_id`."""
    out, i = {}, 0
    while i < len(args):
        a = args[i]
        if a.startswith("--") and i + 1 < len(args):
            out[a[2:]] = args[i + 1]
            i += 2
        else:
            out.setdefault("_id", a)
            i += 1
    return out


if __name__ == "__main__":
    main()
