"""Who this copy of Job Hunter belongs to, and their setup: details, CVs, writing samples, industries, Claude.

Everything personal lives in profile/ (and is left out of a shareable copy, see scripts/share.py):
  profile/user.json            name and contact details (the letter header and file names), setup progress,
                               tailor_cvs (may Claude tailor CVs per role)
  profile/cvs.json             the CVs: [{key, file, path?, note?, uploaded}]; files in profile/cvs/ unless `path` says otherwise
  profile/sample_letters.json  writing samples: [{id, file, uploaded}]; files in profile/sample-letters/
  profile/industries.json      what the user wants, in their own words: [{key, name, notes?, cv?}]; each is a dashboard
                               category ("sector" on a role is the industry's name)
  profile/claude.json          written by the /job-hunter-setup skill once Claude is connected: {connected_on, task, schedule}

  python3 scripts/user.py              # print a summary of the setup
  python3 scripts/user.py cvs          # the CVs: key, file on disk, note
"""
import datetime
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
PROFILE = ROOT / "profile"
USER = PROFILE / "user.json"
CVS = PROFILE / "cvs.json"
CV_DIR = PROFILE / "cvs"
SAMPLES = PROFILE / "sample_letters.json"
SAMPLE_DIR = PROFILE / "sample-letters"
INDUSTRIES = PROFILE / "industries.json"
CLAUDE = PROFILE / "claude.json"
MAX_SAMPLES = 5
# One colour per industry, in order, all readable on the dashboard's graphite (and distinct from the stage colours).
PALETTE = ["#93B3EA", "#B8A9EE", "#66D7B6", "#EF98CA", "#7DCBEB", "#E8C07A", "#A3D977", "#F2A07B", "#C5B3D9", "#8FD3D0"]


def _read(path, default):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return default


def _write(path, data):
    sys.path.insert(0, str(ROOT / "scripts"))
    import store
    store.atomic_write(path, json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def details():
    return _read(USER, {})


def name():
    return (details().get("name") or "").strip() or "Job Hunter user"


def contact_line():
    d = details()
    parts = [d.get("city"), d.get("phone"), d.get("email"), (d.get("linkedin") or "").replace("https://", "").replace("www.", "")]
    return " | ".join(p.strip() for p in parts if isinstance(p, str) and p.strip())


def tailoring():
    """Whether Claude may tailor CVs per role (Setup > CVs): reorder, trim, and borrow lines from the user's other CVs."""
    return bool(details().get("tailor_cvs"))


def cvs():
    return [c for c in _read(CVS, []) if isinstance(c, dict) and c.get("key")]


def cv_path(c):
    if c.get("path"):
        return pathlib.Path(c["path"]).expanduser()
    return CV_DIR / c.get("file", "")


def cv_file(key):
    """The file on disk for a CV key ("CV Tech"), or None. A CV may list older file names to try (`also`)."""
    for c in cvs():
        if c["key"] == key:
            for p in [cv_path(c)] + [cv_path(c).parent / n for n in c.get("also", [])]:
                if p.is_file():
                    return p
    return None


def default_cv(sector=None):
    """The CV for a role in this industry: the industry's own choice, else the first CV."""
    for i in industries():
        if sector and i.get("name") == sector and i.get("cv"):
            return i["cv"]
    cs = cvs()
    return cs[0]["key"] if cs else "CV"


def samples():
    return [s for s in _read(SAMPLES, []) if isinstance(s, dict) and s.get("file")]


def industries():
    out = []
    for n, i in enumerate(_read(INDUSTRIES, [])):
        if isinstance(i, dict) and i.get("name"):
            i = dict(i)
            i.setdefault("key", slug(i["name"]))
            i["color"] = i.get("color") or PALETTE[n % len(PALETTE)]
            out.append(i)
    return out


def claude():
    return _read(CLAUDE, {})


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-")[:24] or "x"


def state():
    """Everything the setup window shows."""
    d = details()
    st = {
        "details": dict({k: d.get(k, "") for k in ("name", "email", "phone", "city", "linkedin")},
                        locations=[c for c in d.get("locations") or [] if isinstance(c, str)]),
        "cvs": [{"key": c["key"], "file": c.get("file") or cv_path(c).name, "note": c.get("note", ""),
                 "uploaded": c.get("uploaded"), "found": bool(cv_file(c["key"]))} for c in cvs()],
        "tailor_cvs": bool(d.get("tailor_cvs")),
        "samples": [{"id": s.get("id"), "file": s["file"], "uploaded": s.get("uploaded")} for s in samples()],
        "legacy_samples": (PROFILE / "examples.md").is_file(),
        "industries": industries(),
        "claude": claude(),
        "setup_complete": bool(d.get("setup_complete")),
        "folder": str(ROOT),
        "max_samples": MAX_SAMPLES,
    }
    st["ready"] = {
        "details": bool(st["details"]["name"] and st["details"]["email"]),
        "cvs": any(c["found"] for c in st["cvs"]),
        "samples": bool(st["samples"]) or st["legacy_samples"],
        "industries": bool(st["industries"]),
        "claude": bool(st["claude"].get("connected_on")),
    }
    return st


def today():
    return datetime.date.today().isoformat()


def main():
    if sys.argv[1:2] == ["cvs"]:
        for c in cvs():
            p = cv_file(c["key"])
            print(f"{c['key']:<24} {p or 'MISSING: ' + str(cv_path(c))}  {c.get('note', '')}")
        return
    s = state()
    print(json.dumps({k: s[k] for k in ("details", "ready", "setup_complete")}, indent=2))
    print("industries:", ", ".join(i["name"] for i in s["industries"]))
    print("cvs:", ", ".join(c["key"] for c in s["cvs"]))
    print("samples:", len(s["samples"]), "(+ examples.md)" if s["legacy_samples"] else "")


if __name__ == "__main__":
    main()
