"""Make a tailored copy of the user's CV for one role, from a spec of allowed changes.

  python3 scripts/tailor_cv.py <job id> <spec.json>    # write cvs/<name>.docx and .pdf, status "suggested"
  python3 scripts/tailor_cv.py --approve <job id>      # mark it approved (the extension's Approve button does this)
  python3 scripts/tailor_cv.py --show <job id>         # print the status and the list of changes

Spec (JSON):
  {
    "reason":  "one line: why a tailored CV helps for this role",
    "summary": "optional new Professional Summary, using only facts from facts.md and the CV",
    "bullets": {"<Employer A>": [5, 1, "CV Tech:3", 2], "<Employer B>": [2, 1]},   # bullets to keep, in the new order
    "skills":  ["Financial Modelling", "Stakeholder Management"]   # optional: skills from the user's CVs, in order
    "cv":      "CV Tech"                                            # optional: start from another of the user's CVs
  }

In `bullets`, a number is one of this CV's own bullets for that employer (1 is the first). "<CV key>:<n>" borrows bullet n
for the same employer from another of the user's CVs, word for word with its formatting; that's how a line from one CV
moves into another. Bullets are never borrowed across employers, and `skills` may include skills from the other CVs.

It only works when the user has CV tailoring switched on (Setup > CVs). It may only reorder, trim, re-emphasise or
borrow what is already in the user's CVs and facts.md. It refuses a summary with a dash or with any word or figure not
found in facts.md or the CVs, refuses unknown bullets or skills, never drops a whole job, and checks the finished document
for dashes. The source CV is copied, never changed. Status and a readable list of changes go to data/tailored/<id>.json,
which the panel shows before the user approves it.
"""
import copy
import datetime
import json
import pathlib
import re
import shutil
import sys
import unicodedata

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from docx import Document  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402

import cv_pdf  # noqa: E402,F401
import word_pdf  # noqa: E402
import cvparse  # noqa: E402
import facts  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parent.parent
JOBS = ROOT / "data" / "jobs.json"
OUT = ROOT / "cvs"
STATUS = ROOT / "data" / "tailored"
sys.path.insert(0, str(ROOT / "scripts"))
import user  # noqa: E402

NAME = user.name()
DATE_RANGE = re.compile(r"[A-Za-z]{3,9}\.?\s+\d{4}\s*–\s*[A-Za-z]{3,9}\.?\s+\d{4}")


def safe(s):
    return re.sub(r"[^\w&' -]+", "", s).strip()


def fold(s):
    return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower().strip()


def short(s, n=9):
    w = s.split()
    return " ".join(w[:n]) + ("..." if len(w) > n else "")


def blocks(doc):
    """The paragraphs tailoring may touch: summary, each job's bullets (by company), skills."""
    out = {"summary": [], "jobs": [], "skills": []}
    section = None
    for p in doc.paragraphs:
        if not p.text.strip():
            continue
        h = cvparse._heading(p)
        if h:
            section = h
            continue
        if section == "summary":
            out["summary"].append(p)
        elif section == "skills":
            out["skills"].append(p)
        elif section == "experience":
            rest, dates = cvparse._dates(p.text)
            if cvparse._is_list(p):
                if out["jobs"]:
                    out["jobs"][-1]["bullets"].append(p)
            elif cvparse._bold_start(p) and not dates and cvparse.SPLIT.search(p.text):
                out["jobs"].append({"company": cvparse._company(p.text)["company"], "bullets": []})
    return out


def find_job(jobs, name):
    return next((x for x in jobs if fold(x["company"]).startswith(fold(name)[:6])), None)


def other_cv(key, cache={}):
    """Another of the user's CVs, parsed: {"jobs": [...], "skills": [...]}, or None if it has no file."""
    if key not in cache:
        path = cvparse.cv_path(key)
        cache[key] = blocks(Document(str(path))) if path else None
    return cache[key]


def borrowed(template, source):
    """A copy of this CV's bullet `template` (its list style and spacing) holding the runs of `source` from another CV."""
    new = copy.deepcopy(template._p)
    for child in list(new):
        if child.tag != qn("w:pPr"):
            new.remove(child)
    for r in source._p.findall(qn("w:r")):
        new.append(copy.deepcopy(r))
    return new


def skill_list(paras):
    return [s for p in paras for s in (x.strip() for x in p.text.split("|")) if s]


def set_text(p, text):
    """Replace a paragraph's text, keeping the first run's formatting."""
    runs = p.runs
    runs[0].text = text
    for r in runs[1:]:
        r._r.getparent().remove(r._r)


def check_summary(text, corpus):
    probs = facts.dash_problems(text)
    bad = corpus.untraceable(text)
    if bad:
        probs.append("uses words or figures not in facts.md or the CV: " + ", ".join(dict.fromkeys(bad)))
    words = len(text.split())
    if not 25 <= words <= 90:
        probs.append(f"is {words} words; keep it between 25 and 90")
    if re.search(r"\b(passionate|leverage|synergy|dynamic|results-driven|proven track record)\b", text, re.I):
        probs.append("uses stock CV phrasing")
    return probs


def tailor(job_id, spec):
    jobs = json.loads(JOBS.read_text())["jobs"]
    job = next((j for j in jobs if j["id"] == job_id), None)
    if not job:
        sys.exit(f"unknown job id {job_id}")
    if not user.tailoring():
        sys.exit("CV tailoring is switched off (Setup > CVs). Use the user's CV as it is.")
    key = spec.get("cv") or job.get("cv") or "CV"
    src = cvparse.cv_path(key)
    if not src:
        sys.exit(f"no CV file for {key!r}")
    problems, changes = [], []
    diff = {"summary": None, "bullets": {}, "skills": None}

    firm = re.split(r"\s+\(", job["firm"])[0]
    base = OUT / f"{NAME} - CV {safe(firm)} {safe(job['title'])}"[:170]
    docx_path, pdf_path = base.with_suffix(".docx"), base.with_suffix(".pdf")
    OUT.mkdir(exist_ok=True)
    tmp = OUT / f".{job_id}.docx"
    shutil.copyfile(src, tmp)
    doc = Document(str(tmp))
    b = blocks(doc)
    source_text = [p.text for p in Document(str(src)).paragraphs]

    # summary
    if spec.get("summary"):
        new = re.sub(r"\s+", " ", spec["summary"]).strip()
        probs = check_summary(new, facts.corpus())
        if probs:
            problems += ["summary " + x for x in probs]
        elif b["summary"]:
            old = " ".join(p.text.strip() for p in b["summary"])
            set_text(b["summary"][0], new)
            for p in b["summary"][1:]:
                p._p.getparent().remove(p._p)
            diff["summary"] = {"before": old, "after": new}
            changes.append("Professional Summary rewritten to lead with what this role asks for.")

    # bullets: keep and reorder
    for name, order in (spec.get("bullets") or {}).items():
        job_block = find_job(b["jobs"], name)
        if not job_block:
            problems.append(f"no job called {name!r} on {key}")
            continue
        paras = job_block["bullets"]
        texts = [p.text.strip() for p in paras]
        if not order or len(set(map(str, order))) != len(order):
            problems.append(f"{name}: list each bullet once, at least one")
            continue
        kept, shown, added, bad = [], [], [], []
        for i in order:
            if isinstance(i, int) and not isinstance(i, bool):
                if not 1 <= i <= len(paras):
                    bad.append(f"{i} (this CV has {len(paras)} bullets for {name})")
                    continue
                kept.append(paras[i - 1]._p)
                shown.append(texts[i - 1])
                continue
            other, _, n = str(i).rpartition(":")
            other_cvs = {c["key"] for c in user.cvs()} - {key}
            odoc = other_cv(other) if other in other_cvs else None
            src_job = find_job(odoc["jobs"], name) if odoc else None
            if not n.isdigit() or not src_job or not 1 <= int(n) <= len(src_job["bullets"]):
                bad.append(f"{i!r} (borrow as \"<one of: {', '.join(sorted(other_cvs))}>:<bullet number>\", "
                           f"from the same employer)")
                continue
            sp = src_job["bullets"][int(n) - 1]
            text = sp.text.strip()
            if fold(text) in {fold(t) for t in texts}:
                bad.append(f"{i!r} (already on this CV as bullet {[fold(t) for t in texts].index(fold(text)) + 1})")
                continue
            kept.append(borrowed(paras[0], sp))
            shown.append(text)
            added.append((other, text))
        if bad:
            problems.append(f"{name}: unknown bullets " + "; ".join(bad))
            continue
        own = [i for i in order if isinstance(i, int)]
        dropped = [texts[i] for i in range(len(paras)) if i + 1 not in own]
        anchor = paras[0]._p.getprevious()
        for p in paras:
            p._p.getparent().remove(p._p)
        for el in kept:
            anchor.addnext(el)
            anchor = el
        diff["bullets"][job_block["company"]] = {"order": shown, "dropped": dropped, "was": texts,
                                                  "added": [{"from": o, "text": t} for o, t in added]}
        if shown and shown[0] != texts[0]:
            changes.append(f"{job_block['company']}: put “{short(shown[0])}” first"
                           + (" and reordered the rest." if len(shown) > 2 else "."))
        for o, t in added:
            changes.append(f"{job_block['company']}: added “{short(t)}” from your {o}.")
        for d in dropped:
            changes.append(f"{job_block['company']}: left out “{short(d)}” to keep the page focused.")

    # skills
    if spec.get("skills"):
        have = skill_list(b["skills"])
        others = {s for c in user.cvs() if c["key"] != key and other_cv(c["key"]) for s in skill_list(other_cv(c["key"])["skills"])}
        want = [s.strip() for s in spec["skills"]]
        unknown = [s for s in want if s not in have and s not in others]
        if unknown:
            problems.append("skills not on any of the user's CVs: " + ", ".join(unknown))
        elif b["skills"]:
            set_text(b["skills"][0], " | ".join(want))
            for p in b["skills"][1:]:
                p._p.getparent().remove(p._p)
            diff["skills"] = {"before": have, "after": want}
            changes.append("Skills: " + " | ".join(want) + "."
                           + ("" if all(s in have for s in want) else
                              " (" + ", ".join(s for s in want if s not in have) + " from your other CVs.)"))

    if problems:
        tmp.unlink()
        sys.exit("Tailored CV rejected:\n  " + "\n  ".join(problems))
    if not changes:
        tmp.unlink()
        sys.exit("Tailored CV rejected: the spec changes nothing.")

    # the finished page: no dashes except the date ranges the CV already had
    for p in doc.paragraphs:
        t = p.text
        if t in source_text:
            t = DATE_RANGE.sub("", t)  # "Oct. 2023 – Aug. 2025" is the CV's own date format
        if facts.dash_problems(t):
            tmp.unlink()
            sys.exit(f"Tailored CV rejected: dash in “{short(p.text, 12)}”")
    doc.save(str(tmp))
    tmp.replace(docx_path)
    pages = word_pdf.export(docx_path, pdf_path)  # Word for an exact match; Chrome rendering if Word fails
    if pages and pages > 1:
        changes.append(f"Note: the PDF runs to {pages} pages; trim a bullet to bring it back to one.")

    STATUS.mkdir(parents=True, exist_ok=True)
    record = {
        "id": job_id, "firm": job["firm"], "title": job["title"], "status": "suggested",
        "created": datetime.datetime.now().isoformat(timespec="seconds"), "approved_at": None,
        "source_cv": key, "source_file": src.name, "docx": docx_path.name, "pdf": pdf_path.name, "pages": pages,
        "reason": spec.get("reason", ""), "changes": changes, "diff": diff, "spec": spec,
    }
    (STATUS / f"{job_id}.json").write_text(json.dumps(record, indent=2, ensure_ascii=False))
    print(docx_path.relative_to(ROOT))
    print(pdf_path.relative_to(ROOT))
    for c in changes:
        print(" -", c)
    return record


def set_status(job_id, approved):
    f = STATUS / f"{job_id}.json"
    if not f.exists():
        return None
    rec = json.loads(f.read_text())
    rec["status"] = "approved" if approved else "suggested"
    rec["approved_at"] = datetime.datetime.now().isoformat(timespec="seconds") if approved else None
    f.write_text(json.dumps(rec, indent=2, ensure_ascii=False))
    return rec


def main():
    a = sys.argv[1:]
    if len(a) == 2 and a[0] == "--approve":
        rec = set_status(a[1], True)
        print("approved" if rec else "no tailored CV for that id")
    elif len(a) == 2 and a[0] == "--show":
        f = STATUS / f"{a[1]}.json"
        if not f.exists():
            sys.exit("no tailored CV for that id")
        rec = json.loads(f.read_text())
        print(rec["status"], "|", rec["docx"])
        for c in rec["changes"]:
            print(" -", c)
    elif len(a) == 2:
        tailor(a[0], json.loads(pathlib.Path(a[1]).read_text()))
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
