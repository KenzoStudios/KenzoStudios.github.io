"""Render a CV .docx to PDF, keeping its layout: fonts, sizes, bold/italic/small caps, bullets, rules and the
right-hand dates and places. The .docx is turned into HTML that mirrors it, then printed by headless Chrome
(scripts/dev/print_pdf.mjs). Word isn't used, so nothing opens on screen.

Usage: python3 scripts/cv_pdf.py <in.docx> <out.pdf> [--html out.html]
"""
import html
import pathlib
import re
import subprocess
import sys
import tempfile

from docx import Document
from docx.oxml.ns import qn

ROOT = pathlib.Path(__file__).resolve().parent.parent
PRINT = ROOT / "scripts" / "dev" / "print_pdf.mjs"
TW = 1 / 20  # twips to points


def _val(el, tag, attr="val"):
    if el is None:
        return None
    c = el.find(qn(tag))
    return None if c is None else c.get(qn("w:" + attr))


def _on(el, tag):
    """A toggle property (w:b, w:i): present and not switched off."""
    if el is None:
        return None
    c = el.find(qn(tag))
    if c is None:
        return None
    return c.get(qn("w:val")) not in ("0", "false")


class Styles:
    def __init__(self, doc):
        root = doc.styles.element
        self.by_id = {s.get(qn("w:styleId")): s for s in root.findall(qn("w:style"))}
        dd = root.find(qn("w:docDefaults"))
        self.default_rpr = dd.find(qn("w:rPrDefault")).find(qn("w:rPr")) if dd is not None else None

    def chain(self, sid):
        out = []
        while sid and sid in self.by_id and len(out) < 10:
            s = self.by_id[sid]
            out.insert(0, s)
            sid = _val(s, "w:basedOn")
        return out

    def ppr(self, sid):
        return [s.find(qn("w:pPr")) for s in self.chain(sid)]

    def rpr(self, sid):
        return [s.find(qn("w:rPr")) for s in self.chain(sid)]


class Numbering:
    def __init__(self, doc):
        self.levels = {}
        try:
            root = doc.part.numbering_part.element
        except Exception:
            return
        abstract = {a.get(qn("w:abstractNumId")): a for a in root.findall(qn("w:abstractNum"))}
        for n in root.findall(qn("w:num")):
            a = abstract.get(_val(n, "w:abstractNumId"))
            if a is None:
                continue
            for lvl in a.findall(qn("w:lvl")):
                self.levels[(n.get(qn("w:numId")), lvl.get(qn("w:ilvl")))] = lvl

    def get(self, num_id, ilvl):
        lvl = self.levels.get((num_id, ilvl or "0"))
        if lvl is None:
            return None
        ind = lvl.find(qn("w:pPr"))
        ind = ind.find(qn("w:ind")) if ind is not None else None
        return {
            "text": _val(lvl, "w:lvlText") or "•",
            "left": int(ind.get(qn("w:left")) or 0) if ind is not None else 360,
            "hanging": int(ind.get(qn("w:hanging")) or 0) if ind is not None else 360,
            "rpr": lvl.find(qn("w:rPr")),
        }


def _merge_run(props, rpr):
    if rpr is None:
        return
    for tag, key in (("w:b", "b"), ("w:i", "i"), ("w:smallCaps", "sc"), ("w:caps", "caps")):
        v = _on(rpr, tag)
        if v is not None:
            props[key] = v
    sz = _val(rpr, "w:sz")
    if sz:
        props["sz"] = int(sz) / 2
    col = _val(rpr, "w:color")
    if col and col != "auto":
        props["color"] = "#" + col
    u = _val(rpr, "w:u")
    if u:
        props["u"] = u != "none"
    sp = _val(rpr, "w:spacing")
    if sp:
        props["ls"] = int(sp) * TW
    font = rpr.find(qn("w:rFonts"))
    if font is not None and font.get(qn("w:ascii")):
        props["font"] = font.get(qn("w:ascii"))


def _run_css(p):
    css = [f"font-size:{p.get('sz', 11)}pt"]
    if p.get("b"):
        css.append("font-weight:700")
    if p.get("i"):
        css.append("font-style:italic")
    if p.get("sc"):
        css.append("font-variant:small-caps")
    if p.get("caps"):
        css.append("text-transform:uppercase")
    if p.get("color"):
        css.append(f"color:{p['color']}")
    if p.get("u"):
        css.append("text-decoration:underline")
    if p.get("ls"):
        css.append(f"letter-spacing:{p['ls']:.2f}pt")
    return ";".join(css)


def _para(p, styles, numbering, text_w):
    pr = p._p.pPr
    sid = _val(pr, "w:pStyle") or "Normal"
    pprs = styles.ppr("Normal") + styles.ppr(sid) + [pr]
    ind, sp, jc, tabs = {}, {}, None, []
    for x in pprs:
        if x is None:
            continue
        i = x.find(qn("w:ind"))
        if i is not None:
            for k in ("left", "right", "hanging", "firstLine"):
                v = i.get(qn("w:" + k))
                if v is not None:
                    ind[k] = int(v)
        s = x.find(qn("w:spacing"))
        if s is not None:
            for k in ("before", "after", "line", "lineRule"):
                v = s.get(qn("w:" + k))
                if v is not None:
                    sp[k] = v
        jc = _val(x, "w:jc") or jc
        t = x.find(qn("w:tabs"))
        if t is not None:
            tabs = sorted(int(tb.get(qn("w:pos"))) for tb in t.findall(qn("w:tab")) if tb.get(qn("w:val")) != "clear")
    base = {}
    _merge_run(base, styles.default_rpr)
    for r in styles.rpr("Normal") + styles.rpr(sid):
        _merge_run(base, r)

    marker = ""
    num = pr.find(qn("w:numPr")) if pr is not None else None
    if num is not None:
        lvl = numbering.get(_val(num, "w:numId"), _val(num, "w:ilvl"))
        if lvl:
            ind.setdefault("left", lvl["left"])
            ind.setdefault("hanging", lvl["hanging"])
            mp = dict(base)
            _merge_run(mp, lvl["rpr"])
            marker = f'<span class="mk" style="{_run_css(mp)};font-weight:400;font-style:normal">' \
                     f'{html.escape(lvl["text"])}</span>'

    # walk the paragraph's content in order: runs, hyperlinks, drawings
    segs, rule = [[]], None

    def run(r, extra=None):
        nonlocal rule
        props = dict(base)
        rpr = r.find(qn("w:rPr"))
        if rpr is not None:
            rs = _val(rpr, "w:rStyle")
            if rs:
                for x in styles.rpr(rs):
                    _merge_run(props, x)
        _merge_run(props, rpr)
        if extra:
            props.update(extra)
        css = _run_css(props)
        for c in r:
            tag = c.tag.split("}")[1]
            if tag == "t":
                parts = re.split(r"( {3,})", c.text or "")
                for k, part in enumerate(parts):
                    if k % 2:
                        segs.append([("gap", "")])
                    elif part:
                        segs[-1].append(("text", f'<span style="{css}">{html.escape(part)}</span>'))
            elif tag == "tab":
                segs.append([("tab", "")])
            elif tag == "br":
                segs[-1].append(("text", "<br>"))
            elif tag in ("drawing", "AlternateContent"):
                ext = c.find(".//" + qn("wp:extent"))
                fill = c.find(".//{http://schemas.openxmlformats.org/drawingml/2006/main}srgbClr")
                if ext is not None and int(ext.get("cy")) <= 50800:
                    rule = (int(ext.get("cx")) / 12700, max(0.75, int(ext.get("cy")) / 12700),
                            "#" + (fill.get("val") if fill is not None else "000000"))

    for child in p._p:
        tag = child.tag.split("}")[1]
        if tag == "r":
            run(child)
        elif tag == "hyperlink":
            for r in child.findall(qn("w:r")):
                run(r)

    left = ind.get("left", 0) * TW
    hang = ind.get("hanging", 0) * TW
    first = ind.get("firstLine", 0) * TW
    css = [f"padding-left:{left:.2f}pt", f"padding-right:{ind.get('right', 0) * TW:.2f}pt",
           f"margin-top:{int(sp.get('before', 0)) * TW:.2f}pt", f"margin-bottom:{int(sp.get('after', 0)) * TW:.2f}pt",
           f"font-size:{base.get('sz', 11)}pt"]
    line = sp.get("line")
    if line and sp.get("lineRule") == "exact":
        css.append(f"line-height:{int(line) * TW:.2f}pt;height:auto")
    elif line:
        css.append(f"line-height:{1.15 * int(line) / 240:.3f}")
    if marker:
        css.append(f"text-indent:{-hang:.2f}pt")
    elif first:
        css.append(f"text-indent:{first:.2f}pt")
    if jc in ("both", "distribute"):
        css.append("text-align:justify")
    elif jc in ("center", "right"):
        css.append(f"text-align:{jc}")
    if rule:
        w, h, col = rule
        return f'<div class="p" style="{";".join(css)}"><div style="width:{w:.1f}pt;max-width:100%;height:{h:.2f}pt;' \
               f'background:{col}"></div></div>'

    body = "".join(x[1] for x in segs[0])
    if marker:
        body = f'{marker}<span style="display:inline-block;width:0"></span>' + body
        css.append(f"--mk:{hang:.2f}pt")
    rest = []
    for k, seg in enumerate(segs[1:], 1):
        inner = "".join(x[1] for x in seg if x[0] == "text")
        if not inner.strip() or not re.sub(r"<[^>]+>|\s", "", inner):
            continue
        kind = seg[0][0]
        # A tab stop near the right edge (or a run of spaces) is these CVs' way of pushing dates and places right.
        tab = tabs[min(k - 1, len(tabs) - 1)] * TW if tabs and kind == "tab" else None
        if tab is None or tab > 0.6 * text_w:
            rest.append(f'<span class="r">{inner.strip()}</span>')
        else:
            rest.append(f'<span class="t" style="left:{tab:.2f}pt">{inner}</span>')
    if not body and not rest:
        body = "&nbsp;"
    return f'<div class="p{" li" if marker else ""}" style="{";".join(css)}">{body}{"".join(rest)}</div>'


def to_html(path):
    doc = Document(str(path))
    sect = doc.sections[0]
    pw, ph = sect.page_width.pt, sect.page_height.pt
    ml, mr, mt, mb = (sect.left_margin.pt, sect.right_margin.pt, sect.top_margin.pt, sect.bottom_margin.pt)
    styles, numbering = Styles(doc), Numbering(doc)
    text_w = pw - ml - mr
    body = "\n".join(_para(p, styles, numbering, text_w) for p in doc.paragraphs)
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>
@page{{size:{pw:.2f}pt {ph:.2f}pt;margin:{mt:.2f}pt {mr:.2f}pt {mb:.2f}pt {ml:.2f}pt}}
html,body{{margin:0;padding:0}}
body{{font-family:Arial,Helvetica,sans-serif;color:#000;-webkit-print-color-adjust:exact;print-color-adjust:exact}}
.p{{position:relative;line-height:1.15;white-space:pre-wrap;overflow-wrap:break-word}}
.p .r{{position:absolute;right:0;top:0;white-space:nowrap}}
.p .t{{position:absolute;top:0;white-space:nowrap}}
.p .mk{{display:inline-block;width:var(--mk);text-indent:0}}
</style></head><body>
{body}
</body></html>"""


def render(docx_path, pdf_path, html_out=None):
    """Write the PDF and return its page count."""
    page = to_html(docx_path)
    with tempfile.TemporaryDirectory() as tmp:
        h = pathlib.Path(html_out) if html_out else pathlib.Path(tmp) / "cv.html"
        h.write_text(page)
        out = subprocess.run(["node", str(PRINT), str(h), str(pdf_path)], capture_output=True, text=True, timeout=120)
        if out.returncode:
            raise RuntimeError("PDF render failed: " + (out.stderr or out.stdout).strip()[-400:])
    m = re.search(r"pages=(\d+)", out.stdout)
    return int(m.group(1)) if m else None


if __name__ == "__main__":
    a = sys.argv[1:]
    if len(a) < 2:
        sys.exit(__doc__)
    extra = a[a.index("--html") + 1] if "--html" in a else None
    print(f"{a[1]} ({render(a[0], a[1], extra)} page)")
