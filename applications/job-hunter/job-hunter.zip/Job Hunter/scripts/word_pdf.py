"""Export .docx files to PDF with Microsoft Word, so the PDF looks exactly as the CV does in Word.

Standard CVs are exported to cvs/standard/ (the user's CV folder is never written to) and re-exported whenever the
.docx is newer than its PDF. Falls back to scripts/cv_pdf.py (headless Chrome) if Word isn't available.

  python3 scripts/word_pdf.py all            # export the four standard CVs if they're missing or out of date
  python3 scripts/word_pdf.py <in.docx> <out.pdf>
"""
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
STANDARD = ROOT / "cvs" / "standard"
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(1, str(ROOT))

SCRIPT = '''
on run argv
    set src to POSIX file (item 1 of argv)
    set dst to item 2 of argv
    tell application "Microsoft Word"
        open src
        set d to active document
        save as d file name dst file format format PDF
        close d saving no
    end tell
end run
'''


def pages(pdf):
    return len(re.findall(rb"/Type\s*/Page(?!s)", pathlib.Path(pdf).read_bytes())) or None


def export(docx, pdf):
    """Write pdf from docx and return its page count. Word first, Chrome rendering as a fallback."""
    docx, pdf = pathlib.Path(docx).resolve(), pathlib.Path(pdf).resolve()
    pdf.parent.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.run(["osascript", "-", str(docx), str(pdf)], input=SCRIPT, text=True, check=True,
                       capture_output=True, timeout=120)
        if pdf.is_file() and pdf.stat().st_mtime >= docx.stat().st_mtime:
            return pages(pdf)
    except (subprocess.SubprocessError, OSError):
        pass
    import cv_pdf
    return cv_pdf.render(docx, pdf)


def standard_pdf(docx):
    """The PDF for a standard CV .docx, exporting it first if it's missing or older than the .docx."""
    docx = pathlib.Path(docx)
    pdf = STANDARD / (docx.stem + ".pdf")
    if not pdf.is_file() or pdf.stat().st_mtime < docx.stat().st_mtime:
        export(docx, pdf)
    return pdf if pdf.is_file() else None


def main():
    if sys.argv[1:] == ["all"]:
        import serve
        for key in serve.CVS:
            src = serve.cv_file(key)
            if src:
                out = standard_pdf(src)
                print(f"{key}: {out.relative_to(ROOT) if out else 'failed'}" + (f" ({pages(out)} page)" if out else ""))
    elif len(sys.argv) == 3:
        print(f"pages={export(sys.argv[1], sys.argv[2])}")
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
