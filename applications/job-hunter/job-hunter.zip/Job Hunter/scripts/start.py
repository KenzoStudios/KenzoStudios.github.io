"""Start Job Hunter and say where things stand. What Claude runs when the user types "run" (see CLAUDE.md).

  python3 scripts/start.py            # start the dashboard if it isn't running, open it, print the status as JSON
  python3 scripts/start.py --no-open  # the same, without opening the browser

The status says whether the dashboard is up, which Python packages are missing, how far setup has got (the same `ready`
flags as the setup window) and, once set up, how many roles are waiting. The server keeps running after Claude's session
ends; its output goes to data/serve.log.
"""
import importlib.util
import json
import os
import pathlib
import platform
import subprocess
import sys
import time
import urllib.request
import webbrowser
from collections import Counter

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import user  # noqa: E402

URL = f"http://localhost:{os.environ.get('JH_PORT', 8765)}"
PACKAGES = {"docx": "python-docx", "openpyxl": "openpyxl"}


def running():
    try:
        with urllib.request.urlopen(URL + "/api/setup", timeout=2) as r:
            return r.status == 200
    except OSError:
        return False


def start():
    if running():
        return True
    (ROOT / "data").mkdir(exist_ok=True)
    log = open(ROOT / "data" / "serve.log", "ab")
    subprocess.Popen([sys.executable, str(ROOT / "serve.py")], cwd=ROOT, stdout=log, stderr=log,
                     stdin=subprocess.DEVNULL, start_new_session=True)
    for _ in range(40):
        time.sleep(0.25)
        if running():
            return True
    return False


def roles():
    try:
        data = json.loads((ROOT / "data" / "jobs.json").read_text())
    except (OSError, ValueError):
        return {}
    jobs = data.get("jobs", [])
    status, stage = Counter(j.get("status") for j in jobs), Counter(j.get("stage") for j in jobs)
    runs = data.get("runs") or []
    return {"to_look_at": status["new"], "interested": status["interested"], "applied": status["applied"],
            "interviews": stage["interview"] + stage["assessment"] + stage["screening"], "offers": stage["offer"],
            "last_search": runs[-1].get("date") if runs else None}


def main():
    up = start()
    if up and "--no-open" not in sys.argv:
        webbrowser.open(URL)
    st = user.state()
    out = {
        "dashboard": URL if up else None,
        "log": None if up else str(ROOT / "data" / "serve.log"),
        "python": platform.python_version(),
        "missing_packages": [p for m, p in PACKAGES.items() if importlib.util.find_spec(m) is None],
        "setup": st["ready"],
        "setup_complete": st["setup_complete"],
        "name": st["details"]["name"],
        "industries": [i["name"] for i in st["industries"]],
        "roles": roles(),
    }
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
