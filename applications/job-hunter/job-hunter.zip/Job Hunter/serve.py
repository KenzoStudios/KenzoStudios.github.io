"""Local server for the Job Hunter dashboard. Run: python3 serve.py, then open http://localhost:8765

Serves dashboard.html, the jobs list, the cover letters and the four CVs, and records the status
buttons (interested / applied / pass) back into data/jobs.json so the daily search can learn from them.
Also answers the Job Hunter browser extension (see extension/README.md):
  POST /api/active {id}                 the dashboard's Apply button: remember which role is being applied for
  GET  /api/autofill?url=<page>|id=<id> the role a page belongs to, with the fields, CV entries, answers and files
  GET  /api/roles                       every role, for the extension's picker
  GET  /api/file/{cv,letters,cvs}/<name>  a CV, cover letter or tailored CV to attach
  POST /api/tailored/<id>/approve {approved}  the user's approval of a suggested tailored CV
And the tracker, apply sessions and answer bank (docs/API.md is the contract):
  POST /api/stage {id, stage, date?, note?}       POST /api/event {id, kind, at, ...}   POST /api/followup {id, date}
  GET  /api/queue?sector=&include=interested     GET|POST /api/session              POST /api/snapshot {id, url, fields, files}
  GET  /api/answers/<id>                          GET /snapshots/<file>, /prep/<file>
  GET  /api/tracker.xlsx                          every application as an Excel workbook, colour-coded by status
  GET  /api/setup                                 the setup window's state (details, CVs, samples, industries, Claude)
  PUT  /api/setup/details|industries|cv-note|options     POST /api/setup/upload?kind=cv|sample&name=&label= (the file as the body)
  POST /api/setup/remove {kind, id}               POST /api/setup/complete      POST /api/setup/share (a copy with no personal data)
  GET|PUT /api/my-answers {answers}               the user's standing answers (profile/my_answers.json)
  POST /api/reveal {kind, name}                   show a CV or letter in Finder (open -R), for uploads a site refuses
Listens on 127.0.0.1 only, and the extension and tracker endpoints answer only requests addressed to localhost or
127.0.0.1. Every write to data/jobs.json is atomic and made under a lock shared with the daily run's scripts.
"""
import datetime
import json
import subprocess
import mimetypes
import os
import pathlib
import re
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import store  # noqa: E402
import tracker  # noqa: E402
import user  # noqa: E402

JOBS = ROOT / "data" / "jobs.json"
SESSION_FILE = ROOT / "data" / "session.json"
SNAPSHOTS = ROOT / "snapshots"
PREP = ROOT / "prep"
CV_DIR = user.CV_DIR


class _CVKeys:
    """The CV keys from profile/cvs.json, read fresh each time (the setup window can add and remove CVs)."""
    def __contains__(self, key):
        return any(c["key"] == key for c in user.cvs())

    def __iter__(self):
        return iter([c["key"] for c in user.cvs()])


CVS = _CVKeys()
STATUSES = {"new", "interested", "applied", "pass"}
ID = re.compile(r"[0-9a-f]{6,20}")
PORT = int(os.environ.get("JH_PORT", 8765))
HOSTS = {f"127.0.0.1:{PORT}", f"localhost:{PORT}"}
# The role last opened with the dashboard's Apply button (or the apply session's current role). Kept in memory only.
ACTIVE = {}
ACTIVE_LOCK = threading.Lock()
# The apply session: {"active", "ids", "index", "started", ...}. Kept in memory and in data/session.json.
SESSION_LOCK = threading.Lock()


def cv_file(key):
    """The file on disk for a CV key ("CV Tech"), or None."""
    return user.cv_file(key)


def load():
    return store.load(JOBS)


def autofill():
    """scripts/autofill.py and tailor_cv.py, imported on first use so the dashboard never waits on python-docx."""
    import autofill as af
    import tailor_cv
    return af, tailor_cv


def answers():
    import answers as ans
    return ans


def my_answers():
    import my_answers as ma
    return ma


# POST /api/reveal: which files may be shown in Finder. Only these four places, only files directly inside them.
REVEAL_DRY = os.environ.get("JH_REVEAL_DRY") == "1"  # tests: say what would be shown, don't open Finder


def reveal_path(kind, name):
    """The file a reveal request names, or None. cv: a CV key (its standard PDF, else the .docx); letters: a cover
    letter; cvs: a tailored CV; standard: a standard CV PDF in cvs/standard/."""
    if not isinstance(name, str) or not name:
        return None
    if kind == "cv":
        if name not in CVS:
            return None
        src = cv_file(name)
        if not src:
            return None
        if src.suffix.lower() == ".pdf":
            return src
        pdf = ROOT / "cvs" / "standard" / (src.stem + ".pdf")
        return pdf if pdf.is_file() else src
    base = {"letters": ROOT / "letters", "cvs": ROOT / "cvs", "standard": ROOT / "cvs" / "standard"}.get(kind)
    target = inside(base, name) if base else None
    return target if target and target.is_file() else None


def inside(base, name):
    """base/name, provided it stays directly inside base."""
    if not name or "/" in name or "\\" in name or name.startswith("."):
        return None
    target = (base / name).resolve()
    return target if target.parent == base.resolve() else None


def update_job(job_id, change):
    """Read, change and save one job under the jobs.json lock. change(job) returns an error message or None.
    Returns (job, error); job is None when the id is unknown."""
    with store.locked(JOBS):
        data = load()
        job = next((j for j in data["jobs"] if j.get("id") == job_id), None)
        if not job:
            return None, "unknown job"
        err = change(job)
        if err:
            return job, err
        store.save(data, JOBS)
        return job, None


def with_flags(job):
    j = dict(job)
    j["answers_ready"] = answers().ready(job.get("id"))
    return j


# ---------------------------------------------------------------- the apply session
def read_session():
    try:
        s = json.loads(SESSION_FILE.read_text())
        if isinstance(s, dict) and isinstance(s.get("ids"), list):
            return s
    except (OSError, ValueError):
        pass
    return {"active": False, "ids": [], "index": 0, "started": None}


SESSION = read_session()


def session_view(jobs=None):
    """The session as the API returns it: the stored fields plus the current role and the total."""
    s = dict(SESSION)
    jobs = jobs if jobs is not None else load()["jobs"]
    cur = None
    if s.get("active") and 0 <= s.get("index", 0) < len(s.get("ids", [])):
        j = next((x for x in jobs if x.get("id") == s["ids"][s["index"]]), None)
        if j:
            cur = {k: j.get(k) for k in ("id", "firm", "title", "url", "status")}
    s["total"] = len(s.get("ids", []))
    s["current"] = cur
    return s


def set_active(job_id):
    with ACTIVE_LOCK:
        ACTIVE.clear()
        if job_id:
            ACTIVE.update(id=job_id, at=time.time())


def session_current_id():
    with SESSION_LOCK:
        s = SESSION
        if s.get("active") and 0 <= s.get("index", 0) < len(s.get("ids", [])):
            return s["ids"][s["index"]], s["index"], len(s["ids"])
    return None, None, None


def same_host(a, b):
    def host(u):
        try:
            h = (urllib.parse.urlsplit(u).hostname or "").lower()
        except ValueError:
            return ""
        return h[4:] if h.startswith("www.") else h
    return bool(host(a)) and host(a) == host(b)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json", extra=None):
        data = body if isinstance(body, bytes) else body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, code, obj):
        return self.send(code, json.dumps(obj, ensure_ascii=False))

    def error(self, code, msg):
        return self.send_json(code, {"error": msg})

    def send_file(self, path, download_name=None, ctype=None, with_path=False):
        if not path.is_file():
            return self.send(404, '{"error":"not found"}')
        ctype = ctype or mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        extra = {}
        if with_path:  # the extension's "Copy file path" (local requests only: see get_file)
            extra["X-JH-Path"] = urllib.parse.quote(str(path.resolve()))
        if download_name:
            extra["Content-Disposition"] = "inline; filename*=UTF-8''" + urllib.parse.quote(download_name)
        self.send(200, path.read_bytes(), ctype, extra)

    def local_only(self):
        """The extension's endpoints answer only requests addressed to this machine (no DNS rebinding)."""
        if self.headers.get("Host", "") not in HOSTS:
            self.send(403, '{"error":"forbidden"}')
            return False
        return True

    def json_body(self):
        """A JSON body, sent as application/json (which other web pages can't do without asking first)."""
        if not self.headers.get("Content-Type", "").startswith("application/json"):
            return None
        try:
            return json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        except ValueError:
            return None

    # ------------------------------------------------------------ GET
    def do_GET(self):
        url = urllib.parse.urlparse(self.path)
        path = urllib.parse.unquote(url.path)
        q = urllib.parse.parse_qs(url.query)
        if path in ("/", "/dashboard.html"):
            return self.send_file(ROOT / "dashboard.html")
        if path.startswith("/design/") and path.endswith(".html"):
            # Design previews (variants of dashboard.html) during a redesign.
            target = (ROOT / "design" / path[len("/design/"):]).resolve()
            if target.parent != (ROOT / "design").resolve():
                return self.send(403, '{"error":"forbidden"}')
            return self.send_file(target)
        if path == "/api/jobs":
            # Roles whose postings have closed sit in the vault (see scripts/postings.py) and stay off the dashboard.
            data = load()
            data["jobs"] = [with_flags(j) for j in data["jobs"] if not j.get("vault")]
            return self.send(200, json.dumps(data, ensure_ascii=False))
        if path.startswith("/letters/"):
            name = path[len("/letters/"):]
            target = (ROOT / "letters" / name).resolve()
            if target.parent != (ROOT / "letters").resolve():
                return self.send(403, '{"error":"forbidden"}')
            return self.send_file(target, name)
        if path.startswith("/cv/"):
            key = path[len("/cv/"):]
            if key not in CVS:
                return self.send(404, '{"error":"unknown cv"}')
            return self.send_cv(key)
        if path in ("/api/autofill", "/api/roles", "/api/queue", "/api/session", "/api/my-answers", "/api/tracker.xlsx", "/api/setup") or path.startswith(
                ("/api/file/", "/api/answers/", "/snapshots/", "/prep/")):
            if not self.local_only():
                return
        if path == "/api/tracker.xlsx":
            return self.send_tracker_xlsx()
        if path == "/api/setup":
            return self.send_json(200, user.state())
        if path == "/api/autofill":
            return self.get_autofill(q)
        if path == "/api/my-answers":
            return self.send_json(200, my_answers().view())
        if path == "/api/roles":
            af, _ = autofill()
            return self.send(200, json.dumps({"roles": af.roles(load()["jobs"])}, ensure_ascii=False))
        if path.startswith("/api/file/"):
            return self.get_file(path[len("/api/file/"):])
        if path == "/api/queue":
            include = "interested" in ",".join(q.get("include", [])).split(",")
            sector = (q.get("sector") or [""])[0].strip() or None
            return self.send_json(200, {"queue": tracker.queue(load()["jobs"], sector, include)})
        if path == "/api/session":
            with SESSION_LOCK:
                return self.send_json(200, session_view())
        if path.startswith("/api/answers/"):
            job_id = path[len("/api/answers/"):]
            if not ID.fullmatch(job_id):
                return self.error(400, "bad id")
            if not any(j.get("id") == job_id for j in load()["jobs"]):
                return self.error(404, "unknown job")
            return self.send_json(200, answers().bank(job_id))
        if path.startswith("/snapshots/"):
            target = inside(SNAPSHOTS, path[len("/snapshots/"):])
            if not target or target.suffix.lower() != ".pdf":
                return self.send(403, '{"error":"forbidden"}')
            return self.send_file(target, target.name)
        if path.startswith("/prep/"):
            target = inside(PREP, path[len("/prep/"):])
            if not target or target.suffix.lower() != ".md":
                return self.send(403, '{"error":"forbidden"}')
            return self.send_file(target, ctype="text/markdown; charset=utf-8")
        self.send(404, '{"error":"not found"}')

    def get_autofill(self, q):
        af, _ = autofill()
        jobs = load()["jobs"]
        with ACTIVE_LOCK:
            active = dict(ACTIVE)
        page = (q.get("url") or [""])[0]
        cur_id, index, total = session_current_id()
        cur = next((j for j in jobs if j.get("id") == cur_id and not j.get("vault")), None) if cur_id else None
        if q.get("id"):
            job = next((j for j in jobs if j["id"] == q["id"][0] and not j.get("vault")), None)
            how, cands = "picked", []
        else:
            job, how, cands = af.match(page, jobs, active)
            # In an apply session the current role wins on its own posting and anywhere on the same host.
            if cur and (af.norm_url(page) == af.norm_url(cur.get("url", "")) or
                        (af.ats_ids(page) & af.ats_ids(cur.get("url", ""))) or same_host(page, cur.get("url", ""))):
                if job and job is not cur and how in ("url", "ats"):
                    cands = [job]
                job, how = cur, "session"
        sess = {"active": bool(cur_id), "index": index, "total": total, "current": cur_id} if cur_id else {"active": False}
        if not job:
            return self.send(200, json.dumps({"matched": "none", "job": None, "session": sess, "candidates": [
                {"id": j["id"], "firm": j["firm"], "title": j["title"]} for j in cands]}, ensure_ascii=False))
        body = af.payload(job, how, cands)
        body["session"] = sess
        body["answers"] = answers().bank(job["id"])
        body["my_answers"] = my_answers().view()
        if how == "active":
            body["active_minutes"] = int((time.time() - active["at"]) // 60)
        return self.send(200, json.dumps(body, ensure_ascii=False))

    def send_tracker_xlsx(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            out = pathlib.Path(tmp) / "tracker.xlsx"
            try:
                tracker.sheet_xlsx(load()["jobs"], out)
            except ImportError:
                return self.error(500, "openpyxl isn't installed for this Python, so the workbook can't be made")
            body = out.read_bytes()
        name = f"Job Hunter applications {datetime.date.today().isoformat()}.xlsx"
        return self.send(200, body, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                         {"Content-Disposition": f'attachment; filename="{name}"'})

    def send_cv(self, key, with_path=False):
        """A standard CV as a PDF (exported from the .docx with Word), falling back to the .docx itself."""
        src = cv_file(key)
        if not src:
            return self.send(404, '{"error":"unknown cv"}')
        name = user.name()
        if src.suffix.lower() == ".pdf":
            return self.send_file(src, f"{name} - CV.pdf", with_path=with_path)
        import word_pdf
        pdf = word_pdf.standard_pdf(src) if src.suffix.lower() == ".docx" else None
        if pdf:
            return self.send_file(pdf, f"{name} - CV.pdf", with_path=with_path)
        return self.send_file(src, f"{name} - CV{src.suffix.lower()}", with_path=with_path)

    def get_file(self, rest):
        """Only three places: a CV by key, a cover letter in letters/, a tailored CV in cvs/."""
        kind, _, name = rest.partition("/")
        if kind == "cv":
            return self.send_cv(name, with_path=True)
        base = {"letters": ROOT / "letters", "cvs": ROOT / "cvs"}.get(kind)
        target = inside(base, name) if base else None
        if not target:
            return self.send(403, '{"error":"forbidden"}')
        return self.send_file(target, name, with_path=True)

    # ------------------------------------------------------------ POST
    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/status":
            return self.post_status()
        if path == "/api/active":
            return self.post_active()
        m = re.fullmatch(r"/api/tailored/([0-9a-f]{6,20})/approve", path)
        if m:
            return self.post_approve(m.group(1))
        if path.startswith("/api/setup/"):
            return self.post_setup(path[len("/api/setup/"):])
        routes = {"/api/stage": self.post_stage, "/api/event": self.post_event, "/api/followup": self.post_followup,
                  "/api/session": self.post_session, "/api/snapshot": self.post_snapshot, "/api/reveal": self.post_reveal}
        if path not in routes:
            return self.send(404, '{"error":"not found"}')
        if not self.local_only():
            return
        body = self.json_body()
        if not isinstance(body, dict):
            return self.error(400, "send a JSON object with Content-Type: application/json")
        if path not in ("/api/session", "/api/reveal") and not (isinstance(body.get("id"), str) and ID.fullmatch(body["id"])):
            return self.error(400, "bad id")
        return routes[path](body)

    def reply_job(self, job, err):
        if job is None:
            return self.error(404, "unknown job")
        if err:
            return self.error(400, err)
        return self.send_json(200, with_flags(job))

    def post_status(self):
        try:
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
            job_id, status = body["id"], body["status"]
        except (ValueError, KeyError, TypeError):
            return self.send(400, '{"error":"bad request"}')
        if status not in STATUSES:
            return self.send(400, '{"error":"bad status"}')

        def change(job):
            before = job.get("status")
            job["status"] = status
            job["status_changed"] = datetime.date.today().isoformat()
            if status == "applied":
                tracker.mark_applied(job)
            elif before == "applied":
                tracker.unmark_applied(job)
        job, err = update_job(job_id, change)
        if job is None:
            return self.send(404, '{"error":"unknown job"}')
        return self.send(200, json.dumps(with_flags(job), ensure_ascii=False))

    def post_stage(self, body):
        stage = body.get("stage")
        if stage not in tracker.STAGES:
            return self.error(400, "stage must be one of " + ", ".join(tracker.STAGES))
        date = body.get("date")
        if date is not None and not tracker.valid_date(date):
            return self.error(400, "date must be YYYY-MM-DD")
        note = tracker.clean(body.get("note"))
        return self.reply_job(*update_job(body["id"], lambda j: tracker.set_stage(j, stage, date, note)))

    def post_event(self, body):
        return self.reply_job(*update_job(body["id"], lambda j: tracker.set_event(j, body)))

    def post_followup(self, body):
        if "date" not in body:
            return self.error(400, "date (YYYY-MM-DD or null) needed")
        date = body["date"]
        if date is not None and not tracker.valid_date(date):
            return self.error(400, "date must be YYYY-MM-DD or null")

        def change(job):
            job["follow_up_on"] = date
        return self.reply_job(*update_job(body["id"], change))

    def post_session(self, body):
        global SESSION
        action = body.get("action")
        jobs = load()["jobs"]
        live = {j["id"] for j in jobs if not j.get("vault")}
        with SESSION_LOCK:
            s = dict(SESSION)
            now = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
            if action == "start":
                ids = body.get("ids")
                if ids is not None:
                    if not isinstance(ids, list) or not all(isinstance(i, str) for i in ids):
                        return self.error(400, "ids must be a list of job ids")
                    ids = [i for i in dict.fromkeys(ids) if i in live]
                else:
                    ids = [r["id"] for r in tracker.queue(jobs, (body.get("sector") or None),
                                                           body.get("include") in ("interested", ["interested"]))]
                if not ids:
                    return self.error(400, "nothing to apply to")
                s = {"active": True, "ids": ids, "index": 0, "started": now, "skipped": []}
            elif action in ("next", "skip"):
                if not s.get("active"):
                    return self.error(409, "no apply session running")
                if action == "skip":
                    s["skipped"] = list(s.get("skipped") or []) + [s["ids"][s["index"]]]
                s["index"] = s.get("index", 0) + 1
                if s["index"] >= len(s["ids"]):
                    s.update(active=False, finished=now)
            elif action == "stop":
                s["active"] = False
                s["stopped"] = now
            else:
                return self.error(400, "action must be start, next, skip or stop")
            SESSION = s
            store.write_json(SESSION_FILE, s)
            view = session_view(jobs)
        set_active(view["current"]["id"] if view["current"] else None)
        return self.send_json(200, view)

    def post_snapshot(self, body):
        snap = tracker.clean_snapshot(body)
        if not snap:
            return self.error(400, "fields (a list of {label, value}) and url needed")
        job = next((j for j in load()["jobs"] if j.get("id") == body["id"]), None)
        if not job:
            return self.error(404, "unknown job")
        try:
            name = tracker.render_snapshot(job, snap, SNAPSHOTS)
        except Exception as e:  # noqa: BLE001  printing is best effort; say why
            return self.error(500, str(e)[:300])

        def change(j):
            j["snapshot"] = name
        update_job(job["id"], change)
        return self.send_json(200, {"snapshot": name})

    def post_reveal(self, body):
        """Show a CV, cover letter or tailored CV in Finder, so the user can drag it into a site that refuses uploads."""
        kind = body.get("kind")
        if kind not in ("cv", "letters", "cvs", "standard"):
            return self.error(400, "kind must be cv, letters, cvs or standard")
        target = reveal_path(kind, body.get("name"))
        if not target:
            return self.error(404, "no such file")
        if not REVEAL_DRY:
            try:
                subprocess.run(["open", "-R", str(target)], check=True, timeout=10, capture_output=True)
            except (subprocess.SubprocessError, OSError) as e:
                return self.error(500, "couldn't open Finder: " + str(e)[:200])
        return self.send_json(200, {"ok": True, "path": str(target.resolve()), "dry": REVEAL_DRY})

    # ------------------------------------------------------------ PUT
    def post_setup(self, what):
        """The setup window: uploads (the raw file as the body, which other web pages can't send without asking first),
        removals, finishing setup and making a shareable copy."""
        import setup_api
        if what not in ("upload", "remove", "complete", "share"):
            return self.send(404, '{"error":"not found"}')
        if not self.local_only():
            return
        if what == "upload":
            if self.headers.get("Content-Type", "") != "application/octet-stream":
                return self.error(400, "send the file as application/octet-stream")
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            size = int(self.headers.get("Content-Length", 0))
            if size > setup_api.MAX_BYTES:
                return self.error(413, "files can be up to 15 MB")
            data = self.rfile.read(size)
            st, err = setup_api.upload(q.get("kind", [""])[0], q.get("name", [""])[0], data, q.get("label", [""])[0])
        else:
            body = self.json_body()
            if not isinstance(body, dict):
                return self.error(400, "send a JSON object with Content-Type: application/json")
            if what == "remove":
                st, err = setup_api.remove(body.get("kind"), body.get("id"))
            elif what == "complete":
                st, err = setup_api.complete()
            else:
                import share
                try:
                    out = share.build()
                except Exception as e:  # noqa: BLE001
                    return self.error(500, f"couldn't make the copy: {e}")
                if not REVEAL_DRY:
                    subprocess.run(["open", "-R", str(out)], check=False)
                return self.send_json(200, {"path": str(out), "name": out.name})
        if err:
            return self.error(400, err)
        return self.send_json(200, st)

    def do_PUT(self):
        path = urllib.parse.urlparse(self.path).path
        if path.startswith("/api/setup/"):
            import setup_api
            if not self.local_only():
                return
            body = self.json_body()
            what = path[len("/api/setup/"):]
            if what == "details":
                st, err = setup_api.save_details(body)
            elif what == "industries":
                st, err = setup_api.save_industries((body or {}).get("industries") if isinstance(body, dict) else None)
            elif what == "options":
                st, err = setup_api.save_options(body)
            elif what == "cv-note":
                st, err = setup_api.save_cv_note((body or {}).get("key"), (body or {}).get("note")) if isinstance(body, dict) else (None, "bad request")
            else:
                return self.send(404, '{"error":"not found"}')
            if err:
                return self.error(400, err)
            return self.send_json(200, st)
        if path != "/api/my-answers":
            return self.send(404, '{"error":"not found"}')
        if not self.local_only():
            return
        body = self.json_body()
        if not isinstance(body, dict):
            return self.error(400, "send a JSON object with Content-Type: application/json")
        result, err = my_answers().update(body.get("answers"))
        if err:
            return self.error(400, err)
        return self.send_json(200, result)

    def post_active(self):
        if not self.local_only():
            return
        body = self.json_body()
        job_id = body.get("id") if isinstance(body, dict) else None
        if not isinstance(job_id, str) or not any(j["id"] == job_id for j in load()["jobs"]):
            return self.send(400, '{"error":"bad request"}')
        set_active(job_id)
        return self.send(200, json.dumps({"id": job_id}))

    def post_approve(self, job_id):
        if not self.local_only():
            return
        body = self.json_body()
        if not isinstance(body, dict):
            return self.send(400, '{"error":"bad request"}')
        af, tailor_cv = autofill()
        rec = tailor_cv.set_status(job_id, body.get("approved", True) is not False)
        if not rec:
            return self.send(404, '{"error":"no tailored cv"}')
        job = next((j for j in load()["jobs"] if j["id"] == job_id), {"id": job_id})
        return self.send(200, json.dumps(af.tailored(job), ensure_ascii=False))


if __name__ == "__main__":
    # A session that was running when the server stopped picks up where it left off.
    cid, _, _ = session_current_id()
    if cid:
        set_active(cid)
    print(f"Job Hunter running at http://localhost:{PORT}  (Ctrl+C to stop)")
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
