# Job Hunter: start here

Job Hunter finds roles for you every weekday, writes a cover letter for each in your own voice, picks the right CV, and
tracks your applications. It runs on your own computer with Claude doing the searching and writing.

## Start it
1. In the Claude desktop app's **Code** tab, start a new local session in an empty folder made for Job Hunter
   (for example Documents\Job Hunter or ~/Documents/Job Hunter).
2. Drag this zip into the chat and type **run**.

(Already unzipped? Open the unzipped folder in the Code tab and type **run**.)

Claude does the rest: it opens the dashboard, asks before installing anything it needs, and walks you through setup
(about 15 minutes). You add your details, your CVs (as many as you like), up to five cover letters you've written, and the
industries you want in your own words, such as "Capital raising". Claude then learns how you write, builds your profile
and schedules a search for weekday mornings. After that, type **run** any time to see what's new.

You need the Claude desktop app (on a Mac or Windows PC) and, for autofill, Google Chrome.

## For Claude
If the user gave you this zip or folder and said "run":
- If you can't run commands on their computer (for example in a chat without Claude Code), tell them Job Hunter runs
  through the Code tab of the Claude desktop app and give them the steps above.
- If it's a zip, unzip it into the session's current folder so that its contents (CLAUDE.md, serve.py, scripts/ and the
  rest) sit directly in that folder, not inside a nested "Job Hunter" folder. If the current folder already holds other
  files, ask before unzipping there. This way, opening that folder later and typing run just works.
- Then read `CLAUDE.md` and follow `.claude/skills/job-hunter-start/SKILL.md`.

You can reopen Setup any time from the top of the dashboard to add CVs, change your industries or reconnect Claude.

## Autofill (optional)
To fill application forms from your CV, load the `extension` folder in Chrome (chrome://extensions, Developer mode,
Load unpacked). See extension/README.md.
