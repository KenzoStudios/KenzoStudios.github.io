# Job Hunter

**To use it:** open this folder in the Claude desktop app's Code tab and type **run**. Claude starts the dashboard
(http://localhost:8765) and takes you to whatever comes next. To open the dashboard without Claude, double-click
**`Open Job Hunter.command`**.

**Setup:** the first time, the Setup window asks for your details, your CVs, up to five cover letters you've written and
the industries you want (in your own words). Then say **done** to Claude, and it builds your profile and schedules the
daily search (`/job-hunter-setup` does the same step on its own). Reopen Setup any time from **Setup** at the top.

**For Claude:** `CLAUDE.md` says what to do when the user types run.

**Sharing:** Setup > **Make a Shareable Copy** (or `python3 scripts/share.py`) writes `dist/Job Hunter.zip`: the app with
none of your personal data, ready for someone else to set up as their own. Its `START HERE.md` explains the rest.

Each role shows:
- a fit score and why it fits you
- the salary (estimates are marked "est.")
- the deadline
- which CV to attach
- a ready-made cover letter (PDF and Word)
- an Apply link

Mark each role **Interested**, **Applied** or **Passed**. The daily search reads those marks and skips roles like the ones you pass.

**Getting around:**
- The list is on the left, and the selected role is on the right.
- The Apply panel takes you through four steps: CV, cover letter, posting, mark as applied.

Keyboard shortcuts:
- `J`/`K` or the arrow keys: move between roles
- `1`–`4`: the four Apply steps
- `I`, `A`, `P`: Interested, Applied, Passed
- `U`: undo
- `?`: list all shortcuts. You can turn single-key shortcuts off there.

On a phone, tapping a role opens it, and Back returns to the list.
Earlier design versions are kept in `design/`.

**Fit colours:** the score beside each role is green for a strong fit (80+), amber for a good fit (65 to 79) and red for a lower fit.

**Firm sweep:** each search starts with `python3 scripts/sweep.py`, which reads the job board of every firm in
`profile/firms.json` directly and lists open London and Dublin roles that might suit you. To add a firm, add it to that file
and test it with `python3 scripts/sweep.py --firm "<name>"`. Firms whose sites can't be read that way are listed for a look by hand.

**Closed postings:** each morning, every role still in To do or Interested is checked to see if the posting is still taking
applications. Closed ones are moved off the dashboard into a vault (in `data/jobs.json`). They're re-checked daily for 30 days
and come back if they reopen; after 30 days they're moved to `data/expired.json`. Roles you've applied to or passed on are
never touched. To see what's in the vault, run `python3 scripts/postings.py list`.

## How autofill works

A small Chrome extension (in `extension/`) fills application forms for you. Set it up once: see `extension/README.md`.

1. In the dashboard, open a role and click **Open Posting** (step 3). Job Hunter notes which role you're applying for.
2. On the application page, a small Job Hunter panel appears in the corner. It recognises the role from the posting
   link, or from your Apply click in the last two hours, or you pick it.
3. The panel lists every field it found on the page with the value it will use: name, contact details, LinkedIn,
   location, right to work, dates, education with grades and your job titles. Untick anything you don't want filled,
   then press **Fill selected**. Or press **Run**: it fills this page and then each next page of the form as you move
   through it (you press Next; it never does), until the confirmation page.
4. Experience boxes get the bullets from your CV for that role, word for word. Below them are a few **optional lines**,
   true facts from `profile/facts.md` picked for the posting. They stay off unless you tick them.
5. **Attach** puts your CV and cover letter into the upload boxes. If the daily search suggested a **tailored CV** for
   the role, read **View changes**, then press **Approve** before you can attach it.
6. **Questions** ("Why do you want to work here?", "Tell us about yourself") are answered from your answer bank: answers
   written for each role from its cover letter and facts.md (`data/answers/<id>.json`), plus standard answers such as
   availability and right to work (`profile/answers.json`). Each one is shown in full with a tick box. Answers written
   for the role are ticked; anything uncertain (two answers that fit, an answer too long for the box) is not. Rich text
   answer boxes are filled too.
7. **My answers** are your standing answers for the questions every form asks, kept in `profile/my_answers.json` and
   edited in the extension (Options > My answers, or from the panel). Each one is **Fill** or **Leave**: how you heard
   ("Company careers website"), salary (£65,000 base; €75,000 for roles in Ireland), previously employed here (No),
   notice period, relocation (Yes), and the equal-opportunity questions ("Prefer not to say", matched to the form's
   decline option). Date of birth is left for you.
8. **Review the page, then submit it yourself.** The extension never presses Submit, Apply, Next or Continue. Consent
   boxes are listed under **Your confirmation needed** for you to tick; on sign-in pages only your email is filled (use
   your password manager for the password); CAPTCHAs are yours. If a site refuses an attached file, **Show in Finder**
   or **Download** it and drag it in.
9. When you submit (or leave the page after a fill), Job Hunter keeps a one-page PDF record of what the form said:
   every question and answer and the files attached, in `snapshots/`. Equal-opportunity, salary and password fields are
   never recorded.
10. On the "thank you for applying" page the panel asks **Application sent?** Press **Mark as applied** to move the role
   to Applied on the dashboard.

**Apply sessions.** Start an apply session from the dashboard to work through your To do list in order: closing soonest
first (within 14 days), then best fit, then newest. The panel shows "Applying 3 of 12", and on each confirmation page
**Next role** opens the next posting in the same tab. Skip one with **Skip this role**. A session survives a restart
of Job Hunter.

Works with Greenhouse, Lever, Ashby, Workday (step by step), SmartRecruiters and most ordinary careers forms.
Everything stays on your computer: the extension talks only to Job Hunter at http://127.0.0.1:8765. Consent boxes,
passwords, CAPTCHAs, "if yes, give details" follow-ups and anything set to Leave are always left to you. Employment
history uses `profile/employment.json` ahead of the CV (for example, one employer split into two roles after a promotion).

## After you apply

Each applied role is tracked through its stages (applied, screening, assessment, interview, offer, rejected, withdrawn),
with any interviews, calls and deadlines you add. A follow-up nudge is set for 7 days after you apply, then every 14
days while you're still waiting. When a role reaches the interview stage, the daily run writes an interview prep sheet
in `prep/` (your pitch, an evidence table, likely questions with answer outlines, questions to ask, and logistics).
Stages only change when you change them. `snapshots/` and `prep/` hold personal details and aren't committed to git.

Tailored CVs are saved in `cvs/`. They only reorder, trim or re-emphasise what's already in your CV and facts.md.

**Daily search:** runs weekdays around 7:30am while the Claude app is open. If the app is closed at that time, it runs the next time you open it.
You can also run it whenever you like from Scheduled in the Claude sidebar ("Job Hunter: daily roles + cover letters" → Run now).

**To change what it looks for,** edit:
- `profile/preferences.md`: sectors, locations, pay, dealbreakers, target firms
- `profile/cv-map.md`: which CV goes with which sector
- `profile/facts.md`: the only facts a letter may use. Add new achievements here.
- `profile/style-guide.md` and `profile/examples.md`: how the letters should sound

Letters are saved in `letters/`. Read each one before you send it.
