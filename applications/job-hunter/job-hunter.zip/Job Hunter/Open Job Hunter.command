#!/bin/bash
# Double-click to open the Job Hunter dashboard.
cd "$(dirname "$0")"
python3 scripts/start.py > /dev/null
