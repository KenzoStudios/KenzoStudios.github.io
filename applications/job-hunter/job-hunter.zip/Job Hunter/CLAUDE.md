# Job Hunter

This folder is Job Hunter: a local app that finds roles for the user every weekday, writes a cover letter for each in their
own voice, picks the right CV and tracks their applications. The dashboard is `serve.py` at http://localhost:8765, the
roles are in `data/`, and everything about the user is in `profile/`.

## When the user types "run"
"run", "start", "open", "launch", "go", "set up", or a first message asking what this is: follow
`.claude/skills/job-hunter-start/SKILL.md` (the /job-hunter-start skill). It starts the dashboard and takes them to
whatever comes next: setting up, connecting Claude, or what's new.

Other requests:
- A job search ("run a search", "run today's search", or the scheduled daily task): follow `RUN.md`.
- Set up again after changing CVs, letters or industries: `.claude/skills/job-hunter-setup/SKILL.md`.

## Not on a Mac?
Job Hunter was built on macOS but runs on Windows and Linux once a few helpers are adapted. Where `python3` isn't found,
use `python` (or `py`). These parts call Mac-only tools; when one fails, change it to work on this system and keep the Mac
path working:
- `scripts/make_letter.py` compiles `scripts/letter_pdf.swift` with `swiftc` to make letter PDFs.
- `scripts/word_pdf.py` exports CVs to PDF through Microsoft Word with AppleScript (it falls back to headless Chrome in
  `scripts/cv_pdf.py`; check that finds Chrome or Edge).
- `serve.py`'s `/api/reveal` shows a file in Finder with `open -R`.
- `Open Job Hunter.command` is a Mac launcher; on Windows, `python scripts/start.py` does the same.

## Always
- Never invent anything about the user. Facts come from `profile/facts.md`, letters follow `profile/style-guide.md`, and
  letters never contain em or en dashes.
- If Gmail is connected, it is read only: never send, reply, label or delete.
- Personal data stays in `profile/` and `data/`. To give Job Hunter to someone else, use Setup > Make a Shareable Copy
  (`scripts/share.py`), never the folder itself.
- Don't commit or push unless the user asks.
