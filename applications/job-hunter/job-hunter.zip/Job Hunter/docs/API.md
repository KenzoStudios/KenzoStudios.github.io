# Job Hunter: data and API contract (v2: answer bank, apply sessions, tracker)

The dashboard (dashboard.html), the extension (extension/) and the server (serve.py) agree on this. All endpoints are
on http://127.0.0.1:8765 and answer local requests only. POST bodies are JSON. Dates are ISO `YYYY-MM-DD`; datetimes are ISO
with timezone.

## Job record (data/jobs.json, existing fields kept)
Existing: id, firm, title, sector, location, url, posted, deadline, salary, salary_meets_target, experience_asked, fit,
reason, red_flags, team, posting_highlights, firm_facts, cv, cv_note, letter_pdf, letter_docx, status
(new|interested|applied|pass), status_changed, found_on, vault, closed_on, last_checked, reopened_on.

New, all optional:
- `stage`: once applied, one of `applied | screening | assessment | interview | offer | rejected | withdrawn`.
  Setting status to applied sets stage to `applied` if it isn't already set.
- `applied_on`: date the application was submitted.
- `stage_history`: `[{"stage": "...", "date": "YYYY-MM-DD", "note": "..."}]`, newest last.
- `events`: `[{"id": "e1", "kind": "interview|assessment|call|deadline|other", "at": "datetime", "title": "...", "note": "...", "link": "..."}]`
- `follow_up_on`: date for a follow-up nudge (defaults to applied_on + 7 days, then + 14 days, until the stage moves past `applied`).
- `snapshot`: file name in `snapshots/` (PDF of the submitted form, made from what the extension captured).
- `prep`: file name in `prep/` (interview prep sheet, Markdown; the daily run writes it when stage becomes interview).
- `answers_ready`: true if `data/answers/<id>.json` exists.

## Answer bank
- `profile/answers.json`: standard answers that are the same everywhere, for example availability ("January 2027"),
  notice period ("Available from January 2027, after my Master's finishes in December 2026"), right to work in UK/IE,
  willingness to relocate, languages, and LinkedIn. Each entry has `{"key", "patterns": [regex on the question label], "answer", "kind": "short|long"}`.
  Never: salary expectations, equal-opportunity or diversity questions, date of birth, "how did you hear about us", consents.
- `data/answers/<id>.json`: role-specific answers written by the daily run (and back-filled for open roles), drawn from
  that role's cover letter and facts.md, in the style guide's register:
  `{"id", "answers": [{"key": "why_firm|why_role|about_you|strength|motivation|other", "patterns": [...], "question": "Why do you want to work at X?", "answer": "...", "words": n}], "source": "letter|facts"}`.
  Typical lengths: why_firm 120-180 words, why_role 120-180, about_you 100-150. No dashes, nothing not in facts.md.

## Endpoints (new)
| Method | Path | Body / query | Returns |
|---|---|---|---|
| GET | /api/jobs | | as now, plus the new fields; vaulted roles still excluded |
| POST | /api/status | {id, status} | as now (also sets stage/applied_on when status becomes applied) |
| POST | /api/stage | {id, stage, date?, note?} | updated job; appends to stage_history; rejected or withdrawn also clears follow_up_on |
| POST | /api/event | {id, kind, at, title?, note?, link?} | updated job (adds or, with `event_id`, updates; `{id, event_id, delete: true}` removes) |
| POST | /api/followup | {id, date or null} | updated job |
| GET | /api/queue | ?sector=…&include=interested | `{"queue": [{"id", "firm", "title", "url", "priority", "why": "closes in 3 days / fit 88 / posted 2 days ago"}]}` ordered by priority: closing soonest first (within 14 days), then fit, then newest. Only status new/interested, not vaulted. |
| GET | /api/session | | `{"active": bool, "ids": [...], "index": n, "started": datetime}` |
| POST | /api/session | {action: "start", ids?} / {action: "next"} / {action: "skip"} / {action: "stop"} | the session; "start" without ids uses /api/queue; the current id becomes the active job for autofill |
| POST | /api/snapshot | {id, url, fields: [{label, value}], files: [names], captured_at} | `{snapshot: "<file>.pdf"}`; the server renders a clean PDF record of the submitted form into snapshots/ |
| GET | /api/answers/<id> | | `{"standard": [...], "role": [...]}` |
| GET | /snapshots/<file>, /prep/<file> | | the file (prep as text/markdown; the dashboard renders it) |

## Extension behaviour (new)
- The panel gets a **Questions** group: long-answer boxes matched against answer patterns. It previews each answer with a
  tick box (role answers are ticked, so you can see them; anything uncertain is unticked).
- **Snapshot:** the extension listens passively for the form's submit or page unload after a fill, captures label/value pairs
  of filled fields and the attached file names, then POSTs /api/snapshot. It never triggers submit itself.
- **Confirmation detection:** on pages whose text matches "thank you for (your )?appl", "application (has been )?(received|submitted)" or
  "we have received your application", the panel shows **"Application sent? Mark as applied"** (POST /api/status applied) and,
  in an apply session, **"Next role"** (POST /api/session next, then open the next url in the same tab).
- The panel header shows the session progress: "Applying 3 of 12".

## Implementation notes (engine, 21 Oct 2026)
These pin down what the contract above left open. Nothing above was changed; these are additions and clarifications.

- **Guards.** The new endpoints (and /snapshots, /prep, /api/answers) answer only requests whose Host is
  `localhost:8765` or `127.0.0.1:8765`. New POSTs must send `Content-Type: application/json` (other web pages can't do
  that without a preflight). Errors come back as `{"error": "..."}` with 400 (bad input), 404 (unknown job), 409 (no
  session running) or 500 (snapshot printing failed).
- **Writes.** Every write to data/jobs.json is atomic (temp file, then rename) and made under one lock shared with the
  daily run's scripts (`scripts/store.py`: a thread lock plus an flock on `data/.jobs.lock`).
- **/api/jobs** adds `answers_ready` to every job (computed: `data/answers/<id>.json` exists). It is never stored.
- **/api/status.** Becoming `applied` sets, only where missing: `applied_on` (today), `stage: "applied"` plus a
  `stage_history` entry `{stage: "applied", date, note: ""}`, and `follow_up_on` (applied_on + 7). Moving *off* applied
  (the dashboard's undo) removes that automatic tracking again, but only if nothing else was recorded (no later stage,
  no events). The response is the job, with `answers_ready`.
- **/api/stage** on a role that isn't applied yet also sets status `applied` (a stage implies it), recording the
  `applied` entry first. `date` must be `YYYY-MM-DD` (default today); `note` is optional. Rejected or withdrawn sets
  `follow_up_on: null`.
- **/api/event.** `at` may be a date or an ISO datetime (`Z` allowed); it is stored normalised
  (`2026-11-03T10:00:00+00:00`). New events get ids `e1`, `e2`, ... ; events are kept sorted by `at`. `link` must
  start with http:// or https://. An update merges: fields you leave out keep their values.
- **Follow-up nudges.** applied_on + 7, then every 14 days after that (+21, +35, ...) while the stage is still
  `applied`. `python3 scripts/tracker.py followups` (daily run) moves an overdue nudge to the next date; it never
  touches other stages and never changes a stage.
- **/api/queue.** Default is status `new` only; `include=interested` adds `interested`. `sector` matches the job's
  sector exactly (case-insensitive). Roles whose deadline has passed are left out. Each row also carries `sector`
  and `status`. Deadlines and posted dates are free text in jobs.json; the first `YYYY-MM-DD` in them is used.
- **/api/session.** Responses add `total`, `current` (`{id, firm, title, url, status}` or null) and, as they happen,
  `skipped` (ids), `finished` or `stopped` (datetimes). `start` also accepts `sector` and `include` (passed to the
  queue when no `ids` are given); unknown, vaulted and duplicate ids are dropped, and an empty list is a 400. `next`
  and `skip` both move on (skip also records the id); moving past the last role ends the session (`active: false`).
  The current role becomes the active job for autofill on start/next/skip, and again when the server restarts.
- **/api/autofill** responses add `answers` (the same object as /api/answers/<id>) and
  `session: {active, index, total, current}`. In a session, the current role wins (`matched: "session"`) on its own
  posting and on any page of the same host; a role the URL matched instead is offered under `candidates`.
- **/api/answers/<id>** also returns `held_back`: answers that failed the checks (dashes, banned phrases, words not
  traceable to facts.md, the CVs, the letter, the posting or the style guide, wrong length, or a forbidden topic) with
  the reason. Held-back answers are never offered to the extension. Role answers get default `patterns` for their key
  when the file has none, plus `words`.
- **/api/snapshot.** Up to 300 fields and 30 file names; empty values are dropped. The PDF is
  `snapshots/<id>-<yyyymmdd-hhmmss>.pdf` (shrunk to fit one page where it can) and `snapshot` on the job is the latest.
  The extension also sends one when a page unloads after a fill, as the contract says, so a tab closed after filling
  (without submitting) leaves a record too. Equal-opportunity, salary and password fields are never captured.
- **/snapshots/<file>** serves only `.pdf`, **/prep/<file>** only `.md` (as `text/markdown; charset=utf-8`), each only
  directly inside its folder.

## Autofill v2 (extension 1.2.0, 21 Oct 2026)
Additions only; everything above still holds.

| Method | Path | Body / query | Returns |
|---|---|---|---|
| GET | /api/my-answers | | `{"answers": [{key, label, group, value, mode, hint, ...}], "eeo_note", "file"}` |
| PUT | /api/my-answers | `{"answers": {key: {value?, mode?, ...}}}` (or a list of `{key, value?, mode?}`) | the same as GET, after the change |
| POST | /api/reveal | `{kind: "cv"|"letters"|"cvs"|"standard", name}` | `{ok, path, dry}`; runs `open -R <path>` (Finder) |

- **My answers** (`profile/my_answers.json`, `scripts/my_answers.py`): the user's standing answers, separate from the answer
  bank. Keys: `hear_about`, `salary`, `previously_employed`, `notice_period`, `relocation`, `dob`, `gender`, `ethnicity`,
  `sexual_orientation`, `disability`, `veteran`, `religion`, `age_range`. Each has `value` and `mode` (`fill` = autofill
  fills it, `leave` = left for the user). `salary` also has `free_text`, `number`, `eur_value`, `eur_free_text`,
  `eur_number` (euro figures for roles in Ireland or forms priced in euro). `dob` must be `YYYY-MM-DD` or empty. Unknown
  keys or fields, a mode other than fill/leave, or text over 400 characters are a 400. Missing keys fall back to the
  defaults (notice period from `profile/answers.json`). Writes are atomic (`store.write_json`). GET and PUT answer only
  local Host headers; PUT needs `Content-Type: application/json` (and, being a PUT, a preflight that the server never
  grants to other origins).
- **/api/reveal** shows a file in Finder for an upload a site refused. `cv`: a CV key (its standard PDF in
  `cvs/standard/`, else the .docx); `letters`, `cvs`, `standard`: a file name directly inside `letters/`, `cvs/` or
  `cvs/standard/`. Anything else is a 400 or 404. With `JH_REVEAL_DRY=1` (tests) it returns the path without opening
  Finder.
- **/api/file/...** responses add `X-JH-Path` (the file's absolute path, URL-encoded) for the panel's "Copy file path".
- **/api/autofill** adds `my_answers` (the GET /api/my-answers object). `fields` adds `over_18` (Yes), `graduation`
  (the latest education end date), `work_history` (one line per employer) and, where useful, `date`
  (`{year, month, day, text}`: `start_date` is 1 January 2027), `alts` (other spellings of a grade) and `numeric`
  (a GPA or IB score for number-only boxes). Education entries add `grade_names`, `gpa`, `points`, `status`
  (`In progress` / `Completed`) and `expected`.
- **Employment overrides** (`profile/employment.json`) are applied to the CV's employment entries before anything else:
  an employer listed there is replaced by its `roles` (title, start, end), the CV's bullets split between them by
  `bullets_matching` patterns (word for word; a bullet matching a `replace` pattern is swapped for its facts.md wording
  first), and `history` is what a single work-history box says. `python3 scripts/autofill.py --employment [CV key]` prints the result.
