# Search preferences

What the daily search looks for. The /job-hunter-setup skill writes this from the setup window and a few questions;
edit it any time (the search reads it fresh every run).

## Who
(Written at setup from the CVs: current situation, experience in a sentence or two, nationality or right to work if relevant.)

## Start date
(When the user can start, and what to skip: internships, roles that need someone immediately, part-time roles...)

## Locations
(The cities, in order of priority. Also in profile/user.json as "locations", which the sweep uses.)

## Seniority
(The level to look for, roughly how many years' experience a posting may ask for, and what to skip.)

## Firm quality
Only reputable, well-regarded employers: names a strong candidate would be proud to have on their CV, and that recruiters
and peers recognise. Search widely, and work through careers pages directly rather than relying on job boards.
(Add any firms or kinds of firm the user never wants.)

## Industries and target roles
One section per industry in profile/industries.json, in the user's words first, then what that means in practice: role
titles, similar roles under other names, the kinds of employer, example firms, and what not to include.

## Pay
(Target base pay, and how to judge commission-based roles. If no salary is listed, estimate a range, mark it "est." and say
where the estimate comes from. Show roles under target, but flag them.)

## How many
Top **10** new roles per run, ranked by fit. Quality over volume.

## Dealbreakers
- Roles that need a language the user doesn't speak fluently.
- Recruitment agency postings that hide the employer, unless the role is clearly excellent.
- Postings older than about 30 days, or closed. Graduate intakes that open months ahead are the exception.
(Add the user's own.)
