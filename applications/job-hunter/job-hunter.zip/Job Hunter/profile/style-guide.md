# How the user's cover letters should read

The first section is written by the /job-hunter-setup skill from the user's own sample letters (`profile/sample-letters/`).
Everything after it applies to every user. Match the user's voice; never copy sentences from their samples.

## Their voice (from their sample letters)
(Written at setup: tone and register, how they open and close, sentence length and rhythm, British or American spelling,
how they talk about themselves and about the firm, phrases they favour and ones they avoid, typical length and shape. Concrete
observations, with short quoted fragments of no more than a few words.)

## What every letter must do
1. **Personable.** Write like a real person talking to another person, in first person, with at least one small human
   moment: what they enjoyed, what surprised them, what they found themselves caring about.
2. **Excited, but professional, and humble.** The excitement is about joining *this* firm and its clients' work, said in
   professional language ("I am keen to…", "what draws me to…", "I would relish…"). Never showing off research.
3. **Sell the skillset.** Make the reader think "they could do this job". Connect abilities to what the role involves and
   show them in action rather than listing them.
4. **Use past roles as stories, not CV lines.** Say what it was like, what they learned and why it matters for this job.
5. **Human.** Natural rhythm, varied sentence lengths, the spelling and idiom of the user's country. Never reads as AI.

## Register
- Enthusiasm words to use: keen, drawn to, particularly appeals, I would relish, I would welcome, excited about, I enjoyed.
- Never use casual intensifiers or gushing words: love, genuinely, really, truly, honestly, absolutely, incredibly, hugely,
  super, amazing, awesome, fantastic, wonderful, brilliant, thrilled, delighted, dream, passionate.
- Never chatty phrasing ("to be honest", "a bit", "lots of", "kind of", "stuff", "get stuck in", "hit the ground running").
- Close formally and warmly, varying the wording.

## Tone: humble confidence
The reader should think: they know who we are, they want to be here, they would be good at this, and I would like working
with them. Never that they are lecturing the firm, showing off research or overrating themselves.
- **Research:** one or two things about the firm, kept high level or tied to why they matter to the user. Never a summary.
- **No overclaiming:** say what they have had exposure to, enjoyed and want to learn, not that they are "well placed".
- **Balance:** each "why I want this" comes with "here is how I would be useful to you".
- **Gaps:** name them plainly, without self-pity, and say what they would do about them.
- **Let achievements speak for themselves:** state what happened and stop. No commentary that interprets it.

## Hard rules
- **No em dashes or en dashes, ever,** and no spaced hyphen used as a dash. (`scripts/make_letter.py` refuses them.)
- **Never make anything up.** Claims about the user come only from `facts.md`. Claims about the firm must be things read on
  the posting or the firm's own pages during the run, each recorded in the spec's `sources` list.
- **Never just repeat the CV.**
- **No AI tells:** "I am writing to express", "delve", "tapestry", "testament to", "leverage", "synergy", "esteemed",
  "dynamic", "unique blend", "aligns perfectly", "perfect fit", "furthermore", "moreover", "in conclusion", "invaluable",
  "honed", "spearheaded", "foster", "robust", "cutting-edge"; groups of three adjectives; "not only X but also Y";
  rhetorical questions; every sentence starting with "I"; opening with a CV summary.
- Don't mention degree classification, salary, visas or age. Don't copy sentences between letters.
- Don't invent experiences either: nothing they have read, attended or talked about unless facts.md says so.

## Shape (520 to 620 words, so it fills one page)
- **Opening (about 90 words):** the role, and a specific reason this company appeals, with where they are now in a clause.
- **Why this company (about 110 words):** grounded in one or two things about the firm, connected to what they enjoyed before.
- **What they would bring, part 1 (about 130 words):** their strongest relevant experience, told as a story.
- **What they would bring, part 2 (about 100 words):** a different strength, from another role, study or achievement.
- **Honest gap and close (about 80 words):** any real gap in one plain sentence, why they would close it quickly, a warm close.
