# Facts bank

The only claims a cover letter, answer or CV line may make about the user. The /job-hunter-setup skill writes this from
their CVs (and anything they confirm when asked). If a letter needs something that isn't here, leave it out. Never invent
numbers, names, clients, awards or stories.

## Who they are right now

## Education

## Experience
(One section per employer: dates, titles, what they did, results, and any story behind them the user has confirmed.)

## Standing answers for application forms
(Right to work, notice period, office and travel, driving licence, references...)

## Contact block (letter header)
