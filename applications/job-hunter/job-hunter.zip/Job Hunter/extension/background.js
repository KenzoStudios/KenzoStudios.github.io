/* Job Hunter Autofill: background worker.
   The only part of the extension that talks to the network, and it talks only to Job Hunter on this computer
   (http://127.0.0.1:8765 unless changed in Options, and only ever to 127.0.0.1 or localhost). Pages never see the
   server: content scripts ask here, and get back JSON or a file. No analytics, no other hosts. */
const ext = globalThis.browser || globalThis.chrome;
const DEFAULT_SERVER = "http://127.0.0.1:8765";
const FILE_PATH = /^\/api\/file\/(cv|letters|cvs)\/[^/?#]+$/;

/* only http://127.0.0.1:<port> or http://localhost:<port>, nothing else */
function validServer(u) {
  try {
    const x = new URL(u);
    if (x.protocol === "http:" && (x.hostname === "127.0.0.1" || x.hostname === "localhost") && (x.pathname === "/" || x.pathname === "")) return x.origin;
  } catch (e) { /* not a URL */ }
  return null;
}
async function server() {
  const s = await ext.storage.local.get("server");
  return validServer(s && s.server) || DEFAULT_SERVER;
}
async function api(path, init) {
  const base = await server();
  let r;
  try {
    r = await fetch(base + path, Object.assign({ cache: "no-store", credentials: "omit" }, init || {}));
  } catch (e) {
    throw new Error("Job Hunter isn't running at " + base + ". Open it with Open Job Hunter.command.");
  }
  if (!r.ok) {
    let m = "";
    try { m = (await r.json()).error || ""; } catch (e) { m = ""; }
    throw new Error(m ? "Job Hunter: " + m : "Job Hunter answered " + r.status + " for " + path.split("?")[0]);
  }
  return r;
}
async function post(path, body) {
  const r = await api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  return r.json();
}
function b64(buf) {
  const bytes = new Uint8Array(buf);
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}
function filename(r, fallback) {
  const cd = r.headers.get("Content-Disposition") || "";
  const m = cd.match(/filename\*=UTF-8''([^;]+)/i);
  return m ? decodeURIComponent(m[1]) : fallback;
}

const handlers = {
  async ping() {
    const base = await server();
    await api("/api/roles");
    return { ok: true, server: base };
  },
  async autofill(msg) {
    const q = msg.id ? "id=" + encodeURIComponent(msg.id) : "url=" + encodeURIComponent(String(msg.url || ""));
    return (await api("/api/autofill?" + q)).json();
  },
  async roles() {
    return (await api("/api/roles")).json();
  },
  async file(msg) {
    if (!FILE_PATH.test(msg.path || "")) throw new Error("not a Job Hunter file");
    const r = await api(msg.path);
    const buf = await r.arrayBuffer();
    let where = "";
    try { where = decodeURIComponent(r.headers.get("X-JH-Path") || ""); } catch (e) { where = ""; }
    return { b64: b64(buf), type: r.headers.get("Content-Type") || "application/octet-stream", name: filename(r, msg.name || "file"), size: buf.byteLength, path: where };
  },
  /* The user's standing answers (profile/my_answers.json): read, or change some of them */
  async myAnswers() {
    return (await api("/api/my-answers")).json();
  },
  async saveMyAnswers(msg) {
    if (!msg.answers || typeof msg.answers !== "object") throw new Error("bad answers");
    const r = await api("/api/my-answers", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ answers: msg.answers }) });
    return r.json();
  },
  /* a CV or letter a site refused: show it in Finder (Job Hunter checks it is one of the user's own files) */
  async reveal(msg) {
    if (["cv", "letters", "cvs", "standard"].indexOf(msg.kind) < 0 || typeof msg.name !== "string" || !msg.name || /[\/]/.test(msg.name)) throw new Error("not a Job Hunter file");
    return post("/api/reveal", { kind: msg.kind, name: msg.name });
  },
  async openOptions(msg) {
    const url = ext.runtime.getURL("options.html") + (msg.page === "my-answers" ? "#my-answers" : "");
    await ext.tabs.create({ url: url });
    return { ok: true };
  },
  async approve(msg) {
    if (!/^[0-9a-f]{6,20}$/.test(msg.id || "")) throw new Error("bad id");
    const r = await api("/api/tailored/" + msg.id + "/approve", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ approved: msg.approved !== false })
    });
    return r.json();
  },
  /* the apply session: read it, or move it on (next, skip, stop). Never starts one: that's the dashboard's job. */
  async session() {
    return (await api("/api/session")).json();
  },
  async sessionAct(msg) {
    if (["next", "skip", "stop"].indexOf(msg.action) < 0) throw new Error("bad session action");
    return post("/api/session", { action: msg.action });
  },
  /* The user's "Mark as applied" on a confirmation page */
  async markApplied(msg) {
    if (!/^[0-9a-f]{6,20}$/.test(msg.id || "")) throw new Error("bad id");
    return post("/api/status", { id: msg.id, status: "applied" });
  },
  /* the record of a sent form: label/value pairs and file names, printed to a PDF by Job Hunter */
  async snapshot(msg) {
    const s = msg.snapshot || {};
    if (!/^[0-9a-f]{6,20}$/.test(s.id || "") || !Array.isArray(s.fields)) throw new Error("bad snapshot");
    return post("/api/snapshot", { id: s.id, url: String(s.url || ""), fields: s.fields, files: s.files || [], captured_at: s.captured_at });
  },
  async open(msg) {
    if (!FILE_PATH.test(msg.path || "")) throw new Error("not a Job Hunter file");
    await ext.tabs.create({ url: (await server()) + msg.path });
    return { ok: true };
  },
  async server() {
    return { server: await server() };
  }
};

ext.runtime.onMessage.addListener(function (msg, sender, reply) {
  /* only this extension's own content scripts and pages */
  if (!msg || !handlers[msg.type] || (sender && sender.id && sender.id !== ext.runtime.id)) return false;
  handlers[msg.type](msg).then(reply, function (e) { reply({ error: String(e && e.message || e) }); });
  return true;
});

/* the toolbar button shows or hides the panel on the current page */
ext.action.onClicked.addListener(function (tab) {
  if (!tab || tab.id == null) return;
  try {
    const p = ext.tabs.sendMessage(tab.id, { type: "toggle" }, { frameId: 0 });
    if (p && p.catch) p.catch(function () {});
  } catch (e) { /* no content script on this page (chrome:// and the like) */ }
});
