/* Job Hunter Autofill: shared helpers for the content scripts (loaded first).
   One namespace per page: globalThis.JHA, in the extension's isolated world. Pages can't reach it. */
(function () {
  if (globalThis.JHA) return;
  const ext = globalThis.browser || globalThis.chrome;
  const JHA = (globalThis.JHA = { ext: ext, version: "1.2.0" });

  /* a message to the background worker; resolves with its answer or rejects with its error */
  JHA.send = function (type, data) {
    const msg = Object.assign({ type: type }, data || {});
    return new Promise(function (resolve, reject) {
      function done(r) {
        const err = ext.runtime.lastError;
        if (err) return reject(new Error(err.message || "extension error"));
        if (!r) return reject(new Error("no answer from the extension"));
        if (r.error) return reject(new Error(r.error));
        resolve(r);
      }
      try {
        const p = ext.runtime.sendMessage(msg, globalThis.browser ? undefined : done);
        if (p && typeof p.then === "function") p.then(done, function (e) { reject(e); });
      } catch (e) { reject(e); }
    });
  };

  JHA.store = {
    async get(key, dflt) {
      try { const o = await ext.storage.local.get(key); return o && o[key] !== undefined ? o[key] : dflt; } catch (e) { return dflt; }
    },
    async set(key, value) {
      try { const o = {}; o[key] = value; await ext.storage.local.set(o); } catch (e) { /* storage is a convenience */ }
    }
  };

  /* the page after an application is sent */
  JHA.CONFIRM = /thank you for (your )?appl|application (has been )?(received|submitted)|we have received your application/i;
  /* a URL the panel may open itself (the next role in an apply session): http(s) only */
  JHA.safeUrl = function (u) {
    try { const x = new URL(String(u)); return /^https?:$/.test(x.protocol) ? x.href : null; } catch (e) { return null; }
  };

  JHA.sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  /* poll until fn() returns something truthy, or give up after ms */
  JHA.waitFor = async function (fn, ms, step) {
    const end = Date.now() + (ms || 1500);
    for (;;) {
      let v = null;
      try { v = fn(); } catch (e) { v = null; }
      if (v) return v;
      if (Date.now() > end) return null;
      await JHA.sleep(step || 60);
    }
  };
  JHA.norm = function (s) {
    return String(s || "").toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/[‘’]/g, "'").replace(/\s+/g, " ").trim();
  };
  JHA.b64ToFile = function (b64, name, type) {
    const bin = atob(b64), bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new File([bytes], name, { type: type, lastModified: Date.now() });
  };
})();
