/* Job Hunter Autofill: finding form fields and filling them.

   SAFETY: this file never submits anything, and JHA.capture only reads. Every click goes through JHA.safeClick, which only presses radio
   buttons, checkboxes, list options, dropdown openers, Yes/No answers and (after the user says so) "Add another"
   buttons, and refuses anything whose text, value or type suggests submit, apply, continue, next, save, send,
   review or finish. Typing sends only printable characters (never Enter, Tab or any other control key). The one
   exception is JHA.keyboardPick: ArrowDown and Enter inside an open combobox list, and only while focus is inside that
   combobox and its list is showing, to choose an option the page won't let us click. Password fields are never
   read, filled or stored, consent boxes are never ticked, and CAPTCHAs are only pointed out. */
(function () {
  const JHA = globalThis.JHA;
  if (!JHA || JHA.scan) return;
  const norm = JHA.norm;

  /* ------------------------------------------------------------ safety */
  const SUBMITTY = /\b(submit|apply|send|continue|next|finish|complete|review|confirm|proceed|done|save|sign ?in|log ?in|register|create account|upload and|withdraw|delete|remove)\b/i;
  JHA.SUBMITTY = SUBMITTY;
  function clickText(el) {
    return [el.textContent, el.getAttribute("aria-label"), el.getAttribute("title"), el.value, el.getAttribute("data-automation-id"), el.getAttribute("data-qa"), el.id, el.name]
      .filter(Boolean).join(" ").replace(/\s+/g, " ").slice(0, 300);
  }
  /* a list option drawn as a plain element (react-select's divs, an <li> in the list a combobox controls) */
  const LIST_BOX = "[role=listbox],ul,ol,[class*='menu' i],[id*='listbox' i],[class*='listbox' i],[class*='options' i]";
  JHA.canClick = function (el, purpose) {
    if (!el || el.nodeType !== 1 || el.disabled) return false;
    const tag = el.tagName;
    if (tag === "INPUT") return el.type === "radio" || el.type === "checkbox";
    const role = el.getAttribute("role");
    if (role === "option" || role === "radio" || role === "checkbox" || role === "menuitemradio") return !SUBMITTY.test(clickText(el));
    if (tag === "BUTTON" || role === "button" || tag === "A") {
      if (tag === "BUTTON" && el.type !== "button" && el.form) return false; /* a submit button of a form */
      if (tag === "A" && /^(https?:|\/)/.test(el.getAttribute("href") || "")) return false; /* links navigate */
      const t = clickText(el);
      if (SUBMITTY.test(t)) return false;
      if (purpose === "add") return /\badd\b/i.test(t);
      if (purpose === "yesno") return /^\s*(yes|no)\s*$/i.test(el.textContent || "");
      if (purpose === "open") return el.getAttribute("aria-haspopup") === "listbox" || el.getAttribute("aria-haspopup") === "true";
      return false;
    }
    if (purpose === "option" && /^(LI|DIV|SPAN)$/.test(tag) && el.parentElement && el.parentElement.closest(LIST_BOX) &&
        !el.querySelector("button,a[href],input,select,textarea,form")) return !SUBMITTY.test(clickText(el));
    return false;
  };
  JHA.safeClick = function (el, purpose) {
    if (!JHA.canClick(el, purpose)) throw new Error("refused to click: " + clickText(el).slice(0, 60));
    el.click();
  };

  /* ------------------------------------------------------------ the DOM, including open shadow roots */
  function deepAll(root, sel, out) {
    out = out || [];
    root.querySelectorAll(sel).forEach(function (n) { out.push(n); });
    root.querySelectorAll("*").forEach(function (n) {
      if (n.shadowRoot && !n.hasAttribute("data-job-hunter-autofill")) deepAll(n.shadowRoot, sel, out); /* never our own panel */
    });
    return out;
  }
  JHA.deepAll = deepAll;
  function visible(el) {
    if (!el.isConnected) return false;
    if (!el.getClientRects().length) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none" && +cs.opacity !== 0;
  }
  JHA.visible = visible;
  function byId(el, id) {
    const r = el.getRootNode();
    return (r && r.getElementById && r.getElementById(id)) || document.getElementById(id);
  }
  function txt(n) { return n ? (n.innerText || n.textContent || "").replace(/\s+/g, " ").trim() : ""; }
  JHA.txt = txt;
  function deepActive() {
    let a = document.activeElement;
    while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement;
    return a;
  }
  JHA.deepActive = deepActive;
  function ownLabel(el) {
    const out = [];
    if (el.labels && el.labels.length) el.labels.forEach(function (l) { out.push(txt(l)); });
    const lb = el.getAttribute("aria-labelledby");
    if (lb) lb.split(/\s+/).forEach(function (id) { const n = byId(el, id); if (n) out.push(txt(n)); });
    if (el.getAttribute("aria-label")) out.push(el.getAttribute("aria-label"));
    return out.filter(Boolean);
  }
  /* the question a field belongs to, for frameworks that don't use <label for> */
  function questionText(el) {
    let n = el.parentElement;
    for (let i = 0; n && i < 5; i++, n = n.parentElement) {
      if (n === document.body) break;
      const lab = n.querySelector(":scope > label, :scope > legend, :scope > [class*='label' i], :scope > [class*='question' i], :scope > h3, :scope > h4, :scope > p");
      if (lab && !lab.contains(el) && txt(lab)) return txt(lab).slice(0, 200);
      const fields = n.querySelectorAll("input:not([type=hidden]),select,textarea,[contenteditable='true']");
      if (fields.length > 3) break;
    }
    const fs = el.closest("fieldset");
    if (fs) { const lg = fs.querySelector("legend"); if (lg) return txt(lg); }
    return "";
  }
  function describe(el) {
    const own = ownLabel(el);
    const q = questionText(el);
    let ph = el.getAttribute("placeholder") || el.getAttribute("aria-placeholder") || el.getAttribute("data-placeholder") || "";
    /* a typeahead's "Search" placeholder (Workday prompts) doesn't make it a site search box */
    if (/^\s*search\b/i.test(ph) && (el.getAttribute("data-automation-id") === "searchBox" || el.closest("[data-uxi-widget-type='selectinput'],[role=combobox]") || el.getAttribute("role") === "combobox")) ph = "";
    const label = own[0] || q || ph || "";
    const ff = el.closest && el.closest("[data-automation-id^='formField-']");
    /* Workday's typeahead box is called "searchBox": that's not a site search, so it isn't part of the description */
    const aid = el.getAttribute("data-automation-id");
    const parts = own.concat([label, q, ph, el.name, el.id, aid === "searchBox" ? "" : aid, el.getAttribute("data-qa"), el.getAttribute("title"), ff && ff.getAttribute("data-automation-id")]);
    const clean = function (xs) { return norm(xs.filter(Boolean).join(" | ").replace(/[_\-[\]]+/g, " ").replace(/([a-z])([A-Z])/g, "$1 $2")); };
    const desc = clean(parts);
    /* the field's own words only (its label, placeholder, name): the user's answers are matched on these when it has a label,
       so a paragraph near a name box that mentions gender or age can't claim it */
    const ownText = own.length ? clean(own.concat([ph, el.name, el.id, aid === "searchBox" ? "" : aid])) : "";
    return { label: label.replace(/\s*\*\s*$/, "").slice(0, 80), desc: desc, own: ownText };
  }
  JHA.describe = describe;

  /* ------------------------------------------------------------ what a field is */
  /* never filled, whatever else the label says */
  const HARD = /password|national insurance|passport|social security|\bssn\b|criminal|convict|signature|captcha|\bif (yes|so|no)\b|expir|pronoun|\bsearch\b/;
  /* boxes that say the user agrees to something: never ticked, listed under "Your confirmation needed" */
  const CONSENT = /privacy|consent|\bterms\b|conditions of|i agree|i accept|agree to|acknowledg|certif|declar|data (processing|protection)|\bgdpr\b|personal (data|information)|i confirm|confirm (that )?(the |all |my )?(information|details|above|answers)|accurate|true and (complete|correct)|i understand|i have read/;
  const MARKETING = /marketing|newsletter|news and|future (roles|opportunit|vacanc|job)|talent (community|pool|network)|keep me (informed|updated)|job alerts?|similar roles/;
  const ADULT = /(18|eighteen) (years )?(of age|or older|or over|years or)|over (the age of )?(18|eighteen)|at least (18|eighteen)|legal (working )?age/;
  /* The user's standing answers (profile/my_answers.json): "my:<key>" kinds. textOk: also for long-answer boxes. */
  const MY = [
    ["hear_about", /how did you (hear|find|learn|come across)|where did you (hear|find|see|learn)|how .{0,25}(hear|learn)(ed)? (about|of)|source of (your )?(application|referral)|referral source|job source|\bsource\b(?! code)|how were you referred/, true],
    ["salary", /salary|compensation|pay expect|expected pay|desired pay|remuneration|\bctc\b|current pay|rate expectation/, true],
    ["previously_employed", /previously (been )?(employed|worked)|worked (here|for us|for this company|at [a-z&' ]{2,40}) before|former(ly)? (an )?employ|ever (been )?(employed|worked) (by|for|at)|have you (ever )?worked (for|at)|past employee|current or former employee/, true],
    ["notice_period", /notice period|how much notice|current notice/, true],
    ["relocation", /relocat|willing to move|open to moving|willing to (re)?locate/, false],
    ["gender", /\bgender\b|\bsex\b|transgender|\btrans\b/, true],
    ["sexual_orientation", /sexual orientation|\borientation\b/, true],
    ["ethnicity", /ethnic|\brace\b|racial/, true],
    ["disability", /disabilit|disabled/, true],
    ["veteran", /veteran|military (service|status)|armed forces|protected vet/, true],
    ["religion", /religio|\bbelief\b|\bfaith\b/, true],
    ["dob", /date of birth|birth ?date|\bdob\b|\bbirthday\b|born on/, true],
    ["age_range", /\bage range\b|\bage group\b|\bage\b|how old/, true]
  ];
  JHA.MY_KEYS = MY.map(function (m) { return m[0]; });
  const EEO_KEYS = /^(gender|sexual_orientation|ethnicity|disability|veteran|religion|age_range)$/;
  JHA.EEO_KEYS = EEO_KEYS;
  const NEVER = /national insurance|passport|social security|\bssn\b|criminal|convict|\breferr(al|ed|er)|signature|captcha|\bsearch\b|privacy|consent|\bterms\b|i agree|acknowledg|certif|declar|marketing|newsletter|expir|\bif (yes|so|no)\b|pronoun|password/;
  const RULES = [
    ["email", /\be ?mail\b/, ["email"]],
    ["preferred_name", /\bpreferred (first )?name\b|\bnickname\b|\bknown as\b/],
    ["work_history", /work history|employment history|career history|previous (employment|employers|roles|positions)|employment record/],
    ["first_name", /\b(first|given|fore) ?name\b|\bfname\b|legal name section first/, ["given-name"]],
    ["last_name", /\b(last|family|sur) ?name\b|\bsurname\b|\blname\b|legal name section last/, ["family-name"]],
    ["phone_code", /country (phone )?code|dial(l?ing)? code|phone country|country code/, ["tel-country-code"]],
    ["country", /^(country|country region)\b|\bcountry\b(?!.*\b(phone|mobile)\b.*\bnumber)/, ["country", "country-name"]],
    ["phone", /\b(phone|mobile|telephone|cell)\b/, ["tel", "tel-national"]],
    ["linkedin", /linked ?in/],
    ["location", /\blocation\b|where are you (based|located)|current(ly)? (based|located)|\bbased in\b/],
    ["postcode", /post ?code|postal|\bzip\b/, ["postal-code"]],
    ["county", /\bcounty\b|\bstate\b|province|\bregion\b/, ["address-level1"]],
    ["town", /\btown\b|town ?\/ ?city|address section city/, ["address-level2"]],
    ["address_line2", /address (line )?2|address 2|apartment|\bflat\b|\bsuite\b/, ["address-line2"]],
    ["address_line1", /address (line )?1|street|^address\b|\bhome address\b|\baddress\b(?!.*(e ?mail|web|city|town|country))/, ["address-line1", "street-address"]],
    ["city", /\bcity\b/],
    ["sponsorship", /sponsor/],
    ["work_limited", /time ?limited|temporary (permission|visa|right)|limited leave|visa (type|status)|permission .{0,30}(limited|restricted)/],
    ["work_auth_ie", /(right|authori[sz]ed|eligible|permit|entitled|legally).{0,60}(ireland|\beu\b|european)/],
    ["work_auth_uk", /(right to work|authori[sz]ed to work|eligible to work|legally (able|entitled|permitted|authori[sz]ed)|work permit|permission to work|entitled to work)/],
    ["citizenship", /citizenship|nationalit/],
    ["start_date", /start date|when (can|could) you start|earliest (start|date)|available to start|availability|date available|available from/],
    ["current_company", /current (company|employer)|most recent (company|employer)|^org$|\borg\b/],
    ["current_title", /current (job )?title|current (role|position)/],
    ["graduation", /graduat|completion date|date of (completion|award)|expected (to )?(finish|complet)/],
    ["school", /\b(school|university|institution|college)\b/],
    ["degree_level", /degree type|type of degree|level of (study|education)|highest (level|degree)/],
    ["grade", /\bgpa\b|\bgrade\b|overall result|classification/],
    ["degree", /\bdegree\b|qualification/],
    ["field", /discipline|field of study|\bmajor\b|area of study|subject/],
    ["full_name", /^(full )?name\b|\bfull name\b|\byour name\b|systemfield name|\bcandidate name\b/, ["name"]]
  ];
  const EXP = [
    ["description", /description|responsibilit|summary|duties|achievement|what did you do/],
    ["current", /current(ly)? work|i currently|present|still work/],
    ["title", /job title|\btitle\b|position|\brole\b/],
    ["company", /company|employer|organi[sz]ation/],
    ["location", /location|city/],
    ["start", /\bfrom\b|start/],
    ["end", /\bto\b|\bend\b|until/]
  ];
  const EDU = [
    ["school", /school|university|institution|college/],
    ["level", /degree type|level/],
    ["current", /currently (study|attend|enrol)|still (study|attend)|i am (currently )?(studying|enrolled)/],
    ["status", /\bstatus\b|in progress|completed\?/],
    ["grade", /gpa|grade|result|classification|\bpoints\b/],
    ["degree", /degree|qualification/],
    ["field", /discipline|field of study|major|subject|area/],
    ["start", /\bfrom\b|start|first year/],
    ["end", /\bto\b|\bend\b|until|last year|graduat|completion|expected/]
  ];
  function kindOf(el, d) {
    const ac = (el.getAttribute("autocomplete") || "").toLowerCase().split(/\s+/);
    if (el.type === "email") return "email";
    if (/\bpreferred (first )?name\b/.test(d.desc)) return "preferred_name";
    for (const r of RULES) if (r[2] && r[2].some(function (a) { return ac.indexOf(a) >= 0; })) return r[0];
    if (el.type === "tel") return /code/.test(d.desc) ? "phone_code" : "phone";
    for (const r of RULES) if (r[1].test(d.desc)) return r[0];
    return null;
  }
  function isLong(el) { return el.tagName === "TEXTAREA" || !!el.isContentEditable; }
  function isTick(el) { return el.type === "checkbox" || el.type === "radio" || el.getAttribute("role") === "checkbox" || el.getAttribute("role") === "radio"; }
  /* never | consent | over_18 | my:<key> | a profile key | null */
  function classify(el, d) {
    const desc = d.desc, mine = d.own || desc;
    if (HARD.test(desc)) return "never";
    if (isTick(el) && CONSENT.test(desc) && !MARKETING.test(desc)) return "consent";
    if (isTick(el) && MARKETING.test(desc)) return "never";
    if (ADULT.test(mine)) return "over_18";
    for (const m of MY) {
      if (!m[1].test(mine)) continue;
      if (!m[2] && isLong(el)) return null; /* a long relocation question: the answer bank's */
      return "my:" + m[0];
    }
    if (NEVER.test(desc)) return "never";
    return kindOf(el, d);
  }
  JHA.classify = classify;
  function subKind(rules, d) {
    const label = d.label || "";
    if (/\?/.test(label) || label.length > 60) return /description|responsibilit|duties/.test(d.desc) ? "description" : null;
    for (const r of rules) if (r[1].test(d.desc)) return r[0];
    return null;
  }
  function shortLabel(f) { return !/\?/.test(f.label || "") && (f.label || "").length <= 40; }

  /* ------------------------------------------------------------ dates */
  const MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
  function describedBy(el) {
    const ids = (el.getAttribute("aria-describedby") || "").split(/\s+/).filter(Boolean);
    return ids.map(function (id) { const n = byId(el, id); return n ? txt(n) : ""; }).join(" ");
  }
  function templateIn(s) {
    const m = s.match(/\b(dd|mm|yyyy|yy)([\/.\- ])(dd|mm|yyyy|yy)(?:\2(dd|mm|yyyy|yy))?\b/);
    if (!m) return null;
    const parts = [m[1], m[3], m[4]].filter(Boolean);
    if (new Set(parts).size !== parts.length || parts.indexOf("mm") < 0) return null;
    return m[0];
  }
  function patternTemplate(p) {
    if (!p) return null;
    const s = p.replace(/\\d\{1,2\}/g, "\\d{2}").replace(/\[0-9\]/g, "\\d");
    const sep = "([/.\\-])";
    let m = s.match(new RegExp("^\\^?\\\\d\\{4\\}\\\\?" + sep + "\\\\d\\{2\\}\\\\?\\1\\\\d\\{2\\}\\$?$"));
    if (m) return "yyyy" + m[1] + "mm" + m[1] + "dd";
    m = s.match(new RegExp("^\\^?\\\\d\\{2\\}\\\\?" + sep + "\\\\d\\{2\\}\\\\?\\1\\\\d\\{4\\}\\$?$"));
    if (m) return "dd" + m[1] + "mm" + m[1] + "yyyy";
    m = s.match(new RegExp("^\\^?\\\\d\\{2\\}\\\\?" + sep + "\\\\d\\{4\\}\\$?$"));
    if (m) return "mm" + m[1] + "yyyy";
    return null;
  }
  /* how a date box wants its value: yyyy-mm-dd, a template like dd/mm/yyyy, or month | year | day | text */
  JHA.dateFormat = function (el, d) {
    if (el.type === "date") return "yyyy-mm-dd";
    if (el.type === "month") return "yyyy-mm";
    const aid = el.getAttribute("data-automation-id") || "";
    if (/dateSectionMonth/i.test(aid)) return "month";
    if (/dateSectionYear/i.test(aid)) return "year";
    if (/dateSectionDay/i.test(aid)) return "day";
    const own = norm([ownLabel(el).join(" "), el.getAttribute("placeholder"), el.getAttribute("aria-placeholder"), el.name, el.id, el.getAttribute("title"), describedBy(el), el.getAttribute("data-date-format")].filter(Boolean).join(" | "));
    const t = templateIn(own) || patternTemplate(el.getAttribute("pattern")) || templateIn(norm(d.desc));
    if (t) return t;
    if (el.tagName === "SELECT") {
      const os = Array.prototype.map.call(el.options, function (o) { return norm(o.textContent); });
      if (os.some(function (o) { return MONTHS.indexOf(o) >= 0 || MONTHS.some(function (m) { return o === m.slice(0, 3); }); })) return "month";
      const years = os.filter(function (o) { return /^(19|20)\d\d$/.test(o); }).length;
      if (years >= 3) return "year";
      const days = os.filter(function (o) { return /^\d{1,2}$/.test(o); }).length;
      if (days >= 28) return /month|\bmm\b/.test(own) ? "month" : "day";
    }
    for (const s of [own, d.desc]) {
      if (/\bmonth\b|\bmm\b/.test(s)) return "month";
      if (/\byear\b|\byyyy\b/.test(s)) return "year";
      if (/\bday\b|\bdd\b/.test(s)) return "day";
    }
    return "text";
  };
  /* a date ({year, month, day, text}) written for a format; "" when the date can't say it (no month, say) */
  JHA.formatDate = function (dt, fmt, fallback) {
    if (!dt || !dt.year) return fmt === "text" ? (fallback || (dt && dt.text) || "") : "";
    const mm = dt.month ? String(dt.month).padStart(2, "0") : "";
    const dd = String(dt.day || 1).padStart(2, "0");
    if (fmt === "year") return String(dt.year);
    if (fmt === "month") return mm;
    if (fmt === "day") return dd;
    if (fmt === "text") return fallback || dt.text || String(dt.year);
    if (/mm/.test(fmt) && !mm) return "";
    return fmt.replace("yyyy", String(dt.year)).replace("yy", String(dt.year).slice(2)).replace("mm", mm).replace("dd", dd);
  };

  /* ------------------------------------------------------------ site adapters */
  const ADAPTERS = [
    { name: "Greenhouse", test: /(^|\.)greenhouse\.io$/,
      files: { cv: "#resume, input[name='resume'], [id*='resume' i] input[type=file]", letter: "#cover_letter, input[name='cover_letter'], [id*='cover' i] input[type=file]" },
      groups: { education: ".education--container, [class*='education' i] .education, fieldset[id*='education' i]" } },
    { name: "Lever", test: /(^|\.)lever\.co$/,
      files: { cv: "input[name='resume'], #resume-upload-input" } },
    { name: "Ashby", test: /(^|\.)ashbyhq\.com$/,
      files: { cv: "#_systemfield_resume, input[name='_systemfield_resume']" } },
    { name: "Workday", test: /(^|\.)(myworkdayjobs\.com|myworkday\.com|workday\.com)$/,
      groups: { experience: "[data-automation-id^='workExperience-']", education: "[data-automation-id^='education-']" },
      add: { experience: "[data-automation-id='workExperienceSection'] button, [aria-labelledby*='Work-Experience' i] button, [role='group'][aria-label*='Work Experience' i] button",
             education: "[data-automation-id='educationSection'] button, [role='group'][aria-label*='Education' i] button" },
      drop: "[data-automation-id='file-upload-drop-zone'], [data-automation-id*='attachments' i]",
      /* Workday's phone box takes the number without the country code, which has its own dropdown */
      value: function (key, v) { return key === "phone" ? v.replace(/^\+44\s*/, "") : v; } },
    { name: "SmartRecruiters", test: /(^|\.)smartrecruiters\.com$/ },
    { name: "Oracle", test: /oraclecloud\.com$/ },
    { name: "Generic", test: /./ }
  ];
  JHA.adapter = function () {
    const h = location.hostname.toLowerCase();
    return ADAPTERS.find(function (a) { return a.test.test(h); });
  };
  JHA.ATS_HOST = /(greenhouse\.io|lever\.co|ashbyhq\.com|myworkdayjobs\.com|myworkday\.com|smartrecruiters\.com|workable\.com|pinpointhq\.com|oraclecloud\.com|taleo\.net|successfactors\.(com|eu)|icims\.com|tal\.net|teamtailor\.com|recruitee\.com|bamboohr\.com|jobvite\.com|eightfold\.ai|avature\.net)$/i;

  /* ------------------------------------------------------------ scanning */
  const FIELD_SEL = "input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=image]):not([type=reset]):not([type=file]):not([type=password]),select,textarea,button[aria-haspopup='listbox'],[contenteditable='true'],[contenteditable=''],[role=checkbox]:not(input)";
  /* a rich text editor: the outermost editable element (Quill, Draft.js, ProseMirror, Lexical, CKEditor, Workday) */
  function isRich(el) { return el.isContentEditable && !(el.parentElement && el.parentElement.isContentEditable) && !/^(INPUT|TEXTAREA)$/.test(el.tagName); }

  const OWN = { experience: /^(current_company|current_title|location|city|start_date)$/, education: /^(school|degree|degree_level|field|grade|graduation)$/ };
  function groupRoots(kind, anchors, adapter, host, fields) {
    if (adapter.groups && adapter.groups[kind]) {
      const r = deepAll(document, adapter.groups[kind]).filter(function (n) { return !host.contains(n) && visible(n); });
      /* keep the outermost matches only */
      const outer = r.filter(function (n) { return !r.some(function (m) { return m !== n && m.contains(n); }); });
      if (outer.length) return outer;
    }
    /* generic: the largest box around each anchor field that holds no other anchor and no contact field */
    const roots = [];
    anchors.forEach(function (a) {
      let g = a.el.parentElement, best = g;
      while (g && g !== document.body && g !== document.documentElement) {
        const inside = anchors.filter(function (b) { return g.contains(b.el); }).length;
        if (inside > 1 || g.querySelector("input[type=email],input[autocomplete=email],input[name*='first' i],input[name*='email' i]")) break;
        if (fields.some(function (f) { return f.kind && !OWN[kind].test(f.kind) && !/^(never|consent)$/.test(f.kind) && g.contains(f.el) && !/company|employer|title|position|role|description|from|to|start|end|current|month|year|date|location|city|status|grade|gpa/.test(f.desc); })) break;
        best = g;
        g = g.parentElement;
      }
      if (best && roots.indexOf(best) < 0) roots.push(best);
    });
    return roots;
  }

  /* sign-in and account pages: only the email (and the name, when creating an account) is filled */
  function loginPage(host) {
    const pw = deepAll(document, "input[type=password]").filter(function (el) { return !host.contains(el) && visible(el); });
    if (!pw.length) return null;
    const labels = norm(pw.map(function (el) { return describe(el).desc; }).join(" "));
    const create = pw.length >= 2 || /verify|confirm|re ?enter|repeat|new password/.test(labels);
    return { kind: create ? "create" : "signin", passwords: pw.length };
  }
  /* CAPTCHAs: shown to the user, never touched. Invisible reCAPTCHA badges don't count. */
  const CAPTCHA_SRC = /recaptcha|hcaptcha\.com|challenges\.cloudflare\.com|turnstile/i;
  function captchas(host) {
    const out = [];
    deepAll(document, "iframe").forEach(function (f) {
      const src = f.getAttribute("src") || "";
      if (!CAPTCHA_SRC.test(src) || /size=invisible/.test(src) || f.closest(".grecaptcha-badge") || host.contains(f) || !visible(f)) return;
      out.push(f.closest(".g-recaptcha,.h-captcha,.cf-turnstile") || f);
    });
    deepAll(document, ".g-recaptcha,.h-captcha,.cf-turnstile").forEach(function (c) {
      if (!host.contains(c) && visible(c) && out.indexOf(c) < 0 && !out.some(function (o) { return c.contains(o) || o.contains(c); })) out.push(c);
    });
    return out.filter(function (c, i) { return out.indexOf(c) === i; }).map(function (c) {
      const src = (c.tagName === "IFRAME" ? c : c.querySelector("iframe") || c).getAttribute("src") || c.className || "";
      return { el: c, label: /hcaptcha|h-captcha/i.test(src) ? "hCaptcha" : /turnstile|cloudflare/i.test(src) ? "Cloudflare Turnstile" : "reCAPTCHA" };
    });
  }
  /* date boxes only a calendar can set (read-only): listed for the user */
  const DATEISH = /\bdate\b|\bdob\b|birth|start|availab|graduat|\bfrom\b|\buntil\b|\bmm\b|\byyyy\b/;

  /* everything on the page that autofill could fill, without touching anything */
  JHA.scan = function (host) {
    const adapter = JHA.adapter();
    const raw = deepAll(document, FIELD_SEL).filter(function (el) {
      if (host.contains(el) || el.disabled || el.getAttribute("aria-disabled") === "true" || !visible(el)) return false;
      if (el.isContentEditable || el.getAttribute("contenteditable") !== null) return isRich(el);
      return true;
    });
    const calendar = [];
    const els = raw.filter(function (el) {
      if (!el.readOnly) return true;
      const d = describe(el);
      if (el.tagName === "INPUT" && DATEISH.test(d.desc) && !HARD.test(d.desc)) calendar.push({ el: el, label: d.label || "Date", desc: d.desc });
      return false;
    });
    const all = els.map(function (el) {
      const d = describe(el);
      return { el: el, label: d.label, desc: d.desc, kind: classify(el, d), d: d, rich: isRich(el) };
    });
    /* radio groups and button pairs count once, by their question */
    const fields = [], seenRadio = {};
    all.forEach(function (f) {
      if (f.el.type === "radio") {
        const key = f.el.name || f.el.closest("[role=radiogroup],fieldset") || f.el;
        if (seenRadio[key]) return;
        seenRadio[key] = 1;
        const q = questionText(f.el) || f.label;
        f.label = q;
        f.desc = norm(q + " " + f.el.name);
        f.kind = classify({ getAttribute: function () { return ""; }, type: "radio", tagName: "INPUT" }, { desc: f.desc });
        f.radio = true;
      }
      fields.push(f);
    });
    /* Yes/No answers drawn as buttons (Ashby): a question with exactly a Yes and a No button */
    deepAll(document, "button").forEach(function (b) {
      if (host.contains(b) || !/^\s*yes\s*$/i.test(b.textContent || "") || !visible(b)) return;
      const box = b.parentElement;
      const no = box && Array.prototype.find.call(box.querySelectorAll("button"), function (x) { return /^\s*no\s*$/i.test(x.textContent || ""); });
      if (!no) return;
      const q = questionText(box) || questionText(b);
      const desc = norm(q);
      if (!q) return;
      const k = classify({ getAttribute: function () { return ""; }, type: "x", tagName: "DIV" }, { desc: desc });
      if (k === "never" || k === "consent") return;
      fields.push({ el: box, yes: b, no: no, label: q.slice(0, 80), desc: desc, kind: k, buttons: true });
    });

    /* repeating sections: experience (anchored on a company box) and education (on a school box) */
    const groups = { experience: [], education: [] };
    const usable = function (f) { return f.kind !== "never" && f.kind !== "consent" && !/^my:/.test(f.kind || ""); };
    const expAnchors = fields.filter(function (f) { return shortLabel(f) && /company|employer|organi[sz]ation/.test(f.desc) && !/current|most recent|sponsor/.test(f.desc) && usable(f); });
    const eduAnchors = fields.filter(function (f) { return shortLabel(f) && /school|university|institution|college/.test(f.desc) && usable(f); });
    [["experience", expAnchors, EXP], ["education", eduAnchors, EDU]].forEach(function (g) {
      if (!g[1].length && !(adapter.groups && adapter.groups[g[0]])) return;
      groupRoots(g[0], g[1], adapter, host, fields).forEach(function (root) {
        const slot = { root: root, fields: [] };
        fields.forEach(function (f) {
          if (f.grouped || !root.contains(f.el) || !usable(f) || f.kind === "over_18") return;
          const k = subKind(g[2], f);
          if (!k) return;
          f.grouped = g[0];
          slot.fields.push({ f: f, part: k, date: (k === "start" || k === "end") ? JHA.dateFormat(f.el, f.d || f) : null });
        });
        if (slot.fields.length) groups[g[0]].push(slot);
      });
    });

    /* the "Add another" buttons next to repeating sections; checked against the safety rules before they're offered */
    const add = {};
    ["experience", "education"].forEach(function (kind) {
      let cands = [];
      if (adapter.add && adapter.add[kind]) cands = deepAll(document, adapter.add[kind]);
      if (!cands.length) {
        const rx = kind === "experience" ? /experience|employment|work history|positions?/i : /education/i;
        cands = deepAll(document, "button,[role=button]").filter(function (b) {
          const t = (b.textContent || "") + " " + (b.getAttribute("aria-label") || "");
          if (!/\badd\b/i.test(t)) return false;
          if (rx.test(t)) return true;
          let s = b.parentElement;
          for (let i = 0; s && i < 4; i++, s = s.parentElement) {
            const h = s.querySelector("h1,h2,h3,h4,legend,[role=heading]");
            if (h && rx.test(h.textContent || "")) return true;
          }
          return false;
        });
      }
      const ok = cands.filter(function (b) { return !host.contains(b) && visible(b) && JHA.canClick(b, "add"); });
      if (ok.length) add[kind] = ok[ok.length - 1];
    });

    /* file boxes: CV, cover letter, or either */
    const files = [];
    const fileEls = deepAll(document, "input[type=file]").filter(function (el) { return !host.contains(el) && !el.disabled; });
    fileEls.forEach(function (el) {
      const d = describe(el);
      let ctx = d.desc;
      let n = el.parentElement;
      for (let i = 0; n && i < 4 && ctx.length < 400; i++, n = n.parentElement) ctx += " " + norm(txt(n)).slice(0, 160);
      let kind = /cover/.test(d.desc) ? "letter" : /resume|\bcv\b|curriculum/.test(d.desc) ? "cv" : /cover/.test(ctx) && !/resume|\bcv\b/.test(ctx) ? "letter" : /resume|\bcv\b|curriculum/.test(ctx) ? "cv" : "any";
      if (adapter.files) {
        if (adapter.files.letter && el.matches(adapter.files.letter)) kind = "letter";
        else if (adapter.files.cv && el.matches(adapter.files.cv)) kind = "cv";
      }
      const generic = !d.label || /^(attach|upload|browse|choose( a)? file|select files?|add file)$/i.test(d.label.trim());
      const label = generic ? (kind === "cv" ? "Resume/CV" : kind === "letter" ? "Cover letter" : "File upload") : d.label;
      files.push({ el: el, kind: kind, label: label, multiple: el.multiple });
    });
    /* drop zones without a file box of their own (Workday) */
    const zoneSel = (adapter.drop ? adapter.drop + "," : "") + "[class*='dropzone' i],[class*='drop-zone' i],[data-testid*='dropzone' i]";
    deepAll(document, zoneSel).forEach(function (z) {
      if (host.contains(z) || !visible(z) || z.querySelector("input[type=file]") || files.some(function (f) { return f.zone === z; })) return;
      if (files.some(function (f) { return z.contains(f.el) || f.el.closest("[class*='drop' i]") === z; })) return;
      const t = norm(txt(z));
      files.push({ zone: z, kind: /cover/.test(t) ? "letter" : "any", label: "Drop zone", multiple: true });
    });

    const flat = fields.filter(function (f) { return !f.grouped && f.kind && f.kind !== "never" && f.kind !== "consent"; });
    const consents = fields.filter(function (f) { return f.kind === "consent"; }).map(function (f) {
      return { el: f.el, label: (f.radio ? f.label : (ownLabel(f.el)[0] || f.label || questionText(f.el))).replace(/\s*\*\s*$/, "").slice(0, 140) };
    });
    /* free-text questions: long-answer boxes no other rule claimed, for the answer bank */
    const questions = fields.filter(function (f) {
      if (f.grouped || f.kind || f.radio || f.buttons) return false;
      const el = f.el, label = f.label || "";
      if (el.tagName === "TEXTAREA" || f.rich) return !!label;
      if (el.tagName !== "INPUT" || !/^(text|search|)$/.test(el.type || "") || el.getAttribute("role") === "combobox") return false;
      return /\?/.test(label) || label.length > 40;
    });
    return { adapter: adapter.name, flat: flat, groups: groups, add: add, files: files, questions: questions,
      consents: consents, calendar: calendar, login: loginPage(host), captcha: captchas(host),
      count: flat.length + groups.experience.length + groups.education.length + files.length + questions.length };
  };

  /* ------------------------------------------------------------ setting values (React, Vue and Angular see them) */
  function nativeSet(el, value) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : el.tagName === "SELECT" ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    desc.set.call(el, value);
  }
  function fire(el, type) { el.dispatchEvent(new Event(type, { bubbles: true, composed: true })); }
  function setText(el, value, keepFocus) {
    try { el.focus({ preventScroll: true }); } catch (e) { /* not focusable */ }
    nativeSet(el, value);
    el.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: String(value) }));
    if (keepFocus) return true;
    fire(el, "change");
    el.dispatchEvent(new FocusEvent("blur", { bubbles: false }));
    el.dispatchEvent(new FocusEvent("focusout", { bubbles: true, composed: true }));
    return true;
  }
  /* typing, one printable character at a time, as a keyboard would. Line breaks, Enter and Tab are never sent. */
  function keyInit(ch) {
    const code = /\d/.test(ch) ? "Digit" + ch : /[a-z]/i.test(ch) ? "Key" + ch.toUpperCase() : ch === " " ? "Space" : "";
    return { key: ch, code: code, bubbles: true, cancelable: true, composed: true };
  }
  async function typeText(el, text, delay) {
    try { el.focus({ preventScroll: true }); } catch (e) { /* not focusable */ }
    if (el.value) {
      nativeSet(el, "");
      el.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "deleteContentBackward" }));
    }
    for (const ch of String(text)) {
      if (/[\r\n\t]/.test(ch)) continue;
      let ok = el.dispatchEvent(new KeyboardEvent("keydown", keyInit(ch)));
      if (ok) ok = el.dispatchEvent(new KeyboardEvent("keypress", keyInit(ch)));
      if (ok) ok = el.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, composed: true, inputType: "insertText", data: ch }));
      if (ok) {
        nativeSet(el, (el.value || "") + ch);
        el.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: ch }));
      }
      el.dispatchEvent(new KeyboardEvent("keyup", keyInit(ch)));
      await JHA.sleep(delay || 16);
    }
  }
  JHA.typeText = typeText;

  /* --- matching an option to what we want */
  const DECLINE = /prefer not|rather not|not (to )?(say|answer|disclose|specify|declare|self ?identify|state)|decline|do(n't|nt| not) (wish|want) to|choose not|wish not|no answer|not disclosed|undisclosed|withh[eo]ld|i do not wish/;
  JHA.DECLINE = DECLINE;
  function clean(s) { return norm(s).replace(/\s*\*\s*$/, "").replace(/[.,;:!?]+$/, "").trim(); }
  const STOPW = { the: 1, a: 1, an: 1, of: 1, in: 1, and: 1, or: 1, to: 1, i: 1, my: 1, for: 1, at: 1 };
  function toks(s) {
    return clean(s).split(/[^a-z0-9+:'.]+/).map(function (t) { return t.replace(/^[.']+|[.']+$/g, "").replace(/'s$/, "").replace(/^([a-z]{3,})s$/, "$1"); })
      .filter(function (t) { return t && !STOPW[t]; });
  }
  function hasWord(hay, needle) {
    const i = hay.indexOf(needle);
    if (i < 0) return false;
    const re = new RegExp("(^|[^a-z0-9])" + needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "($|[^a-z0-9])");
    return re.test(hay);
  }
  function score(opt, target) {
    const o = clean(opt), t = clean(target);
    if (!o || !t) return 0;
    if (o === t) return 1;
    const short = t.length <= 3;
    if (o.indexOf(t + " ") === 0 || o.indexOf(t + ",") === 0 || o.indexOf(t + " (") === 0 || o.indexOf(t + " -") === 0) return short ? 0.9 : 0.93;
    if (short) return 0;
    if (hasWord(o, t)) return 0.86;
    if (o.length > 3 && hasWord(t, o)) return 0.5 + 0.3 * (o.length / t.length);
    const T = toks(t), O = toks(o);
    if (!T.length || !O.length) return 0;
    const inter = T.filter(function (x) { return O.indexOf(x) >= 0; }).length;
    if (!inter) return 0;
    return 0.75 * (0.65 * inter / T.length + 0.35 * inter / O.length);
  }
  JHA.score = score;
  function synonyms(key, want) {
    const w = norm(want);
    if (w === "yes") return ["yes", "y", "true"];
    if (w === "no") return ["no", "n", "false"];
    if (key === "country" && /united kingdom/.test(w)) return ["united kingdom", "uk", "great britain", "gb", "united kingdom of great britain and northern ireland", "england"];
    if (/master/.test(w) && /degree|level/.test(key)) return ["master's degree", "masters degree", "master's", "masters", "master", "msc", "postgraduate"];
    if (/bachelor|\bba\b/.test(w) && /degree|level/.test(key)) return ["bachelor's degree", "bachelors degree", "bachelor's", "bachelor", "ba", "undergraduate"];
    if (/bachelor/.test(w)) return ["bachelor's degree", "bachelors degree", "bachelor's", "bachelor", "ba", "undergraduate"];
    if (/^\d{1,2}$/.test(w) && key === "month") { const m = +w; return [String(m).padStart(2, "0"), String(m), MONTHS[m - 1], MONTHS[m - 1].slice(0, 3)]; }
    if (/^\d{1,2}$/.test(w) && key === "day") return [String(+w).padStart(2, "0"), String(+w)];
    if (key === "hear_about" && /career|company|website/.test(w)) return ["company careers website", "company website", "careers website", "company careers site", "careers site", "career site", "company career site", "company careers page", "careers page", "corporate website", "our website", "website"];
    return [w];
  }
  /* what to type into a typeahead, and the texts an option may match */
  JHA.targetsFor = function (key, value, opts) {
    opts = opts || {};
    let targets = [value].concat(synonyms(key, value)).concat(opts.alts || []);
    let queries = [value];
    if (key === "phone_code" && /^\+?44$/.test(String(value).trim())) {
      targets = ["united kingdom +44", "united kingdom (+44)", "+44 united kingdom", "uk (+44)", "uk +44", "gb +44", "gb (+44)", "united kingdom", "+44"];
      queries = ["United Kingdom", "+44"];
    }
    if (key === "location" || key === "city") queries.push(String(value).split(",")[0]);
    if (/degree|level/.test(key)) { const s = synonyms(key, value); if (s.length > 1) queries.push(s[s.length - 3] || s[0]); }
    const words = String(value).split(/\s+/);
    if (words.length > 2) queries.push(words.slice(0, 2).join(" "));
    const seen = {};
    targets = targets.filter(function (t) { const k = clean(t); if (!k || seen[k]) return false; seen[k] = 1; return true; });
    const qs = {};
    queries = queries.filter(function (q) { q = String(q || "").trim(); if (!q || qs[q.toLowerCase()]) return false; qs[q.toLowerCase()] = 1; return true; });
    return { targets: targets, queries: queries, decline: !!opts.decline, number: opts.number || null, key: key };
  };
  function amounts(s) {
    const out = [];
    String(s).replace(/(\d[\d,.]*)\s*(k\b)?/gi, function (m, n, k) {
      let v = parseFloat(n.replace(/,/g, ""));
      if (isNaN(v)) return m;
      if (k) v *= 1000;
      out.push(v);
      return m;
    });
    return out;
  }
  /* the option nearest a number: the range that contains it, else the closest */
  function pickNumber(opts, n) {
    let best = null;
    opts.forEach(function (o) {
      const t = norm(o.text), a = amounts(t);
      if (!a.length) return;
      let lo = a[0], hi = a.length > 1 ? a[1] : a[0];
      if (/\+|above|over|more than|or more|at least/.test(t) && a.length === 1) hi = Infinity;
      if (/under|below|less than|up to/.test(t) && a.length === 1) { hi = a[0]; lo = 0; }
      const dist = n >= lo && n <= hi ? 0 : Math.min(Math.abs(n - lo), Math.abs(n - hi));
      if (!best || dist < best.dist) best = { o: o, dist: dist };
    });
    if (!best) return null;
    return { el: best.o.el, text: best.o.text, value: best.o.value, score: best.dist === 0 ? 1 : 0.6 };
  }
  /* the best option for T (from targetsFor) among [{text, el}], with its score; null below the bar */
  function pick(opts, T) {
    const named = opts.filter(function (o) { const t = clean(o.text); return t && !/^(select|choose|please select|--|select one|select\.\.\.)/.test(t); });
    if (T.number && named.some(function (o) { return amounts(o.text).length; })) return pickNumber(named, T.number);
    let best = null;
    named.forEach(function (o) {
      let s = 0;
      if (T.decline) {
        if (!DECLINE.test(norm(o.text))) return;
        s = 0.6 + 0.4 * Math.max.apply(null, T.targets.map(function (t) { return score(o.text, t); }));
      } else {
        T.targets.forEach(function (t, i) { s = Math.max(s, score(o.text, t) * (1 - 0.01 * Math.min(i, 20))); });
      }
      if (!best || s > best.score) best = { el: o.el, text: o.text, value: o.value, score: s };
    });
    return best && best.score >= 0.5 ? best : null;
  }
  JHA.pick = pick;
  function bestOption(opts, key, want, extra) { return pick(opts, JHA.targetsFor(key, want, extra)); }

  function setSelect(el, key, value, opts) {
    const os = Array.prototype.filter.call(el.options, function (o) { return !o.disabled; }).map(function (o) { return { text: o.textContent, value: o.value, el: o }; });
    const o = bestOption(os.filter(function (x) { return x.value !== "" || x.text.trim(); }), key, value, opts);
    if (!o) { JHA.reason = "No option on its list matches “" + String(value).slice(0, 40) + "”"; return false; }
    nativeSet(el, o.value);
    fire(el, "input");
    fire(el, "change");
    return el.value === o.value;
  }

  /* --- typeaheads and comboboxes (react-select, Greenhouse location, Workday prompts) */
  function isCombo(el) {
    if (el.tagName !== "INPUT") return false;
    const aid = el.getAttribute("data-automation-id") || "";
    return el.getAttribute("role") === "combobox" || !!el.getAttribute("aria-autocomplete") || /^(listbox|true)$/.test(el.getAttribute("aria-haspopup") || "") ||
      !!el.closest("[role=combobox]") || aid === "searchBox" || !!el.closest("[data-uxi-widget-type='selectinput'],[data-automation-id='multiselectInputContainer']") ||
      /react-select/.test(el.id || "") || /select__input|Select-input/.test(el.className || "");
  }
  JHA.isCombo = isCombo;
  function comboRoot(el) {
    return el.closest("[role=combobox]:not(input),[data-uxi-widget-type='selectinput'],[data-automation-id='multiselectInputContainer'],[class*='select__control' i],[class*='-control' i][class*='select' i]") || el;
  }
  function listsOf(el) {
    const out = [];
    [el, el.closest("[role=combobox]")].forEach(function (n) {
      if (!n) return;
      ["aria-controls", "aria-owns"].forEach(function (a) {
        (n.getAttribute(a) || "").split(/\s+/).forEach(function (id) { const x = id && byId(el, id); if (x && out.indexOf(x) < 0) out.push(x); });
      });
    });
    return out;
  }
  function optionText(o) { return txt(o); }
  function comboOptions(el, host) {
    let els = [];
    listsOf(el).forEach(function (s) {
      const opt = s.querySelectorAll("[role=option]");
      els = els.concat(Array.from(opt.length ? opt : s.querySelectorAll("li")));
    });
    if (!els.filter(visible).length) {
      els = deepAll(document, "[role=listbox] [role=option], [role=option], [data-automation-id='promptOption'], [id*='-option-'], [class*='menu' i] [class*='option' i]:not(:has([class*='option' i])), [role=listbox] li");
    }
    const seen = [];
    return els.filter(function (o) {
      if (seen.indexOf(o) >= 0) return false;
      seen.push(o);
      if (host && host.contains(o)) return false;
      if (o.closest("[data-job-hunter-autofill]")) return false;
      if (!visible(o) || o.getAttribute("aria-disabled") === "true") return false;
      return !/^(loading|searching|no (options|results|matches|items))/i.test(txt(o));
    }).map(function (o) { return { el: o, text: optionText(o) }; });
  }
  function listOpen(el) {
    if (el.getAttribute("aria-expanded") === "true") return true;
    const r = el.closest("[role=combobox]");
    if (r && r.getAttribute("aria-expanded") === "true") return true;
    return comboOptions(el).length > 0;
  }
  /* the text a field shows around itself, without any open list: did a pick stick? */
  function fieldBox(el) {
    let n = el.parentElement, best = n;
    for (let i = 0; n && i < 5 && n !== document.body; i++, n = n.parentElement) {
      const k = n.querySelectorAll("input:not([type=hidden]),select,textarea").length;
      if (k > 2) break;
      best = n;
      if (n.matches("[data-automation-id^='formField-'],.field,[class*='field' i],fieldset,li")) break;
    }
    return best || el;
  }
  function boxText(box) {
    const out = [];
    const w = document.createTreeWalker(box, NodeFilter.SHOW_TEXT, {
      acceptNode: function (t) {
        const p = t.parentElement;
        if (!p || p.closest("[role=listbox],[role=option],[class*='menu' i],script,style")) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    while (w.nextNode()) out.push(w.currentNode.nodeValue);
    return clean(out.join(" "));
  }
  function occurrences(hay, needle) {
    if (!needle) return 0;
    const re = new RegExp("(^|[^a-z0-9])" + needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(?=$|[^a-z0-9])", "g");
    return (hay.match(re) || []).length;
  }
  async function confirmPick(el, chosen, before) {
    const t = clean(chosen.text);
    return !!(await JHA.waitFor(function () {
      if (el.isConnected && clean(el.value) === t) return true;
      const after = boxText(fieldBox(el));
      return occurrences(after, t) > occurrences(before, t);
    }, 900, 60));
  }
  function isActiveOption(el, o) {
    const id = el.getAttribute("aria-activedescendant") || (el.closest("[role=combobox]") || el).getAttribute("aria-activedescendant");
    if (id && o.id) return id === o.id;
    return o.getAttribute("aria-selected") === "true" || /is-focused|--focused|focused|highlighted|\bactive\b/i.test(o.className || "");
  }
  function kbd(key) { return new KeyboardEvent("keydown", { key: key, code: key, bubbles: true, cancelable: true, composed: true }); }
  /* ArrowDown to the option, then Enter: ONLY while focus is inside this combobox and its list is open, and only once
     the page itself shows that option as the highlighted one. Anything else: no keys at all. */
  JHA.keyboardPick = async function (el, option) {
    const inside = function () { const a = deepActive(); const root = comboRoot(el); return a === el || (root !== el && root.contains(a)); };
    if (!inside() || !listOpen(el)) return false;
    for (let i = 0; i < 40 && !isActiveOption(el, option); i++) {
      if (!inside() || !listOpen(el)) return false;
      el.dispatchEvent(kbd("ArrowDown"));
      await JHA.sleep(40);
    }
    if (!isActiveOption(el, option) || !option.isConnected) return false;
    if (!inside() || !listOpen(el)) return false; /* checked again right before Enter */
    el.dispatchEvent(kbd("Enter"));
    return true;
  };
  async function setCombo(el, key, value, opts) {
    const T = JHA.targetsFor(key, value, opts);
    const before = boxText(fieldBox(el));
    let best = null;
    for (const q of T.queries.slice(0, 3)) {
      el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, composed: true }));
      await typeText(el, q);
      best = await JHA.waitFor(function () { return pick(comboOptions(el), T); }, 1800, 80);
      if (best) {
        await JHA.sleep(180); /* async lists redraw a moment after the last key: take the option from the final list */
        best = pick(comboOptions(el), T) || best;
        break;
      }
    }
    if (!best) { JHA.reason = "No option on its list matches “" + String(value).slice(0, 40) + "”: pick it yourself"; return "typed"; }
    if (JHA.canClick(best.el, "option")) {
      best.el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, composed: true }));
      JHA.safeClick(best.el, "option");
      if (await confirmPick(el, best, before)) return "ok";
      /* a two-level list (Workday's "How did you hear"): a category opened; pick inside it */
      const next = pick(comboOptions(el).filter(function (o) { return o.el !== best.el; }), T);
      if (next && JHA.canClick(next.el, "option")) {
        next.el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, composed: true }));
        JHA.safeClick(next.el, "option");
        if (await confirmPick(el, next, before)) return "ok";
      }
    }
    if (best.el.isConnected && await JHA.keyboardPick(el, best.el) && await confirmPick(el, best, before)) return "ok";
    JHA.reason = "Chose “" + best.text.slice(0, 40) + "” but the page didn't keep it: pick it yourself";
    return "typed";
  }
  async function openAndPick(btn, key, value, opts) {
    if (!JHA.canClick(btn, "open")) return false;
    const T = JHA.targetsFor(key, value, opts);
    const before = boxText(fieldBox(btn)) + " " + clean(txt(btn));
    JHA.safeClick(btn, "open");
    const option = await JHA.waitFor(function () { return pick(comboOptions(btn), T); }, 1500);
    if (option && JHA.canClick(option.el, "option")) {
      JHA.safeClick(option.el, "option");
      await JHA.sleep(60);
      const t = clean(option.text);
      if (clean(txt(btn)) === t || occurrences(boxText(fieldBox(btn)) + " " + clean(txt(btn)), t) > occurrences(before, t)) return true;
      return true; /* a list that closed without showing the pick still took it in most sites; the capture checks later */
    }
    JHA.reason = option ? "Its list option can't be pressed safely" : "No option on its list matches “" + String(value).slice(0, 40) + "”";
    return false;
  }
  function radioPick(f, key, value, opts) {
    const name = f.el.name;
    const box = f.el.closest("fieldset,[role=radiogroup]") || f.el.form || document;
    const radios = Array.prototype.filter.call(box.querySelectorAll("input[type=radio]"), function (r) { return !name || r.name === name; });
    const os = radios.map(function (r) { return { text: describe(r).label || (r.labels && r.labels[0] && txt(r.labels[0])) || r.value, el: r }; });
    const o = bestOption(os, key, value, opts);
    if (!o) { JHA.reason = "None of its answers matches “" + String(value).slice(0, 40) + "”"; return false; }
    if (!o.el.checked) JHA.safeClick(o.el);
    return o.el.checked;
  }

  /* --- rich text editors: select everything, then insert; checked by reading the text back */
  function lines(s) { return String(s).split(/\n/).map(function (l) { return l.replace(/\s+/g, " ").trim(); }).filter(Boolean); }
  function richOk(el, text) {
    const got = lines(el.innerText || ""), want = lines(text);
    return got.join(" ") === want.join(" ") && got.length === want.length;
  }
  function selectAll(el) {
    try { el.focus({ preventScroll: true }); } catch (e) { /* not focusable */ }
    const root = el.getRootNode();
    const sel = (root.getSelection && root.getSelection()) || document.getSelection();
    const r = document.createRange();
    r.selectNodeContents(el);
    sel.removeAllRanges();
    sel.addRange(r);
  }
  const RICH = [
    ["execCommand", function (el, text) {
      String(text).split("\n").forEach(function (line, i) {
        if (i) document.execCommand("insertParagraph");
        if (line) document.execCommand("insertText", false, line);
      });
    }],
    ["paste", function (el, text) {
      const dt = new DataTransfer();
      dt.setData("text/plain", text);
      el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true, composed: true }));
    }],
    ["beforeinput", function (el, text) {
      const dt = new DataTransfer();
      dt.setData("text/plain", text);
      const ok = el.dispatchEvent(new InputEvent("beforeinput", { inputType: "insertFromPaste", dataTransfer: dt, bubbles: true, cancelable: true, composed: true }));
      if (ok) el.dispatchEvent(new InputEvent("beforeinput", { inputType: "insertText", data: text, bubbles: true, cancelable: true, composed: true }));
    }]
  ];
  JHA.setRich = async function (el, text) {
    if (richOk(el, text)) return "already";
    for (const m of RICH) {
      selectAll(el);
      try { m[1](el, text); } catch (e) { /* the next way */ }
      await JHA.sleep(60);
      /* an editor that keeps its own model redraws from it: wait for that before believing the text */
      if (richOk(el, text)) { await JHA.sleep(320); if (richOk(el, text)) return m[0]; }
    }
    JHA.reason = "The editor didn't keep the text: paste it yourself";
    return null;
  };

  /* --- Workday's date boxes: separate MM and YYYY parts that only take typing */
  function isSegment(el) {
    return el.tagName === "INPUT" && (/^dateSection(Month|Day|Year)-input$/.test(el.getAttribute("data-automation-id") || "") || el.getAttribute("role") === "spinbutton");
  }
  async function typeSegment(el, value) {
    await typeText(el, value, 30);
    await JHA.sleep(40);
    const v = String(value).replace(/^0+/, "");
    const shown = [el.value, el.getAttribute("aria-valuetext"), el.getAttribute("aria-valuenow")].map(function (x) { return String(x || "").replace(/^0+/, ""); });
    return shown.indexOf(v) >= 0;
  }

  /* fill one field; returns "ok", "typed" (needs a pick from a list), or "fail". JHA.reason says why, if not ok. */
  JHA.fillField = async function (f, key, value, opts) {
    opts = opts || {};
    JHA.reason = "";
    const adapter = JHA.adapter();
    if (adapter.value) value = adapter.value(key, value);
    const el = f.el;
    try {
      if (f.buttons) {
        const b = /^y/i.test(value) ? f.yes : /^n/i.test(value) ? f.no : null;
        if (!b || !JHA.canClick(b, "yesno")) { JHA.reason = "Only Yes or No buttons here"; return "fail"; }
        JHA.safeClick(b, "yesno");
        return "ok";
      }
      if (f.radio) return radioPick(f, key, value, opts) ? "ok" : "fail";
      if (el.tagName === "SELECT") return setSelect(el, key, value, opts) ? "ok" : "fail";
      if (el.type === "checkbox" || el.getAttribute("role") === "checkbox") {
        const checked = function () { return el.type === "checkbox" ? el.checked : el.getAttribute("aria-checked") === "true"; };
        if (opts.choice) {
          /* one box of a "tick all that apply" list: tick it only if it is the answer */
          const label = ownLabel(el)[0] || describe(el).label;
          const T = JHA.targetsFor(key, value, opts);
          const hit = T.decline ? DECLINE.test(norm(label)) : T.targets.some(function (t) { return score(label, t) >= 0.86; });
          if (!hit) return "skip";
          if (!checked()) JHA.safeClick(el);
          return checked() ? "ok" : "fail";
        }
        const want = /^(yes|true|1)$/i.test(value);
        if (checked() !== want) JHA.safeClick(el);
        return "ok";
      }
      if (el.tagName === "BUTTON") return (await openAndPick(el, key, value, opts)) ? "ok" : "fail";
      if (f.rich || isRich(el)) return (await JHA.setRich(el, value)) ? "ok" : "fail";
      if (isSegment(el)) return (await typeSegment(el, value)) ? "ok" : "fail";
      if (el.type === "date" || el.type === "month") {
        setText(el, value);
        await JHA.sleep(30);
        if (el.value === value) return "ok";
        JHA.reason = "The date picker didn't take " + value + ": pick it yourself";
        return "fail";
      }
      if (isCombo(el)) return await setCombo(el, key, value, opts);
      setText(el, value);
      await JHA.sleep(30);
      if (norm(el.value) === norm(value)) return "ok";
      JHA.reason = "The page changed it back";
      return "fail";
    } catch (e) {
      JHA.reason = String(e && e.message || e).slice(0, 80);
      return "fail";
    }
  };
  JHA.isNumeric = function (el) {
    return el.type === "number" || /^(decimal|numeric)$/.test(el.getAttribute("inputmode") || "") || /^\^?\[?\\?d/.test(el.getAttribute("pattern") || "");
  };

  /* the value a part of an experience or education entry takes */
  JHA.entryValue = function (entry, part, date, kind, extras, el) {
    const d = part === "start" ? entry.start : part === "end" ? entry.end : null;
    if (d) {
      if (part === "end" && entry.current && kind === "experience") return ""; /* a course still running keeps its expected end */
      if (!d.year) return "";
      return JHA.formatDate(d, date || "text", d.text);
    }
    if (kind === "experience") {
      if (part === "title") return entry.title;
      if (part === "company") return entry.company;
      if (part === "location") return entry.location;
      if (part === "current") return entry.current ? "yes" : "no";
      if (part === "description") return (entry.bullets || []).concat(extras || []).map(function (b) { return "• " + b; }).join("\n");
    } else {
      if (part === "school") return entry.school;
      if (part === "degree") return entry.degree;
      if (part === "level") return entry.level || "";
      if (part === "field") return entry.field || "";
      if (part === "grade") return (el && JHA.isNumeric(el) && (entry.gpa || entry.points)) || entry.grade || "";
      if (part === "status") return entry.status || "";
      if (part === "current") return entry.current ? "yes" : "no";
    }
    return "";
  };
  JHA.entryAlts = function (entry, part) {
    if (part === "grade") return entry.grade_names || [];
    if (part === "status") return entry.current ? ["in progress", "ongoing", "currently studying", "expected", "not completed"] : ["completed", "graduated", "complete", "finished"];
    return [];
  };

  /* ------------------------------------------------------------ the record of a sent form (passive: reads only) */
  /* label/value pairs of every field with a value, and the names of attached files. Equal-opportunity, salary,
     consent and password fields are left out, as are hidden fields; nothing on the page is touched. */
  const SKIP_CAPTURE = /password|national insurance|passport|social security|\bssn\b|gender|\bsex\b|\brace\b|ethnic|veteran|disabilit|sexual|orientation|pronoun|religio|birth|\bage\b|salary|compensation|pay expect|remuneration|criminal|convict|signature|captcha/;
  JHA.capture = function (host) {
    const out = [], seen = {};
    function add(label, value) {
      label = String(label || "").replace(/\s*\*\s*$/, "").trim().slice(0, 300) || "(no label)";
      value = String(value == null ? "" : value).trim();
      if (!value) return;
      const k = label + "\u0000" + value;
      if (seen[k]) return;
      seen[k] = 1;
      out.push({ label: label, value: value.slice(0, 12000) });
    }
    const els = deepAll(document, "input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=image]):not([type=reset]):not([type=file]):not([type=password]),select,textarea,button[aria-haspopup='listbox'],[contenteditable='true']")
      .filter(function (el) { return !(host && host.contains(el)) && (!el.isContentEditable || isRich(el)); });
    const radios = {};
    els.forEach(function (el) {
      const d = describe(el);
      if (SKIP_CAPTURE.test(d.desc) || (NEVER.test(d.desc) && !/\b(if (yes|so|no)|previously|worked)/.test(d.desc))) return;
      if (el.type === "radio") {
        if (!el.checked) return;
        const key = el.name || "";
        if (key && radios[key]) return;
        radios[key] = 1;
        const q = questionText(el) || d.label;
        if (SKIP_CAPTURE.test(norm(q))) return;
        return add(q, (el.labels && el.labels[0] && txt(el.labels[0])) || el.value);
      }
      if (el.type === "checkbox") return el.checked ? add(d.label || questionText(el), "Yes") : null;
      if (el.tagName === "SELECT") {
        const o = el.options[el.selectedIndex];
        const t = o ? txt(o) : "";
        return (!o || !o.value || /^(select|choose|please select|--)/i.test(t)) ? null : add(d.label, t);
      }
      if (el.tagName === "BUTTON") {
        const t = txt(el);
        return /^(select( one)?|choose)/i.test(t) ? null : add(d.label || questionText(el), t);
      }
      if (el.isContentEditable) return add(d.label || questionText(el), el.innerText);
      add(d.label || questionText(el), el.value);
    });
    /* Yes/No answers drawn as buttons (Ashby): the one marked pressed or selected */
    deepAll(document, "button[aria-pressed='true'],button.on,button[aria-checked='true'],button[data-selected='true']").forEach(function (b) {
      if (host && host.contains(b) || !/^\s*(yes|no)\s*$/i.test(b.textContent || "")) return;
      const q = questionText(b.parentElement) || questionText(b);
      if (q && !SKIP_CAPTURE.test(norm(q))) add(q, txt(b));
    });
    const files = [];
    deepAll(document, "input[type=file]").forEach(function (el) {
      if (host && host.contains(el)) return;
      Array.prototype.forEach.call(el.files || [], function (f) { if (files.indexOf(f.name) < 0) files.push(f.name); });
    });
    return { fields: out, files: files };
  };

  /* ------------------------------------------------------------ files */
  function hasFile(input, name) {
    return Array.prototype.some.call(input.files || [], function (f) { return f.name === name; });
  }
  function pageShows(name, host) {
    const t = document.body ? document.body.textContent || "" : "";
    if (t.indexOf(name) >= 0) return true;
    return deepAll(document, "input[type=file]").some(function (i) { return !(host && host.contains(i)) && hasFile(i, name); });
  }
  function drop(z, file) {
    const dt = new DataTransfer();
    dt.items.add(file);
    ["dragenter", "dragover", "drop"].forEach(function (t) {
      z.dispatchEvent(new DragEvent(t, { bubbles: true, cancelable: true, composed: true, dataTransfer: dt }));
    });
  }
  /* "ok", or "fail" when the page refused the file (the box is still empty, or the site cleared it) */
  JHA.attach = async function (target, file, host) {
    if (target.el) {
      const el = target.el;
      const dt = new DataTransfer();
      if (target.multiple && el.files) Array.prototype.forEach.call(el.files, function (f) { if (f.name !== file.name) dt.items.add(f); });
      dt.items.add(file);
      try { el.files = dt.files; } catch (e) { /* read-only in some frameworks */ }
      fire(el, "input");
      fire(el, "change");
      await JHA.sleep(450); /* a site that refuses files clears the box just after */
      if (el.isConnected && hasFile(el, file.name)) return "ok";
      /* the second way: drop it onto the box's drop area */
      const zone = el.closest("[class*='drop' i],[data-automation-id*='drop' i],[data-testid*='drop' i],label,.field,[class*='upload' i]") || el.parentElement;
      if (zone) {
        drop(zone, file);
        await JHA.sleep(450);
        if ((el.isConnected && hasFile(el, file.name)) || pageShows(file.name, host)) return "ok";
      }
      return "fail";
    }
    drop(target.zone, file);
    return (await JHA.waitFor(function () { return pageShows(file.name, host); }, 4000, 150)) ? "ok" : "fail";
  };
  JHA.fileTarget = function (scan, want) {
    const exact = scan.files.find(function (f) { return f.kind === want; });
    if (exact) return exact;
    if (want === "letter") return scan.files.find(function (f) { return f.kind === "any"; }) || scan.files.find(function (f) { return f.kind === "cv" && f.multiple; });
    return scan.files.find(function (f) { return f.kind === "any"; });
  };
})();
