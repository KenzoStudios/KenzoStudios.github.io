/* Job Hunter Autofill: the content script's main part.
   On the Job Hunter dashboard it only says "the extension is here". On an application page it asks Job Hunter
   (through the background worker) which role this is, shows the panel, and fills what the user ticks.
   It never submits: see the safety notes in fill.js. After a fill it listens (passively) for the user sending the form,
   and keeps a record of what was sent; on a confirmation page it offers "Mark as applied" and, in an apply session,
   "Next role", which opens the next posting by changing location.href. It never clicks anything on the page to do so.
   Run mode fills each step of a multi-step form as the user moves through it; it never presses Next itself. */
(function () {
  const JHA = globalThis.JHA;
  if (!JHA || JHA.started) return;
  JHA.started = true;
  const esc = JHA.esc, ic = JHA.ic;
  const TOP = window === window.top;

  /* ------------------------------------------------------------ the dashboard: tell it autofill is installed */
  if (document.querySelector('meta[name="job-hunter"]')) {
    if (TOP) {
      document.documentElement.setAttribute("data-jh-autofill", JHA.version);
      window.dispatchEvent(new CustomEvent("jh-autofill", { detail: { version: JHA.version } }));
    }
    return;
  }

  const ATS = JHA.ATS_HOST.test(location.hostname);
  /* inside frames, only embedded application forms (a Greenhouse board inside a firm's careers page, say) */
  if (!TOP && !ATS) return;
  const EMBED = "iframe[src*='greenhouse.io'],iframe#grnhse_iframe,iframe[src*='lever.co'],iframe[src*='ashbyhq.com'],iframe[src*='smartrecruiters.com'],iframe[src*='myworkdayjobs.com']";

  const MATCH_LABEL = {
    url: "Matched by posting link", ats: "Matched by posting ID", site: "Same job board",
    active: "From your Apply click", picked: "Chosen by you", session: "Your apply session"
  };
  const S = {
    phase: "idle", data: null, scan: null, error: "",
    ticks: {}, parts: {}, slots: { experience: [], education: [] }, extras: {}, results: {}, files: {},
    showMore: false, showChanges: false, picker: false, roles: null, letter: "pdf", tailoredFmt: "pdf",
    collapsed: false, busy: false, status: { text: "", tone: "" }, shown: false, forced: false, hidden: false,
    q: {}, qResults: {}, qList: [],
    filledAt: 0, snap: { order: [], values: {}, files: [] }, snapSig: "", lastCapture: 0, attached: [],
    confirmed: false, marked: false,
    reasons: {}, run: false, runKey: "", runSteps: 0, runEls: null, maEdit: null, maDraft: "", fileData: {}
  };
  let panel = null, lastUrl = location.href, settings = { open: false };
  const hostEl = function () { return panel ? panel.host : document.createElement("i"); };

  /* ------------------------------------------------------------ state helpers */
  function field(key) { return (S.data && S.data.fields || []).find(function (f) { return f.key === key; }); }
  function entries(kind) { return (S.data && S.data[kind]) || []; }
  function looksLikeForm(scan) {
    return scan.flat.length >= 2 || scan.files.length > 0 || scan.groups.experience.length > 0 || !!scan.login || scan.consents.length > 0;
  }
  /* on a sign-in page only the email is filled; on an account-creation page, the email and the name */
  function pageFlat() {
    const flat = S.scan ? S.scan.flat : [];
    if (!S.scan || !S.scan.login) return flat;
    const ok = S.scan.login.kind === "create" ? /^(email|first_name|last_name|full_name)$/ : /^email$/;
    return flat.filter(function (f) { return ok.test(f.kind); });
  }
  /* ------------------------------------------------------------ the user's standing answers (profile/my_answers.json) */
  function myAnswer(key) { return ((S.data && S.data.my_answers && S.data.my_answers.answers) || []).find(function (a) { return a.key === key; }) || null; }
  function myKeysOnPage() {
    const seen = {}, out = [];
    pageFlat().forEach(function (f) { if (/^my:/.test(f.kind) && !seen[f.kind]) { seen[f.kind] = 1; out.push({ key: f.kind.slice(3), f: f }); } });
    return out;
  }
  function myOn(a) { return !!(a && a.mode === "fill" && String(a.value || "").trim()); }
  function euroRole(f) {
    const loc = JHA.norm(S.data && S.data.job && S.data.job.location || "");
    const optText = f.el.tagName === "SELECT" ? JHA.norm(f.el.textContent) : "";
    if (/€|\beur\b/.test(optText) && !/£|\bgbp\b/.test(optText)) return true;
    if (/£|\bgbp\b/.test(optText)) return false;
    return /dublin|ireland/.test(loc) && !/london|united kingdom|\buk\b|england/.test(loc);
  }
  /* what one of the user's answers puts in a given box: {value, opts} or null when it's his to fill */
  function myFill(key, f) {
    const a = myAnswer(key);
    if (!myOn(a)) return null;
    const el = f.el, opts = {};
    let value = String(a.value).trim();
    if (key === "salary") {
      const eur = euroRole(f);
      const num = eur ? a.eur_number : a.number;
      const textBox = !f.radio && !f.buttons && el.tagName !== "SELECT" && el.tagName !== "BUTTON" && !JHA.isCombo(el);
      if (textBox && JHA.isNumeric(el)) return num ? { value: String(num), opts: opts } : null;
      if (textBox) return { value: (eur ? a.eur_free_text || a.eur_value : a.free_text) || value, opts: opts };
      opts.number = num || null;
      if (eur && a.eur_value) value = a.eur_value;
    }
    if (key === "dob") {
      const m = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
      if (!m) return null;
      opts.date = { year: +m[1], month: +m[2], day: +m[3], text: value };
    }
    if (JHA.DECLINE.test(JHA.norm(value))) opts.decline = true;
    if (el.type === "checkbox" || el.getAttribute("role") === "checkbox") opts.choice = true;
    return { value: value, opts: opts };
  }
  async function saveMy(changes, msg) {
    try {
      const r = await JHA.send("saveMyAnswers", { answers: changes });
      S.data.my_answers = r;
      setStatus(msg || "Saved to My answers.", "ok");
    } catch (e) { setStatus("Couldn’t save: " + e.message, "bad"); }
  }
  function setStatus(text, tone) { S.status = { text: text, tone: tone || "" }; render(); }

  function resetChoices() {
    S.ticks = {}; S.parts = {}; S.extras = {}; S.results = {}; S.files = {}; S.q = {}; S.qResults = {}; S.reasons = {}; S.fileData = {};
    (S.data.fields || []).forEach(function (f) { S.ticks[f.key] = !!f.default; });
    S.slots = { experience: [], education: [] };
  }
  /* slot i of a repeating section takes entry i, unless the user picks another */
  function syncSlots() {
    ["experience", "education"].forEach(function (kind) {
      const n = S.scan ? S.scan.groups[kind].length : 0;
      const es = entries(kind);
      for (let i = 0; i < n; i++) {
        if (S.slots[kind][i] === undefined) S.slots[kind][i] = i < es.length ? i : -1;
        (S.scan.groups[kind][i].fields || []).forEach(function (p) {
          const k = kind + "." + i + "." + p.part;
          if (S.parts[k] === undefined) S.parts[k] = true;
        });
      }
    });
  }
  /* a ticked extra line goes to the first box holding that employer (an employer split into two roles: it goes to the first) */
  function extrasFor(entry, slot) {
    if (slot !== undefined && S.scan) {
      const first = S.slots.experience.findIndex(function (j) { const e = entries("experience")[j]; return e && e.company === entry.company; });
      if (first >= 0 && first !== slot) return [];
    }
    return (S.data.extras || []).filter(function (x, i) { return S.extras[i] && x.attach === entry.company; }).map(function (x) { return x.text; });
  }
  /* where a ticked extra line will go */
  function extraTarget(x) {
    const g = S.scan ? S.scan.groups.experience : [];
    for (let i = 0; i < g.length; i++) {
      const e = entries("experience")[S.slots.experience[i]];
      if (e && e.company === x.attach && g[i].fields.some(function (p) { return p.part === "description"; })) return "Adds to the " + e.company.split(" ")[0] + " description";
    }
    return null;
  }

  /* ------------------------------------------------------------ the answer bank's questions */
  function bank() { return (S.data && S.data.answers) || { standard: [], role: [] }; }
  function answerById(id) {
    if (!id) return null;
    const p = id.split(":"), list = p[0] === "r" ? bank().role : bank().standard;
    return list[+p[1]] || null;
  }
  function rx(p) { try { return new RegExp(p, "i"); } catch (e) { return null; } }
  function hits(a, text) { return (a.patterns || []).some(function (p) { const r = rx(p); return r && r.test(text); }); }
  /* the long-answer boxes on the page, each with a stable key (its question, numbered if it repeats) */
  function questions() {
    const seen = {};
    return ((S.scan && S.scan.questions) || []).map(function (q) {
      const base = JHA.norm(q.label);
      seen[base] = (seen[base] || 0) + 1;
      return { q: q, key: base + "#" + seen[base] };
    });
  }
  /* a new box gets the answer whose patterns match its question. A single role answer (or a single standard one)
     is ticked; two that both fit, an answer longer than the box allows, or no match at all stay unticked. */
  function syncQuestions() {
    questions().forEach(function (x) {
      if (S.q[x.key]) return;
      const label = JHA.norm(x.q.label);
      const pick = function (list, tag) { return list.map(function (a, i) { return { id: tag + ":" + i, a: a }; }).filter(function (y) { return hits(y.a, label); }); };
      const role = pick(bank().role, "r"), std = pick(bank().standard, "s");
      const tier = role.length ? role : std;
      const choice = tier.length ? tier[0].id : "";
      let on = tier.length === 1, note = tier.length > 1 ? "Several answers fit this question: check this is the right one." : "";
      const a = answerById(choice), max = x.q.el.maxLength;
      if (a && max > 0 && a.answer.length > max) { on = false; note = "Longer than this box allows (" + max + " characters): shorten it yourself."; }
      S.q[x.key] = { choice: choice, on: on, note: note };
    });
  }

  /* ------------------------------------------------------------ rendering */
  function stIcon(r, why) {
    if (r === "ok") return '<span class="st ok" title="Filled">' + ic("check") + "</span>";
    if (r === "typed" || r === "cal") return '<span class="st wait" title="' + esc(why || "Typed; pick it from the list on the page") + '">' + ic("alert") + "</span>";
    if (r === "fail" || r === "skip") return '<span class="st bad" title="' + esc(why || "Didn’t take: fill this one yourself") + '">' + ic("alert") + "</span>";
    return '<span class="st"></span>';
  }
  function whyHTML(key) {
    const r = S.results[key], w = S.reasons[key];
    return w && r && r !== "ok" ? '<div class="rsn ' + (r === "typed" ? "wait" : "bad") + '">' + esc(w) + "</div>" : "";
  }
  function rowsHTML() {
    const flat = pageFlat().filter(function (f) { return !/^my:/.test(f.kind); });
    const seen = {}, order = [];
    flat.forEach(function (f) { if (!seen[f.kind] && field(f.kind)) { seen[f.kind] = f; order.push(f.kind); } });
    const groups = {};
    order.forEach(function (k) { const g = field(k).group; (groups[g] = groups[g] || []).push(k); });
    let h = "";
    Object.keys(groups).forEach(function (g) {
      h += '<p class="gl">' + esc(g) + "</p>";
      groups[g].forEach(function (k) {
        const f = field(k), on = !!S.ticks[k];
        const ad = JHA.adapter(), shown = ad.value ? ad.value(k, f.value) : f.value;
        h += '<label class="row' + (on ? "" : " off") + '" title="' + esc("On the page: " + (seen[k].label || k)) + '">' +
          '<input type="checkbox" class="cb" data-tick="' + esc(k) + '" data-fk="t-' + esc(k) + '"' + (on ? " checked" : "") + ">" +
          '<span class="k">' + esc(f.label) + '</span><span class="v">' + esc(shown) + "</span>" + stIcon(S.results[k], S.reasons[k]) + "</label>" + whyHTML(k);
      });
    });
    /* date boxes only a calendar can set */
    (S.scan.calendar || []).forEach(function (c, i) {
      h += '<div class="row copy cal"><span class="k">' + esc(c.label) + '</span><span class="v">Calendar only: pick the date yourself</span>' +
        '<button type="button" class="ib" data-act="jump" data-arg="cal:' + i + '" aria-label="Jump to ' + esc(c.label) + '">' + ic("target") + "</button></div>";
    });
    /* values Job Hunter has that this page didn't ask for: shown on request, to copy */
    const rest = S.scan.login ? [] : (S.data.fields || []).filter(function (f) { return !seen[f.key] && !/^(school|degree|degree_level|field|grade|graduation|work_history)$/.test(f.key); });
    if (rest.length) {
      h += '<button type="button" class="more" data-act="more" data-fk="more" aria-expanded="' + S.showMore + '">' + ic("dn") + (S.showMore ? "Hide" : "Show") + " " + rest.length + " more, not asked here</button>";
      if (S.showMore) rest.forEach(function (f) {
        h += '<div class="row copy"><span class="k">' + esc(f.label) + '</span><span class="v">' + esc(f.value) + '</span><button type="button" class="ib" data-act="copy" data-arg="' + esc(f.value) + '" aria-label="Copy ' + esc(f.label) + '">' + ic("copy") + "</button></div>";
      });
    }
    return h;
  }
  const PART = { title: "Title", company: "Company", location: "Location", start: "From", end: "To", current: "Current", description: "Description",
    school: "School", degree: "Degree", level: "Degree type", field: "Field", grade: "Grade" };
  function slotsHTML(kind) {
    const g = S.scan.groups[kind], es = entries(kind);
    if (!g.length) return "";
    let h = '<section class="sec"><div class="sh"><h3>' + (kind === "experience" ? "Experience" : "Education") + '</h3><span class="n">' + g.length + (g.length === 1 ? " box" : " boxes") + "</span></div>";
    if (kind === "experience") h += '<p class="note">Bullets are pasted 1:1 from ' + esc(S.data.cv_file || "your CV") + ".</p>";
    g.forEach(function (slot, i) {
      const sel = S.slots[kind][i];
      const e = es[sel];
      h += '<div class="slot"><div class="slot-h"><span class="lab">Box ' + (i + 1) + '</span><select class="sel" data-slot="' + kind + "." + i + '" data-fk="s-' + kind + i + '" aria-label="What goes in ' + kind + " box " + (i + 1) + '">' +
        es.map(function (x, j) {
          const name = kind === "experience" ? x.company + " · " + x.title : x.school + (x.degree ? " · " + x.degree : "");
          return '<option value="' + j + '"' + (j === sel ? " selected" : "") + ">" + esc(name) + "</option>";
        }).join("") + '<option value="-1"' + (sel === -1 ? " selected" : "") + ">Leave empty</option></select></div>";
      if (e) {
        const parts = [], seenPart = {};
        slot.fields.forEach(function (p) {
          if (seenPart[p.part]) return;
          seenPart[p.part] = 1;
          const k = kind + "." + i + "." + p.part, on = S.parts[k] !== false;
          const r = slot.fields.filter(function (q) { return q.part === p.part; }).map(function (q, n) { return S.results[k + "." + n]; });
          const res = r.indexOf("fail") >= 0 ? "fail" : r.indexOf("typed") >= 0 ? "typed" : r.length && r.every(function (x) { return x === "ok"; }) ? "ok" : "";
          let label = PART[p.part] || p.part;
          if (p.part === "description") label += " · " + (e.bullets || []).length + " bullets";
          parts.push('<label class="part"><input type="checkbox" class="cb" data-tick="part:' + k + '" data-fk="p-' + k + '"' + (on ? " checked" : "") + ">" + esc(label) + stIcon(res) + "</label>");
        });
        h += '<div class="parts">' + parts.join("") + "</div>";
        if (kind === "experience" && seenPart.description) {
          const ex = extrasFor(e, i);
          h += '<ul class="bul">' + (e.bullets || []).map(function (b) { return "<li>" + esc(b) + "</li>"; }).join("") +
            ex.map(function (b) { return '<li class="x">' + esc(b) + "</li>"; }).join("") + "</ul>";
        }
      }
      h += "</div>";
    });
    const free = es.length - g.length;
    const add = S.scan.add[kind];
    if (free > 0 && add) {
      h += '<div class="slot"><p class="note" style="margin:0 0 8px">The form has ' + g.length + (g.length === 1 ? " box" : " boxes") + "; your CV has " + es.length + ". Add another box for " +
        esc(kind === "experience" ? es[g.length].company : es[g.length].school) + '?</p><button type="button" class="btn" data-act="add" data-arg="' + kind + '" data-fk="add-' + kind + '">' + ic("plus") + "Add another box</button>" +
        '<p class="note" style="margin:6px 0 0">Presses the page’s “' + esc((add.textContent || "Add").trim().slice(0, 30)) + "” button, which Job Hunter has checked is not a submit button.</p></div>";
    }
    return h + "</section>";
  }
  function extrasHTML() {
    const xs = S.data.extras || [], held = S.data.extras_held_back || [];
    if (!xs.length && !held.length) return "";
    let h = '<section class="sec"><div class="sh"><h3>Optional lines</h3><span class="n">' + xs.length + "</span></div>" +
      '<p class="note">Off until you tick them. Each is a true line from facts.md, picked for this posting.</p>';
    xs.forEach(function (x, i) {
      const on = !!S.extras[i], to = extraTarget(x);
      h += '<label class="extra"><input type="checkbox" class="cb" data-tick="extra:' + i + '" data-fk="x-' + i + '"' + (on ? " checked" : "") + ">" +
        '<span><span class="t">' + esc(x.text) + '</span><span class="why">' + esc(x.reason || "") + "</span>" +
        '<span class="to">' + (to ? "<b>" + esc(to) + "</b>" : "No description box for it here: copy it instead") + "</span></span>" +
        '<button type="button" class="ib" data-act="copy" data-arg="' + esc(x.text) + '" aria-label="Copy this line">' + ic("copy") + "</button></label>";
    });
    if (held.length) h += '<p class="note" style="margin-top:6px" title="' + esc(held.map(function (x) { return x.text + " (" + x.why + ")"; }).join("\n")) + '">' +
      held.length + (held.length === 1 ? " suggested line was" : " suggested lines were") + " held back: not traceable to facts.md, or it had a dash.</p>";
    return h + "</section>";
  }
  function questionsHTML() {
    const qs = questions();
    S.qList = qs.map(function (x) { return x.key; });
    if (!qs.length) return "";
    const b = bank(), n = qs.filter(function (x) { return S.q[x.key] && S.q[x.key].on && S.q[x.key].choice; }).length;
    let h = '<section class="sec"><div class="sh"><h3>Questions</h3><span class="n">' + n + " of " + qs.length + " ticked</span></div>" +
      '<p class="note">Answers from your answer bank: this role’s letter and facts.md. Anything uncertain is left unticked. Read each one before you submit.</p>';
    qs.forEach(function (x, i) {
      const st = S.q[x.key] || { choice: "", on: false }, a = answerById(st.choice), on = !!(st.on && a);
      const opt = function (id, label) { return '<option value="' + id + '"' + (id === st.choice ? " selected" : "") + ">" + esc(label) + "</option>"; };
      const KEYS = { why_firm: "Why this firm", why_role: "Why this role", about_you: "About you", strength: "What you’d bring", motivation: "What motivates you", other: "Other" };
      const opts = b.role.map(function (r, j) { return opt("r:" + j, "This role · " + (KEYS[r.key] || r.key)); })
        .concat(b.standard.map(function (r, j) { return opt("s:" + j, "Standard · " + r.key.replace(/_/g, " ")); }))
        .concat([opt("", "Leave empty")]).join("");
      h += '<div class="q' + (on ? " on" : "") + '"><label class="q-h"><input type="checkbox" class="cb" data-tick="q:' + i + '" data-fk="q-' + i + '"' + (on ? " checked" : "") + (a ? "" : " disabled") + ">" +
        '<span class="ql">' + esc(x.q.label) + "</span>" + stIcon(S.qResults[x.key]) + "</label>" +
        '<select class="sel qsel" data-slot="q:' + i + '" data-fk="qs-' + i + '" aria-label="Answer for: ' + esc(x.q.label.slice(0, 60)) + '">' + opts + "</select>" +
        (a ? '<div class="ans">' + esc(a.answer) + '</div><div class="qm">' + (a.words || String(a.answer).split(/\s+/).length) + " words · " + (st.choice[0] === "r" ? "from this role’s letter" : "standard answer") + "</div>"
          : '<div class="qm">No answer picked: write it yourself, or choose one above.</div>') +
        (st.note ? '<div class="qm warn">' + esc(st.note) + "</div>" : "") + "</div>";
    });
    return h + "</section>";
  }
  function fileRow(id, name, sub, kind, extra) {
    const target = JHA.fileTarget(S.scan, kind);
    const r = S.files[id];
    const where = target ? "to " + (target.label || "upload box") : "no upload box found";
    return '<div class="file"><span class="fi' + (r === "ok" ? " ok" : "") + '">' + ic(r === "ok" ? "check" : "file") + "</span>" +
      '<span style="min-width:0"><div class="fn">' + esc(name) + '</div><div class="fs">' + esc(sub + " · " + (r === "ok" ? "attached" : r === "fail" ? "didn’t attach" : where)) + "</div></span>" +
      '<span class="fa">' + (extra || "") + '<button type="button" class="btn" data-act="attach" data-arg="' + id + '" data-fk="a-' + id + '"' + (target && !S.busy ? "" : " disabled") + ">" + ic("clip") + (r === "ok" ? "Again" : "Attach") + "</button></span></div>" +
      (r === "fail" ? '<div class="refused"><p>The site didn’t take the file. Drag it in yourself:</p><div class="acts">' +
        '<button type="button" class="btn" data-act="reveal" data-arg="' + id + '" data-fk="rv-' + id + '">' + ic("folder") + "Show in Finder</button>" +
        '<button type="button" class="btn" data-act="download" data-arg="' + id + '" data-fk="dl-' + id + '">' + ic("down") + "Download</button>" +
        '<button type="button" class="btn" data-act="copy-path" data-arg="' + id + '" data-fk="cp-' + id + '">' + ic("copy") + "Copy file path</button></div></div>" : "");
  }
  /* ------------------------------------------------------------ the new groups */
  function myHTML() {
    const ks = myKeysOnPage();
    if (!ks.length) return "";
    const on = ks.filter(function (x) { return myOn(myAnswer(x.key)); }).length;
    let h = '<section class="sec my"><div class="sh"><h3>My answers</h3><span class="n">' + on + " of " + ks.length + " fill</span></div>" +
      '<p class="note">Your standing answers. <b>Fill</b> fills the box; <b>Leave</b> keeps it for you. Changes are saved for every form.</p>';
    ks.forEach(function (x) {
      const a = myAnswer(x.key) || { key: x.key, label: x.key, value: "", mode: "leave" };
      const k = "my:" + x.key, eff = myOn(a);
      h += '<div class="ma' + (eff ? "" : " off") + '" title="' + esc("On the page: " + (x.f.label || a.label)) + '">' +
        '<span class="kv"><span class="k">' + esc(a.label) + '</span><span class="v" title="' + esc(a.value || "") + '">' + esc(eff ? a.value : (a.mode === "fill" ? "Not set: left for you" : "Left for you")) + "</span></span>" +
        '<span class="seg" role="group" aria-label="' + esc(a.label) + ': fill or leave"><button type="button" data-act="ma-mode" data-arg="' + esc(x.key) + '.fill" data-fk="mf-' + esc(x.key) + '" aria-pressed="' + (a.mode === "fill") + '">Fill</button>' +
        '<button type="button" data-act="ma-mode" data-arg="' + esc(x.key) + '.leave" data-fk="ml-' + esc(x.key) + '" aria-pressed="' + (a.mode === "leave") + '">Leave</button></span>' +
        '<button type="button" class="ib" data-act="ma-edit" data-arg="' + esc(x.key) + '" data-fk="me-' + esc(x.key) + '" aria-label="Edit ' + esc(a.label) + '">' + ic("pen") + "</button>" +
        stIcon(S.results[k], S.reasons[k]) + "</div>" + whyHTML(k);
      if (S.maEdit === x.key) {
        h += '<div class="mae"><input type="text" class="mai" data-ma-input="' + esc(x.key) + '" data-fk="mi-' + esc(x.key) + '" value="' + esc(S.maDraft) + '" aria-label="' + esc(a.label) + '" placeholder="' + esc(x.key === "dob" ? "YYYY-MM-DD" : JHA.EEO_KEYS.test(x.key) ? "Prefer not to say" : "") + '">' +
          '<button type="button" class="btn go" data-act="ma-save" data-arg="' + esc(x.key) + '" data-fk="ms-' + esc(x.key) + '">Save</button><button type="button" class="btn" data-act="ma-cancel">Cancel</button></div>';
      }
    });
    h += '<button type="button" class="more" data-act="ma-options" data-fk="mo">' + ic("ext") + "All my answers (Options)</button>";
    return h + "</section>";
  }
  function consentHTML() {
    const cs = (S.scan.consents || []);
    if (!cs.length) return "";
    let h = '<section class="sec conf"><div class="sh"><h3>Your confirmation needed</h3><span class="n">' + cs.length + "</span></div>" +
      '<p class="note">Job Hunter never ticks these. Read each one and tick it yourself.</p>';
    cs.forEach(function (c, i) {
      const done = c.el.type === "checkbox" ? c.el.checked : c.el.getAttribute("aria-checked") === "true";
      h += '<div class="cf"><span class="st' + (done ? " ok" : "") + '">' + ic(done ? "check" : "box") + '</span><span class="ct">' + esc(c.label || "Consent box") + "</span>" +
        '<button type="button" class="btn" data-act="jump" data-arg="consent:' + i + '" data-fk="j-' + i + '">Jump to</button></div>';
    });
    return h + "</section>";
  }
  function noticesHTML() {
    let h = "";
    const lg = S.scan.login;
    if (lg) h += '<div class="notice"><b>' + (lg.kind === "create" ? "Create account page" : "Sign-in page") + "</b><p>Job Hunter fills only your email" +
      (lg.kind === "create" ? " and name" : "") + ". Use your password manager for the password.</p></div>";
    (S.scan.captcha || []).forEach(function (c, i) {
      h += '<div class="notice warn"><b>Complete the CAPTCHA yourself</b><p>' + esc(c.label) + " on this page. Job Hunter doesn’t touch it.</p>" +
        '<div class="acts"><button type="button" class="btn" data-act="jump" data-arg="captcha:' + i + '" data-fk="jc-' + i + '">Jump to</button></div></div>';
    });
    return h;
  }
  function filesHTML() {
    const f = S.data.files || {}, t = S.data.tailored;
    let h = '<section class="sec"><div class="sh"><h3>Attachments</h3></div>';
    if (f.cv) h += fileRow("cv", f.cv.name, f.cv.key, "cv");
    if (f.letter_pdf || f.letter_docx) {
      const fmt = f.letter_pdf && f.letter_docx ? S.letter : f.letter_pdf ? "pdf" : "docx";
      const seg = f.letter_pdf && f.letter_docx ? '<span class="seg" role="group" aria-label="Cover letter format"><button type="button" data-act="fmt" data-arg="letter.pdf" aria-pressed="' + (fmt === "pdf") + '">PDF</button><button type="button" data-act="fmt" data-arg="letter.docx" aria-pressed="' + (fmt === "docx") + '">Word</button></span>' : "";
      const lf = fmt === "pdf" ? f.letter_pdf : f.letter_docx;
      h += fileRow("letter", "Cover letter", lf.name.replace(/^.*? - Cover Letter /, "").replace(/\.(pdf|docx)$/, ""), "letter", seg);
    }
    if (!f.cv && !f.letter_pdf && !f.letter_docx) h += '<p class="note">No CV or cover letter for this role yet.</p>';
    if (t) {
      const approved = t.status === "approved";
      h += '<div class="tail"><div class="tail-h"><b>Tailored CV</b><span class="pillst ' + (approved ? "app" : "sug") + '">' + (approved ? ic("check") + "Approved" : "Suggested") + "</span></div>" +
        (t.reason ? "<p>" + esc(t.reason) + "</p>" : "") +
        '<div class="acts"><button type="button" class="btn" data-act="changes" data-fk="chg" aria-expanded="' + S.showChanges + '">' + (S.showChanges ? "Hide changes" : "View changes") + "</button>" +
        (t.files && t.files.pdf ? '<button type="button" class="btn" data-act="open" data-arg="tailored.pdf">' + ic("ext") + "Open PDF</button>" : "") +
        (approved ? "" : '<button type="button" class="btn go" data-act="approve" data-fk="approve">' + ic("check") + "Approve</button>") + "</div>";
      if (S.showChanges) {
        h += '<ul class="chg">' + (t.changes || []).map(function (c) { return "<li>" + esc(c) + "</li>"; }).join("") + "</ul>";
        if (t.summary && t.summary.after) h += '<div class="ba"><div><span class="l">New summary</span><span class="now">' + esc(t.summary.after) + '</span></div>' +
          '<div><span class="l">Was</span><span class="was">' + esc(t.summary.before) + "</span></div></div>";
      }
      if (approved && t.files) {
        const fmt = t.files.pdf && t.files.docx ? S.tailoredFmt : t.files.pdf ? "pdf" : "docx";
        const tf = t.files[fmt];
        const seg = t.files.pdf && t.files.docx ? '<span class="seg" role="group" aria-label="Tailored CV format"><button type="button" data-act="fmt" data-arg="tailored.pdf" aria-pressed="' + (fmt === "pdf") + '">PDF</button><button type="button" data-act="fmt" data-arg="tailored.docx" aria-pressed="' + (fmt === "docx") + '">Word</button></span>' : "";
        if (tf) h += fileRow("tailored", "Tailored CV", fmt === "pdf" ? "PDF" : "Word", "cv", seg);
      } else if (!approved) {
        h += '<p>Attach unlocks once you approve it.</p>';
      }
      h += "</div>";
    }
    return h + "</section>";
  }
  function sess() { const x = S.data && S.data.session; return x && x.active ? x : null; }
  function headHTML() {
    const x = sess();
    const sub = x ? '<span class="prog" title="Your apply session">Applying ' + (x.index + 1) + " of " + x.total + "</span>" : '<span class="brand-sub">Autofill</span>';
    return '<header class="hd"><span class="mark" aria-hidden="true"></span><span class="brand">Job Hunter</span>' + sub + '<span class="sp"></span>' +
      '<button type="button" class="ib" data-act="collapse" data-fk="collapse" aria-label="Collapse to a pill">' + ic("minus") + "</button>" +
      '<button type="button" class="ib" data-act="close" aria-label="Hide on this page">' + ic("x") + "</button></header>";
  }
  function confirmHTML() {
    if (!S.confirmed || !S.data || !S.data.job) return "";
    const j = S.data.job, x = sess(), applied = S.marked || j.status === "applied";
    return '<div class="done" role="region" aria-label="Application sent"><h3>Application sent?</h3><p>This looks like ' + esc(j.firm) + "’s confirmation page." +
      (applied ? " It’s marked as applied in Job Hunter." : "") + '</p><div class="acts">' +
      (applied ? '<span class="chip">' + ic("check") + "Marked as applied</span>" : '<button type="button" class="btn go" data-act="mark-applied" data-fk="mark">' + ic("check") + "Mark as applied</button>") +
      (x ? '<button type="button" class="btn" data-act="next-role" data-fk="next">Next role' + ic("next") + "</button>" : "") + "</div></div>";
  }
  function sessionBarHTML() {
    const x = sess();
    if (!x || S.confirmed) return "";
    return '<div class="sessbar"><span>Role ' + (x.index + 1) + " of " + x.total + " in your apply session</span>" +
      '<button type="button" class="lk" data-act="skip-role" data-fk="skip">Skip this role</button></div>';
  }
  function pickerHTML() {
    if (!S.picker) return "";
    if (!S.roles) return '<div class="picker"><span class="note">Loading your roles…</span></div>';
    return '<div class="picker"><select class="sel" data-pick="1" data-fk="pick" aria-label="Choose the role this application is for"><option value="">Choose a role…</option>' +
      S.roles.map(function (r) { return '<option value="' + esc(r.id) + '">' + esc(r.firm + " · " + r.title + (r.status === "applied" ? " (applied)" : r.status === "pass" ? " (passed)" : "")) + "</option>"; }).join("") +
      '</select><button type="button" class="btn" data-act="picker">Cancel</button></div>';
  }
  function html() {
    if (S.collapsed) {
      const firm = S.data && S.data.job ? S.data.job.firm.split(" (")[0] : S.phase === "offline" ? "offline" : "no role";
      const x = sess();
      return '<div class="wrap-pill"><button type="button" class="pill" data-act="expand" data-fk="expand" aria-label="Open Job Hunter autofill"><span class="mark" aria-hidden="true"></span>Job Hunter<span class="pf">' + esc(firm) + "</span>" +
        (x ? '<span class="pf">' + (x.index + 1) + "/" + x.total + "</span>" : "") + "</button></div>";
    }
    let h = '<div class="card">' + headHTML() + '<div class="body">';
    if (S.phase === "loading") {
      h += '<div class="empty" style="display:flex;gap:10px;align-items:center"><span class="spin" aria-hidden="true"></span><p>Asking Job Hunter about this page…</p></div>';
    } else if (S.phase === "offline") {
      h += '<div class="empty"><h3>Job Hunter isn’t running</h3><p>' + esc(S.error) + '</p><p style="margin-top:6px">Double-click <code>Open Job Hunter.command</code>, then try again.</p><div class="acts"><button type="button" class="btn" data-act="retry" data-fk="retry">' + ic("retry") + "Try again</button></div></div>";
    } else if (S.phase === "none") {
      h += '<div class="empty"><h3>No Job Hunter role matched</h3><p>This page isn’t one of your postings, and no Apply click in the last two hours. Pick the role it’s for.</p>' +
        (S.picker ? pickerHTML() : '<div class="acts"><button type="button" class="btn go" data-act="picker" data-fk="picker">Choose a role</button></div>') + "</div>";
    } else if (S.phase === "ready") {
      const j = S.data.job, how = S.data.matched;
      const mins = how === "active" && S.data.active_minutes != null ? (S.data.active_minutes < 1 ? ", just now" : ", " + S.data.active_minutes + " min ago") : "";
      h += confirmHTML();
      h += '<section class="role"><div class="firm">' + esc(j.firm) + '</div><div class="title">' + esc(j.title) + "</div>" +
        '<div class="how"><span class="chip' + (how === "active" || how === "site" ? " soft" : "") + '">' + ic("target") + esc((MATCH_LABEL[how] || how) + mins) + "</span>" +
        (S.picker ? "" : '<button type="button" class="lk" data-act="picker" data-fk="picker">Not this role?</button>') + "</div>" + pickerHTML() + "</section>";
      h += sessionBarHTML();
      if (S.confirmed && !looksLikeForm(S.scan) && !S.scan.questions.length) /* a thank-you page: nothing to fill */
        return h + '</div><div class="ft"><p class="status ' + esc(S.status.tone) + '" role="status" aria-live="polite">' + esc(S.status.text) + "</p></div></div>";
      h += '<p class="safe">' + ic("shield") + "<span><b>Review the page, then submit it yourself.</b> Job Hunter fills and attaches only; it never presses Submit, Apply or Next.</span></p>";
      const nFlat = pageFlat().filter(function (f) { return !/^my:/.test(f.kind); }).length;
      h += runBarHTML() + noticesHTML();
      h += '<section class="sec"><div class="sh"><h3>Fields on this page</h3><span class="n">' + (nFlat ? countTicked() + " ticked" : "none found") + "</span></div>";
      h += nFlat ? rowsHTML() : '<p class="note">No fields to fill on this page yet. On a multi-step form, they appear as you go.</p>' + rowsHTML();
      h += "</section>";
      if (S.scan.login) h += myHTML() + consentHTML();
      else h += myHTML() + slotsHTML("experience") + slotsHTML("education") + questionsHTML() + consentHTML() + extrasHTML() + filesHTML();
    }
    h += "</div>";
    if (S.phase === "ready") {
      const n = fillCount();
      h += '<div class="ft"><div class="ftb"><button type="button" class="btn go fill" data-act="fill" data-fk="fill"' + (n && !S.busy ? "" : " disabled") + ">" +
        (S.busy ? '<span class="spin" aria-hidden="true"></span>Filling…' : "Fill selected" + (n ? ' <span class="n">' + n + "</span>" : "")) + "</button>" +
        (S.run ? '<button type="button" class="btn stop" data-act="stop" data-fk="stop">' + ic("stop") + "Stop</button>"
          : '<button type="button" class="btn run" data-act="run" data-fk="run" title="Fill this page, then each next page as you move through the form"' + (S.busy ? " disabled" : "") + ">" + ic("play") + "Run</button>") + "</div>" +
        '<p class="status ' + esc(S.status.tone) + '" role="status" aria-live="polite">' + esc(S.status.text) + "</p></div>";
    }
    return h + "</div>";
  }
  function runBarHTML() {
    if (!S.run) return "";
    return '<div class="runbar" role="status"><span class="pulse" aria-hidden="true"></span><span><b>Run mode: will fill each page as you go</b>' +
      "<br>Press the page’s Next yourself. " + (S.runSteps ? S.runSteps + (S.runSteps === 1 ? " page" : " pages") + " filled so far." : "") + "</span>" +
      '<button type="button" class="btn" data-act="stop" data-fk="stop2">Stop</button></div>';
  }
  function countTicked() {
    const seen = {};
    pageFlat().forEach(function (f) { if (field(f.kind) && S.ticks[f.kind]) seen[f.kind] = 1; });
    return Object.keys(seen).length;
  }
  function fillCount() {
    if (!S.scan) return 0;
    let n = 0;
    pageFlat().forEach(function (f) { if ((field(f.kind) && S.ticks[f.kind]) || (/^my:/.test(f.kind) && myOn(myAnswer(f.kind.slice(3))))) n++; });
    if (S.scan.login) return n;
    ["experience", "education"].forEach(function (kind) {
      S.scan.groups[kind].forEach(function (slot, i) {
        if (S.slots[kind][i] < 0 || !entries(kind)[S.slots[kind][i]]) return;
        slot.fields.forEach(function (p) { if (S.parts[kind + "." + i + "." + p.part] !== false) n++; });
      });
    });
    questions().forEach(function (x) { const st = S.q[x.key]; if (st && st.on && answerById(st.choice)) n++; });
    return n;
  }
  function render() {
    if (!panel || S.hidden) return;
    panel.render(html());
  }

  /* ------------------------------------------------------------ actions */
  async function load(by) {
    S.phase = "loading"; render();
    try {
      S.data = await JHA.send("autofill", by && by.id ? { id: by.id } : { url: location.href });
    } catch (e) {
      S.phase = "offline"; S.error = e.message; render(); return;
    }
    if (!S.data.job) { S.phase = "none"; render(); return; }
    S.phase = "ready";
    resetChoices();
    rescan(true);
  }
  function rescan(force) {
    const before = S.scan;
    S.scan = JHA.scan(hostEl());
    if (S.phase === "ready") { syncSlots(); syncQuestions(); }
    if (force || !before || sig(before) !== sig(S.scan)) render();
  }
  function sig(s) { return [s.flat.length, s.groups.experience.length, s.groups.education.length, s.files.length, s.questions.length, Object.keys(s.add).join(), s.consents.length, s.calendar.length, s.captcha.length, s.login ? s.login.kind : ""].join("|") + s.flat.map(function (f) { return f.kind; }).join(); }

  /* the value one flat field takes: {value, key, opts}, or null to leave it */
  function flatValue(f) {
    if (/^my:/.test(f.kind)) {
      const key = f.kind.slice(3), m = myFill(key, f);
      if (!m) return null;
      if (m.opts.date) {
        const fmt = JHA.dateFormat(f.el, f.d || f);
        const v = JHA.formatDate(m.opts.date, fmt, m.value);
        return v ? { value: v, key: fmt === "month" ? "month" : fmt === "day" ? "day" : key, opts: {} } : null;
      }
      return { value: m.value, key: key, opts: m.opts };
    }
    const meta = field(f.kind);
    if (!meta || !S.ticks[f.kind]) return null;
    let value = meta.value, key = f.kind;
    const opts = { alts: meta.alts || [] };
    if (meta.date) {
      const fmt = JHA.dateFormat(f.el, f.d || f);
      value = JHA.formatDate(meta.date, fmt, meta.value);
      if (fmt === "month") key = "month";
      if (fmt === "day") key = "day";
      if (!value) return null;
    }
    if (meta.numeric && JHA.isNumeric(f.el)) value = meta.numeric;
    if (f.kind === "work_history" && f.el.tagName === "INPUT") value = value.split("\n").join("; ");
    return { value: value, key: key, opts: opts };
  }

  async function fill(why) {
    if (S.busy) return;
    rescan(false);
    S.busy = true; S.results = {}; S.reasons = {}; setStatus(why === "run" ? "Run mode: filling this page…" : "Filling…");
    const done = [], need = [], filled = [];
    const seenFlat = {};
    const note = function (k, r, label) {
      if (r === "skip") return;
      if (r !== "ok" && JHA.reason) S.reasons[k] = JHA.reason;
      (r === "ok" ? done : need).push(label);
    };
    const choice = {}; /* "tick all that apply" lists: one result per question */
    for (const f of pageFlat()) {
      const v = flatValue(f);
      if (!v) continue;
      const r = await JHA.fillField(f, v.key, v.value, v.opts);
      if (v.opts.choice) { if (r === "ok") choice[f.kind] = "ok"; else if (!choice[f.kind]) choice[f.kind] = "none"; continue; }
      const meta = field(f.kind), myA = /^my:/.test(f.kind) && myAnswer(f.kind.slice(3));
      S.results[f.kind] = seenFlat[f.kind] && S.results[f.kind] === "ok" && r !== "fail" ? "ok" : r;
      seenFlat[f.kind] = 1;
      note(f.kind, r, meta ? meta.label : myA ? myA.label : f.kind);
      if (r === "ok" && !f.radio && !f.buttons && !f.rich && f.el.tagName !== "SELECT" && f.el.tagName !== "BUTTON" && f.el.type !== "checkbox" && !JHA.isCombo(f.el)) filled.push([f.el, f.el.value]);
    }
    Object.keys(choice).forEach(function (k) {
      S.results[k] = choice[k] === "ok" ? "ok" : "fail";
      if (choice[k] !== "ok") { S.reasons[k] = "No box on its list matches your answer"; need.push(k.slice(3)); } else done.push(k.slice(3));
    });
    if (!S.scan.login) {
      for (const kind of ["experience", "education"]) {
        const g = S.scan.groups[kind];
        for (let i = 0; i < g.length; i++) {
          const e = entries(kind)[S.slots[kind][i]];
          if (!e) continue;
          const count = {};
          for (const p of g[i].fields) {
            const k = kind + "." + i + "." + p.part;
            const n = count[p.part] = (count[p.part] || 0);
            count[p.part]++;
            if (S.parts[k] === false) continue;
            const v = JHA.entryValue(e, p.part, p.date, kind, kind === "experience" ? extrasFor(e, i) : [], p.f.el);
            if (!v && p.part !== "current") continue;
            const key = p.date === "month" ? "month" : p.date === "day" ? "day" : p.part === "level" ? "degree_level" : p.part === "current" ? "current" : p.part;
            const r = await JHA.fillField(p.f, key, v || "no", { alts: JHA.entryAlts(e, p.part) });
            S.results[k + "." + n] = r;
            if (r !== "ok" && JHA.reason) S.reasons[k + "." + n] = JHA.reason;
            (r === "ok" ? done : need).push((PART[p.part] || p.part) + " (box " + (i + 1) + ")");
            if (r === "ok" && !p.f.rich && p.f.el.tagName !== "SELECT" && p.f.el.type !== "checkbox" && p.f.el.tagName !== "BUTTON" && !JHA.isCombo(p.f.el)) filled.push([p.f.el, p.f.el.value]);
          }
        }
      }
      for (const x of questions()) {
        const st = S.q[x.key], a = st && st.on ? answerById(st.choice) : null;
        if (!a) continue;
        const max = x.q.el.maxLength;
        if (max > 0 && a.answer.length > max) { S.qResults[x.key] = "fail"; need.push("an answer too long for its box"); continue; }
        const r = await JHA.fillField(x.q, "answer", a.answer);
        S.qResults[x.key] = r;
        (r === "ok" ? done : need).push("Answer: " + x.q.label.slice(0, 40));
        if (r === "ok" && !x.q.rich) filled.push([x.q.el, x.q.el.value]);
      }
    }
    (S.scan.calendar || []).forEach(function (c) { need.push(c.label + " (calendar only)"); });
    /* values that a framework silently put back haven't stuck */
    await JHA.sleep(400);
    const reverted = filled.filter(function (x) { return x[0].isConnected && x[0].value !== x[1]; }).length;
    S.busy = false;
    S.runEls = new Set(pageFlat().map(function (f) { return f.el; }));
    if (done.length) { S.filledAt = Date.now(); captureNow(); }
    const extra = [];
    if (S.scan.consents && S.scan.consents.length) extra.push(S.scan.consents.length + " to confirm yourself");
    if (S.scan.captcha && S.scan.captcha.length) extra.push("complete the CAPTCHA yourself");
    if (S.scan.login) extra.push("use your password manager for the password");
    const msg = (why === "run" ? "Run mode: " : "") + done.length + " filled" + (need.length ? "; " + need.length + " need you: " + need.slice(0, 3).join(", ") + (need.length > 3 ? "…" : "") : "") +
      (reverted ? "; " + reverted + " were reset by the page" : "") + (extra.length ? "; " + extra.join("; ") : "") + ". Review the page, then submit it yourself.";
    setStatus(msg, need.length || reverted ? "warn" : "ok");
  }

  function fileMeta(id) {
    const f = S.data.files || {}, t = S.data.tailored || {};
    if (id === "cv") return { meta: f.cv, kind: "cv" };
    if (id === "letter") return { meta: (S.letter === "docx" && f.letter_docx) || f.letter_pdf || f.letter_docx, kind: "letter" };
    if (id === "tailored") return { meta: t.status === "approved" && t.files && ((S.tailoredFmt === "docx" && t.files.docx) || t.files.pdf || t.files.docx), kind: "cv" };
    return {};
  }
  async function attach(id) {
    if (id === "tailored" && (S.data.tailored || {}).status !== "approved") return setStatus("Approve the tailored CV first.", "warn");
    const fm = fileMeta(id), meta = fm.meta;
    rescan(false);
    const target = JHA.fileTarget(S.scan, fm.kind);
    if (!meta || !target) return setStatus("No upload box for that on this page.", "warn");
    setStatus("Attaching " + meta.name + "…");
    try {
      const r = await JHA.send("file", { path: meta.url, name: meta.name });
      S.fileData[id] = { b64: r.b64, type: r.type, name: meta.name, path: r.path || "", url: meta.url };
      const ok = (await JHA.attach(target, JHA.b64ToFile(r.b64, meta.name, r.type), hostEl())) === "ok";
      S.files[id] = ok ? "ok" : "fail";
      if (ok) { S.filledAt = S.filledAt || Date.now(); if (S.attached.indexOf(meta.name) < 0) S.attached.push(meta.name); }
      setStatus(ok ? "Attached " + meta.name + ". Check it on the page." : "The site refused the file. Use Show in Finder or Download and drag it in yourself.", ok ? "ok" : "bad");
    } catch (e) {
      S.files[id] = "fail";
      setStatus(e.message, "bad");
    }
  }
  /* uploads a site refuses: show the file in Finder, download it, or copy its path */
  function revealArgs(id) {
    const d = S.fileData[id], url = (d && d.url) || (fileMeta(id).meta || {}).url || "";
    const m = url.match(/^\/api\/file\/(cv|letters|cvs)\/([^/?#]+)$/);
    return m ? { kind: m[1], name: decodeURIComponent(m[2]) } : null;
  }
  async function fileHelp(act, id) {
    if (act === "reveal") {
      const a = revealArgs(id);
      if (!a) return setStatus("Job Hunter doesn’t know where that file is.", "bad");
      try { const r = await JHA.send("reveal", a); S.fileData[id] = Object.assign(S.fileData[id] || {}, { path: r.path }); setStatus("Shown in Finder: drag it onto the upload box.", "ok"); }
      catch (e) { setStatus(e.message, "bad"); }
      return;
    }
    let d = S.fileData[id];
    if (!d || (act === "download" && !d.b64) || (act === "copy-path" && !d.path)) {
      const fm = fileMeta(id);
      if (!fm.meta) return setStatus("No file for that.", "bad");
      try { const r = await JHA.send("file", { path: fm.meta.url, name: fm.meta.name }); d = S.fileData[id] = { b64: r.b64, type: r.type, name: fm.meta.name, path: r.path || "", url: fm.meta.url }; }
      catch (e) { return setStatus(e.message, "bad"); }
    }
    if (act === "download") {
      const url = URL.createObjectURL(JHA.b64ToFile(d.b64, d.name, d.type));
      const a = document.createElement("a");
      a.href = url; a.download = d.name; a.style.display = "none";
      panel.root.appendChild(a); /* inside the panel's own shadow root: never a page element */
      a.click();
      setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 4000);
      return setStatus("Downloaded " + d.name + ": drag it from Downloads onto the upload box.", "ok");
    }
    if (act === "copy-path") {
      if (!d.path) return setStatus("Job Hunter didn’t say where that file is.", "bad");
      try { await navigator.clipboard.writeText(d.path); setStatus("Copied the file path. In the site’s file dialog press ⌘⇧G and paste it.", "ok"); }
      catch (e) { setStatus("Couldn’t copy here. The file is at " + d.path, "warn"); }
    }
  }
  /* "Jump to": scroll a consent box, a calendar-only date or a CAPTCHA into view and focus it. Never clicks it. */
  function jump(arg) {
    const p = arg.split(":"), i = +p[1];
    const item = p[0] === "consent" ? S.scan.consents[i] : p[0] === "cal" ? S.scan.calendar[i] : p[0] === "captcha" ? S.scan.captcha[i] : null;
    if (!item || !item.el || !item.el.isConnected) return setStatus("That isn’t on the page any more.", "warn");
    const el = item.el;
    el.scrollIntoView({ block: "center", behavior: "smooth" });
    try { el.focus({ preventScroll: true }); } catch (e) { /* not focusable */ }
    const prev = el.style.outline, prevOff = el.style.outlineOffset;
    el.style.outline = "3px solid #C6EC72"; el.style.outlineOffset = "3px";
    setTimeout(function () { el.style.outline = prev; el.style.outlineOffset = prevOff; }, 2200);
    setStatus(p[0] === "captcha" ? "There’s the CAPTCHA: complete it yourself." : p[0] === "cal" ? "Pick the date from its calendar." : "Read it, then tick it yourself if you agree.", "ok");
  }

  /* ------------------------------------------------------------ Run mode: fill each step as the user moves through it */
  /* A step is the URL, the form's current step marker (Workday's progress bar, an aria-current step) and its heading.
     Run mode never presses Next: it waits for the user to, then fills the new step once it has settled. */
  function stepKey() {
    const marker = JHA.deepAll(document, "[data-automation-id='progressBarActiveStep'],[aria-current='step'],[class*='step' i][class*='active' i],[class*='step' i][class*='current' i],.steps b")
      .filter(function (n) { return !hostEl().contains(n) && JHA.visible(n); })[0];
    const head = Array.prototype.find.call(document.querySelectorAll("main h1, main h2, form h2, h2, [data-automation-id*='pageHeader' i]"), function (n) { return JHA.visible(n) && !hostEl().contains(n); });
    return location.href + "|" + (marker ? JHA.txt(marker) : "") + "|" + (head ? JHA.txt(head) : "");
  }
  async function startRun() {
    S.run = true; S.runSteps = 0; S.runKey = stepKey();
    render();
    await fill("run");
    S.runSteps = 1;
    render();
  }
  function stopRun(msg) {
    S.run = false;
    if (S.runTimer) { clearTimeout(S.runTimer); S.runTimer = 0; }
    if (msg) setStatus(msg, "ok"); else render();
  }
  /* called on page changes while Run is on */
  function runWatch() {
    if (!S.run || S.busy || S.confirmed || S.runTimer) return;
    const k = stepKey();
    const fresh = S.scan && pageFlat().filter(function (f) { return !(S.runEls && S.runEls.has(f.el)); });
    const newStep = k !== S.runKey || (fresh && fresh.length >= 2 && fresh.length === pageFlat().length);
    if (!newStep) return;
    S.runKey = k;
    /* wait for the new step to settle: the same fields for 700ms (at most 6s) */
    let last = "", stableSince = Date.now(), started = Date.now();
    const tick = async function () {
      S.runTimer = 0;
      if (!S.run || S.confirmed) return;
      const now = JHA.scan(hostEl());
      const sigNow = sig(now);
      if (sigNow !== last) { last = sigNow; stableSince = Date.now(); }
      if (Date.now() - stableSince < 700 && Date.now() - started < 6000) { S.runTimer = setTimeout(tick, 150); return; }
      if (confirmText()) return onConfirmation();
      rescan(true);
      S.runKey = stepKey();
      if (fillCount() || S.scan.calendar.length) { await fill("run"); S.runSteps++; render(); }
      else { S.runEls = new Set(pageFlat().map(function (f) { return f.el; })); setStatus("Run mode: nothing to fill on this page. Waiting for the next one.", "ok"); }
    };
    S.runTimer = setTimeout(tick, 150);
  }

  /* ------------------------------------------------------------ the record of what was sent (passive) */
  /* Values are gathered after a fill and at each step (Workday clears a step's fields when it moves on), then sent
     to Job Hunter when the user submits, when the page unloads, or when a confirmation page appears. Reading only. */
  function captureNow() {
    if (!S.filledAt || !S.data || !S.data.job) return;
    S.lastCapture = Date.now();
    let c;
    try { c = JHA.capture(hostEl()); } catch (e) { return; }
    c.fields.forEach(function (f) {
      if (!(f.label in S.snap.values)) S.snap.order.push(f.label);
      S.snap.values[f.label] = f.value;
    });
    c.files.concat(S.attached).forEach(function (n) { if (S.snap.files.indexOf(n) < 0) S.snap.files.push(n); });
  }
  function sendSnapshot(why) {
    if (!S.filledAt || !S.data || !S.data.job) return;
    if (why !== "confirmation") captureNow();
    if (!S.snap.order.length) return;
    const body = {
      id: S.data.job.id, url: location.href, captured_at: new Date().toISOString(),
      fields: S.snap.order.map(function (l) { return { label: l, value: S.snap.values[l] }; }), files: S.snap.files.slice()
    };
    const sig = JSON.stringify([body.fields, body.files]);
    if (sig === S.snapSig) return; /* already sent exactly this */
    S.snapSig = sig;
    JHA.send("snapshot", { snapshot: body }).then(function (r) {
      S.snapFile = r.snapshot;
      setStatus("Saved a PDF record of the form as sent (" + r.snapshot + ").", "ok");
    }, function (e) {
      S.snapSig = "";
      setStatus("Couldn’t save a record of the form: " + e.message, "warn");
    });
  }
  const SEND_CLICK = /\b(submit|send)\b/i, APPLY_ONLY = /^\s*(apply|apply now|finish)\s*$/i;
  /* The user's own clicks and submits, heard in the capture phase. Nothing is prevented, changed or re-sent. */
  document.addEventListener("submit", function () { if (S.filledAt) sendSnapshot("submit"); }, true);
  document.addEventListener("click", function (e) {
    if (!e.isTrusted || !S.filledAt) return;
    const b = e.target && e.target.closest ? e.target.closest("button,input[type=submit],[role=button]") : null;
    if (!b || (panel && (b === panel.host || panel.host.contains(b)))) return;
    const t = [b.textContent, b.value, b.getAttribute("aria-label")].filter(Boolean).join(" ");
    if (SEND_CLICK.test(t) || APPLY_ONLY.test(b.textContent || b.value || "")) sendSnapshot("submit click");
    else captureNow(); /* Next, Continue, Save: keep this step's values */
  }, true);
  window.addEventListener("pagehide", function () { if (S.filledAt) sendSnapshot("unload"); });

  /* ------------------------------------------------------------ confirmation pages */
  function confirmText() {
    const b = document.body;
    return !!b && JHA.CONFIRM.test((b.innerText || "").slice(0, 30000));
  }
  async function onConfirmation() {
    S.confirmed = true;
    if (S.run) { S.run = false; if (S.runTimer) { clearTimeout(S.runTimer); S.runTimer = 0; } }
    sendSnapshot("confirmation");
    if (panel) { S.hidden = false; S.collapsed = false; S.autoCollapsed = false; render(); return; }
    if (S.hidden) return;
    await show(true);
    if (!S.data || !S.data.job) { if (panel) { panel.remove(); panel = null; } }
  }
  /* at most every 1.5 seconds, and once more after the page goes quiet (a thank-you message may be its last change) */
  function maybeConfirm() {
    if (S.confirmed || !(panel || S.filledAt || ATS)) return;
    const wait = 1500 - (Date.now() - (S.lastConfirmCheck || 0));
    if (wait > 0 || S.busy) {
      if (!S.confirmTimer) S.confirmTimer = setTimeout(function () { S.confirmTimer = 0; maybeConfirm(); }, Math.max(wait, 300));
      return;
    }
    S.lastConfirmCheck = Date.now();
    if (confirmText()) onConfirmation();
  }
  async function nextRole(action) {
    try {
      const r = await JHA.send("sessionAct", { action: action });
      const url = r.current && JHA.safeUrl(r.current.url);
      if (!r.active || !r.current) { if (S.data) S.data.session = { active: false }; setStatus("That was the last role in this apply session.", "ok"); return; }
      if (!url) { setStatus("The next role has no posting link. Open it from the dashboard.", "warn"); return; }
      setStatus("Opening " + r.current.firm + "…", "ok");
      location.href = url; /* navigation only: the page itself is never clicked */
    } catch (e) { setStatus(e.message, "bad"); }
  }

  async function onAct(act, arg, el) {
    if (panel && panel.justDragged && Date.now() - panel.justDragged < 250) return;
    if (act === "collapse") { S.collapsed = true; render(); return; }
    if (act === "expand") { S.collapsed = false; render(); return; }
    if (act === "close") { S.hidden = true; panel.remove(); panel = null; return; }
    if (act === "retry") return load();
    if (act === "more") { S.showMore = !S.showMore; render(); return; }
    if (act === "changes") { S.showChanges = !S.showChanges; render(); return; }
    if (act === "fmt") { const p = arg.split("."); if (p[0] === "letter") S.letter = p[1]; else S.tailoredFmt = p[1]; render(); return; }
    if (act === "copy") {
      try { await navigator.clipboard.writeText(arg); setStatus("Copied.", "ok"); } catch (e) { setStatus("Couldn’t copy here; select the text instead.", "warn"); }
      return;
    }
    if (act === "picker") {
      S.picker = !S.picker; render();
      if (S.picker && !S.roles) {
        try { S.roles = (await JHA.send("roles")).roles; } catch (e) { S.roles = []; setStatus(e.message, "bad"); }
        render();
      }
      return;
    }
    if (act === "pick-role") { if (arg) { S.picker = false; await load({ id: arg }); } return; }
    if (act === "fill") return fill();
    if (act === "run") return startRun();
    if (act === "stop") return stopRun("Run mode stopped.");
    if (act === "jump") return jump(arg);
    if (act === "reveal" || act === "download" || act === "copy-path") return fileHelp(act, arg);
    if (act === "ma-mode") {
      const p = arg.split("."), a = myAnswer(p[0]);
      if (!a || a.mode === p[1]) return;
      const ch = {}; ch[p[0]] = { mode: p[1] };
      await saveMy(ch, p[1] === "fill" ? a.label + ": will be filled." : a.label + ": left for you.");
      if (p[1] === "fill" && !String(a.value || "").trim()) { S.maEdit = p[0]; S.maDraft = ""; render(); }
      return;
    }
    if (act === "ma-edit") { const a = myAnswer(arg); S.maEdit = S.maEdit === arg ? null : arg; S.maDraft = a ? a.value || "" : ""; render(); return; }
    if (act === "ma-cancel") { S.maEdit = null; render(); return; }
    if (act === "ma-save") {
      const ch = {}; ch[arg] = { value: S.maDraft };
      if (String(S.maDraft).trim()) ch[arg].mode = "fill";
      S.maEdit = null;
      await saveMy(ch);
      return;
    }
    if (act === "ma-options") { JHA.send("openOptions", { page: "my-answers" }).catch(function (e) { setStatus(e.message, "bad"); }); return; }
    if (act === "mark-applied") {
      try {
        const j = await JHA.send("markApplied", { id: S.data.job.id });
        S.marked = true; S.data.job.status = j.status;
        setStatus("Marked as applied. The dashboard now tracks it.", "ok");
      } catch (e) { setStatus(e.message, "bad"); }
      return;
    }
    if (act === "next-role") return nextRole("next");
    if (act === "skip-role") return nextRole("skip");
    if (act === "attach") return attach(arg);
    if (act === "open") {
      const t = S.data.tailored;
      if (t && t.files && t.files.pdf) JHA.send("open", { path: t.files.pdf.url }).catch(function (e) { setStatus(e.message, "bad"); });
      return;
    }
    if (act === "approve") {
      try {
        S.data.tailored = await JHA.send("approve", { id: S.data.job.id });
        setStatus("Tailored CV approved. You can attach it now.", "ok");
      } catch (e) { setStatus(e.message, "bad"); }
      return;
    }
    if (act === "add") {
      const btn = S.scan.add[arg];
      if (!btn || !JHA.canClick(btn, "add")) return setStatus("That button doesn’t look safe to press; add the box yourself.", "warn");
      const n = S.scan.groups[arg].length;
      JHA.safeClick(btn, "add");
      await JHA.waitFor(function () { return JHA.scan(hostEl()).groups[arg].length > n; }, 2500);
      rescan(true);
      setStatus(S.scan.groups[arg].length > n ? "Added a box. Tick what to fill, then Fill selected." : "No new box appeared; add it on the page.", S.scan.groups[arg].length > n ? "ok" : "warn");
    }
  }
  function onTick(key, on) {
    if (key.indexOf("q:") === 0) { const k = S.qList[+key.slice(2)]; if (k && S.q[k]) { S.q[k].on = on; S.q[k].note = ""; } }
    else if (key.indexOf("part:") === 0) S.parts[key.slice(5)] = on;
    else if (key.indexOf("extra:") === 0) S.extras[+key.slice(6)] = on;
    else S.ticks[key] = on;
    render();
  }
  function onSlot(key, value) {
    if (key.indexOf("q:") === 0) {
      const k = S.qList[+key.slice(2)];
      if (k && S.q[k]) { S.q[k].choice = value; S.q[k].on = !!value; S.q[k].note = ""; delete S.qResults[k]; }
      render();
      return;
    }
    const p = key.split(".");
    S.slots[p[0]][+p[1]] = +value;
    render();
  }

  /* ------------------------------------------------------------ showing up */
  async function show(force) {
    if (panel) { S.hidden = false; render(); return; }
    settings.open = !!(await JHA.store.get("exposePanel", false));
    panel = new JHA.Panel({
      open: settings.open, onAct: onAct, onTick: onTick, onSlot: onSlot,
      onMoved: function (pos) { JHA.store.set("pos", pos); },
      onInput: function (key, value) { if (S.maEdit === key) S.maDraft = value; },
      onEnter: function (key) { if (S.maEdit === key) onAct("ma-save", key); }
    });
    S.hidden = false;
    S.collapsed = false;
    const pos = await JHA.store.get("pos", null);
    if (pos) panel.place(pos);
    await load();
    if (!force && S.phase === "none" && !ATS) { panel.remove(); panel = null; }
  }

  async function start() {
    if (TOP && document.querySelector(EMBED)) return; /* the embedded form's own panel handles it */
    if (confirmText()) {
      /* a confirmation page: on a job board, or anywhere Job Hunter knows the role (posting link, Apply click, session) */
      if (!ATS) {
        let d;
        try { d = await JHA.send("autofill", { url: location.href }); } catch (e) { return; }
        if (!d || !d.job) return;
      }
      return onConfirmation();
    }
    const scan = JHA.scan(hostEl());
    if (!ATS && !looksLikeForm(scan)) return;
    if (!ATS) {
      /* an ordinary site with a form: only if Job Hunter knows the role (a posting link or a recent Apply click) */
      let d;
      try { d = await JHA.send("autofill", { url: location.href }); } catch (e) { return; }
      if (!d || !d.job) return;
    }
    S.scan = scan;
    await show(false);
    /* a posting page without its form yet (Workday before Apply): just the pill until a form appears */
    if (panel && !looksLikeForm(S.scan || scan)) { S.collapsed = true; S.autoCollapsed = true; render(); }
  }

  /* multi-step forms (Workday) and single-page apps: look again when the page changes. A throttle, not a
     debounce: pages that never stop re-rendering would otherwise never be looked at again. */
  let timer = 0;
  const mo = new MutationObserver(function (muts) {
    if (panel && muts.every(function (m) { return panel.host.contains(m.target) || m.target === panel.host; })) return;
    if (timer) return;
    timer = setTimeout(function () {
      timer = 0;
      if (location.href !== lastUrl) {
        lastUrl = location.href;
        if (panel && S.phase === "ready") { rescan(true); runWatch(); return; }
      }
      if (panel && !S.hidden && S.phase === "ready" && !S.busy) {
        rescan(false);
        if (S.autoCollapsed && looksLikeForm(S.scan)) { S.autoCollapsed = false; S.collapsed = false; render(); }
        if (S.filledAt && Date.now() - S.lastCapture > 2000) captureNow();
        runWatch();
      }
      else if (!panel && !S.hidden && !JHA.starting) { JHA.starting = true; start().finally(function () { JHA.starting = false; }); }
      maybeConfirm();
    }, 500);
  });
  mo.observe(document.documentElement, { childList: true, subtree: true });

  JHA.ext.runtime.onMessage.addListener(function (msg) {
    if (!msg || msg.type !== "toggle" || !TOP) return;
    if (panel && !S.hidden) { S.collapsed = !S.collapsed; S.autoCollapsed = false; render(); }
    else { S.hidden = false; show(true); }
  });

  JHA.starting = true;
  start().finally(function () { JHA.starting = false; });
})();
