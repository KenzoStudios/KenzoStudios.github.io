/* Job Hunter Autofill: the on-page panel. A Shadow DOM box in the deal-desk style (graphite, one lime accent),
   about 340px wide, draggable by its header and collapsible to a pill. It only draws; content.js decides. */
(function () {
  const JHA = globalThis.JHA;
  if (!JHA || JHA.Panel) return;

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; });
  }
  /* Tabler icons (MIT), as on the dashboard */
  const I = {
    check: '<path d="M5 12l5 5l10-10"/>',
    x: '<path d="M18 6l-12 12"/><path d="M6 6l12 12"/>',
    minus: '<path d="M5 12l14 0"/>',
    file: '<path d="M14 3v4a1 1 0 0 0 1 1h4"/><path d="M17 21h-10a2 2 0 0 1-2-2v-14a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2z"/>',
    clip: '<path d="M15 7l-6.5 6.5a1.5 1.5 0 0 0 3 3l6.5-6.5a3 3 0 0 0-6-6l-6.5 6.5a4.5 4.5 0 0 0 9 9l6.5-6.5"/>',
    shield: '<path d="M12 3a12 12 0 0 0 8.5 3a12 12 0 0 1-8.5 15a12 12 0 0 1-8.5-15a12 12 0 0 0 8.5-3"/><path d="M9 12l2 2l4-4"/>',
    alert: '<path d="M12 9v4"/><path d="M10.363 3.591l-8.106 13.534a1.914 1.914 0 0 0 1.636 2.871h16.214a1.914 1.914 0 0 0 1.636-2.87l-8.106-13.536a1.914 1.914 0 0 0-3.274 0z"/><path d="M12 16h.01"/>',
    copy: '<path d="M7 9.667a2.667 2.667 0 0 1 2.667-2.667h8.666a2.667 2.667 0 0 1 2.667 2.667v8.666a2.667 2.667 0 0 1-2.667 2.667h-8.666a2.667 2.667 0 0 1-2.667-2.667z"/><path d="M4.012 16.737a2.005 2.005 0 0 1-1.012-1.737v-10c0-1.1.9-2 2-2h10c.75 0 1.158.385 1.5 1"/>',
    ext: '<path d="M12 6h-6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6"/><path d="M11 13l9-9"/><path d="M15 4h5v5"/>',
    dn: '<path d="M6 9l6 6l6-6"/>',
    plus: '<path d="M12 5l0 14"/><path d="M5 12l14 0"/>',
    target: '<path d="M11 12a1 1 0 1 0 2 0a1 1 0 1 0-2 0"/><path d="M7 12a5 5 0 1 0 10 0a5 5 0 1 0-10 0"/><path d="M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0"/>',
    next: '<path d="M5 12l14 0"/><path d="M13 18l6-6"/><path d="M13 6l6 6"/>',
    retry: '<path d="M20 11a8.1 8.1 0 0 0-15.5-2m-.5-4v4h4"/><path d="M4 13a8.1 8.1 0 0 0 15.5 2m.5 4v-4h-4"/>',
    folder: '<path d="M5 4h4l3 3h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-14a2 2 0 0 1-2-2v-11a2 2 0 0 1 2-2"/>',
    down: '<path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/><path d="M7 11l5 5l5-5"/><path d="M12 4l0 12"/>',
    pen: '<path d="M4 20h4l10.5-10.5a2.828 2.828 0 1 0-4-4l-10.5 10.5v4"/><path d="M13.5 6.5l4 4"/>',
    box: '<path d="M4 6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-12a2 2 0 0 1-2-2z"/>',
    play: '<path d="M7 4v16l13-8z"/>',
    stop: '<path d="M5 7a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-10a2 2 0 0 1-2-2z"/>'
  };
  function ic(n, cls) { return '<svg class="i' + (cls ? " " + cls : "") + '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + I[n] + "</svg>"; }

  const CSS = `
:host{all:initial}
*,*::before,*::after{box-sizing:border-box}
.jh{
  --canvas:#0A0B0D;--s1:#111215;--s2:#16171B;--s3:#1C1E22;--s4:#23252A;
  --line:#212328;--line2:#2E3036;--line3:#3B3E45;
  --ink:#F4F5F1;--ink2:#C9CCD1;--ink3:#8F949C;--ink4:#5E636B;
  --accent:#C6EC72;--accent-hover:#D3F38E;--accent-press:#B5DD5E;--on-accent:#10140A;
  --accent-wash:rgba(198,236,114,.10);--accent-line:rgba(198,236,114,.34);
  --warn:#EBBA76;--warn-wash:rgba(235,186,118,.11);--warn-line:rgba(235,186,118,.30);
  --risk:#EE9592;--risk-wash:rgba(238,149,146,.07);
  --display:"Bricolage Grotesque","Geist",ui-sans-serif,-apple-system,"SF Pro Display","Segoe UI",sans-serif;
  --sans:"Geist",ui-sans-serif,-apple-system,"SF Pro Text","Segoe UI",sans-serif;
  --mono:"Geist Mono",ui-monospace,"SF Mono",Menlo,monospace;
  --ease:cubic-bezier(.2,.7,.2,1);--ease-out:cubic-bezier(.16,1,.3,1);
  position:fixed;z-index:2147483646;right:16px;bottom:16px;width:340px;max-width:calc(100vw - 24px);
  color:var(--ink);font:400 13px/1.45 var(--sans);letter-spacing:-.003em;text-align:left;
  -webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;color-scheme:dark;
}
.jh button,.jh select,.jh input{font:inherit;color:inherit;letter-spacing:inherit;margin:0}
.jh button{cursor:pointer;-webkit-tap-highlight-color:transparent}
svg.i{width:15px;height:15px;flex:none;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
:focus{outline:none}
:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:6px}
.vh{position:absolute!important;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}

/* the card */
.card{position:relative;display:flex;flex-direction:column;max-height:min(680px,calc(100vh - 32px));border-radius:12px;overflow:hidden;
  background:linear-gradient(180deg,rgba(198,236,114,.055),transparent 120px),var(--s2);
  box-shadow:0 0 0 1px var(--line2) inset,0 1px 0 rgba(255,255,255,.05) inset,0 22px 50px -16px rgba(2,3,5,.85),0 4px 14px -6px rgba(2,3,5,.6);
  animation:popin .2s var(--ease-out) both}
.card::before{content:"";position:absolute;left:16px;right:16px;top:0;height:1px;background:linear-gradient(90deg,transparent,var(--accent),transparent);opacity:.55;pointer-events:none}
@keyframes popin{from{opacity:0;transform:translateY(6px) scale(.98)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion:reduce){.card,.pill{animation:none}}

.hd{display:flex;align-items:center;gap:8px;padding:10px 8px 10px 14px;cursor:grab;user-select:none;touch-action:none;border-bottom:1px solid var(--line)}
.hd.dragging{cursor:grabbing}
.mark{width:9px;height:9px;border-radius:50%;background:var(--accent);box-shadow:0 0 0 3px var(--accent-wash),0 0 12px rgba(198,236,114,.45);flex:none}
.brand{font:700 14px/1 var(--display);letter-spacing:-.01em;color:var(--ink)}
.brand-sub{font-size:11.5px;color:var(--ink3);margin-left:1px}
.hd .sp{flex:1}
.ib{display:grid;place-items:center;width:28px;height:28px;border:0;border-radius:6px;background:none;color:var(--ink3)}
.ib:hover{background:var(--s4);color:var(--ink)}

.body{overflow:auto;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:var(--line2) transparent}
.body::-webkit-scrollbar{width:8px}.body::-webkit-scrollbar-thumb{background:var(--line2);border-radius:8px}

.role{padding:12px 14px 12px}
.firm{font:700 17px/1.15 var(--display);letter-spacing:-.015em;color:var(--ink)}
.title{margin-top:3px;font-size:12.5px;color:var(--ink2)}
.how{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:9px}
.chip{display:inline-flex;align-items:center;gap:5px;min-height:22px;padding:0 8px;border-radius:9999px;font-size:11.5px;font-weight:500;
  color:var(--accent);background:var(--accent-wash);box-shadow:inset 0 0 0 1px var(--accent-line)}
.chip svg.i{width:12px;height:12px;stroke-width:2.2}
.chip.soft{color:var(--warn);background:var(--warn-wash);box-shadow:inset 0 0 0 1px var(--warn-line)}
.lk{border:0;background:none;padding:2px 4px;border-radius:4px;font-size:12px;font-weight:500;color:var(--ink3);text-decoration:underline;text-decoration-color:var(--line3);text-underline-offset:3px}
.lk:hover{color:var(--ink);text-decoration-color:var(--ink3)}
.picker{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:6px;margin-top:9px}
select.sel{width:100%;min-height:32px;padding:0 8px;border-radius:6px;border:0;background:var(--s3);box-shadow:inset 0 0 0 1px var(--line2);font-size:12.5px}

.safe{display:flex;gap:8px;align-items:flex-start;margin:0 14px 10px;padding:8px 10px;border-radius:8px;font-size:12px;line-height:1.45;color:var(--ink2);
  background:var(--s1);box-shadow:inset 0 0 0 1px var(--line2)}
.safe svg.i{color:var(--accent);margin-top:1px;width:14px;height:14px}
.safe b{color:var(--ink);font-weight:600}

.sec{padding:10px 14px 12px;border-top:1px solid var(--line)}
.sh{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px}
.sh h3{margin:0;font:700 13px/1.2 var(--display);letter-spacing:-.005em;color:var(--ink)}
.sh .n{font:500 11px/1 var(--mono);color:var(--ink3)}
.gl{margin:8px 0 2px;font-size:10.5px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--ink3)}
.note{font-size:11.5px;color:var(--ink3);line-height:1.45;margin:2px 0 6px}

.row{display:grid;grid-template-columns:18px 100px minmax(0,1fr) 16px;align-items:center;gap:8px;min-height:28px;padding:2px 4px;margin:0 -4px;border-radius:6px;cursor:pointer}
.row:hover{background:rgba(255,255,255,.03)}
.row .k{font-size:12px;color:var(--ink3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.row .v{font-size:12.5px;color:var(--ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.row.off .v{color:var(--ink3)}
.row .st{display:grid;place-items:center}
.row .st svg.i{width:14px;height:14px;stroke-width:2.4}
.ok{color:var(--accent)} .bad{color:var(--risk)} .wait{color:var(--warn)}
.row.copy{grid-template-columns:100px minmax(0,1fr) 26px;cursor:default}
.cb{appearance:none;-webkit-appearance:none;width:16px;height:16px;border-radius:4px;margin:0;display:grid;place-items:center;cursor:pointer;
  background:var(--s1);box-shadow:inset 0 0 0 1.5px var(--line3);transition:background .12s var(--ease)}
.cb:checked{background:var(--accent);box-shadow:none}
.cb:checked::after{content:"";width:8px;height:4.5px;border-left:2px solid var(--on-accent);border-bottom:2px solid var(--on-accent);transform:translateY(-1px) rotate(-45deg)}
.cb:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.more{display:flex;align-items:center;gap:4px;margin-top:6px;border:0;background:none;padding:2px 0;font-size:12px;font-weight:500;color:var(--ink3)}
.more:hover{color:var(--ink)}
.more svg.i{width:13px;height:13px;transition:transform .15s var(--ease)}
.more[aria-expanded="true"] svg.i{transform:rotate(180deg)}

.slot{margin-top:8px;padding:9px 10px 10px;border-radius:8px;background:var(--s1);box-shadow:inset 0 0 0 1px var(--line2)}
.slot-h{display:grid;grid-template-columns:auto minmax(0,1fr);align-items:center;gap:8px}
.slot-h .lab{font-size:11px;font-weight:600;letter-spacing:.05em;text-transform:uppercase;color:var(--ink3)}
.parts{display:flex;flex-wrap:wrap;gap:4px;margin-top:8px}
.part{display:inline-flex;align-items:center;gap:6px;min-height:26px;padding:0 9px 0 6px;border-radius:9999px;font-size:12px;color:var(--ink2);cursor:pointer;
  background:var(--s3);box-shadow:inset 0 0 0 1px var(--line2)}
.part .cb{width:14px;height:14px}
.part .cb:checked::after{width:7px;height:4px}
.part .st svg.i{width:12px;height:12px;stroke-width:2.6}
.bul{margin:8px 0 0;padding:0;list-style:none;display:grid;gap:4px}
.bul li{position:relative;padding-left:12px;font-size:11.5px;line-height:1.45;color:var(--ink3);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.bul li::before{content:"";position:absolute;left:2px;top:.68em;width:5px;height:1.5px;background:var(--ink4)}
.bul li.x{color:var(--accent)}
.bul li.x::before{background:var(--accent)}

.extra{display:grid;grid-template-columns:18px minmax(0,1fr) auto;gap:8px;align-items:start;padding:7px 0;cursor:pointer}
.extra + .extra{border-top:1px solid var(--line)}
.extra .cb{margin-top:2px}
.extra .t{font-size:12.5px;line-height:1.45;color:var(--ink)}
.extra .why{display:block;margin-top:3px;font-size:11px;line-height:1.4;color:var(--ink3)}
.extra .to{display:block;margin-top:3px;font-size:11px;color:var(--ink3)}
.extra .to b{color:var(--ink2);font-weight:500}

.file{display:grid;grid-template-columns:28px minmax(0,1fr) auto;gap:10px;align-items:center;padding:7px 0}
.file + .file{border-top:1px solid var(--line)}
.fi{display:grid;place-items:center;width:28px;height:28px;border-radius:6px;background:var(--s3);box-shadow:inset 0 0 0 1px var(--line2);color:var(--ink3)}
.fi.ok{color:var(--accent);background:var(--accent-wash);box-shadow:inset 0 0 0 1px var(--accent-line)}
.fn{font-size:12.5px;font-weight:500;color:var(--ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fs{font-size:11px;color:var(--ink3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fa{display:flex;align-items:center;gap:4px}
.seg{display:inline-flex;padding:2px;border-radius:6px;background:var(--s1);box-shadow:inset 0 0 0 1px var(--line2)}
.seg button{border:0;background:none;min-height:22px;padding:0 7px;border-radius:4px;font-size:11px;font-weight:500;color:var(--ink3)}
.seg button[aria-pressed="true"]{background:var(--s4);color:var(--ink)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:28px;padding:0 10px;border:0;border-radius:6px;font-size:12px;font-weight:600;
  background:var(--s3);color:var(--ink);box-shadow:inset 0 0 0 1px var(--line2),inset 0 1px 0 rgba(255,255,255,.035);white-space:nowrap}
.btn:hover{background:var(--s4)}
.btn svg.i{width:13px;height:13px}
.btn:disabled{color:var(--ink4);background:none;box-shadow:inset 0 0 0 1px var(--line);cursor:not-allowed}
.btn.go{background:var(--accent);color:var(--on-accent);box-shadow:inset 0 1px 0 rgba(255,255,255,.4)}
.btn.go:hover{background:var(--accent-hover)}
.btn.go:active{background:var(--accent-press)}

.tail{margin-top:4px;padding:9px 10px;border-radius:8px;background:var(--s1);box-shadow:inset 0 0 0 1px var(--line2)}
.tail-h{display:flex;align-items:center;justify-content:space-between;gap:8px}
.tail-h b{font-size:12.5px;font-weight:600}
.pillst{display:inline-flex;align-items:center;gap:4px;min-height:20px;padding:0 7px;border-radius:9999px;font-size:11px;font-weight:600}
.pillst.sug{color:var(--warn);background:var(--warn-wash);box-shadow:inset 0 0 0 1px var(--warn-line)}
.pillst.app{color:var(--accent);background:var(--accent-wash);box-shadow:inset 0 0 0 1px var(--accent-line)}
.tail p{margin:6px 0 0;font-size:11.5px;color:var(--ink3);line-height:1.45}
.tail .acts{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
.chg{margin:8px 0 0;padding:0;list-style:none;display:grid;gap:6px}
.chg li{font-size:11.5px;line-height:1.45;color:var(--ink2);padding-left:12px;position:relative}
.chg li::before{content:"";position:absolute;left:2px;top:.68em;width:5px;height:1.5px;background:var(--accent)}
.ba{margin-top:8px;display:grid;gap:6px;font-size:11.5px;line-height:1.45}
.ba .l{display:block;font-size:10.5px;font-weight:600;letter-spacing:.05em;text-transform:uppercase;color:var(--ink3);margin-bottom:2px}
.ba .was{color:var(--ink3);text-decoration:line-through;text-decoration-color:var(--ink4)}
.ba .now{color:var(--ink)}

.ft{padding:10px 14px 12px;border-top:1px solid var(--line);background:var(--s2)}
.fill{width:100%;min-height:38px;font-size:13px;border-radius:8px}
.fill .n{font:600 11.5px/1 var(--mono);opacity:.7}
.status{margin:8px 0 0;font-size:11.5px;line-height:1.45;color:var(--ink3);min-height:1.45em}
.status.ok{color:var(--accent)} .status.warn{color:var(--warn)} .status.bad{color:var(--risk)}

.empty{padding:14px}
.empty h3{margin:0 0 4px;font:700 14px/1.25 var(--display);color:var(--ink)}
.empty p{margin:0;font-size:12px;color:var(--ink3);line-height:1.5}
.empty .acts{display:flex;gap:6px;margin-top:10px}
code{font:500 11px/1 var(--mono);padding:2px 5px;border-radius:4px;background:var(--s3);color:var(--ink2)}
.spin{width:14px;height:14px;border-radius:50%;border:2px solid var(--line3);border-top-color:var(--accent);animation:sp .8s linear infinite}
@keyframes sp{to{transform:rotate(360deg)}}

/* apply session progress, in the header */
.prog{display:inline-flex;align-items:center;gap:5px;min-height:20px;padding:0 8px;border-radius:9999px;font:600 11px/1 var(--mono);
  color:var(--accent);background:var(--accent-wash);box-shadow:inset 0 0 0 1px var(--accent-line);white-space:nowrap}

/* questions from the answer bank */
.q{padding:8px 0}
.q + .q{border-top:1px solid var(--line)}
.q-h{display:grid;grid-template-columns:18px minmax(0,1fr) 16px;gap:8px;align-items:start;cursor:pointer}
.q-h .cb{margin-top:1px}
.q .ql{font-size:12px;line-height:1.4;color:var(--ink)}
.q .st svg.i{width:14px;height:14px;stroke-width:2.4}
.q .qsel{margin:6px 0 0 26px;width:calc(100% - 26px)}
.q .ans{margin:6px 0 0 26px;font-size:11.5px;line-height:1.45;color:var(--ink3);display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden;white-space:pre-wrap}
.q.on .ans{color:var(--ink2)}
.q .qm{margin:4px 0 0 26px;font-size:10.5px;color:var(--ink4);font-family:var(--mono)}
.q .qm.warn{color:var(--warn);font-family:var(--sans)}

/* confirmation page */
.done{margin:12px 14px 4px;padding:11px 12px;border-radius:8px;background:var(--accent-wash);box-shadow:inset 0 0 0 1px var(--accent-line)}
.done h3{margin:0 0 3px;font:700 14px/1.25 var(--display);color:var(--ink)}
.done p{margin:0;font-size:12px;line-height:1.45;color:var(--ink2)}
.done .acts{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}
.sessbar{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:0 14px 10px;font-size:11.5px;color:var(--ink3)}

/* why a field didn't take */
.rsn{margin:-1px 0 4px 26px;font-size:11px;line-height:1.4}
.rsn.wait{color:var(--warn)} .rsn.bad{color:var(--risk)}
.row.cal .v{color:var(--warn)}

/* My answers */
.ma{display:grid;grid-template-columns:minmax(0,1fr) auto 26px 16px;align-items:center;gap:6px;min-height:36px;padding:3px 0}
.ma + .ma{border-top:1px solid var(--line)}
.ma .kv{display:flex;flex-direction:column;min-width:0}
.ma .k{font-size:11px;line-height:1.3;color:var(--ink3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ma .v{font-size:12.5px;line-height:1.35;color:var(--ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ma.off .v{color:var(--ink3);font-style:italic}
.ma .st{display:grid;place-items:center}
.ma .st svg.i,.cf .st svg.i{width:14px;height:14px;stroke-width:2.4}
.ma .ib{width:26px;height:26px}
.ma .ib svg.i{width:13px;height:13px}
.mae{display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:6px;margin:2px 0 8px}
.mai{min-height:30px;padding:0 9px;border:0;border-radius:6px;background:var(--s1);color:var(--ink);box-shadow:inset 0 0 0 1px var(--line3);font-size:12.5px}
.mai:focus-visible{outline:2px solid var(--accent);outline-offset:1px}
.note b{color:var(--ink2);font-weight:600}
.more svg.i{width:13px;height:13px}

/* Your confirmation needed */
.cf{display:grid;grid-template-columns:16px minmax(0,1fr) auto;gap:8px;align-items:center;padding:6px 0}
.cf + .cf{border-top:1px solid var(--line)}
.cf .ct{font-size:12px;line-height:1.4;color:var(--ink2)}
.cf .st{display:grid;place-items:center;color:var(--warn)} .cf .st.ok{color:var(--accent)}

/* sign-in pages and CAPTCHAs */
.notice{margin:0 14px 10px;padding:9px 11px;border-radius:8px;background:var(--s1);box-shadow:inset 0 0 0 1px var(--line2)}
.notice b{display:block;font-size:12.5px;color:var(--ink);font-weight:600}
.notice p{margin:3px 0 0;font-size:11.5px;line-height:1.45;color:var(--ink3)}
.notice.warn{background:var(--warn-wash);box-shadow:inset 0 0 0 1px var(--warn-line)}
.notice.warn b{color:var(--warn)}
.notice .acts{display:flex;gap:6px;margin-top:8px}

/* uploads a site refused */
.refused{margin:0 0 6px 38px;padding:8px 10px;border-radius:8px;background:var(--risk-wash);box-shadow:inset 0 0 0 1px rgba(238,149,146,.25)}
.refused p{margin:0 0 6px;font-size:11.5px;color:var(--ink2)}
.refused .acts{display:flex;flex-wrap:wrap;gap:6px}

/* Run mode */
.ftb{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:6px}
.btn.run,.btn.stop{min-height:38px;border-radius:8px;padding:0 14px}
.btn.run svg.i{width:12px;height:12px;fill:currentColor;stroke-width:1.4}
.btn.stop{color:var(--warn);box-shadow:inset 0 0 0 1px var(--warn-line)}
.runbar{display:grid;grid-template-columns:10px minmax(0,1fr) auto;gap:9px;align-items:center;margin:0 14px 10px;padding:9px 10px 9px 11px;border-radius:8px;
  font-size:11.5px;line-height:1.45;color:var(--ink3);background:var(--accent-wash);box-shadow:inset 0 0 0 1px var(--accent-line)}
.runbar b{color:var(--ink);font-weight:600}
.pulse{width:8px;height:8px;border-radius:50%;background:var(--accent);box-shadow:0 0 0 0 rgba(198,236,114,.6);animation:pl 1.6s var(--ease) infinite}
@keyframes pl{0%{box-shadow:0 0 0 0 rgba(198,236,114,.55)}70%{box-shadow:0 0 0 7px rgba(198,236,114,0)}100%{box-shadow:0 0 0 0 rgba(198,236,114,0)}}
@media (prefers-reduced-motion:reduce){.pulse{animation:none}}

/* collapsed */
.pill{display:inline-flex;align-items:center;gap:8px;min-height:36px;padding:0 14px 0 12px;border:0;border-radius:9999px;cursor:pointer;
  background:var(--s2);color:var(--ink);box-shadow:0 0 0 1px var(--line2) inset,0 12px 30px -12px rgba(2,3,5,.85);animation:popin .2s var(--ease-out) both;
  font:600 12.5px/1 var(--sans)}
.pill:hover{background:var(--s3)}
.pill .pf{color:var(--ink3);font-weight:500;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.wrap-pill{display:flex;justify-content:flex-end}
`;

  function Panel(opts) {
    this.opts = opts;
    this.host = document.createElement("div");
    this.host.setAttribute("data-job-hunter-autofill", "");
    this.host.style.cssText = "all:initial;position:fixed;z-index:2147483646;inset:auto;";
    this.root = this.host.attachShadow({ mode: opts.open ? "open" : "closed" });
    const style = document.createElement("style");
    style.textContent = CSS;
    this.root.appendChild(style);
    this.box = document.createElement("div");
    this.box.className = "jh";
    this.box.setAttribute("role", "complementary");
    this.box.setAttribute("aria-label", "Job Hunter autofill");
    this.root.appendChild(this.box);
    (document.body || document.documentElement).appendChild(this.host);
    this.pos = null;
    this.wire();
  }
  Panel.prototype.place = function (pos) {
    this.pos = pos;
    const b = this.box;
    if (!pos) { b.style.left = b.style.top = ""; b.style.right = b.style.bottom = "16px"; return; }
    const w = b.offsetWidth || 340, h = b.offsetHeight || 60;
    /* the whole card stays on screen, however it was dragged or whatever it grew to */
    const x = Math.max(8, Math.min(window.innerWidth - w - 8, pos.x));
    const y = Math.max(8, Math.min(window.innerHeight - h - 8, pos.y));
    b.style.right = b.style.bottom = "auto";
    b.style.left = x + "px";
    b.style.top = y + "px";
  };
  Panel.prototype.wire = function () {
    const self = this, b = this.box;
    b.addEventListener("click", function (e) {
      const t = e.target.closest("[data-act]");
      if (!t || t.disabled) return;
      self.opts.onAct(t.getAttribute("data-act"), t.getAttribute("data-arg"), t, e);
    });
    b.addEventListener("change", function (e) {
      const t = e.target;
      if (t.matches("[data-tick]")) self.opts.onTick(t.getAttribute("data-tick"), t.checked);
      else if (t.matches("[data-slot]")) self.opts.onSlot(t.getAttribute("data-slot"), t.value);
      else if (t.matches("[data-pick]")) self.opts.onAct("pick-role", t.value, t, e);
    });
    b.addEventListener("input", function (e) {
      const t = e.target;
      if (t.matches && t.matches("[data-ma-input]") && self.opts.onInput) self.opts.onInput(t.getAttribute("data-ma-input"), t.value);
    });
    b.addEventListener("keydown", function (e) {
      const t = e.target;
      if (t.matches && t.matches("[data-ma-input]")) {
        /* typing in the panel's own box: keep the keys away from the page (its shortcuts, its form) */
        e.stopPropagation();
        if (e.key === "Enter") { e.preventDefault(); if (self.opts.onEnter) self.opts.onEnter(t.getAttribute("data-ma-input")); }
        else if (e.key === "Escape") self.opts.onAct("ma-cancel");
        return;
      }
      if (e.key === "Escape") { e.stopPropagation(); self.opts.onAct("collapse"); }
    });
    ["keyup", "keypress"].forEach(function (type) {
      b.addEventListener(type, function (e) { if (e.target.matches && e.target.matches("[data-ma-input]")) e.stopPropagation(); });
    });
    /* dragging by the header (or the pill) */
    let drag = null;
    b.addEventListener("pointerdown", function (e) {
      const hd = e.target.closest(".hd,.pill");
      if (!hd || (e.target.closest("button") && !e.target.closest(".pill")) || e.button !== 0) return;
      const r = b.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top, x0: e.clientX, y0: e.clientY, moved: false, el: hd };
      hd.setPointerCapture(e.pointerId);
    });
    b.addEventListener("pointermove", function (e) {
      if (!drag) return;
      if (!drag.moved && Math.abs(e.clientX - drag.x0) + Math.abs(e.clientY - drag.y0) < 4) return;
      drag.moved = true;
      drag.el.classList.add("dragging");
      self.place({ x: e.clientX - drag.dx, y: e.clientY - drag.dy });
    });
    function end() {
      if (!drag) return;
      const moved = drag.moved;
      drag.el.classList.remove("dragging");
      drag = null;
      if (moved) { self.justDragged = Date.now(); self.opts.onMoved(self.pos); }
    }
    b.addEventListener("pointerup", end);
    b.addEventListener("pointercancel", end);
    window.addEventListener("resize", function () { if (self.pos) self.place(self.pos); });
  };
  Panel.prototype.render = function (html) {
    const body = this.root.querySelector(".body");
    const scroll = body ? body.scrollTop : 0;
    const active = this.root.activeElement;
    const fk = active && active.getAttribute && active.getAttribute("data-fk");
    this.box.innerHTML = html;
    const nb = this.root.querySelector(".body");
    if (nb) nb.scrollTop = scroll;
    if (fk) { const el = this.root.querySelector('[data-fk="' + fk + '"]'); if (el) el.focus({ preventScroll: true }); }
    if (this.pos) this.place(this.pos);
  };
  Panel.prototype.remove = function () { this.host.remove(); };

  JHA.Panel = Panel;
  JHA.esc = esc;
  JHA.ic = ic;
})();
