# Running the extension in Safari (for later)

The extension is written to work in Safari too: it uses the `browser` namespace when it exists and falls back to
`chrome`, and only uses APIs Safari supports (storage, runtime messaging, tabs.create, action, content scripts,
host permissions). Safari extensions have to be wrapped in a small Mac app, which needs Xcode. Xcode isn't installed
yet, so these are the steps for when it is.

## 1. Install Xcode

Install Xcode from the Mac App Store, open it once to finish installing its components, then in Terminal:

```
sudo xcode-select -s /Applications/Xcode.app/Contents/Developer
xcrun --find safari-web-extension-converter
```

The second command should print a path. If it says "unable to find utility", Xcode isn't selected yet.

## 2. Convert the extension

```
cd ~/Documents/"Claude Code"/"Job Hunter"
xcrun safari-web-extension-converter extension \
  --project-location safari \
  --app-name "Job Hunter Autofill" \
  --bundle-identifier com.example.jobhunter.autofill \
  --macos-only \
  --swift \
  --no-open
```

This creates `safari/Job Hunter Autofill/` with an Xcode project. It links to the files in `extension/` rather than
copying them, so later changes to the extension are picked up by rebuilding (leave out `--copy-resources`).
It may warn that Safari doesn't support some manifest keys (for example `minimum_chrome_version`); that's fine.

## 3. Build and run

1. `open "safari/Job Hunter Autofill/Job Hunter Autofill.xcodeproj"`
2. In Xcode, select the project, then each of the two targets (the app and the extension) > **Signing & Capabilities**,
   and choose your **Personal Team** (sign in with your Apple ID in Xcode > Settings > Accounts if it isn't listed).
3. Choose the **Job Hunter Autofill (macOS)** scheme and press **Cmd+R**. A small app window opens; you can close it.

## 4. Turn it on in Safari

1. Safari > Settings > **Advanced**: tick **Show features for web developers**.
2. Safari > **Develop** menu: tick **Allow Unsigned Extensions** (Safari asks for your password; this resets each time
   Safari quits, so do it again after a restart, or sign the app with a paid developer account to avoid it).
3. Safari > Settings > **Extensions**: tick **Job Hunter Autofill**.
4. Click **Edit Websites...** and set **Other Websites** to **Allow**, so the panel can appear on any careers site.
   The extension still only sends data to Job Hunter on this computer.
5. Open the dashboard at http://localhost:8765 and check **Autofill ready** shows under Open Posting.

## If Safari won't start the background script

Safari has supported Manifest V3 service workers since Safari 16.4. On an older Safari, change the `background` entry in
`extension/manifest.json` to

```
"background": { "scripts": ["background.js"], "persistent": false },
```

`background.js` works unchanged either way. Keep the `service_worker` version for Chrome.

## Things to check the first time in Safari

- Attaching a file: Safari 14.1 or later is needed to set a file input's files.
- The dashboard link `chrome://extensions` in the "Set up autofill" help is Chrome-specific; in Safari the extension is
  managed in Settings > Extensions.
