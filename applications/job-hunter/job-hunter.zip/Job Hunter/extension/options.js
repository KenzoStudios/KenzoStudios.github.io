/* Job Hunter Autofill: options. The server address may only be this computer (127.0.0.1 or localhost). */
const ext = globalThis.browser || globalThis.chrome;
const DEFAULT_SERVER = "http://127.0.0.1:8765";
const $ = function (id) { return document.getElementById(id); };

function validServer(u) {
  try {
    const x = new URL(String(u).trim());
    if (x.protocol === "http:" && (x.hostname === "127.0.0.1" || x.hostname === "localhost") && (x.pathname === "/" || x.pathname === "")) return x.origin;
  } catch (e) { /* not a URL */ }
  return null;
}
function say(text, tone) { const s = $("status"); s.textContent = text; s.className = tone || ""; }

async function init() {
  const o = await ext.storage.local.get(["server", "exposePanel"]);
  $("server").value = validServer(o.server) || DEFAULT_SERVER;
  $("expose").checked = !!o.exposePanel;
}
$("save").addEventListener("click", async function () {
  const v = validServer($("server").value);
  if (!v) return say("Use http://127.0.0.1:<port> or http://localhost:<port>.", "bad");
  await ext.storage.local.set({ server: v });
  $("server").value = v;
  say("Saved.", "ok");
});
$("reset").addEventListener("click", async function () {
  await ext.storage.local.remove("server");
  $("server").value = DEFAULT_SERVER;
  say("Back to " + DEFAULT_SERVER + ".", "ok");
});
$("test").addEventListener("click", async function () {
  say("Testing…");
  ext.runtime.sendMessage({ type: "ping" }, function (r) {
    const err = ext.runtime.lastError;
    if (err || !r || r.error) return say((r && r.error) || (err && err.message) || "No answer.", "bad");
    say("Connected to Job Hunter at " + r.server + ".", "ok");
  });
});
$("expose").addEventListener("change", async function (e) {
  await ext.storage.local.set({ exposePanel: e.target.checked });
  say(e.target.checked ? "Panel visible to page scripts (tests only)." : "Panel hidden from page scripts.", "ok");
});
init();


/* ------------------------------------------------------------ My answers */
const tabs = { conn: [$("tab-conn"), $("page-conn")], my: [$("tab-my"), $("page-my")] };
function showTab(which) {
  Object.keys(tabs).forEach(function (k) { tabs[k][0].setAttribute("aria-selected", String(k === which)); tabs[k][1].hidden = k !== which; });
  if (which === "my") loadMy();
}
$("tab-conn").addEventListener("click", function () { history.replaceState(null, "", "#"); showTab("conn"); });
$("tab-my").addEventListener("click", function () { history.replaceState(null, "", "#my-answers"); showTab("my"); });
function sayMy(text, tone) { const s = $("ma-status"); s.textContent = text; s.className = tone || ""; }
function ask(type, data) {
  return new Promise(function (resolve, reject) {
    ext.runtime.sendMessage(Object.assign({ type: type }, data || {}), function (r) {
      const err = ext.runtime.lastError;
      if (err || !r || r.error) return reject(new Error((r && r.error) || (err && err.message) || "No answer."));
      resolve(r);
    });
  });
}
function el(tag, attrs, text) {
  const n = document.createElement(tag);
  Object.keys(attrs || {}).forEach(function (k) { if (attrs[k] !== undefined && attrs[k] !== null) n.setAttribute(k, attrs[k]); });
  if (text) n.textContent = text;
  return n;
}
let loaded = false;
async function loadMy() {
  if (loaded) return;
  let r;
  try { r = await ask("myAnswers"); } catch (e) { $("ma-list").textContent = ""; sayMy(e.message, "bad"); return; }
  loaded = true;
  $("eeo-note").textContent = r.eeo_note || "";
  const list = $("ma-list");
  list.textContent = "";
  let group = "";
  r.answers.forEach(function (a) {
    if (a.group !== group) { group = a.group; list.appendChild(el("p", { class: "grp" }, group)); }
    const row = el("div", { class: "ans", "data-key": a.key });
    const lab = el("label", { class: "l", for: "v-" + a.key }, a.label);
    if (a.hint) lab.appendChild(el("span", { class: "h" }, a.hint));
    row.appendChild(lab);
    const box = el("div", { class: "sub" });
    const long = a.key === "notice_period";
    const v = el(long ? "textarea" : "input", { id: "v-" + a.key, "data-f": "value", type: long ? null : "text", placeholder: a.key === "dob" ? "YYYY-MM-DD" : /^(gender|ethnicity|sexual_orientation|disability|veteran|religion|age_range)$/.test(a.key) ? "Prefer not to say" : "", maxlength: "400" });
    v.value = a.value || "";
    box.appendChild(v);
    if (a.key === "salary") {
      [["free_text", "For free-text salary boxes", "textarea"], ["number", "For number-only boxes (GBP)", "number"], ["eur_value", "Roles in Ireland or paid in euro", "text"],
       ["eur_free_text", "Free-text, euro", "textarea"], ["eur_number", "Number-only, euro", "number"]].forEach(function (x) {
        box.appendChild(el("label", { for: "v-" + a.key + "-" + x[0] }, x[1]));
        const i = el(x[2] === "textarea" ? "textarea" : "input", { id: "v-" + a.key + "-" + x[0], "data-f": x[0], type: x[2] === "textarea" ? null : x[2], maxlength: "400", min: x[2] === "number" ? "0" : null });
        i.value = a[x[0]] == null ? "" : a[x[0]];
        box.appendChild(i);
      });
    }
    row.appendChild(box);
    const m = el("select", { "data-f": "mode", "aria-label": a.label + ": fill or leave" });
    [["fill", "Fill automatically"], ["leave", "Leave for me"]].forEach(function (o) { const op = el("option", { value: o[0] }, o[1]); if (a.mode === o[0]) op.selected = true; m.appendChild(op); });
    row.appendChild(m);
    list.appendChild(row);
  });
}
$("ma-save").addEventListener("click", async function () {
  const changes = {};
  document.querySelectorAll("#ma-list .ans").forEach(function (row) {
    const c = {};
    row.querySelectorAll("[data-f]").forEach(function (i) {
      const f = i.getAttribute("data-f");
      if (i.type === "number") c[f] = i.value === "" ? null : Number(i.value);
      else c[f] = i.value;
    });
    changes[row.getAttribute("data-key")] = c;
  });
  sayMy("Saving…");
  try { await ask("saveMyAnswers", { answers: changes }); sayMy("Saved. Every form uses these from now on.", "ok"); }
  catch (e) { sayMy(e.message, "bad"); }
});
showTab(location.hash === "#my-answers" ? "my" : "conn");
