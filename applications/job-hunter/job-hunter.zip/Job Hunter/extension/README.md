# Job Hunter Autofill (Chrome extension)

Fills job application forms from Job Hunter: your contact details, right to work, education (with grades), job titles,
the experience boxes (your CV bullets, word for word), dates, dropdowns and typeaheads, rich text answer boxes, and your
standing answers (how you heard, salary, equal-opportunity questions and the like), and attaches your CV and cover
letter. It never submits anything. Version 1.2.0.

## Install (once)

1. Make sure Job Hunter is running: double-click `Open Job Hunter.command` (the dashboard opens at http://localhost:8765).
2. In Chrome, go to `chrome://extensions`.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and choose this folder: `Job Hunter/extension`.
5. Optional: pin it. Click the puzzle-piece icon in Chrome's toolbar, then the pin next to **Job Hunter Autofill**.
6. Reload the dashboard. Under **Open Posting** it now says **Autofill ready**.

After you change files in this folder, press the reload arrow on the extension's card in `chrome://extensions`.

## Use

1. In the dashboard, pick a role and click **Open Posting** (or press `3`).
2. Go to the application form. The panel appears in the bottom-right corner. If it doesn't, click the toolbar button.
3. Check the values, untick anything you don't want, and press **Fill selected**.
4. Tick any **optional lines** you want added to a role description. They are off by default.
5. Press **Attach** next to the CV and the cover letter (PDF or Word). A suggested **tailored CV** needs **Approve** first.
6. Under **Questions**, read each answer from your answer bank. Untick any you don't want, or pick another answer from
   its list. Answers written for this role are ticked; uncertain ones aren't.
7. Read the whole page, fix anything the site didn't take (marked in amber or red in the panel), then submit it yourself.
8. On the confirmation page, press **Mark as applied**. In an apply session, **Next role** opens the next posting.

On a multi-step form (Workday), the panel looks again at each step. Press **Fill selected** on each one, or press
**Run** once: it fills this page, then fills each new page by itself as you press the site's Next (it never presses Next
itself). The panel says "Run mode: will fill each page as you go"; **Stop** turns it off, and it stops by itself on the
confirmation page. Where the site has an **Add another** button for experience, the panel asks before pressing it.

### The panel's groups

- **Fields on this page**: contact details, right to work, start date, education. Amber means the site needs you (a
  typeahead with no good match, a date only a calendar can set), with the reason underneath.
- **My answers**: your standing answers for questions every form asks, each with **Fill** or **Leave** (left for you).
  Change the mode, or press the pencil to change the answer; it is saved for every form. **All my answers** opens
  Options > My answers, where every answer can be edited.
- **Questions**: long answers from your answer bank (as before), now also in rich text editors.
- **Your confirmation needed**: privacy, terms, data-processing and "the information is accurate" boxes. They are never
  ticked; **Jump to** scrolls to each one so you can read and tick it.
- On a **sign-in or create-account page** the panel fills only your email (and your name when creating an account) and
  says "Use your password manager for the password."
- With a **CAPTCHA** on the page it says "Complete the CAPTCHA yourself" and doesn't touch it.
- If a site **refuses an attached file**, the file row offers **Show in Finder**, **Download** and **Copy file path**, so
  you can drag it in yourself.

The panel can be dragged by its header, collapsed to a pill with the minus button, and hidden on a page with the cross.

## What it will and won't do

- **It never submits.** It never presses Submit, Apply, Next, Continue, Save, Review or anything like them, and it never
  sends Enter to a form. The only things it ever clicks are radio buttons, checkboxes, dropdown and list options, Yes/No
  answers and (after you say so) an Add another button, each checked against those words first. Typing sends only
  letters, digits and spaces. The one exception: when a typeahead's list is open and focus is inside it, it may press
  ArrowDown and then Enter to choose the option the list itself has highlighted, if the option can't be clicked.
- **It fills only what you tick**, and shows every value before it fills.
- **Next role and Skip this role** change the tab's address to the next posting's link. They never click anything on
  the page.
- **The record of what you sent** is made by reading the form when you submit it, or when you leave the page after a
  fill. It only listens: it never sends, delays or changes the submit. Equal-opportunity, salary and password fields are
  left out. The PDF is saved by Job Hunter in `snapshots/` on this computer.
- **Your standing answers** live in `profile/my_answers.json` (Options > My answers). Defaults: how you heard "Company
  careers website"; salary £65,000 base (free-text boxes: "£65,000 base, open to discussion depending on the overall
  package"; number-only boxes: 65000; a list of ranges: the one containing 65,000; roles in Ireland or paid in euro:
  €75,000); previously employed here "No"; notice period from `profile/answers.json`; open to relocation "Yes"; gender,
  ethnicity, sexual orientation, disability, veteran status, religion and age range "Prefer not to say" (the nearest
  decline option on the form). Date of birth is empty and left for you. Set any of them to **Leave for me** to answer
  it yourself on each form.
- **It leaves to you:** consent, privacy and "information is accurate" boxes; "if yes, give details" follow-ups;
  pronouns; passwords; CAPTCHAs; date-only-by-calendar boxes; anything you set to Leave; anything that didn't match an
  option well enough (shown in amber with the reason).
- **Passwords are never read, filled or stored**, and consent boxes are never ticked.
- **Your data stays on this computer.** The extension talks only to Job Hunter at `http://127.0.0.1:8765` (or
  `localhost`), through its background worker. No other servers, no analytics. Pages can't read the panel.
- **Optional lines** are true facts from `profile/facts.md`, each tied to a line of the posting. **Tailored CVs** only
  reorder, trim or re-emphasise what is already in your CV, and are only attached once you approve them.

## Options

Right-click the toolbar button, then **Options**.

- **Connection**: change the Job Hunter address (only `127.0.0.1` or `localhost` are allowed) and test the connection.
  Leave "Let page scripts see the panel" off; it exists for the automated tests.
- **My answers**: every standing answer with its value and its mode (**Fill automatically** or **Leave for me**).
  Equal-opportunity answers are free text: "Prefer not to say" picks the nearest decline option; write your own answer
  to use it instead. Press **Save my answers**.

## Sites

| Site | Notes |
|---|---|
| Greenhouse (`job-boards.greenhouse.io`, `boards.greenhouse.io`, embedded boards) | Typeaheads and react-select menus (location, school, degree, phone country code, Yes/No questions) are typed into and the best-matching option is picked from the list. |
| Lever (`jobs.lever.co`) | Full name, links, radio questions. "Current company" is offered but unticked. |
| Ashby (`jobs.ashbyhq.com`) | Yes/No answer buttons are pressed only when they're plain buttons, not submit buttons. |
| Workday (`*.myworkdayjobs.com`) | Step by step, or with Run. Dropdowns, search prompts ("How did you hear", school), MM/YYYY date boxes (typed), experience and education boxes, Add another, the drag-and-drop file zone, and the email on sign-in and create-account pages. The phone number goes in without +44 (Workday has its own country code box). |
| SmartRecruiters | Fields drawn inside web components are found too. |
| Anything else | Fields are recognised by their labels, so most careers forms work. |

## If something doesn't work

- **"Job Hunter isn't running"**: double-click `Open Job Hunter.command`, then **Try again** in the panel.
- **No panel**: click the toolbar button. If the page isn't one of your postings and you haven't clicked Apply in the
  last two hours, choose the role with **Not this role?** or **Choose a role**.
- **A value didn't stick** (amber or red mark): the reason is under it. Fill that one by hand.
- **A file didn't attach**: press **Show in Finder** (or **Download**) under it and drag the file onto the upload box.
  **Copy file path** puts its path on the clipboard: in the site's file dialog press ⌘⇧G and paste it.

## Dates, grades and employment

- Dates are written the way each box asks: native date and month pickers, `DD/MM/YYYY`, `MM/YYYY` and similar (read from
  the placeholder, pattern or hint), separate day, month and year lists, and Workday's MM and YYYY boxes. Start
  availability comes from your standing answers; education and employment dates come from your CV.
- Grades come from your CV, matched to the wording a form uses (a UK classification written out in full, a GPA, IB points).
- Employment comes from your CV with any corrections in `profile/employment.json`, which is read first (for example, one
  employer split into two roles after a promotion), with your CV bullets split between them word for word. A single
  free-text work-history box gets the one-line history written there. Check what autofill will use with `python3 scripts/autofill.py --employment`.

Safari: see `SAFARI.md`.
