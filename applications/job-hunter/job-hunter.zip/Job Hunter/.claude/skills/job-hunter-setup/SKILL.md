---
name: job-hunter-setup
description: Connect Claude to Job Hunter. Reads what the user put in the setup window (details, CVs, sample cover letters, industries), writes their profile (facts, voice, preferences, CV notes, firm list), schedules the weekday search and marks Claude as connected. Use when the user types /job-hunter-setup, asks to set up or connect Job Hunter, or has changed their CVs, letters or industries and wants Job Hunter to catch up.
---

# Set up Job Hunter for this user

You are in the Job Hunter folder. The user filled in the setup window in the dashboard (http://localhost:8765, "Setup" at
the top). Your job is to turn that into everything the daily search (`RUN.md`) needs. Work through the steps in order and
tell the user briefly what you're doing as you go. Never invent anything about them: every fact comes from their CVs, their
letters or their own answers to you.

## 0. Check the setup window is done
Check the Python packages Job Hunter uses: `python3 -c "import docx, openpyxl"`. If that fails, run
`pip3 install --user python-docx openpyxl` (ask first).

Run `python3 scripts/user.py`. If `ready` shows details, cvs, samples or industries as false, tell the user which part of the
setup window to finish (open http://localhost:8765 and click Setup), then stop.

If `profile/facts.md`, `profile/style-guide.md`, `profile/preferences.md` or `profile/firms.json` are missing, copy them from
`templates/profile/` first. If they already exist and have real content, this is an update: keep what's there, change only
what the new CVs, letters or industries call for, and say what you changed.

## 1. Read the CVs and write the facts bank
`python3 scripts/user.py cvs` lists each CV and its file. Read every one (Read the PDF directly; for .docx use
`textutil -convert txt -stdout "<file>"` on a Mac, or python-docx elsewhere). Then write `profile/facts.md` from `templates/profile/facts.md`:
- Who they are now, education, and one section per employer with dates, titles, responsibilities and results, taken from
  the CVs word for word where figures are involved. Where CVs disagree, ask the user which is right.
- The contact block at the end, built from profile/user.json (city | phone | email | LinkedIn).
- Ask the user, in one short message, the questions a form or letter will need and the CVs don't answer: right to work in
  each country they're targeting (and whether they need sponsorship), notice period or start date, target base pay, the
  level they're aiming for, whether they hold a driving licence, any professional qualifications, and one or two things they
  are proud of that the CV undersells. Record only what they tell you, under "Standing answers" or the employer it belongs to.

Then give each CV a one-line note in `profile/cvs.json` (the `note` field): what it emphasises and which kinds of role it suits.
Keep each entry's other fields as they are.

## 2. Learn their voice from the sample letters
Read every file in `profile/sample-letters/` (PDF, Word or text; `profile/sample_letters.json` lists them). Write
`profile/style-guide.md` from `templates/profile/style-guide.md`, filling in "Their voice" with concrete observations: tone
and register, openings and closings, sentence length, spelling (British or American), how they describe themselves and the
firm, favourite turns of phrase, length and paragraph shape. Quote only short fragments, never whole sentences, and keep
every rule in the rest of the template. Where their letters break one of the hard rules (dashes, stock phrases), follow the
rule, not the habit.

## 3. Turn their industries into preferences
`profile/industries.json` holds what they typed, such as "Capital raising" or "Climate tech sales", with optional notes.
Write `profile/preferences.md` from `templates/profile/preferences.md`:
- Who, start date, locations, seniority and pay from facts.md and their answers in step 1. Also add their cities to
  `profile/user.json` as `"locations": ["London", "Dublin"]` (the sweep reads it).
- One section per industry, headed with its name exactly as typed. Expand it into what it means in practice: the role
  titles it covers, similar roles under other names, the kinds of employer, 15 to 40 example firms of real quality, and
  what not to include. Read it broadly: "Capital raising" also means investor relations, fundraising, placement agents and
  LP relations.
- For each industry, add to its entry in `profile/industries.json`:
  `"titles"`: a regex of title words worth reading (case-insensitive, broad), `"exclude"`: a regex of title words that are
  never right for this user at this level (for example senior titles or unrelated functions), and `"cv"`: the key of the CV
  that suits it best by default. Keep `key`, `name` and `notes` as they are.

## 4. Build the firm list
For each industry, add the example firms to `profile/firms.json` as
`{"firm": "...", "sector": "<industry name exactly>", "ats": "...", "url": "<careers page>"}`. Find each firm's job board:
Greenhouse (`"ats": "greenhouse", "slug"`), Lever (`"lever", "slug"`), Ashby (`"ashby", "slug"`), SmartRecruiters
(`"smartrecruiters", "slug"`) or Workday (`"workday", "tenant", "wd", "site"` from a URL like
`https://<tenant>.<wd>.myworkdayjobs.com/<site>`); look at the other entries in the file for the exact shape. If the board
isn't one of those, use `"ats": "page"` with the careers URL, and the daily run checks it by hand. Test a few with
`python3 scripts/sweep.py --firm "<firm>"` (it should list roles or say 0, not fail).

## 5. Schedule the weekday search
The daily search runs by itself, so it shouldn't stop to ask permission for every command. Before creating the task,
tell the user in one line that it works best if they switch this session to **Auto** permissions (the mode picker by the
message box), because the task is saved in the session's mode; wait for them to say they've switched or would rather not.

Create a scheduled task with the scheduled-tasks tools (load them with ToolSearch if they're deferred). Each run starts
fresh in no particular folder, so the prompt must name this folder's full path (`folder` in `python3 scripts/user.py`):
- taskId `job-hunter-daily`, title "Job Hunter: daily search", `cronExpression` `30 7 * * 1-5` (weekdays 07:30, local time)
- prompt: "Run the Job Hunter daily search. Work in the folder <full path>. Open <full path>/RUN.md and follow it step by
  step, then reply with the summary it asks for. Never invent a posting, salary or fact about the user, never log in to
  any site, submit an application or send any message."

If the result says the task wasn't saved in Auto mode, tell the user the morning run may pause to ask for approval, and
that they can change its mode in the Scheduled list. Tell them it only runs by itself if the Claude app is open at
07:30; if it wasn't, they start it from the Routines section in Claude (or type "run a search" here). If the scheduled-tasks tools aren't available, tell the user how to add
it themselves in the Claude desktop app (Code tab, Scheduled, New task, with the same name, time and prompt), and wait
for them to confirm.

Then write `profile/claude.json`:
`{"connected_on": "<YYYY-MM-DD>", "task": "job-hunter-daily", "schedule": "Weekdays at 07:30"}`.
The setup window shows Claude as connected as soon as this file exists.

## 6. Optional: replies from employers
If the user wants the tracker to move on its own when firms reply, they can connect Gmail in Claude's connectors settings;
the daily run reads it (read only) when it's connected. Mention this once; don't push.

## 7. Finish
Tell the user what you set up, in a few lines: their industries and how you read each one, which CV goes with what, the
number of firms you'll check, and when the search runs. Say whether CV tailoring is on (`tailor_cvs` in
`python3 scripts/user.py`): when it's on, Claude may suggest a copy of a CV reordered, trimmed or with lines brought in
from their other CVs, never anything new, and each one waits for their approval; they can switch it in Setup > CVs.
Offer to run the first search now (follow RUN.md).
