---
name: job-hunter-start
description: Start Job Hunter and take the user to whatever comes next. Opens the dashboard, installs what's missing (with permission), walks a new user through the setup window, connects Claude, or for someone already set up says what's waiting and offers a search. Use when the user types run, start, open, launch, go or set up in the Job Hunter folder, or asks what to do with it.
---

# Start Job Hunter

The user wants Job Hunter running. They may have just unzipped it and know nothing about it, or use it every day. Keep
messages short and plain: no jargon, no file paths unless they need one. Do the steps in order and don't ask before
starting the dashboard; that's what they asked for.

If they asked for a job **search** ("run a search", "run today's search"), that's `RUN.md`, not this skill: follow RUN.md.

## 1. Start the dashboard
Run `python3 scripts/start.py`. It starts the dashboard if it isn't already running, opens it in their browser, and prints
the status as JSON.
- If `python3` isn't found, or macOS offers to install "command line developer tools": tell the user to click Install in
  that window (it takes a few minutes), wait for them to say it's done, then run start.py again.
- If `dashboard` is null, read the log it names, fix what you can and run it again. If the port is busy with something
  else, say so.

## 2. Install what's missing
If `missing_packages` isn't empty, say in one line what they're for (Word CVs and letters, and the Excel export), ask
to install them, then run `pip3 install --user python-docx openpyxl`. If pip refuses ("externally managed"), use
`python3 -m pip install --user python-docx openpyxl`. Check with `python3 -c "import docx, openpyxl"`.

## 3. Go to wherever they are
Use `setup` from the status (details, cvs, samples, industries, claude).

**A. Setup isn't filled in** (any of details, cvs, samples or industries is false). It's a new user, or they stopped
halfway. Tell them:
- Job Hunter is open in their browser, with a Setup window.
- What it needs, in a few short lines: their details, their CVs (as many as they like; Claude picks the right one for each
  role), up to five cover letters they've written (so letters sound like them), and the industries they want, typed in
  their own words, such as "Capital raising".
- To come back here and say **done** when they reach the last step, "Connect Claude".

When they say done, run `python3 scripts/user.py`. If something is still missing, say which part and wait again. If it's
all there, carry on with B straight away.

**B. Setup is filled in but Claude isn't connected** (`claude` is false). Say you'll now read their CVs and letters,
ask a few questions and schedule their daily search. Then follow `.claude/skills/job-hunter-setup/SKILL.md` from step 0
(the /job-hunter-setup skill). At the end, if the Setup window is still open in their browser, tell them to click
**Finish**.

**C. Everything is set up.** Say hello by first name and give a short status from `roles`, such as: 6 new roles to look
at, 12 applied, 1 interview. Mention the last search date only if it's more than a weekday ago. Then offer, in one line,
to run a search now (RUN.md). Don't run one unless they say yes.

## 4. Finish
Close with two short lines:
- The dashboard is at http://localhost:8765. To open it later without Claude, double-click **Open Job Hunter.command** in
  this folder (on a Mac; on Windows, type run here).
- The search runs by itself at 07:30 on weekdays if the Claude app is open then. If it wasn't, start it from the
  Routines section in Claude, or type "run a search" here.
  Type **run** here any time.
Say the second line only the first time (cases A and B).
