# Daily job search: how a run works

Folder: the Job Hunter folder this file is in. Each run starts fresh, so follow these steps in order.
Job Hunter works for whoever set it up: their details, CVs, writing samples and industries come from the setup window
(`python3 scripts/user.py` prints them). "The user" below means that person; address them as "you" in what you write for them.

## 1. Read the profile
- `profile/preferences.md`: what to look for (industries, locations, start date, pay, seniority, how many per run).
- `profile/industries.json`: the industries the user typed in during setup, in their own words, each with notes. Every role's
  `sector` is one of these names, exactly; read each industry broadly and find roles similar to what they described.
- `profile/facts.md`: the only claims a letter may make.
- `profile/style-guide.md`: how the user writes. Their own letters are in `profile/sample-letters/` (and
  `profile/examples.md` / `profile/example-*.json` where present); read two or three before writing.
- `profile/cvs.json` (`python3 scripts/user.py cvs`): the user's CVs, each with a note on what it emphasises. Pick the best
  CV for every role yourself (see step 3); an industry's `cv` in industries.json is only the default.
- Run `python3 scripts/jobs.py seen` to list what's already tracked. Never re-add those.
  Look at the jobs marked `pass`: they show what the user doesn't want (firm type, role type, pay). Avoid similar ones.

## 1b. Check the postings the user is still considering
Some postings close before they get to them. A closed role leaves the dashboard but is kept for a month in case it reopens.
- Run `python3 scripts/postings.py auto`. It checks every role with status new or interested, including those already in the
  vault, and records each result. Greenhouse, Ashby and Lever are read through their APIs, Workday through its API or a real
  browser, LinkedIn through the public page, and anything else through the page itself.
- For each posting it lists as needing a manual check, open the posting (WebFetch, or `node scripts/dev/pagetext.mjs <url>`
  for pages that only render in a browser). Decide whether it is still accepting applications: look for a working apply
  button and no "closed", "no longer accepting" or "doesn't exist" notice. Record each with
  `python3 scripts/postings.py set <id> open|closed`. If you can't tell, leave it alone; don't guess.
- Run `python3 scripts/postings.py expire`. It removes roles that have been in the vault for more than 30 days.
- Never check, vault or remove roles marked applied or passed. The script refuses to.
- In the final summary, list any roles moved to the vault, any that reopened and came back, and any that expired.

## 1c. Read Gmail for replies to applications
If the user's Gmail is connected, the tracker moves on its own when firms write back. **Read only:** never send, reply,
draft, label, archive, star or delete anything, and never open links in emails.
- Search since two days before the `gmail_checked` date in `data/jobs.json` (search_threads, `-in:sent`), for example
  `after:YYYY/MM/DD -in:sent (application OR applying OR applied OR candidacy OR interview OR assessment OR hirevue OR
  unfortunately OR regret OR "next steps" OR invitation OR offer)`, plus a second search for messages from the applicant
  systems (`from:(myworkday.com OR greenhouse-mail.io OR ashbyhq.com OR smartrecruiters.com OR lever.co OR
  teamtailor-mail.com OR pinpoint.email OR hirevue.com OR avature.net)`). Skip newsletters, job alerts, IE Careers mail
  and login or verification codes.
- Match each message to a tracked role by firm and role title (`python3 scripts/tracker.py sheet` lists them, and
  `python3 scripts/jobs.py seen` lists every role). Read the body when the snippet doesn't make the outcome clear.
  Decide the kind:
  `acknowledged` (application received) · `update` (anything else from the firm about it) · `screening` (recruiter call)
  · `assessment` (test, game, video interview, case, task) · `interview` · `offer` · `rejected` · `closed` (the firm
  withdrew the role).
- Record each with `python3 scripts/tracker.py email <id> --date YYYY-MM-DD --kind <kind> --subject "<subject>"
  --sender <address> --thread <Gmail thread id>`. It keeps only those fields, never the body. It moves the stage
  forward, or to rejected; it marks a role applied if it wasn't, and brings it out of the vault.
- An application the user made outside Job Hunter: add it first with `python3 scripts/tracker.py external --firm "..."
  --title "..." --sector "<one of the five>" --location "..." --applied YYYY-MM-DD [--url ...]`, then record its emails.
- An interview or test with a date and time: add it as an event on the role (in `data/jobs.json` via
  `tracker.set_event`, kind `interview` or `assessment`, ISO time with the offset the email gives, the meeting link).
- Then `python3 scripts/tracker.py no-reply` (four weeks with no contact at all counts as rejected) and
  `python3 scripts/tracker.py gmail-checked`.
- If the Gmail tools aren't available in this run, say so in the summary and carry on.
- In the summary, list every interview or assessment invite first, then rejections, then roles marked no reply.

## 2. Search (one search per industry in `profile/industries.json`, in parallel if you can)
Each industry is what the user typed, such as "Capital raising"; its notes and the matching section of preferences.md say
more. Look for roles that are the same thing under other names, not only exact title matches.
- **Start with `python3 scripts/sweep.py`.** It reads the job board of every firm in `profile/firms.json` (the firm lists in
  `profile/preferences.md`) and prints each open role in the user's locations that might suit them and isn't tracked yet, by sector.
  Read every role it lists: open the posting and judge it against the preferences. Don't skip a firm because it seems
  unlikely; the sweep exists because whole firms were being missed.
- The sweep also lists firms whose careers site has no readable API, oldest check first. Look at as many as you can on their
  own careers page (WebFetch, or `node scripts/dev/pagetext.mjs <url>` for pages that only render in a browser), and record each
  one with `python3 scripts/sweep.py checked "<firm>" <roles kept>` so the next run starts with the others.
- Graduate and "2027 start" intakes (consulting, expert networks, some asset managers) are posted months ahead and stay open.
  Judge them by whether they're still open, not by how old the posting is.
- If you find a good firm that isn't in `profile/firms.json`, add it there (check its board with `--firm "<name>"` first).
- Then widen out with web search, public LinkedIn job pages and the job boards that suit the user's industries and country. Only keep roles at firms that meet
  the "Firm quality" bar.
- Respect every firm or role the preferences rule out.
- Never log in and never submit anything.
**Verify every posting by fetching it**: it must be real, open, in one of the user's locations, and at the right level.
The `url` must be the page where the user applies (the posting or its application page), never a PDF, a careers home page or a
search results page. If a firm only publishes a PDF brief and takes applications by email, set `url` to the careers page that
lists the role, add `"apply_email"`, and start `red_flags` with "How to apply: …". `jobs.py add` rejects PDF links without
`apply_email`.
Drop anything you can't verify, and never invent a posting, URL or salary.

## 3. Pick the top 10
Rank by fit across all sectors. Spread across sectors where the quality allows, but don't force it.
Write the picks to `data/picks.json` as an array of objects with these fields:
`firm, title, sector` (one of the industry names in `profile/industries.json`, exactly),
`location, url, posted, deadline, salary` (prefix estimates with "est."), `salary_meets_target` (true/false/null),
`experience_asked, fit` (0–100), `reason` (one sentence, addressed to the user as "you"), `red_flags`, `cv_note` (one line on why that CV),
`posting_highlights` (3–6 short bullets from the posting), `firm_facts` (1–3 checkable facts), `team`,
plus `cv` (the key of the best CV in `profile/cvs.json` for this role; set it every time) and `in_financial_services` (BD roles only).
Then run `python3 scripts/jobs.py add data/picks.json`. It prints the new ids and the CV picked for each.

## 4. Write a cover letter for each new pick
For each id, write `data/letters/<id>.json`:
`{"firm": "...", "role": "<exact posting title>", "city": "<the role's city>", "paragraphs": ["...", "..."]}`
(optional `"salutation": "Dear <Name>,"` if the posting names a person).
Before writing, research the company: read the posting and the firm's own website (about, strategy, funds or products, recent news)
and pick one or two things that show the user knows the firm, kept high level or tied to why they matter to them (see
the research rule in the style guide). The tone is humble and keen: never lecture the firm, never claim mastery. Put every firm claim in the spec's `"sources"` list as
`{"claim": "...", "url": "..."}`.
Follow `profile/style-guide.md` exactly: 520-620 words so the letter fills the page, personable and excited about this company,
selling the strengths this role needs, past roles as stories not CV lines, no dashes, nothing invented, in the user's own
voice (from their sample letters). `make_letter.py` rejects letters with dashes, stock AI phrases or the wrong length; fix and re-run.
Then run:
```
python3 scripts/make_letter.py data/letters/<id>.json
python3 scripts/jobs.py set-letter <id> "<docx path printed>" "<pdf path printed>"
```
Read every letter back once before moving on: no invented facts, no sentence copied from another letter, and it fits on one page.

## 4b. Prepare autofill for each new pick
The browser extension (see `extension/README.md`) fills the user's applications from their CV. For each new id:

**Extra lines.** Write `data/autofill/<id>.json` with up to 4 optional lines they can tick on to add to a role description:
```
{"extras": [{"text": "...", "reason": "Posting: \"<the highlight it answers>\"", "attach": "<employer, exactly as on the CV>"}]}
```
- Each `text` is a true fact from `profile/facts.md` that their CV for this role doesn't already say, tied to one of the
  posting's highlights. Write it as a CV line (starts with a verb or a plain noun phrase, no "I", no "he" or "she"), professional
  register per `profile/style-guide.md`, and no dashes of any kind.
- `attach` is the job it belongs to, exactly as the employer is named on the CV.
- Only include lines that genuinely help this application. Fewer is fine; none is fine.
- Check with `python3 scripts/autofill.py --id <id>`. Any line with a dash, or a word or figure not found in facts.md or
  the CVs, is held back and listed under `extras_held_back`. Rewrite it or drop it.

**Tailored CV (only when the user has it switched on, and only when it would genuinely help).** Check
`python3 scripts/user.py` or `profile/user.json`: if `tailor_cvs` isn't true, skip this step entirely and use the CV as it is.
Most roles don't need one; the right one of their CVs is enough. Suggest one only when the posting leans on something
their CV for that sector buries, for example a client-facing role where the CV leads with approvals, or a modelling-heavy
role where the P&L work sits last, or when another of their CVs words the same job in a way that fits this role better.
A tailored CV may only reorder, trim or re-emphasise what is already in their CVs and facts.md, or bring in a line from
another of their CVs. It never adds a claim, never rewrites a bullet, and never uses a dash. Never borrow a line that
facts.md contradicts or corrects (facts.md wins), and never move a line to a different employer.
Write a spec (anywhere, e.g. `data/tailored/<id>-spec.json`):
```
{"reason": "one line, to the user, on why this helps",
 "summary": "optional new Professional Summary, 25 to 90 words, facts only",
 "bullets": {"<Employer A>": [5, "CV Tech:1", 1, 2, 4], "<Employer B>": [2, 1]},
 "skills": ["optional", "skills from any of their CVs, in the order that suits the role"]}
```
`bullets` lists the bullets to keep for each employer, in the new order: a number is this CV's own bullet (1 is the first
on the CV), and `"<CV key>:<n>"` brings in bullet n for the same employer from another of their CVs, word for word
(`python3 scripts/user.py cvs` lists the keys). Any of this CV's bullets left out are dropped, so when you bring one in,
usually drop the one it replaces to keep the page to one sheet. Never drop a whole job. Then run `python3 scripts/tailor_cv.py <id> <spec.json>`. It refuses anything not
traceable to facts.md or the CV, and any dash; fix the spec and re-run. It writes the .docx and .pdf to `cvs/` and marks
the CV **suggested**. Open the PDF once to check it still fits on one page. The user approves it in the panel before it can
be attached; never mark it approved yourself.

## 4c. Write the answer bank for each new pick
Application forms ask free-text questions ("Why do you want to work at X?", "Tell us about yourself"). The extension
fills them from `data/answers/<id>.json`. For each new id (and any open role `python3 scripts/answers.py todo` lists):
```
{"id": "<id>", "source": "letter", "answers": [
  {"key": "why_firm", "question": "Why do you want to work at <Firm>?", "answer": "..."},
  {"key": "why_role", "question": "Why are you interested in this role?", "answer": "..."},
  {"key": "about_you", "question": "Tell us about yourself.", "answer": "..."},
  {"key": "strength", "question": "What would you bring to the team?", "answer": "..."},
  {"key": "motivation", "question": "What motivates you?", "answer": "..."}]}
```
- Draw each answer from that role's letter spec (`data/letters/<id>.json`) and `profile/facts.md`, re-cut as a standalone
  answer to the question, in the professional register of `profile/style-guide.md`. Don't paste whole letter paragraphs.
- Lengths: why_firm and why_role 120 to 180 words, about_you 100 to 150, strength and motivation 60 to 150.
- Never answer salary, equal-opportunity, date of birth, "how did you hear about us" or consent questions. Nothing invented.
- `patterns` are optional: each key has default question patterns. Add your own only for an unusual question the posting asks.
- Check with `python3 scripts/answers.py check <id>`. It holds back any answer with a dash, a phrase `make_letter.py`
  bans, a word or figure not found in facts.md, the CVs, the letter, the posting or the style guide, or the wrong length.
  Rewrite until every answer prints `ok`. Standard answers (availability, right to work, LinkedIn) live in
  `profile/answers.json`; only change them if a fact in facts.md changes.

## 4d. After applying: follow-ups and interview prep
The user records stages (screening, interview, offer...) and events on the dashboard. The only automatic stage changes
are the Gmail check and the four-week rule (step 1c); never change a stage any other way.
- Run `python3 scripts/tracker.py followups`. It moves overdue follow-up nudges on roles still at the applied stage to the
  next date (7 days after applying, then every 14 days). List what it moved in the summary.
- Run `python3 scripts/tracker.py prep-due`. For each role it lists (stage interview, no prep sheet yet), write
  `prep/<id>.md`, an interview prep sheet. Start from `python3 scripts/tracker.py prep-skeleton <id>` and fill it in from
  the posting, the firm facts and sources, the letter and facts.md. It has these sections, in this order:
  1. **Logistics:** date, time, format, who (from the role's events), the posting link, the CV that was sent.
  2. **The pitch:** a 60-second answer to "tell me about yourself" for this firm: who they are, why this firm, why this role,
     what they bring. Four or five sentences in their voice.
  3. **Evidence table:** one row per posting highlight: what they want, the user's evidence from facts.md, the story to tell.
  4. **Likely questions with answer outlines:** 8 to 12 questions (why this firm, why this role, CV walk-through,
     competency questions the posting points to, their honest gap), each with three or four bullet points.
  5. **Questions to ask them:** four to six, specific to the team and the firm, never answered by the posting itself.
  6. **Firm facts to have to hand:** checkable facts with sources, kept short.
  Same rules as the letters: nothing invented, no dashes. Check with `python3 scripts/tracker.py prep-check <id>`.
  Mention each new prep sheet in the summary.

## 5. Finish
`python3 scripts/jobs.py run "<n> new: <short summary>"`. Then reply with one line per new role:
fit · firm · title · CV to use · salary. Add "tailored CV suggested" to any role that has one, and say if any new role
is missing its answers file. Then list follow-ups moved and prep sheets written (step 4d).
